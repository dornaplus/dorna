# نرم‌افزار حسابداری و انبارداری فینتو (PHP + MySQL)

نرم‌افزار کامل حسابداری، انبارداری، فروش/خرید، خزانه‌داری، چک، حقوق و دستمزد، گزارش‌ها، تنظیمات، اشتراک و ثبت‌نام.

## شروع سریع

**هاست سی‌پنل:** فایل‌ها را در `public_html` آپلود کنید → دیتابیس و کاربر بسازید → `install.php` را در مرورگر باز کنید.
راهنمای کامل: [`نصب-روی-سی-پنل.md`](نصب-روی-سی-پنل.md)

**کامپیوتر شخصی:**
```bash
bash tools/run.sh          # سپس http://localhost:8080/install.php
```

## مستندات

| فایل | توضیح |
|---|---|
| `نصب-روی-سی-پنل.md` | نصب گام‌به‌گام روی cPanel (آزمون‌شده) |
| `راهنمای-اجرا.md` | اجرای محلی، تنظیمات، آزمون‌ها و رفع اشکال |
| `db/README.txt` | فایل‌های نصب دیتابیس و روش ایمپورت در phpMyAdmin |

## آزمون‌های خودکار

```bash
php tools/check_links.php && php tools/check_modules.php && php tools/check_sql.php
php tools/check_schema_usage.php && php tools/check_transactions.php
php tools/http_test.php  http://localhost:8080   # ۱۲۵ آزمون صفحه/گزارش/ثبت‌نام
php tools/crud_test.php  http://localhost:8080   # ۲۵ ماژول
php tools/ops_test.php   http://localhost:8080   # ۱۵ جریان عملیاتی
FINTO_DB_NAME=finto_test php tools/smoke.php     # ۱۷ آزمون داده‌ای
```
