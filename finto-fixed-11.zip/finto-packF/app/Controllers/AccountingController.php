<?php
/** حسابداری: اسناد دستی، تراز افتتاحیه، حقوق و دستمزد، سال مالی */
final class AccountingController
{
    /* ───────────── فهرست اسناد ───────────── */
    public function journal(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $q = trim((string)($_GET['q'] ?? '')); $type = (string)($_GET['entry_type'] ?? ''); $source = (string)($_GET['source'] ?? '');
        $from = to_gregorian((string)($_GET['from'] ?? '')); $to = to_gregorian((string)($_GET['to'] ?? ''));
        $w = ['e.business_id=?', 'e.deleted_at IS NULL']; $pr = [$biz];
        if ($q !== '') { $w[] = '(e.entry_no LIKE ? OR e.description LIKE ? OR e.reference_no LIKE ?)'; array_push($pr, "%$q%", "%$q%", "%$q%"); }
        if ($type) { $w[] = 'e.entry_type=?'; $pr[] = $type; }
        if ($source) { $w[] = 'e.source=?'; $pr[] = $source; }
        if ($from) { $w[] = 'e.entry_date>=?'; $pr[] = $from; }
        if ($to) { $w[] = 'e.entry_date<=?'; $pr[] = $to; }
        $where = implode(' AND ', $w);
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 25;
        $totals = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(e.total_debit),0) debit FROM journal_entries e WHERE $where", $pr);
        $rows = Database::all("SELECT e.*, u.full_name AS creator FROM journal_entries e LEFT JOIN users u ON u.id=e.created_by
                                WHERE $where ORDER BY e.entry_date DESC, e.id DESC LIMIT ".($per*($page-1)).", $per", $pr);
        return view('pages/accounting/journal_index', ['title' => 'اسناد حسابداری', 'rows' => $rows, 'totals' => $totals, 'page' => $page, 'per' => $per,
            'q' => $q, 'type' => $type, 'source' => $source, 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '']);
    }

    /* ───────────── ثبت سند دستی ───────────── */
    public function createEntry(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('accounting.create')) abort(403, 'مجوز ثبت سند را ندارید.');
        return $this->entryForm(null);
    }

    private function entryForm(?array $entry): string
    {
        $biz = Auth::businessId();
        $lines = $entry ? Database::all('SELECT * FROM journal_entry_lines WHERE journal_entry_id=? ORDER BY row_no', [$entry['id']]) : [];
        return view('pages/accounting/journal_form', ['title' => $entry ? 'ویرایش سند '.$entry['entry_no'] : 'ثبت سند حسابداری', 'entry' => $entry, 'lines' => $lines,
            'accounts' => Database::all('SELECT id, code, title, person_required FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status="active" ORDER BY code', [$biz]),
            'persons' => Database::all('SELECT id, code, first_name, last_name, company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 400', [$biz]),
            'projects' => Database::all('SELECT id,name FROM projects WHERE business_id=?', [$biz]),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=?', [$biz]),
            'nextNo' => Sequence::peekNumber($biz, Auth::fiscalYearId(), 'journal'),
            'entryTypes' => ['normal', 'adjustment', 'opening', 'closing', 'payroll', 'transfer']]);
    }

    public function storeEntry(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('accounting.create')) abort(403, 'مجوز ثبت سند را ندارید.');
        $biz = Auth::businessId();
        $date = to_gregorian((string)post('entry_date')) ?: today();
        $lines = [];
        foreach ((array)($_POST['line_account_id'] ?? []) as $i => $accId) {
            if (!$accId) continue;
            $dr = fa_num(($_POST['line_debit'][$i] ?? 0));
            $cr = fa_num(($_POST['line_credit'][$i] ?? 0));
            if ($dr <= 0 && $cr <= 0) continue;
            $lines[] = ['account_id' => (int)$accId, 'debit' => $dr, 'credit' => $cr,
                'description' => $_POST['line_desc'][$i] ?? null,
                'person_id' => !empty($_POST['line_person_id'][$i]) ? (int)$_POST['line_person_id'][$i] : null,
                'cost_center_id' => !empty($_POST['line_cost_center_id'][$i]) ? (int)$_POST['line_cost_center_id'][$i] : null];
        }
        try {
            $id = Posting::create($biz, [
                'entry_date' => $date, 'entry_type' => (string)post('entry_type', 'normal'),
                'description' => (string)post('description') ?: null,
                'reference_no' => (string)post('reference_no') ?: null,
                'project_id' => post('project_id') ? (int)post('project_id') : null,
                'source' => 'manual',
            ], $lines);
            Flash::push('success', 'سند حسابداری ثبت شد.');
            redirect('app/journal/'.$id);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/journal/create'); }
        return '';
    }

    public function showEntry(array $p): string
    {
        Auth::requireApp();
        $e = $this->findEntry((int)$p['id']);
        $lines = Database::all('SELECT l.*, a.code AS account_code, a.title AS account_title, p.first_name, p.last_name, p.company_name,
                                       c.name AS cost_center_name, ch.cheque_no
                                  FROM journal_entry_lines l JOIN chart_of_accounts a ON a.id=l.account_id
                                  LEFT JOIN persons p ON p.id=l.person_id LEFT JOIN cost_centers c ON c.id=l.cost_center_id
                                  LEFT JOIN cheques ch ON ch.id=l.cheque_id
                                 WHERE l.journal_entry_id=? ORDER BY l.row_no', [$e['id']]);
        return view('pages/accounting/journal_show', ['title' => 'سند '.$e['entry_no'], 'e' => $e, 'lines' => $lines]);
    }
    public function reverseEntry(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('accounting.lock') && !Auth::can('accounting.edit')) abort(403, 'مجوز برگشت سند را ندارید.');
        try { $newId = Posting::reverse((int)$p['id'], (string)post('reason')); Flash::push('success', 'سند برگشتی #'.$newId.' صادر شد.'); redirect('app/journal/'.$newId); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); redirect('app/journal/'.$p['id']); }
        return '';
    }
    public function printEntry(array $p): string
    {
        Auth::requireApp();
        $e = $this->findEntry((int)$p['id']);
        $lines = Database::all('SELECT l.*, a.code AS account_code, a.title AS account_title FROM journal_entry_lines l JOIN chart_of_accounts a ON a.id=l.account_id WHERE l.journal_entry_id=? ORDER BY l.row_no', [$e['id']]);
        return view('pages/accounting/journal_print', ['title' => 'چاپ سند '.$e['entry_no'], 'e' => $e, 'lines' => $lines, 'business' => Auth::business()]);
    }

    /* ───────────── تراز افتتاحیه ───────────── */
    public function openingSetup(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $fyId = Auth::fiscalYearId();
        if (is_post()) {
            csrf_verify();
            try {
                $count = Database::transaction(function () use ($biz, $fyId) {
                    $lines = []; $rows = [];
                    foreach ((array)($_POST['debit'] ?? []) as $accId => $dr) {
                        $dr = fa_num($dr);
                        $cr = fa_num($_POST['credit'][$accId] ?? 0);
                        if ($dr <= 0 && $cr <= 0) continue;
                        $lines[] = ['account_id' => (int)$accId, 'debit' => $dr, 'credit' => $cr, 'description' => 'مانده افتتاحیه'];
                        $rows[] = ['account_id' => (int)$accId, 'debit_amount' => $dr, 'credit_amount' => $cr];
                    }
                    if (!$lines) throw new RuntimeException('مانده‌ای وارد نشده است.');
                    // حذف ترازهای قبلی همان سال
                    $old = Database::all('SELECT journal_entry_id FROM opening_balances WHERE business_id=? AND fiscal_year_id=? AND journal_entry_id IS NOT NULL', [$biz, $fyId]);
                    foreach ($old as $o) if ($o['journal_entry_id']) Database::run('DELETE FROM journal_entry_lines WHERE journal_entry_id=?', [$o['journal_entry_id']]);
                    foreach ($old as $o) if ($o['journal_entry_id']) Database::run('DELETE FROM journal_entries WHERE id=?', [$o['journal_entry_id']]);
                    Database::run('DELETE FROM opening_balances WHERE business_id=? AND fiscal_year_id=?', [$biz, $fyId]);
                    $jeId = Posting::create($biz, ['entry_date' => (Auth::fiscalYear()['start_date'] ?? today()), 'entry_type' => 'opening',
                        'description' => 'سند تراز افتتاحیه '.jdate(Auth::fiscalYear()['start_date'] ?? today()), 'source' => 'manual'], $lines);
                    foreach ($rows as $r) {
                        $r['business_id'] = $biz; $r['fiscal_year_id'] = $fyId; $r['journal_entry_id'] = $jeId; $r['is_locked'] = 1;
                        $r['created_at'] = now(); $r['created_by'] = Auth::id();
                        $r['currency_id'] = $r['currency_id'] ?? base_currency_id($biz);
                        Database::insert('opening_balances', $r);
                    }
                    return count($rows);
                });
                Flash::push('success', 'تراز افتتاحیه با '.$count.' ردیف ثبت شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/opening-balances/setup');
        }
        $balances = [];
        foreach (Database::all('SELECT * FROM opening_balances WHERE business_id=? AND fiscal_year_id=?', [$biz, $fyId]) as $b) $balances[(int)$b['account_id']] = $b;
        return view('pages/accounting/opening', ['title' => 'تراز افتتاحیه', 'balances' => $balances,
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status="active" ORDER BY code', [$biz]),
            'fy' => Auth::fiscalYear()]);
    }

    /* ───────────── حقوق و دستمزد ───────────── */
    public function createPayroll(array $p): string { return $this->payrollForm([]); }

    private function payrollForm(array $doc): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $employees = Database::all('SELECT e.*, s.base_salary, s.housing_allowance, s.food_allowance, s.child_allowance, s.other_allowances,
                                           s.insurance_rate_employee, s.insurance_rate_employer, s.tax_exemption_amount
                                      FROM employees e LEFT JOIN employee_salary_settings s ON s.employee_id=e.id
                                     WHERE e.business_id=? AND e.status="active" ORDER BY e.full_name', [$biz]);
        return view('pages/accounting/payroll_form', ['title' => 'ثبت سند حقوق و دستمزد', 'employees' => $employees, 'doc' => $doc,
            'components' => Database::all('SELECT id,title,component_kind,calc_type,rate_percent,default_amount FROM payroll_components WHERE business_id=? AND is_active=1', [$biz]),
            'cashAccounts' => Database::all('SELECT id,title FROM cash_accounts WHERE business_id=? AND status="active"', [$biz]),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1', [$biz]),
            'nextNo' => Sequence::peek($biz, Auth::fiscalYearId(), 'hr')]);
    }

    public function storePayroll(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $rows = [];
        foreach ((array)($_POST['employee_id'] ?? []) as $i => $empId) {
            if (!$empId) continue;
            $comps = [];
            foreach ((array)($_POST['comp_amount'][$i] ?? []) as $cid => $amt) {
                $amt = fa_num($amt);
                if ($amt == 0) continue;
                $comps[] = ['component_id' => (int)$cid, 'amount' => $amt];
            }
            $rows[] = ['employee_id' => (int)$empId, 'worked_days' => (float)($_POST['worked_days'][$i] ?? 30),
                'base_salary' => fa_num($_POST['base_salary'][$i] ?? 0),
                'deductions' => fa_num($_POST['deductions'][$i] ?? 0), 'components' => $comps];
        }
        try {
            $id = Trade::createPayroll(['doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'period_title' => (string)post('period_title') ?: ('حقوق '.jdate(today())),
                'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null], $rows);
            Flash::push('success', 'سند حقوق ثبت و سند حسابداری آن صادر شد.');
            redirect('app/payroll-documents/'.$id);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/payroll-documents/create'); }
        return '';
    }

    public function payPayroll(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $doc = Database::one('SELECT * FROM payroll_documents WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$doc) abort(404, 'سند حقوق یافت نشد.');
        try {
            if (!$doc['cash_account_id']) throw new RuntimeException('حساب پرداخت برای این سند تعیین نشده است.');
            $jeId = Posting::post((int)$doc['business_id'], 'payroll.payment', ['amount' => (float)$doc['net_amount']], [
                'date' => today(), 'cash_account_id' => (int)$doc['cash_account_id'], 'reference_type' => 'payroll_document',
                'reference_id' => $doc['id'], 'reference_no' => $doc['doc_no'], 'description' => 'پرداخت حقوق '.$doc['period_title']]);
            Database::run('UPDATE payroll_documents SET status="paid" WHERE id=?', [$doc['id']]);
            Trade::updateCashBalance((int)$doc['cash_account_id']);
            Flash::push('success', 'پرداخت حقوق ثبت شد (سند #'.$jeId.').');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll-documents/'.$p['id']);
        return '';
    }

    /* ───────────── سال مالی ───────────── */
    public function activateYear(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $fy = Database::one('SELECT * FROM fiscal_years WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$fy) abort(404, 'سال مالی یافت نشد.');
        Database::run('UPDATE fiscal_years SET is_current=0 WHERE business_id=?', [Auth::businessId()]);
        Database::run('UPDATE fiscal_years SET is_current=1 WHERE id=?', [$fy['id']]);
        Flash::push('success', 'سال مالی «'.$fy['title'].'» به عنوان سال جاری تعیین شد.');
        redirect('app/fiscal-years/'.$fy['id']);
        return '';
    }

    /** بستن سال مالی: انتقال مانده‌ها به سال جدید و قفل سال */
    public function closeYear(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $biz = Auth::businessId();
        $fy = Database::one('SELECT * FROM fiscal_years WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$fy) abort(404, 'سال مالی یافت نشد.');
        try {
            Database::transaction(function () use ($biz, $fy) {
                if ($fy['status'] === 'closed') throw new RuntimeException('این سال مالی قبلاً بسته شده است.');
                // محاسبه سود و زیان دوره و انتقال به حساب سود انباشته
                $pl = Database::all("SELECT a.account_type, SUM(l.debit_amount - l.credit_amount) AS bal
                                       FROM journal_entry_lines l JOIN journal_entries e ON e.id=l.journal_entry_id
                                       JOIN chart_of_accounts a ON a.id=l.account_id
                                      WHERE e.business_id=? AND e.entry_date BETWEEN ? AND ? AND a.account_type IN ('revenue','expense','cogs')
                                      GROUP BY a.account_type", [$biz, $fy['start_date'], $fy['end_date']]);
                $profit = 0.0;
                foreach ($pl as $r) $profit += ($r['account_type'] === 'revenue' ? -(float)$r['bal'] : -(float)$r['bal']);
                $profit = round($profit, 2);
                $retained = (int)($fy['kept_earnings_account_id'] ?: Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key="retained_earnings"', [$biz], 0));
                $profitAcc = (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key="current_profit"', [$biz], 0);
                $closeEntryId = null;
                if ($retained && $profitAcc && abs($profit) > 0.009) {
                    $lines = $profit > 0
                        ? [['account_id' => $profitAcc, 'debit' => $profit, 'description' => 'بستن حساب سود دوره'], ['account_id' => $retained, 'credit' => $profit, 'description' => 'انتقال سود به سود انباشته']]
                        : [['account_id' => $retained, 'debit' => abs($profit), 'description' => 'جبران زیان انباشته'], ['account_id' => $profitAcc, 'credit' => abs($profit), 'description' => 'بستن حساب زیان دوره']];
                    $closeEntryId = Posting::create($biz, ['entry_date' => $fy['end_date'], 'entry_type' => 'closing', 'source' => 'auto',
                        'description' => 'سند بستن سال مالی '.$fy['title']], $lines, ['skip_period_check' => true]);
                }
                Database::run('UPDATE fiscal_periods SET status="locked", locked_at=NOW() WHERE fiscal_year_id=?', [$fy['id']]);
                Database::run('UPDATE fiscal_years SET status="closed", closed_at=NOW(), closed_by=? WHERE id=?', [Auth::id(), $fy['id']]);
                // سال مالی جدید: ۱۲ ماه بعد از سال بسته‌شده
                [$ny] = gregorian_to_jalali((int)substr($fy['start_date'], 0, 4), (int)substr($fy['start_date'], 5, 2), (int)substr($fy['start_date'], 8, 2));
                [$s, $e] = jalali_year_range($ny + 1);
                $newFyId = Provisioner::createFiscalYear($biz, 'سال مالی '.($ny + 1), $s, $e, Auth::id());
                Database::insert('year_closing_logs', ['business_id' => $biz, 'from_fiscal_year_id' => $fy['id'], 'to_fiscal_year_id' => $newFyId,
                    'step' => 2, 'status' => 'success', 'ran_by' => Auth::id(),
                    'message' => 'بستن سال مالی '.$fy['title'].' با سود/زیان '.num($profit), 'closing_entry_id' => $closeEntryId,
                    'created_at' => now(), 'created_by' => Auth::id()]);
                Audit::log('close_year', 'fiscal_years', (int)$fy['id'], 'بستن سال مالی '.$fy['title'].' با سود '.$profit);
                Flash::push('success', 'سال مالی بسته شد و سال جدید ایجاد گردید.');
            });
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/fiscal-years/'.$p['id']);
        return '';
    }

    /* ───────────── مسیریابی فرم‌های اختصاصی همین کنترلر ───────────── */
    public function formCreate(array $m, array $p): string
    {
        return match ($m['key']) {
            'journal' => $this->entryForm(null),
            'payroll-documents' => $this->payrollForm([]),
            'opening-balances' => redirect('app/opening-balances/setup'),
            default => view('pages/resource/form', ['m' => $m, 'groups' => Fields::groups($m['table']), 'row' => [],
                'title' => 'تعریف '.$m['singular'], 'action' => url('app/'.$m['key']), 'isNew' => true, 'error' => null]),
        };
    }
    public function formEdit(array $m, array $p): string
    {
        return match ($m['key']) {
            'journal' => $this->entryForm($this->findEntry((int)$p['id'])),
            'payroll-documents' => $this->payrollForm(['id' => (int)$p['id']]),
            default => $this->genericEdit($m, (int)$p['id']),
        };
    }
    private function genericEdit(array $m, int $id): string
    {
        $row = Database::one('SELECT * FROM `'.$m['table'].'` WHERE id=?', [$id]);
        if (!$row) abort(404, 'رکورد یافت نشد.');
        return view('pages/resource/form', ['m' => $m, 'groups' => Fields::groups($m['table']), 'row' => $row,
            'title' => 'ویرایش '.$m['singular'], 'action' => url('app/'.$m['key'].'/'.$id), 'isNew' => false, 'error' => null]);
    }
    public function customSave(array $m, array $p, ?string $id): string
    {
        return match ($m['key']) {
            'journal' => $this->storeEntry($p),
            'payroll-documents' => $this->storePayroll($p),
            default => $this->genericSave($m, $id),
        };
    }
    private function genericSave(array $m, ?string $id): string
    {
        csrf_verify();
        try {
            $data = $_POST; unset($data['_token']);
            if (isset(Schema::columns($m['table'])['business_id'])) $data['business_id'] = Auth::businessId();
            if ($id) { $data['updated_at'] = now(); $data['updated_by'] = Auth::id(); Database::update($m['table'], $data, 'id=:pk', ['pk' => $id]); }
            else { $data['created_at'] = now(); $data['created_by'] = Auth::id(); Database::insert($m['table'], $data); }
            Flash::push('success', 'ذخیره شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/'.$m['key']);
        return '';
    }

    private function findEntry(int $id): array
    {
        $e = Database::one('SELECT e.*, u.full_name AS creator FROM journal_entries e LEFT JOIN users u ON u.id=e.created_by WHERE e.id=? AND e.business_id=?', [$id, Auth::businessId()]);
        if (!$e) abort(404, 'سند حسابداری یافت نشد.');
        return $e;
    }
}
