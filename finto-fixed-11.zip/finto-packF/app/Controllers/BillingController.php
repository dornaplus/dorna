<?php
/** خرید پکیج و مدیریت اشتراک */
final class BillingController
{
    public function plans(array $p): string
    {
        Auth::requireApp();
        $plans = Database::all('SELECT * FROM plans WHERE is_active=1 ORDER BY sort_order, id');
        foreach ($plans as $i => $pl) {
            $plans[$i]['features'] = Database::all('SELECT * FROM plan_features WHERE plan_id=? ORDER BY id', [$pl['id']]);
        }
        return view('pages/billing/plans', ['title' => 'پکیج‌های اشتراک', 'plans' => $plans,
            'current' => Database::one('SELECT s.*, pl.title AS plan_title FROM subscriptions s JOIN plans pl ON pl.id=s.plan_id WHERE s.business_id=? ORDER BY s.id DESC LIMIT 1', [Auth::businessId()]),
            'usage' => Database::all('SELECT * FROM subscription_usage WHERE business_id=? ORDER BY id DESC LIMIT 12', [Auth::businessId()])]);
    }

    public function subscribe(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $biz = Auth::businessId();
        $plan = Database::one('SELECT * FROM plans WHERE id=? AND is_active=1', [(int)$p['id']]);
        if (!$plan) { Flash::push('error', 'پکیج یافت نشد.'); redirect('app/plans'); }
        try {
            $payId = Database::transaction(function () use ($biz, $plan) {
                $current = Database::one('SELECT * FROM subscriptions WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz]);
                $start = today();
                if ($current && $current['expires_at'] > today()) $start = $current['expires_at'];
                $expires = date('Y-m-d', strtotime($start.' +1 year'));
                // دوره آزمایشی در صورت درخواست
                $useTrial = (bool)post('use_trial') && (!$current || $current['status'] === 'expired');
                $subStatus = $useTrial ? 'trial' : 'active';
                if ($useTrial) $expires = date('Y-m-d', strtotime($start.' +14 days'));
                if ($current) {
                    Database::run('UPDATE subscriptions SET is_active=0 WHERE id=?', [$current['id']]);
                }
                $subId = Database::insert('subscriptions', ['business_id' => $biz, 'plan_id' => $plan['id'], 'starts_at' => $start,
                    'expires_at' => $expires, 'status' => $subStatus, 'documents_used' => 0,
                    'documents_limit' => (int)$plan['included_documents'], 'auto_renew' => post('auto_renew') ? 1 : 0,
                    'trial_ends_at' => $useTrial ? $expires : null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
                $amount = (float)$plan['price_amount'];
                $taxRate = (float)(Settings::get('financial.vat_rate', 10));
                $payId = Database::insert('subscription_payments', ['business_id' => $biz, 'subscription_id' => $subId, 'plan_id' => $plan['id'],
                    'amount' => $amount, 'discount_amount' => 0, 'payable_amount' => $useTrial ? 0 : round($amount * (1 + $taxRate / 100), 2),
                    'payment_gateway' => (string)post('gateway', 'internal'), 'gateway_ref' => 'SIM-'.strtoupper(bin2hex(random_bytes(4))),
                    'status' => $useTrial ? 'pending' : 'paid', 'paid_at' => $useTrial ? null : now(), 'created_at' => now(), 'created_by' => Auth::id()]);
                foreach ([['documents', 0], ['users', 1], ['sms', 0]] as [$metric, $value]) {
                    Database::insert('subscription_usage', ['business_id' => $biz, 'subscription_id' => $subId, 'usage_date' => $start,
                        'metric' => $metric, 'used_value' => $value]);
                }
                if (post('sms_credits')) {
                    $units = (int)$plan['sms_credits'];
                    if ($units > 0) {
                        $bal = (float)Database::val('SELECT balance_after FROM message_credits WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz], 0) + $units;
                        Database::insert('message_credits', ['business_id' => $biz, 'tx_type' => 'purchase', 'units' => $units, 'balance_after' => $bal,
                            'unit_price' => 800, 'amount' => $units * 800, 'description' => 'اعتبار پیامک پکیج '.$plan['title'], 'created_at' => now(), 'created_by' => Auth::id()]);
                    }
                }
                Audit::log('subscribe', 'subscriptions', $subId, 'فعال‌سازی پکیج '.$plan['title']);
                return $payId;
            });
            Flash::push('success', 'پکیج «'.$plan['title'].'» فعال شد.');
            redirect('app/subscription');
        } catch (Throwable $e) { Flash::push('error', 'خطا در خرید پکیج: '.$e->getMessage()); redirect('app/plans'); }
        return '';
    }

    public function subscription(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $sub = Database::one('SELECT s.*, pl.title AS plan_title, pl.price_amount, pl.max_users, pl.sms_credits FROM subscriptions s
                               JOIN plans pl ON pl.id=s.plan_id WHERE s.business_id=? ORDER BY s.id DESC LIMIT 1', [$biz]);
        $payments = Database::all('SELECT sp.*, pl.title AS plan_title FROM subscription_payments sp LEFT JOIN plans pl ON pl.id=sp.plan_id
                                    WHERE sp.business_id=? ORDER BY sp.id DESC LIMIT 20', [$biz]);
        $usage = $sub ? Database::all('SELECT * FROM subscription_usage WHERE subscription_id=? ORDER BY id DESC LIMIT 12', [$sub['id']]) : [];
        $docCount = (int)Database::val("SELECT (SELECT COUNT(*) FROM invoices WHERE business_id=? AND status='posted') + (SELECT COUNT(*) FROM journal_entries WHERE business_id=? AND source='manual')", [$biz, $biz], 0);
        return view('pages/billing/subscription', ['title' => 'اشتراک من', 'sub' => $sub, 'payments' => $payments, 'usage' => $usage, 'docCount' => $docCount]);
    }

    public function pay(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $biz = Auth::businessId();
        $sub = Database::one('SELECT s.*, pl.title AS plan_title, pl.price_amount FROM subscriptions s JOIN plans pl ON pl.id=s.plan_id WHERE s.business_id=? ORDER BY s.id DESC LIMIT 1', [$biz]);
        if (!$sub) { Flash::push('error', 'اشتراک فعالی وجود ندارد.'); redirect('app/plans'); }
        try {
            $amount = round((float)$sub['price_amount'] * 1.1, 2);
            Database::insert('subscription_payments', ['business_id' => $biz, 'subscription_id' => $sub['id'], 'plan_id' => $sub['plan_id'],
                'amount' => (float)$sub['price_amount'], 'discount_amount' => 0, 'payable_amount' => $amount,
                'payment_gateway' => (string)post('gateway', 'internal'), 'gateway_ref' => 'SIM-'.strtoupper(bin2hex(random_bytes(4))),
                'status' => 'paid', 'paid_at' => now(), 'created_at' => now(), 'created_by' => Auth::id()]);
            Database::run('UPDATE subscriptions SET status="active", expires_at=DATE_ADD(GREATEST(expires_at, CURDATE()), INTERVAL 1 YEAR) WHERE id=?', [$sub['id']]);
            Flash::push('success', 'پرداخت اشتراک ثبت شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/subscription');
        return '';
    }
}
