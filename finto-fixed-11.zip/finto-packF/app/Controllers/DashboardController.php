<?php
/** داشبورد مدیریتی: شاخص‌ها، نمودار درآمد/هزینه، نقد و بانک، چک‌های نزدیک، فاکتورهای سررسید گذشته */
final class DashboardController
{
    public function index(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('dashboard.view') && !Auth::isAdmin()) abort(403, 'برای مشاهده داشبورد مجوز ندارید.');
        $biz = Auth::businessId();
        $kpi = Database::one('SELECT * FROM v_dashboard_kpi WHERE business_id=?', [$biz]) ?: [];
        $fy = Auth::fiscalYear();

        // نمودار درآمد/هزینه ۱۲ ماه (از دفتر)
        $chart = [];
        if ($fy) {
            $rows = Database::all("SELECT ld.jalali_month, ld.kind, ROUND(SUM(ld.amount),2) AS amount FROM (
                    SELECT l.debit_amount - l.credit_amount AS amount, MONTH(e.entry_date) AS m, a.account_type AS kind,
                           CONCAT(YEAR(e.entry_date), '-', LPAD(MONTH(e.entry_date),2,'0')) AS jalali_month
                      FROM journal_entry_lines l JOIN journal_entries e ON e.id=l.journal_entry_id
                      JOIN chart_of_accounts a ON a.id=l.account_id
                     WHERE e.business_id=? AND e.status='posted' AND e.deleted_at IS NULL AND e.entry_date BETWEEN ? AND ?
                       AND a.account_type IN ('revenue','expense','cogs')) ld
                 GROUP BY ld.jalali_month, ld.kind ORDER BY ld.jalali_month", [$biz, $fy['start_date'], $fy['end_date']]);
            foreach ($rows as $r) $chart[$r['jalali_month']][$r['kind']] = (float)$r['amount'];
        }
        // نقد و بانک
        $cash = Database::all('SELECT id, title, account_kind, current_balance FROM cash_accounts WHERE business_id=? AND status="active" ORDER BY account_kind, id', [$biz]);
        // چک‌های نزدیک سررسید
        $cheques = Database::all('SELECT c.*, p.first_name, p.last_name, p.company_name FROM cheques c LEFT JOIN persons p ON p.id=c.person_id
                                   WHERE c.business_id=? AND c.status IN ("in_hand","deposited") ORDER BY c.due_date LIMIT 8', [$biz]);
        // فاکتورهای سررسید گذشته
        $overdue = Database::all('SELECT i.*, p.first_name, p.last_name, p.company_name FROM invoices i LEFT JOIN persons p ON p.id=i.person_id
                                   WHERE i.business_id=? AND i.settlement_status IN ("overdue","unpaid","partial") AND i.status="posted" AND i.remaining_amount>0
                                   ORDER BY i.due_date LIMIT 8', [$biz]);
        // آخرین فاکتورها
        $latest = Database::all('SELECT i.*, p.first_name, p.last_name, p.company_name FROM invoices i LEFT JOIN persons p ON p.id=i.person_id
                                  WHERE i.business_id=? AND i.status <> "cancelled" ORDER BY i.id DESC LIMIT 6', [$biz]);
        // هشدار موجودی
        $lowStock = Database::all('SELECT * FROM v_low_stock WHERE business_id=? LIMIT 6', [$biz]);
        // سود و زیان خلاصه
        $pl = Database::all('SELECT account_type, ROUND(SUM(balance_amount),2) AS amount FROM v_trial_balance WHERE business_id=? AND account_type IN ("revenue","expense","cogs") GROUP BY account_type', [$biz]);
        $plSum = ['revenue' => 0, 'expense' => 0, 'cogs' => 0];
        foreach ($pl as $r) $plSum[$r['account_type']] = (float)$r['amount'];
        // فروش به تفکیک کالا (این ماه/سال)
        $topProducts = Database::all('SELECT product_title, product_code, SUM(sold_amount) AS amount, SUM(sold_quantity) AS qty FROM v_sales_by_item WHERE business_id=? GROUP BY product_title, product_code ORDER BY amount DESC LIMIT 5', [$biz]);
        return view('pages/dashboard', ['title' => 'داشبورد', 'kpi' => $kpi, 'fy' => $fy, 'chart' => $chart,
            'cash' => $cash, 'cheques' => $cheques, 'overdue' => $overdue, 'latest' => $latest, 'lowStock' => $lowStock,
            'plSum' => $plSum, 'topProducts' => $topProducts]);
    }
}
