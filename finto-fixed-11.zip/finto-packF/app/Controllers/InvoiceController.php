<?php
/** فاکتورهای خرید و فروش: ثبت، قطعی‌سازی، لغو، چاپ و نمایش */
final class InvoiceController
{
    public const TYPE_TITLES = ['sale' => 'فاکتور فروش', 'buy' => 'فاکتور خرید', 'sale_return' => 'برگشت از فروش', 'buy_return' => 'برگشت از خرید', 'quote' => 'پیش‌فاکتور'];

    public function index(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('invoices.view')) abort(403, 'مجوز مشاهده فاکتورها را ندارید.');
        $biz = Auth::businessId();
        $type = (string)($_GET['type'] ?? 'sale');
        $status = (string)($_GET['status'] ?? '');
        $personId = (int)($_GET['person_id'] ?? 0);
        $q = trim((string)($_GET['q'] ?? ''));
        $from = to_gregorian((string)($_GET['from'] ?? ''));
        $to = to_gregorian((string)($_GET['to'] ?? ''));
        $w = ['i.business_id = ?', 'i.deleted_at IS NULL']; $params = [$biz];
        if ($type) { $w[] = 'i.invoice_type = ?'; $params[] = $type; }
        if ($status) { $w[] = 'i.status = ?'; $params[] = $status; }
        if ($personId) { $w[] = 'i.person_id = ?'; $params[] = $personId; }
        if ($q !== '') { $w[] = '(i.invoice_no LIKE ? OR i.description LIKE ? OR i.reference_invoice_id IN (SELECT id FROM invoices WHERE invoice_no LIKE ?))'; array_push($params, "%$q%", "%$q%", "%$q%"); }
        if ($from) { $w[] = 'i.invoice_date >= ?'; $params[] = $from; }
        if ($to) { $w[] = 'i.invoice_date <= ?'; $params[] = $to; }
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 25;
        $where = implode(' AND ', $w);
        $totals = Database::one("SELECT COUNT(*) AS cnt, IFNULL(SUM(i.total_amount),0) AS total, IFNULL(SUM(i.paid_amount),0) AS paid,
                                        IFNULL(SUM(i.remaining_amount),0) AS remaining, IFNULL(SUM(i.profit_amount),0) AS profit
                                   FROM invoices i WHERE $where", $params);
        $rows = Database::all("SELECT i.*, p.first_name, p.last_name, p.company_name, p.code AS person_code
                                 FROM invoices i LEFT JOIN persons p ON p.id = i.person_id
                                WHERE $where ORDER BY i.invoice_date DESC, i.id DESC LIMIT ".($per * ($page - 1)).", $per", $params);
        return view('pages/invoices/index', ['title' => self::TYPE_TITLES[$type] ?? 'فاکتورها', 'rows' => $rows, 'type' => $type,
            'totals' => $totals, 'page' => $page, 'per' => $per, 'status' => $status, 'personId' => $personId, 'q' => $q,
            'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '']);
    }

    public function create(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('invoices.create')) abort(403, 'مجوز ثبت فاکتور را ندارید.');
        Auth::business();
        $biz = Auth::businessId();
        $type = (string)($_GET['type'] ?? 'sale');
        if (!isset(self::TYPE_TITLES[$type])) $type = 'sale';
        $isReturn = in_array($type, ['sale_return', 'buy_return'], true);
        return view('pages/invoices/create', [
            'title' => 'ثبت '.self::TYPE_TITLES[$type], 'type' => $type, 'isReturn' => $isReturn,
            'nextNo' => Sequence::peek($biz, Auth::fiscalYearId(), $type),
            'persons' => Database::all('SELECT p.id, p.code, p.first_name, p.last_name, p.company_name,
                (SELECT c.value FROM person_contacts c WHERE c.person_id=p.id AND c.contact_type IN ("mobile","phone") ORDER BY c.is_primary DESC, c.id LIMIT 1) AS mobile
                  FROM persons p WHERE p.business_id=? AND p.deleted_at IS NULL AND p.status="active" ORDER BY p.id DESC LIMIT 300', [$biz]),
            'products' => Database::all('SELECT pr.id, pr.code, pr.title, pr.item_type, pr.main_unit_id, pr.is_taxable, pr.vat_rate_id,
                                               IFNULL((SELECT price FROM product_prices pp JOIN price_types pt ON pt.id=pp.price_type_id WHERE pp.product_id=pr.id AND pt.slug=? ORDER BY pp.id DESC LIMIT 1),0) AS sale_price,
                                               IFNULL((SELECT price FROM product_prices pp JOIN price_types pt ON pt.id=pp.price_type_id WHERE pp.product_id=pr.id AND pt.slug=? ORDER BY pp.id DESC LIMIT 1),0) AS buy_price,
                                               (SELECT IFNULL(SUM(sb.quantity),0) FROM stock_balances sb WHERE sb.product_id=pr.id) AS stock_qty
                                          FROM products pr WHERE pr.business_id=? AND pr.deleted_at IS NULL AND pr.status="active" ORDER BY pr.title LIMIT 500',
                ['sale', 'purchase', $biz]),
            'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=? AND status="active"', [$biz]),
            'cashAccounts' => Database::all('SELECT id,title,account_kind FROM cash_accounts WHERE business_id=? AND status="active"', [$biz]),
            'marketers' => Database::all('SELECT id,code,full_name,commission_percent FROM marketers WHERE business_id=? AND status="active"', [$biz]),
            'taxes' => Database::all('SELECT id,title,rate_percent FROM taxes WHERE business_id=? AND is_active=1', [$biz]),
            'projects' => Database::all('SELECT id,name FROM projects WHERE business_id=? AND status="active"', [$biz]),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1', [$biz]),
            'openInvoices' => $isReturn ? Database::all('SELECT i.id, i.invoice_no, i.total_amount, i.invoice_date, i.person_id FROM invoices i WHERE i.business_id=? AND i.status="posted" AND i.invoice_type=? ORDER BY i.id DESC LIMIT 300',
                [$biz, $type === 'sale_return' ? 'sale' : 'buy']) : [],
        ]);
    }

    public function store(array $p): string
    {
        Auth::requireApp();
        csrf_verify();
        if (!Auth::can('invoices.create')) abort(403, 'مجوز ثبت فاکتور را ندارید.');
        $biz = Auth::businessId();
        $type = (string)post('invoice_type', 'sale');
        $data = [
            'business_id' => $biz, 'invoice_type' => $type, 'invoice_date' => to_gregorian((string)post('invoice_date')) ?: today(),
            'due_date' => to_gregorian((string)post('due_date')), 'person_id' => (int)post('person_id'),
            'warehouse_id' => post('warehouse_id') ? (int)post('warehouse_id') : null,
            'marketer_id' => post('marketer_id') ? (int)post('marketer_id') : null,
            'project_id' => post('project_id') ? (int)post('project_id') : null,
            'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null,
            'settlement_type' => (string)post('settlement_type', 'credit'),
            'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
            'invoice_discount' => fa_num(post('invoice_discount', '0')),
            'description' => (string)post('description') ?: null,
            'reference_invoice_id' => post('reference_invoice_id') ? (int)post('reference_invoice_id') : null,
        ];
        if (!$data['person_id']) { Flash::keep($_POST); Flash::push('error', 'انتخاب شخص الزامی است.'); redirect('app/invoices/create?type='.$type); }
        // ردیف‌ها
        $lines = [];
        $pids = (array)($_POST['line_product_id'] ?? []);
        foreach ($pids as $i => $pid) {
            if (!$pid) continue;
            $lines[] = ['product_id' => (int)$pid, 'quantity' => fa_num($_POST['line_quantity'][$i] ?? 0),
                'unit_price' => fa_num($_POST['line_unit_price'][$i] ?? 0),
                'discount_percent' => fa_num($_POST['line_discount'][$i] ?? 0),
                'unit_id' => !empty($_POST['line_unit_id'][$i]) ? (int)$_POST['line_unit_id'][$i] : null,
                'tax_id' => (!empty($_POST['line_tax_id'][$i]) && (int)fa_num($_POST['line_tax_id'][$i]) > 0) ? (int)fa_num($_POST['line_tax_id'][$i]) : null,
                'description' => $_POST['line_desc'][$i] ?? null];
        }
        $charges = [];
        foreach ((array)($_POST['charge_amount'] ?? []) as $i => $amt) {
            $amt = fa_num($amt);
            if ($amt <= 0) continue;
            $charges[] = ['charge_type' => $_POST['charge_type'][$i] ?? 'other', 'title' => $_POST['charge_title'][$i] ?? 'هزینه',
                'amount' => $amt, 'tax_id' => !empty($_POST['charge_tax_id'][$i]) ? (int)$_POST['charge_tax_id'][$i] : null];
        }
        $mode = (string)post('save_mode', 'post');
        try {
            $id = Trade::createInvoice($data, $lines, $charges, false);
            if ($mode === 'post') {
                Trade::postInvoice($id);
                Flash::push('success', 'فاکتور ثبت و قطعی شد؛ سند حسابداری و سند انبار صادر گردید.');
            } else {
                Flash::push('success', 'فاکتور به صورت پیش‌نویس ذخیره شد. برای صدور سند، دکمه «قطعی‌سازی» را بزنید.');
            }
            Flash::clearOld();
            redirect('app/invoices/'.$id);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', 'خطا در ثبت فاکتور: '.$e->getMessage());
            redirect('app/invoices/create?type='.$type);
        }
        return '';
    }

    public function show(array $p): string
    {
        Auth::requireApp();
        $inv = $this->find((int)$p['id']);
        $lines = Database::all('SELECT l.*, pr.code, pr.title AS product_title, u.title AS unit_title, t.title AS tax_title
                                  FROM invoice_lines l LEFT JOIN products pr ON pr.id=l.product_id
                                  LEFT JOIN units u ON u.id=l.unit_id LEFT JOIN taxes t ON t.id=l.tax_id
                                 WHERE l.invoice_id=? ORDER BY l.row_no', [$inv['id']]);
        $charges = Database::all('SELECT * FROM invoice_charges WHERE invoice_id=?', [$inv['id']]);
        $settlements = Database::all('SELECT s.*, r.doc_no AS receipt_no, pm.doc_no AS payment_no, ch.cheque_no
                                        FROM invoice_settlements s LEFT JOIN receipts r ON r.id=s.receipt_id
                                        LEFT JOIN payments pm ON pm.id=s.payment_id LEFT JOIN cheques ch ON ch.id=s.cheque_id
                                       WHERE s.invoice_id=? ORDER BY s.id', [$inv['id']]);
        $person = Database::one('SELECT * FROM persons WHERE id=?', [$inv['person_id']]);
        $je = $inv['journal_entry_id'] ? Database::one('SELECT * FROM journal_entries WHERE id=?', [$inv['journal_entry_id']]) : null;
        $invDoc = $inv['inventory_doc_id'] ? Database::one('SELECT * FROM inventory_documents WHERE id=?', [$inv['inventory_doc_id']]) : null;
        $history = Database::all('SELECT h.*, u.full_name FROM invoice_status_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.invoice_id=? ORDER BY h.id', [$inv['id']]);
        return view('pages/invoices/show', ['title' => 'فاکتور '.$inv['invoice_no'], 'inv' => $inv, 'lines' => $lines, 'charges' => $charges,
            'settlements' => $settlements, 'person' => $person, 'je' => $je, 'invDoc' => $invDoc, 'history' => $history,
            'typeTitle' => self::TYPE_TITLES[$inv['invoice_type']] ?? 'فاکتور']);
    }

    public function post(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('invoices.approve') && !Auth::can('invoices.edit')) abort(403, 'مجوز قطعی‌سازی فاکتور را ندارید.');
        try {
            $res = Trade::postInvoice((int)$p['id']);
            Flash::push('success', 'فاکتور قطعی شد. سند حسابداری: '.($res['journal_entry_id'] ? '#'.$res['journal_entry_id'] : '—'));
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/invoices/'.$p['id']);
    }
    public function cancel(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        try { Trade::cancelInvoice((int)$p['id'], (string)post('reason')); Flash::push('success', 'فاکتور لغو شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/invoices/'.$p['id']);
    }

    public function printView(array $p): string
    {
        Auth::requireApp();
        $inv = $this->find((int)$p['id']);
        $lines = Database::all('SELECT l.*, pr.code, pr.title AS product_title, u.title AS unit_title FROM invoice_lines l
                                 LEFT JOIN products pr ON pr.id=l.product_id LEFT JOIN units u ON u.id=l.unit_id
                                WHERE l.invoice_id=? ORDER BY l.row_no', [$inv['id']]);
        $charges = Database::all('SELECT * FROM invoice_charges WHERE invoice_id=?', [$inv['id']]);
        $person = Database::one('SELECT * FROM persons WHERE id=?', [$inv['person_id']]);
        $tpl = Database::one('SELECT * FROM print_templates WHERE business_id=? AND template_type=? AND status="active" ORDER BY is_default DESC LIMIT 1',
            [Auth::businessId(), 'invoice']);
        Database::insert('print_logs', ['business_id' => Auth::businessId(), 'template_id' => $tpl['id'] ?? null, 'entity_type' => 'invoice',
            'entity_id' => $inv['id'], 'user_id' => Auth::id(), 'copy_count' => 1, 'printed_at' => now()]);
        return view('pages/invoices/print', ['title' => 'چاپ فاکتور '.$inv['invoice_no'], 'inv' => $inv, 'lines' => $lines, 'charges' => $charges,
            'person' => $person, 'tpl' => $tpl, 'business' => Auth::business(), 'typeTitle' => self::TYPE_TITLES[$inv['invoice_type']] ?? 'فاکتور',
            'amountWords' => $this->amountInWords((float)$inv['total_amount'])]);
    }

    private function find(int $id): array
    {
        $inv = Database::one('SELECT i.*, p.code AS person_code, p.first_name, p.last_name, p.company_name, p.address, p.national_id,
                                    (SELECT c.value FROM person_contacts c WHERE c.person_id=p.id AND c.contact_type IN ("mobile","phone") ORDER BY c.is_primary DESC, c.id LIMIT 1) AS mobile
                                FROM invoices i LEFT JOIN persons p ON p.id=i.person_id WHERE i.id=? AND i.business_id=?', [$id, Auth::businessId()]);
        if (!$inv) abort(404, 'فاکتور یافت نشد.');
        return $inv;
    }

    /** تبدیل مبلغ به حروف (برای چاپ فاکتور) */
    public static function amountInWords(float $amount): string
    {
        $amount = (int)round($amount);
        if ($amount === 0) return 'صفر ریال';
        $yekan = ['','یک','دو','سه','چهار','پنج','شش','هفت','هشت','نه'];
        $dahgan = ['','','بیست','سی','چهل','پنجاه','شصت','هفتاد','هشتاد','نود'];
        $dah = ['ده','یازده','دوازده','سیزده','چهارده','پانزده','شانزده','هفده','هجده','نوزده'];
        $sadgan = ['','صد','دویست','سیصد','چهارصد','پانصد','ششصد','هفتصد','هشتصد','نهصد'];
        $scale = ['', ' هزار', ' میلیون', ' میلیارد', ' بیلیون'];
        $three = function (int $n) use ($yekan, $dahgan, $dah, $sadgan): string {
            $out = [];
            $s = intdiv($n, 100); $r = $n % 100;
            if ($s) $out[] = $sadgan[$s];
            if ($r >= 10 && $r < 20) $out[] = $dah[$r - 10];
            else { $d = intdiv($r, 10); $y = $r % 10; if ($d > 1) $out[] = $dahgan[$d]; if ($y) $out[] = ($d === 1 ? 'و ' : '').$yekan[$y]; }
            return implode(' و ', array_filter($out));
        };
        $parts = []; $i = 0; $n = $amount;
        while ($n > 0) {
            $chunk = $n % 1000;
            if ($chunk) $parts[] = $three($chunk).$scale[$i];
            $n = intdiv($n, 1000); $i++;
        }
        return implode(' و ', array_reverse($parts)).' ریال';
    }
}
