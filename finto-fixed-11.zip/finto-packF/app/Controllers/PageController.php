<?php
final class PageController
{
    public function landing(array $p): string
    {
        if (Auth::id()) {
            if (isset($_SESSION['pending_user_id'])) redirect('onboarding/profile');
            redirect(Auth::businessId() ? 'app' : 'onboarding/business');
        }
        $plans = Database::all('SELECT * FROM plans WHERE is_active=1 ORDER BY sort_order, id');
        foreach ($plans as $i => $pl) $plans[$i]['features'] = Database::all('SELECT * FROM plan_features WHERE plan_id=? ORDER BY id', [$pl['id']]);
        $stats = [
            'tables' => count(Schema::tables()), 'views' => count(Schema::views()),
            'permissions' => (int)Database::val('SELECT COUNT(*) FROM permissions', [], 0),
            'plans' => count($plans),
        ];
        return view('pages/landing', ['plans' => $plans, 'stats' => $stats, 'title' => 'نرم‌افزار حسابداری و انبارداری فینتو']);
    }
    public function terms(array $p): string { return view('pages/terms', ['title' => 'قوانین و شرایط']); }
}
