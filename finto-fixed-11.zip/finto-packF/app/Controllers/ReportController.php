<?php
/** مرکز گزارش‌ها — اجرای گزارش‌های مالی/انبار/خزانه روی نماهای دیتابیس با فیلتر و خروجی */
final class ReportController
{
    private const FILTER_LABELS = ['fiscal_year_id' => 'سال مالی', 'account_id' => 'حساب', 'person_id' => 'شخص', 'product_id' => 'کالا',
        'warehouse_id' => 'انبار', 'cash_account_id' => 'حساب نقد/بانک', 'invoice_type' => 'نوع فاکتور', 'action' => 'نوع رخداد', 'date' => 'تاریخ'];

    public function index(array $p): string
    {
        Auth::requireApp();
        $groups = [];
        foreach (Meta::reports() as $key => $r) $groups[$r['group']][$key] = $r;
        return view('pages/reports/index', ['title' => 'مرکز گزارش‌ها', 'groups' => $groups]);
    }

    public function show(array $p): string
    {
        Auth::requireApp();
        $rep = $this->report((string)$p['key']);
        [$cols, $rows, $totals, $filters, $page, $per, $total, $runError] = $this->run($rep);
        return view('pages/reports/show', ['title' => $rep['title'], 'rep' => $rep, 'cols' => $cols, 'rows' => $rows, 'totals' => $totals,
            'filters' => $filters, 'page' => $page, 'per' => $per, 'total' => $total, 'filterLabels' => self::FILTER_LABELS, 'runError' => $runError ?? null]);
    }

    public function export(array $p): string
    {
        Auth::requireApp();
        $rep = $this->report((string)$p['key']);
        [$cols, $rows] = $this->run($rep, true);
        $headers = array_map(fn($c) => Schema::label($rep['view'], $c), $cols);
        $out = [];
        foreach ($rows as $r) $out[] = array_map(fn($c) => $r[$c], $cols);
        csv_download($rep['title'].'-'.date('Ymd'), $headers, $out);
        return '';
    }

    public function printView(array $p): string
    {
        Auth::requireApp();
        $rep = $this->report((string)$p['key']);
        [$cols, $rows, $totals, $filters, , , , $runError] = $this->run($rep, true);
        if ($runError) { echo "\xEF\xBB\xBF" . $runError; exit; }
        return view('pages/reports/print', ['title' => $rep['title'], 'rep' => $rep, 'cols' => $cols, 'rows' => $rows, 'totals' => $totals,
            'filters' => $filters, 'business' => Auth::business(), 'filterLabels' => self::FILTER_LABELS, 'runError' => $runError ?? null]);
    }

    private function report(string $key): array
    {
        $all = Meta::reports();
        if (!isset($all[$key])) abort(404, 'گزارش مورد نظر یافت نشد.');
        if (!in_array($all[$key]['view'], Schema::views(), true)) abort(500, 'نمای گزارش در دیتابیس موجود نیست.');
        if (!Auth::can('reports.view') && !Auth::isAdmin()) abort(403, 'مجوز مشاهده گزارش‌ها را ندارید.');
        return array_merge(['key' => $key, 'view' => $all[$key]['view']], $all[$key]);
    }

    /** اجرای گزارش با فیلترها؛ بازگشت [ستون‌ها، ردیف‌ها، جمع‌ها، فیلترهای اعمال‌شده، صفحه، تعداد در صفحه، کل ردیف] */
    private function run(array $rep, bool $all = false): array
    {
        $view = $rep['view'];
        $cols = array_keys(Schema::columns($view));
        $where = []; $params = [];
        if (in_array('business_id', $cols, true)) { $where[] = 'business_id = :biz'; $params['biz'] = Auth::businessId(); }
        foreach ($rep['filters'] as $f) {
            $v = $_GET[$f] ?? null;
            if ($v === null || $v === '') continue;
            if ($f === 'date') {
                $from = to_gregorian((string)($_GET['from'] ?? '')); $to = to_gregorian((string)($_GET['to'] ?? ''));
                if ($from || $to) {
                    $dateCol = in_array('entry_date', $cols, true) ? 'entry_date' : (in_array('movement_date', $cols, true) ? 'movement_date'
                        : (in_array('doc_date', $cols, true) ? 'doc_date' : (in_array('invoice_date', $cols, true) ? 'invoice_date' : 'created_at')));
                    if ($from) { $where[] = "`$dateCol` >= :from"; $params['from'] = $from; }
                    if ($to) { $where[] = "`$dateCol` <= :to"; $params['to'] = $to.' 23:59:59'; }
                }
                continue;
            }
            if (in_array($f, $cols, true)) { $where[] = "`$f` = :".$f; $params[$f] = $v; }
        }
        $w = $where ? ' WHERE '.implode(' AND ', $where) : '';
        try {
            $total = (int)Database::val("SELECT COUNT(*) FROM `$view` $w", $params, 0);
            $page = max(1, (int)($_GET['page'] ?? 1));
            $per = $all ? max(1, $total) : max(10, min(500, (int)($_GET['per_page'] ?? 50)));
            $limit = $all ? '' : ' LIMIT '.($per * ($page - 1)).', '.$per;
            $rows = Database::all("SELECT * FROM `$view` $w".$limit, $params);
        } catch (Throwable $e) {
            return [[], [], [], [], 1, 50, 0, 'نمای «'.$view.'» در این دیتابیس در دسترس نیست. نصب جداول را با اجرای مجدد install.php بررسی کنید.'];
        }
        // جمع ستون‌های عددی
        $totals = [];
        foreach ($cols as $c) {
            $m = Schema::column($view, $c);
            if ($m && in_array($m['type'], ['decimal','int','bigint','double','float'], true) && !str_ends_with($c, '_id') && !in_array($c, ['level_no','row_no'])) {
                $sum = 0; $hasAny = false;
                foreach ($rows as $r) { if ($r[$c] !== null) { $sum += (float)$r[$c]; $hasAny = true; } }
                if ($hasAny) $totals[$c] = round($sum, 4);
            }
        }
        $filters = [];
        foreach ($rep['filters'] as $f) if (($v = $_GET[$f] ?? null) !== null && $v !== '') $filters[$f] = $v;
        return [$cols, $rows, $totals, $filters, $page, $per, $total, null];
    }
}
