<?php
/**
 * کنترلر عمومی CRUD متادیتا-محور: فهرست، فرم، نمایش، ویرایش، حذف نرم، جدول‌های فرزند
 * همه ماژول‌های Meta::MODULES از همین کنترلر استفاده می‌کنند.
 */
final class ResourceController
{
    private function module(array $p, string $action = 'view'): array
    {
        $key = (string)$p['module'];
        $m = Meta::module($key);
        if (!$m) abort(404, 'ماژول «'.$key.'» تعریف نشده است.');
        Auth::requireApp();
        $perm = $m['perm'] ? $m['perm'].'.'.$action : '';
        if ($perm && !Auth::can($perm)) abort(403, 'برای این عملیات مجوز «'.Meta::enumLabel($action).'» در ماژول '.$m['title'].' را ندارید.');
        if ($m['readonly'] && in_array($action, ['create','edit','delete'], true)) abort(403, 'این صفحه فقط خواندنی است.');
        return $m;
    }

    /* ───────────── فهرست ───────────── */
    public function index(array $p): string
    {
        $m = $this->module($p, 'view');
        $table = $m['table'];
        $cols = Schema::columns($table);
        $hasBiz = isset($cols['business_id']);
        $where = []; $params = [];
        if ($hasBiz) { $where[] = 't.business_id = :biz'; $params['biz'] = Auth::businessId(); }
        if (isset($cols['deleted_at'])) $where[] = 't.deleted_at IS NULL';
        // جست‌وجو
        $q = trim((string)($_GET['q'] ?? ''));
        if ($q !== '' && $m['search']) {
            $likes = [];
            foreach ($m['search'] as $i => $c) { $likes[] = "CAST(t.`$c` AS CHAR) LIKE :q"; }
            $likes[] = 'CAST(t.`'.Schema::pk($table)[0].'` AS CHAR) LIKE :q';
            $where[] = '('.implode(' OR ', $likes).')';
            $params['q'] = '%'.$q.'%';
        }
        // فیلترها
        $activeFilters = [];
        foreach ($m['filters'] as $c) {
            $v = $_GET[$c] ?? null;
            if ($v === null || $v === '') continue;
            $where[] = "t.`$c` = :f_$c"; $params['f_'.$c] = $v; $activeFilters[$c] = $v;
        }
        // بازه تاریخ
        $from = to_gregorian((string)($_GET['from'] ?? '')); $to = to_gregorian((string)($_GET['to'] ?? ''));
        foreach (['date','datetime'] as $t2) { }
        $dateCol = null;
        foreach (['doc_date','invoice_date','entry_date','movement_date','created_at','due_date','cheque_date'] as $c) if (isset($cols[$c])) { $dateCol = $c; break; }
        if ($dateCol && ($from || $to)) {
            if ($from) { $where[] = "t.`$dateCol` >= :from"; $params['from'] = $from; }
            if ($to) { $where[] = "t.`$dateCol` <= :to"; $params['to'] = $to.' 23:59:59'; }
        }
        $w = $where ? ' WHERE '.implode(' AND ', $where) : '';
        $total = (int)Database::val("SELECT COUNT(*) FROM `$table` t$w", $params, 0);
        $perPage = (int)($_GET['per_page'] ?? 25);
        $perPage = max(5, min(200, $perPage));
        $page = max(1, (int)($_GET['page'] ?? 1));
        $order = $m['order'];
        if (!preg_match('/^[a-zA-Z_][\w]*( (ASC|DESC))?(, ?[a-zA-Z_][\w]*( (ASC|DESC))?)*$/', $order)) $order = Schema::pk($table)[0].' DESC';
        $orderSql = implode(', ', array_map(fn($o) => 't.'.trim($o), explode(',', $order)));
        $rows = Database::all("SELECT t.* FROM `$table` t$w ORDER BY $orderSql LIMIT ".($perPage * ($page - 1)).", $perPage", $params);
        return view('pages/resource/index', ['m' => $m, 'rows' => $rows, 'title' => $m['title'], 'q' => $q,
            'activeFilters' => $activeFilters, 'page' => $page, 'perPage' => $perPage, 'total' => $total,
            'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '', 'dateCol' => $dateCol]);
    }

    /* ───────────── نمایش ───────────── */
    public function show(array $p): string
    {
        $m = $this->module($p, 'view');
        $row = $this->find($m, (string)$p['id']);
        if (!$row) abort(404, 'رکورد مورد نظر یافت نشد.');
        $children = [];
        foreach ($m['children'] as $ch) {
            $children[] = ['def' => $ch, 'rows' => Database::all('SELECT * FROM `'.$ch['table'].'` WHERE `'.$ch['fk'].'`=? ORDER BY '.Schema::pk($ch['table'])[0].' DESC', [$p['id']])];
        }
        return view('pages/resource/show', ['m' => $m, 'row' => $row, 'children' => $children, 'title' => $m['singular'].' #'.$p['id']]);
    }

    /* ───────────── فرم ایجاد/ویرایش ───────────── */
    public function create(array $p): string
    {
        $m = $this->module($p, 'create');
        if ($m['custom']) return $this->custom($m, 'create', $p);
        $groups = Fields::groups($m['table'], ['hide' => $m['hide'] ?? []]);
        return view('pages/resource/form', ['m' => $m, 'groups' => $groups, 'row' => [], 'title' => 'تعریف '.$m['singular'],
            'action' => url('app/'.$m['key']), 'isNew' => true, 'error' => null]);
    }
    public function edit(array $p): string
    {
        $m = $this->module($p, 'edit');
        if ($m['custom']) return $this->custom($m, 'edit', $p);
        $row = $this->find($m, (string)$p['id']);
        if (!$row) abort(404, 'رکورد یافت نشد.');
        $groups = Fields::groups($m['table'], ['hide' => $m['hide'] ?? []]);
        return view('pages/resource/form', ['m' => $m, 'groups' => $groups, 'row' => $row, 'title' => 'ویرایش '.$m['singular'],
            'action' => url('app/'.$m['key'].'/'.$p['id']), 'isNew' => false, 'error' => null]);
    }

    /* ───────────── ذخیره ───────────── */
    /** تولید شناسه/کد یکتا برای ستون‌های اجباری کدمانند */
    private static function autoNumber(string $table, string $col): string
    {
        $prefix = strtoupper(substr(preg_replace('/[^a-z]/i', '', $table), 0, 2));
        for ($i = 0; $i < 20; $i++) {
            $code = $prefix.'-'.date('ym').str_pad((string)random_int(1, 9999), 4, '0', STR_PAD_LEFT);
            $dup = Database::val("SELECT COUNT(*) FROM `$table` WHERE `$col`=?", [$code], 0);
            if (!$dup) return $code;
        }
        return $prefix.'-'.time();
    }

    public function store(array $p): string { return $this->save($p, null); }
    public function update(array $p): string { return $this->save($p, (string)$p['id']); }

    private function save(array $p, ?string $id): string
    {
        $m = $this->module($p, $id ? 'edit' : 'create');
        if ($m['custom']) return $this->customStore($m, $p, $id);
        csrf_verify();
        $table = $m['table'];
        $cols = Schema::columns($table);
        $data = [];
        $auto = ['id','created_at','created_by','updated_at','updated_by','deleted_at','row_version'];
        // ستون‌های مالکیت که فرم ارسال نمی‌کند و باید خودکار پر شوند
        if (isset($cols['business_id'])) $data['business_id'] = Auth::businessId();
        if (isset($cols['fiscal_year_id']) && !array_key_exists('fiscal_year_id', $_POST) && Auth::fiscalYearId()) $data['fiscal_year_id'] = Auth::fiscalYearId();
        foreach ($cols as $c => $meta) {
            if (in_array($c, $auto, true)) continue;
            if ($c === 'business_id') { $data[$c] = Auth::businessId(); continue; }
            if ($c === 'fiscal_year_id' && isset($data['fiscal_year_id'])) continue;
            if (!array_key_exists($c, $_POST)) {
                if ($id) continue; // در ویرایش، ستون‌های ارسال‌نشده دست‌نخورده می‌مانند
                if (in_array($c, ['currency_id','base_currency_id'], true)) { $data[$c] = base_currency_id(); continue; }
                if ($meta['type'] === 'json') { if (!$meta['null']) $data[$c] = '{}'; continue; }
                if (in_array($meta['type'], ['tinyint','smallint','int','bigint','decimal','float','double'], true) && !$meta['null'] && $meta['default'] === null) { $data[$c] = 0; continue; }
                if (in_array($meta['type'], ['date','datetime'], true) && !$meta['null'] && $meta['default'] === null) { $data[$c] = today(); continue; }
                // ستون‌های کد/شماره اجباری که فرم ورودی ندارند (مثل ticket_no) → تولید خودکار یکتا
                if (!$meta['null'] && $meta['default'] === null && preg_match('/(^|_)(code|no|number|slug|serial)$/', $c)) {
                    $data[$c] = self::autoNumber($table, $c);
                }
                continue;
            }
            if ($meta['enum']) { $v = $_POST[$c]; $data[$c] = in_array($v, $meta['enum'], true) ? $v : ($meta['null'] ? null : ($meta['enum'][0] ?? null)); continue; }
            $data[$c] = Fields::coerce($table, $c, $_POST[$c]);
        }
        // اعتبارسنجی
        $errors = [];
        foreach ($cols as $c => $meta) {
            if (in_array($c, ['id','created_at','created_by','business_id','deleted_at'], true)) continue;
            if (array_key_exists($c, $data) && $data[$c] === null && !$meta['null'] && $meta['default'] === null) $errors[] = Schema::label($table, $c).' الزامی است.';
        }
        // یکتایی‌ها
        foreach (Schema::uniques($table) as $u) {
            $conds = []; $pr = []; $valid = true;
            foreach ($u as $c) { if (!isset($data[$c]) || $data[$c] === null) { $valid = false; break; } $conds[] = "`$c`=?"; $pr[] = $data[$c]; }
            if (!$valid) continue;
            if ($id) { $conds[] = Schema::pk($table)[0].'<>?'; $pr[] = $id; }
            $dup = Database::val('SELECT COUNT(*) FROM `'.$table.'` WHERE '.implode(' AND ', $conds), $pr);
            if ($dup) $errors[] = 'رکوردی با همین '.(implode(' و ', array_map(fn($c) => Schema::label($table, $c), $u))).' قبلاً ثبت شده است.';
        }
        if ($errors) {
            Flash::keep($_POST); set_errors($errors);
            Flash::push('error', implode(' ', array_slice($errors, 0, 3)));
            redirect($id ? 'app/'.$m['key'].'/'.$id.'/edit' : 'app/'.$m['key'].'/create');
        }
        try {
            if ($id) {
                $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                if (isset($cols['row_version'])) $data['row_version'] = (int)Database::val('SELECT row_version FROM `'.$table.'` WHERE '.Schema::pk($table)[0].'=?', [$id], 1) + 1;
                Database::update($table, $data, Schema::pk($table)[0].'=:pk', ['pk' => $id]);
                Audit::log('update', $table, (int)$id, 'ویرایش '.$m['singular'].' #'.$id, ['fields' => array_keys($data)]);
                Flash::push('success', $m['singular'].' با موفقیت ویرایش شد.');
                Flash::clearOld();
                redirect('app/'.$m['key'].'/'.$id);
            }
            $data['created_at'] = now(); $data['created_by'] = Auth::id();
            $newId = Database::insert($table, $data);
            Audit::log('create', $table, $newId, 'ایجاد '.$m['singular'], ['fields' => array_keys($data)]);
            Flash::push('success', $m['singular'].' با موفقیت ثبت شد.');
            Flash::clearOld();
            redirect('app/'.$m['key'].'/'.$newId);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', 'خطا در ذخیره‌سازی: '.$e->getMessage());
            redirect($id ? 'app/'.$m['key'].'/'.$id.'/edit' : 'app/'.$m['key'].'/create');
        }
    }

    /* ───────────── حذف (نرم در صورت وجود ستون) ───────────── */
    public function destroy(array $p): string
    {
        $m = $this->module($p, 'delete');
        csrf_verify();
        $table = $m['table'];
        $row = $this->find($m, (string)$p['id']);
        if (!$row) abort(404, 'رکورد یافت نشد.');
        try {
            if (isset(Schema::columns($table)['deleted_at'])) {
                Database::run('UPDATE `'.$table.'` SET deleted_at=NOW(), is_active=0 WHERE '.Schema::pk($table)[0].'=?', [$p['id']]);
            } else {
                Database::run('DELETE FROM `'.$table.'` WHERE '.Schema::pk($table)[0].'=?', [$p['id']]);
            }
            Audit::log('delete', $table, (int)$p['id'], 'حذف '.$m['singular'].' #'.$p['id']);
            Flash::push('success', $m['singular'].' حذف شد.');
        } catch (Throwable $e) {
            Flash::push('error', 'حذف ممکن نشد: این رکورد در اسناد دیگر استفاده شده است. ('.$e->getMessage().')');
        }
        redirect('app/'.$m['key']);
    }

    /* ───────────── جدول‌های فرزند ───────────── */
    public function childStore(array $p): string
    {
        $m = $this->module($p, 'edit');
        csrf_verify();
        $child = null;
        foreach ($m['children'] as $ch) if ($ch['table'] === $p['child']) $child = $ch;
        if (!$child) abort(404, 'جدول فرزند یافت نشد.');
        $table = $child['table'];
        $cols = Schema::columns($table);
        $data = [];
        foreach ($cols as $c => $meta) {
            if (in_array($c, ['id','created_at','created_by','updated_at','updated_by','deleted_at','row_version'], true)) continue;
            if ($c === $child['fk']) { $data[$c] = (int)$p['id']; continue; }
            if (!array_key_exists($c, $_POST)) continue;
            $data[$c] = $meta['enum'] ? $_POST[$c] : Fields::coerce($table, $c, $_POST[$c]);
            if ($c === 'business_id') $data[$c] = Auth::businessId();
        }
        try { Database::insert($table, $data); Flash::push('success', $child['title'].' ثبت شد.'); }
        catch (Throwable $e) { Flash::push('error', 'خطا در ثبت: '.$e->getMessage()); }
        redirect('app/'.$m['key'].'/'.$p['id']);
    }
    public function childDestroy(array $p): string
    {
        $m = $this->module($p, 'edit');
        csrf_verify();
        foreach ($m['children'] as $ch) {
            if ($ch['table'] !== $p['child']) continue;
            try { Database::run('DELETE FROM `'.$ch['table'].'` WHERE '.Schema::pk($ch['table'])[0].'=? AND `'.$ch['fk'].'`=?', [$p['cid'], $p['id']]); Flash::push('success', 'ردیف حذف شد.'); }
            catch (Throwable $e) { Flash::push('error', 'حذف ممکن نشد: '.$e->getMessage()); }
        }
        redirect('app/'.$m['key'].'/'.$p['id']);
    }

    /* ───────────── کمکی‌ها ───────────── */
    private function find(array $m, string $id): ?array
    {
        $pk = Schema::pk($m['table'])[0];
        $cols = Schema::columns($m['table']);
        $w = ["`$pk` = ?"]; $pr = [$id];
        if (isset($cols['business_id'])) { $w[] = 'business_id = ?'; $pr[] = Auth::businessId(); }
        return Database::one('SELECT * FROM `'.$m['table'].'` WHERE '.implode(' AND ', $w).' LIMIT 1', $pr);
    }
    private function custom(array $m, string $mode, array $p): string
    {
        $map = ['party' => 'PeopleController', 'catalog' => 'CatalogController', 'treasury' => 'TreasuryController',
            'cheque' => 'TreasuryController', 'stock' => 'StockController', 'stock_transfer' => 'StockController',
            'journal' => 'AccountingController', 'opening' => 'AccountingController', 'payroll' => 'AccountingController',
            'fiscal' => 'AccountingController', 'incexp' => 'IncexpController', 'user' => 'UserController', 'role' => 'SettingsController'];
        $class = $map[$m['custom']] ?? null;
        if (!$class) abort(500, 'کنترلر اختصاصی '.$m['custom'].' یافت نشد.');
        $obj = new $class();
        $method = $mode === 'create' ? 'formCreate' : 'formEdit';
        if (!method_exists($obj, $method)) { $groups = Fields::groups($m['table']); return view('pages/resource/form', ['m' => $m, 'groups' => $groups, 'row' => [], 'title' => 'تعریف '.$m['singular'], 'action' => url('app/'.$m['key']), 'isNew' => true, 'error' => null]); }
        return $obj->$method($m, $p);
    }
    private function customStore(array $m, array $p, ?string $id): string
    {
        $map = ['party' => 'PeopleController', 'catalog' => 'CatalogController', 'treasury' => 'TreasuryController',
            'cheque' => 'TreasuryController', 'stock' => 'StockController', 'stock_transfer' => 'StockController',
            'journal' => 'AccountingController', 'opening' => 'AccountingController', 'payroll' => 'AccountingController',
            'fiscal' => 'AccountingController', 'incexp' => 'IncexpController', 'user' => 'UserController', 'role' => 'SettingsController'];
        $class = $map[$m['custom']] ?? null;
        if (!$class) abort(500, 'کنترلر اختصاصی یافت نشد.');
        $obj = new $class();
        return $obj->customSave($m, $p, $id);
    }
}
