<?php
/** تنظیمات: کسب‌وکار، مالی، حقوق، پیامک، سطح دسترسی و نقش‌ها */
final class SettingsController
{
    public function business(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        $biz = Auth::business();
        $error = null;
        if (is_post()) {
            csrf_verify();
            try {
                $cols = Schema::columns('businesses');
                $data = [];
                foreach ($cols as $c => $m) {
                    if (in_array($c, ['id','slug','created_at','created_by','updated_at','updated_by','deleted_at','row_version','status','logo_attachment_id','timezone'], true)) continue;
                    if (!array_key_exists($c, $_POST)) continue;
                    $data[$c] = $m['enum'] ? $_POST[$c] : Fields::coerce('businesses', $c, $_POST[$c]);
                }
                $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                Database::update('businesses', $data, 'id=:pk', ['pk' => $biz['id']]);
                Audit::log('update', 'businesses', (int)$biz['id'], 'ویرایش اطلاعات کسب‌وکار');
                Flash::push('success', 'اطلاعات کسب‌وکار ذخیره شد.');
                redirect('app/settings/business');
            } catch (Throwable $e) { $error = $e->getMessage(); }
        }
        $groups = Fields::groups('businesses', ['hide' => ['slug','status','timezone','logo_attachment_id']]);
        return view('pages/settings/business', ['title' => 'ویرایش کسب‌وکار', 'biz' => $biz, 'groups' => $groups, 'error' => $error,
            'provinces' => Database::all('SELECT id, name AS title FROM provinces ORDER BY id LIMIT 40'),
            'cities' => Database::all('SELECT id, name AS title FROM cities ORDER BY id LIMIT 200'),
            'currencies' => Database::all('SELECT id,title,symbol,is_base FROM currencies WHERE is_active=1 ORDER BY is_base DESC LIMIT 12')]);
    }

    public function financial(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) {
                    Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                }
                // نگاشت حساب‌ها
                foreach ((array)($_POST['mapping'] ?? []) as $mappingId => $accId) {
                    if (!$accId) continue;
                    Database::run('UPDATE account_mappings SET account_id=? WHERE id=? AND business_id=?', [(int)$accId, (int)$mappingId, $biz]);
                }
                Flash::push('success', 'تنظیمات مالی ذخیره شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/financial');
        }
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category IN ("financial","technical") ORDER BY category, id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        return view('pages/settings/financial', ['title' => 'تنظیمات مالی', 'groups' => $groups,
            'mappings' => Database::all('SELECT m.*, a.code, a.title AS account_title FROM account_mappings m LEFT JOIN chart_of_accounts a ON a.id=m.account_id WHERE m.business_id=? ORDER BY m.id', [$biz]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [$biz]),
            'taxes' => Database::all('SELECT * FROM taxes WHERE business_id=? ORDER BY id', [$biz]),
            'fiscalYears' => Database::all('SELECT * FROM fiscal_years WHERE business_id=? ORDER BY id DESC', [$biz])]);
    }

    public function hr(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('payroll.view') && !Auth::can('settings.view')) abort(403, 'مجوز دسترسی ندارید.');
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                if (post('new_component_title')) {
                    Database::insert('payroll_components', ['business_id' => $biz, 'title' => (string)post('new_component_title'),
                        'component_kind' => (string)post('new_component_kind', 'earning'), 'calc_type' => (string)post('new_component_calc', 'fixed'),
                        'rate_percent' => (float)post('new_component_rate', 0), 'default_amount' => (float)str_replace(',', '', (string)post('new_component_amount', '0')),
                        'account_id' => post('new_component_account') ? (int)post('new_component_account') : null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
                }
                foreach ((array)($_POST['component'] ?? []) as $id => $vals) {
                    if (!isset($vals['rate_percent']) && !isset($vals['default_amount'])) continue;
                    Database::run('UPDATE payroll_components SET rate_percent=?, default_amount=? WHERE id=? AND business_id=?',
                        [(float)($vals['rate_percent'] ?? 0), (float)str_replace(',', '', (string)($vals['default_amount'] ?? 0)), (int)$id, $biz]);
                }
                Flash::push('success', 'تنظیمات حقوق و دستمزد ذخیره شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/hr');
        }
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category="hr" ORDER BY id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        return view('pages/settings/hr', ['title' => 'تنظیمات حقوق و دستمزد', 'groups' => $groups,
            'components' => Database::all('SELECT c.*, a.title AS account_title FROM payroll_components c LEFT JOIN chart_of_accounts a ON a.id=c.account_id WHERE c.business_id=? ORDER BY c.id', [$biz]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [$biz]),
            'leaveTypes' => Database::all('SELECT * FROM leave_types WHERE business_id=? ORDER BY id', [$biz]),
            'devices' => Database::all('SELECT * FROM attendance_devices WHERE business_id=? ORDER BY id', [$biz])]);
    }

    public function sms(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                Flash::push('success', 'تنظیمات پیامک ذخیره شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/sms');
        }
        $balance = (float)Database::val('SELECT balance_after FROM message_credits WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz], 0);
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category="sms" ORDER BY id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        return view('pages/settings/sms', ['title' => 'تنظیمات پیامک', 'groups' => $groups, 'balance' => $balance,
            'templates' => Database::all('SELECT * FROM message_templates WHERE business_id=? ORDER BY id', [$biz]),
            'rules' => Database::all('SELECT * FROM notification_rules WHERE business_id=? ORDER BY id', [$biz]),
            'recent' => Database::all('SELECT * FROM messages WHERE business_id=? ORDER BY id DESC LIMIT 20', [$biz])]);
    }

    private function castValue($value, string $type)
    {
        return match ($type) {
            'number' => (float)str_replace(',', '', (string)$value),
            'bool' => (bool)(int)$value,
            'json' => (json_decode((string)$value, true) ?? (string)$value),
            default => (string)$value,
        };
    }

    /* ───────────── نقش‌ها و مجوزها ───────────── */
    public function formCreate(array $m, array $p): string
    {
        return view('pages/settings/role_form', ['title' => 'تعریف نقش', 'm' => $m, 'row' => [], 'perms' => $this->permissionsByModule(),
            'selected' => [], 'action' => url('app/roles')]);
    }
    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM roles WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$row) abort(404, 'نقش یافت نشد.');
        $sel = array_column(Database::all('SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id WHERE rp.role_id=?', [$row['id']]), 'slug');
        return view('pages/settings/role_form', ['title' => 'ویرایش نقش '.$row['name'], 'm' => $m, 'row' => $row,
            'perms' => $this->permissionsByModule(), 'selected' => $sel, 'action' => url('app/roles/'.$row['id'])]);
    }
    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $biz = Auth::businessId();
        try {
            $data = ['business_id' => $biz, 'name' => (string)post('name'), 'slug' => (string)post('slug') ?: ('role-'.random_int(100, 999)),
                'description' => (string)post('description') ?: null, 'is_system' => 0, 'is_active' => 1];
            if ($id) { $data['updated_at'] = now(); $data['updated_by'] = Auth::id(); Database::update('roles', $data, 'id=:pk', ['pk' => $id]); $roleId = (int)$id; }
            else { $data['created_at'] = now(); $data['created_by'] = Auth::id(); $roleId = Database::insert('roles', $data); }
            $this->syncPermissions($roleId, (array)($_POST['perms'] ?? []));
            Flash::push('success', 'نقش و سطح دسترسی ذخیره شد.');
            redirect('app/roles/'.$roleId);
        } catch (Throwable $e) { Flash::push('error', 'خطا: '.$e->getMessage()); redirect($id ? 'app/roles/'.$id.'/edit' : 'app/roles/create'); }
        return '';
    }
    public function savePermissions(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز تغییر سطح دسترسی را ندارید.');
        $this->syncPermissions((int)$p['id'], (array)($_POST['perms'] ?? []));
        Flash::push('success', 'سطح دسترسی نقش به‌روزرسانی شد.');
        redirect('app/roles/'.$p['id']);
        return '';
    }
    private function syncPermissions(int $roleId, array $slugs): void
    {
        $role = Database::one('SELECT * FROM roles WHERE id=? AND business_id=?', [$roleId, Auth::businessId()]);
        if (!$role) throw new RuntimeException('نقش یافت نشد.');
        Database::run('DELETE FROM role_permissions WHERE role_id=?', [$roleId]);
        foreach ($slugs as $slug) {
            $pid = Database::val('SELECT id FROM permissions WHERE slug=?', [$slug]);
            if ($pid) Database::run('INSERT IGNORE INTO role_permissions (role_id, permission_id, scope) VALUES (?,?,"own_business")', [$roleId, $pid]);
        }
        Audit::log('update', 'roles', $roleId, 'به‌روزرسانی سطح دسترسی نقش '.$role['name'], ['count' => count($slugs)]);
    }
    public function permissionsByModule(): array
    {
        $out = [];
        foreach (Database::all('SELECT * FROM permissions WHERE is_active=1 ORDER BY module, action') as $perm) $out[$perm['module']][] = $perm;
        return $out;
    }

    /* ───────────── کاربران: رمز و نقش ───────────── */
    public function resetPassword(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز ندارید.');
        $pw = (string)post('password');
        if (mb_strlen($pw) < 8) { Flash::push('error', 'رمز عبور باید حداقل ۸ کاراکتر باشد.'); redirect('app/users/'.$p['id']); }
        Database::run('UPDATE users SET password_hash=?, password_changed_at=NOW(), failed_attempts=0, locked_until=NULL WHERE id=?',
            [password_hash($pw, PASSWORD_BCRYPT, ['cost' => 10]), (int)$p['id']]);
        Audit::log('reset_password', 'users', (int)$p['id'], 'تغییر رمز کاربر توسط مدیر');
        Flash::push('success', 'رمز عبور کاربر تغییر کرد.');
        redirect('app/users/'.$p['id']);
        return '';
    }
    public function saveUserRole(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز ندارید.');
        $biz = Auth::businessId(); $uid = (int)$p['id'];
        try {
            $row = Database::one('SELECT * FROM user_business_roles WHERE user_id=? AND business_id=?', [$uid, $biz]);
            $data = ['role_id' => (int)post('role_id'), 'is_active' => post('is_active') ? 1 : 0,
                'max_discount_percent' => (float)post('max_discount_percent', 0), 'can_see_cost' => post('can_see_cost') ? 1 : 0,
                'default_warehouse_id' => post('default_warehouse_id') ? (int)post('default_warehouse_id') : null,
                'default_cash_account_id' => post('default_cash_account_id') ? (int)post('default_cash_account_id') : null];
            if ($row) Database::update('user_business_roles', $data, 'id=:pk', ['pk' => $row['id']]);
            else { $data['business_id'] = $biz; $data['user_id'] = $uid; $data['created_at'] = now(); $data['created_by'] = Auth::id(); Database::insert('user_business_roles', $data); }
            Flash::push('success', 'نقش کاربر در این کسب‌وکار ذخیره شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/users/'.$uid);
        return '';
    }
}
