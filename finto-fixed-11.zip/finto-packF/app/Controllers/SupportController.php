<?php
/** پشتیبانی: ثبت تیکت، گفت‌وگو و تغییر وضعیت */
final class SupportController
{
    public function create(array $p): string
    {
        Auth::requireApp();
        if (is_post()) {
            csrf_verify();
            $subject = (string)post('subject');
            $message = (string)post('message');
            if (mb_strlen($subject) < 3 || mb_strlen($message) < 5) {
                Flash::keep($_POST); Flash::push('error', 'موضوع و متن پیام را کامل وارد کنید.'); redirect('app/tickets/create');
            }
            try {
                $id = Database::transaction(function () use ($subject, $message) {
                    $biz = Auth::businessId();
                    $no = 'TK-'.current_jalali_year().str_pad((string)((int)Database::val('SELECT COUNT(*) FROM tickets WHERE business_id=?', [$biz], 0) + 1), 4, '0', STR_PAD_LEFT);
                    $tid = Database::insert('tickets', ['business_id' => $biz, 'ticket_no' => $no, 'subject' => $subject,
                        'department_id' => post('department_id') ? (int)post('department_id') : null,
                        'request_type' => (string)post('request_type', 'question'), 'priority' => (string)post('priority', 'normal'),
                        'status' => 'open', 'created_by' => Auth::id(), 'contact_phone' => (string)post('contact_phone') ?: null,
                        'last_reply_at' => now(), 'is_active' => 1, 'created_at' => now()]);
                    Database::insert('ticket_messages', ['ticket_id' => $tid, 'sender_type' => 'user', 'sender_user_id' => Auth::id(),
                        'body' => $message, 'is_internal_note' => 0, 'created_at' => now(), 'created_by' => Auth::id()]);
                    return $tid;
                });
                Flash::push('success', 'تیکت شما ثبت شد. کارشناسان پشتیبانی به‌زودی پاسخ می‌دهند.');
                Flash::clearOld();
                redirect('app/tickets/'.$id);
            } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/tickets/create'); }
        }
        return view('pages/support/create', ['title' => 'تیکت جدید',
            'departments' => Database::all('SELECT id,title FROM support_departments WHERE is_active=1 ORDER BY id')]);
    }

    public function show(array $p): string
    {
        Auth::requireApp();
        $t = Database::one('SELECT t.*, u.full_name AS creator FROM tickets t LEFT JOIN users u ON u.id=t.created_by WHERE t.id=? AND t.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$t) abort(404, 'تیکت یافت نشد.');
        $messages = Database::all('SELECT m.*, u.full_name FROM ticket_messages m LEFT JOIN users u ON u.id=m.sender_user_id WHERE m.ticket_id=? ORDER BY m.id', [$t['id']]);
        return view('pages/support/show', ['title' => 'تیکت '.$t['ticket_no'], 't' => $t, 'messages' => $messages]);
    }

    public function reply(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $msg = (string)post('message');
        if (mb_strlen($msg) < 2) { Flash::push('error', 'متن پیام را وارد کنید.'); redirect('app/tickets/'.$p['id']); }
        $ticket = Database::one('SELECT * FROM tickets WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$ticket) abort(404, 'تیکت یافت نشد.');
        $isOwner = (int)$ticket['created_by'] === (int)Auth::id();
        Database::insert('ticket_messages', ['ticket_id' => (int)$p['id'], 'sender_type' => $isOwner ? 'user' : 'support', 'sender_user_id' => Auth::id(),
            'body' => $msg, 'is_internal_note' => post('is_internal') ? 1 : 0, 'created_at' => now(), 'created_by' => Auth::id()]);
        Database::run('UPDATE tickets SET status="pending", last_reply_at=NOW() WHERE id=?', [(int)$p['id']]);
        Flash::push('success', 'پیام شما ثبت شد.');
        redirect('app/tickets/'.$p['id']);
        return '';
    }

    public function status(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $status = (string)post('status', 'closed');
        if (!in_array($status, ['open','answered','pending','closed'], true)) $status = 'closed';
        Database::run('UPDATE tickets SET status=?, closed_at='.($status === 'closed' ? 'NOW()' : 'closed_at').', satisfaction_rate=? WHERE id=? AND business_id=?',
            [$status, post('satisfaction_rate') ? (int)post('satisfaction_rate') : null, (int)$p['id'], Auth::businessId()]);
        Flash::push('success', 'وضعیت تیکت به‌روزرسانی شد.');
        redirect('app/tickets/'.$p['id']);
        return '';
    }
}
