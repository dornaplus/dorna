<?php
/** دریافت، پرداخت، انتقال وجه و چرخه عمر چک */
final class TreasuryController
{
    /* ───────────── دریافت ───────────── */
    public function receipts(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $q = trim((string)($_GET['q'] ?? '')); $status = (string)($_GET['status'] ?? ''); $personId = (int)($_GET['person_id'] ?? 0);
        $from = to_gregorian((string)($_GET['from'] ?? '')); $to = to_gregorian((string)($_GET['to'] ?? ''));
        $w = ['r.business_id=?', 'r.deleted_at IS NULL']; $pr = [$biz];
        if ($q !== '') { $w[] = '(r.doc_no LIKE ? OR r.description LIKE ? OR r.bank_reference LIKE ?)'; array_push($pr, "%$q%", "%$q%", "%$q%"); }
        if ($status) { $w[] = 'r.status=?'; $pr[] = $status; }
        if ($personId) { $w[] = 'r.person_id=?'; $pr[] = $personId; }
        if ($from) { $w[] = 'r.doc_date>=?'; $pr[] = $from; }
        if ($to) { $w[] = 'r.doc_date<=?'; $pr[] = $to; }
        $where = implode(' AND ', $w);
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 25;
        $totals = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(r.amount),0) total FROM receipts r WHERE $where", $pr);
        $rows = Database::all("SELECT r.*, p.first_name, p.last_name, p.company_name, p.code AS person_code, c.title AS cash_title, ch.cheque_no
                                 FROM receipts r LEFT JOIN persons p ON p.id=r.person_id LEFT JOIN cash_accounts c ON c.id=r.cash_account_id
                                 LEFT JOIN cheques ch ON ch.id=r.cheque_id WHERE $where ORDER BY r.id DESC LIMIT ".($per*($page-1)).", $per", $pr);
        return view('pages/treasury/receipts', ['title' => 'دریافت‌ها', 'rows' => $rows, 'totals' => $totals, 'page' => $page, 'per' => $per,
            'q' => $q, 'status' => $status, 'personId' => $personId, 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '']);
    }

    public function createReceipt(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('receipts.create')) abort(403, 'مجوز ثبت دریافت را ندارید.');
        $biz = Auth::businessId();
        $personId = (int)($_GET['person_id'] ?? 0);
        $openInvoices = $personId ? $this->openInvoices($personId, 'sale') : [];
        return view('pages/treasury/receipt_form', ['title' => 'ثبت دریافت', 'nextNo' => Sequence::peek($biz, Auth::fiscalYearId(), 'receipt'),
            'persons' => $this->persons(), 'cashAccounts' => $this->cashAccounts(), 'methods' => Database::all('SELECT id,title_fa FROM payment_methods WHERE business_id=?', [$biz]),
            'personId' => $personId, 'openInvoices' => $openInvoices,
            'cashAccountId' => (int)(Auth::business()['id'] ? Database::val('SELECT id FROM cash_accounts WHERE business_id=? ORDER BY id LIMIT 1', [$biz]) : 0)]);
    }
    public function storeReceipt(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $biz = Auth::businessId();
        $personId = (int)post('person_id');
        if (!$personId) { Flash::keep($_POST); Flash::push('error', 'انتخاب شخص الزامی است.'); redirect('app/receipts/create'); }
        $methodId = post('payment_method_id') ? (int)post('payment_method_id') : null;
        $chequeId = null;
        try {
            $amount = fa_num(post('amount'));
            // اگر روش پرداخت «چک» است و شماره چک وارد شده، چک ثبت می‌شود
            if ((string)post('payment_kind') === 'cheque' && post('cheque_no')) {
                $chequeId = Trade::createCheque(['direction' => 'received', 'cheque_no' => (string)post('cheque_no'),
                    'bank_name' => (string)post('bank_name'), 'branch_name' => (string)post('branch_name'), 'account_no' => (string)post('account_no'),
                    'sayad_id' => (string)post('sayad_id'), 'person_id' => $personId, 'amount' => $amount,
                    'issue_date' => to_gregorian((string)post('issue_date')) ?: today(), 'due_date' => to_gregorian((string)post('due_date')),
                    'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null]);
            }
            $allocations = [];
            foreach ((array)($_POST['alloc_invoice_id'] ?? []) as $i => $invId) {
                $amt = fa_num($_POST['alloc_amount'][$i] ?? 0);
                if (!$invId || $amt <= 0) continue;
                $allocations[] = ['invoice_id' => (int)$invId, 'amount' => $amt, 'description' => 'تسویه فاکتور'];
            }
            $allocSum = array_sum(array_column($allocations, 'amount'));
            if ($allocSum > $amount + 0.01) throw new RuntimeException('جمع تخصیص به فاکتورها از مبلغ دریافت بیشتر است.');
            $id = Trade::createReceipt([
                'person_id' => $personId, 'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'payment_method_id' => $methodId, 'cheque_id' => $chequeId, 'amount' => $amount,
                'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'bank_reference' => (string)post('bank_reference') ?: null, 'description' => (string)post('description') ?: null,
                'person_name' => (string)post('person_name', ''),
            ], $allocations, true);
            Flash::push('success', 'سند دریافت ثبت شد و سند حسابداری آن صادر گردید.');
            Flash::clearOld();
            redirect('app/receipts/'.$id);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', 'خطا در ثبت دریافت: '.$e->getMessage());
            redirect('app/receipts/create');
        }
        return '';
    }
    public function showReceipt(array $p): string
    {
        Auth::requireApp();
        $r = Database::one('SELECT r.*, p.first_name, p.last_name, p.company_name, p.code AS person_code, c.title AS cash_title, ch.cheque_no
                              FROM receipts r LEFT JOIN persons p ON p.id=r.person_id LEFT JOIN cash_accounts c ON c.id=r.cash_account_id
                              LEFT JOIN cheques ch ON ch.id=r.cheque_id WHERE r.id=? AND r.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$r) abort(404, 'سند دریافت یافت نشد.');
        $lines = Database::all('SELECT l.*, i.invoice_no, i.total_amount FROM receipt_lines l LEFT JOIN invoices i ON i.id=l.invoice_id WHERE l.receipt_id=?', [$r['id']]);
        $je = $r['journal_entry_id'] ? Database::one('SELECT * FROM journal_entries WHERE id=?', [$r['journal_entry_id']]) : null;
        $jeLines = $je ? Database::all('SELECT l.*, a.code AS account_code, a.title AS account_title FROM journal_entry_lines l JOIN chart_of_accounts a ON a.id=l.account_id WHERE l.journal_entry_id=? ORDER BY l.row_no', [$je['id']]) : [];
        return view('pages/treasury/receipt_show', ['title' => 'سند دریافت '.$r['doc_no'], 'r' => $r, 'lines' => $lines, 'je' => $je, 'jeLines' => $jeLines]);
    }
    public function printReceipt(array $p): string
    {
        Auth::requireApp();
        $r = Database::one('SELECT r.*, p.first_name, p.last_name, p.company_name FROM receipts r LEFT JOIN persons p ON p.id=r.person_id WHERE r.id=? AND r.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$r) abort(404, 'سند یافت نشد.');
        $lines = Database::all('SELECT l.*, i.invoice_no FROM receipt_lines l LEFT JOIN invoices i ON i.id=l.invoice_id WHERE l.receipt_id=?', [$r['id']]);
        return view('pages/treasury/print_receipt', ['title' => 'چاپ سند دریافت', 'r' => $r, 'lines' => $lines, 'business' => Auth::business(),
            'amountWords' => InvoiceController::amountInWords((float)$r['amount'])]);
    }

    /* ───────────── پرداخت ───────────── */
    public function payments(array $p): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $q = trim((string)($_GET['q'] ?? '')); $status = (string)($_GET['status'] ?? ''); $personId = (int)($_GET['person_id'] ?? 0);
        $from = to_gregorian((string)($_GET['from'] ?? '')); $to = to_gregorian((string)($_GET['to'] ?? ''));
        $w = ['r.business_id=?', 'r.deleted_at IS NULL']; $pr = [$biz];
        if ($q !== '') { $w[] = '(r.doc_no LIKE ? OR r.description LIKE ?)'; array_push($pr, "%$q%", "%$q%"); }
        if ($status) { $w[] = 'r.status=?'; $pr[] = $status; }
        if ($personId) { $w[] = 'r.person_id=?'; $pr[] = $personId; }
        if ($from) { $w[] = 'r.doc_date>=?'; $pr[] = $from; }
        if ($to) { $w[] = 'r.doc_date<=?'; $pr[] = $to; }
        $where = implode(' AND ', $w);
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 25;
        $totals = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(r.amount),0) total FROM payments r WHERE $where", $pr);
        $rows = Database::all("SELECT r.*, p.first_name, p.last_name, p.company_name, p.code AS person_code, c.title AS cash_title, ch.cheque_no
                                 FROM payments r LEFT JOIN persons p ON p.id=r.person_id LEFT JOIN cash_accounts c ON c.id=r.cash_account_id
                                 LEFT JOIN cheques ch ON ch.id=r.cheque_id WHERE $where ORDER BY r.id DESC LIMIT ".($per*($page-1)).", $per", $pr);
        return view('pages/treasury/payments', ['title' => 'پرداخت‌ها', 'rows' => $rows, 'totals' => $totals, 'page' => $page, 'per' => $per,
            'q' => $q, 'status' => $status, 'personId' => $personId, 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '']);
    }
    public function createPayment(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('payments.create')) abort(403, 'مجوز ثبت پرداخت را ندارید.');
        $biz = Auth::businessId();
        $personId = (int)($_GET['person_id'] ?? 0);
        return view('pages/treasury/payment_form', ['title' => 'ثبت پرداخت', 'nextNo' => Sequence::peek($biz, Auth::fiscalYearId(), 'payment'),
            'persons' => $this->persons(), 'cashAccounts' => $this->cashAccounts(), 'methods' => Database::all('SELECT id,title_fa FROM payment_methods WHERE business_id=?', [$biz]),
            'personId' => $personId, 'openInvoices' => $personId ? $this->openInvoices($personId, 'buy') : [],
            'unpaidExpenses' => Database::all('SELECT id, doc_no, doc_date, title, amount FROM expense_documents WHERE business_id=? AND status="posted" AND (payment_id IS NULL) ORDER BY id DESC LIMIT 100', [$biz]),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1', [$biz])]);
    }
    public function storePayment(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $personId = (int)post('person_id');
        if (!$personId) { Flash::keep($_POST); Flash::push('error', 'انتخاب شخص الزامی است.'); redirect('app/payments/create'); }
        try {
            $amount = fa_num(post('amount'));
            $chequeId = null;
            if ((string)post('payment_kind') === 'cheque' && post('cheque_no')) {
                $chequeId = Trade::createCheque(['direction' => 'issued', 'cheque_no' => (string)post('cheque_no'),
                    'bank_name' => (string)post('bank_name'), 'branch_name' => (string)post('branch_name'), 'account_no' => (string)post('account_no'),
                    'sayad_id' => (string)post('sayad_id'), 'person_id' => $personId, 'amount' => $amount,
                    'issue_date' => to_gregorian((string)post('issue_date')) ?: today(), 'due_date' => to_gregorian((string)post('due_date')),
                    'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                    'spent_to_person_id' => $personId]);
            }
            $allocations = [];
            foreach ((array)($_POST['alloc_invoice_id'] ?? []) as $i => $invId) {
                $amt = fa_num($_POST['alloc_amount'][$i] ?? 0);
                if (!$invId || $amt <= 0) continue;
                $allocations[] = ['invoice_id' => (int)$invId, 'amount' => $amt, 'description' => 'تسویه فاکتور خرید'];
            }
            foreach ((array)($_POST['alloc_expense_id'] ?? []) as $i => $expId) {
                $amt = fa_num($_POST['alloc_expense_amount'][$i] ?? 0);
                if (!$expId || $amt <= 0) continue;
                $allocations[] = ['expense_document_id' => (int)$expId, 'amount' => $amt, 'description' => 'پرداخت سند هزینه'];
            }
            $id = Trade::createPayment([
                'person_id' => $personId, 'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null,
                'payment_method_id' => post('payment_method_id') ? (int)post('payment_method_id') : null, 'cheque_id' => $chequeId,
                'amount' => $amount, 'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'bank_reference' => (string)post('bank_reference') ?: null, 'description' => (string)post('description') ?: null,
                'person_name' => (string)post('person_name', ''),
            ], $allocations, true);
            Flash::push('success', 'سند پرداخت ثبت شد و سند حسابداری آن صادر گردید.');
            Flash::clearOld();
            redirect('app/payments/'.$id);
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', 'خطا در ثبت پرداخت: '.$e->getMessage()); redirect('app/payments/create');
        }
        return '';
    }
    public function showPayment(array $p): string
    {
        Auth::requireApp();
        $r = Database::one('SELECT r.*, p.first_name, p.last_name, p.company_name, p.code AS person_code, c.title AS cash_title, ch.cheque_no
                              FROM payments r LEFT JOIN persons p ON p.id=r.person_id LEFT JOIN cash_accounts c ON c.id=r.cash_account_id
                              LEFT JOIN cheques ch ON ch.id=r.cheque_id WHERE r.id=? AND r.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$r) abort(404, 'سند پرداخت یافت نشد.');
        $lines = Database::all('SELECT l.*, i.invoice_no, i.total_amount, e.doc_no AS expense_no FROM payment_lines l LEFT JOIN invoices i ON i.id=l.invoice_id
                                 LEFT JOIN expense_documents e ON e.id=l.expense_document_id WHERE l.payment_id=?', [$r['id']]);
        $je = $r['journal_entry_id'] ? Database::one('SELECT * FROM journal_entries WHERE id=?', [$r['journal_entry_id']]) : null;
        $jeLines = $je ? Database::all('SELECT l.*, a.code AS account_code, a.title AS account_title FROM journal_entry_lines l JOIN chart_of_accounts a ON a.id=l.account_id WHERE l.journal_entry_id=? ORDER BY l.row_no', [$je['id']]) : [];
        return view('pages/treasury/payment_show', ['title' => 'سند پرداخت '.$r['doc_no'], 'r' => $r, 'lines' => $lines, 'je' => $je, 'jeLines' => $jeLines]);
    }
    public function printPayment(array $p): string
    {
        Auth::requireApp();
        $r = Database::one('SELECT r.*, p.first_name, p.last_name, p.company_name FROM payments r LEFT JOIN persons p ON p.id=r.person_id WHERE r.id=? AND r.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$r) abort(404, 'سند یافت نشد.');
        $lines = Database::all('SELECT l.*, i.invoice_no FROM payment_lines l LEFT JOIN invoices i ON i.id=l.invoice_id WHERE l.payment_id=?', [$r['id']]);
        return view('pages/treasury/print_payment', ['title' => 'چاپ سند پرداخت', 'r' => $r, 'lines' => $lines, 'business' => Auth::business(),
            'amountWords' => InvoiceController::amountInWords((float)$r['amount'])]);
    }

    /* ───────────── انتقال وجه ───────────── */
    public function createTransfer(array $p): string
    {
        Auth::requireApp();
        return view('pages/treasury/transfer_form', ['title' => 'ثبت انتقال وجه', 'cashAccounts' => $this->cashAccounts(),
            'nextNo' => Sequence::peek(Auth::businessId(), Auth::fiscalYearId(), 'transfer'),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1', [Auth::businessId()])]);
    }
    public function storeTransfer(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        try {
            $id = Trade::createTransfer(['from_cash_account_id' => (int)post('from_cash_account_id'), 'to_cash_account_id' => (int)post('to_cash_account_id'),
                'amount' => fa_num(post('amount')), 'fee_amount' => fa_num(post('fee_amount', '0')),
                'fee_cost_center_id' => post('fee_cost_center_id') ? (int)post('fee_cost_center_id') : null,
                'doc_date' => to_gregorian((string)post('doc_date')) ?: today(), 'bank_reference' => (string)post('bank_reference') ?: null,
                'description' => (string)post('description') ?: null]);
            Flash::push('success', 'انتقال وجه ثبت شد.');
            redirect('app/transfers/'.$id);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/transfers/create'); }
        return '';
    }

    /* ───────────── چک ───────────── */
    public function formCreate(array $m, array $p): string
    {
        return view('pages/treasury/cheque_form', ['m' => $m, 'row' => [], 'title' => 'ثبت چک', 'action' => url('app/cheques'),
            'persons' => $this->persons(), 'cashAccounts' => $this->cashAccounts(),
            'direction' => (string)($_GET['direction'] ?? 'received')]);
    }
    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM cheques WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$row) abort(404, 'چک یافت نشد.');
        return view('pages/treasury/cheque_form', ['m' => $m, 'row' => $row, 'title' => 'ویرایش چک '.$row['cheque_no'], 'action' => url('app/cheques/'.$row['id']),
            'persons' => $this->persons(), 'cashAccounts' => $this->cashAccounts(), 'direction' => $row['direction']]);
    }
    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $data = ['business_id' => Auth::businessId(), 'direction' => (string)post('direction', 'received'),
            'cheque_no' => (string)post('cheque_no'), 'bank_name' => (string)post('bank_name') ?: null,
            'branch_name' => (string)post('branch_name') ?: null, 'account_no' => (string)post('account_no') ?: null,
            'sayad_id' => (string)post('sayad_id') ?: null, 'person_id' => post('person_id') ? (int)post('person_id') : null,
            'amount' => (float)str_replace(',', '', (string)post('amount', '0')), 'issue_date' => to_gregorian((string)post('issue_date')) ?: today(),
            'due_date' => to_gregorian((string)post('due_date')), 'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
            'spent_to_person_id' => post('spent_to_person_id') ? (int)post('spent_to_person_id') : null,
            'description' => (string)post('description') ?: null, 'is_active' => 1];
        if (!$data['cheque_no']) { Flash::push('error', 'شماره چک الزامی است.'); redirect('app/cheques/create'); }
        try {
            if ($id) {
                $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                Database::update('cheques', $data, 'id=:pk', ['pk' => $id]);
                Flash::push('success', 'چک ویرایش شد.');
                redirect('app/cheques/'.$id);
            }
            $newId = Trade::createCheque($data);
            Flash::push('success', 'چک ثبت شد.');
            redirect('app/cheques/'.$newId);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect($id ? 'app/cheques/'.$id.'/edit' : 'app/cheques/create'); }
        return '';
    }
    public function showCheque(array $p): string
    {
        Auth::requireApp();
        $ch = Database::one('SELECT c.*, p.first_name, p.last_name, p.company_name, ca.title AS cash_title FROM cheques c
                               LEFT JOIN persons p ON p.id=c.person_id LEFT JOIN cash_accounts ca ON ca.id=c.cash_account_id
                              WHERE c.id=? AND c.business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$ch) abort(404, 'چک یافت نشد.');
        $histories = Database::all('SELECT h.*, u.full_name FROM cheque_histories h LEFT JOIN users u ON u.id=h.user_id WHERE h.cheque_id=? ORDER BY h.id', [$ch['id']]);
        return view('pages/treasury/cheque_show', ['title' => 'چک '.$ch['cheque_no'], 'ch' => $ch, 'histories' => $histories]);
    }
    public function chequeEvent(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        try {
            Trade::chequeEvent((int)$p['id'], (string)post('event'), to_gregorian((string)post('event_date')) ?: today(), (string)post('note'));
            Flash::push('success', 'رویداد چک ثبت و سند آن صادر شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/cheques/'.$p['id']);
    }

    /* ───────────── کمکی ───────────── */
    private function persons(): array
    {
        return Database::all('SELECT id, code, first_name, last_name, company_name, person_kind,
                (SELECT c.value FROM person_contacts c WHERE c.person_id=persons.id AND c.contact_type IN ("mobile","phone") ORDER BY c.is_primary DESC, c.id LIMIT 1) AS mobile FROM persons
                               WHERE business_id=? AND deleted_at IS NULL AND status="active" ORDER BY id DESC LIMIT 400', [Auth::businessId()]);
    }
    private function cashAccounts(): array
    {
        return Database::all('SELECT id, code, title, account_kind, current_balance FROM cash_accounts WHERE business_id=? AND status="active" ORDER BY id', [Auth::businessId()]);
    }
    private function openInvoices(int $personId, string $kind): array
    {
        $types = $kind === 'sale' ? "('sale','sale_return')" : "('buy','buy_return')";
        return Database::all("SELECT i.id, i.invoice_no, i.invoice_date, i.due_date, i.total_amount, i.paid_amount, i.remaining_amount, i.settlement_status
                                FROM invoices i WHERE i.business_id=? AND i.person_id=? AND i.status='posted' AND i.invoice_type IN $types
                                 AND i.remaining_amount > 0 ORDER BY i.due_date, i.id", [Auth::businessId(), $personId]);
    }
}
