<?php
/**
 * ساخت خودکار فرم و نمایش مقادیر از متادیتای دیتابیس
 * برچسب هر فیلد از COMMENT فارسی ستون گرفته می‌شود.
 */
final class Fields
{
    /** ستون‌های فنی که در فرم نمایش داده نمی‌شوند */
    public const SYSTEM_COLS = ['id','business_id','created_at','created_by','updated_at','updated_by','deleted_at','row_version',
        'password_hash','secret_hash','code_hash','journal_entry_id','inventory_doc_id','fiscal_period_id','payment_id','receipt_id'];

    public static function groups(string $table, array $opts = []): array
    {
        $cols = Schema::columns($table);
        $hide = $opts['hide'] ?? [];
        $only = $opts['only'] ?? null;
        $groups = ['اطلاعات پایه' => [], 'اطلاعات مالی' => [], 'تاریخ‌ها و زمان‌بندی' => [], 'وضعیت و پرچم‌ها' => [], 'توضیحات' => [], 'سایر' => []];
        foreach ($cols as $name => $m) {
            if (in_array($name, self::SYSTEM_COLS, true) && !in_array($name, $only ?? [], true)) continue;
            if (in_array($name, $hide, true)) continue;
            if ($only !== null && !in_array($name, $only, true)) continue;
            $f = self::spec($table, $name, $m);
            $groups[self::section($name, $f)][] = $f;
        }
        return array_filter($groups, fn($g) => count($g) > 0);
    }

    private static function section(string $name, array $f): string
    {
        if (in_array($f['type'], ['date', 'datetime'], true) || str_contains($name, 'date') || str_contains($name, 'at_')) return 'تاریخ‌ها و زمان‌بندی';
        if ($f['type'] === 'bool' || str_starts_with($name, 'is_') || str_starts_with($name, 'has_') || str_starts_with($name, 'show_') || str_starts_with($name, 'allow_')
            || in_array($name, ['status','nature','account_type','direction','kind','priority'], true)) return 'وضعیت و پرچم‌ها';
        if (in_array($f['type'], ['money','number'], true) || str_contains($name, 'amount') || str_contains($name, 'price') || str_contains($name, 'cost')
            || str_contains($name, 'balance') || str_contains($name, 'percent') || str_contains($name, 'rate') || str_ends_with($name, '_id') && self::isMoneyFk($name)) return 'اطلاعات مالی';
        if (in_array($name, ['description','notes','note','address','body','body_template','message','subject','layout_json','condition_json','template_json','attributes_json','scopes_json'], true)) return 'توضیحات';
        if (in_array($name, ['code','title','title_fa','name','full_name','first_name','last_name','company_name'], true)) return 'اطلاعات پایه';
        return in_array($f['type'], ['fk', 'enum'], true) ? 'اطلاعات پایه' : 'سایر';
    }
    private static function isMoneyFk(string $n): bool
    {
        return in_array($n, ['account_id','tax_id','expense_account_id','revenue_account_id','default_account_id','retained_earnings_account_id','gl_account_id','linked_account_id','cash_account_id'], true);
    }

    public static function spec(string $table, string $name, array $m): array
    {
        $type = 'text';
        $enum = $m['enum'] ?? [];
        $fk = Schema::fk($table, $name);
        if (str_starts_with($name, 'password') && $m['type'] === 'varchar') $type = 'password';
        elseif ($enum) $type = 'enum';
        elseif ($fk) $type = 'fk';
        elseif (in_array($m['type'], ['tinyint'], true) && (str_starts_with($name, 'is_') || str_starts_with($name, 'has_') || str_starts_with($name, 'show_') || str_starts_with($name, 'allow_') || str_starts_with($name, 'auto_') || $name === 'reconciled' || $name === 'count_in_reports')) $type = 'bool';
        elseif (in_array($m['type'], ['int','bigint','smallint','tinyint','mediumint'], true)) $type = 'number';
        elseif (in_array($m['type'], ['decimal','float','double'], true)) $type = (str_contains($name, 'percent') || str_contains($name, 'rate') || str_contains($name, 'factor') || str_contains($name, 'fx_') || str_contains($name, 'qty') || $name === 'quantity') ? 'number' : 'money';
        elseif ($m['type'] === 'date') $type = 'date';
        elseif (in_array($m['type'], ['datetime','timestamp'], true)) $type = 'datetime';
        elseif (Schema::isJson($table, $name)) $type = 'json';
        elseif (in_array($m['type'], ['text','mediumtext','longtext'], true)) $type = 'textarea';
        elseif (str_contains($name, 'email')) $type = 'email';
        elseif (str_contains($name, 'mobile') || str_contains($name, 'phone')) $type = 'tel';
        $required = (!$m['null'] && $m['default'] === null && $m['extra'] !== 'auto_increment' && !in_array($name, ['created_at'], true));
        return ['name' => $name, 'label' => Schema::label($table, $name), 'type' => $type, 'enum' => $enum,
            'fk' => $fk, 'required' => $required, 'nullable' => (bool)$m['null'], 'default' => $m['default'],
            'comment' => $m['comment'], 'raw_type' => $m['column_type'], 'scale' => $m['scale'] ?? 0, 'table' => $table];
    }

    /** رندر یک فیلد فرم */
    public static function render(array $f, $value = null, array $opts = []): string
    {
        $name = e($f['name']); $id = 'f_'.$name;
        $val = $value !== null && $value !== '' ? $value : ($opts['row'][$f['name']] ?? null);
        $def = $f['default'];
        if (is_string($def) && ($def === 'NULL' || str_contains($def, 'CURRENT'))) $def = null;
        if ($val === null || $val === '') $val = ($def !== null && $def !== '') ? $def : '';
        $req = ($opts['required_all'] ?? false) || $f['required'] ? 'required' : '';
        $cls = 'inp'.($f['type'] === 'json' || $f['type'] === 'textarea' ? ' wide' : '');
        $html = '<div class="field' . ($f['type'] === 'textarea' || $f['type'] === 'json' ? ' field-wide' : '') . '" data-name="'.e($f['name']).'">';
        $html .= '<label for="'.$id.'">'.e($f['label']).($req ? ' <span class="req">*</span>' : '').'</label>';
        switch ($f['type']) {
            case 'bool':
                $checked = ($val === null) ? ($f['default'] === '1' || $f['default'] === 1) : (bool)(int)$val;
                $html .= '<label class="switch"><input type="checkbox" name="'.$name.'" id="'.$id.'" value="1"'.($checked ? ' checked' : '').'><span></span></label>';
                break;
            case 'enum':
                $html .= '<select name="'.$name.'" id="'.$id.'" class="'.$cls.'" '.$req.'>';
                if ($f['nullable'] || !$f['required']) $html .= '<option value="">— انتخاب کنید —</option>';
                foreach ($f['enum'] as $v) $html .= '<option value="'.e($v).'"'.((string)$val === (string)$v ? ' selected' : '').'>'.e(Meta::enumLabel($v)).'</option>';
                $html .= '</select>';
                break;
            case 'fk':
                $refTable = $f['fk']['table'];
                if ($refTable === 'businesses') { $html .= '<input type="hidden" name="'.$name.'" value="'.e($val).'">'; break; }
                $options = Schema::options($refTable, '', 400, $opts['fk_scope'][$f['name']] ?? []);
                $html .= '<select name="'.$name.'" id="'.$id.'" class="'.$cls.' select-search" '.$req.'>';
                $html .= '<option value="">— انتخاب کنید —</option>';
                foreach ($options as $o) $html .= '<option value="'.e($o['id']).'"'.((string)$val === (string)$o['id'] ? ' selected' : '').'>'.e($o['text']).'</option>';
                $html .= '</select>';
                break;
            case 'date':
                $html .= '<input type="text" name="'.$name.'" id="'.$id.'" class="'.$cls.' jalali" placeholder="۱۴۰۴/۰۱/۰۱" value="'.e($val ? jdate((string)$val) === '—' ? $val : jdate((string)$val) : '').'" '.$req.' data-value="'.e($val).'">';
                break;
            case 'datetime':
                $html .= '<input type="text" name="'.$name.'" id="'.$id.'" class="'.$cls.' jalali" placeholder="۱۴۰۴/۰۱/۰۱ ۱۲:۰۰" value="'.e($val ? jdate((string)$val, '/', true) : '').'" '.$req.'>';
                break;
            case 'money':
                $html .= '<input type="text" name="'.$name.'" id="'.$id.'" class="inp money" inputmode="decimal" value="'.e($val === '' ? '' : num((float)$val, $f['scale'] > 0 && $f['scale'] <= 2 ? 2 : 0)).'" '.$req.'>';
                break;
            case 'number':
                $html .= '<input type="number" step="any" name="'.$name.'" id="'.$id.'" class="'.$cls.'" value="'.e($val).'" '.$req.'>';
                break;
            case 'textarea':
            case 'json':
                $html .= '<textarea name="'.$name.'" id="'.$id.'" class="'.$cls.'" rows="'.($f['type'] === 'json' ? 4 : 3).'" '.$req.'>'.e($val).'</textarea>';
                break;
            case 'password':
                $html .= '<input type="password" name="'.$name.'" id="'.$id.'" class="'.$cls.'" autocomplete="new-password" '.($opts['password_required'] ?? false ? 'required' : '').'>';
                break;
            default:
                $t = in_array($f['type'], ['email','tel'], true) ? $f['type'] : 'text';
                $mm = [];
                $maxlength = (($f['raw_type'] ?? '') && preg_match('/varchar\((\d+)\)/', (string)$f['raw_type'], $mm)) ? (int)$mm[1] : 0;
                $html .= '<input type="'.$t.'" name="'.$name.'" id="'.$id.'" class="'.$cls.'" value="'.e($val).'" '.$req.($maxlength ? ' maxlength="'.$maxlength.'"' : '').'>';
        }
        if (!empty($f['comment']) && $f['type'] !== 'bool') $html .= '<div class="hint">'.e($f['comment']).'</div>';
        $html .= '</div>';
        return $html;
    }

    /** نمایش یک مقدار در فهرست/جزئیات */
    public static function display(string $table, string $col, $value, array $row = []): string
    {
        $m = Schema::column($table, $col);
        if ($value === null || $value === '') return '<span class="muted">—</span>';
        if ($m) {
            if ($m['enum']) return '<span class="pill st-'.e($value).'">'.e(Meta::enumLabel((string)$value)).'</span>';
            $fk = Schema::fk($table, $col);
            if ($fk) {
                $text = Database::val('SELECT * FROM `'.$fk['table'].'` WHERE `'.$fk['column'].'`=? LIMIT 1', [$value]);
                $refRow = Database::one('SELECT * FROM `'.$fk['table'].'` WHERE `'.$fk['column'].'`=? LIMIT 1', [$value]);
                return $refRow ? '<span class="ref">'.e(Schema::refText($fk['table'], $refRow)).'</span>' : '<span class="muted">#'.e($value).'</span>';
            }
            if (in_array($m['type'], ['tinyint','smallint','int','bigint'], true) && (str_starts_with($col,'is_')||str_starts_with($col,'has_')||str_starts_with($col,'show_')||str_starts_with($col,'allow_')||str_starts_with($col,'auto_')))
                return (int)$value ? '<span class="badge on">بله</span>' : '<span class="badge off">خیر</span>';
            if ($m['type'] === 'decimal') {
                $isRate = str_contains($col,'percent') || str_contains($col,'rate') || str_contains($col,'factor') || str_contains($col,'fx_rate');
                if ($isRate) return '<span class="num">'.num((float)$value, 2).'</span>';
                return '<span class="num money-v">'.num((float)$value, 0).'</span>';
            }
            if (in_array($m['type'], ['date'], true)) return '<span class="date-v">'.jdate((string)$value).'</span>';
            if (in_array($m['type'], ['datetime','timestamp'], true)) return '<span class="date-v">'.jdate((string)$value, '/', true).'</span>';
            if ($m['type'] === 'json' || in_array($m['type'], ['text','mediumtext','longtext'], true)) {
                $s = is_string($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE);
                return '<span class="longtext">'.e(mb_strimwidth((string)$s, 0, 80, '…')).'</span>';
            }
        }
        return e((string)$value);
    }

    /** تبدیل مقدار ورودی فرم به مقدار مناسب ستون */
    public static function coerce(string $table, string $col, $value)
    {
        $m = Schema::column($table, $col);
        if (!$m) return $value;
        $isJson = Schema::isJson($table, $col);
        if ($value === '' || $value === null) return $m['null'] || $m['default'] !== null ? null : ($m['enum'] ? ($m['enum'][0] ?? null) : null);
        switch (true) {
            case $m['enum'] && $m['type'] === 'enum': return (string)$value;
            case in_array($m['type'], ['int','bigint','smallint','tinyint','mediumint'], true): return (int)$value;
            case in_array($m['type'], ['decimal','float','double'], true):
                $v = str_replace([',', '،', ' ', 'ریال', 'تومان'], '', (string)$value);
                $v = strtr($v, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
                return (float)$v;
            case in_array($m['type'], ['date'], true): return to_gregorian((string)$value);
            case in_array($m['type'], ['datetime','timestamp'], true): return to_gregorian((string)$value);
            case $isJson:
                if (is_array($value)) return json_encode($value, JSON_UNESCAPED_UNICODE);
                $raw = trim((string)$value);
                if ($raw === '' || $raw === 'NULL') return $m['null'] ? null : '{}';
                $d = json_decode($raw, true);
                if (json_last_error() === JSON_ERROR_NONE) return json_encode($d, JSON_UNESCAPED_UNICODE);
                // ورودی نامعتبر: به‌صورت مقدار متنی در JSON نگه داشته می‌شود (قید CHECK دیتابیس حفظ می‌شود)
                return json_encode($raw, JSON_UNESCAPED_UNICODE);
            default: return (string)$value;
        }
    }
}
