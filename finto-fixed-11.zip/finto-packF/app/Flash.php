<?php
/** مدیریت پیام‌های یک‌بارمصرف و مقادیر فرم */
final class Flash
{
    public static function push(string $type, string $msg): void { $_SESSION['_flash'][] = ['type' => $type, 'msg' => $msg]; }
    public static function all(): array { $f = $_SESSION['_flash'] ?? []; unset($_SESSION['_flash']); return $f; }
    public static function keep(array $input, array $skip = ['_token', 'password', 'password_confirmation']): void
    {
        $old = [];
        foreach ($input as $k => $v) if (!in_array($k, $skip, true) && !is_array($v)) $old[$k] = $v;
        $_SESSION['_old'] = $old;
    }
    public static function old(string $k, $d = '') { return $_SESSION['_old'][$k] ?? $d; }
    public static function clearOld(): void { unset($_SESSION['_old']); }
    /**
     * چرخه عمر پیام‌ها: پیام‌های ثبت‌شده در هر درخواست، در درخواست بعدی نمایش داده و در
     * پایان همان درخواست پاک می‌شوند (این متد در پایان هر درخواست اجرا می‌شود).
     */
    public static function age(): void
    {
        if (!empty($_SESSION['_flash_pending'])) {
            // پیام‌های درخواست قبل در همین درخواست نمایش داده شدند → پاک‌سازی
            unset($_SESSION['_flash'], $_SESSION['_errors'], $_SESSION['_old'], $_SESSION['_flash_pending']);
        }
        if (!empty($_SESSION['_flash']) || !empty($_SESSION['_errors']) || !empty($_SESSION['_old'])) {
            $_SESSION['_flash_pending'] = true;
        }
    }
}
