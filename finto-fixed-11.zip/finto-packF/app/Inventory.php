<?php
/**
 * موتور انبار — منبع یکتای موجودی: اسناد انبار
 * کاردکس (stock_movements) → مانده جاری (stock_balances) → لایه‌های بهای تمام‌شده (stock_cost_layers) با FIFO
 */
final class Inventory
{
    public static function variant(int $v = 0): int { return $v > 0 ? $v : 0; }

    public static function ensureBalance(int $biz, int $wh, int $product, int $variant = 0): void
    {
        $v = self::variant($variant);
        $exists = Database::val('SELECT COUNT(*) FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [$biz, $wh, $product, $v]);
        if (!$exists) {
            Database::run('INSERT INTO stock_balances (business_id, warehouse_id, product_id, variant_id, quantity, reserved_quantity, avg_unit_cost, last_movement_at)
                           VALUES (?,?,?,?,0,0,0,NOW())', [$biz, $wh, $product, $v]);
        }
    }

    public static function currentQty(int $biz, int $wh, int $product, int $variant = 0): float
    {
        return (float)Database::val('SELECT quantity FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?',
            [$biz, $wh, $product, self::variant($variant)], 0);
    }

    /** ورود کالا: کاردکس + لایه FIFO + مانده */
    public static function applyIn(int $biz, int $wh, int $product, int $variant, float $qty, float $unitCost, string $date, ?int $docId, ?string $srcType = null, ?int $srcId = null, array $extra = []): float
    {
        $v = self::variant($variant); $qty = round($qty, 4); $unitCost = round($unitCost, 2);
        if ($qty <= 0) return 0.0;
        self::ensureBalance($biz, $wh, $product, $v);
        $bal = self::currentQty($biz, $wh, $product, $v);
        $newBal = round($bal + $qty, 4);
        $totalCost = round($qty * $unitCost, 2);
        $col = Schema::column('stock_movements', 'movement_date');
        $fyId = Posting::periodFor($biz, $date)[0]['id'] ?? null;
        $movementId = Database::insert('stock_movements', [
            'business_id' => $biz, 'fiscal_year_id' => $fyId, 'movement_date' => $date, 'warehouse_id' => $wh,
            'product_id' => $product, 'variant_id' => variant_ref($v), 'direction' => 'in', 'quantity' => $qty,
            'unit_cost' => $unitCost, 'total_cost' => $totalCost, 'balance_after' => $newBal,
            'document_id' => $docId, 'source_type' => $srcType, 'source_id' => $srcId,
        ]);
        $row = Database::one('SELECT quantity, avg_unit_cost FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [$biz, $wh, $product, $v]);
        $oldQty = (float)$row['quantity']; $oldAvg = (float)$row['avg_unit_cost'];
        $avg = $newBal > 0 ? round((($oldQty * $oldAvg) + $totalCost) / $newBal, 2) : $unitCost;
        Database::run('UPDATE stock_balances SET quantity=?, avg_unit_cost=?, last_movement_at=? WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?',
            [$newBal, $avg, $date.' '.date('H:i:s'), $biz, $wh, $product, $v]);
        // لایه FIFO
        Database::insert('stock_cost_layers', [
            'business_id' => $biz, 'warehouse_id' => $wh, 'product_id' => $product, 'variant_id' => variant_ref($v),
            'in_date' => $date, 'document_id' => $docId, 'qty_in' => $qty, 'qty_remaining' => $qty, 'unit_cost' => $unitCost,
        ]);
        return $movementId;
    }

    /** خروج کالا با مصرف لایه‌های FIFO؛ اگر موجودی کافی نباشد خطا می‌دهد (مگر مجاز باشد) */
    public static function applyOut(int $biz, int $wh, int $product, int $variant, float $qty, string $date, ?int $docId, ?string $srcType = null, ?int $srcId = null, array $opts = []): array
    {
        $v = self::variant($variant); $qty = round($qty, 4);
        if ($qty <= 0) return ['total_cost' => 0.0, 'unit_cost' => 0.0];
        self::ensureBalance($biz, $wh, $product, $v);
        $bal = self::currentQty($biz, $wh, $product, $v);
        $allowNeg = $opts['allow_negative'] ?? (bool)Settings::get('inventory.allow_negative', false);
        $fyId = Posting::periodFor($biz, $date)[0]['id'] ?? null;
        if ($bal + 0.0001 < $qty && !$allowNeg) {
            $pName = Database::val('SELECT title FROM products WHERE id=?', [$product], 'کالا');
            throw new RuntimeException("موجودی کالای «{$pName}» در انبار کافی نیست (موجودی: ".num($bal, 2)." / درخواست: ".num($qty, 2).").");
        }
        // مصرف لایه‌ها
        $remaining = $qty; $totalCost = 0.0; $consumed = [];
        $layers = Database::all('SELECT * FROM stock_cost_layers WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=? AND qty_remaining > 0 ORDER BY in_date, id', [$biz, $wh, $product, $v]);
        foreach ($layers as $layer) {
            if ($remaining <= 0) break;
            $take = min($remaining, (float)$layer['qty_remaining']);
            $cost = round($take * (float)$layer['unit_cost'], 2);
            Database::run('UPDATE stock_cost_layers SET qty_remaining = qty_remaining - ? WHERE id=?', [$take, $layer['id']]);
            $consumed[] = ['layer' => $layer, 'qty' => $take, 'cost' => $cost];
            $totalCost += $cost; $remaining = round($remaining - $take, 4);
        }
        $unitCost = $qty > 0 ? round($totalCost / $qty, 2) : 0.0;
        if ($remaining > 0.0001) { // موجودی منفی: باقیمانده با بهای آخرین میانگین
            $avg = (float)Database::val('SELECT avg_unit_cost FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [$biz, $wh, $product, $v], 0);
            $totalCost += round($remaining * $avg, 2);
            $unitCost = round($totalCost / $qty, 2);
        }
        $newBal = round($bal - $qty, 4);
        $movementId = Database::insert('stock_movements', [
            'business_id' => $biz, 'fiscal_year_id' => $fyId, 'movement_date' => $date, 'warehouse_id' => $wh,
            'product_id' => $product, 'variant_id' => variant_ref($v), 'direction' => 'out', 'quantity' => $qty,
            'unit_cost' => $unitCost, 'total_cost' => round($totalCost, 2), 'balance_after' => $newBal,
            'document_id' => $docId, 'source_type' => $srcType, 'source_id' => $srcId,
        ]);
        foreach ($consumed as $c) {
            Database::insert('stock_layer_consumptions', ['layer_id' => $c['layer']['id'], 'movement_id' => $movementId, 'qty_used' => $c['qty'], 'unit_cost' => $c['layer']['unit_cost']]);
        }
        Database::run('UPDATE stock_balances SET quantity=?, last_movement_at=? WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?',
            [$newBal, $date.' '.date('H:i:s'), $biz, $wh, $product, $v]);
        return ['total_cost' => round($totalCost, 2), 'unit_cost' => $unitCost, 'movement_id' => $movementId];
    }

    /** پیش‌بینی بهای خروج بدون ثبت */
    public static function peekCost(int $biz, int $wh, int $product, float $qty, int $variant = 0): float
    {
        $v = self::variant($variant); $remaining = $qty; $cost = 0.0;
        foreach (Database::all('SELECT qty_remaining, unit_cost FROM stock_cost_layers WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=? AND qty_remaining>0 ORDER BY in_date, id', [$biz, $wh, $product, $v]) as $l) {
            if ($remaining <= 0) break;
            $take = min($remaining, (float)$l['qty_remaining']);
            $cost += $take * (float)$l['unit_cost']; $remaining -= $take;
        }
        if ($remaining > 0) $cost += $remaining * (float)Database::val('SELECT avg_unit_cost FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [$biz, $wh, $product, $v], 0);
        return round($cost, 2);
    }

    /**
     * ثبت سند انبار با آرتیکل‌های آن (بدون سند حسابداری) — منبع یکتای تغییر موجودی
     * $lines: [['product_id'=>,'variant_id'=>,'unit_id'=>,'quantity'=>,'unit_cost'=>,'description'=>,'waste_reason_id'=>]]
     */
    public static function createDocument(array $head, array $lines, bool $postNow = true): int
    {
        $biz = (int)$head['business_id'];
        $date = $head['doc_date'] ?? today();
        $fyId = $head['fiscal_year_id'] ?? (Posting::periodFor($biz, $date)[0]['id'] ?? null);
        $docNo = $head['doc_no'] ?? Sequence::next($biz, $fyId, $head['doc_type'] === 'waste' ? 'waste' : ($head['doc_type'] === 'count_adjust' ? 'count' : 'transfer'), []);
        $docId = Database::insert('inventory_documents', [
            'business_id' => $biz, 'fiscal_year_id' => $fyId, 'doc_type' => $head['doc_type'], 'doc_no' => $docNo,
            'doc_date' => $date, 'warehouse_id' => $head['warehouse_id'], 'dest_warehouse_id' => $head['dest_warehouse_id'] ?? null,
            'person_id' => $head['person_id'] ?? null, 'source_type' => $head['source_type'] ?? null, 'source_id' => $head['source_id'] ?? null,
            'status' => $postNow ? 'posted' : 'draft', 'total_cost' => 0,
            'description' => $head['description'] ?? null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        $row = 1;
        foreach ($lines as $l) {
            $variant = self::variant((int)($l['variant_id'] ?? 0));
            $qty = round((float)$l['quantity'], 4);
            $unitId = !empty($l['unit_id']) ? (int)$l['unit_id'] : Database::val('SELECT main_unit_id FROM products WHERE id=?', [(int)$l['product_id']]);
            $baseQty = $qty;
            if (!empty($l['unit_id'])) {
                $factor = (float)Database::val('SELECT factor FROM product_units WHERE product_id=? AND unit_id=?', [(int)$l['product_id'], (int)$l['unit_id']], 1);
                $baseQty = round($qty * ($factor ?: 1), 4);
            }
            Database::insert('inventory_document_lines', [
                'document_id' => $docId, 'row_no' => $row++, 'product_id' => (int)$l['product_id'], 'variant_id' => variant_ref($variant),
                'unit_id' => $unitId, 'quantity' => $qty, 'base_quantity' => $baseQty,
                'unit_cost' => round((float)($l['unit_cost'] ?? 0), 2), 'total_cost' => 0,
                'waste_reason_id' => $l['waste_reason_id'] ?? null, 'description' => $l['description'] ?? null,
            ]);
        }
        if ($postNow) self::postDocument($docId);
        return $docId;
    }

    /** ثبت سند انبار: اعمال کاردکس/لایه/مانده + سند حسابداری مرتبط */
    public static function postDocument(int $docId, bool $withJournal = true): array
    {
        $doc = Database::one('SELECT * FROM inventory_documents WHERE id=?', [$docId]);
        if (!$doc) throw new RuntimeException('سند انبار یافت نشد.');
        if ($doc['status'] === 'posted' && $doc['journal_entry_id'] && !$withJournal) return ['total_cost' => (float)$doc['total_cost']];
        $biz = (int)$doc['business_id'];
        $date = $doc['doc_date'];
        $lines = Database::all('SELECT * FROM inventory_document_lines WHERE document_id=? ORDER BY row_no', [$docId]);
        if (!$lines) throw new RuntimeException('سند انبار آرتیکل ندارد.');
        $type = $doc['doc_type'];
        $total = 0.0;
        // پیش‌محاسبه بهای ورودی‌ها برای انتقال (انتقال = خروج از مبدأ با بهای لایه + ورود به مقصد با همان بها)
        foreach ($lines as $l) {
            $qty = (float)$l['base_quantity'];
            switch ($type) {
                case 'receive': case 'opening': case 'buy_return': case 'sale_return':
                    $unitCost = (float)$l['unit_cost'];
                    if ($unitCost <= 0) $unitCost = (float)Database::val('SELECT pp.price FROM product_prices pp JOIN price_types pt ON pt.id=pp.price_type_id
                        WHERE pp.product_id=? AND (pt.slug IN ("buy","purchase") ) ORDER BY pp.id DESC LIMIT 1', [$l['product_id']], 0);
                    if ($unitCost <= 0) $unitCost = (float)Database::val('SELECT avg_unit_cost FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [$biz, $doc['warehouse_id'], $l['product_id'], $l['variant_id']], 0);
                    Inventory::applyIn($biz, (int)$doc['warehouse_id'], (int)$l['product_id'], (int)$l['variant_id'], $qty, $unitCost, $date, $docId, $doc['source_type'], (int)$doc['source_id']);
                    Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$unitCost, round($qty * $unitCost, 2), $l['id']]);
                    $total += round($qty * $unitCost, 2);
                    break;
                case 'transfer_out':
                    $res = Inventory::applyOut($biz, (int)$doc['warehouse_id'], (int)$l['product_id'], (int)$l['variant_id'], $qty, $date, $docId, $doc['source_type'], (int)$doc['source_id']);
                    Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$res['unit_cost'], $res['total_cost'], $l['id']]);
                    $total += $res['total_cost'];
                    break;
                case 'transfer_in':
                    $unitCost = (float)$l['unit_cost'];
                    if ($unitCost <= 0) { $unitCost = 0; }
                    Inventory::applyIn($biz, (int)$doc['warehouse_id'], (int)$l['product_id'], (int)$l['variant_id'], $qty, $unitCost, $date, $docId, $doc['source_type'], (int)$doc['source_id']);
                    Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$unitCost, round($qty * $unitCost, 2), $l['id']]);
                    $total += round($qty * $unitCost, 2);
                    break;
                case 'issue': case 'waste': case 'count_adjust': case 'sale_return_out':
                    $res = Inventory::applyOut($biz, (int)$doc['warehouse_id'], (int)$l['product_id'], (int)$l['variant_id'], $qty, $date, $docId, $doc['source_type'], (int)$doc['source_id']);
                    Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$res['unit_cost'], $res['total_cost'], $l['id']]);
                    $total += $res['total_cost'];
                    break;
                default:
                    throw new RuntimeException('نوع سند انبار نامعتبر است: '.$type);
            }
        }
        Database::run('UPDATE inventory_documents SET status="posted", total_cost=? WHERE id=?', [round($total, 2), $docId]);
        // سند حسابداری مرتبط با اسناد انبار مستقل
        $jeId = $doc['journal_entry_id'];
        if ($withJournal && !$jeId && $total > 0) {
            $eventKey = match ($type) {
                'waste' => 'inventory.waste',
                'count_adjust' => (str_ends_with((string)$doc['doc_no'], '+') || str_contains((string)$doc['description'], 'اضافه‌شدگی')) ? 'inventory.count.surplus' : 'inventory.count.shortage',
                'receive', 'opening' => 'inventory.receive',
                'issue', 'transfer_out' => 'inventory.issue',
                default => null,
            };
            // برای اسناد متصل به فاکتور (source_type=invoice) سند حسابداری جداگانه صادر نمی‌شود
            $linked = in_array($doc['source_type'], ['invoice', 'sale', 'buy', 'payroll'], true);
            if ($eventKey && !$linked && !in_array($type, ['transfer_in', 'transfer_out'], true)) {
                $jeId = Posting::post($biz, $eventKey, ['cogs' => round($total, 2), 'amount' => round($total, 2)], [
                    'date' => $date, 'reference_type' => 'inventory_document', 'reference_id' => $docId, 'reference_no' => $doc['doc_no'],
                    'description' => 'سند خودکار انبار '.$doc['doc_no'],
                ]);
                Database::run('UPDATE inventory_documents SET journal_entry_id=? WHERE id=?', [$jeId, $docId]);
            }
        }
        Audit::log('post_inventory_doc', 'inventory_documents', $docId, 'ثبت سند انبار '.$doc['doc_no'], ['total_cost' => $total]);
        return ['total_cost' => round($total, 2), 'journal_entry_id' => $jeId];
    }

    /** رزرو موجودی برای پیش‌فاکتور */
    public static function reserve(int $biz, int $wh, int $product, int $variant, float $qty, int $invoiceId, ?string $until = null): void
    {
        $v = self::variant($variant);
        self::ensureBalance($biz, $wh, $product, $v);
        Database::insert('stock_reservations', [
            'business_id' => $biz, 'warehouse_id' => $wh, 'product_id' => $product, 'variant_id' => $v,
            'quantity' => round($qty, 4), 'source_type' => 'invoice', 'source_id' => $invoiceId, 'status' => 'active',
            'expires_at' => $until, 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        Database::run('UPDATE stock_balances SET reserved_quantity = reserved_quantity + ? WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?', [round($qty, 4), $biz, $wh, $product, $v]);
    }
    public static function releaseReservations(int $invoiceId): void
    {
        foreach (Database::all('SELECT * FROM stock_reservations WHERE source_type="invoice" AND source_id=? AND status="active"', [$invoiceId]) as $r) {
            Database::run('UPDATE stock_balances SET reserved_quantity = GREATEST(0, reserved_quantity - ?) WHERE business_id=? AND warehouse_id=? AND product_id=? AND variant_id=?',
                [(float)$r['quantity'], $r['business_id'], $r['warehouse_id'], $r['product_id'], $r['variant_id']]);
            Database::run('UPDATE stock_reservations SET status="released" WHERE id=?', [$r['id']]);
        }
    }
}
