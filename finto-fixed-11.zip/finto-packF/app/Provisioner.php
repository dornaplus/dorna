<?php
/**
 * راه‌اندازی کسب‌وکار جدید: ساخت دیتابیسِ کاری کامل از قالب پیش‌فرض
 * کدینگ حساب‌ها، نگاشت‌ها، قواعد سند خودکار، مالیات، واحدها، روش‌های پرداخت، تنظیمات،
 * شماره‌گذاری، قالب‌های چاپ، نقش‌های دسترسی، سال مالی و دوره‌ها، انبار و صندوق پیش‌فرض.
 */
final class Provisioner
{
    public static function template(): array
    {
        $f = __DIR__.'/Data/business_template.php';
        if (!is_file($f)) throw new RuntimeException('فایل قالب کسب‌وکار یافت نشد. فایل app/Data/business_template.php را بازسازی کنید.');
        return require $f;
    }

    public static function provision(int $userId, array $d): int
    {
        $tpl = self::template();
        return Database::transaction(function () use ($userId, $d, $tpl) {
            $slug = trim(preg_replace('/[^\p{L}\p{N}]+/u', '-', $d['name']), '-');
            $slug = mb_substr($slug, 0, 60).'-'.random_int(100, 999);
            $bizId = Database::insert('businesses', [
                'name' => $d['name'], 'slug' => $slug, 'activity_type' => $d['activity_type'] ?? 'bazargardani',
                'legal_type' => $d['legal_type'] ?? 'hoqoqi', 'economic_code' => (isset($d['economic_code']) && $d['economic_code'] !== '' ? $d['economic_code'] : null) ?: null,
                'national_id' => (isset($d['national_id']) && $d['national_id'] !== '' ? $d['national_id'] : null) ?: null, 'reg_no' => (isset($d['reg_no']) && $d['reg_no'] !== '' ? $d['reg_no'] : null) ?: null,
                'phone' => (isset($d['phone']) && $d['phone'] !== '' ? $d['phone'] : null) ?: null, 'mobile' => (isset($d['mobile']) && $d['mobile'] !== '' ? $d['mobile'] : null) ?: null, 'email' => (isset($d['email']) && $d['email'] !== '' ? $d['email'] : null) ?: null,
                'country_id' => (int)((isset($d['country_id']) && $d['country_id'] ? $d['country_id'] : null) ?: Database::val('SELECT id FROM countries ORDER BY id LIMIT 1', [], 1)), 'province_id' => (isset($d['province_id']) && $d['province_id'] !== '' ? $d['province_id'] : null) ?: null, 'city_id' => (isset($d['city_id']) && $d['city_id'] !== '' ? $d['city_id'] : null) ?: null,
                'postal_code' => (isset($d['postal_code']) && $d['postal_code'] !== '' ? $d['postal_code'] : null) ?: null, 'address' => (isset($d['address']) && $d['address'] !== '' ? $d['address'] : null) ?: null,
                'base_currency_id' => (int)((isset($d['currency_id']) && $d['currency_id'] !== '' ? $d['currency_id'] : null) ?: Database::val('SELECT id FROM currencies WHERE is_base=1 ORDER BY id LIMIT 1', [], 1)), 'timezone' => 'Asia/Tehran', 'status' => 'faal',
                'is_active' => 1, 'created_at' => now(), 'created_by' => $userId,
            ]);

            /* ── کدینگ حساب‌ها ── */
            $accIds = [];
            foreach ($tpl['chart_of_accounts'] as $a) {
                $accIds[$a['code']] = Database::insert('chart_of_accounts', [
                    'business_id' => $bizId, 'code' => $a['code'], 'parent_id' => $a['parent_code'] ? ($accIds[$a['parent_code']] ?? null) : null,
                    'level_no' => $a['level_no'], 'title' => $a['title'], 'account_type' => $a['account_type'], 'nature' => $a['nature'],
                    'is_group' => $a['is_group'], 'is_postable' => $a['is_postable'], 'person_required' => $a['person_required'],
                    'system_role' => $a['system_role'] ?: null, 'full_path' => $a['full_path'], 'status' => 'active',
                    'is_active' => 1, 'created_at' => now(), 'created_by' => $userId,
                ]);
            }
            $acc = fn($code) => $code ? ($accIds[$code] ?? null) : null;

            /* ── سال مالی جاری و ۱۲ دوره ── */
            [$defStart, $defEnd] = jalali_year_range(current_jalali_year());
            $fy = self::createFiscalYear($bizId,
                (string)($d['fy_title'] ?? ('سال مالی '.current_jalali_year())),
                (string)($d['fy_start'] ?? $defStart), (string)($d['fy_end'] ?? $defEnd), $userId);

            /* ── نگاشت حساب‌ها ── */
            foreach ($tpl['account_mappings'] as $m) {
                Database::insert('account_mappings', ['business_id' => $bizId, 'mapping_key' => $m['mapping_key'],
                    'title_fa' => $m['title_fa'], 'account_id' => $acc($m['account_code']), 'created_at' => now(), 'created_by' => $userId]);
            }
            /* ── قواعد سند خودکار ── */
            foreach ($tpl['auto_entry_rules'] as $r) {
                $rid = Database::insert('auto_entry_rules', ['business_id' => $bizId, 'event_key' => $r['event_key'], 'title_fa' => $r['title_fa'],
                    'is_enabled' => $r['is_enabled'], 'priority' => $r['priority'], 'description' => $r['description'],
                    'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
                foreach ($r['lines'] as $l) {
                    Database::insert('auto_entry_rule_lines', ['rule_id' => $rid, 'side' => $l['side'], 'account_source' => $l['account_source'],
                        'mapping_key' => $l['mapping_key'], 'account_id' => $acc($l['account_code']), 'amount_source' => $l['amount_source'], 'row_order' => $l['row_order']]);
                }
            }
            /* ── مالیات، واحد، گروه شخص، نوع قیمت، روش/شرط پرداخت، دسته درآمد-هزینه، دلیل ضایعات ── */
            foreach ($tpl['taxes'] as $x) Database::insert('taxes', ['business_id' => $bizId, 'title' => $x['title'], 'tax_kind' => $x['tax_kind'],
                'rate_percent' => $x['rate_percent'], 'is_inclusive' => $x['is_inclusive'], 'account_id' => $acc($x['account_code']),
                'moadian_tax_code' => $x['moadian_tax_code'], 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['units'] as $x) Database::insert('units', ['business_id' => $bizId, 'title' => $x['title'], 'symbol' => $x['symbol'], 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['person_types'] as $x) Database::insert('person_types', ['business_id' => $bizId, 'slug' => $x['slug'], 'title_fa' => $x['title_fa'], 'is_system' => $x['is_system'], 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['price_types'] as $x) Database::insert('price_types', ['business_id' => $bizId, 'slug' => $x['slug'], 'title_fa' => $x['title_fa'], 'is_system' => 1, 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['payment_methods'] as $x) Database::insert('payment_methods', ['business_id' => $bizId, 'slug' => $x['slug'], 'title_fa' => $x['title_fa'], 'requires_cheque' => ($x['slug'] ?? '') === 'cheque' ? 1 : 0, 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['payment_terms'] as $x) Database::insert('payment_terms', ['business_id' => $bizId, 'title' => $x['title'], 'days' => $x['days'], 'is_cash' => $x['is_cash'], 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['pl_categories'] as $x) Database::insert('profit_loss_categories', ['business_id' => $bizId, 'kind' => $x['kind'], 'title' => $x['title'],
                'default_account_id' => $acc($x['account_code']), 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['waste_reasons'] as $x) Database::insert('waste_reasons', ['business_id' => $bizId, 'title' => $x['title'],
                'expense_account_id' => $acc($x['expense_account_code']), 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            /* ── تنظیمات ── */
            foreach ($tpl['settings'] as $x) Database::insert('settings', ['business_id' => $bizId, 'category' => $x['category'], 'setting_key' => $x['setting_key'],
                'value_json' => $x['value_json'], 'value_type' => $x['value_type'], 'title_fa' => $x['title_fa'], 'group_fa' => $x['group_fa'], 'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['number_sequences'] as $x) Database::insert('number_sequences', ['business_id' => $bizId, 'fiscal_year_id' => $fy, 'doc_type' => $x['doc_type'],
                'template' => $x['template'], 'next_value' => $x['next_value'], 'step' => $x['step'], 'reset_yearly' => $x['reset_yearly'],
                'created_at' => now(), 'created_by' => $userId]);
            foreach ($tpl['print_templates'] as $x) Database::insert('print_templates', ['business_id' => $bizId, 'title' => $x['title'], 'template_type' => $x['template_type'],
                'paper_size' => $x['paper_size'], 'show_logo' => $x['show_logo'], 'logo_position' => $x['logo_position'], 'font_size' => $x['font_size'],
                'show_signature' => $x['show_signature'], 'amount_in_words' => $x['amount_in_words'], 'show_economic_code' => $x['show_economic_code'],
                'show_bank_info' => $x['show_bank_info'], 'show_barcode' => $x['show_barcode'], 'is_default' => $x['is_default'], 'status' => $x['status'],
                'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            /* ── نقش‌ها و مجوزها ── */
            $roleIds = [];
            $permIds = [];
            foreach (Database::all('SELECT id, slug FROM permissions') as $p) $permIds[$p['slug']] = (int)$p['id'];
            foreach ($tpl['roles'] as $r) {
                $rid = Database::insert('roles', ['business_id' => $bizId, 'name' => $r['name'], 'slug' => $r['slug'], 'is_system' => $r['is_system'],
                    'description' => $r['description'], 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
                $roleIds[$r['slug']] = $rid;
                foreach ($r['permissions'] as $slug) {
                    if (isset($permIds[$slug])) Database::run('INSERT IGNORE INTO role_permissions (role_id, permission_id, scope) VALUES (?,?,?)', [$rid, $permIds[$slug], 'own_business']);
                }
            }
            /* ── انبار و صندوق پیش‌فرض ── */
            $whId = Database::insert('warehouses', ['business_id' => $bizId, 'code' => 'W-01', 'title' => 'انبار اصلی', 'warehouse_type' => 'main',
                'count_in_reports' => 1, 'status' => 'active', 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            $cashAcc = Database::insert('cash_accounts', ['business_id' => $bizId, 'code' => 'CA-01', 'title' => 'صندوق', 'account_kind' => 'cash_box',
                'gl_account_id' => $acc(Database::val('SELECT code FROM chart_of_accounts WHERE business_id=? AND system_role="cash" LIMIT 1', [$bizId]) ?: '1101'),
                'currency_id' => (isset($d['currency_id']) && $d['currency_id'] !== '' ? $d['currency_id'] : null) ?: base_currency_id($bizId), 'opening_balance' => 0, 'current_balance' => 0, 'show_in_dashboard' => 1,
                'status' => 'active', 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            /* ── سال مالی: نگاشت درآمد انباشته ── */
            Database::run('UPDATE fiscal_years SET kept_earnings_account_id=? WHERE id=?', [$acc('3101') ?: null, $fy]);
            /* ── عضویت کاربر جاری با نقش مدیر ── */
            Database::insert('user_business_roles', ['business_id' => $bizId, 'user_id' => $userId, 'role_id' => $roleIds['admin'] ?? reset($roleIds),
                'default_warehouse_id' => $whId, 'default_cash_account_id' => $cashAcc, 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId]);
            Auth::switchBusiness($bizId);
            Audit::log('create_business', 'businesses', $bizId, 'راه‌اندازی کسب‌وکار '.$d['name']);
            return $bizId;
        });
    }

    public static function createFiscalYear(int $bizId, string $title, string $start, string $end, ?int $userId = null): int
    {
        return Database::transaction(function () use ($bizId, $title, $start, $end, $userId) {
            Database::run('UPDATE fiscal_years SET is_current=0 WHERE business_id=?', [$bizId]);
            $fyId = Database::insert('fiscal_years', ['business_id' => $bizId, 'title' => $title, 'start_date' => $start, 'end_date' => $end,
                'status' => 'open', 'is_current' => 1, 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId ?? Auth::id()]);
            // ۱۲ دوره: هر یک ماه شمسی
            [$jy] = gregorian_to_jalali((int)substr($start, 0, 4), (int)substr($start, 5, 2), (int)substr($start, 8, 2));
            for ($m = 1; $m <= 12; $m++) {
                [$sy, $sm, $sd] = jalali_to_gregorian($jy, $m, 1);
                $lastDay = $m <= 6 ? 31 : ($m <= 11 ? 30 : 29);
                [$ey, $em, $ed] = jalali_to_gregorian($jy, $m, $lastDay);
                Database::insert('fiscal_periods', ['business_id' => $bizId, 'fiscal_year_id' => $fyId, 'title' => jmonth_name($m).' '.$jy,
                    'start_date' => sprintf('%04d-%02d-%02d', $sy, $sm, $sd), 'end_date' => sprintf('%04d-%02d-%02d', $ey, $em, $ed),
                    'status' => 'open', 'is_active' => 1, 'created_at' => now(), 'created_by' => $userId ?? Auth::id()]);
            }
            return $fyId;
        });
    }
}
