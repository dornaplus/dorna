<?php
/** مسیریاب ساده با پشتیبانی از پارامترهای {name} */
final class Router
{
    private array $routes = [];

    public function add(string $method, string $pattern, $handler): void
    {
        $regex = '#^'.preg_replace('#\{([a-z_]+)\}#', '(?P<$1>[^/]+)', rtrim($pattern, '/')).'/?$#u';
        $this->routes[] = ['method' => strtoupper($method), 'regex' => $regex, 'handler' => $handler, 'pattern' => $pattern];
    }
    public function get(string $p, $h): void { $this->add('GET', $p, $h); }
    public function post(string $p, $h): void { $this->add('POST', $p, $h); }
    public function any(string $p, $h): void { $this->add('GET', $p, $h); $this->add('POST', $p, $h); }

    public function dispatch(string $uri): void
    {
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $base = base_path();
        if ($base !== '' && str_starts_with($path, $base)) $path = substr($path, strlen($base));
        $path = '/'.trim(urldecode($path), '/');
        if ($path === '/') $path = '/';
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        foreach ($this->routes as $r) {
            if ($r['method'] !== $method) continue;
            if (preg_match($r['regex'], $path, $m)) {
                $params = array_filter($m, fn($k) => !is_int($k), ARRAY_FILTER_USE_KEY);
                $this->invoke($r['handler'], $params);
                return;
            }
        }
        http_response_code(404);
        render('errors/page', ['code' => 404, 'title' => 'صفحه یافت نشد', 'message' => 'آدرس «'.$path.'» در نرم‌افزار تعریف نشده است.']);
    }

    private function invoke($handler, array $params): void
    {
        if (is_callable($handler)) { echo $handler($params); return; }
        [$class, $method] = explode('@', $handler);
        if (!class_exists($class)) abort(500, 'کنترلر '.$class.' یافت نشد.');
        $obj = new $class();
        if (!method_exists($obj, $method)) abort(500, 'متد '.$method.' یافت نشد.');
        echo $obj->$method($params);
    }
}
