<?php
/** سرویس‌های کمکی: کد تایید (OTP)، پیامک، شماره‌گذاری اسناد، لاگ حسابرسی، تنظیمات */
final class Otp
{
    /** نگاشت هدف کد تایید به مقادیر مجاز ستون purpose در جدول otp_codes */
    public static function purpose(string $p): string
    {
        return match ($p) {
            'register', 'verify', 'verify_contact', 'phone_change' => 'verify_contact',
            'reset', 'reset_password', 'forgot'                   => 'reset_password',
            '2fa', 'two_factor'                                   => '2fa',
            default                                               => 'login',
        };
    }

    public static function create(?int $userId, string $mobile, string $purpose = 'register'): string
    {
        $cfg = config('security');
        $purpose = self::purpose($purpose);
        // ستون created_at در جدول otp_codes وجود ندارد؛ زمان ارسال از expires_at منهای اعتبار محاسبه می‌شود
        $last = Database::one('SELECT expires_at FROM otp_codes WHERE mobile=? AND purpose=? ORDER BY id DESC LIMIT 1', [$mobile, $purpose]);
        if ($last) {
            $sentAt = strtotime((string)$last['expires_at']) - (int)$cfg['otp_ttl_seconds'];
            if ((time() - $sentAt) < (int)$cfg['otp_resend_seconds']) {
                $wait = (int)$cfg['otp_resend_seconds'] - (time() - $sentAt);
                throw new RuntimeException('لطفاً '.ceil(max(1, $wait) / 60).' دقیقه دیگر برای ارسال مجدد کد صبر کنید.');
            }
        }
        $code = (string)random_int(100000, 999999);
        Database::run('DELETE FROM otp_codes WHERE mobile=? AND purpose=? AND used_at IS NULL', [$mobile, $purpose]);
        Database::insert('otp_codes', [
            'user_id' => $userId, 'mobile' => $mobile, 'purpose' => $purpose,
            'code_hash' => self::hash($code), 'expires_at' => date('Y-m-d H:i:s', time() + $cfg['otp_ttl_seconds']),
            'attempts' => 0,
        ]);
        Sms::send($mobile, "کد تایید فینتو: {$code}\nاین کد تا ۵ دقیقه اعتبار دارد.", $userId, 'otp');
        // در حالت نمایشی، کد برای نمایش روی صفحه نگه داشته می‌شود تا آزمایش محلی ساده باشد
        if (config('app')['demo_mode'] && session_status() === PHP_SESSION_ACTIVE) $_SESSION['_demo_otp'][$mobile] = $code;
        return $code;
    }
    public static function hash(string $code): string { return hash_hmac('sha256', $code, config('security')['hash_secret']); }
    public static function verify(string $mobile, string $code, string $purpose = 'register'): array
    {
        $cfg = config('security');
        $purpose = self::purpose($purpose);
        $row = Database::one('SELECT * FROM otp_codes WHERE mobile=? AND purpose=? AND used_at IS NULL ORDER BY id DESC LIMIT 1', [$mobile, $purpose]);
        if (!$row) return [false, 'کد تاییدی برای این شماره ثبت نشده است.'];
        if (strtotime($row['expires_at']) < time()) return [false, 'کد تایید منقضی شده است. کد جدید دریافت کنید.'];
        if ((int)$row['attempts'] >= $cfg['otp_max_attempts']) return [false, 'تعداد تلاش‌های ناموفق زیاد بود. کد جدید دریافت کنید.'];
        if (!hash_equals((string)$row['code_hash'], self::hash($code))) {
            Database::run('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?', [$row['id']]);
            $left = max(0, $cfg['otp_max_attempts'] - (int)$row['attempts'] - 1);
            return [false, "کد وارد‌شده صحیح نیست. {$left} تلاش باقی مانده است."];
        }
        Database::run('UPDATE otp_codes SET used_at=NOW() WHERE id=?', [$row['id']]);
        return [true, $row];
    }
}

final class Sms
{
    /** ارسال پیامک — در حالت پیش‌فرض در جدول messages ثبت می‌شود (شبیه‌سازی/لاگ) */
    public static function send(string $mobile, string $body, ?int $personOrUserId = null, string $entityType = 'otp', ?string $recipientName = null): bool
    {
        try {
            $bizId = Auth::businessId() ?: 1;
            Database::insert('messages', [
                'business_id' => $bizId, 'channel' => 'sms', 'recipient' => $mobile, 'body' => $body,
                'entity_type' => $entityType, 'status' => 'sent', 'provider' => config('app')['sms_driver'],
                'sent_at' => now(), 'created_at' => now(), 'cost_amount' => 800,
            ]);
        } catch (Throwable $e) { /* عدم موفقیت ثبت پیامک نباید جریان اصلی را متوقف کند */ }
        // در حالت نمایشی/توسعه، متن پیامک در فایل لاگ ذخیره می‌شود (این فایل از دسترس وب مسدود است)
        if (config('app')['debug'] || config('app')['demo_mode']) {
            @file_put_contents(storage_path('sms.log'), date('c')." | {$mobile} | ".str_replace("\n", ' ', $body)."\n", FILE_APPEND);
        }
        return true;
    }
}

final class Sequence
{
    /** نگاشت نوع سند داخلی به مقادیر مجاز ستون number_sequences.doc_type */
    public static function docType(string $docType): string
    {
        $allowed = ['sale','buy','sale_return','buy_return','quote','receipt','payment','cheque','journal','hr','voucher','transfer','waste','count'];
        if (in_array($docType, $allowed, true)) return $docType;
        return match ($docType) {
            'expense', 'income', 'expenses', 'incomes' => 'voucher',
            'payroll' => 'hr',
            'stock_count', 'stock-count' => 'count',
            'stock_transfer' => 'transfer',
            default => 'voucher',
        };
    }

    /** شماره سند بعدی بر اساس number_sequences */
    public static function next(int $businessId, ?int $fiscalYearId, string $docType, array $ctx = []): string
    {
        $docType = self::docType($docType);
        $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? AND (fiscal_year_id <=> ?) ORDER BY id LIMIT 1', [$businessId, $docType, $fiscalYearId]);
        if (!$row) {
            $prefix = strtoupper(substr($docType, 0, 3));
            $defaultTpl = ($ctx['prefix'] ?? $prefix).'-{FY}-{SEQ}';
            Database::insert('number_sequences', ['business_id' => $businessId, 'fiscal_year_id' => $fiscalYearId, 'doc_type' => $docType,
                'template' => $ctx['template'] ?? $defaultTpl, 'next_value' => 1, 'step' => 1, 'reset_yearly' => 1, 'created_at' => now()]);
            $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id DESC LIMIT 1', [$businessId, $docType]);
        }
        $seq = (int)$row['next_value'];
        Database::run('UPDATE number_sequences SET next_value = next_value + ? WHERE id=?', [(int)($row['step'] ?: 1), $row['id']]);
        $fy = $ctx['fy'] ?? current_jalali_year();
        // قالب اختصاصی (مثلاً EXP/INC برای اسناد هزینه و درآمد که سری شماره مشترک دارند)
        $tpl = $ctx['template'] ?? $row['template'];
        return str_replace(['{FY}', '{SEQ}', '{YYYY}'], [$fy, str_pad((string)$seq, 4, '0', STR_PAD_LEFT), date('Y')], $tpl);
    }
    /** شماره عددی خالص (برای ستون‌های عددی مثل journal_entries.entry_no) */
    public static function nextNumber(int $businessId, ?int $fiscalYearId, string $docType): int
    {
        $docType = self::docType($docType);
        $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id LIMIT 1', [$businessId, $docType]);
        if (!$row) {
            Database::insert('number_sequences', ['business_id' => $businessId, 'fiscal_year_id' => $fiscalYearId, 'doc_type' => $docType,
                'template' => '{SEQ}', 'next_value' => 1, 'step' => 1, 'reset_yearly' => 1, 'created_at' => now()]);
            $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id DESC LIMIT 1', [$businessId, $docType]);
        }
        $seq = (int)$row['next_value'];
        Database::run('UPDATE number_sequences SET next_value = next_value + ? WHERE id=?', [(int)($row['step'] ?: 1), $row['id']]);
        return $seq;
    }

    public static function peekNumber(int $businessId, ?int $fiscalYearId, string $docType): int
    {
        $docType = self::docType($docType);
        $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id LIMIT 1', [$businessId, $docType]);
        return (int)($row['next_value'] ?? 1);
    }

    public static function peek(int $businessId, ?int $fiscalYearId, string $docType): string
    {
        $docType = self::docType($docType);
        $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id LIMIT 1', [$businessId, $docType]);
        $seq = (int)($row['next_value'] ?? 1);
        $tpl = $row['template'] ?? 'DOC-{FY}-{SEQ}';
        return str_replace(['{FY}', '{SEQ}', '{YYYY}'], [current_jalali_year(), str_pad((string)$seq, 4, '0', STR_PAD_LEFT), date('Y')], $tpl);
    }
}

final class Audit
{
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, ?string $description = null, ?array $payload = null): void
    {
        try {
            $uid = Auth::id();
            $device = preg_match('/Mobile|Android|iPhone/i', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')) ? 'mobile' : 'desktop';
            Database::insert('audit_logs', [
                'business_id' => Auth::businessId(), 'user_id' => $uid, 'action' => $action,
                'entity_type' => $entityType, 'entity_id' => $entityId,
                'after_json' => json_encode(array_filter(['description' => $description, 'payload' => $payload], fn($v) => $v !== null && $v !== []), JSON_UNESCAPED_UNICODE),
                'ip_address' => inet_pton($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') ?: null,
                'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
                'device_type' => $device,
                'created_at' => now(),
            ]);
        } catch (Throwable $e) { }
    }
    public static function track(string $table, int $id, array $new, array $old = []): void
    {
        $changes = [];
        foreach ($new as $k => $v) if (!array_key_exists($k, $old) || (string)$old[$k] !== (string)$v) $changes[$k] = $v;
        if ($changes) self::log($old ? 'update' : 'create', $table, $id, ($old ? 'ویرایش ' : 'ایجاد ').$table, ['changes' => $changes]);
    }
}

final class Settings
{
    private static array $cache = [];
    public static function all(?int $businessId = null): array
    {
        $bid = $businessId ?: (Auth::businessId() ?: 0);
        if (isset(self::$cache[$bid])) return self::$cache[$bid];
        $out = [];
        foreach (Database::all('SELECT setting_key, value_json FROM settings WHERE business_id=?', [$bid]) as $r) {
            $v = $r['value_json'];
            $decoded = json_decode((string)$v, true);
            $out[$r['setting_key']] = json_last_error() === JSON_ERROR_NONE ? $decoded : $v;
        }
        return self::$cache[$bid] = $out;
    }
    public static function get(string $key, $default = null, ?int $businessId = null)
    {
        $all = self::all($businessId);
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }
    public static function set(int $businessId, string $key, $value): void
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE);
        // value_type فقط مقادیر مجاز enum را می‌پذیرد: bool|int|decimal|string|json|date
        $type = is_bool($value) ? 'bool'
            : (is_int($value) ? 'int'
            : (is_float($value) || (is_string($value) && is_numeric($value) && str_contains($value, '.')) ? 'decimal'
            : (is_array($value) ? 'json'
            : ((is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}/', $value)) ? 'date' : 'string'))));
        $row = Database::one('SELECT id FROM settings WHERE business_id=? AND setting_key=?', [$businessId, $key]);
        if ($row) Database::run('UPDATE settings SET value_json=?, value_type=? WHERE id=?', [$json, $type, $row['id']]);
        else {
            $prefix = explode('.', $key)[0];
            $category = in_array($prefix, ['financial','printing','hr','sms','backup','technical','access','moadian'], true) ? $prefix : 'technical';
            Database::insert('settings', ['business_id' => $businessId, 'category' => $category, 'setting_key' => $key, 'value_json' => $json,
                'value_type' => $type, 'title_fa' => $key, 'group_fa' => 'سایر', 'created_at' => now()]);
        }
        self::$cache = [];
    }
}

function storage_path(string $p = ''): string { return __DIR__.'/../storage/'.ltrim($p, '/'); }
