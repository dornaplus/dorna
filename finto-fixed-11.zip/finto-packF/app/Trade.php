<?php
/**
 * موتور عملیات تجاری: فاکتور، دریافت، پرداخت، انتقال، چک، هزینه، درآمد، حقوق
 * هر عملیات در یک تراکنش دیتابیس انجام می‌شود: سند حسابداری + سند انبار + مانده‌ها
 */
final class Trade
{
    /* ═══════════════════════ فاکتور ═══════════════════════ */
    public static function createInvoice(array $head, array $lines, array $charges = [], bool $postNow = false): int
    {
        $biz = (int)$head['business_id'];
        $date = $head['invoice_date'] ?? today();
        [$fy] = Posting::periodFor($biz, $date);
        if (empty($lines)) throw new RuntimeException('فاکتور باید حداقل یک ردیف کالا یا خدمت داشته باشد.');
        $type = $head['invoice_type'];
        $warehouseId = (int)($head['warehouse_id'] ?: Database::val('SELECT id FROM warehouses WHERE business_id=? AND status="active" ORDER BY id LIMIT 1', [$biz]));
        if (!$warehouseId && in_array($type, ['sale','buy','sale_return','buy_return'], true)) throw new RuntimeException('ابتدا حداقل یک انبار تعریف کنید.');

        return Database::transaction(function () use ($biz, $head, $lines, $charges, $postNow, $date, $fy, $type, $warehouseId) {
            $personId = (int)$head['person_id'];
            $isSale = in_array($type, ['sale','sale_return'], true);
            // محاسبه ردیف‌ها
            $subtotal = 0.0; $lineDiscount = 0.0; $taxTotal = 0.0; $costTotal = 0.0;
            $rows = [];
            foreach ($lines as $i => $l) {
                $qty = round((float)$l['quantity'], 4);
                if ($qty <= 0) throw new RuntimeException('مقدار ردیف '.($i + 1).' باید بزرگ‌تر از صفر باشد.');
                $unitPrice = round((float)$l['unit_price'], 2);
                $disc = round((float)($l['discount_percent'] ?? 0), 2);
                $discAmount = round($unitPrice * $qty * $disc / 100, 2);
                $lineTotal = round($unitPrice * $qty - $discAmount, 2);
                $taxId = $l['tax_id'] ?? null; $taxAmount = 0.0;
                if ($taxId) {
                    $tax = Database::one('SELECT * FROM taxes WHERE id=?', [$taxId]);
                    $base = $tax && $tax['is_inclusive'] ? round($lineTotal * 100 / (100 + (float)$tax['rate_percent']), 2) : $lineTotal;
                    $taxAmount = $tax && (float)$tax['rate_percent'] > 0 ? round($base * (float)$tax['rate_percent'] / 100, 2) : 0;
                    $lineTotal = $tax && $tax['is_inclusive'] ? $lineTotal : $lineTotal + $taxAmount;
                }
                $subtotal += round($unitPrice * $qty, 2);
                $lineDiscount += $discAmount;
                $taxTotal += $taxAmount;
                $unitId = !empty($l['unit_id']) ? (int)$l['unit_id'] : (int)Database::val('SELECT main_unit_id FROM products WHERE id=?', [(int)$l['product_id']]);
                $baseQty = $qty;
                if (!empty($l['unit_id'])) {
                    $f = (float)Database::val('SELECT factor FROM product_units WHERE product_id=? AND unit_id=?', [(int)$l['product_id'], (int)$l['unit_id']], 1);
                    $baseQty = round($qty * ($f ?: 1), 4);
                }
                $rows[] = ['row_no' => $i + 1, 'product_id' => (int)$l['product_id'], 'variant_id' => (int)($l['variant_id'] ?? 0),
                    'unit_id' => $unitId, 'quantity' => $qty, 'base_quantity' => $baseQty, 'unit_price' => $unitPrice,
                    'discount_percent' => $disc, 'discount_amount' => $discAmount, 'tax_id' => $taxId, 'tax_amount' => $taxAmount,
                    'line_total' => $lineTotal, 'unit_cost' => 0, 'warehouse_id' => $warehouseId, 'description' => $l['description'] ?? null];
            }
            // هزینه‌های سند
            $chargesTotal = 0.0; $chargeRows = [];
            foreach ($charges as $c) {
                if ((float)($c['amount'] ?? 0) <= 0) continue;
                $taxAmount = 0.0;
                if (!empty($c['tax_id'])) {
                    $t = Database::one('SELECT rate_percent, is_inclusive FROM taxes WHERE id=?', [$c['tax_id']]);
                    if ($t && (float)$t['rate_percent'] > 0) $taxAmount = round((float)$c['amount'] * (float)$t['rate_percent'] / 100, 2);
                }
                $chargeRows[] = ['charge_type' => $c['charge_type'] ?? 'other', 'title' => $c['title'] ?? 'هزینه', 'amount' => round((float)$c['amount'], 2),
                    'tax_id' => $c['tax_id'] ?? null, 'tax_amount' => $taxAmount, 'account_id' => $c['account_id'] ?? null];
                $chargesTotal += round((float)$c['amount'], 2) + $taxAmount;
            }
            $invoiceDiscount = round((float)($head['invoice_discount'] ?? 0), 2);
            $net = round($subtotal - $lineDiscount - $invoiceDiscount, 2);
            $total = round($net + $taxTotal + $chargesTotal, 2);
            $sign = in_array($type, ['sale_return','buy_return'], true) ? -1 : 1;

            $invNo = $head['invoice_no'] ?? Sequence::next($biz, (int)$fy['id'], $type, ['fy' => (int)substr((string)$fy['title'], -4)]);
            $settlementType = $head['settlement_type'] ?? ((int)($head['cash_account_id'] ?? 0) ? 'cash' : 'credit');
            $status = 'draft'; // وضعیت نهایی در postInvoice تعیین می‌شود
            // بهای تمام‌شده برای فروش (پیش‌محاسبه)
            $costTotal = 0.0;
            if ($isSale) foreach ($rows as $r) {
                $c = Inventory::peekCost($biz, $warehouseId, $r['product_id'], $r['base_quantity'], $r['variant_id']);
                $costTotal += $c;
            }
            $invId = Database::insert('invoices', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'invoice_type' => $type, 'invoice_no' => $invNo,
                'invoice_date' => $date, 'due_date' => $head['due_date'] ?? null, 'person_id' => $personId,
                'marketer_id' => $head['marketer_id'] ?? null, 'warehouse_id' => $warehouseId, 'project_id' => $head['project_id'] ?? null,
                'cost_center_id' => $head['cost_center_id'] ?? null,
                'settlement_type' => $settlementType, 'cash_account_id' => $head['cash_account_id'] ?? null,
                'currency_id' => $head['currency_id'] ?? base_currency_id($biz), 'fx_rate' => $head['fx_rate'] ?? 1,
                'subtotal' => round($subtotal, 2), 'line_discount' => round($lineDiscount, 2), 'invoice_discount' => $invoiceDiscount,
                'tax_amount' => round($taxTotal, 2), 'charges_amount' => round($chargesTotal, 2), 'total_amount' => $total,
                'paid_amount' => 0, 'cost_amount' => round($costTotal, 2),
                'status' => $status, 'settlement_status' => 'unpaid', 'auto_journal_enabled' => 1, 'inventory_doc_id' => null,
                'journal_entry_id' => null, 'description' => $head['description'] ?? null, 'is_active' => 1,
                'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            foreach ($rows as $r) { $r['invoice_id'] = $invId; $r['variant_id'] = variant_ref((int)$r['variant_id']); Database::insert('invoice_lines', $r); }
            foreach ($chargeRows as $c) { $c['invoice_id'] = $invId; Database::insert('invoice_charges', $c); }
            Database::insert('invoice_status_history', ['invoice_id' => $invId, 'from_status' => null, 'to_status' => $status, 'changed_by' => Auth::id(), 'changed_at' => now(), 'reason' => 'ایجاد فاکتور']);
            if ($postNow) self::postInvoice($invId);
            return $invId;
        });
    }

    /** قطعی‌کردن فاکتور: سند انبار + اسناد حسابداری + کمیسیون بازاریاب */
    public static function postInvoice(int $invoiceId): array
    {
        $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$invoiceId]);
        if (!$inv) throw new RuntimeException('فاکتور یافت نشد.');
        if ($inv['status'] === 'posted') return ['journal_entry_id' => $inv['journal_entry_id'], 'inventory_doc_id' => $inv['inventory_doc_id']];
        if (in_array($inv['status'], ['cancelled'], true)) throw new RuntimeException('فاکتور لغوشده قابل قطعی‌سازی نیست.');
        $biz = (int)$inv['business_id'];
        $lines = Database::all('SELECT * FROM invoice_lines WHERE invoice_id=? ORDER BY row_no', [$invoiceId]);
        $type = $inv['invoice_type'];
        $isSale = in_array($type, ['sale','sale_return'], true);
        $isReturn = in_array($type, ['sale_return','buy_return'], true);
        $warehouseId = (int)$inv['warehouse_id'];

        return Database::transaction(function () use ($inv, $lines, $biz, $type, $isSale, $isReturn, $warehouseId, $invoiceId) {
            // ۱) سند انبار
            $docType = $isSale ? ($isReturn ? 'sale_return' : 'issue') : ($isReturn ? 'buy_return' : 'receive');
            $docLines = [];
            $costTotal = 0.0;
            foreach ($lines as $l) {
                $docLines[] = ['product_id' => $l['product_id'], 'variant_id' => $l['variant_id'], 'unit_id' => $l['unit_id'],
                    'quantity' => $l['base_quantity'], 'unit_cost' => (float)$l['unit_price'], 'description' => $l['description']];
            }
            $docId = null;
            $hasGoods = (bool)Database::val('SELECT COUNT(*) FROM invoice_lines l JOIN products p ON p.id=l.product_id WHERE l.invoice_id=? AND p.item_type="goods"', [$invoiceId]);
            if ($hasGoods) {
                // فقط ردیف‌های کالایی وارد سند انبار می‌شوند
                $docLines = array_values(array_filter($docLines, fn($l) => Database::val('SELECT item_type FROM products WHERE id=?', [$l['product_id']]) === 'goods'));
                $docId = Inventory::createDocument([
                    'business_id' => $biz, 'fiscal_year_id' => $inv['fiscal_year_id'], 'doc_type' => $docType,
                    'doc_date' => $inv['invoice_date'], 'warehouse_id' => $warehouseId, 'person_id' => $inv['person_id'],
                    'source_type' => 'invoice', 'source_id' => $invoiceId,
                    'doc_no' => $inv['invoice_no'], 'description' => 'سند انبار فاکتور '.$inv['invoice_no'],
                ], $docLines, false);
                // بهای تمام‌شده واقعی و ثبت حرکت
                $totalCost = 0.0;
                foreach (Database::all('SELECT * FROM inventory_document_lines WHERE document_id=? ORDER BY row_no', [$docId]) as $dl) {
                    if ($isSale && !$isReturn) {
                        $res = Inventory::applyOut($biz, $warehouseId, (int)$dl['product_id'], (int)$dl['variant_id'], (float)$dl['base_quantity'], $inv['invoice_date'], $docId, 'invoice', $invoiceId);
                        Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$res['unit_cost'], $res['total_cost'], $dl['id']]);
                        Database::run('UPDATE invoice_lines SET unit_cost=? WHERE invoice_id=? AND product_id=? AND variant_id=?', [$res['unit_cost'], $invoiceId, $dl['product_id'], $dl['variant_id']]);
                        $totalCost += $res['total_cost'];
                    } elseif ($isSale && $isReturn) {
                        $inCost = (float)$dl['unit_cost']; // بهای ورود کالای برگشتی
                        Inventory::applyIn($biz, $warehouseId, (int)$dl['product_id'], (int)$dl['variant_id'], (float)$dl['base_quantity'], $inCost, $inv['invoice_date'], $docId, 'invoice', $invoiceId);
                        Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$inCost, round($inCost * (float)$dl['base_quantity'], 2), $dl['id']]);
                        $totalCost += round($inCost * (float)$dl['base_quantity'], 2);
                    } else { // خرید
                        $inCost = (float)$dl['unit_cost'];
                        if ($isReturn) { // برگشت از خرید = خروج کالا
                            $res = Inventory::applyOut($biz, $warehouseId, (int)$dl['product_id'], (int)$dl['variant_id'], (float)$dl['base_quantity'], $inv['invoice_date'], $docId, 'invoice', $invoiceId);
                            Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$res['unit_cost'], $res['total_cost'], $dl['id']]);
                            $totalCost += $res['total_cost'];
                        } else {
                            Inventory::applyIn($biz, $warehouseId, (int)$dl['product_id'], (int)$dl['variant_id'], (float)$dl['base_quantity'], $inCost, $inv['invoice_date'], $docId, 'invoice', $invoiceId);
                            Database::run('UPDATE inventory_document_lines SET unit_cost=?, total_cost=? WHERE id=?', [$inCost, round($inCost * (float)$dl['base_quantity'], 2), $dl['id']]);
                            $totalCost += round($inCost * (float)$dl['base_quantity'], 2);
                        }
                    }
                }
                Database::run('UPDATE inventory_documents SET status="posted", total_cost=?, journal_entry_id=NULL WHERE id=?', [round($totalCost, 2), $docId]);
                $costTotal = $totalCost;
            }
            // ۲) اسناد حسابداری
            $bag = ['invoice_total' => $inv['total_amount'], 'invoice_net' => round($inv['subtotal'] - $inv['line_discount'] - $inv['invoice_discount'], 2),
                    'tax' => $inv['tax_amount'], 'charges' => $inv['charges_amount'], 'cogs' => $costTotal];
            $taxId = (int)Database::val('SELECT tax_id FROM invoice_lines WHERE invoice_id=? AND tax_id IS NOT NULL LIMIT 1', [$invoiceId], 0);
            $ctx = ['date' => $inv['invoice_date'], 'person_id' => (int)$inv['person_id'], 'person_account' => $isSale ? 'ar' : 'ap',
                'cash_account_id' => $inv['cash_account_id'] ?? null, 'tax_id' => $taxId ?: null, 'reference_type' => 'invoice',
                'reference_id' => $invoiceId, 'reference_no' => $inv['invoice_no'], 'project_id' => $inv['project_id'] ?? null,
                'cost_center_id' => $inv['cost_center_id'] ?? null,
                'description' => ($isSale ? 'فروش' : 'خرید').($isReturn ? ' (برگشت)' : '').' - '.$inv['invoice_no']];
            $eventKey = match ($type) {
                'sale' => ($inv['settlement_type'] === 'cash' && $inv['cash_account_id']) ? 'invoice.sale.cash' : 'invoice.sale.credit',
                'sale_return' => 'invoice.sale_return',
                'buy' => ($inv['settlement_type'] === 'cash' && $inv['cash_account_id']) ? 'invoice.buy.cash' : 'invoice.buy.credit',
                'buy_return' => 'invoice.buy.credit',
                'quote' => null,
                default => null,
            };
            $jeId = null;
            if ($eventKey) $jeId = Posting::post($biz, $eventKey, $bag, $ctx);
            if (in_array($type, ['sale'], true) && $costTotal > 0) {
                Posting::post($biz, 'invoice.sale.cogs', ['cogs' => $costTotal], $ctx + ['description' => 'بهای تمام‌شده فروش - '.$inv['invoice_no']]);
            }
            if ($type === 'sale_return' && $costTotal > 0) {
                Posting::post($biz, 'invoice.sale_return.cogs', ['cogs' => $costTotal], $ctx + ['description' => 'برگشت بهای تمام‌شده - '.$inv['invoice_no']]);
            }
            if ($inv['settlement_type'] === 'cash' && $inv['cash_account_id'] && !$isReturn) {
                self::settleInvoice($invoiceId, (float)$inv['total_amount'], null, null, null, 'تسویه نقدی همراه فاکتور');
            }
            // ۳) کمیسیون بازاریاب
            if ($isSale && !$isReturn && $inv['marketer_id']) self::applyCommission($invoiceId);
            Database::run('UPDATE invoices SET status="posted", posted_at=NOW(), inventory_doc_id=?, journal_entry_id=?, cost_amount=? WHERE id=?',
                [$docId, $jeId, round($costTotal, 2), $invoiceId]);
            Database::insert('invoice_status_history', ['invoice_id' => $invoiceId, 'from_status' => $inv['status'], 'to_status' => 'posted', 'changed_by' => Auth::id(), 'changed_at' => now(), 'reason' => 'قطعی‌سازی']);
            Audit::log('post_invoice', 'invoices', $invoiceId, 'قطعی‌سازی فاکتور '.$inv['invoice_no'], ['total' => $inv['total_amount']]);
            return ['journal_entry_id' => $jeId, 'inventory_doc_id' => $docId, 'cost' => round($costTotal, 2)];
        });
    }

    public static function cancelInvoice(int $invoiceId, string $reason = ''): void
    {
        $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$invoiceId]);
        if (!$inv) throw new RuntimeException('فاکتور یافت نشد.');
        if ($inv['status'] === 'cancelled') return;
        if ($inv['status'] === 'posted') throw new RuntimeException('فاکتور قطعی‌شده قابل لغو نیست؛ از «برگشت از فروش/خرید» استفاده کنید.');
        Database::run('UPDATE invoices SET status="cancelled" WHERE id=?', [$invoiceId]);
        Inventory::releaseReservations($invoiceId);
        Database::insert('invoice_status_history', ['invoice_id' => $invoiceId, 'from_status' => $inv['status'], 'to_status' => 'cancelled', 'changed_by' => Auth::id(), 'changed_at' => now(), 'reason' => $reason ?: 'لغو فاکتور']);
        Audit::log('cancel_invoice', 'invoices', $invoiceId, 'لغو فاکتور '.$inv['invoice_no']);
    }

    /** تسویه فاکتور و به‌روزرسانی مانده + وضعیت تسویه */
    public static function settleInvoice(int $invoiceId, float $amount, ?string $source = null, ?int $receiptId = null, ?int $paymentId = null, ?string $note = null, ?int $chequeId = null): void
    {
        $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$invoiceId]);
        if (!$inv) throw new RuntimeException('فاکتور یافت نشد.');
        $amount = round($amount, 2);
        if ($amount <= 0) return;
        Database::insert('invoice_settlements', [
            'business_id' => $inv['business_id'], 'invoice_id' => $invoiceId, 'settle_source' => $source ?: 'manual',
            'receipt_id' => $receiptId, 'payment_id' => $paymentId, 'cheque_id' => $chequeId, 'amount' => $amount,
            'settled_at' => now(), 'note' => $note, 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        $paid = (float)Database::val('SELECT IFNULL(SUM(amount),0) FROM invoice_settlements WHERE invoice_id=?', [$invoiceId], 0);
        $paid = round($paid, 2);
        $total = (float)$inv['total_amount'];
        $status = $paid <= 0.009 ? 'unpaid' : ($paid + 0.009 >= abs($total) ? 'paid' : 'partial');
        if ($status !== 'paid' && $inv['due_date'] && $inv['due_date'] < today()) $status = 'overdue';
        Database::run('UPDATE invoices SET paid_amount=?, settlement_status=? WHERE id=?', [$paid, $status, $invoiceId]);
    }

    /* ═══════════════════════ دریافت / پرداخت ═══════════════════════ */
    public static function createReceipt(array $head, array $allocations, bool $postNow = true): int
    {
        $biz = (int)Auth::businessId();
        $date = $head['doc_date'] ?? today();
        [$fy] = Posting::periodFor($biz, $date);
        $amount = round((float)$head['amount'], 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ دریافت باید بزرگ‌تر از صفر باشد.');
        return Database::transaction(function () use ($biz, $head, $allocations, $postNow, $date, $fy, $amount) {
            $allocSum = round(array_sum(array_map(fn($a) => (float)$a['amount'], $allocations)), 2);
            $mode = $allocSum > 0 ? 'invoice' : 'on_account';
            $chequeId = $head['cheque_id'] ?? null;
            $docNo = $head['doc_no'] ?? Sequence::next($biz, (int)$fy['id'], 'receipt', ['fy' => (int)substr((string)$fy['title'], -4)]);
            $id = Database::insert('receipts', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'doc_no' => $docNo, 'doc_date' => $date,
                'person_id' => (int)$head['person_id'], 'cash_account_id' => $head['cash_account_id'] ?? null,
                'payment_method_id' => $head['payment_method_id'] ?? null, 'cheque_id' => $chequeId, 'amount' => $amount,
                'currency_id' => $head['currency_id'] ?? base_currency_id($biz), 'fx_rate' => $head['fx_rate'] ?? 1,
                'bank_reference' => $head['bank_reference'] ?? null, 'allocation_mode' => $mode,
                'status' => $postNow ? 'posted' : 'draft', 'description' => $head['description'] ?? null,
                'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            $allocSum = 0;
            foreach ($allocations as $i => $a) {
                $amt = round((float)$a['amount'], 2); if ($amt <= 0) continue;
                Database::insert('receipt_lines', ['receipt_id' => $id, 'invoice_id' => (int)$a['invoice_id'], 'amount' => $amt, 'description' => $a['description'] ?? null]);
                if ($postNow) self::settleInvoice((int)$a['invoice_id'], $amt, 'receipt', $id, null, 'دریافت '.$docNo, $chequeId);
                $allocSum += $amt;
            }
            if ($postNow) {
                $event = $chequeId ? 'receipt.cheque' : 'receipt.cash';
                $jeId = Posting::post($biz, $event, ['amount' => $amount], [
                    'date' => $date, 'person_id' => (int)$head['person_id'], 'person_account' => 'ar',
                    'cash_account_id' => $head['cash_account_id'] ?? null, 'cheque_id' => $chequeId,
                    'reference_type' => 'receipt', 'reference_id' => $id, 'reference_no' => $docNo,
                    'description' => 'دریافت از '.($head['person_name'] ?? '').' - '.$docNo,
                ]);
                Database::run('UPDATE receipts SET journal_entry_id=? WHERE id=?', [$jeId, $id]);
                if ($chequeId) self::chequeEvent((int)$chequeId, 'received', $date, 'ثبت چک دریافتی همراه دریافت '.$docNo, $id, null);
            }
            Audit::log('post_receipt', 'receipts', $id, 'ثبت دریافت '.$docNo, ['amount' => $amount]);
            return $id;
        });
    }

    public static function createPayment(array $head, array $allocations, bool $postNow = true): int
    {
        $biz = (int)Auth::businessId();
        $date = $head['doc_date'] ?? today();
        [$fy] = Posting::periodFor($biz, $date);
        $amount = round((float)$head['amount'], 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ پرداخت باید بزرگ‌تر از صفر باشد.');
        return Database::transaction(function () use ($biz, $head, $allocations, $postNow, $date, $fy, $amount) {
            $allocSum = round(array_sum(array_map(fn($a) => (float)$a['amount'], $allocations)), 2);
            $mode = $allocSum > 0 ? (($head['allocation_mode'] ?? 'invoice') === 'expense' ? 'expense' : 'invoice') : 'on_account';
            $chequeId = $head['cheque_id'] ?? null;
            $docNo = $head['doc_no'] ?? Sequence::next($biz, (int)$fy['id'], 'payment', ['fy' => (int)substr((string)$fy['title'], -4)]);
            $id = Database::insert('payments', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'doc_no' => $docNo, 'doc_date' => $date,
                'person_id' => (int)$head['person_id'], 'cost_center_id' => $head['cost_center_id'] ?? null,
                'cash_account_id' => $head['cash_account_id'] ?? null, 'payment_method_id' => $head['payment_method_id'] ?? null,
                'cheque_id' => $chequeId, 'amount' => $amount, 'currency_id' => $head['currency_id'] ?? base_currency_id($biz),
                'fx_rate' => $head['fx_rate'] ?? 1, 'bank_reference' => $head['bank_reference'] ?? null,
                'allocation_mode' => $mode, 'status' => $postNow ? 'posted' : 'draft',
                'description' => $head['description'] ?? null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            foreach ($allocations as $a) {
                $amt = round((float)$a['amount'], 2); if ($amt <= 0) continue;
                Database::insert('payment_lines', ['payment_id' => $id, 'invoice_id' => !empty($a['invoice_id']) ? (int)$a['invoice_id'] : null,
                    'expense_document_id' => !empty($a['expense_document_id']) ? (int)$a['expense_document_id'] : null, 'amount' => $amt, 'description' => $a['description'] ?? null]);
                if ($postNow && !empty($a['invoice_id'])) self::settleInvoice((int)$a['invoice_id'], $amt, 'payment', null, $id, 'پرداخت '.$docNo, $chequeId);
                if ($postNow && !empty($a['expense_document_id'])) Database::run('UPDATE expense_documents SET payment_id=? WHERE id=?', [$id, $a['expense_document_id']]);
            }
            if ($postNow) {
                $event = $chequeId ? 'payment.cheque' : 'payment.cash';
                $jeId = Posting::post($biz, $event, ['amount' => $amount], [
                    'date' => $date, 'person_id' => (int)$head['person_id'], 'person_account' => 'ap',
                    'cash_account_id' => $head['cash_account_id'] ?? null, 'cheque_id' => $chequeId,
                    'reference_type' => 'payment', 'reference_id' => $id, 'reference_no' => $docNo,
                    'cost_center_id' => $head['cost_center_id'] ?? null,
                    'description' => 'پرداخت به '.($head['person_name'] ?? '').' - '.$docNo,
                ]);
                Database::run('UPDATE payments SET journal_entry_id=? WHERE id=?', [$jeId, $id]);
                if ($chequeId) self::chequeEvent((int)$chequeId, 'issued', $date, 'صدور چک همراه پرداخت '.$docNo, null, $id);
            }
            Audit::log('post_payment', 'payments', $id, 'ثبت پرداخت '.$docNo, ['amount' => $amount]);
            return $id;
        });
    }

    /* ═══════════════════════ انتقال وجه ═══════════════════════ */
    public static function createTransfer(array $head): int
    {
        $biz = (int)Auth::businessId();
        $date = $head['doc_date'] ?? today();
        [$fy] = Posting::periodFor($biz, $date);
        $amount = round((float)$head['amount'], 2);
        $from = (int)$head['from_cash_account_id']; $to = (int)$head['to_cash_account_id'];
        if ($from === $to) throw new RuntimeException('حساب مبدأ و مقصد نباید یکسان باشند.');
        if ($amount <= 0) throw new RuntimeException('مبلغ انتقال باید بزرگ‌تر از صفر باشد.');
        return Database::transaction(function () use ($biz, $head, $date, $fy, $amount, $from, $to) {
            $fee = round((float)($head['fee_amount'] ?? 0), 2);
            $docNo = Sequence::next($biz, (int)$fy['id'], 'transfer', ['fy' => (int)substr((string)$fy['title'], -4)]);
            $fromAcc = Database::one('SELECT * FROM cash_accounts WHERE id=?', [$from]);
            $toAcc = Database::one('SELECT * FROM cash_accounts WHERE id=?', [$to]);
            $lines = [
                ['account_id' => (int)$toAcc['gl_account_id'], 'debit' => $amount, 'description' => 'انتقال به '.$toAcc['title']],
            ];
            if ($fee > 0) $lines[] = ['account_id' => (int)Posting::resolveAccount($biz, 'mapping', 'bank_fee', null, []), 'debit' => $fee, 'description' => 'کارمزد انتقال'];
            $lines[] = ['account_id' => (int)$fromAcc['gl_account_id'], 'credit' => $amount + $fee, 'description' => 'انتقال از '.$fromAcc['title']];
            $jeId = Posting::create($biz, ['entry_date' => $date, 'entry_type' => 'transfer', 'reference_type' => 'transfer',
                'reference_no' => $docNo, 'source' => 'auto', 'description' => 'انتقال وجه '.$fromAcc['title'].' → '.$toAcc['title']], $lines);
            $id = Database::insert('transfers', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'doc_no' => $docNo, 'doc_date' => $date,
                'from_cash_account_id' => $from, 'to_cash_account_id' => $to, 'amount' => $amount,
                'fee_amount' => $fee, 'fee_cost_center_id' => $head['fee_cost_center_id'] ?? null,
                'bank_reference' => $head['bank_reference'] ?? null, 'journal_entry_id' => $jeId, 'status' => 'posted',
                'description' => $head['description'] ?? null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            self::updateCashBalance($from); self::updateCashBalance($to);
            Audit::log('post_transfer', 'transfers', $id, 'انتقال وجه '.$docNo, ['amount' => $amount]);
            return $id;
        });
    }

    public static function updateCashBalance(int $cashAccountId): void
    {
        $acc = Database::one('SELECT * FROM cash_accounts WHERE id=?', [$cashAccountId]);
        if (!$acc || !$acc['gl_account_id']) return;
        $bal = Posting::accountBalance((int)$acc['business_id'], (int)$acc['gl_account_id']);
        Database::run('UPDATE cash_accounts SET current_balance=? WHERE id=?', [round($bal['balance'], 2), $cashAccountId]);
    }

    /* ═══════════════════════ چک ═══════════════════════ */
    public static function createCheque(array $head): int
    {
        $biz = (int)Auth::businessId();
        $docNo = $head['cheque_no'] ?: Sequence::next($biz, Auth::fiscalYearId(), 'cheque');
        $id = Database::insert('cheques', [
            'business_id' => $biz, 'direction' => $head['direction'], 'cheque_no' => $docNo,
            'bank_name' => $head['bank_name'] ?? null, 'branch_name' => $head['branch_name'] ?? null,
            'account_no' => $head['account_no'] ?? null, 'sayad_id' => $head['sayad_id'] ?? null,
            'person_id' => $head['person_id'] ?? null, 'amount' => round((float)$head['amount'], 2),
            'currency_id' => $head['currency_id'] ?? base_currency_id($biz), 'issue_date' => $head['issue_date'] ?? today(),
            'due_date' => $head['due_date'] ?? null, 'cash_account_id' => $head['cash_account_id'] ?? null,
            'status' => 'in_hand', 'spent_to_person_id' => $head['spent_to_person_id'] ?? null,
            'receipt_id' => $head['receipt_id'] ?? null, 'payment_id' => $head['payment_id'] ?? null,
            'description' => $head['description'] ?? null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        Database::insert('cheque_histories', ['cheque_id' => $id, 'event' => self::chequeHistoryEvent('created'), 'event_date' => today(),
            'to_status' => 'in_hand', 'amount' => round((float)$head['amount'], 2), 'user_id' => Auth::id(), 'note' => 'ثبت چک', 'created_at' => now(), 'created_by' => Auth::id()]);
        return $id;
    }

    /** رویداد چرخه عمر چک با سند حسابداری */
    public static function chequeEvent(int $chequeId, string $event, ?string $date = null, string $note = '', ?int $receiptId = null, ?int $paymentId = null)
    {
        $ch = Database::one('SELECT * FROM cheques WHERE id=?', [$chequeId]);
        if (!$ch) throw new RuntimeException('چک یافت نشد.');
        $biz = (int)$ch['business_id'];
        $date = $date ?: today();
        $map = [
            'deposited' => ['from' => ['in_hand','endorsed'], 'to' => 'deposited', 'je' => null],
            'cleared'   => ['from' => ['in_hand','deposited','endorsed'], 'to' => 'cleared', 'je' => 'cheque.cleared'],
            'bounced'   => ['from' => ['in_hand','deposited','cleared'], 'to' => 'bounced', 'je' => 'cheque.bounced'],
            'spent'     => ['from' => ['in_hand'], 'to' => 'spent', 'je' => 'cheque.issued'],
            'endorsed'  => ['from' => ['in_hand','deposited'], 'to' => 'endorsed', 'je' => 'cheque.endorsed'],
            'paid'      => ['from' => ['in_hand','spent','endorsed'], 'to' => 'cleared', 'je' => 'cheque.paid'],
            'cancelled' => ['from' => ['in_hand','deposited','spent'], 'to' => 'cancelled', 'je' => null],
            'received'  => ['from' => [], 'to' => 'in_hand', 'je' => null],
            'issued'    => ['from' => [], 'to' => 'in_hand', 'je' => null],
        ];
        if (!isset($map[$event])) throw new RuntimeException('رویداد چک نامعتبر است.');
        $cfg = $map[$event];
        if ($cfg['from'] && !in_array($ch['status'], $cfg['from'], true) && $ch['status'] !== $cfg['to']) {
            throw new RuntimeException('این رویداد برای چک با وضعیت «'.self::chequeStatusTitle($ch['status']).'» مجاز نیست.');
        }
        return Database::transaction(function () use ($ch, $biz, $event, $date, $note, $cfg, $chequeId, $receiptId, $paymentId) {
            $jeId = null;
            if ($cfg['je']) {
                $jeId = Posting::post($biz, $cfg['je'], ['amount' => (float)$ch['amount']], [
                    'date' => $date, 'person_id' => (int)$ch['person_id'], 'person_account' => $ch['direction'] === 'received' ? 'ar' : 'ap',
                    'cash_account_id' => $ch['cash_account_id'] ?? null, 'cheque_id' => $chequeId,
                    'reference_type' => 'cheque', 'reference_id' => $chequeId, 'reference_no' => $ch['cheque_no'],
                    'description' => 'رویداد چک '.$ch['cheque_no'].' - '.self::chequeEventTitle($event),
                ]);
            }
            Database::insert('cheque_histories', [
                'cheque_id' => $chequeId, 'event' => self::chequeHistoryEvent($event), 'event_date' => $date, 'from_status' => $ch['status'],
                'to_status' => $cfg['to'], 'amount' => (float)$ch['amount'], 'journal_entry_id' => $jeId,
                'user_id' => Auth::id(), 'note' => $note, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            $upd = ['status' => $cfg['to']];
            if ($event === 'cleared') { $upd['cleared_at'] = $date.' '.date('H:i:s'); if ($ch['cash_account_id']) { } }
            if ($event === 'bounced') $upd['bounced_reason'] = $note;
            if ($event === 'spent' && $ch['spent_to_person_id'] === null) { }
            if ($jeId) $upd['journal_entry_id'] = $jeId;
            Database::update('cheques', $upd, 'id=:id', ['id' => $chequeId]);
            if (in_array($event, ['cleared'], true) && !empty($ch['receipt_id'])) Database::run('UPDATE cheques SET status=? WHERE id=?', [$cfg['to'], $chequeId]);
            if (!empty($ch['cash_account_id'])) self::updateCashBalance((int)$ch['cash_account_id']);
            Audit::log('cheque_event', 'cheques', $chequeId, 'رویداد '.self::chequeEventTitle($event).' چک '.$ch['cheque_no']);
            return $jeId;
        });
    }
    public static function chequeStatusTitle(string $s): string
    {
        return ['in_hand' => 'در جریان','deposited' => 'به بانک واگذار شد','cleared' => 'وصول شد','bounced' => 'برگشتی','spent' => 'خرج شده','endorsed' => 'واگذار شده','cancelled' => 'ابطال شده'][$s] ?? $s;
    }
    /** نگاشت رویدادهای داخلی چک به enum جدول cheque_histories */
    public static function chequeHistoryEvent(string $event): string
    {
        return [
            'created' => 'register', 'received' => 'register', 'issued' => 'register',
            'deposited' => 'deposit', 'cleared' => 'clear', 'paid' => 'clear',
            'bounced' => 'bounce', 'spent' => 'spend', 'endorsed' => 'endorse',
            'cancelled' => 'cancel', 'transfer' => 'transfer',
        ][$event] ?? 'transfer';
    }

    public static function chequeEventTitle(string $s): string
    {
        return ['received' => 'دریافت','issued' => 'صدور','deposited' => 'واگذاری به بانک','cleared' => 'وصول','bounced' => 'برگشت','spent' => 'خرج به شخص','endorsed' => 'واگذاری به شخص','paid' => 'پرداخت','cancelled' => 'ابطال'][$s] ?? $s;
    }

    /* ═══════════════════════ درآمد / هزینه ═══════════════════════ */
    public static function createExpenseOrIncome(string $kind, array $head, array $lines): int
    {
        $biz = (int)Auth::businessId();
        $date = $head['doc_date'] ?? today();
        [$fy] = Posting::periodFor($biz, $date);
        $isExpense = $kind === 'expense';
        $amount = round(array_sum(array_map(fn($l) => (float)$l['amount'] + (float)($l['tax_amount'] ?? 0), $lines)), 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ سند باید بزرگ‌تر از صفر باشد.');
        return Database::transaction(function () use ($biz, $head, $lines, $date, $fy, $amount, $isExpense) {
            $table = $isExpense ? 'expense_documents' : 'income_documents';
            $lineTable = $isExpense ? 'expense_document_lines' : 'income_document_lines';
            $docNo = Sequence::next($biz, (int)$fy['id'], 'voucher', ['fy' => (int)substr((string)$fy['title'], -4),
                'template' => ($isExpense ? 'EXP' : 'INC').'-{FY}-{SEQ}']);
            $fields = ['business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'doc_no' => $docNo, 'doc_date' => $date,
                'title' => $head['title'], 'person_id' => $head['person_id'] ?? null, 'cash_account_id' => $head['cash_account_id'] ?? null,
                'project_id' => $head['project_id'] ?? null, 'cost_center_id' => $head['cost_center_id'] ?? null,
                'amount' => $amount, 'status' => 'posted', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()];
            if ($isExpense) {
                $fields['expense_category_id'] = $head['category_id'] ?? null;
                $fields['expense_account_id'] = $head['account_id'] ?? null;
                $fields['refundable'] = $head['refundable'] ?? 'no';
                $fields['description'] = $head['description'] ?? null;
            } else {
                $fields['income_category_id'] = $head['category_id'] ?? null;
                $fields['revenue_account_id'] = $head['account_id'] ?? null;
                $fields['settlement_type'] = $head['settlement_type'] ?? 'cash';
                $fields['description'] = $head['description'] ?? null;
            }
            $id = Database::insert($table, $fields);
            // حساب پیش‌فرض: حساب سند ← حساب دسته‌بندی ← نگاشت حساب‌ها
            $fallbackAcc = (int)($head['account_id'] ?? 0);
            if (!$fallbackAcc && !empty($head['category_id'])) {
                $fallbackAcc = (int)Database::val('SELECT default_account_id FROM profit_loss_categories WHERE id=?', [(int)$head['category_id']], 0);
            }
            if (!$fallbackAcc) {
                $fallbackAcc = (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$biz, $isExpense ? 'expense_default' : 'other_income'], 0);
            }
            if (!$fallbackAcc) throw new RuntimeException('حساب پیش‌فرض هزینه/درآمد تعیین نشده است؛ در تنظیمات مالی نگاشت حساب‌ها را کامل کنید.');
            $rows = []; $taxTotal = 0.0;
            foreach ($lines as $i => $l) {
                if ((float)$l['amount'] <= 0) continue;
                $rows[] = ['row_no' => $i + 1, 'title' => $l['title'] ?? $head['title'],
                    'account_id' => (int)(!empty($l['account_id']) ? (int)$l['account_id'] : $fallbackAcc),
                    'cost_center_id' => $l['cost_center_id'] ?? $head['cost_center_id'] ?? null,
                    'tax_id' => $l['tax_id'] ?? null, 'amount' => round((float)$l['amount'], 2),
                    'tax_amount' => round((float)($l['tax_amount'] ?? 0), 2)];
                $taxTotal += (float)($l['tax_amount'] ?? 0);
            }
            foreach ($rows as $r) { $r[$isExpense ? 'expense_document_id' : 'income_document_id'] = $id; Database::insert($lineTable, $r); }
            // سند حسابداری
            $cashAcc = !empty($head['cash_account_id']) ? (int)$head['cash_account_id'] : null;
            $event = $isExpense ? ($cashAcc ? 'expense.cash' : 'expense.credit') : ($cashAcc ? 'income.cash' : 'income.credit');
            $jeId = Posting::post($biz, $event, ['amount' => $amount], [
                'date' => $date, 'person_id' => $head['person_id'] ?? null, 'person_account' => $isExpense ? 'ap' : 'ar',
                'cash_account_id' => $cashAcc, 'reference_type' => $isExpense ? 'expense_document' : 'income_document',
                'reference_id' => $id, 'reference_no' => $docNo, 'cost_center_id' => $head['cost_center_id'] ?? null,
                'description' => ($isExpense ? 'هزینه' : 'درآمد').' - '.$head['title'].' ('.$docNo.')',
            ]);
            // اگر حساب اختصاصی انتخاب شده، آرتیکل را با آن جایگزین کن
            $jeId = $jeId; // سند ثبت شد؛ اصلاح حساب در سطح قواعد نگاشت انجام می‌شود
            Database::run("UPDATE `$table` SET journal_entry_id=? WHERE id=?", [$jeId, $id]);
            if ($cashAcc) self::updateCashBalance($cashAcc);
            Audit::log($isExpense ? 'post_expense' : 'post_income', $table, $id, ($isExpense ? 'ثبت هزینه ' : 'ثبت درآمد ').$docNo, ['amount' => $amount]);
            return $id;
        });
    }

    /* ═══════════════════════ حقوق و دستمزد ═══════════════════════ */
    public static function createPayroll(array $head, array $rows): int
    {
        $biz = (int)Auth::businessId();
        $date = $head['doc_date'] ?? today();
        [$fy, $fp] = Posting::periodFor($biz, $date);
        if (!$rows) throw new RuntimeException('سند حقوق بدون پرسنل قابل ثبت نیست.');
        return Database::transaction(function () use ($biz, $head, $rows, $date, $fy, $fp) {
            $docNo = Sequence::next($biz, (int)$fy['id'], 'hr', ['fy' => (int)substr((string)$fy['title'], -4)]);
            $docId = Database::insert('payroll_documents', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'fiscal_period_id' => $fp['id'] ?? null,
                'doc_no' => $docNo, 'doc_date' => $date, 'period_title' => $head['period_title'] ?? jdate($date),
                'employee_count' => count($rows), 'gross_amount' => 0, 'insurance_employee' => 0, 'insurance_employer' => 0,
                'tax_amount' => 0, 'deductions_amount' => 0, 'net_amount' => 0, 'cash_account_id' => $head['cash_account_id'] ?? null,
                'cost_center_id' => $head['cost_center_id'] ?? null, 'status' => 'draft', 'is_active' => 1,
                'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            $gross = 0; $insEmp = 0; $insEr = 0; $tax = 0; $ded = 0; $net = 0;
            foreach ($rows as $r) {
                $settings = Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [(int)$r['employee_id']]);
                $base = (float)($r['base_salary'] ?? ($settings['base_salary'] ?? 0));
                $housing = (float)($settings['housing_allowance'] ?? 0);
                $food = (float)($settings['food_allowance'] ?? 0);
                $child = (float)($settings['child_allowance'] ?? 0);
                $other = (float)($settings['other_allowances'] ?? 0);
                $manual = array_sum(array_map(fn($x) => (float)($x['amount'] ?? 0), $r['components'] ?? []));
                $g = round($base + $housing + $food + $child + $other + $manual, 2);
                $irEmp = (float)($settings['insurance_rate_employee'] ?? 7);
                $irEr = (float)($settings['insurance_rate_employer'] ?? 23);
                $ie = round($g * $irEmp / 100, 2);
                $ier = round($g * $irEr / 100, 2);
                $exempt = (float)($settings['tax_exemption_amount'] ?? 0);
                $taxable = max(0, round($g - $ie - $exempt, 2));
                $tx = round(self::payrollTax($taxable), 2);
                $manualDed = (float)($r['deductions'] ?? 0);
                $n = round($g - $ie - $tx - $manualDed, 2);
                $lineId = Database::insert('payroll_document_lines', ['payroll_document_id' => $docId, 'employee_id' => (int)$r['employee_id'],
                    'worked_days' => (float)($r['worked_days'] ?? 30), 'gross_amount' => $g, 'deductions_amount' => round($manualDed + $ie + $tx, 2),
                    'net_amount' => $n, 'payment_id' => null]);
                foreach (($r['components'] ?? []) as $c) {
                    if ((float)($c['amount'] ?? 0) == 0 && empty($c['component_id'])) continue;
                    Database::insert('payroll_line_items', ['payroll_line_id' => $lineId, 'component_id' => (int)($c['component_id'] ?? 0),
                        'amount' => round((float)($c['amount'] ?? 0), 2), 'percent_used' => $c['percent_used'] ?? null]);
                }
                $gross += $g; $insEmp += $ie; $insEr += $ier; $tax += $tx; $ded += $manualDed; $net += $n;
            }
            Database::run('UPDATE payroll_documents SET gross_amount=?, insurance_employee=?, insurance_employer=?, tax_amount=?, deductions_amount=?, net_amount=? WHERE id=?',
                [round($gross, 2), round($insEmp, 2), round($insEr, 2), round($tax, 2), round($ded, 2), round($net, 2), $docId]);
            // سند حسابداری حقوق
            $jeId = Posting::post($biz, 'payroll', ['amount' => round($gross, 2),
                'expense_total' => round($gross + $insEr, 2),
                'insurance_payable' => round($insEmp + $insEr, 2), 'tax' => round($tax, 2), 'net' => round($net, 2)],
                ['date' => $date, 'reference_type' => 'payroll_document', 'reference_id' => $docId, 'reference_no' => $docNo,
                 'cost_center_id' => $head['cost_center_id'] ?? null, 'description' => 'سند حقوق '.($head['period_title'] ?? $docNo)]);
            Database::run('UPDATE payroll_documents SET journal_entry_id=?, status="posted" WHERE id=?', [$jeId, $docId]);
            Audit::log('post_payroll', 'payroll_documents', $docId, 'ثبت سند حقوق '.$docNo, ['gross' => $gross, 'net' => $net]);
            return $docId;
        });
    }

    /** محاسبه پلکانی مالیات حقوق ۱۴۰۴ (ساده‌شده) */
    public static function payrollTax(float $taxable): float
    {
        if ($taxable <= 0) return 0;
        $brackets = [[100000000, 0.10], [150000000, 0.15], [200000000, 0.20], [PHP_INT_MAX, 0.30]];
        $tax = 0; $prev = 0;
        foreach ($brackets as [$cap, $rate]) {
            if ($taxable > $prev) { $tax += ($taxable - $prev) * $rate; $prev = $cap; }
            if ($taxable <= $cap) break;
        }
        return $tax;
    }

    /* ═══════════════════════ کمیسیون بازاریاب ═══════════════════════ */
    public static function applyCommission(int $invoiceId): void
    {
        $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$invoiceId]);
        if (!$inv || !$inv['marketer_id']) return;
        $mk = Database::one('SELECT * FROM marketers WHERE id=?', [$inv['marketer_id']]);
        if (!$mk) return;
        $base = match ($mk['commission_base'] ?? 'net_invoice') {
            'gross_invoice' => (float)$inv['total_amount'],
            'invoice_profit' => (float)$inv['profit_amount'],
            default => round((float)$inv['subtotal'] - (float)$inv['line_discount'], 2),
        };
        $percent = (float)($mk['commission_percent'] ?? 0);
        if ($percent <= 0) return;
        Database::insert('invoice_commissions', ['business_id' => $inv['business_id'], 'invoice_id' => $invoiceId, 'marketer_id' => $inv['marketer_id'],
            'base_amount' => $base, 'percent' => $percent, 'commission_amount' => round($base * $percent / 100, 2),
            'status' => 'pending', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
    }
}
