<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?></title><link rel="stylesheet" href="<?= asset('theme.css') ?>"></head>
<body><div class="public">
  <div class="auth-card" style="text-align:center">
    <div style="font-size:52px;font-weight:700;color:var(--p-600)"><?= (int)$code ?></div>
    <h2><?= e($title) ?></h2>
    <?php if (!empty($message)): ?><div class="alert error" style="text-align:right"><div style="white-space:pre-wrap"><?= e($message) ?></div></div><?php endif; ?>
    <div class="btn-row" style="justify-content:center;margin-top:14px">
      <a class="btn" href="<?= url('app') ?>">بازگشت به نرم‌افزار</a>
      <a class="btn gray" href="<?= url('/') ?>">صفحه اصلی</a>
    </div>
  </div>
</div></body></html>
