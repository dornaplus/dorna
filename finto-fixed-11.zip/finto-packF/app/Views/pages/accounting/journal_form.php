<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array|null $entry @var array $lines @var array $accounts @var array $persons @var array $projects @var array $costCenters
 *  @var int $nextNo @var array $entryTypes */
$entry = $entry ?? null; $lines = $lines ?? []; $accounts = $accounts ?? []; $persons = $persons ?? [];
$projects = $projects ?? []; $costCenters = $costCenters ?? []; $entryTypes = $entryTypes ?? ['normal'];
$typeTitles = ['normal' => 'عادی', 'adjustment' => 'اصلاحی', 'opening' => 'افتتاحیه', 'closing' => 'بستن سال', 'payroll' => 'حقوق و دستمزد', 'transfer' => 'انتقالی'];
$old = $_SESSION['_old'] ?? [];
$rowcount = max(3, count($lines) + 1);
?>
<div class="page-head">
    <h2><?= $entry ? 'ویرایش سند '.e($entry['entry_no']) : 'ثبت سند حسابداری' ?></h2>
    <div class="actions">
        <span class="pill st-draft">شماره بعدی: <?= e($nextNo) ?></span>
        <a class="btn gray" href="<?= url('app/journal') ?>">بازگشت به فهرست</a>
    </div>
</div>

<form method="post" action="<?= url('app/journal') ?>" class="stack" data-journal="1">
<?= csrf_field() ?>
<div class="card">
    <div class="card-head"><h3>مشخصات سند</h3></div>
    <div class="card-body">
        <div class="grid c4">
            <label class="field"><span>تاریخ سند</span>
                <input type="text" name="entry_date" class="inp jalali" dir="ltr" required
                       value="<?= e(jdate($entry['entry_date'] ?? ($old['entry_date'] ?? today()))) ?>" data-date="<?= e($entry['entry_date'] ?? today()) ?>">
            </label>
            <label class="field"><span>نوع سند</span>
                <select name="entry_type" class="inp">
                    <?php foreach ($entryTypes as $t): ?>
                        <option value="<?= $t ?>" <?= ($entry['entry_type'] ?? ($old['entry_type'] ?? 'normal')) === $t ? 'selected' : '' ?>><?= e($typeTitles[$t] ?? $t) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>عطف / شماره مرجع</span><input type="text" name="reference_no" class="inp" dir="ltr"
                       value="<?= e($entry['reference_no'] ?? ($old['reference_no'] ?? '')) ?>"></label>
            <label class="field"><span>پروژه</span>
                <select name="project_id" class="inp select-search">
                    <option value="">— بدون پروژه —</option>
                    <?php foreach ($projects as $pj): ?>
                        <option value="<?= (int)$pj['id'] ?>" <?= (string)($entry['project_id'] ?? '') === (string)$pj['id'] ? 'selected' : '' ?>><?= e($pj['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <label class="field"><span>شرح سند</span><input type="text" name="description" class="inp" required
               value="<?= e($entry['description'] ?? ($old['description'] ?? '')) ?>" placeholder="شرح کلی سند حسابداری"></label>
    </div>
</div>

<div class="card">
    <div class="card-head">
        <h3>آرتیکل‌های سند</h3>
        <div class="muted sm">جمع بدهکار و بستانکار باید برابر باشد. برای حساب‌های «شخص‌دار» (مثل حساب‌های دریافتنی) انتخاب طرف حساب الزامی است.</div>
    </div>
    <div class="table-wrap">
        <table class="tbl" data-rows="jl">
            <thead>
                <tr>
                    <th style="width:42px">#</th>
                    <th style="min-width:260px">حساب</th>
                    <th>طرف حساب</th>
                    <th>مرکز هزینه</th>
                    <th>شرح آرتیکل</th>
                    <th class="num" style="min-width:140px">بدهکار</th>
                    <th class="num" style="min-width:140px">بستانکار</th>
                    <th style="width:46px"></th>
                </tr>
            </thead>
            <tbody>
            <?php for ($i = 0; $i < $rowcount; $i++): $l = $lines[$i] ?? []; ?>
                <tr>
                    <td class="num"><?= $i + 1 ?></td>
                    <td>
                        <select name="line_account_id[<?= $i ?>]" class="inp select-search">
                            <option value="">— انتخاب حساب —</option>
                            <?php foreach ($accounts as $a): ?>
                                <option value="<?= (int)$a['id'] ?>" data-person="<?= (int)($a['person_required'] ?? 0) ?>"
                                    <?= (int)($l['account_id'] ?? 0) === (int)$a['id'] ? 'selected' : '' ?>><?= e($a['code']) ?> — <?= e($a['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_person_id[<?= $i ?>]" class="inp select-search">
                            <option value="">—</option>
                            <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '')) ?: ($p['company_name'] ?? ''); ?>
                                <option value="<?= (int)$p['id'] ?>" <?= (int)($l['person_id'] ?? 0) === (int)$p['id'] ? 'selected' : '' ?>><?= e($nm) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_cost_center_id[<?= $i ?>]" class="inp">
                            <option value="">—</option>
                            <?php foreach ($costCenters as $cc): ?>
                                <option value="<?= (int)$cc['id'] ?>" <?= (int)($l['cost_center_id'] ?? 0) === (int)$cc['id'] ? 'selected' : '' ?>><?= e($cc['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><input type="text" name="line_desc[<?= $i ?>]" class="inp" value="<?= e($l['description'] ?? '') ?>"></td>
                    <td><input type="text" name="line_debit[<?= $i ?>]" class="inp money jdr" value="<?= (float)($l['debit_amount'] ?? 0) ? number_format((float)$l['debit_amount']) : '' ?>"></td>
                    <td><input type="text" name="line_credit[<?= $i ?>]" class="inp money jcr" value="<?= (float)($l['credit_amount'] ?? 0) ? number_format((float)$l['credit_amount']) : '' ?>"></td>
                    <td><button type="button" class="btn icon gray js-del-row" title="حذف">✕</button></td>
                </tr>
            <?php endfor; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="5" class="end">جمع</th>
                    <th class="num jdr_sum">0</th>
                    <th class="num jcr_sum">0</th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="card-foot">
        <div class="total-box">
            <div><span>جمع بدهکار</span><strong class="num jdr_sum">0</strong></div>
            <div><span>جمع بستانکار</span><strong class="num jcr_sum">0</strong></div>
            <div class="grand"><span>مانده (بدهکار - بستانکار)</span><strong class="num jdiff_out">0</strong></div>
        </div>
        <div class="actions">
            <button type="button" class="btn soft js-add-row">افزودن آرتیکل</button>
            <button type="submit" class="btn js-submit"><?= $entry ? 'ذخیره سند' : 'ثبت سند' ?></button>
            <a class="btn gray" href="<?= url('app/journal') ?>">انصراف</a>
        </div>
    </div>
</div>
</form>
<script>
(function () {
    var tbl = document.querySelector('table[data-rows="jl"]');
    if (!tbl) return;
    function num(v) { return parseFloat(String(v).replace(/[^\d.-]/g, '')) || 0; }
    function renumber() {
        tbl.querySelectorAll('tbody tr').forEach(function (tr, n) {
            var c = tr.querySelector('td.num'); if (c) c.textContent = n + 1;
            tr.querySelectorAll('input,select').forEach(function (el) { if (el.name) el.name = el.name.replace(/\[\d+]/, '[' + n + ']'); });
        });
    }
    function recalc() {
        var dr = 0, cr = 0;
        tbl.querySelectorAll('.jdr').forEach(function (i) { dr += num(i.value); });
        tbl.querySelectorAll('.jcr').forEach(function (i) { cr += num(i.value); });
        document.querySelectorAll('.jdr_sum').forEach(function (el) { el.textContent = dr.toLocaleString('fa-IR'); });
        document.querySelectorAll('.jcr_sum').forEach(function (el) { el.textContent = cr.toLocaleString('fa-IR'); });
        var diff = dr - cr;
        document.querySelectorAll('.jdiff_out').forEach(function (el) {
            el.textContent = diff.toLocaleString('fa-IR');
            el.classList.toggle('neg', Math.abs(diff) > 0.009);
        });
        var ok = Math.abs(diff) < 0.009 && dr > 0;
        var sub = document.querySelector('.js-submit');
        if (sub) { sub.disabled = !ok; sub.title = ok ? '' : 'جمع بدهکار و بستانکار باید برابر و بزرگ‌تر از صفر باشد'; }
    }
    tbl.addEventListener('input', recalc);
    var add = document.querySelector('.js-add-row');
    if (add) add.addEventListener('click', function () {
        var tpl = tbl.querySelector('tbody tr').cloneNode(true);
        tpl.querySelectorAll('input').forEach(function (i) { i.value = ''; });
        tpl.querySelectorAll('select').forEach(function (s) { s.value = ''; });
        tbl.querySelector('tbody').appendChild(tpl); renumber(); recalc();
    });
    tbl.addEventListener('click', function (ev) {
        var b = ev.target.closest('.js-del-row'); if (!b) return;
        var rows = tbl.querySelectorAll('tbody tr');
        if (rows.length <= 1) rows[0].querySelectorAll('input').forEach(function (i) { i.value = ''; });
        else b.closest('tr').remove();
        renumber(); recalc();
    });
    recalc();
})();
</script>
<?= view('partials/foot') ?>