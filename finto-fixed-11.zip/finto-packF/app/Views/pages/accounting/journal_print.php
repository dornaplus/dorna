<?php /** @var array $e @var array $lines @var array $business */
$lines = $lines ?? []; $business = $business ?? Auth::business();
$typeTitles = ['normal' => 'عادی', 'adjustment' => 'اصلاحی', 'opening' => 'افتتاحیه', 'closing' => 'بستن سال', 'payroll' => 'حقوق و دستمزد', 'transfer' => 'انتقالی'];
?>
<div class="print-page">
    <div class="print-head">
        <div>
            <h1><?= e($business['name'] ?? '') ?></h1>
            <div class="muted sm"><?= e($business['address'] ?? '') ?> <?= !empty($business['phone']) ? ' — تلفن: '.e($business['phone']) : '' ?></div>
        </div>
        <div class="end">
            <h2>سند حسابداری</h2>
            <div>شماره: <strong dir="ltr"><?= e($e['entry_no']) ?></strong></div>
            <div>تاریخ: <strong class="num"><?= e(jdate($e['entry_date'])) ?></strong></div>
            <div>نوع: <?= e($typeTitles[$e['entry_type']] ?? $e['entry_type']) ?></div>
        </div>
    </div>
    <table class="tbl print-tbl">
        <thead><tr><th>#</th><th>کد</th><th>شرح حساب</th><th>تفصیلی</th><th class="num">بدهکار</th><th class="num">بستانکار</th></tr></thead>
        <tbody>
        <?php foreach ($lines as $i => $l): ?>
            <tr>
                <td class="num"><?= $i + 1 ?></td>
                <td class="num" dir="ltr"><?= e($l['account_code']) ?></td>
                <td><?= e($l['account_title']) ?></td>
                <td><?= e(mb_strimwidth((string)($l['description'] ?? ''), 0, 60, '…')) ?></td>
                <td class="num"><?= $l['debit_amount'] > 0 ? money($l['debit_amount']) : '' ?></td>
                <td class="num"><?= $l['credit_amount'] > 0 ? money($l['credit_amount']) : '' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4" class="end">جمع</th><th class="num"><?= money($e['total_debit']) ?></th><th class="num"><?= money($e['total_credit']) ?></th></tr>
        </tfoot>
    </table>
    <?php if (!empty($e['description'])): ?>
        <p class="print-note"><strong>شرح:</strong> <?= e($e['description']) ?></p>
    <?php endif; ?>
    <p class="words"><?= e(amount_in_words((float)$e['total_debit'], currency_title())) ?></p>
    <div class="signs">
        <div>تهیه‌کننده</div><div>تأییدکننده</div><div>مدیر مالی</div><div>مدیرعامل</div>
    </div>
    <div class="print-foot">
        <span><?= e(config('app')['name']) ?></span>
        <span>تاریخ چاپ: <?= e(jdate(today())) ?> — ساعت <?= e(date('H:i')) ?></span>
    </div>
</div>
<script>window.print && setTimeout(function(){ window.print(); }, 400);</script>
