<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $e @var array $lines */
$lines = $lines ?? [];
$typeTitles = ['normal' => 'عادی', 'adjustment' => 'اصلاحی', 'opening' => 'افتتاحیه', 'closing' => 'بستن سال', 'payroll' => 'حقوق و دستمزد', 'transfer' => 'انتقالی'];
$statusTitles = ['draft' => 'پیش‌نویس', 'posted' => 'قطعی', 'reversed' => 'برگشت‌شده'];
$srcTitles = ['manual' => 'دستی', 'auto' => 'خودکار', 'invoice' => 'فاکتور', 'receipt' => 'دریافت', 'payment' => 'پرداخت', 'inventory' => 'انبار', 'payroll' => 'حقوق'];
?>
<div class="page-head">
    <div>
        <h2>سند حسابداری <?= e($e['entry_no']) ?></h2>
        <div class="muted sm"><?= e(jdate($e['entry_date'])) ?> — <?= e($typeTitles[$e['entry_type']] ?? $e['entry_type']) ?>
            — <span class="pill <?= $e['status'] === 'posted' ? 'st-paid' : ($e['status'] === 'reversed' ? 'st-cancelled' : 'st-draft') ?>"><?= e($statusTitles[$e['status']] ?? $e['status']) ?></span></div>
    </div>
    <div class="actions">
        <a class="btn soft" href="<?= url('app/journal/'.$e['id'].'/print') ?>" target="_blank"><?= icon('print') ?> چاپ سند</a>
        <?php if ($e['status'] === 'posted'): ?>
            <form method="post" action="<?= url('app/journal/'.$e['id'].'/reverse') ?>" data-confirm="سند برگشتی با همین مبالغ ثبت می‌شود. ادامه می‌دهید؟">
                <?= csrf_field() ?>
                <button class="btn danger" type="submit">ثبت سند برگشتی</button>
            </form>
        <?php endif; ?>
        <a class="btn gray" href="<?= url('app/journal') ?>">بازگشت</a>
    </div>
</div>

<div class="grid c4">
    <div class="card kpi">
        <span class="dot"></span>
        <div class="kv"><span>جمع بدهکار</span><strong class="num"><?= money($e['total_debit']) ?></strong></div>
    </div>
    <div class="card kpi">
        <span class="dot green"></span>
        <div class="kv"><span>جمع بستانکار</span><strong class="num"><?= money($e['total_credit']) ?></strong></div>
    </div>
    <div class="card kpi">
        <span class="dot gold"></span>
        <div class="kv"><span>منبع صدور</span><strong><?= e($srcTitles[$e['source']] ?? $e['source']) ?></strong></div>
    </div>
    <div class="card kpi">
        <span class="dot"></span>
        <div class="kv"><span>عطف</span><strong dir="ltr"><?= e($e['reference_no'] ?? '—') ?></strong></div>
    </div>
</div>

<div class="card">
    <div class="card-head"><h3>آرتیکل‌ها</h3><span class="muted sm"><?= num(count($lines), 0) ?> ردیف</span></div>
    <div class="table-wrap">
        <table class="tbl">
            <thead><tr><th>#</th><th>کد حساب</th><th>عنوان حساب</th><th>طرف حساب / مرکز هزینه</th><th>شرح</th><th class="num">بدهکار</th><th class="num">بستانکار</th></tr></thead>
            <tbody>
            <?php foreach ($lines as $i => $l):
                $pn = trim(($l['first_name'] ?? '').' '.($l['last_name'] ?? '')) ?: ($l['company_name'] ?? ''); ?>
                <tr>
                    <td class="num"><?= $i + 1 ?></td>
                    <td class="num" dir="ltr"><?= e($l['account_code']) ?></td>
                    <td><?= e($l['account_title']) ?></td>
                    <td><?= e($pn) ?><?= $pn && !empty($l['cost_center_name']) ? ' / ' : '' ?><?= e($l['cost_center_name'] ?? '') ?><?= !empty($l['cheque_no']) ? ' (چک '.e($l['cheque_no']).')' : '' ?></td>
                    <td><?= e(mb_strimwidth((string)($l['description'] ?? ''), 0, 70, '…')) ?></td>
                    <td class="num"><?= money($l['debit_amount']) ?></td>
                    <td class="num"><?= money($l['credit_amount']) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$lines): ?><tr><td colspan="7" class="muted center">آرتیکلی ثبت نشده است.</td></tr><?php endif; ?>
            </tbody>
            <tfoot>
                <tr><th colspan="5" class="end">جمع</th><th class="num"><?= money($e['total_debit']) ?></th><th class="num"><?= money($e['total_credit']) ?></th></tr>
            </tfoot>
        </table>
    </div>
</div>

<?php if (!empty($e['description'])): ?>
<div class="card">
    <div class="card-head"><h3>شرح سند</h3></div>
    <div class="card-body"><p><?= nl2br(e($e['description'])) ?></p></div>
</div>
<?php endif; ?>
<?= view('partials/foot') ?>