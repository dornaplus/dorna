<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $balances @var array $accounts @var array|null $fy */
$balances = $balances ?? []; $accounts = $accounts ?? []; $fy = $fy ?? null;
$sumDr = 0; $sumCr = 0;
foreach ($balances as $b) { $sumDr += (float)$b['debit_amount']; $sumCr += (float)$b['credit_amount']; }
?>
<div class="page-head">
    <div>
        <h2>تراز افتتاحیه سال مالی <?= e($fy['title'] ?? '') ?></h2>
        <div class="muted sm">مانده ابتدای دوره حساب‌ها را وارد کنید. با ذخیره، «سند افتتاحیه» صادر و مانده‌ها قفل می‌شوند.</div>
    </div>
    <div class="actions">
        <a class="btn gray" href="<?= url('app/settings/financial') ?>">تنظیمات مالی</a>
        <a class="btn gray" href="<?= url('app/journal') ?>">اسناد حسابداری</a>
    </div>
</div>

<?php if (!empty($balances)): ?>
<div class="alert info">تراز افتتاحیه این سال مالی قبلاً ثبت شده است (<?= num(count($balances), 0) ?> حساب). با ذخیره مجدد، مقادیر پیشین جایگزین می‌شوند.</div>
<?php endif; ?>

<form method="post" action="<?= url('app/opening-balances/setup') ?>" class="stack" data-opening="1">
<?= csrf_field() ?>
<div class="card">
    <div class="card-head">
        <h3>حساب‌های قابل تخصیص</h3>
        <input type="search" class="inp" style="max-width:260px" placeholder="جست‌وجوی کد یا نام حساب…" data-opening-search>
    </div>
    <div class="table-wrap">
        <table class="tbl" data-opening-table>
            <thead>
                <tr><th>کد حساب</th><th>عنوان حساب</th><th class="num" style="min-width:150px">بدهکار</th><th class="num" style="min-width:150px">بستانکار</th><th class="num">مانده</th></tr>
            </thead>
            <tbody>
            <?php foreach ($accounts as $a): $b = $balances[(int)$a['id']] ?? null;
                $dr = (float)($b['debit_amount'] ?? 0); $cr = (float)($b['credit_amount'] ?? 0); ?>
                <tr data-search="<?= e($a['code'].' '.$a['title']) ?>">
                    <td class="num" dir="ltr"><?= e($a['code']) ?></td>
                    <td><?= e($a['title']) ?></td>
                    <td><input type="text" name="debit[<?= (int)$a['id'] ?>]" class="inp money op-dr" value="<?= $dr > 0 ? e(number_format($dr)) : '' ?>"></td>
                    <td><input type="text" name="credit[<?= (int)$a['id'] ?>]" class="inp money op-cr" value="<?= $cr > 0 ? e(number_format($cr)) : '' ?>"></td>
                    <td class="num op-bal"><?= money($dr - $cr) ?></td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$accounts): ?><tr><td colspan="5" class="muted center">حساب قابل تخصیصی یافت نشد.</td></tr><?php endif; ?>
            </tbody>
            <tfoot>
                <tr><th colspan="2" class="end">جمع</th><th class="num op-dr-sum">0</th><th class="num op-cr-sum">0</th><th class="num op-diff">0</th></tr>
            </tfoot>
        </table>
    </div>
    <div class="card-foot">
        <div class="total-box">
            <div><span>جمع بدهکار</span><strong class="num op-dr-sum">0</strong></div>
            <div><span>جمع بستانکار</span><strong class="num op-cr-sum">0</strong></div>
            <div class="grand"><span>اختلاف</span><strong class="num op-diff">0</strong></div>
        </div>
        <div class="actions">
            <button type="button" class="btn soft js-only-filled">نمایش فقط حساب‌های دارای مانده</button>
            <button type="submit" class="btn js-save-opening">ذخیره تراز افتتاحیه</button>
        </div>
    </div>
</div>
</form>
<script>
(function () {
    var form = document.querySelector('[data-opening="1"]'); if (!form) return;
    function num(v) { return parseFloat(String(v).replace(/[^\d.-]/g, '')) || 0; }
    function recalc() {
        var dr = 0, cr = 0;
        form.querySelectorAll('tbody tr').forEach(function (tr) {
            var d = num((tr.querySelector('.op-dr') || {}).value), c = num((tr.querySelector('.op-cr') || {}).value);
            dr += d; cr += c;
            var el = tr.querySelector('.op-bal');
            if (el) { el.textContent = (d - c).toLocaleString('fa-IR'); el.classList.toggle('neg', (d - c) < 0); }
        });
        form.querySelectorAll('.op-dr-sum').forEach(function (el) { el.textContent = dr.toLocaleString('fa-IR'); });
        form.querySelectorAll('.op-cr-sum').forEach(function (el) { el.textContent = cr.toLocaleString('fa-IR'); });
        var diff = dr - cr;
        form.querySelectorAll('.op-diff').forEach(function (el) { el.textContent = diff.toLocaleString('fa-IR'); el.classList.toggle('neg', Math.abs(diff) > 0.009); });
        var b = form.querySelector('.js-save-opening');
        if (b) { var ok = Math.abs(diff) < 0.009 && dr > 0; b.disabled = !ok; b.title = ok ? '' : 'جمع بدهکار و بستانکار باید برابر و بزرگ‌تر از صفر باشد'; }
    }
    form.addEventListener('input', recalc);
    var s = form.querySelector('[data-opening-search]');
    if (s) s.addEventListener('input', function () {
        var q = s.value.trim();
        form.querySelectorAll('tbody tr[data-search]').forEach(function (tr) {
            tr.style.display = (!q || tr.dataset.search.indexOf(q) !== -1) ? '' : 'none';
        });
    });
    var only = form.querySelector('.js-only-filled');
    if (only) only.addEventListener('click', function () {
        var on = only.dataset.on === '1'; only.dataset.on = on ? '0' : '1';
        form.querySelectorAll('tbody tr[data-search]').forEach(function (tr) {
            var filled = num((tr.querySelector('.op-dr') || {}).value) || num((tr.querySelector('.op-cr') || {}).value);
            tr.style.display = (!on || filled) ? '' : 'none';
        });
        only.textContent = on ? 'نمایش فقط حساب‌های دارای مانده' : 'نمایش همه حساب‌ها';
    });
    recalc();
})();
</script>
<?= view('partials/foot') ?>