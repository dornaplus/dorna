<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $employees @var array $components @var array $cashAccounts @var array $costCenters @var array $doc @var string $nextNo */
$employees = $employees ?? []; $components = $components ?? []; $doc = $doc ?? [];
$rows = Database::all('SELECT id,title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [Auth::businessId()]);
?>
<form method="post" action="<?= url('app/payroll-documents') ?>" class="stack" data-payroll="1">
<?= csrf_field() ?>
<input type="hidden" name="redirect_to" value="create">
<div class="card">
    <div class="card-head">
        <h3>ثبت سند حقوق و دستمزد</h3>
        <span class="pill st-draft">شماره بعدی: <?= e($nextNo) ?></span>
    </div>
    <div class="card-body">
        <div class="grid c4">
            <label class="field"><span>تاریخ سند</span><input type="text" name="doc_date" class="inp jalali" value="<?= e(old('doc_date', today()) ? jdate(old('doc_date', today())) : '') ?>" data-date="<?= e(today()) ?>" dir="ltr" required></label>
            <label class="field"><span>عنوان دوره</span><input type="text" name="period_title" class="inp" value="<?= e(old('period_title', 'حقوق '.jdate(today()))) ?>"></label>
            <label class="field"><span>حساب پرداخت (صندوق/بانک)</span>
                <select name="cash_account_id" class="inp select-search">
                    <option value="">— انتخاب نشده —</option>
                    <?php foreach ($cashAccounts as $a): $sel = (string)old('cash_account_id', $doc['cash_account_id'] ?? '') === (string)$a['id']; ?>
                        <option value="<?= (int)$a['id'] ?>" <?= $sel ? 'selected' : '' ?>><?= e($a['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>مرکز هزینه</span>
                <select name="cost_center_id" class="inp select-search">
                    <option value="">— بدون مرکز هزینه —</option>
                    <?php foreach ($costCenters as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)old('cost_center_id', $doc['cost_center_id'] ?? '') === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['name'] ?? $c['title'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-head">
        <h3>اقلام حقوق پرسنل</h3>
        <div class="muted sm">جمع‌ها به‌صورت زنده محاسبه می‌شود؛ فرمول محاسبه مالیات و بیمه در «تنظیمات ← حقوق و دستمزد» قابل تعیین است.</div>
    </div>
    <div class="table-wrap">
        <table class="tbl" data-rows="emp">
            <thead>
                <tr>
                    <th style="width:42px">#</th>
                    <th>پرسنل</th>
                    <?php foreach ($components as $c): ?>
                        <th><?= e($c['title']) ?><small class="muted block"><?= e($c['calc_type']) ?></small></th>
                    <?php endforeach; ?>
                    <th>روز کارکرد</th>
                    <th>حقوق پایه</th>
                    <th>کسورات</th>
                    <th>جمع اقلام</th>
                    <th>جمع کل</th>
                </tr>
            </thead>
            <tbody>
            <?php $i = 0; foreach ($employees as $emp):
                $base = (float)($emp['base_salary'] ?? 0);
                $allow = (float)($emp['housing_allowance'] ?? 0) + (float)($emp['food_allowance'] ?? 0) + (float)($emp['child_allowance'] ?? 0) + (float)($emp['other_allowances'] ?? 0);
                $inRow = $base + $allow;
            ?>
                <tr data-row="emp">
                    <td class="num"><?= $i + 1 ?></td>
                    <td>
                        <strong><?= e($emp['full_name']) ?></strong>
                        <small class="muted block" dir="ltr"><?= e($emp['personnel_code'] ?? '') ?></small>
                        <input type="hidden" name="employee_id[<?= $i ?>]" value="<?= (int)$emp['id'] ?>">
                    </td>
                    <?php foreach ($components as $c):
                        $def = (float)($c['default_amount'] ?? 0) ?: round($inRow * (float)($c['rate_percent'] ?? 0) / 100); ?>
                        <td><input type="text" name="comp_amount[<?= $i ?>][<?= (int)$c['id'] ?>]" class="inp money sum_src" value="<?= e(number_format($def)) ?>" data-ignore="1"></td>
                    <?php endforeach; ?>
                    <td><input type="text" name="worked_days[<?= $i ?>]" class="inp money" value="30" style="max-width:80px"></td>
                    <td><input type="text" name="base_salary[<?= $i ?>]" class="inp money sum_src" value="<?= e(number_format($base)) ?>" style="min-width:130px"></td>
                    <td><input type="text" name="deductions[<?= $i ?>]" class="inp money" value="<?= e(number_format(0)) ?>" style="min-width:110px"></td>
                    <td class="num row-allow"><?= money($allow) ?></td>
                    <td class="num row-total">0</td>
                </tr>
            <?php $i++; endforeach; ?>
            <?php if (!$employees): ?>
                <tr><td colspan="<?= count($components) + 7 ?>" class="muted center">هنوز پرسنلی ثبت نشده است. از بخش «اشخاص و پرسنل ← کارکنان» پرسنل اضافه کنید.</td></tr>
            <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="<?= count($components) + 4 ?>">جمع کل</th>
                    <th class="num sum_all">0</th>
                    <th class="num sum_all2">0</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="card-foot">
        <div class="total-box">
            <div><span>جمع ناخالص</span><strong class="num sum_gross"><?= money(0) ?></strong></div>
            <div><span>بیمه کارمند (۷٪)</span><strong class="num ins_out"><?= money(0) ?></strong></div>
            <div><span>مالیات (۱۰٪)</span><strong class="num tax_out"><?= money(0) ?></strong></div>
            <div class="grand"><span>خالص پرداختی</span><strong class="num net_out"><?= money(0) ?></strong></div>
        </div>
        <div class="actions">
            <button type="button" class="btn soft js-add-emp">افزودن ردیف پرسنل</button>
            <button type="submit" class="btn">ثبت سند حقوق و صدور سند حسابداری</button>
            <a class="btn gray" href="<?= url('app/payroll-documents') ?>">انصراف</a>
        </div>
    </div>
</div>
</form>
<script>
(function () {
    var tbl = document.querySelector('[data-rows="emp"]');
    if (!tbl) return;
    var compCount = <?= count($components) ?>;
    function num(v) { return parseFloat(String(v).replace(/[^\d.-]/g, '')) || 0; }
    function recalc() {
        var gross = 0, idx = 0;
        tbl.querySelectorAll('tbody tr[data-row="emp"]').forEach(function (tr) {
            idx++;
            var n = idx - 1;
            tr.querySelectorAll('input[name^="employee_id"]').forEach(function (h) { h.name = 'employee_id[' + n + ']'; });
            var comp = 0, base = 0;
            tr.querySelectorAll('input[name^="comp_amount"]').forEach(function (h) { comp += num(h.value); h.name = h.name.replace(/comp_amount\[\d+]/, 'comp_amount[' + n + ']'); });
            tr.querySelectorAll('input[name^="base_salary"]').forEach(function (h) { base = num(h.value); h.name = 'base_salary[' + n + ']'; });
            tr.querySelectorAll('input[name^="worked_days"]').forEach(function (h) { h.name = 'worked_days[' + n + ']'; });
            tr.querySelectorAll('input[name^="deductions"]').forEach(function (h) { h.name = 'deductions[' + n + ']'; });
            var allow = num((tr.querySelector('.row-allow') || {}).textContent);
            var total = base + allow + comp;
            var t = tr.querySelector('.row-total');
            if (t) t.textContent = total.toLocaleString('fa-IR');
            gross += total;
        });
        var ins = gross * 0.07, tax = gross * 0.10;
        document.querySelectorAll('.sum_gross').forEach(function (el) { el.textContent = gross.toLocaleString('fa-IR'); });
        document.querySelectorAll('.ins_out').forEach(function (el) { el.textContent = ins.toLocaleString('fa-IR'); });
        document.querySelectorAll('.tax_out').forEach(function (el) { el.textContent = tax.toLocaleString('fa-IR'); });
        document.querySelectorAll('.net_out').forEach(function (el) { el.textContent = (gross - ins - tax).toLocaleString('fa-IR'); });
    }
    tbl.addEventListener('input', recalc);
    var add = document.querySelector('.js-add-emp');
    if (add) add.addEventListener('click', function () {
        var tpl = document.querySelector('tr[data-row="emp"]');
        if (!tpl) { tbl.querySelector('tbody').insertAdjacentHTML('beforeend', '<tr data-row="emp"><td></td><td><input class="inp" name="emp_name[]" placeholder="نام پرسنل"></td><td colspan="' + (compCount + 5) + '"></td><td class="num row-total">0</td></tr>'); recalc(); return; }
        var clone = tpl.cloneNode(true);
        clone.querySelectorAll('input').forEach(function (i) { if (!i.classList.contains('money')) i.value = ''; });
        tbl.querySelector('tbody').appendChild(clone); recalc();
    });
    recalc();
})();
</script>
<?= view('partials/foot') ?>