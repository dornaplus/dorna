<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public">
  <div class="auth-card" style="max-width:620px">
    <div class="steps">
      <div class="s on"><i>۱</i> موبایل</div>
      <div class="s on"><i>۲</i> کد تایید</div>
      <div class="s on"><i>۳</i> اطلاعات شخصی</div>
      <div class="s on"><i>۴</i> کسب‌وکار</div>
    </div>
    <h2>اطلاعات کسب‌وکار</h2>
    <div class="sub">با ثبت این اطلاعات، دیتابیس کاری شما با کدینگ حساب‌ها، قواعد سند خودکار و تنظیمات پیش‌فرض ساخته می‌شود.</div>
    <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="<?= url('onboarding/business') ?>">
      <?= csrf_field() ?>
      <div class="grid c2" style="gap:0 12px">
        <div class="field"><label>نام کسب‌وکار <span class="req">*</span></label>
          <input class="inp" type="text" name="name" value="<?= e(Flash::old('name')) ?>" placeholder="شرکت بازرگانی من" required></div>
        <div class="field"><label>نوع شخصیت</label>
          <select class="inp" name="legal_type">
            <option value="hoqoqi">حقوقی (شرکت/مؤسسه)</option>
            <option value="haqiqi">حقیقی (شخصی)</option>
          </select></div>
        <div class="field"><label>زمینه فعالیت</label>
          <select class="inp" name="activity_type">
            <option value="bazargardani">بازرگانی</option>
            <option value="khadamati">خدماتی</option>
            <option value="tolidi">تولیدی</option>
            <option value="forushgahi">فروشگاهی</option>
            <option value="peymankari">پیمانکاری</option>
          </select></div>
        <div class="field"><label>واحد پول</label>
          <select class="inp" name="currency_id">
            <?php foreach ($currencies as $c): ?>
              <option value="<?= $c['id'] ?>" <?= (int)$c['id'] === (int)$defaultCurrency ? 'selected' : '' ?>><?= e($c['title']) ?> (<?= e($c['symbol']) ?>)</option>
            <?php endforeach; ?>
          </select></div>
        <div class="field"><label>کد اقتصادی</label><input class="inp" type="text" name="economic_code" style="direction:ltr;text-align:left" value="<?= e(Flash::old('economic_code')) ?>"></div>
        <div class="field"><label>شناسه ملی</label><input class="inp" type="text" name="national_id" style="direction:ltr;text-align:left" value="<?= e(Flash::old('national_id')) ?>"></div>
        <div class="field"><label>شماره ثبت</label><input class="inp" type="text" name="reg_no" style="direction:ltr;text-align:left"></div>
        <div class="field"><label>تلفن</label><input class="inp" type="tel" name="phone" style="direction:ltr;text-align:left" value="<?= e(Flash::old('phone')) ?>"></div>
        <div class="field"><label>استان</label>
          <select class="inp select-search" name="province_id" id="f_province"><option value="">— انتخاب —</option>
            <?php foreach ($provinces as $pr): ?><option value="<?= $pr['id'] ?>"><?= e($pr['title']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="field"><label>شهر</label>
          <select class="inp select-search" name="city_id" id="f_city" data-province-source="f_province"><option value="">— ابتدا استان را انتخاب کنید —</option>
            <?php foreach (Database::all('SELECT id, province_id, name AS title FROM cities ORDER BY name LIMIT 500') as $ct): ?>
              <option value="<?= $ct['id'] ?>" data-prov="<?= $ct['province_id'] ?>"><?= e($ct['title']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="field field-wide"><label>نشانی</label><textarea class="inp" name="address" rows="2"><?= e(Flash::old('address')) ?></textarea></div>
      </div>
      <div class="section-title">سال مالی</div>
      <div class="grid c3" style="gap:0 12px">
        <div class="field"><label>عنوان سال مالی</label><input class="inp" type="text" name="fy_title" value="<?= e('سال مالی '.jdate($defStart, '/', false)) ?>"></div>
        <div class="field"><label>تاریخ شروع <span class="req">*</span></label><input class="inp jalali" type="text" name="fy_start" value="<?= e(jdate($defStart)) ?>" data-value="<?= e($defStart) ?>" required></div>
        <div class="field"><label>تاریخ پایان <span class="req">*</span></label><input class="inp jalali" type="text" name="fy_end" value="<?= e(jdate($defEnd)) ?>" data-value="<?= e($defEnd) ?>" required></div>
      </div>
      <button class="btn" style="width:100%;justify-content:center">ایجاد کسب‌وکار و ورود به نرم‌افزار</button>
    </form>
  </div>
</div>
<?= view('partials/public_foot') ?>
