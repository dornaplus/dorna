<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public"><div class="auth-card" style="max-width:560px;text-align:center">
  <div style="width:64px;height:64px;border-radius:20px;background:var(--ok-bg);color:var(--ok);display:grid;place-items:center;font-size:30px;margin:0 auto 12px">✓</div>
  <h2>کسب‌وکار شما آماده است</h2>
  <div class="sub">«<?= e($business['name'] ?? '') ?>» با موفقیت ایجاد شد. موارد زیر به‌صورت خودکار ساخته شدند:</div>
  <div class="card tight" style="text-align:right">
    <div class="list-row"><span>کدینگ حساب‌ها</span><b class="amt"><?= num(Database::val('SELECT COUNT(*) FROM chart_of_accounts WHERE business_id=?', [Auth::businessId()], 0)) ?> حساب</b></div>
    <div class="list-row"><span>قواعد سند خودکار</span><b class="amt"><?= num(Database::val('SELECT COUNT(*) FROM auto_entry_rules WHERE business_id=?', [Auth::businessId()], 0)) ?> قاعده</b></div>
    <div class="list-row"><span>نگاشت حساب‌ها</span><b class="amt"><?= num(Database::val('SELECT COUNT(*) FROM account_mappings WHERE business_id=?', [Auth::businessId()], 0)) ?> نگاشت</b></div>
    <div class="list-row"><span>تنظیمات</span><b class="amt"><?= num(Database::val('SELECT COUNT(*) FROM settings WHERE business_id=?', [Auth::businessId()], 0)) ?> کلید</b></div>
    <div class="list-row"><span>سال مالی</span><b class="amt"><?= e(Auth::fiscalYear()['title'] ?? '—') ?></b></div>
  </div>
  <a class="btn" href="<?= url('app') ?>" style="margin-top:14px">ورود به داشبورد</a>
</div></div>
<?= view('partials/public_foot') ?>
