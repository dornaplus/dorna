<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public"><div class="auth-card">
  <h2>فراموشی رمز عبور</h2>
  <div class="sub">شماره موبایل حساب خود را وارد کنید تا کد تایید ارسال شود.</div>
  <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="<?= url('forgot') ?>">
    <?= csrf_field() ?>
    <div class="field"><label>شماره موبایل</label><input class="inp" type="tel" name="mobile" style="direction:ltr;text-align:left" placeholder="09121234567" required autofocus></div>
    <button class="btn" style="width:100%;justify-content:center">ارسال کد تایید</button>
  </form>
  <div style="text-align:center;margin-top:14px;font-size:12.5px"><a href="<?= url('login') ?>">بازگشت به ورود</a></div>
</div></div>
<?= view('partials/public_foot') ?>
