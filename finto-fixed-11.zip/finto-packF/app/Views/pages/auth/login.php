<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public">
  <div class="auth-card">
    <div style="text-align:center;margin-bottom:14px">
      <div style="width:56px;height:56px;border-radius:18px;background:linear-gradient(135deg,var(--p-600),var(--p-400));color:#fff;display:grid;place-items:center;font-size:22px;font-weight:700;margin:0 auto 10px">فن</div>
      <h2>ورود به نرم‌افزار فینتو</h2>
      <div class="sub">سامانه حسابداری، انبارداری و فروش</div>
    </div>
    <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if (config('app')['demo_mode']): ?>
      <div class="alert info small">کاربران نمونه: <b>09120000001</b> تا <b>09120000004</b> — رمز: <b>demo1234</b></div>
    <?php endif; ?>
    <form method="post" action="<?= url('login') ?>">
      <?= csrf_field() ?>
      <div class="field"><label>موبایل یا ایمیل</label>
        <input class="inp" type="text" name="mobile" value="<?= e(Flash::old('mobile')) ?>" placeholder="09121234567" required autofocus></div>
      <div class="field"><label>کلمه عبور</label>
        <input class="inp" type="password" name="password" placeholder="••••••••" required></div>
      <button class="btn" style="width:100%;justify-content:center">ورود</button>
    </form>
    <div style="display:flex;justify-content:space-between;margin-top:14px;font-size:12.5px">
      <a href="<?= url('forgot') ?>">رمز عبورم را فراموش کرده‌ام</a>
      <a href="<?= url('register') ?>">ثبت‌نام کنید</a>
    </div>
  </div>
  <div class="small muted" style="margin-top:14px"><a href="<?= url('/') ?>">← بازگشت به صفحه اصلی</a></div>
</div>
<?= view('partials/public_foot') ?>
