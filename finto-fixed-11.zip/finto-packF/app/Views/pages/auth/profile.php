<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public">
  <div class="auth-card">
    <div class="steps">
      <div class="s on"><i>۱</i> شماره موبایل</div>
      <div class="s on"><i>۲</i> کد تایید</div>
      <div class="s on"><i>۳</i> اطلاعات شخصی</div>
      <div class="s"><i>۴</i> کسب‌وکار</div>
    </div>
    <h2>اطلاعات شخصی</h2>
    <div class="sub">شماره موبایل <b style="direction:ltr;display:inline-block"><?= e($user['mobile']) ?></b> تایید شد. اطلاعات زیر را تکمیل کنید.</div>
    <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="<?= url('onboarding/profile') ?>">
      <?= csrf_field() ?>
      <div class="grid c2" style="gap:0 12px">
        <div class="field"><label>نام <span class="req">*</span></label><input class="inp" type="text" name="first_name" value="<?= e(Flash::old('first_name')) ?>" required autofocus></div>
        <div class="field"><label>نام خانوادگی <span class="req">*</span></label><input class="inp" type="text" name="last_name" value="<?= e(Flash::old('last_name')) ?>" required></div>
      </div>
      <div class="field"><label>کد ملی <span class="req">*</span></label>
        <input class="inp" type="text" name="national_id" value="<?= e(Flash::old('national_id')) ?>" placeholder="۱۰ رقم" maxlength="10" style="direction:ltr;text-align:left" required>
        <div class="hint">کد ملی با رقم کنترل معتبرسنجی می‌شود.</div></div>
      <div class="field"><label>ایمیل (اختیاری)</label><input class="inp" type="email" name="email" value="<?= e(Flash::old('email')) ?>" style="direction:ltr;text-align:left" placeholder="you@example.com"></div>
      <button class="btn" style="width:100%;justify-content:center">ادامه → اطلاعات کسب‌وکار</button>
    </form>
  </div>
</div>
<?= view('partials/public_foot') ?>
