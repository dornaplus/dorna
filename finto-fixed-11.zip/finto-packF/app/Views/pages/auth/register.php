<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public">
  <div class="auth-card">
    <div class="steps">
      <div class="s on"><i>۱</i> شماره موبایل</div>
      <div class="s"><i>۲</i> کد تایید</div>
      <div class="s"><i>۳</i> اطلاعات شخصی</div>
      <div class="s"><i>۴</i> کسب‌وکار</div>
    </div>
    <h2>ایجاد حساب کاربری</h2>
    <div class="sub">برای شروع، شماره موبایل و رمز عبور دلخواه خود را وارد کنید.</div>
    <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <form method="post" action="<?= url('register') ?>">
      <?= csrf_field() ?>
      <div class="field"><label>شماره موبایل <span class="req">*</span></label>
        <input class="inp" type="tel" name="mobile" value="<?= e(Flash::old('mobile')) ?>" placeholder="09121234567" style="direction:ltr;text-align:left" required autofocus>
        <div class="hint">کد تایید به این شماره ارسال می‌شود.</div></div>
      <div class="field"><label>رمز عبور <span class="req">*</span></label>
        <input class="inp" type="password" name="password" placeholder="حداقل ۸ کاراکتر شامل حرف و عدد" required></div>
      <div class="field"><label>تکرار رمز عبور <span class="req">*</span></label>
        <input class="inp" type="password" name="password_confirmation" required></div>
      <label class="checkbox" style="margin-bottom:12px">
        <input type="checkbox" name="accept_terms" value="1" required>
        <span><a href="<?= url('terms') ?>" target="_blank">قوانین و شرایط استفاده</a> را می‌پذیرم.</span>
      </label>
      <button class="btn" style="width:100%;justify-content:center">ثبت‌نام و دریافت کد تایید</button>
    </form>
    <div style="text-align:center;margin-top:14px;font-size:12.5px">حساب دارید؟ <a href="<?= url('login') ?>">ورود به نرم‌افزار</a></div>
  </div>
</div>
<?= view('partials/public_foot') ?>
