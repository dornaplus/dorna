<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public"><div class="auth-card">
  <h2>تعیین رمز عبور جدید</h2>
  <div class="sub">رمز جدید را وارد کنید؛ پس از ذخیره، به‌صورت خودکار وارد می‌شوید.</div>
  <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" action="<?= url('reset') ?>">
    <?= csrf_field() ?>
    <div class="field"><label>رمز عبور جدید</label><input class="inp" type="password" name="password" required autofocus></div>
    <div class="field"><label>تکرار رمز عبور</label><input class="inp" type="password" name="password_confirmation" required></div>
    <button class="btn" style="width:100%;justify-content:center">ذخیره رمز جدید</button>
  </form>
</div></div>
<?= view('partials/public_foot') ?>
