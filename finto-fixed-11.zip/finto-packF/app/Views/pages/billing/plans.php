<?= view('partials/head', ['title' => $title]) ?>
<?php if ($current): ?>
  <div class="card">
    <div class="card-head"><h3>اشتراک فعلی</h3>
      <span class="pill st-<?= e($current['status']) ?>"><?= e(Meta::enumLabel($current['status'])) ?></span>
      <div class="grow"></div><a class="btn ghost sm" href="<?= url('app/subscription') ?>">جزئیات اشتراک</a></div>
    <div class="grid c4">
      <div><div class="muted small">پکیج</div><b><?= e($current['plan_title']) ?></b></div>
      <div><div class="muted small">اعتبار تا</div><b><?= e(jdate($current['expires_at'])) ?></b></div>
      <div><div class="muted small">اسناد مصرف‌شده</div><b><?= num($current['documents_used']) ?> / <?= num($current['documents_limit']) ?></b></div>
      <div><div class="muted small">تمدید خودکار</div><b><?= !empty($current['auto_renew']) ? 'فعال' : 'غیرفعال' ?></b></div>
    </div>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-head"><h3>پکیج‌های اشتراک</h3><span class="pill"><?= num(count($plans)) ?> پکیج</span><div class="grow"></div>
    <span class="help">پرداخت آزمایشی داخلی (بدون درگاه) — در صورت فعال بودن دوره آزمایشی، ۱۴ روز رایگان است.</span></div>
  <div class="grid c4">
    <?php foreach ($plans as $pl): ?>
      <div class="plan <?= !empty($pl['is_popular']) ? 'pop' : '' ?>">
        <?php if (!empty($pl['is_popular'])): ?><span class="badge-pop">پیشنهاد ما</span><?php endif; ?>
        <b style="color:var(--p-900)"><?= e($pl['title']) ?></b>
        <div class="price"><?= money($pl['price_amount']) ?></div>
        <div class="small muted"><?= e($pl['description'] ?? '') ?></div>
        <ul>
          <li>اسناد شامل: <?= num($pl['included_documents']) ?></li>
          <li>هر سند اضافه: <?= num($pl['extra_document_price']) ?></li>
          <li>حداکثر کاربر: <?= num($pl['max_users']) ?></li>
          <li>اعتبار پیامک: <?= num($pl['sms_credits']) ?></li>
          <?php foreach ($pl['features'] as $ft): ?>
            <li><?= e($ft['title_fa']) ?><?= !empty($ft['included']) ? '' : ' (ندارد)' ?><?= $ft['limit_value'] ? ' — '.num($ft['limit_value']) : '' ?></li>
          <?php endforeach; ?>
        </ul>
        <form method="post" action="<?= url('app/plans/'.$pl['id'].'/subscribe') ?>">
          <?= csrf_field() ?>
          <label class="checkbox" style="margin:6px 0"><input type="checkbox" name="use_trial" value="1"><span class="small">فعال‌سازی دوره آزمایشی ۱۴ روزه</span></label>
          <label class="checkbox" style="margin-bottom:6px"><input type="checkbox" name="sms_credits" value="1" checked><span class="small">افزودن اعتبار پیامک پکیج</span></label>
          <label class="checkbox" style="margin-bottom:8px"><input type="checkbox" name="auto_renew" value="1"><span class="small">تمدید خودکار</span></label>
          <input type="hidden" name="gateway" value="internal">
          <button class="btn <?= !empty($pl['is_popular']) ? '' : 'ghost' ?>" style="width:100%;justify-content:center"><?= $current && (int)$current['plan_id'] === (int)$pl['id'] ? 'تمدید این پکیج' : 'انتخاب و فعال‌سازی' ?></button>
        </form>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>مصرف اشتراک</h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/subscription') ?>">اشتراک من</a></div>
  <div class="table-wrap"><table class="tbl" style="min-width:520px">
    <thead><tr><th>تاریخ</th><th>سنجه</th><th>مقدار مصرف</th></tr></thead>
    <tbody><?php foreach ($usage as $u): ?>
      <tr><td><?= e(jdate($u['usage_date'])) ?></td><td><span class="pill"><?= e(Meta::enumLabel($u['metric'])) ?></span></td><td class="num"><?= num($u['used_value']) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$usage): ?><tr><td colspan="3" class="muted small">مصرفی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
</div>
<?= view('partials/foot') ?>
