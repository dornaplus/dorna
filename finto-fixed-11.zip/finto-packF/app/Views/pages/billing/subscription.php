<?= view('partials/head', ['title' => $title]) ?>
<?php if (!$sub): ?>
  <div class="card"><?= view('partials/empty', ['message' => 'اشتراکی برای این کسب‌وکار فعال نیست.', 'actionUrl' => url('app/plans'), 'actionText' => 'خرید پکیج']) ?></div>
<?php else: ?>
<div class="grid c4">
  <div class="kpi card"><div class="dot">★</div><div class="t">پکیج فعال</div><div class="v" style="font-size:19px"><?= e($sub['plan_title']) ?></div>
    <div class="u"><span class="pill st-<?= e($sub['status']) ?>"><?= e(Meta::enumLabel($sub['status'])) ?></span></div></div>
  <div class="kpi card green"><div class="dot">◷</div><div class="t">اعتبار تا</div><div class="v" style="font-size:19px"><?= e(jdate($sub['expires_at'])) ?></div>
    <div class="u">شروع: <?= e(jdate($sub['starts_at'])) ?></div></div>
  <div class="kpi card gold"><div class="dot">▤</div><div class="t">اسناد مصرف‌شده</div><div class="v"><?= num($docCount) ?></div>
    <div class="u">سقف: <?= num($sub['documents_limit']) ?></div></div>
  <div class="kpi card"><div class="dot">✉</div><div class="t">اعتبار پیامک پکیج</div><div class="v"><?= num($sub['sms_credits']) ?></div>
    <div class="u">حداکثر کاربر: <?= num($sub['max_users']) ?></div></div>
</div>
<div class="card" style="margin-top:12px">
  <div class="card-head"><h3>وضعیت اشتراک</h3><div class="grow"></div>
    <a class="btn" href="<?= url('app/plans') ?>">خرید / تمدید پکیج</a>
    <form method="post" action="<?= url('app/subscription/pay') ?>" style="display:inline"><?= csrf_field() ?>
      <input type="hidden" name="gateway" value="internal">
      <button class="btn success">پرداخت و تمدید یک‌ساله</button></form></div>
  <?php $used = (float)$sub['documents_limit'] > 0 ? min(100, round($docCount / (float)$sub['documents_limit'] * 100)) : 0; ?>
  <div class="chart-bars" style="height:26px;align-items:center">
    <div style="flex:1;background:var(--p-100);border-radius:10px;height:14px;overflow:hidden">
      <div style="width:<?= $used ?>%;height:100%;background:linear-gradient(90deg,var(--p-400),var(--p-700))"></div>
    </div>
  </div>
  <div class="help" style="margin-top:8px">میزان مصرف اسناد: <?= num($used) ?>٪ — تاریخ انقضا: <?= e(jdate($sub['expires_at'])) ?> — تمدید خودکار: <?= !empty($sub['auto_renew']) ? 'فعال' : 'غیرفعال' ?></div>
</div>
<?php endif; ?>

<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>پرداخت‌های اشتراک</h3><span class="pill"><?= num(count($payments)) ?></span></div>
    <div class="table-wrap"><table class="tbl" style="min-width:560px">
      <thead><tr><th>تاریخ</th><th>پکیج</th><th>مبلغ</th><th>قابل پرداخت</th><th>درگاه</th><th>وضعیت</th></tr></thead>
      <tbody><?php foreach ($payments as $p): ?>
        <tr><td><?= e(jdate($p['created_at'])) ?></td><td><?= e($p['plan_title'] ?? '—') ?></td>
          <td class="num"><?= num($p['amount']) ?></td><td class="num money-v"><?= num($p['payable_amount']) ?></td>
          <td><span class="pill"><?= e(Meta::enumLabel($p['payment_gateway'] ?? '')) ?></span></td>
          <td><span class="pill st-<?= $p['status'] === 'paid' ? 'paid' : ($p['status'] === 'pending' ? 'unpaid' : 'cancelled') ?>"><?= e(Meta::enumLabel($p['status'])) ?></span></td></tr>
      <?php endforeach; ?>
      <?php if (!$payments): ?><tr><td colspan="6" class="muted small">پرداختی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>مصرف به تفکیک سنجه</h3></div>
    <div class="table-wrap"><table class="tbl" style="min-width:420px">
      <thead><tr><th>تاریخ</th><th>سنجه</th><th>مقدار</th></tr></thead>
      <tbody><?php foreach ($usage as $u): ?>
        <tr><td><?= e(jdate($u['usage_date'])) ?></td><td><span class="pill"><?= e(Meta::enumLabel($u['metric'])) ?></span></td><td class="num"><?= num($u['used_value']) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$usage): ?><tr><td colspan="3" class="muted small">داده‌ای ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
    <div class="form-actions" style="border:none;padding:0"><a class="btn ghost sm" href="<?= url('app/subscription-payments') ?>">همه پرداخت‌های اشتراک</a></div>
  </div>
</div>
<?= view('partials/foot') ?>
