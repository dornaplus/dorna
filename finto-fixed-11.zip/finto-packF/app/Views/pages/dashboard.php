<?= view('partials/head', ['title' => $title]) ?>
<?php
$months = [];
foreach ($chart as $ym => $v) { [$y, $m] = explode('-', $ym); [$jy, $jm] = gregorian_to_jalali((int)$y, (int)$m, 1); $months[jmonth_name($jm)] = $v; }
$maxV = 1; foreach ($months as $v) $maxV = max($maxV, (float)($v['revenue'] ?? 0), (float)($v['expense'] ?? 0), (float)($v['cogs'] ?? 0));
$cashTotal = array_sum(array_map(fn($c) => (float)$c['current_balance'], $cash));
$profit = ($plSum['revenue'] ?? 0) - ($plSum['expense'] ?? 0) - ($plSum['cogs'] ?? 0);
?>
<div class="grid c5">
  <div class="kpi card"><div class="dot">◈</div><div class="t">موجودی نقد و بانک</div><div class="v"><?= num($cashTotal) ?></div><div class="u"><?= num(count($cash)) ?> حساب فعال</div></div>
  <div class="kpi card green"><div class="dot">↑</div><div class="t">طلب از مشتریان</div><div class="v"><?= num($kpi['receivable_amount'] ?? 0) ?></div><div class="u">فاکتورهای تسویه‌نشده</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">بدهی به تأمین‌کنندگان</div><div class="v"><?= num($kpi['payable_amount'] ?? 0) ?></div><div class="u">فاکتورهای خرید باز</div></div>
  <div class="kpi card gold"><div class="dot">▤</div><div class="t">ارزش موجودی انبار</div><div class="v"><?= num($kpi['inventory_value'] ?? 0) ?></div><div class="u">بر پایه بهای FIFO</div></div>
  <div class="kpi card"><div class="dot">◷</div><div class="t">فاکتورهای سررسید گذشته</div><div class="v"><?= num($kpi['overdue_invoice_count'] ?? 0) ?></div><div class="u"><?= num($kpi['due_cheques_count'] ?? 0) ?> چک نزدیک سررسید</div></div>
</div>

<div class="grid c3" style="margin-top:14px">
  <div class="card" style="grid-column:span 2">
    <div class="card-head"><h3>درآمد و هزینه <?= e($fy['title'] ?? '') ?></h3><div class="grow"></div>
      <div class="legend"><span><i style="background:var(--p-500)"></i>درآمد</span><span><i style="background:#f472b6"></i>هزینه و بهای تمام‌شده</span></div>
    </div>
    <?php if (!$months): ?>
      <div class="empty"><div class="big">◔</div><div>در این سال مالی سندی ثبت نشده است.</div></div>
    <?php else: ?>
      <div class="chart-bars">
        <?php foreach ($months as $label => $v): $inc = (float)($v['revenue'] ?? 0); $exp = (float)($v['expense'] ?? 0) + (float)($v['cogs'] ?? 0); ?>
          <div class="col" title="<?= e($label) ?>: درآمد <?= num($inc) ?> / هزینه <?= num($exp) ?>">
            <div class="bars">
              <div class="bar" style="height:<?= max(2, round($inc / $maxV * 100)) ?>%"></div>
              <div class="bar exp" style="height:<?= max(2, round($exp / $maxV * 100)) ?>%"></div>
            </div>
            <span class="lbl"><?= e($label) ?></span>
          </div>
        <?php endforeach; ?>
      </div>
      <div class="grid c3" style="margin-top:8px">
        <div><div class="muted small">جمع درآمد سال</div><div class="big-num" style="font-size:18px"><?= num($plSum['revenue'] ?? 0) ?></div></div>
        <div><div class="muted small">جمع هزینه و بهای تمام‌شده</div><div class="big-num" style="font-size:18px"><?= num(($plSum['expense'] ?? 0) + ($plSum['cogs'] ?? 0)) ?></div></div>
        <div><div class="muted small">سود (زیان) دوره</div><div class="big-num" style="font-size:18px;color:<?= $profit >= 0 ? 'var(--ok)' : 'var(--err)' ?>"><?= num($profit) ?></div></div>
      </div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>موجودی نقد و بانک</h3></div>
    <?php $sum = max(1, $cashTotal); $angle = 0; $colors = ['#7c3aed', '#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe', '#ede9fe'];
    $segs = []; $circ = 2 * M_PI * 52; ?>
    <div class="donut">
      <svg viewBox="0 0 120 120">
        <circle cx="60" cy="60" r="52" fill="none" stroke="#f3f0fb" stroke-width="14"></circle>
        <?php foreach ($cash as $i => $c): $frac = (float)$c['current_balance'] / $sum; $len = $frac * $circ; ?>
          <circle cx="60" cy="60" r="52" fill="none" stroke="<?= $colors[$i % 6] ?>" stroke-width="14"
                  stroke-dasharray="<?= round($len, 2) ?> <?= round($circ - $len, 2) ?>" stroke-dashoffset="<?= round(-$angle, 2) ?>"
                  transform="rotate(-90 60 60)"></circle>
          <?php $angle += $len; ?>
        <?php endforeach; ?>
        <text x="60" y="58" text-anchor="middle" font-size="9" fill="#8b86a3">جمع</text>
        <text x="60" y="72" text-anchor="middle" font-size="9" fill="#4c1d95"><?= num(round($cashTotal / 1000000)) ?>م</text>
      </svg>
      <div class="rows">
        <?php foreach ($cash as $i => $c): ?>
          <div class="row"><i style="display:inline-block;width:9px;height:9px;border-radius:3px;background:<?= $colors[$i % 6] ?>"></i>
            <span><?= e($c['title']) ?></span><b><?= num($c['current_balance']) ?></b></div>
        <?php endforeach; ?>
        <?php if (!$cash): ?><div class="muted small">حسابی تعریف نشده است.</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="grid c3" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>آخرین فاکتورها</h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/invoices') ?>">همه</a></div>
    <?php foreach ($latest as $inv): $pname = trim(($inv['first_name'] ?? '').' '.($inv['last_name'] ?? '').' '.($inv['company_name'] ?? '')); ?>
      <a class="list-row" href="<?= url('app/invoices/'.$inv['id']) ?>">
        <div><div class="t"><?= e($inv['invoice_no']) ?></div><div class="s"><?= e($pname) ?> · <?= e(jdate($inv['invoice_date'])) ?></div></div>
        <div class="amt"><?= num($inv['total_amount']) ?></div>
      </a>
    <?php endforeach; ?>
    <?php if (!$latest): ?><div class="muted small">فاکتوری ثبت نشده است.</div><?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>چک‌های در جریان</h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/cheques') ?>">همه</a></div>
    <?php foreach ($cheques as $c): ?>
      <a class="list-row" href="<?= url('app/cheques/'.$c['id']) ?>">
        <div><div class="t"><?= e($c['cheque_no']) ?> <span class="pill st-<?= e($c['status']) ?>"><?= e(Trade::chequeStatusTitle($c['status'])) ?></span></div>
          <div class="s"><?= e(trim(($c['first_name'] ?? '').' '.($c['last_name'] ?? '').' '.($c['company_name'] ?? ''))) ?> · سررسید <?= e(jdate($c['due_date'])) ?></div></div>
        <div class="amt"><?= num($c['amount']) ?></div>
      </a>
    <?php endforeach; ?>
    <?php if (!$cheques): ?><div class="muted small">چکی در جریان نیست.</div><?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>هشدارها</h3></div>
    <?php if ($lowStock): ?>
      <div class="small muted" style="margin-bottom:6px">کالاهای زیر نقطه سفارش:</div>
      <?php foreach ($lowStock as $ls): ?>
        <div class="list-row"><div><div class="t"><?= e($ls['product_title']) ?></div><div class="s">موجودی <?= num($ls['quantity'], 2) ?> / نقطه سفارش <?= num($ls['reorder_point'], 2) ?></div></div>
          <div class="amt" style="color:var(--err)">کمبود <?= num($ls['shortage_quantity'], 2) ?></div></div>
      <?php endforeach; ?>
    <?php endif; ?>
    <?php if ($overdue): ?>
      <div class="small muted" style="margin:8px 0 6px">فاکتورهای سررسید گذشته:</div>
      <?php foreach ($overdue as $o): ?>
        <a class="list-row" href="<?= url('app/invoices/'.$o['id']) ?>">
          <div><div class="t"><?= e($o['invoice_no']) ?></div><div class="s">سررسید <?= e(jdate($o['due_date'])) ?></div></div>
          <div class="amt" style="color:var(--err)"><?= num($o['remaining_amount']) ?></div></a>
      <?php endforeach; ?>
    <?php endif; ?>
    <?php if (!$lowStock && !$overdue): ?><div class="muted small">هشدار فعالی وجود ندارد. 👌</div><?php endif; ?>
  </div>
</div>

<div class="grid c2" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>پرفروش‌ترین کالاها</h3></div>
    <?php if (!$topProducts): ?><div class="muted small">داده‌ای برای نمایش نیست.</div><?php endif; ?>
    <?php foreach ($topProducts as $tp): ?>
      <div class="list-row"><div><div class="t"><?= e($tp['product_title']) ?></div><div class="s"><?= e($tp['product_code']) ?> · مقدار <?= num($tp['qty'], 2) ?></div></div>
        <div class="amt"><?= num($tp['amount']) ?></div></div>
    <?php endforeach; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>دسترسی سریع</h3></div>
    <div class="btn-row">
      <a class="btn" href="<?= url('app/invoices/create?type=sale') ?>">فاکتور فروش</a>
      <a class="btn ghost" href="<?= url('app/invoices/create?type=buy') ?>">فاکتور خرید</a>
      <a class="btn ghost" href="<?= url('app/receipts/create') ?>">ثبت دریافت</a>
      <a class="btn ghost" href="<?= url('app/payments/create') ?>">ثبت پرداخت</a>
      <a class="btn ghost" href="<?= url('app/journal/create') ?>">سند حسابداری</a>
      <a class="btn ghost" href="<?= url('app/inventory-documents/create') ?>">حواله انبار</a>
      <a class="btn ghost" href="<?= url('app/persons/create') ?>">شخص جدید</a>
      <a class="btn ghost" href="<?= url('app/products/create') ?>">کالای جدید</a>
      <a class="btn soft" href="<?= url('app/reports') ?>">مرکز گزارش‌ها</a>
    </div>
    <div class="help" style="margin-top:12px">سال مالی جاری: <b><?= e($fy['title'] ?? '—') ?></b> (<?= e(jdate($fy['start_date'] ?? null)) ?> تا <?= e(jdate($fy['end_date'] ?? null)) ?>) — وضعیت: <?= e(Meta::enumLabel($fy['status'] ?? 'open')) ?></div>
  </div>
</div>
<?= view('partials/foot') ?>
