<?= view('partials/public_head', ['title' => $title]) ?>
<div class="landing">
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:22px">
    <div style="width:46px;height:46px;border-radius:14px;background:linear-gradient(135deg,var(--p-600),var(--p-400));color:#fff;display:grid;place-items:center;font-size:19px;font-weight:700">فن</div>
    <div><b style="font-size:19px;color:var(--p-900)">فینتو</b><div class="small muted">نرم‌افزار حسابداری، انبارداری و فروش</div></div>
    <div class="spacer" style="flex:1"></div>
    <a class="btn ghost" href="<?= url('login') ?>">ورود</a>
    <a class="btn" href="<?= url('register') ?>">ثبت‌نام رایگان</a>
  </div>
  <div class="hero">
    <div>
      <h1>حسابداری، انبارداری و فروش کسب‌وکارتان — همه در یک نرم‌افزار</h1>
      <p>فینتو با موتور سند خودکار، مدیریت انبار مبتنی بر FIFO، خزانه‌داری و چک، حقوق و دستمزد، گزارش‌های مالی و سامانه مودیان در کنار شماست. دیتابیس نمونهٔ آماده داخل نرم‌افزار بارگذاری شده است.</p>
      <div class="btn-row" style="margin-top:16px">
        <a class="btn" href="<?= url('register') ?>">شروع کنید</a>
        <a class="btn ghost" href="<?= url('login') ?>">ورود با حساب نمونه</a>
      </div>
      <div class="chips-row" style="margin-top:16px">
        <span class="chip"><?= num($stats['tables']) ?> جدول دیتابیس</span>
        <span class="chip"><?= num($stats['views']) ?> نمای گزارش</span>
        <span class="chip"><?= num($stats['permissions']) ?> سطح دسترسی</span>
        <span class="chip">موتور سند خودکار</span>
        <span class="chip">تاریخ شمسی</span>
      </div>
    </div>
    <div class="mock">
      <div class="card tight" style="box-shadow:none;border:none;margin:0">
        <div class="grid c2" style="gap:10px">
          <div class="kpi card tight" style="margin:0"><div class="t">فروش این ماه</div><div class="v">۷۵,۶۲۵,۰۰۰</div></div>
          <div class="kpi green card tight" style="margin:0"><div class="t">دریافتنی‌ها</div><div class="v">۰</div></div>
          <div class="kpi gold card tight" style="margin:0"><div class="t">موجودی نقد و بانک</div><div class="v">۶۱۰,۶۲۰,۰۰۰</div></div>
          <div class="kpi red card tight" style="margin:0"><div class="t">بدهی به تأمین‌کننده</div><div class="v">۲۳۰,۰۰۰,۰۰۰</div></div>
        </div>
        <div class="chart-bars" style="height:150px">
          <?php foreach ([[35, 20], [50, 30], [28, 18], [62, 40], [48, 22], [70, 35]] as $i => $b): ?>
            <div class="col"><div class="bars">
              <div class="bar" style="height:<?= $b[0] ?>%"></div><div class="bar exp" style="height:<?= $b[1] ?>%"></div>
            </div><span class="lbl">ماه <?= $i + 1 ?></span></div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

  <h2 style="text-align:center;margin:26px 0 14px">امکانات نرم‌افزار</h2>
  <div class="grid c4">
    <?php foreach ([
      ['فاکتور خرید و فروش', 'فاکتور نقدی/اعتباری/چکی، برگشت، پیش‌فاکتور با صدور خودکار سند حسابداری و انبار'],
      ['انبارداری حرفه‌ای', 'کاردکس، لایه‌های FIFO، انتقال بین انبارها، ضایعات، انبارگردانی و نقطه سفارش'],
      ['دریافت و پرداخت', 'تسویه فاکتورها، علی‌الحساب، چک دریافتی/پرداختی با چرخه وصول و برگشت'],
      ['حسابداری دوطرفه', 'کدینگ درختی، اسناد دستی و خودکار، تراز افتتاحیه، بستن سال مالی و ترازنامه'],
      ['حقوق و دستمزد', 'پرسنل، اجزای حقوق، بیمه و مالیات پلکانی، سند حقوق و پرداخت آن'],
      ['گزارش‌های مالی', 'تراز آزمایشی، سود و زیان، ترازنامه، دفتر روزنامه، موجودی، مطالبات و مالیات'],
      ['چند کاربری و سطوح دسترسی', 'نقش‌ها و مجوزهای ریز، دسترسی به تفکیک کسب‌وکار و مرکز هزینه'],
      ['پشتیبان و رهگیری', 'گزارش رخدادها، پشتیبان‌گیری، مودیان و اعتبار پیامک'],
    ] as [$t, $d]): ?>
      <div class="card">
        <h3 style="color:var(--p-800);font-size:14.5px"><?= e($t) ?></h3>
        <div class="small muted"><?= e($d) ?></div>
      </div>
    <?php endforeach; ?>
  </div>

  <h2 style="text-align:center;margin:26px 0 14px">پکیج‌های اشتراک</h2>
  <div class="grid c4">
    <?php foreach ($plans as $pl): ?>
      <div class="plan <?= $pl['is_popular'] ? 'pop' : '' ?>">
        <?php if ($pl['is_popular']): ?><span class="badge-pop">پیشنهاد ما</span><?php endif; ?>
        <b style="color:var(--p-900)"><?= e($pl['title']) ?></b>
        <div class="price"><?= money($pl['price_amount']) ?></div>
        <div class="small muted"><?= e($pl['description'] ?? '') ?></div>
        <ul>
          <?php foreach ($pl['features'] as $ft): ?>
            <li><?= e($ft['title_fa']) ?><?= $ft['limit_value'] ? ' — '.num($ft['limit_value']) : '' ?></li>
          <?php endforeach; ?>
        </ul>
        <a class="btn <?= $pl['is_popular'] ? '' : 'ghost' ?>" style="justify-content:center" href="<?= url('register') ?>">انتخاب و شروع</a>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="card" style="text-align:center;margin-top:26px">
    <b>آماده‌اید شروع کنید؟</b>
    <div class="small muted" style="margin:6px 0 12px">در کمتر از ۲ دقیقه کسب‌وکارتان را با کدینگ استاندارد راه‌اندازی کنید.</div>
    <a class="btn" href="<?= url('register') ?>">ثبت‌نام و راه‌اندازی کسب‌وکار</a>
  </div>
  <div class="small muted" style="text-align:center;margin-top:16px">© <?= jdate(today()) ?> فینتو — نسخه <?= e(config('app')['version']) ?></div>
</div>
<?= view('partials/public_foot') ?>
