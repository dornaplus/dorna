<?= view('partials/head', ['title' => $title]) ?>
<?php $row = array_merge($row ?? [], $_SESSION['_old'] ?? []); $fin = array_merge($financial ?? [], $_SESSION['_old'] ?? []); ?>
<form method="post" action="<?= e($action) ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/persons') ?>">فهرست اشخاص</a></div>
    <?php foreach ($groups as $gtitle => $fields): ?>
      <div class="section-title"><?= e($gtitle) ?></div>
      <div class="form-grid">
        <?php foreach ($fields as $f): ?>
          <?= Fields::render($f, $row[$f['name']] ?? null, ['row' => $row]) ?>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>گروه‌های شخص</h3></div>
    <div class="checkgrid">
      <?php foreach ($types as $t): ?>
        <label class="checkbox"><input type="checkbox" name="person_types[]" value="<?= $t['id'] ?>" <?= in_array($t['id'], array_map('intval', (array)$selectedTypes), true) ? 'checked' : '' ?>><span><?= e($t['title_fa'] ?? $t['title'] ?? $t['slug']) ?></span></label>
      <?php endforeach; ?>
      <?php if (!$types): ?><div class="muted small">گروهی تعریف نشده است.</div><?php endif; ?>
    </div>
    <div class="hint">گروه‌های شخص تعیین می‌کنند شخص در کدام بخش‌ها (مشتری، تأمین‌کننده، پرسنل…) قابل انتخاب باشد. <a href="<?= url('app/person-types') ?>">مدیریت گروه‌ها</a></div>
  </div>

  <div class="card">
    <div class="card-head"><h3>تنظیمات مالی شخص</h3></div>
    <div class="form-grid">
      <div class="field"><label>حساب دریافتنی/پرداختنی اختصاصی</label>
        <select class="inp select-search" name="receivable_account_id"><option value="">— استفاده از حساب عمومی اشخاص —</option>
          <?php foreach (Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status="active" ORDER BY code', [Auth::businessId()]) as $a): ?>
            <option value="<?= $a['id'] ?>" <?= (string)($fin['receivable_account_id'] ?? '') === (string)$a['id'] ? 'selected' : '' ?>><?= e($a['code'].' — '.$a['title']) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>سقف اعتبار (ریال)</label><input class="inp money" type="text" name="credit_limit_amount" value="<?= e($fin['credit_limit_amount'] ?? 0) ?>"></div>
      <div class="field"><label>شرایط پرداخت پیش‌فرض</label>
        <select class="inp" name="payment_term_id"><option value="">— انتخاب —</option>
          <?php foreach (Database::all('SELECT id, title FROM payment_terms WHERE business_id=?', [Auth::businessId()]) as $pt): ?>
            <option value="<?= $pt['id'] ?>" <?= (string)($fin['payment_term_id'] ?? '') === (string)$pt['id'] ? 'selected' : '' ?>><?= e($pt['title']) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>نوع قیمت پیش‌فرض</label>
        <select class="inp" name="default_price_type_id"><option value="">— انتخاب —</option>
          <?php foreach (Database::all('SELECT id, title_fa FROM price_types WHERE business_id=? AND is_active=1', [Auth::businessId()]) as $pt): ?>
            <option value="<?= $pt['id'] ?>" <?= (string)($fin['default_price_type_id'] ?? '') === (string)$pt['id'] ? 'selected' : '' ?>><?= e($pt['title_fa']) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>درصد تخفیف پیش‌فرض</label><input class="inp" type="number" step="any" name="default_discount_percent" value="<?= e($fin['default_discount_percent'] ?? 0) ?>"></div>
      <div class="field"><label>ماهیت مانده اول دوره</label>
        <select class="inp" name="opening_balance_type">
          <?php foreach (['none','debit','credit'] as $obt): ?>
            <option value="<?= $obt ?>" <?= ($fin['opening_balance_type'] ?? 'none') === $obt ? 'selected' : '' ?>><?= e(['none' => 'ندارد', 'debit' => 'بدهکار', 'credit' => 'بستانکار'][$obt]) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>پیامک تشکر پس از فروش</label>
        <label class="switch"><input type="checkbox" name="sms_thanks_enabled" value="1" <?= !empty($fin['sms_thanks_enabled']) ? 'checked' : '' ?>><span></span></label></div>
    </div>
    <div class="form-actions">
      <button class="btn"><?= empty($row['id']) ? 'ثبت شخص' : 'ذخیره تغییرات' ?></button>
      <a class="btn gray" href="<?= url('app/persons') ?>">انصراف</a>
      <?php if (!empty($row['id'])): ?>
        <div class="spacer"></div>
        <a class="btn ghost" href="<?= url('app/invoices/create?type=sale') ?>">ثبت فاکتور فروش</a>
        <a class="btn ghost" href="<?= url('app/receipts/create?person_id='.$row['id']) ?>">ثبت دریافت</a>
      <?php endif; ?>
    </div>
  </div>
</form>
<?= view('partials/foot') ?>
