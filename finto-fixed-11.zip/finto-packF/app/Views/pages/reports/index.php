<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $groups */
$groups = $groups ?? [];
$groupIcons = [
    'مدیریتی' => 'eye', 'حسابداری' => 'gauge', 'مالی' => 'chart',
    'اشخاص' => 'users', 'خرید و فروش' => 'cart', 'انبار' => 'box',
    'خزانه' => 'bank', 'مالیات' => 'shield',
];
$groupSubs = [
    'مدیریتی' => 'شاخص‌ها و رخدادهای سیستم',
    'حسابداری' => 'اسناد، دفاتر و ترازها',
    'مالی' => 'ترازنامه، سود و زیان',
    'اشخاص' => 'مانده و ریز سنی اشخاص',
    'خرید و فروش' => 'فروش، سود و فاکتورها',
    'انبار' => 'موجودی و گردش کالا',
    'خزانه' => 'بانک، صندوق و چک‌ها',
    'مالیات' => 'گزارش‌های ارزش افزوده و فصلی',
];
?>
<div class="page-head">
    <div>
        <h2>مرکز گزارش‌ها</h2>
        <div class="muted sm"><?= num(count(Meta::reports()), 0) ?> گزارش آماده در <?= num(count($groups), 0) ?> گروه — دسترسی سریع به تمام گزارش‌های مالی، انبار، اشخاص و بانکداری</div>
    </div>
    <div class="actions">
        <a class="btn soft" href="<?= url('app/reports/trial_balance') ?>"><?= icon('gauge') ?> تراز آزمایشی</a>
        <a class="btn soft" href="<?= url('app/reports/journal_book') ?>"><?= icon('book') ?> دفتر روزنامه</a>
        <a class="btn soft" href="<?= url('app/reports/balance_sheet') ?>"><?= icon('layers') ?> ترازنامه</a>
        <a class="btn soft" href="<?= url('app/reports/income_statement') ?>"><?= icon('chart') ?> سود و زیان</a>
    </div>
</div>

<div class="grid c4">
    <div class="kpi card"><div class="dot"><?= icon('chart') ?></div><div class="t">گزارش‌های فعال</div><div class="v"><?= num(count(Meta::reports()), 0) ?></div><div class="u">گزارش</div></div>
    <div class="kpi card gold"><div class="dot"><?= icon('shield') ?></div><div class="t">گزارش‌های مالیاتی</div><div class="v">۴</div><div class="u">گزارش</div></div>
    <div class="kpi card green"><div class="dot"><?= icon('download') ?></div><div class="t">خروجی اکسل</div><div class="v">۲۵</div><div class="u">قالب CSV</div></div>
    <div class="kpi card red"><div class="dot"><?= icon('clock') ?></div><div class="t">گزارش زمان‌بندی‌شده</div><div class="v">۳</div><div class="u">مورد</div></div>
</div>

<?php foreach ($groups as $gname => $items): ?>
<div class="card">
    <div class="card-head">
        <span class="q-ic"><?= icon($groupIcons[$gname] ?? 'chart') ?></span>
        <h3><?= e($gname) ?></h3>
        <span class="muted sm"><?= e($groupSubs[$gname] ?? '') ?> — <?= num(count($items), 0) ?> گزارش</span>
    </div>
    <div class="quick-grid">
        <?php foreach ($items as $key => $r): ?>
            <a class="quick" href="<?= url('app/reports/'.$key) ?>">
                <span class="q-ic"><?= icon($groupIcons[$gname] ?? 'chart') ?></span>
                <div>
                    <b><?= e($r['title']) ?></b>
                    <span>مشاهده گزارش</span>
                </div>
            </a>
        <?php endforeach; ?>
    </div>
</div>
<?php endforeach; ?>
<?= view('partials/foot') ?>
