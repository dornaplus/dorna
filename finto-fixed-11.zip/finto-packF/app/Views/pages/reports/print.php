<?php
/** @var array $rep @var array $cols @var array $rows @var array $totals @var array $filters @var array $business @var array $filterLabels */
$rep = $rep ?? []; $cols = $cols ?? []; $rows = $rows ?? []; $totals = $totals ?? []; $business = $business ?? [];
$filterLabels = $filterLabels ?? []; $filters = $filters ?? [];
?>
<div class="print-page">
    <?php if (!empty($runError)): ?><div class="alert error"><?= e($runError) ?></div><?php endif; ?>
    <div class="print-head">
        <div>
            <h1><?= e($business['name'] ?? '') ?></h1>
            <div class="muted sm"><?= e($business['address'] ?? '') ?></div>
        </div>
        <div class="end">
            <h2><?= e($rep['title'] ?? 'گزارش') ?></h2>
            <div>تاریخ گزارش: <strong><?= e(jdate(today())) ?></strong></div>
            <?php if ($filters): ?>
                <div class="muted sm">
                    <?php $bits = []; foreach ($filters as $k => $v) { $bits[] = ($filterLabels[$k] ?? $k).': '.e($v); } echo implode(' — ', $bits); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <table class="tbl print-tbl">
        <thead>
        <tr>
            <th style="width:40px">#</th>
            <?php foreach ($cols as $c): ?><th><?= e(Schema::label($rep['view'], $c)) ?></th><?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $i => $r): ?>
            <tr>
                <td class="num"><?= $i + 1 ?></td>
                <?php foreach ($cols as $c): $m = Schema::column($rep['view'], $c) ?? ['type' => 'varchar', 'name' => $c]; ?>
                    <td class="<?= in_array($m['type'], ['decimal','double','float','int','bigint','smallint','tinyint'], true) ? 'num' : '' ?>"><?= report_cell($m, $r[$c] ?? null) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <?php if ($totals): ?>
        <tfoot>
            <tr><th class="end">جمع کل</th><?php foreach ($cols as $c): ?><th class="num"><?= isset($totals[$c]) ? money($totals[$c]) : '' ?></th><?php endforeach; ?></tr>
        </tfoot>
        <?php endif; ?>
    </table>
    <div class="signs"><div>تهیه‌کننده</div><div>مدیر مالی</div><div>مدیرعامل</div></div>
    <div class="print-foot">
        <span><?= e(config('app')['name']) ?> — <?= e($business['name'] ?? '') ?></span>
        <span><?= num(count($rows), 0) ?> ردیف — چاپ <?= e(jdate(today())) ?> <?= e(date('H:i')) ?></span>
    </div>
</div>
<script>window.print && setTimeout(function(){ window.print(); }, 400);</script>
