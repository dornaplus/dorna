<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $rep @var array $cols @var array $rows @var array $totals @var array $filters @var int $page @var int $per @var int $total @var array $filterLabels */
$rep = $rep ?? []; $cols = $cols ?? []; $rows = $rows ?? []; $totals = $totals ?? []; $filters = $filters ?? [];
$filterLabels = $filterLabels ?? []; $page = (int)($page ?? 1); $per = (int)($per ?? 50); $total = (int)($total ?? 0);
$biz = Auth::businessId();

$selectors = [
    'fiscal_year_id' => ['label' => 'سال مالی', 'rows' => Database::all('SELECT id, title FROM fiscal_years WHERE business_id=? ORDER BY id DESC', [$biz])],
    'account_id' => ['label' => 'حساب', 'rows' => Database::all('SELECT id, CONCAT(code, " — ", title) AS title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [$biz])],
    'person_id' => ['label' => 'شخص', 'rows' => Database::all('SELECT id, CONCAT(IFNULL(code,""), " — ", IFNULL(company_name, CONCAT(IFNULL(first_name,""), " ", IFNULL(last_name,"")))) AS title FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 500', [$biz])],
    'product_id' => ['label' => 'کالا/خدمت', 'rows' => Database::all('SELECT id, CONCAT(IFNULL(code,""), " — ", title) AS title FROM products WHERE business_id=? AND deleted_at IS NULL ORDER BY title LIMIT 800', [$biz])],
    'warehouse_id' => ['label' => 'انبار', 'rows' => Database::all('SELECT id, title FROM warehouses WHERE business_id=? ORDER BY title', [$biz])],
    'cash_account_id' => ['label' => 'صندوق/بانک/تنخواه', 'rows' => Database::all('SELECT id, title FROM cash_accounts WHERE business_id=? ORDER BY title', [$biz])],
    'invoice_type' => ['label' => 'نوع فاکتور', 'rows' => [
        ['id' => 'sale', 'title' => 'فروش'], ['id' => 'buy', 'title' => 'خرید'],
        ['id' => 'sale_return', 'title' => 'برگشت از فروش'], ['id' => 'buy_return', 'title' => 'برگشت از خرید'], ['id' => 'quote', 'title' => 'پیش‌فاکتور']]],
    'action' => ['label' => 'نوع رخداد', 'rows' => Database::all('SELECT DISTINCT action AS id, action AS title FROM audit_logs WHERE business_id=? ORDER BY action', [$biz])],
];

$lastCol = $cols ? end($cols) : null;
?>
<?php if (!empty($runError)): ?><div class="alert error"><?= e($runError) ?></div><?php endif; ?>
<div class="page-head">
    <div>
        <h2><?= e($rep['title'] ?? 'گزارش') ?></h2>
        <div class="muted sm"><?= e($rep['group'] ?? '') ?> — <?= num($total, 0) ?> ردیف<?= $filters ? ' (فیلتر فعال)' : '' ?></div>
    </div>
    <div class="actions">
        <a class="btn soft" href="<?= url('app/reports/'.($rep['key'] ?? '').'/print'.qs()) ?>" target="_blank"><?= icon('print') ?> چاپ</a>
        <a class="btn soft" href="<?= url('app/reports/'.($rep['key'] ?? '').'/export'.qs()) ?>"><?= icon('download') ?> خروجی CSV</a>
        <a class="btn gray" href="<?= url('app/reports') ?>">همه گزارش‌ها</a>
    </div>
</div>

<?php if (!empty($rep['filters'])): ?>
<form class="card filters" method="get" action="<?= url('app/reports/'.$rep['key']) ?>">
    <div class="grid c4">
        <?php foreach ($rep['filters'] as $f): if ($f === 'date') continue; $sel = $selectors[$f] ?? null; if (!$sel) continue; ?>
            <label class="field"><span><?= e($filterLabels[$f] ?? $f) ?></span>
                <select name="<?= e($f) ?>" class="inp select-search">
                    <option value="">همه</option>
                    <?php foreach ($sel['rows'] as $o): ?>
                        <option value="<?= e($o['id']) ?>" <?= (string)($filters[$f] ?? '') === (string)$o['id'] ? 'selected' : '' ?>><?= e($o['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        <?php endforeach; ?>
        <?php if (in_array('date', $rep['filters'], true)): ?>
            <label class="field"><span>از تاریخ</span><input type="text" name="from" class="inp jalali" dir="ltr" value="<?= e($_GET['from'] ?? '') ?>"></label>
            <label class="field"><span>تا تاریخ</span><input type="text" name="to" class="inp jalali" dir="ltr" value="<?= e($_GET['to'] ?? '') ?>"></label>
        <?php endif; ?>
        <label class="field"><span>تعداد در صفحه</span>
            <select name="per_page" class="inp">
                <?php foreach ([25, 50, 100, 200, 500] as $n): ?>
                    <option value="<?= $n ?>" <?= $per === $n ? 'selected' : '' ?>><?= num($n, 0) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </div>
    <div class="actions end">
        <button class="btn" type="submit">اعمال فیلتر</button>
        <a class="btn gray" href="<?= url('app/reports/'.$rep['key']) ?>">حذف فیلترها</a>
    </div>
</form>
<?php endif; ?>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead>
            <tr>
                <th style="width:46px">#</th>
                <?php foreach ($cols as $c): $cm = Schema::column($rep['view'], $c) ?? ['type' => 'varchar']; ?>
                    <th class="<?= in_array($cm['type'], ['decimal','double','float','int','bigint','smallint','tinyint'], true) ? 'num' : '' ?>"><?= e(Schema::label($rep['view'], $c)) ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $i => $r): ?>
                <tr>
                    <td class="num"><?= num($per * ($page - 1) + $i + 1, 0) ?></td>
                    <?php foreach ($cols as $c): $m = Schema::column($rep['view'], $c) ?? ['type' => 'varchar', 'name' => $c]; ?>
                        <td class="<?= in_array($m['type'], ['decimal','double','float','int','bigint','smallint','tinyint'], true) ? 'num' : '' ?>"><?= report_cell($m, $r[$c] ?? null) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?><tr><td colspan="<?= count($cols) + 1 ?>" class="muted center">داده‌ای برای نمایش یافت نشد.</td></tr><?php endif; ?>
            </tbody>
            <?php if ($totals): ?>
            <tfoot>
                <tr>
                    <th class="end">جمع</th>
                    <?php foreach ($cols as $c): ?><th class="num"><?= isset($totals[$c]) ? money($totals[$c]) : '' ?></th><?php endforeach; ?>
                </tr>
            </tfoot>
            <?php endif; ?>
        </table>
    </div>
    <div class="card-foot">
        <?php $page = $page; $per = $per; $total = $total; require __DIR__.'/../../partials/pagination.php'; ?>
    </div>
</div>
<?= view('partials/foot') ?>