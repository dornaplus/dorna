<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= e($action) ?>" class="card">
  <?= csrf_field() ?>
  <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <?php foreach ($groups as $groupTitle => $fields): ?>
    <div class="section-title"><?= e($groupTitle) ?></div>
    <div class="form-grid">
      <?php foreach ($fields as $f): ?>
        <?= Fields::render($f, $row[$f['name']] ?? null, ['row' => $row]) ?>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
  <div class="form-actions">
    <button class="btn" type="submit"><?= $isNew ? 'ثبت' : 'ذخیره تغییرات' ?></button>
    <a class="btn gray" href="<?= url('app/'.$m['key']) ?>">انصراف</a>
    <?php if (!$isNew): ?>
      <div class="spacer"></div>
      <span class="muted small">شناسه: <?= num($row[Schema::pk($m['table'])[0]]) ?></span>
    <?php endif; ?>
  </div>
</form>
<?= view('partials/foot') ?>
