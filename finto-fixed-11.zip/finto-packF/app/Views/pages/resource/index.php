<?= view('partials/head', ['title' => $title]) ?>
<div class="card tight">
  <form method="get" class="filters">
    <div class="field" style="flex:1;min-width:220px">
      <label>جست‌وجو</label>
      <input class="inp" type="text" name="q" value="<?= e($q) ?>" placeholder="عبارت مورد نظر…">
    </div>
    <?php foreach ($m['filters'] as $f): $col = Schema::column($m['table'], $f); ?>
      <div class="field">
        <label><?= e(Schema::label($m['table'], $f)) ?></label>
        <?php if ($col && $col['enum']): ?>
          <select class="inp" name="<?= e($f) ?>">
            <option value="">همه</option>
            <?php foreach ($col['enum'] as $v): ?><option value="<?= e($v) ?>" <?= ($activeFilters[$f] ?? '') === $v ? 'selected' : '' ?>><?= e(Meta::enumLabel($v)) ?></option><?php endforeach; ?>
          </select>
        <?php elseif ($col && Schema::fk($m['table'], $f)): $fk = Schema::fk($m['table'], $f); ?>
          <select class="inp" name="<?= e($f) ?>">
            <option value="">همه</option>
            <?php foreach (Schema::options($fk['table'], '', 300, isset(Schema::columns($fk['table'])['business_id']) ? ['business_id' => Auth::businessId()] : []) as $o): ?>
              <option value="<?= $o['id'] ?>" <?= (string)($activeFilters[$f] ?? '') === (string)$o['id'] ? 'selected' : '' ?>><?= e($o['text']) ?></option>
            <?php endforeach; ?>
          </select>
        <?php else: ?>
          <input class="inp" type="text" name="<?= e($f) ?>" value="<?= e($activeFilters[$f] ?? '') ?>">
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <?php if ($dateCol): ?>
      <div class="field"><label>از تاریخ</label><input class="inp jalali" type="text" name="from" value="<?= e($from) ?>" placeholder="۱۴۰۴/۰۱/۰۱"></div>
      <div class="field"><label>تا تاریخ</label><input class="inp jalali" type="text" name="to" value="<?= e($to) ?>" placeholder="۱۴۰۴/۱۲/۲۹"></div>
    <?php endif; ?>
    <div class="field"><button class="btn" type="submit">اعمال فیلتر</button></div>
    <div class="field"><a class="btn gray" href="<?= url('app/'.$m['key']) ?>">پاک‌کردن</a></div>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h3><?= e($m['title']) ?></h3>
    <span class="pill"><?= num($total) ?> رکورد</span>
    <div class="grow"></div>
    <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.create')): ?>
      <a class="btn" href="<?= url('app/'.$m['key'].'/create') ?>">+ تعریف <?= e($m['singular']) ?></a>
    <?php endif; ?>
    <a class="btn ghost sm" href="<?= url('app/reports/invoice_list') ?>">گزارش‌ها</a>
  </div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'رکوردی یافت نشد.'.($q !== '' ? ' عبارت جست‌وجو را تغییر دهید.' : ''), 'actionUrl' => $m['readonly'] ? null : url('app/'.$m['key'].'/create'), 'actionText' => '+ تعریف '.$m['singular']]) ?>
  <?php else: ?>
  <div class="table-wrap">
    <table class="tbl">
      <thead><tr>
        <th>#</th>
        <?php foreach ($m['list'] as $c): ?><th><?= e(Schema::label($m['table'], $c)) ?></th><?php endforeach; ?>
        <th>عملیات</th>
      </tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr>
          <td class="muted small"><?= num($r[Schema::pk($m['table'])[0]] ?? 0) ?></td>
          <?php foreach ($m['list'] as $c): ?><td><?= Fields::display($m['table'], $c, $r[$c] ?? null, $r) ?></td><?php endforeach; ?>
          <td class="acts">
            <a class="btn ghost sm" href="<?= url('app/'.$m['key'].'/'.$r[Schema::pk($m['table'])[0]]) ?>">مشاهده</a>
            <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
              <a class="btn gray sm" href="<?= url('app/'.$m['key'].'/'.$r[Schema::pk($m['table'])[0]].'/edit') ?>">ویرایش</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?= view('partials/pagination', ['page' => $page, 'per' => $perPage, 'total' => $total]) ?>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
