<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head">
    <h3><?= e($m['title']) ?> — <?= e($m['singular']) ?> #<?= num($row[Schema::pk($m['table'])[0]]) ?></h3>
    <div class="grow"></div>
    <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
      <a class="btn" href="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/edit') ?>">ویرایش</a>
    <?php endif; ?>
    <a class="btn ghost" href="<?= url('app/'.$m['key']) ?>">بازگشت به فهرست</a>
  </div>
  <div class="form-grid">
    <?php foreach (Schema::columns($m['table']) as $c => $meta): if (in_array($c, Fields::SYSTEM_COLS, true) && !in_array($c, ['journal_entry_id','inventory_doc_id'], true)) continue; ?>
      <div class="field"><label><?= e(Schema::label($m['table'], $c)) ?></label>
        <div><?= Fields::display($m['table'], $c, $row[$c] ?? null, $row) ?></div></div>
    <?php endforeach; ?>
  </div>
</div>

<?php foreach ($children as $ch): $def = $ch['def']; ?>
<div class="card">
  <div class="card-head"><h3><?= e($def['title']) ?></h3><span class="pill"><?= num(count($ch['rows'])) ?> ردیف</span><div class="grow"></div>
    <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
      <button class="btn sm" data-modal="modal-child-<?= e($def['table']) ?>" type="button">+ افزودن</button>
    <?php endif; ?>
  </div>
  <?php if (!$ch['rows']): ?>
    <div class="muted small">ردیفی ثبت نشده است.</div>
  <?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:520px">
      <thead><tr><?php foreach ($def['list'] as $c): ?><th><?= e(Schema::label($def['table'], $c)) ?></th><?php endforeach; ?>
        <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?><th>عملیات</th><?php endif; ?></tr></thead>
      <tbody>
      <?php foreach ($ch['rows'] as $cr): ?>
        <tr>
          <?php foreach ($def['list'] as $c): ?><td><?= Fields::display($def['table'], $c, $cr[$c] ?? null, $cr) ?></td><?php endforeach; ?>
          <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
            <td class="acts">
              <form method="post" data-confirm="این ردیف حذف شود؟" action="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/child/'.$def['table'].'/'.$cr[Schema::pk($def['table'])[0]].'/delete') ?>" style="display:inline">
                <?= csrf_field() ?><button class="btn danger sm">حذف</button>
              </form>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</div>
<?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
<div class="modal-backdrop" id="modal-child-<?= e($def['table']) ?>">
  <div class="modal">
    <h3>افزودن به <?= e($def['title']) ?></h3>
    <form method="post" action="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/child/'.$def['table']) ?>">
      <?= csrf_field() ?>
      <?php
        $childGroups = Fields::groups($def['table'], ['hide' => array_merge([$def['fk'], 'id', 'business_id', 'created_at', 'created_by', 'updated_at', 'updated_by', 'deleted_at', 'row_version'])]);
        $requiredFields = []; $optionalFields = [];
        foreach ($childGroups as $fields) foreach ($fields as $f) { if ($f['required']) $requiredFields[] = $f; else $optionalFields[] = $f; }
      ?>
      <div class="grid c2" style="gap:0 12px">
        <?php foreach ($requiredFields as $f): ?><?= Fields::render($f, null, []) ?><?php endforeach; ?>
      </div>
      <?php if ($optionalFields): ?>
      <details style="margin:10px 0">
        <summary class="muted small" style="cursor:pointer">سایر فیلدها</summary>
        <div class="grid c2" style="gap:0 12px">
          <?php foreach ($optionalFields as $f): ?><?= Fields::render($f, null, []) ?><?php endforeach; ?>
        </div>
      </details>
      <?php endif; ?>
      <div class="form-actions"><button class="btn" type="submit">افزودن</button><button class="btn gray" data-close type="button">بستن</button></div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php endforeach; ?>
<?= view('partials/foot') ?>
