<?php /** بخش مشترک فرم تنظیمات (کلید/مقدار) — استفاده در financial, hr, sms */ ?>
<?php foreach ($groups as $gtitle => $items): ?>
  <div class="section-title"><?= e($gtitle) ?></div>
  <div class="form-grid">
    <?php foreach ($items as $s): $key = (string)$s['setting_key']; $dec = json_decode((string)$s['value_json'], true);
      $isArr = is_array($dec); $val = $isArr ? json_encode($dec, JSON_UNESCAPED_UNICODE) : (is_bool($dec) ? ($dec ? '1' : '0') : (string)($dec ?? '')); ?>
      <div class="field">
        <label for="s_<?= e($key) ?>"><?= e($s['title_fa'] ?: $key) ?></label>
        <?php if ($isArr): ?>
          <textarea class="inp wide" name="setting[<?= e($key) ?>]" id="s_<?= e($key) ?>" rows="3" dir="ltr"><?= e($val) ?></textarea>
        <?php elseif (($s['value_type'] ?? '') === 'bool'): ?>
          <label class="switch"><input type="checkbox" name="setting[<?= e($key) ?>]" id="s_<?= e($key) ?>" value="1" <?= $val === '1' ? 'checked' : '' ?>><span></span></label>
          <input type="hidden" name="type[<?= e($key) ?>]" value="bool">
        <?php else: ?>
          <input class="inp<?= ($s['value_type'] ?? '') === 'number' ? ' money' : '' ?>" type="text" name="setting[<?= e($key) ?>]" id="s_<?= e($key) ?>" value="<?= e($val) ?>">
          <input type="hidden" name="type[<?= e($key) ?>]" value="<?= e($s['value_type'] ?: 'string') ?>">
        <?php endif; ?>
        <div class="hint"><?= e($key) ?></div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endforeach; ?>