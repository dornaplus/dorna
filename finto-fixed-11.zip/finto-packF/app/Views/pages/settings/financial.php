<?= view('partials/head', ['title' => $title]) ?>
<div class="tabs" data-tabs="#fin-scope" style="margin-bottom:12px">
  <a class="on" data-tab="#tab-settings">تنظیمات مالی</a>
  <a data-tab="#tab-mappings">نگاشت حساب‌ها</a>
  <a data-tab="#tab-taxes">مالیات‌ها</a>
  <a data-tab="#tab-years">سال‌های مالی</a>
</div>
<form method="post" action="<?= url('app/settings/financial') ?>">
  <?= csrf_field() ?>
  <div id="fin-scope">
    <div class="card" data-tab="#tab-settings" id="tab-settings">
      <div class="card-head"><h3>پارامترهای مالی و فنی</h3><span class="pill"><?= num(array_sum(array_map('count', $groups))) ?> کلید</span></div>
      <?= view('pages/settings/_settings_form', ['groups' => $groups]) ?>
    </div>

    <div class="card" data-tab="#tab-mappings" id="tab-mappings" hidden>
      <div class="card-head"><h3>نگاشت حساب‌های پیش‌فرض</h3><span class="pill"><?= num(count($mappings)) ?> نگاشت</span>
        <div class="grow"></div><a class="btn ghost sm" href="<?= url('app/account-mappings') ?>">مدیریت نگاشت‌ها</a></div>
      <div class="alert info">این نگاشت‌ها تعیین می‌کنند هر رخداد (فروش، خرید، دریافت، حقوق…) روی کدام حساب‌های دفتر کل سند بخورد.</div>
      <div class="table-wrap"><table class="tbl" style="min-width:760px">
        <thead><tr><th>کلید نگاشت</th><th>عنوان</th><th>حساب فعلی</th><th>حساب جدید</th></tr></thead>
        <tbody><?php foreach ($mappings as $m): ?>
          <tr>
            <td class="muted small" dir="ltr"><?= e($m['mapping_key']) ?></td>
            <td><?= e($m['title_fa'] ?? $m['description'] ?? $m['mapping_key']) ?></td>
            <td><?= $m['account_id'] ? e(($m['code'] ?? '').' — '.($m['account_title'] ?? '')) : '<span class="pill st-unpaid">تعیین نشده</span>' ?></td>
            <td><select class="inp select-search" name="mapping[<?= (int)$m['id'] ?>]"><option value="">— بدون تغییر —</option>
              <?php foreach ($accounts as $a): ?>
                <option value="<?= $a['id'] ?>" <?= (string)$m['account_id'] === (string)$a['id'] ? 'selected' : '' ?>><?= e($a['code'].' — '.$a['title']) ?></option>
              <?php endforeach; ?></select></td>
          </tr>
        <?php endforeach; ?></tbody></table></div>
    </div>

    <div class="card" data-tab="#tab-taxes" id="tab-taxes" hidden>
      <div class="card-head"><h3>مالیات‌ها</h3><span class="pill"><?= num(count($taxes)) ?></span><div class="grow"></div>
        <a class="btn sm" href="<?= url('app/taxes/create') ?>">+ تعریف مالیات</a></div>
      <div class="table-wrap"><table class="tbl" style="min-width:640px">
        <thead><tr><th>عنوان</th><th>نوع</th><th>نرخ</th><th>حساب</th><th>کد مودیان</th><th>وضعیت</th><th>عملیات</th></tr></thead>
        <tbody><?php foreach ($taxes as $t): ?>
          <tr><td><?= e($t['title']) ?></td><td><span class="pill"><?= e(Meta::enumLabel($t['tax_kind'])) ?></span></td>
            <td class="num"><?= num($t['rate_percent'], 2) ?>٪</td>
            <td class="muted small"><?= e(Database::val('SELECT CONCAT(code, " — ", title) FROM chart_of_accounts WHERE id=?', [$t['account_id']], '—')) ?></td>
            <td class="muted small"><?= e($t['moadian_tax_code'] ?? '—') ?></td>
            <td><span class="pill st-<?= !empty($t['is_active']) ? 'active' : 'cancelled' ?>"><?= !empty($t['is_active']) ? 'فعال' : 'غیرفعال' ?></span></td>
            <td class="acts"><a class="btn ghost sm" href="<?= url('app/taxes/'.$t['id'].'/edit') ?>">ویرایش</a></td></tr>
        <?php endforeach; ?></tbody></table></div>
    </div>

    <div class="card" data-tab="#tab-years" id="tab-years" hidden>
      <div class="card-head"><h3>سال‌های مالی</h3><span class="pill"><?= num(count($fiscalYears)) ?></span><div class="grow"></div>
        <a class="btn sm" href="<?= url('app/fiscal-years/create') ?>">+ تعریف سال مالی</a></div>
      <div class="table-wrap"><table class="tbl" style="min-width:720px">
        <thead><tr><th>عنوان</th><th>از تاریخ</th><th>تا تاریخ</th><th>وضعیت</th><th>جاری</th><th>عملیات</th></tr></thead>
        <tbody><?php foreach ($fiscalYears as $y): ?>
          <tr><td><?= e($y['title']) ?></td><td><?= e(jdate($y['start_date'])) ?></td><td><?= e(jdate($y['end_date'])) ?></td>
            <td><span class="pill st-<?= e($y['status']) ?>"><?= e(Meta::enumLabel($y['status'])) ?></span></td>
            <td><?= !empty($y['is_current']) ? '<span class="pill st-active">جاری</span>' : '—' ?></td>
            <td class="acts">
              <?php if (empty($y['is_current'])): ?>
                <form method="post" action="<?= url('app/fiscal-years/'.$y['id'].'/activate') ?>" style="display:inline"><?= csrf_field() ?><button class="btn ghost sm">انتخاب به‌عنوان جاری</button></form>
              <?php endif; ?>
              <?php if ($y['status'] === 'open'): ?>
                <form method="post" action="<?= url('app/fiscal-years/'.$y['id'].'/close') ?>" style="display:inline" data-confirm="سال مالی بسته شود؟ سود و زیان به حساب انباشته منتقل و دوره‌ها قفل می‌شوند.">
                  <?= csrf_field() ?><button class="btn danger sm">بستن سال مالی</button></form>
              <?php endif; ?>
            </td></tr>
        <?php endforeach; ?></tbody></table></div>
    </div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره تنظیمات مالی</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
