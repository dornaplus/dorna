<?= view('partials/head', ['title' => $title]) ?>
<div class="tabs" data-tabs="#hr-scope" style="margin-bottom:12px">
  <a class="on" data-tab="#tab-hr">تنظیمات حقوق و دستمزد</a>
  <a data-tab="#tab-comp">اجزای حقوق</a>
  <a data-tab="#tab-extras">مرخصی و دستگاه‌ها</a>
</div>
<form method="post" action="<?= url('app/settings/hr') ?>">
  <?= csrf_field() ?>
  <div id="hr-scope">
    <div class="card" data-tab="#tab-hr" id="tab-hr">
      <div class="card-head"><h3>پارامترهای حقوق و دستمزد</h3>
        <div class="grow"></div><a class="btn ghost sm" href="<?= url('app/payroll-documents/create') ?>">ثبت سند حقوق</a></div>
      <?= view('pages/settings/_settings_form', ['groups' => $groups]) ?>
    </div>

    <div class="card" data-tab="#tab-comp" id="tab-comp" hidden>
      <div class="card-head"><h3>اجزای حقوق</h3><span class="pill"><?= num(count($components)) ?></span></div>
      <div class="table-wrap"><table class="tbl" style="min-width:760px">
        <thead><tr><th>عنوان</th><th>نوع</th><th>روش محاسبه</th><th>درصد</th><th>مبلغ پیش‌فرض</th><th>حساب</th></tr></thead>
        <tbody><?php foreach ($components as $c): ?>
          <tr>
            <td><?= e($c['title']) ?></td>
            <td><span class="pill"><?= e(Meta::enumLabel($c['component_kind'])) ?></span></td>
            <td><?= e(Meta::enumLabel($c['calc_type'])) ?></td>
            <td><input class="inp" type="number" step="any" name="component[<?= (int)$c['id'] ?>][rate_percent]" value="<?= e($c['rate_percent']) ?>"></td>
            <td><input class="inp money" type="text" name="component[<?= (int)$c['id'] ?>][default_amount]" value="<?= e(num((float)$c['default_amount'])) ?>"></td>
            <td class="muted small"><?= e($c['account_title'] ?? '—') ?></td>
          </tr>
        <?php endforeach; ?></tbody></table></div>
      <div class="section-title">افزودن جزء جدید</div>
      <div class="form-grid">
        <div class="field"><label>عنوان</label><input class="inp" type="text" name="new_component_title"></div>
        <div class="field"><label>نوع</label><select class="inp" name="new_component_kind">
          <option value="earning">مزایا</option><option value="deduction">کسورات</option><option value="employer">سهم کارفرما</option></select></div>
        <div class="field"><label>روش محاسبه</label><select class="inp" name="new_component_calc">
          <option value="fixed">مبلغ ثابت</option><option value="percent_of_base">درصد از حقوق پایه</option><option value="percent_of_gross">درصد از جمع حقوق</option></select></div>
        <div class="field"><label>درصد</label><input class="inp" type="number" step="any" name="new_component_rate" value="0"></div>
        <div class="field"><label>مبلغ پیش‌فرض</label><input class="inp money" type="text" name="new_component_amount" value="0"></div>
        <div class="field"><label>حساب</label><select class="inp select-search" name="new_component_account"><option value="">— انتخاب —</option>
          <?php foreach ($accounts as $a): ?><option value="<?= $a['id'] ?>"><?= e($a['code'].' — '.$a['title']) ?></option><?php endforeach; ?></select></div>
      </div>
    </div>

    <div class="card" data-tab="#tab-extras" id="tab-extras" hidden>
      <div class="grid c3">
        <div>
          <div class="section-title">انواع مرخصی</div>
          <div class="table-wrap"><table class="tbl" style="min-width:240px"><thead><tr><th>عنوان</th><th>استحقاقی</th><th>سقف روز</th></tr></thead>
            <tbody><?php foreach ($leaveTypes as $l): ?><tr><td><?= e($l['title']) ?></td><td><?= !empty($l['is_paid']) ? 'بله' : 'خیر' ?></td><td class="num"><?= num($l['annual_quota_days']) ?></td></tr><?php endforeach; ?>
            <?php if (!$leaveTypes): ?><tr><td colspan="3" class="muted small">موردی ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
          <div class="form-actions" style="border:none;padding:0"><a class="btn ghost sm" href="<?= url('app/leave-types/create') ?>">+ نوع مرخصی</a></div>
        </div>
        <div>
          <div class="section-title">دستگاه‌های حضور و غیاب</div>
          <div class="table-wrap"><table class="tbl" style="min-width:280px"><thead><tr><th>عنوان</th><th>نوع</th><th>آدرس</th><th>آخرین همگام‌سازی</th></tr></thead>
            <tbody><?php foreach ($devices as $d): ?><tr><td><?= e($d['title']) ?></td><td><?= e(Meta::enumLabel($d['device_type'])) ?></td><td dir="ltr" class="muted small"><?= e($d['ip_address'] ?? '—') ?></td>
              <td class="muted small"><?= e($d['last_sync_at'] ? jdate($d['last_sync_at'], '/', true) : '—') ?></td></tr><?php endforeach; ?>
            <?php if (!$devices): ?><tr><td colspan="4" class="muted small">دستگاهی ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
          <div class="form-actions" style="border:none;padding:0"><a class="btn ghost sm" href="<?= url('app/attendance-devices/create') ?>">+ دستگاه جدید</a></div>
        </div>
        <div>
          <div class="section-title">راهنما</div>
          <div class="help">
            اجزای حقوق در سند حقوق و دستمزد استفاده می‌شوند؛ سهم کارفرما به هزینه اضافه و کسورات از خالص کسر می‌شود.
           نرخ بیمه و مالیات را می‌توانید در تب اول تغییر دهید.
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره تنظیمات حقوق</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
