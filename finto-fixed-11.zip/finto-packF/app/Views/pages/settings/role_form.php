<?= view('partials/head', ['title' => $title]) ?>
<?php $row = array_merge($row ?? [], $_SESSION['_old'] ?? []); ?>
<form method="post" action="<?= e($action) ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/roles') ?>">نقش‌ها</a>
      <button class="btn ghost sm" type="button" data-check-all="1">انتخاب همه</button>
      <button class="btn ghost sm" type="button" data-check-all="0">حذف انتخاب‌ها</button></div>
    <div class="form-grid">
      <div class="field"><label>نام نقش <span class="req">*</span></label><input class="inp" type="text" name="name" value="<?= e($row['name'] ?? '') ?>" required></div>
      <div class="field"><label>شناسه انگلیسی (slug)</label><input class="inp" type="text" name="slug" value="<?= e($row['slug'] ?? '') ?>" dir="ltr" placeholder="accountant"></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"><?= e($row['description'] ?? '') ?></textarea></div>
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h3>سطح دسترسی</h3><span class="pill"><?= num(count($selected)) ?> مجوز فعال</span>
      <div class="grow"></div><span class="help">هر ماژول شامل مشاهده، ثبت، ویرایش، حذف و مجوزهای اختصاصی است.</span></div>
    <?php foreach ($perms as $module => $items): if ($module === 'api') continue; ?>
      <div class="section-title" style="display:flex;align-items:center;gap:8px">
        <span><?= e(Meta::enumLabel($module)) ?></span>
        <label class="checkbox"><input type="checkbox" data-module-toggle="<?= e($module) ?>"><span class="small">همه</span></label>
      </div>
      <div class="checkgrid">
        <?php foreach ($items as $pm): ?>
          <label class="checkbox"><input type="checkbox" name="perms[]" value="<?= e($pm['slug']) ?>" data-module="<?= e($module) ?>" <?= in_array($pm['slug'], (array)$selected, true) ? 'checked' : '' ?>>
            <span><?= e($pm['title_fa'] ?: $pm['action']) ?> <i class="muted small" dir="ltr"><?= e($pm['action']) ?></i></span></label>
        <?php endforeach; ?>
      </div>
    <?php endforeach; ?>
    <div class="form-actions"><button class="btn success">ذخیره نقش و سطح دسترسی</button>
      <a class="btn gray" href="<?= url('app/roles') ?>">انصراف</a></div>
  </div>
</form>
<?= view('partials/foot') ?>
