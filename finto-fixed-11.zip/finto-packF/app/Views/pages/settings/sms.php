<?= view('partials/head', ['title' => $title]) ?>
<div class="grid c3">
  <div class="kpi card"><div class="dot">✉</div><div class="t">اعتبار پیامک</div><div class="v"><?= num($balance) ?></div><div class="u">پیامک قابل ارسال</div></div>
  <div class="kpi card green"><div class="dot">▤</div><div class="t">قالب‌های پیامک</div><div class="v"><?= num(count($templates)) ?></div><div class="u">قالب فعال</div></div>
  <div class="kpi card gold"><div class="dot">◔</div><div class="t">ارسال‌های اخیر</div><div class="v"><?= num(count($recent)) ?></div><div class="u">۲۰ پیام آخر</div></div>
</div>
<form method="post" action="<?= url('app/settings/sms') ?>">
  <?= csrf_field() ?>
  <div class="card" style="margin-top:12px">
    <div class="card-head"><h3>تنظیمات سامانه پیامک</h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/message-credits/create') ?>">خرید اعتبار پیامک</a>
      <a class="btn ghost sm" href="<?= url('app/message-templates/create') ?>">+ قالب پیامک</a></div>
    <?= view('pages/settings/_settings_form', ['groups' => $groups]) ?>
  </div>
  <div class="grid c2">
    <div class="card">
      <div class="card-head"><h3>قالب‌های پیامک</h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/message-templates') ?>">مدیریت</a></div>
      <div class="table-wrap"><table class="tbl" style="min-width:520px">
        <thead><tr><th>عنوان</th><th>رخداد</th><th>متن</th><th>وضعیت</th></tr></thead>
        <tbody><?php foreach ($templates as $t): ?>
          <tr><td><?= e($t['title_fa']) ?></td><td class="muted small" dir="ltr"><?= e($t['event_key']) ?></td>
            <td class="muted small"><?= e(mb_substr((string)$t['body_template'], 0, 40)) ?>…</td>
            <td><span class="pill st-<?= !empty($t['is_active']) ? 'active' : 'cancelled' ?>"><?= !empty($t['is_active']) ? 'فعال' : 'غیرفعال' ?></span></td></tr>
        <?php endforeach; ?>
        <?php if (!$templates): ?><tr><td colspan="4" class="muted small">قالبی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>قواعد اطلاع‌رسانی</h3></div>
      <div class="table-wrap"><table class="tbl" style="min-width:460px">
        <thead><tr><th>رخداد</th><th>وضعیت</th><th>روز قبل</th><th>مبلغ آستانه</th></tr></thead>
        <tbody><?php foreach ($rules as $r): ?>
          <tr><td class="muted small" dir="ltr"><?= e($r['rule_key']) ?></td>
            <td><span class="pill st-<?= !empty($r['is_enabled']) ? 'active' : 'cancelled' ?>"><?= !empty($r['is_enabled']) ? 'فعال' : 'خاموش' ?></span></td>
            <td class="muted small"><?= e(str_replace(['[', ']', '"'], '', (string)$r['days_before_json'])) ?></td>
            <td class="num"><?= num($r['threshold_amount']) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$rules): ?><tr><td colspan="4" class="muted small">قاعده‌ای ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h3>آخرین پیامک‌ها</h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/messages') ?>">همه پیامک‌ها</a></div>
    <div class="table-wrap"><table class="tbl" style="min-width:700px">
      <thead><tr><th>گیرنده</th><th>متن</th><th>کانال</th><th>وضعیت</th><th>هزینه</th><th>تاریخ</th></tr></thead>
      <tbody><?php foreach ($recent as $msg): ?>
        <tr><td dir="ltr"><?= e($msg['recipient'] ?? '—') ?></td><td class="muted small"><?= e(mb_substr((string)$msg['body'], 0, 50)) ?></td>
          <td><span class="pill"><?= e(Meta::enumLabel($msg['channel'])) ?></span></td>
          <td><span class="pill st-<?= $msg['status'] === 'sent' || $msg['status'] === 'delivered' ? 'paid' : ($msg['status'] === 'failed' ? 'cancelled' : 'unpaid') ?>"><?= e(Meta::enumLabel($msg['status'])) ?></span></td>
          <td class="num"><?= num($msg['cost_amount']) ?></td><td><?= e(jdate($msg['sent_at'] ?? $msg['created_at'], '/', true)) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$recent): ?><tr><td colspan="6" class="muted small">پیامکی ارسال نشده است.</td></tr><?php endif; ?></tbody></table></div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره تنظیمات پیامک</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
