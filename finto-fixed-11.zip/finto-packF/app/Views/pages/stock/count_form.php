<?= view('partials/head', ['title' => $title]) ?>
<div class="card tight">
  <form method="get" class="filters">
    <div class="field" style="min-width:240px"><label>انبار مورد شمارش</label>
      <select class="inp" name="warehouse_id" onchange="this.form.submit()">
        <option value="">— انتخاب انبار —</option>
        <?php foreach ($warehouses as $w): ?><option value="<?= $w['id'] ?>" <?= $warehouseId == $w['id'] ? 'selected' : '' ?>><?= e($w['title']) ?></option><?php endforeach; ?>
      </select></div>
    <div class="field"><button class="btn">نمایش اقلام انبار</button></div>
  </form>
</div>

<?php if (!$warehouseId): ?>
  <div class="card"><?= view('partials/empty', ['message' => 'برای شروع انبارگردانی، ابتدا انبار مورد نظر را انتخاب کنید.']) ?></div>
<?php else: ?>
<form method="post" action="<?= url('app/stock-counts') ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="warehouse_id" value="<?= (int)$warehouseId ?>">
  <div class="card">
    <div class="card-head"><h3>انبارگردانی انبار <?= e(Database::val('SELECT title FROM warehouses WHERE id=?', [$warehouseId], '')) ?></h3>
      <span class="pill"><?= num(count($balances)) ?> قلم</span><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/stock-counts') ?>">سوابق انبارگردانی</a></div>
    <div class="form-grid">
      <div class="field"><label>تاریخ شمارش</label><input class="inp jalali" type="text" name="count_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>"></div>
      <div class="field"><label>بازه شمارش</label>
        <select class="inp" name="period_type">
          <option value="yearly">سالانه (کامل)</option><option value="quarterly">فصلی</option>
          <option value="monthly">ماهانه</option><option value="adhoc">موردی / موردی جزئی</option>
        </select></div>
    </div>
    <?php if (!$balances): ?>
      <?= view('partials/empty', ['message' => 'در این انبار موجودی‌ای ثبت نشده است.']) ?>
    <?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:760px">
      <thead><tr><th>#</th><th>کالا</th><th>واحد</th><th>موجودی دفتری</th><th>بهای واحد</th><th>مقدار شمارش‌شده</th><th>اختلاف</th><th>ارزش اختلاف</th></tr></thead>
      <tbody>
      <?php $i = 1; foreach ($balances as $b): ?>
        <tr>
          <td class="muted small"><?= num($i++) ?></td>
          <td><b><?= e($b['product_title']) ?></b><div class="muted small"><?= e($b['product_code']) ?></div></td>
          <td><?= e($b['unit_title'] ?? '—') ?></td>
          <td class="num" data-book="<?= (float)$b['quantity'] ?>"><?= num($b['quantity'], 2) ?></td>
          <td class="num muted"><?= num($b['avg_unit_cost']) ?></td>
          <td><input class="inp" type="number" step="any" name="counted[<?= (int)$b['product_id'] ?>]" data-diff-input data-book="<?= (float)$b['quantity'] ?>" data-cost="<?= (float)($b['avg_unit_cost'] ?? 0) ?>" placeholder="<?= e(num($b['quantity'], 2)) ?>"></td>
          <td><span data-diff>—</span></td>
          <td><span data-diff-value>—</span></td>
        </tr>
      <?php endforeach; ?>
      </tbody></table></div>
    <div class="grid c3" style="margin-top:10px">
      <div><div class="muted small">اقلام دارای اختلاف</div><b><span id="sum_qty">0</span></b></div>
      <div><div class="muted small">ارزش ریالی اختلاف</div><b><span id="sum_cost">0</span></b></div>
      <div class="help">کسری‌ها و اضافه‌شدگی‌ها به‌صورت خودکار به سند انبار و سند حسابداری اصلاحی تبدیل می‌شوند.</div>
    </div>
    <div class="form-actions"><button class="btn success">ثبت انبارگردانی و صدور اسناد</button>
      <a class="btn gray" href="<?= url('app/stock-counts') ?>">انصراف</a></div>
    <?php endif; ?>
  </div>
</form>
<?php endif; ?>
<?= view('partials/foot') ?>
