<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= url('app/stock-transfers') ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3>انتقال کالا بین انبارها</h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/inventory-documents') ?>">اسناد انبار</a></div>
    <div class="form-grid">
      <div class="field"><label>از انبار (مبدأ) <span class="req">*</span></label>
        <select class="inp" name="warehouse_id" required><option value="">— انتخاب —</option>
          <?php foreach ($warehouses as $w): ?><option value="<?= $w['id'] ?>"><?= e($w['title']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>به انبار (مقصد) <span class="req">*</span></label>
        <select class="inp" name="dest_warehouse_id" required><option value="">— انتخاب —</option>
          <?php foreach ($warehouses as $w): ?><option value="<?= $w['id'] ?>"><?= e($w['title']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>تاریخ انتقال <span class="req">*</span></label>
        <input class="inp jalali" type="text" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"></textarea></div>
    </div>
    <div class="alert info">با ثبت انتقال، دو سند انبار (خروج از مبدأ و ورود به مقصد) با همان بهای تمام‌شده صادر می‌شود.</div>
  </div>
  <div class="card">
    <div class="card-head"><h3>اقلام انتقال</h3><div class="grow"></div><button class="btn sm" type="button" data-add-row="stock">+ افزودن ردیف</button></div>
    <div class="table-wrap"><table class="tbl" style="min-width:700px">
      <thead><tr><th style="width:34px">#</th><th>کالا</th><th>مقدار</th><th>توضیح</th><th></th></tr></thead>
      <tbody data-rows="stock"></tbody></table></div>
    <template id="tpl-stock">
      <td>__n__</td>
      <td><select name="line_product_id[]" class="inp select-search" required><option value="">— انتخاب کالا —</option>
        <?php foreach ($products as $pr): ?>
          <option value="<?= $pr['id'] ?>" data-unit="<?= (int)$pr['main_unit_id'] ?>" data-stock="<?= (float)$pr['stock_qty'] ?>"><?= e($pr['code'].' — '.$pr['title'].' ['.num($pr['stock_qty'], 1).']') ?></option>
        <?php endforeach; ?></select>
        <div class="hint">موجودی کل: <span data-stock>—</span></div></td>
      <td><input class="inp" type="number" step="any" min="0.0001" name="line_quantity[]" value="1" required></td>
      <td><input class="inp" type="text" name="line_desc[]"></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>
    <div class="grid c2" style="margin-top:10px">
      <div><div class="muted small">جمع مقدار انتقالی</div><b><span id="sum_qty">0</span></b></div>
      <div class="help">واحد شمارش هر کالا به‌صورت خودکار از مشخصات کالا انتخاب می‌شود.</div>
    </div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ثبت انتقال</button>
    <a class="btn gray" href="<?= url('app/stock-transfers') ?>">انصراف</a>
  </div></div>
</form>
<?= view('partials/foot') ?>
