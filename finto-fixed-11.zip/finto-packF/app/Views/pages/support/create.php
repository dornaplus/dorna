<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= url('app/tickets/create') ?>">
  <?= csrf_field() ?>
  <div class="grid c3">
    <div class="card" style="grid-column:span 2">
      <div class="card-head"><h3>ارسال تیکت پشتیبانی</h3><div class="grow"></div>
        <a class="btn ghost sm" href="<?= url('app/tickets') ?>">تیکت‌های من</a></div>
      <div class="form-grid">
        <div class="field"><label>موضوع <span class="req">*</span></label><input class="inp" type="text" name="subject" value="<?= old('subject') ?>" required></div>
        <div class="field"><label>دپارتمان</label>
          <select class="inp" name="department_id"><option value="">— انتخاب —</option>
            <?php foreach ($departments as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['title']) ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>نوع درخواست</label>
          <select class="inp" name="request_type">
            <?php foreach (['question','bug','suggestion','complaint','billing'] as $rt): ?>
              <option value="<?= $rt ?>" <?= old('request_type') === $rt ? 'selected' : '' ?>><?= e(Meta::enumLabel($rt)) ?></option>
            <?php endforeach; ?></select></div>
        <div class="field"><label>اولویت</label>
          <select class="inp" name="priority">
            <?php foreach (['low','normal','high','urgent'] as $pr): ?>
              <option value="<?= $pr ?>" <?= old('priority', 'normal') === $pr ? 'selected' : '' ?>><?= e(Meta::enumLabel($pr)) ?></option>
            <?php endforeach; ?></select></div>
        <div class="field"><label>شماره تماس</label><input class="inp" type="text" name="contact_phone" value="<?= old('contact_phone') ?>" dir="ltr"></div>
        <div class="field field-wide"><label>متن پیام <span class="req">*</span></label><textarea class="inp wide" name="message" rows="6" required><?= old('message') ?></textarea></div>
      </div>
      <div class="form-actions"><button class="btn success">ارسال تیکت</button>
        <a class="btn gray" href="<?= url('app') ?>">بازگشت</a></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>راهنما</h3></div>
      <div class="help">
        <p>پیش از ارسال تیکت، بخش <a href="<?= url('app/reports') ?>">مرکز گزارش‌ها</a> و راهنمای بخش‌ها را بررسی کنید.</p>
        <p>موضوع‌های پرتکرار: تنظیمات چاپ، سطح دسترسی، تنظیمات مالی، سامانه مودیان، پشتیبان‌گیری.</p>
        <p>ساعات پاسخ‌گویی: شنبه تا چهارشنبه ۹ تا ۱۷ — پنجشنبه ۹ تا ۱۳.</p>
      </div>
    </div>
  </div>
</form>
<?= view('partials/foot') ?>
