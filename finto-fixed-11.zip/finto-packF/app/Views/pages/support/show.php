<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head"><h3><?= e($t['subject']) ?></h3>
    <span class="pill"><?= e($t['ticket_no']) ?></span>
    <span class="pill st-<?= e($t['status']) ?>"><?= e(Meta::enumLabel($t['status'])) ?></span>
    <span class="pill"><?= e(Meta::enumLabel($t['priority'])) ?></span>
    <div class="grow"></div>
    <a class="btn ghost sm" href="<?= url('app/tickets') ?>">فهرست تیکت‌ها</a>
    <a class="btn ghost sm" href="<?= url('app/tickets/create') ?>">تیکت جدید</a></div>
  <div class="grid c4">
    <div><div class="muted small">ایجادکننده</div><b><?= e($t['creator'] ?? '—') ?></b></div>
    <div><div class="muted small">نوع درخواست</div><b><?= e(Meta::enumLabel($t['request_type'])) ?></b></div>
    <div><div class="muted small">آخرین پاسخ</div><b><?= e($t['last_reply_at'] ? jdate($t['last_reply_at'], '/', true) : '—') ?></b></div>
    <div><div class="muted small">تاریخ ایجاد</div><b><?= e(jdate($t['created_at'], '/', true)) ?></b></div>
  </div>
</div>
<div class="grid c3">
  <div class="card" style="grid-column:span 2">
    <div class="card-head"><h3>گفت‌وگو</h3><span class="pill"><?= num(count($messages)) ?> پیام</span></div>
    <?php foreach ($messages as $m): ?>
      <div class="list-row" style="align-items:flex-start">
        <div>
          <div class="t"><?= $m['sender_type'] === 'support' ? 'پشتیبانی فینتو' : e($m['full_name'] ?? 'کاربر') ?>
            <?php if (!empty($m['is_internal_note'])): ?><span class="pill st-draft">یادداشت داخلی</span><?php endif; ?></div>
          <div class="small" style="white-space:pre-wrap;margin-top:4px"><?= e($m['body']) ?></div>
          <div class="muted small" style="margin-top:4px"><?= e(jdate($m['created_at'], '/', true)) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
    <?php if (!$messages): ?><div class="muted small">پیامی وجود ندارد.</div><?php endif; ?>
    <form method="post" action="<?= url('app/tickets/'.$t['id'].'/reply') ?>" style="margin-top:12px">
      <?= csrf_field() ?>
      <div class="field field-wide"><label>پاسخ شما</label><textarea class="inp wide" name="message" rows="4" required></textarea></div>
      <div class="form-actions" style="border:none;padding:0">
        <button class="btn">ارسال پاسخ</button>
        <label class="checkbox" style="margin-inline-start:10px"><input type="checkbox" name="is_internal" value="1"><span class="small">یادداشت داخلی (فقط برای تیم)</span></label>
      </div>
    </form>
  </div>
  <div class="card">
    <div class="card-head"><h3>تغییر وضعیت</h3></div>
    <form method="post" action="<?= url('app/tickets/'.$t['id'].'/status') ?>">
      <?= csrf_field() ?>
      <div class="field"><label>وضعیت تیکت</label>
        <select class="inp" name="status">
          <?php foreach (['open','answered','pending','closed'] as $st): ?>
            <option value="<?= $st ?>" <?= $t['status'] === $st ? 'selected' : '' ?>><?= e(Meta::enumLabel($st)) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>رضایت از پاسخ (۱ تا ۵)</label>
        <select class="inp" name="satisfaction_rate"><option value="">— ثبت نشده —</option>
          <?php foreach ([5,4,3,2,1] as $r): ?><option value="<?= $r ?>" <?= (int)($t['satisfaction_rate'] ?? 0) === $r ? 'selected' : '' ?>><?= $r ?></option><?php endforeach; ?></select></div>
      <div class="form-actions" style="border:none;padding:0"><button class="btn">ذخیره وضعیت</button></div>
    </form>
    <div class="section-title">اطلاعات</div>
    <div class="help">
      شماره تماس: <b dir="ltr"><?= e($t['contact_phone'] ?? '—') ?></b><br>
      دپارتمان: <?= e(Database::val('SELECT title FROM support_departments WHERE id=?', [$t['department_id']], '—')) ?><br>
      زمان بسته‌شدن: <?= e($t['closed_at'] ? jdate($t['closed_at'], '/', true) : '—') ?>
    </div>
  </div>
</div>
<?= view('partials/foot') ?>
