<?= view('partials/public_head', ['title' => $title]) ?>
<div class="landing">
  <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px">
    <div style="width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg,var(--p-600),var(--p-400));color:#fff;display:grid;place-items:center;font-size:18px;font-weight:700">فن</div>
    <div><b style="font-size:18px;color:var(--p-900)">قوانین و شرایط استفاده</b><div class="small muted">فینتو — نرم‌افزار حسابداری، انبارداری و فروش</div></div>
    <div style="flex:1"></div>
    <a class="btn ghost" href="<?= url('register') ?>">ثبت‌نام</a>
    <a class="btn" href="<?= url('login') ?>">ورود</a>
  </div>
  <div class="card">
    <h3>۱. پذیرش قوانین</h3>
    <p class="small">با ثبت‌نام و استفاده از نرم‌افزار، شما این شرایط را می‌پذیرید. ارائه خدمات مبتنی بر پکیج انتخابی و مدت اعتبار اشتراک است.</p>
    <h3>۲. حساب کاربری</h3>
    <p class="small">شماره موبایل، نام کاربری شما است و مسئولیت حفظ رمز عبور بر عهده شماست. تمام رخدادهای کاربران در گزارش رخدادها ثبت می‌شود.</p>
    <h3>۳. داده‌ها و پشتیبان‌گیری</h3>
    <p class="small">داده‌های هر کسب‌وکار به‌صورت جداگانه نگهداری می‌شود. توصیه می‌شود از بخش پشتیبان‌گیری، نسخه پشتیبان دوره‌ای تهیه کنید.</p>
    <h3>۴. اشتراک و پرداخت</h3>
    <p class="small">پکیج‌ها بر اساس تعداد اسناد، کاربران و اعتبار پیامک تعیین می‌شوند. در صورت اتمام سهمیه، امکان تمدید یا ارتقای پکیج وجود دارد.</p>
    <h3>۵. پشتیبانی</h3>
    <p class="small">پشتیبانی از طریق ارسال تیکت انجام می‌شود و پاسخ‌گویی بر اساس اولویت تیکت و ساعت کاری است.</p>
    <h3>۶. تغییر شرایط</h3>
    <p class="small">فینتو می‌تواند شرایط را به‌روزرسانی کند؛ نسخه معتبر همیشه آخرین نسخه منتشرشده است.</p>
    <div class="form-actions"><a class="btn" href="<?= url('register') ?>">می‌پذیرم و ثبت‌نام می‌کنم</a>
      <a class="btn gray" href="<?= url('/') ?>">بازگشت به صفحه اصلی</a></div>
  </div>
</div>
<?= view('partials/public_foot') ?>
