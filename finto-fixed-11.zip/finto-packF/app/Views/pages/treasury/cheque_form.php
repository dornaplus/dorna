<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= e($action) ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3></div>
    <div class="form-grid">
      <div class="field"><label>نوع چک <span class="req">*</span></label>
        <select class="inp" name="direction" required>
          <option value="received" <?= $direction === 'received' ? 'selected' : '' ?>>دریافتی (از مشتری)</option>
          <option value="issued" <?= $direction === 'issued' ? 'selected' : '' ?>>پرداختی (به تأمین‌کننده)</option>
        </select></div>
      <div class="field"><label>شماره چک <span class="req">*</span></label><input class="inp" type="text" name="cheque_no" value="<?= e($row['cheque_no'] ?? '') ?>" required></div>
      <div class="field"><label>مبلغ <span class="req">*</span></label><input class="inp money" type="text" name="amount" value="<?= e($row ? num($row['amount']) : '') ?>" required></div>
      <div class="field"><label>بانک</label><input class="inp" type="text" name="bank_name" value="<?= e($row['bank_name'] ?? '') ?>"></div>
      <div class="field"><label>شعبه</label><input class="inp" type="text" name="branch_name" value="<?= e($row['branch_name'] ?? '') ?>"></div>
      <div class="field"><label>شماره حساب</label><input class="inp" type="text" name="account_no" value="<?= e($row['account_no'] ?? '') ?>"></div>
      <div class="field"><label>شناسه صیادی</label><input class="inp" type="text" name="sayad_id" value="<?= e($row['sayad_id'] ?? '') ?>"></div>
      <div class="field"><label>شخص</label>
        <select class="inp select-search" name="person_id"><option value="">— انتخاب —</option>
          <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '').' '.($p['company_name'] ?? '')); ?>
            <option value="<?= $p['id'] ?>" <?= ($row['person_id'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= e($p['code'].' — '.$nm) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>تاریخ صدور</label><input class="inp jalali" type="text" name="issue_date" data-value="<?= e($row['issue_date'] ?? today()) ?>"></div>
      <div class="field"><label>تاریخ سررسید</label><input class="inp jalali" type="text" name="due_date" data-value="<?= e($row['due_date'] ?? '') ?>"></div>
      <div class="field"><label>حساب بانکی مرتبط</label>
        <select class="inp" name="cash_account_id"><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= $c['id'] ?>" <?= ($row['cash_account_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"><?= e($row['description'] ?? '') ?></textarea></div>
    </div>
    <div class="form-actions"><button class="btn success">ذخیره چک</button><a class="btn gray" href="<?= url('app/cheques') ?>">انصراف</a></div>
  </div>
</form>
<?= view('partials/foot') ?>
