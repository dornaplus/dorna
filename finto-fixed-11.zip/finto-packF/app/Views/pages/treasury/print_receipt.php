<?= view('partials/public_head', ['title' => $title]) ?>
<div class="print-page">
  <div class="print-head">
    <div><div class="biz"><?= e($business['name'] ?? '') ?></div>
      <div class="print-meta"><?= e($business['address'] ?? '') ?><?php if (!empty($business['phone'])): ?><br>تلفن: <?= e($business['phone']) ?><?php endif; ?></div></div>
    <div style="text-align:left"><div style="font-size:15px;font-weight:700;color:var(--p-800)">رسید دریافت وجه</div>
      <div class="print-meta">شماره: <b><?= e($r['doc_no']) ?></b><br>تاریخ: <b><?= e(jdate($r['doc_date'])) ?></b></div></div>
  </div>
  <div class="print-meta" style="margin:10px 0">
    دریافت شد از آقای/خانم/شرکت: <b><?= e(trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '').' '.($r['company_name'] ?? ''))) ?></b><br>
    مبلغ: <b><?= num($r['amount']) ?> <?= e(Auth::currency()) ?></b>
  </div>
  <div class="words">مبلغ به حروف: <?= e($amountWords) ?></div>
  <table class="print-tbl">
    <thead><tr><th>ردیف</th><th>بابت</th><th>شماره فاکتور</th><th>مبلغ</th></tr></thead>
    <tbody>
    <?php $i = 1; foreach ($lines as $l): ?>
      <tr><td><?= num($i++) ?></td><td><?= e($l['description'] ?? 'تسویه فاکتور') ?></td><td><?= e($l['invoice_no'] ?? '—') ?></td><td><?= num($l['amount']) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$lines): ?><tr><td>۱</td><td>علی‌الحساب</td><td>—</td><td><?= num($r['amount']) ?></td></tr><?php endif; ?>
    </tbody>
  </table>
  <div class="signs"><span>امضای دریافت‌کننده</span><span>مهر و امضای شرکت</span></div>
  <div class="no-print" style="margin-top:20px;text-align:center">
    <button class="btn" onclick="window.print()">چاپ</button>
    <a class="btn gray" href="<?= url('app/receipts/'.$r['id']) ?>">بازگشت</a></div>
</div>
<?= view('partials/public_foot') ?>
