<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= url('app/transfers') ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3>ثبت انتقال وجه</h3><span class="pill">شماره بعدی: <?= e($nextNo) ?></span></div>
    <div class="form-grid">
      <div class="field"><label>از حساب <span class="req">*</span></label>
        <select class="inp" name="from_cash_account_id" required><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['title'].' (موجودی '.num($c['current_balance']).')') ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>به حساب <span class="req">*</span></label>
        <select class="inp" name="to_cash_account_id" required><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['title'].' (موجودی '.num($c['current_balance']).')') ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>مبلغ <span class="req">*</span></label><input class="inp money" type="text" name="amount" required></div>
      <div class="field"><label>کارمزد</label><input class="inp money" type="text" name="fee_amount" value="0"></div>
      <div class="field"><label>تاریخ <span class="req">*</span></label><input class="inp jalali" type="text" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      <div class="field"><label>شماره پیگیری</label><input class="inp" type="text" name="bank_reference"></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"></textarea></div>
    </div>
    <div class="form-actions"><button class="btn success">ثبت انتقال</button><a class="btn gray" href="<?= url('app/transfers') ?>">انصراف</a></div>
  </div>
</form>
<?= view('partials/foot') ?>
