<?= view('partials/head', ['title' => $title]) ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<div class="grid c2">
  <form method="post" action="<?= url('app/my-account') ?>" class="card">
    <?= csrf_field() ?>
    <div class="card-head"><h3>اطلاعات حساب کاربری</h3></div>
    <div class="form-grid">
      <div class="field"><label>نام</label><input class="inp" type="text" name="first_name" value="<?= e($first) ?>"></div>
      <div class="field"><label>نام خانوادگی</label><input class="inp" type="text" name="last_name" value="<?= e($last) ?>"></div>
      <div class="field"><label>شماره موبایل (نام کاربری)</label><input class="inp" type="text" value="<?= e($user['mobile'] ?? '') ?>" disabled></div>
      <div class="field"><label>ایمیل</label><input class="inp" type="email" name="email" value="<?= e($user['email'] ?? '') ?>"></div>
      <div class="field"><label>زبان</label>
        <select class="inp" name="preferred_language">
          <?php foreach (['fa' => 'فارسی', 'en' => 'English'] as $k => $v): ?>
            <option value="<?= $k ?>" <?= ($user['preferred_language'] ?? 'fa') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>پوسته</label>
        <select class="inp" name="theme">
          <?php foreach (['light' => 'روشن', 'dark' => 'تیره'] as $k => $v): ?>
            <option value="<?= $k ?>" <?= ($user['theme'] ?? 'light') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
          <?php endforeach; ?></select></div>
    </div>
    <div class="form-actions"><button class="btn">ذخیره اطلاعات</button>
      <a class="btn gray" href="<?= url('logout') ?>">خروج از حساب</a></div>
  </form>

  <div class="card">
    <div class="card-head"><h3>کسب‌وکارهای من</h3><span class="pill"><?= num(count($businesses)) ?></span></div>
    <?php foreach ($businesses as $b): $isActive = (int)($b['id'] ?? 0) === (int)(Auth::businessId() ?? 0); ?>
      <div class="list-row">
        <div><div class="t"><?= e($b['name']) ?> <?= $isActive ? '<span class="pill st-active">فعال</span>' : '' ?></div>
          <div class="s"><?= e($b['business_code'] ?? '') ?> · <?= e(Meta::enumLabel($b['activity_type'] ?? '')) ?> · <?= e($b['role_title'] ?? $b['role_name'] ?? '') ?></div></div>
        <?php if (!$isActive): ?>
          <form method="post" action="<?= url('app/switch-business/'.$b['id']) ?>"><?= csrf_field() ?><button class="btn ghost sm">انتخاب</button></form>
        <?php else: ?>
          <a class="btn soft sm" href="<?= url('app') ?>">ورود به نرم‌افزار</a>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    <div class="section-title">راه‌های میان‌بر</div>
    <div class="btn-row">
      <a class="btn ghost" href="<?= url('onboarding/business') ?>">ثبت کسب‌وکار جدید</a>
      <a class="btn ghost" href="<?= url('app/plans') ?>">خرید پکیج و اشتراک</a>
      <a class="btn ghost" href="<?= url('app/subscription') ?>">اشتراک من</a>
      <a class="btn ghost" href="<?= url('app/tickets/create') ?>">ارسال تیکت پشتیبانی</a>
    </div>
  </div>
</div>
<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>تغییر رمز عبور</h3></div>
    <form method="post" action="<?= url('forgot') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="mobile" value="<?= e($user['mobile'] ?? '') ?>">
      <div class="alert info">برای تغییر رمز، کد تایید به شماره موبایل شما ارسال می‌شود.</div>
      <div class="form-actions" style="border:none;padding:0"><button class="btn ghost">ارسال کد تایید و تغییر رمز</button></div>
    </form>
  </div>
  <div class="card">
    <div class="card-head"><h3>وضعیت اشتراک</h3></div>
    <div class="help">پکیج فعال و اعتبار پیامک از بخش <a href="<?= url('app/subscription') ?>">اشتراک من</a> و <a href="<?= url('app/plans') ?>">خرید پکیج</a> قابل مشاهده و تمدید است.</div>
  </div>
</div>
<?= view('partials/foot') ?>
