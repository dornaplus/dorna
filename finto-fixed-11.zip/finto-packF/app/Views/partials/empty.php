<div class="empty">
  <div class="big">◌</div>
  <div><?= e($message ?? 'رکوردی برای نمایش وجود ندارد.') ?></div>
  <?php if (!empty($actionUrl)): ?><div style="margin-top:12px"><a class="btn" href="<?= e($actionUrl) ?>"><?= e($actionText ?? 'ایجاد') ?></a></div><?php endif; ?>
</div>
