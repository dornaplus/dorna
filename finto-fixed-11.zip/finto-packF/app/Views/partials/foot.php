    </div>
  </div>
</div>
<nav class="bottom-nav">
  <a href="<?= url('app') ?>" class="<?= current_path() === url('app') ? 'on' : '' ?>"><span class="bn-ic">◧</span><span>داشبورد</span></a>
  <a href="<?= url('app/invoices') ?>" class="<?= str_contains(current_path(), 'invoice') ? 'on' : '' ?>"><span class="bn-ic">▤</span><span>فاکتور</span></a>
  <a href="<?= url('app/persons') ?>" class="<?= str_contains(current_path(), 'person') ? 'on' : '' ?>"><span class="bn-ic">👥</span><span>اشخاص</span></a>
  <a href="<?= url('app/products') ?>" class="<?= str_contains(current_path(), 'product') ? 'on' : '' ?>"><span class="bn-ic">📦</span><span>کالا</span></a>
  <button type="button" data-burger class="bn-menu"><span class="bn-ic">☰</span><span>منو</span></button>
</nav>
<div class="modal-backdrop" id="modal-biz">
  <div class="modal">
    <h3>تغییر کسب‌وکار</h3>
    <div class="small muted" style="margin-bottom:10px">کسب‌وکارهای در دسترس شما:</div>
    <?php foreach (Auth::businesses() as $b): ?>
      <form method="post" action="<?= url('app/switch-business/'.$b['id']) ?>" style="margin-bottom:6px">
        <?= csrf_field() ?>
        <button class="btn <?= Auth::businessId() == $b['id'] ? 'soft' : 'gray' ?>" style="width:100%;justify-content:space-between">
          <span><?= e($b['name']) ?></span><span class="small muted"><?= e($b['role_name'] ?? '') ?></span>
        </button>
      </form>
    <?php endforeach; ?>
    <div class="btn-row" style="margin-top:12px">
      <a class="btn ghost sm" href="<?= url('onboarding/business') ?>">+ کسب‌وکار جدید</a>
      <div class="spacer"></div>
      <button class="btn gray sm" data-close type="button">بستن</button>
    </div>
  </div>
</div>
<script src="<?= asset('app.js') ?>?v=<?= time() ?>"></script>
</body>
</html>
