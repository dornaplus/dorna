<?= Fields::render($f, $value ?? null, ['row' => $row ?? []]) ?>
