<?php
$u = Auth::user(); $biz = Auth::business(); $flash = Flash::all();
$fullName = $u['full_name'] ?? 'کاربر';
$initials = mb_substr(trim($fullName) ?: 'ک', 0, 2);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'فینتو') ?> | <?= e(config('app')['short_name']) ?></title>
<link rel="stylesheet" href="<?= asset('theme.css') ?>?v=1790695013">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>
<div class="sidebar-backdrop"></div>
<div class="toast-wrap">
  <?php foreach ($flash as $f): ?><div class="toast <?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>
</div>
<div class="app">
  <aside class="sidebar"><?= view('partials/sidebar') ?></aside>
  <div class="main">
    <header class="topbar">
      <button class="btn ghost sm" data-burger type="button">☰</button>
      <div class="page-title"><?= e($title ?? '') ?></div>
      <div class="grow"></div>
      <div class="searchbox">
        <span class="mag">⌕</span>
        <input type="text" placeholder="جست‌وجوی سریع (شخص، کالا، فاکتور، سند…)" data-quick-search>
        <div class="search-results"></div>
      </div>
      <?php if ($biz): ?>
      <div class="chip" data-modal="modal-biz" style="cursor:pointer">
        <span><?= e(mb_strimwidth($biz['name'], 0, 26, '…')) ?></span>
        <span class="muted small">▾</span>
      </div>
      <?php endif; ?>
      <div class="chip"><?= e(jdate(today())) ?></div>
      <a class="chip" href="<?= url('app/tickets/create') ?>" title="پشتیبانی">؟</a>
      <a href="<?= url('app/my-account') ?>"><div class="avatar" title="<?= e($fullName) ?>"><?= e($initials) ?></div></a>
      <a class="btn gray sm" href="<?= url('logout') ?>">خروج</a>
    </header>
    <div class="content">
      <?php if (!empty($_SESSION['_errors'])): ?>
        <div class="alert error"><b>خطاها:</b><div><?= implode('<br>', array_map('e', $_SESSION['_errors'])) ?></div></div>
        <?php unset($_SESSION['_errors']); ?>
      <?php endif; ?>
