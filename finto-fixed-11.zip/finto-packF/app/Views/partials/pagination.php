<?php
$page = (int)($page ?? 1); $per = (int)($per ?? $perPage ?? 25); $total = (int)($total ?? 0);
$pages = max(1, (int)ceil($total / max(1, $per)));
if ($pages <= 1) return;
$mk = function ($p) { $q = $_GET; $q['page'] = $p; return '?'.http_build_query($q); };
$start = max(1, $page - 3); $end = min($pages, $page + 3);
?>
<div class="pagebar">
  <span class="muted small">مجموع: <?= num($total) ?> رکورد</span>
  <?php if ($page > 1): ?><a href="<?= e($mk(1)) ?>">«</a><a href="<?= e($mk($page - 1)) ?>">‹ قبلی</a><?php endif; ?>
  <?php for ($i = $start; $i <= $end; $i++): ?>
    <?php if ($i === $page): ?><span class="cur"><?= num($i) ?></span><?php else: ?><a href="<?= e($mk($i)) ?>"><?= num($i) ?></a><?php endif; ?>
  <?php endfor; ?>
  <?php if ($page < $pages): ?><a href="<?= e($mk($page + 1)) ?>">بعدی ›</a><a href="<?= e($mk($pages)) ?>">»</a><?php endif; ?>
  <div class="spacer"></div>
  <form method="get" style="display:flex;gap:6px;align-items:center">
    <?php foreach ($_GET as $k => $v) { if (!in_array($k, ['page', 'per_page'], true)) { ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php } } ?>
    <span class="muted small">در صفحه:</span>
    <select name="per_page" class="inp" style="width:78px;padding:5px 8px" onchange="this.form.submit()">
      <?php foreach ([10, 25, 50, 100, 200] as $n): ?><option value="<?= $n ?>" <?= $n === $per ? 'selected' : '' ?>><?= $n ?></option><?php endforeach; ?>
    </select>
  </form>
</div>
