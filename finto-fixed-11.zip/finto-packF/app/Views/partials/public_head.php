<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title ?? 'فینتو') ?></title>
<link rel="stylesheet" href="<?= asset('theme.css') ?>">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>
<div class="toast-wrap">
  <?php foreach (Flash::all() as $f): ?><div class="toast <?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>
</div>
