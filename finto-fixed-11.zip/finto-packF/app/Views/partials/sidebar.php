<?php
$groups = Meta::NAV; $cur = current_path();
$biz = Auth::business();
$initials = '';
if ($biz && !empty($biz['name'])) $initials = mb_substr($biz['name'], 0, 2);
?>
<div class="brand">
  <div class="logo">فن</div>
  <div>
    <b>فینتو</b>
    <span>حسابداری و انبارداری</span>
  </div>
</div>
<?php foreach ($groups as $g): 
  $active = false; $routes = array_column($g['items'] ?? [], 'route');
  foreach ($routes as $r) { if (str_starts_with($cur, url(explode('?', $r)[0])) && explode('?', $r)[0] !== 'app' ) { $active = true; } }
  if (($g['key'] ?? '') === 'dashboard' && $cur === url('app')) $active = true;
  if (($g['key'] ?? '') === 'reports' && str_contains($cur, '/app/reports')) $active = true;
?>
  <div class="nav-group<?= $active ? ' active' : '' ?>">
    <div class="nav-head">
      <span class="ico"><?= icons($g['icon'] ?? 'dot') ?></span>
      <span><?= e($g['title']) ?></span>
      <?php if (!empty($g['items'])): ?><span class="caret">◀</span><?php endif; ?>
    </div>
    <?php if (!empty($g['items'])): ?>
      <div class="nav-sub">
        <?php if (!empty($g['route'])): ?><a class="<?= $cur === url($g['route']) ? 'on' : '' ?>" href="<?= url($g['route']) ?>"><?= e($g['title']) ?></a><?php endif; ?>
        <?php foreach ($g['items'] as $it): $link = explode('?', $it['route'])[0]; ?>
          <a class="<?= ($cur === url($it['route']) || ($cur.'?'.http_build_query($_GET) === url($it['route']) && str_contains($it['route'],'?'))) ? 'on' : '' ?>" href="<?= url($it['route']) ?>"><?= e($it['title']) ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
<div class="card tight small muted" style="margin-top:14px">
  <div>نسخه <?= e(config('app')['version']) ?></div>
  <div>دیتابیس: <?= e(config('db')['name']) ?></div>
  <div><?= e(Auth::roleSlug() ? 'نقش: '.Auth::roleSlug() : '') ?></div>
</div>
