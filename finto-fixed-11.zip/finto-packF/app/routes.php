<?php
/** جدول مسیرها — ترتیب مهم است: مسیرهای اختصاصی پیش از مسیرهای عمومی ماژول ثبت می‌شوند */
return function (Router $r): void {
    /* ── عمومی ── */
    $r->get('/', 'PageController@landing');
    $r->any('/login', 'AuthController@login');
    $r->any('/register', 'AuthController@register');
    $r->any('/verify', 'AuthController@verify');
    $r->post('/verify/resend', 'AuthController@resend');
    $r->any('/forgot', 'AuthController@forgot');
    $r->any('/reset', 'AuthController@reset');
    $r->get('/logout', 'AuthController@logout');
    $r->get('/terms', 'PageController@terms');

    /* ── راه‌اندازی اولیه ── */
    $r->any('/onboarding/profile', 'OnboardingController@profile');
    $r->any('/onboarding/business', 'OnboardingController@business');
    $r->get('/onboarding/done', 'OnboardingController@done');

    /* ── داخل نرم‌افزار ── */
    $r->get('/app', 'DashboardController@index');
    $r->get('/app/search', 'LookupController@quickSearch');
    $r->get('/app/lookup/{table}', 'LookupController@options');
    $r->any('/app/my-account', 'UserController@account');
    $r->post('/app/switch-business/{id}', 'UserController@switchBusiness');

    /* فاکتورها */
    $r->get('/app/invoices/create', 'InvoiceController@create');
    $r->post('/app/invoices', 'InvoiceController@store');
    $r->get('/app/invoices/{id}/print', 'InvoiceController@printView');
    $r->post('/app/invoices/{id}/post', 'InvoiceController@post');
    $r->post('/app/invoices/{id}/cancel', 'InvoiceController@cancel');
    $r->get('/app/invoices', 'InvoiceController@index');
    $r->get('/app/invoices/{id}', 'InvoiceController@show');

    /* دریافت / پرداخت / انتقال */
    $r->any('/app/receipts/create', 'TreasuryController@createReceipt');
    $r->post('/app/receipts', 'TreasuryController@storeReceipt');
    $r->get('/app/receipts/{id}/print', 'TreasuryController@printReceipt');
    $r->get('/app/receipts', 'TreasuryController@receipts');
    $r->get('/app/receipts/{id}', 'TreasuryController@showReceipt');
    $r->any('/app/payments/create', 'TreasuryController@createPayment');
    $r->post('/app/payments', 'TreasuryController@storePayment');
    $r->get('/app/payments/{id}/print', 'TreasuryController@printPayment');
    $r->get('/app/payments', 'TreasuryController@payments');
    $r->get('/app/payments/{id}', 'TreasuryController@showPayment');
    $r->any('/app/transfers/create', 'TreasuryController@createTransfer');
    $r->post('/app/transfers', 'TreasuryController@storeTransfer');

    /* چک‌ها */
    /* چک‌ها: فرم و ذخیره اختصاصی از طریق کنترلر عمومی CRUD (ماژول cheques) */
    $r->get('/app/cheques/create', function (array $p) { return (new ResourceController())->create(['module' => 'cheques'] + $p); });
    $r->post('/app/cheques', function (array $p) { return (new ResourceController())->store(['module' => 'cheques'] + $p); });
    $r->post('/app/cheques/{id}/event', 'TreasuryController@chequeEvent');
    $r->get('/app/cheques/{id}', 'TreasuryController@showCheque');

    /* انبار */
    $r->any('/app/inventory-documents/create', 'StockController@createDocument');
    $r->post('/app/inventory-documents', 'StockController@storeDocument');
    $r->post('/app/inventory-documents/{id}/post', 'StockController@postDocument');
    $r->any('/app/stock-transfers/create', 'StockController@createTransfer');
    $r->post('/app/stock-transfers', 'StockController@storeTransfer');
    $r->any('/app/stock-counts/create', 'StockController@createCount');
    $r->post('/app/stock-counts', 'StockController@storeCount');

    /* حسابداری */
    $r->any('/app/journal/create', 'AccountingController@createEntry');
    $r->post('/app/journal', 'AccountingController@storeEntry');
    $r->post('/app/journal/{id}/reverse', 'AccountingController@reverseEntry');
    $r->get('/app/journal/{id}/print', 'AccountingController@printEntry');
    $r->get('/app/journal', 'AccountingController@journal');
    $r->get('/app/journal/{id}', 'AccountingController@showEntry');
    $r->any('/app/opening-balances/setup', 'AccountingController@openingSetup');
    $r->post('/app/fiscal-years/{id}/close', 'AccountingController@closeYear');
    $r->post('/app/fiscal-years/{id}/activate', 'AccountingController@activateYear');
    $r->any('/app/payroll-documents/create', 'AccountingController@createPayroll');
    $r->post('/app/payroll-documents', 'AccountingController@storePayroll');
    $r->post('/app/payroll-documents/{id}/pay', 'AccountingController@payPayroll');

    /* درآمد و هزینه */
    $r->any('/app/expenses/create', 'IncexpController@createExpense');
    $r->post('/app/expenses', 'IncexpController@storeExpense');
    $r->any('/app/incomes/create', 'IncexpController@createIncome');
    $r->post('/app/incomes', 'IncexpController@storeIncome');

    /* گزارش‌ها */
    $r->get('/app/reports', 'ReportController@index');
    $r->get('/app/reports/{key}/export', 'ReportController@export');
    $r->get('/app/reports/{key}/print', 'ReportController@printView');
    $r->get('/app/reports/{key}', 'ReportController@show');

    /* تنظیمات اختصاصی */
    $r->any('/app/settings/business', 'SettingsController@business');
    $r->any('/app/settings/financial', 'SettingsController@financial');
    $r->any('/app/settings/hr', 'SettingsController@hr');
    $r->any('/app/settings/sms', 'SettingsController@sms');
    $r->post('/app/roles/{id}/permissions', 'SettingsController@savePermissions');
    $r->post('/app/users/{id}/password', 'SettingsController@resetPassword');
    $r->post('/app/users/{id}/business-role', 'SettingsController@saveUserRole');

    /* پشتیبانی */
    $r->any('/app/tickets/create', 'SupportController@create');
    $r->post('/app/tickets/{id}/reply', 'SupportController@reply');
    $r->post('/app/tickets/{id}/status', 'SupportController@status');
    $r->get('/app/tickets/{id}', 'SupportController@show');

    /* خرید پکیج */
    $r->get('/app/plans', 'BillingController@plans');
    $r->post('/app/plans/{id}/subscribe', 'BillingController@subscribe');
    $r->get('/app/subscription', 'BillingController@subscription');
    $r->post('/app/subscription/pay', 'BillingController@pay');

    /* ── مسیرهای عمومی ماژول‌ها (متادیتا-محور) ── */
    $r->get('/app/{module}/create', 'ResourceController@create');
    $r->post('/app/{module}', 'ResourceController@store');
    $r->post('/app/{module}/{id}/delete', 'ResourceController@destroy');
    $r->post('/app/{module}/{id}', 'ResourceController@update');
    $r->post('/app/{module}/{id}/child/{child}', 'ResourceController@childStore');
    $r->post('/app/{module}/{id}/child/{child}/{cid}/delete', 'ResourceController@childDestroy');
    $r->get('/app/{module}/{id}/edit', 'ResourceController@edit');
    $r->get('/app/{module}/{id}', 'ResourceController@show');
    $r->get('/app/{module}', 'ResourceController@index');
};
