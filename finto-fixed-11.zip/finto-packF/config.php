<?php
/**
 * تنظیمات نرم‌افزار حسابداری فینتو (نسخه PHP)
 * مقادیر را مطابق سرور خود تغییر دهید.
 */
return [
    'app' => [
        'name'        => 'فینتو | نرم‌افزار حسابداری و انبارداری',
        'short_name'  => 'فینتو',
        'version'     => '1.0.0',
        'url'         => '',            // مثال: https://accounting.example.com  (خالی = تشخیص خودکار)
        'timezone'    => 'Asia/Tehran',
        'locale'      => 'fa_IR',
        'debug'       => false,         // در حال توسعه true کنید (در سرور واقعی false بماند)
        'demo_mode'   => true,          // اگر true، کد تایید پیامک‌شده در صفحه نمایش داده می‌شود
        'sms_driver'  => 'log',         // log | kavenegar | ...  (در حالت log پیام در جدول messages ثبت می‌شود)
        'session_name'=> 'FINTOSESS',
        'upload_dir'  => '/uploads',
    ],
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'name'     => 'finto_accounting',
        'user'     => 'finto',
        'pass'     => 'finto123',
        'charset'  => 'utf8mb4',
        'socket'   => '',               // مثال: /var/run/mysqld/mysqld.sock
    ],
    'security' => [
        'otp_ttl_seconds'   => 300,     // اعتبار کد تایید (پنج دقیقه)
        'otp_max_attempts'  => 5,
        'otp_resend_seconds'=> 120,
        'session_ttl_days'  => 30,
        'password_min'      => 8,
        'hash_secret'       => 'change-me-finto-app-secret-2026', // برای هش کد تایید
    ],
];
