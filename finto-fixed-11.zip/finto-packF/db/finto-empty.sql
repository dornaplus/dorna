-- ════════════════════════════════════════════════════════════════════
--  نرم‌افزار حسابداری و انبارداری فینتو — فایل نصب دیتابیس
--  finto-empty.sql  |  بدون داده نمایشی (ساختار + داده مرجع)
--  -----------------------------------------------------------------
--  روش ۱ (پیشنهادی): این فایل را در نصب‌کننده وبی برنامه (install.php) استفاده کنید.
--  روش ۲ (دستی): در cPanel → phpMyAdmin یک دیتابیس بسازید، آن را انتخاب کنید،
--                 سپس Import → Choose File → همین فایل → Go
--  نیازمندی: MySQL 8.0.16+ یا MariaDB 10.5+ (به دلیل قیدهای CHECK و نماها)
--  1 دستور CREATE DATABASE/USE حذف شده است تا روی دیتابیس انتخابی شما اجرا شود.
-- ════════════════════════════════════════════════════════════════════

-- ============================================================================
--  نصب کامل دیتابیس پنل حسابداری و انبارداری فینتو — فایل یکجا
--  MySQL 8.0.16+ / MariaDB 10.5+   |   همه جداول InnoDB و utf8mb4
--  ---------------------------------------------------------------------------
--  اجرا:   mysql -u root -p < 99_install_all.sql
--  محتوا: ساخت دیتابیس → جداول → کلیدهای خارجی → نماها → داده مرجع → داده نمونه
--  برای نصب بدون داده نمونه، فایل 05_demo_data.sql را اجرا نکنید.
--  هشدار: فایل ۰۵ داده آزمایشی است و باید در محیط عملیاتی اجرا نشود.
-- ============================================================================


-- ════════════════════════ فایل 00_create_database.sql ════════════════════════

-- ============================================================================
-- ۰۰ — ساخت دیتابیس و تنظیمات پایه
-- دیتابیس پنل حسابداری و انبارداری فینتو | MySQL 8.0+ (سازگار با MariaDB 10.5+)
-- این فایل را اول اجرا کنید، سپس ۰۱ → ۰۲ → ۰۳ → ۰۴ → ۰۵
-- ============================================================================
-- نیازمندی: MySQL 8.0.16 یا بالاتر (برای پشتیبانی کامل از CHECK) — MariaDB 10.5+
-- همه جداول InnoDB و utf8mb4 هستند تا متن فارسی و ایموجی درست ذخیره شود.
-- ============================================================================

CREATE DATABASE IF NOT EXISTS `finto_accounting`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;


-- تنظیمات جلسه اجرای اسکریپت (بدون نیاز به دسترسی ادمین)
SET NAMES utf8mb4;

SET SESSION sql_mode = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

SET SESSION time_zone = '+03:30';
            -- منطقه زمانی ایران
SET SESSION foreign_key_checks = 1;
          -- کنترل صحت داده در زمان ورود داده‌های نمونه



-- ════════════════════════ فایل 01_tables.sql ════════════════════════

-- ============================================================================
-- ۰۱ — ساخت جداول (بدون کلید خارجی؛ کلیدها در فایل ۰۲ افزوده می‌شوند)
-- دیتابیس پنل حسابداری و انبارداری — MySQL 8.0 / MariaDB 10.5+
-- تولید خودکار از /tools/spec.py — همه جدول‌ها InnoDB و utf8mb4
-- ============================================================================


-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: هسته، کسب‌وکار و پیکربندی  (۱۴ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `businesses` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `name` VARCHAR(150) NOT NULL COMMENT 'نام کسب‌وکار',
  `slug` VARCHAR(80) NOT NULL COMMENT 'شناسه یکتای متنی برای URL',
  `activity_type` ENUM('bazargardani','khadamati','tolidi','forushgahi','peymankari') NOT NULL COMMENT 'نوع فعالیت',
  `legal_type` ENUM('hoqoqi','haqiqi') NOT NULL DEFAULT 'hoqoqi' COMMENT 'شخص حقوقی/حقیقی',
  `economic_code` VARCHAR(20) COMMENT 'کد اقتصادی',
  `national_id` VARCHAR(20) COMMENT 'شناسه ملی',
  `tax_file_no` VARCHAR(30) COMMENT 'شماره پرونده مالیاتی',
  `reg_no` VARCHAR(20) COMMENT 'شماره ثبت',
  `phone` VARCHAR(20) COMMENT 'تلفن ثابت',
  `mobile` VARCHAR(15) COMMENT 'موبایل مدیر',
  `email` VARCHAR(120) COMMENT 'ایمیل',
  `website` VARCHAR(150) COMMENT 'وب‌سایت',
  `country_id` SMALLINT UNSIGNED COMMENT 'کشور',
  `province_id` SMALLINT UNSIGNED COMMENT 'استان',
  `city_id` SMALLINT UNSIGNED COMMENT 'شهر',
  `postal_code` VARCHAR(15) COMMENT 'کد پستی',
  `address` VARCHAR(500) COMMENT 'نشانی کامل',
  `logo_attachment_id` BIGINT UNSIGNED COMMENT 'لوگو',
  `base_currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول پایه (تومان/ریال)',
  `timezone` VARCHAR(40) NOT NULL DEFAULT 'Asia/Tehran' COMMENT 'منطقه زمانی',
  `status` ENUM('faal','moattal','archived') NOT NULL DEFAULT 'faal' COMMENT 'وضعیت کسب‌وکار',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_businesses_slug` (`slug`),
  KEY `ix_businesses_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کسب‌وکارها — ریشه چند‌مستأجری؛ هر کسب‌وکار مجموعه‌ای مستقل از داده‌های مالی دارد.';


CREATE TABLE IF NOT EXISTS `fiscal_years` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(40) NOT NULL COMMENT 'عنوان مثال: ۱۴۰۵',
  `start_date` DATE NOT NULL COMMENT 'شروع دوره',
  `end_date` DATE NOT NULL COMMENT 'پایان دوره',
  `status` ENUM('open','closing','closed') NOT NULL DEFAULT 'open' COMMENT 'باز / در حال بستن / بسته‌شده',
  `is_current` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'سال جاری',
  `closed_at` DATETIME COMMENT 'زمان بستن',
  `closed_by` BIGINT UNSIGNED COMMENT 'کاربر بستن سال',
  `kept_earnings_account_id` BIGINT UNSIGNED COMMENT 'حساب سود انباشته/سرمایه برای انتقال نتیجه',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_fiscal_years_business_id` (`business_id`),
  CONSTRAINT `chk_fiscal_year_dates` CHECK (end_date >= start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سال‌های مالی — دوره مالی؛ همه اسناد و شماره‌گذاری‌ها به سال مالی گره می‌خورند.';


CREATE TABLE IF NOT EXISTS `fiscal_periods` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `title` VARCHAR(30) NOT NULL COMMENT 'عنوان مثال: مهر ۱۴۰۵',
  `start_date` DATE NOT NULL COMMENT 'شروع',
  `end_date` DATE NOT NULL COMMENT 'پایان',
  `status` ENUM('open','locked') NOT NULL DEFAULT 'open' COMMENT 'وضعیت قفل',
  `locked_at` DATETIME COMMENT 'زمان قفل',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_fiscal_periods_business_id` (`business_id`),
  CONSTRAINT `chk_fiscal_period_dates` CHECK (end_date >= start_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='دوره‌های مالی (ماهانه) — قفل‌کردن ماه‌ها برای منع ثبت سند در دوره بسته.';


CREATE TABLE IF NOT EXISTS `currencies` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` CHAR(3) NOT NULL COMMENT 'کد ISO مثال: IRR',
  `title` VARCHAR(30) NOT NULL COMMENT 'نام مثال: تومان',
  `symbol` VARCHAR(8) COMMENT 'نماد',
  `minor_unit` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد رقم اعشار',
  `is_base` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'پول پایه سامانه',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_currencies_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='واحدهای پول — تومان، ریال و ارزهای خارجی.';


CREATE TABLE IF NOT EXISTS `currency_rates` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'ارز',
  `rate_date` DATE NOT NULL COMMENT 'تاریخ نرخ',
  `buy_rate` DECIMAL(18,6) NOT NULL COMMENT 'نرخ خرید',
  `sell_rate` DECIMAL(18,6) NOT NULL COMMENT 'نرخ فروش',
  `avg_rate` DECIMAL(18,6) COMMENT 'نرخ میانگین',
  `source` VARCHAR(40) COMMENT 'منبع نرخ',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_currency_rates_currency_id_rate_date_business_id` (`currency_id`, `rate_date`, `business_id`),
  KEY `ix_currency_rates_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نرخ‌های ارز — نرخ تسعیر روز/میانگین برای اسناد ارزی.';


CREATE TABLE IF NOT EXISTS `settings` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `category` ENUM('financial','printing','hr','sms','backup','technical','access','integration','moadian') NOT NULL COMMENT 'دسته تنظیم',
  `setting_key` VARCHAR(80) NOT NULL COMMENT 'کلید مثال: financial.auto_journal_sale',
  `value_json` JSON NOT NULL COMMENT 'مقدار (عدد/بولین/رشته/آرایه)',
  `value_type` ENUM('bool','int','decimal','string','json','date') NOT NULL COMMENT 'نوع مقدار برای صحت‌سنجی',
  `title_fa` VARCHAR(150) COMMENT 'عنوان فارسی برای نمایش در UI',
  `group_fa` VARCHAR(80) COMMENT 'گروه نمایش',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_settings_business_id` (`business_id`),
  KEY `ix_settings_category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات — تنظیمات دسته‌بندی‌شده هر کسب‌وکار؛ نگاشت مستقیم با صفحه «تنظیمات» پنل.';


CREATE TABLE IF NOT EXISTS `number_sequences` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_type` ENUM('sale','buy','sale_return','buy_return','quote','receipt','payment','cheque','journal','hr','voucher','transfer','waste','count') NOT NULL COMMENT 'نوع سند',
  `template` VARCHAR(80) NOT NULL DEFAULT '{FY}-{SEQ}' COMMENT 'قالب مثال: {FY}-{SEQ:4}',
  `next_value` BIGINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'شماره بعدی',
  `step` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'گام افزایش',
  `reset_yearly` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'بازنشانی در سال جدید',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_number_sequences_business_id_fiscal_year_id_doc_type` (`business_id`, `fiscal_year_id`, `doc_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='شماره‌گذاری اسناد — قالب سفارشی شماره فاکتور، سند، حواله و... .';


CREATE TABLE IF NOT EXISTS `projects` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(30) COMMENT 'کد پروژه',
  `name` VARCHAR(150) NOT NULL COMMENT 'نام پروژه',
  `manager_person_id` BIGINT UNSIGNED COMMENT 'مسئول پروژه',
  `start_date` DATE COMMENT 'شروع',
  `end_date` DATE COMMENT 'پایان',
  `budget_amount` DECIMAL(18,2) COMMENT 'بودجه',
  `status` ENUM('open','closed') NOT NULL DEFAULT 'open' COMMENT 'وضعیت',
  `description` TEXT COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_projects_business_id` (`business_id`),
  KEY `ix_projects_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پروژه‌ها — تخصیص اسناد و فاکتورها به پروژه (صفحه لیست پروژه‌ها).';


CREATE TABLE IF NOT EXISTS `cost_centers` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `parent_id` BIGINT UNSIGNED COMMENT 'مرکز والد (درختی)',
  `code` VARCHAR(30) COMMENT 'کد',
  `name` VARCHAR(120) NOT NULL COMMENT 'نام مثال: هزینه اداری',
  `center_type` ENUM('expense','income','both') NOT NULL COMMENT 'نوع مرکز',
  `linked_account_id` BIGINT UNSIGNED COMMENT 'حساب پیش‌فرض',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_cost_centers_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مراکز هزینه/درآمد — تفکیک درآمد و هزینه برای گزارش‌گیری مدیریتی.';


CREATE TABLE IF NOT EXISTS `attachments` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `entity_type` VARCHAR(60) NOT NULL COMMENT 'نوع موجودیت مثال: invoice',
  `entity_id` BIGINT UNSIGNED NOT NULL COMMENT 'شناسه موجودیت',
  `file_name` VARCHAR(255) NOT NULL COMMENT 'نام اصلی فایل',
  `storage_key` VARCHAR(400) NOT NULL COMMENT 'مسیر/کلید ذخیره‌سازی',
  `mime_type` VARCHAR(80) NOT NULL COMMENT 'نوع MIME',
  `size_bytes` BIGINT UNSIGNED NOT NULL COMMENT 'حجم',
  `checksum` CHAR(64) COMMENT 'SHA-256 برای تشخیص تکراری',
  `uploaded_by` BIGINT UNSIGNED COMMENT 'بارگذاری‌کننده',
  `is_public` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قابل مشاهده برای مشتری در لینک عمومی',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_attachments_business_id` (`business_id`),
  KEY `ix_attachments_entity_type` (`entity_type`),
  KEY `ix_attachments_entity_id` (`entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پیوست‌ها — فایل‌های پیوست همه بخش‌ها (فاکتور، تیکت، شخص، کالا، سند).';


CREATE TABLE IF NOT EXISTS `audit_logs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  `action` ENUM('insert','update','delete','login','logout','print','send','submit','cancel','lock','unlock','export') NOT NULL COMMENT 'نوع عملیات',
  `entity_type` VARCHAR(60) COMMENT 'موجودیت',
  `entity_id` BIGINT UNSIGNED COMMENT 'شناسه رکورد',
  `before_json` JSON COMMENT 'مقدار قبل',
  `after_json` JSON COMMENT 'مقدار بعد',
  `ip_address` VARBINARY(16) COMMENT 'IP (IPv4/IPv6)',
  `user_agent` VARCHAR(255) COMMENT 'مرورگر/دستگاه',
  `device_type` ENUM('web','mobile','api','panel') COMMENT 'کانال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_audit_logs_user_id` (`user_id`),
  KEY `ix_audit_logs_action` (`action`),
  KEY `ix_audit_logs_entity_type` (`entity_type`),
  KEY `ix_audit_logs_business_id_entity_type_entity_id` (`business_id`, `entity_type`, `entity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='لاگ کاربران و تغییرات — ثبت همه تغییرات مهم + لاگ ورود/خروج (صفحه «لاگ کاربران»).';


CREATE TABLE IF NOT EXISTS `countries` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `name` VARCHAR(80) NOT NULL COMMENT 'نام',
  `iso2` CHAR(2) COMMENT 'کد دو حرفی',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_countries_iso2` (`iso2`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کشورها — جدول مرجع کشور.';


CREATE TABLE IF NOT EXISTS `provinces` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `country_id` SMALLINT UNSIGNED NOT NULL COMMENT 'کشور',
  `name` VARCHAR(80) NOT NULL COMMENT 'نام',
  PRIMARY KEY (`id`),
  KEY `ix_provinces_country_id` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='استان‌ها — جدول مرجع استان.';


CREATE TABLE IF NOT EXISTS `cities` (
  `id` SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `province_id` SMALLINT UNSIGNED NOT NULL COMMENT 'استان',
  `name` VARCHAR(80) NOT NULL COMMENT 'نام',
  PRIMARY KEY (`id`),
  KEY `ix_cities_province_id` (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='شهرها — جدول مرجع شهر.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: کاربران، نقش‌ها و امنیت  (۱۱ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `users` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `full_name` VARCHAR(120) NOT NULL COMMENT 'نام و نام خانوادگی',
  `mobile` VARCHAR(15) COMMENT 'موبایل (نام کاربری اصلی)',
  `email` VARCHAR(120) COMMENT 'ایمیل',
  `password_hash` VARCHAR(255) NOT NULL COMMENT 'هش کلمه عبور (bcrypt/argon2)',
  `password_changed_at` DATETIME COMMENT 'زمان آخرین تغییر رمز',
  `avatar_attachment_id` BIGINT UNSIGNED COMMENT 'تصویر پروفایل',
  `two_factor_enabled` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ورود دو مرحله‌ای پیامکی',
  `preferred_language` ENUM('fa','en') NOT NULL DEFAULT 'fa' COMMENT 'زبان',
  `theme` ENUM('light','dark','purple') NOT NULL DEFAULT 'purple' COMMENT 'پوسته',
  `status` ENUM('active','inactive','blocked') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `last_login_at` DATETIME COMMENT 'آخرین ورود',
  `failed_attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تلاش‌های ناموفق متوالی',
  `locked_until` DATETIME COMMENT 'قفل موقت حساب',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_users_mobile` (`mobile`),
  UNIQUE KEY `k_users_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کاربران — کاربران سامانه؛ ورود با موبایل یا ایمیل (صفحه auth).';


CREATE TABLE IF NOT EXISTS `roles` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `name` VARCHAR(60) NOT NULL COMMENT 'نام نقش',
  `slug` VARCHAR(40) NOT NULL COMMENT 'شناسه یکتا مثال: accountant',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نقش سیستمی غیرقابل حذف',
  `description` VARCHAR(255) COMMENT 'توضیح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_roles_business_id_slug` (`business_id`, `slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نقش‌ها — مدیر کل، حسابدار، انباردار، بازاریاب، پشتیبان فروش.';


CREATE TABLE IF NOT EXISTS `permissions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `module` VARCHAR(40) NOT NULL COMMENT 'ماژول مثال: invoices',
  `action` ENUM('view','create','edit','delete','print','export','approve','lock','submit') NOT NULL COMMENT 'عملیات',
  `slug` VARCHAR(80) NOT NULL COMMENT 'مثل invoices.create',
  `title_fa` VARCHAR(150) NOT NULL COMMENT 'عنوان فارسی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_permissions_slug` (`slug`),
  KEY `ix_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مجوزها — مجوز ریز به تفکیک ماژول و عملیات (ماتریس دسترسی پنل).';


CREATE TABLE IF NOT EXISTS `role_permissions` (
  `role_id` BIGINT UNSIGNED NOT NULL COMMENT 'نقش',
  `permission_id` BIGINT UNSIGNED NOT NULL COMMENT 'مجوز',
  `scope` ENUM('all','own','team') NOT NULL DEFAULT 'all' COMMENT 'دامنه اعمال (همه/فقط رکوردهای خودش)',
  PRIMARY KEY (`role_id`, `permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نقش ↔ مجوز — ماتریس دسترسی: کدام نقش چه اجازه‌ای دارد.';


CREATE TABLE IF NOT EXISTS `user_business_roles` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر',
  `role_id` BIGINT UNSIGNED NOT NULL COMMENT 'نقش',
  `max_discount_percent` DECIMAL(5,2) COMMENT 'سقف تخفیف مجاز کاربر',
  `can_see_cost` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'مشاهده بهای تمام‌شده',
  `default_warehouse_id` BIGINT UNSIGNED COMMENT 'انبار پیش‌فرض',
  `default_cash_account_id` BIGINT UNSIGNED COMMENT 'حساب پیش‌فرض دریافت/پرداخت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_user_business_roles_user_id_business_id_role_id` (`user_id`, `business_id`, `role_id`),
  KEY `ix_user_business_roles_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کاربر ↔ کسب‌وکار ↔ نقش — عضویت کاربر در کسب‌وکار با یک یا چند نقش + محدودیت‌های اختصاصی.';


CREATE TABLE IF NOT EXISTS `sessions` (
  `id` CHAR(36) NOT NULL COMMENT 'شناسه نشست (UUID)',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر',
  `refresh_token_hash` CHAR(64) NOT NULL COMMENT 'هش توکن تازه‌سازی',
  `ip_address` VARBINARY(16) COMMENT 'IP',
  `user_agent` VARCHAR(255) COMMENT 'مرورگر',
  `expires_at` DATETIME NOT NULL COMMENT 'انقضا',
  `revoked_at` DATETIME COMMENT 'ابطال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_sessions_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نشست‌ها — توکن‌های ورود و مدیریت نشست فعال.';


CREATE TABLE IF NOT EXISTS `otp_codes` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED COMMENT 'کاربر (در بازیابی ممکن است NULL باشد)',
  `mobile` VARCHAR(15) NOT NULL COMMENT 'شماره مقصد',
  `purpose` ENUM('login','2fa','reset_password','verify_contact') NOT NULL COMMENT 'هدف',
  `code_hash` CHAR(64) NOT NULL COMMENT 'هش کد',
  `expires_at` DATETIME NOT NULL COMMENT 'انقضا (حداکثر ۲ دقیقه)',
  `used_at` DATETIME COMMENT 'زمان مصرف',
  `attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تلاش‌های اشتباه',
  PRIMARY KEY (`id`),
  KEY `ix_otp_codes_mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کدهای یکبارمصرف — کد پیامکی ورود دو مرحله‌ای و بازیابی رمز.';


CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر',
  `token_hash` CHAR(64) NOT NULL COMMENT 'هش توکن',
  `expires_at` DATETIME NOT NULL COMMENT 'انقضا',
  `used_at` DATETIME COMMENT 'مصرف',
  `requested_ip` VARBINARY(16) COMMENT 'IP درخواست',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_password_resets_token_hash` (`token_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='بازیابی رمز عبور — توکن‌های فراموشی رمز (صفحه «رمزمو فراموش کرده‌ام»).';


CREATE TABLE IF NOT EXISTS `api_clients` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `name` VARCHAR(100) NOT NULL COMMENT 'نام کلاینت',
  `client_key` VARCHAR(60) NOT NULL COMMENT 'کلید عمومی',
  `secret_hash` VARCHAR(255) NOT NULL COMMENT 'هش کلید خصوصی',
  `scopes_json` JSON NOT NULL COMMENT 'مجوزهای API',
  `allowed_ips` VARCHAR(500) COMMENT 'IPهای مجاز',
  `rate_limit_per_min` INT UNSIGNED NOT NULL DEFAULT 60 COMMENT 'محدودیت نرخ',
  `status` ENUM('active','revoked') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_api_clients_client_key` (`client_key`),
  KEY `ix_api_clients_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کلاینت‌های API — اتصال سیستم‌های بیرونی (فروشگاه‌ساز، CRM) طبق بخش API پنل.';


CREATE TABLE IF NOT EXISTS `api_logs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `api_client_id` BIGINT UNSIGNED COMMENT 'کلاینت',
  `endpoint` VARCHAR(200) NOT NULL COMMENT 'مسیر',
  `method` ENUM('GET','POST','PUT','PATCH','DELETE') NOT NULL COMMENT 'متد',
  `status_code` SMALLINT UNSIGNED NOT NULL COMMENT 'کد پاسخ',
  `request_body` MEDIUMTEXT COMMENT 'بدنه درخواست',
  `response_body` MEDIUMTEXT COMMENT 'بدنه پاسخ',
  `duration_ms` INT UNSIGNED COMMENT 'زمان پردازش',
  `ip_address` VARBINARY(16) COMMENT 'IP',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_api_logs_business_id` (`business_id`),
  KEY `ix_api_logs_api_client_id` (`api_client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='لاگ درخواست‌های API — رهگیری فراخوانی‌ها، خطاها و زمان پاسخ.';


CREATE TABLE IF NOT EXISTS `user_settings` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر',
  `setting_key` VARCHAR(80) NOT NULL COMMENT 'کلید',
  `value_json` JSON NOT NULL COMMENT 'مقدار',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_user_settings_user_id_setting_key` (`user_id`, `setting_key`),
  KEY `ix_user_settings_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات کاربر — ترجیحات اختصاصی هر کاربر در هر کسب‌وکار.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: اشخاص، بازاریاب و سهامدار  (۱۱ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `persons` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(30) NOT NULL COMMENT 'کد شخص (خودکار یا دستی)',
  `person_kind` ENUM('haqiqi','hoqoqi') NOT NULL DEFAULT 'haqiqi' COMMENT 'حقیقی/حقوقی',
  `first_name` VARCHAR(80) COMMENT 'نام',
  `last_name` VARCHAR(120) COMMENT 'نام خانوادگی / نام شرکت',
  `company_name` VARCHAR(180) COMMENT 'نام شرکت (برای حقوقی)',
  `father_name` VARCHAR(80) COMMENT 'نام پدر',
  `national_id` VARCHAR(12) COMMENT 'کد ملی',
  `national_legal_id` VARCHAR(20) COMMENT 'شناسه ملی',
  `mobile` VARCHAR(20) COMMENT 'موبایل',
  `phone` VARCHAR(20) COMMENT 'تلفن',
  `email` VARCHAR(120) COMMENT 'ایمیل',
  `website` VARCHAR(150) COMMENT 'وبسایت',
  `economic_code` VARCHAR(20) COMMENT 'کد اقتصادی',
  `foreign_person` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'شخص غیرایرانی',
  `country_id` SMALLINT UNSIGNED COMMENT 'کشور',
  `province_id` SMALLINT UNSIGNED COMMENT 'استان',
  `city_id` SMALLINT UNSIGNED COMMENT 'شهر',
  `postal_code` VARCHAR(15) COMMENT 'کد پستی',
  `address` VARCHAR(500) COMMENT 'نشانی',
  `introducer_person_id` BIGINT UNSIGNED COMMENT 'معرف',
  `marketer_id` BIGINT UNSIGNED COMMENT 'بازاریاب پیش‌فرض شخص',
  `price_list_note` VARCHAR(120) COMMENT 'توضیح لیست قیمت اختصاصی',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `notes` TEXT COMMENT 'یادداشت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_persons_business_id_code` (`business_id`, `code`),
  KEY `ix_persons_business_id_last_name` (`business_id`, `last_name`),
  KEY `ix_persons_business_id_company_name` (`business_id`, `company_name`),
  FULLTEXT KEY `ix_persons_last_name_company_name_first_name` (`last_name`, `company_name`, `first_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اشخاص — مشتریان، تأمین‌کنندگان و همکاران (صفحه «تعریف شخص» و «لیست اشخاص»).';


CREATE TABLE IF NOT EXISTS `person_types` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `slug` VARCHAR(30) NOT NULL COMMENT 'شناسه مثال: customer',
  `title_fa` VARCHAR(60) NOT NULL COMMENT 'عنوان مثال: مشتری',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نوع سیستمی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_person_types_business_id_slug` (`business_id`, `slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انواع شخص — مشتری، تأمین‌کننده، همکار، بازاریاب، سهامدار، پرسنل.';


CREATE TABLE IF NOT EXISTS `person_type_links` (
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `person_type_id` BIGINT UNSIGNED NOT NULL COMMENT 'نوع',
  PRIMARY KEY (`person_id`, `person_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انواع هر شخص (چند-به-چند) — یک شخص می‌تواند هم مشتری و هم تأمین‌کننده باشد.';


CREATE TABLE IF NOT EXISTS `person_contacts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `contact_type` ENUM('mobile','phone','email','whatsapp','telegram','fax') NOT NULL COMMENT 'نوع',
  `value` VARCHAR(150) NOT NULL COMMENT 'مقدار',
  `is_primary` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'اصلی',
  `is_verified` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'تأیید‌شده',
  PRIMARY KEY (`id`),
  KEY `ix_person_contacts_person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='راه‌های تماس اشخاص — چند موبایل/تلفن/ایمیل برای هر شخص.';


CREATE TABLE IF NOT EXISTS `person_bank_accounts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `bank_name` VARCHAR(80) NOT NULL COMMENT 'نام بانک',
  `branch_name` VARCHAR(120) COMMENT 'شعبه',
  `account_no` VARCHAR(30) COMMENT 'شماره حساب',
  `card_no` VARCHAR(20) COMMENT 'شماره کارت',
  `iban` VARCHAR(26) COMMENT 'شبا (IR + ۲۴ رقم)',
  `account_holder` VARCHAR(150) COMMENT 'صاحب حساب',
  `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'پیش‌فرض',
  PRIMARY KEY (`id`),
  KEY `ix_person_bank_accounts_person_id` (`person_id`),
  KEY `ix_person_bank_accounts_iban` (`iban`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='حساب‌های بانکی اشخاص — شبا، کارت و حساب برای تسویه و صدور فاکتور.';


CREATE TABLE IF NOT EXISTS `person_financial_settings` (
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `receivable_account_id` BIGINT UNSIGNED COMMENT 'حساب دریافتنی/پرداختنی',
  `opening_balance_type` ENUM('none','debit','credit') NOT NULL DEFAULT 'none' COMMENT 'نوع مانده اولیه',
  `credit_limit_amount` DECIMAL(18,2) COMMENT 'سقف اعتبار',
  `payment_term_id` BIGINT UNSIGNED COMMENT 'شرط پرداخت',
  `default_price_type_id` BIGINT UNSIGNED COMMENT 'نوع قیمت پیش‌فرض',
  `default_discount_percent` DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'درصد تخفیف پیش‌فرض',
  `sms_thanks_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'ارسال پیامک تشکر',
  `statement_period` ENUM('monthly','quarterly','manual') NOT NULL DEFAULT 'monthly' COMMENT 'دوره ارسال صورت‌حساب',
  PRIMARY KEY (`person_id`),
  UNIQUE KEY `k_person_financial_settings_person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات مالی و اعتباری اشخاص — سقف اعتبار، شرط پرداخت، تخفیف و قیمت پیش‌فرض (بخش «تنظیمات مالی و اعتباری» فرم شخص).';


CREATE TABLE IF NOT EXISTS `payment_terms` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(60) NOT NULL COMMENT 'عنوان مثال: اعتباری ۳۰ روز',
  `days` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'مهلت (روز)',
  `is_cash` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نقدی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_payment_terms_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='شرایط پرداخت — نقدی، اعتباری ۱۵/۳۰/۶۰ روز و مشابه آن.';


CREATE TABLE IF NOT EXISTS `person_product_prices` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا/خدمت',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع کالا',
  `unit_price` DECIMAL(18,2) NOT NULL COMMENT 'قیمت مصوب',
  `discount_percent` DECIMAL(5,2) COMMENT 'درصد تخفیف',
  `from_date` DATE COMMENT 'اعتبار از',
  `to_date` DATE COMMENT 'اعتبار تا',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_person_product_prices_business_id` (`business_id`),
  KEY `ix_person_product_prices_person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قیمت اختصاصی شخص برای کالا — قیمت مصوب هر مشتری برای کالای مشخص.';


CREATE TABLE IF NOT EXISTS `marketers` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص مرتبط (اختیاری)',
  `code` VARCHAR(20) NOT NULL COMMENT 'کد بازاریاب',
  `full_name` VARCHAR(120) NOT NULL COMMENT 'نام بازاریاب',
  `commission_percent` DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'درصد کمیسیون',
  `commission_base` ENUM('net_invoice','gross_invoice','invoice_profit') NOT NULL DEFAULT 'net_invoice' COMMENT 'مبنای محاسبه',
  `settlement_cycle` ENUM('monthly','quarterly','per_invoice') NOT NULL DEFAULT 'monthly' COMMENT 'دوره تسویه',
  `monthly_cap_amount` DECIMAL(18,2) COMMENT 'سقف پورسانت ماهانه',
  `region` VARCHAR(80) COMMENT 'منطقه فعالیت',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_marketers_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='بازاریابان — درصد کمیسیون، مبنای محاسبه و دوره تسویه (صفحه «تعریف/لیست بازاریاب»).';


CREATE TABLE IF NOT EXISTS `shareholders` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص سهامدار',
  `share_percent` DECIMAL(5,2) NOT NULL COMMENT 'درصد سهام',
  `share_type` ENUM('ordinary','preferred') NOT NULL DEFAULT 'ordinary' COMMENT 'نوع سهام',
  `capital_amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ سرمایه',
  `effective_from` DATE NOT NULL COMMENT 'از تاریخ',
  `effective_to` DATE COMMENT 'تا تاریخ (رکوردهای تاریخی)',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_shareholders_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سهامداران — درصد سهام، نوع سهام و سرمایه (صفحه «سهامداران»).';


CREATE TABLE IF NOT EXISTS `person_opening_balances` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص',
  `debit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بدهکار',
  `credit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بستانکار',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_person_opening_balances_business_id` (`business_id`),
  KEY `ix_person_opening_balances_person_id` (`person_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مانده اولیه اشخاص — مانده بدهکار/بستانکار ابتدای دوره هر شخص.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: کالا، خدمات، قیمت و مالیات  (۱۳ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `product_categories` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `parent_id` BIGINT UNSIGNED COMMENT 'والد',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان',
  `path` VARCHAR(400) COMMENT 'مسیر درختی برای جستجوی سریع',
  `sort_order` INT NOT NULL DEFAULT 0 COMMENT 'ترتیب',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_product_categories_business_id_title` (`business_id`, `title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='دسته‌بندی کالا — درخت دسته‌بندی کالاها و خدمات.';


CREATE TABLE IF NOT EXISTS `units` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(50) NOT NULL COMMENT 'نام واحد',
  `symbol` VARCHAR(20) COMMENT 'نماد',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'واحد سیستمی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_units_business_id_title` (`business_id`, `title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='واحدهای اندازه‌گیری — عدد، بسته، کارتن، متر، کیلوگرم، ساعت و... .';


CREATE TABLE IF NOT EXISTS `products` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(30) NOT NULL COMMENT 'کد کالا/خدمت',
  `item_type` ENUM('goods','service') NOT NULL DEFAULT 'goods' COMMENT 'کالا یا خدمت',
  `title` VARCHAR(200) NOT NULL COMMENT 'نام کالا/خدمت',
  `category_id` BIGINT UNSIGNED COMMENT 'دسته‌بندی',
  `main_unit_id` BIGINT UNSIGNED NOT NULL COMMENT 'واحد اصلی',
  `base_unit_id` BIGINT UNSIGNED COMMENT 'واحد پایه برای موجودی',
  `pack_factor` DECIMAL(12,3) NOT NULL DEFAULT 1 COMMENT 'ضریب تبدیل به واحد پایه',
  `has_variants` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'دارای تنوع (رنگ/سایز)',
  `default_warehouse_id` BIGINT UNSIGNED COMMENT 'انبار پیش‌فرض',
  `accounting_account_id` BIGINT UNSIGNED COMMENT 'حساب موجودی/خدمات',
  `cost_method` ENUM('weighted_average','fifo','lifo') NOT NULL DEFAULT 'weighted_average' COMMENT 'روش قیمت‌گذاری',
  `is_taxable` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'مشمول مالیات',
  `vat_rate_id` BIGINT UNSIGNED COMMENT 'نرخ مالیات اختصاصی',
  `reorder_point` DECIMAL(14,3) COMMENT 'نقطه سفارش پیش‌فرض',
  `min_sale_qty` DECIMAL(14,3) COMMENT 'حداقل مقدار فروش',
  `allowed_discount_percent` DECIMAL(5,2) COMMENT 'تخفیف مجاز',
  `show_in_online_store` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش در وب‌سرویس/فروشگاه',
  `description` TEXT COMMENT 'توضیحات و مشخصات فنی',
  `image_attachment_id` BIGINT UNSIGNED COMMENT 'تصویر کالا',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_products_business_id_code` (`business_id`, `code`),
  KEY `ix_products_category_id` (`category_id`),
  KEY `ix_products_business_id_category_id` (`business_id`, `category_id`),
  KEY `ix_products_business_id_title` (`business_id`, `title`),
  FULLTEXT KEY `ix_products_title` (`title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کالاها و خدمات — قلب انبارداری و فروش (صفحه «ثبت کالا و خدمت» و لیست کالاها).';


CREATE TABLE IF NOT EXISTS `product_units` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `unit_id` BIGINT UNSIGNED NOT NULL COMMENT 'واحد',
  `factor` DECIMAL(14,4) NOT NULL DEFAULT 1 COMMENT 'ضریب تبدیل به واحد اصلی',
  `barcode` VARCHAR(60) COMMENT 'بارکد مخصوص این واحد',
  `sale_price` DECIMAL(18,2) COMMENT 'قیمت این واحد',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_product_units_product_id_unit_id` (`product_id`, `unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='واحدهای فرعی کالا — هر کالا می‌تواند چند واحد با ضریب تبدیل داشته باشد.';


CREATE TABLE IF NOT EXISTS `product_barcodes` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `barcode` VARCHAR(60) NOT NULL COMMENT 'بارکد',
  `barcode_type` ENUM('EAN13','CODE128','QR','custom') NOT NULL DEFAULT 'CODE128' COMMENT 'نوع بارکد',
  `is_primary` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'اصلی',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_product_barcodes_barcode` (`barcode`),
  KEY `ix_product_barcodes_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='بارکدهای کالا — چند بارکد برای یک کالا (تأمین‌کنندگان مختلف/چاپ لیبل).';


CREATE TABLE IF NOT EXISTS `price_types` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `slug` VARCHAR(30) NOT NULL COMMENT 'شناسه مثال: retail',
  `title_fa` VARCHAR(60) NOT NULL COMMENT 'عنوان',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'سیستمی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_price_types_business_id_slug` (`business_id`, `slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انواع قیمت — خرید، فروش، عمده، مصوب مشتری، پیمانکاری.';


CREATE TABLE IF NOT EXISTS `product_prices` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `price_type_id` BIGINT UNSIGNED NOT NULL COMMENT 'نوع قیمت',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `price` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `from_date` DATE NOT NULL COMMENT 'اعتبار از',
  `to_date` DATE COMMENT 'اعتبار تا',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_product_prices_product_id_price_type_id_from_date` (`product_id`, `price_type_id`, `from_date`),
  KEY `ix_product_prices_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قیمت‌های کالا — چندین قیمت با تاریخ اعتبار برای هر کالا/تنوع.';


CREATE TABLE IF NOT EXISTS `price_update_batches` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان دسته',
  `price_type_id` BIGINT UNSIGNED NOT NULL COMMENT 'نوع قیمت هدف',
  `change_mode` ENUM('percent','margin','amount','excel') NOT NULL COMMENT 'روش تغییر',
  `change_value` DECIMAL(18,4) COMMENT 'مقدار تغییر',
  `filter_json` JSON COMMENT 'شرط انتخاب کالاها',
  `affected_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد کالای متأثر',
  `status` ENUM('draft','applied','reverted') NOT NULL DEFAULT 'draft' COMMENT 'وضعیت',
  `applied_at` DATETIME COMMENT 'زمان اعمال',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_price_update_batches_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='بروزرسانی گروهی قیمت — دسته اجرای تغییر گروهی قیمت‌ها (درصد/مبلغ/اکسل).';


CREATE TABLE IF NOT EXISTS `taxes` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(80) NOT NULL COMMENT 'عنوان مثال: ارزش افزوده ۱۰٪',
  `tax_kind` ENUM('vat','withholding','income','municipality','customs','other') NOT NULL DEFAULT 'vat' COMMENT 'نوع مالیات',
  `rate_percent` DECIMAL(6,3) NOT NULL COMMENT 'نرخ',
  `is_inclusive` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قیمت شامل مالیات',
  `account_id` BIGINT UNSIGNED COMMENT 'حساب مالیات پرداختنی/دریافتنی',
  `moadian_tax_code` VARCHAR(20) COMMENT 'کد مالیاتی برای سامانه مودیان',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_taxes_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مالیات‌ها و عوارض — مالیات بر ارزش افزوده ۱۰٪/۹٪، معاف، عوارض و مالیات‌های خاص.';


CREATE TABLE IF NOT EXISTS `product_taxes` (
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `tax_id` BIGINT UNSIGNED NOT NULL COMMENT 'مالیات',
  PRIMARY KEY (`product_id`, `tax_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مالیات کالا — مالیات به تفکیک هر کالا/خدمت (الزام سامانه مودیان).';


CREATE TABLE IF NOT EXISTS `product_attributes` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(80) NOT NULL COMMENT 'نام ویژگی',
  `attr_type` ENUM('select','text','number','color') NOT NULL DEFAULT 'select' COMMENT 'نوع',
  `values_json` JSON COMMENT 'مقادیر مجاز مثال: [قرمز,آبی]',
  `is_filterable` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'قابل فیلتر در گزارش',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_product_attributes_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ویژگی‌های کالا — رنگ، سایز، گارانتی، جنس و... .';


CREATE TABLE IF NOT EXISTS `product_variants` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `sku` VARCHAR(40) COMMENT 'کد انبارdاری تنوع',
  `attributes_json` JSON NOT NULL COMMENT 'ترکیب ویژگی‌ها',
  `barcode` VARCHAR(60) COMMENT 'بارکد',
  `extra_price` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'اختلاف قیمت با کالای اصلی',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_product_variants_sku` (`sku`),
  UNIQUE KEY `k_product_variants_business_id_sku` (`business_id`, `sku`),
  KEY `ix_product_variants_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنوع کالا — ترکیب ویژگی‌ها (مثال: رنگ قرمز + سایز L) با بارکد و قیمت مستقل.';


CREATE TABLE IF NOT EXISTS `product_warehouse_settings` (
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `reorder_point` DECIMAL(14,3) COMMENT 'نقطه سفارش',
  `max_stock` DECIMAL(14,3) COMMENT 'حداکثر موجودی',
  `default_bin_location` VARCHAR(40) COMMENT 'قفسه/موقعیت',
  PRIMARY KEY (`product_id`, `warehouse_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات کالا در انبار — نقطه سفارش و موجودی حداقل به تفکیک انبار.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: انبار و موجودی  (۱۱ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `warehouses` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(20) COMMENT 'کد انبار',
  `title` VARCHAR(120) NOT NULL COMMENT 'نام انبار',
  `warehouse_type` ENUM('main','branch','waste','transit','consignment') NOT NULL DEFAULT 'main' COMMENT 'نوع انبار',
  `keeper_user_id` BIGINT UNSIGNED COMMENT 'انباردار مسئول',
  `province_id` SMALLINT UNSIGNED COMMENT 'استان',
  `city_id` SMALLINT UNSIGNED COMMENT 'شهر',
  `address` VARCHAR(400) COMMENT 'نشانی',
  `phone` VARCHAR(20) COMMENT 'تلفن',
  `count_in_reports` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'محاسبه موجودی در گزارش‌های کل',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_warehouses_business_id_title` (`business_id`, `title`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انبارها — انبار مرکزی، شعبه، ضایعات و... (صفحه «انبارها»).';


CREATE TABLE IF NOT EXISTS `inventory_documents` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_type` ENUM('receive','issue','transfer_in','transfer_out','sale_return','buy_return','waste','count_adjust','opening') NOT NULL COMMENT 'نوع سند انبار',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره حواله',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ سند',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار مبدأ/اصلی',
  `dest_warehouse_id` BIGINT UNSIGNED COMMENT 'انبار مقصد (انتقال)',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص مرتبط',
  `source_type` VARCHAR(40) COMMENT 'مرجع مثال: invoice',
  `source_id` BIGINT UNSIGNED COMMENT 'شناسه مرجع',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند حسابداری خودکار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `total_cost` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بهای کل سند',
  `description` VARCHAR(400) COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_inventory_documents_business_id_fiscal_year_id_doc__34b05e` (`business_id`, `fiscal_year_id`, `doc_type`, `doc_no`),
  KEY `ix_inventory_documents_doc_type` (`doc_type`),
  KEY `ix_inventory_documents_doc_date` (`doc_date`),
  KEY `ix_inventory_documents_business_id_doc_type_doc_date` (`business_id`, `doc_type`, `doc_date`),
  KEY `ix_inventory_documents_source_type_source_id` (`source_type`, `source_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد انبار (حواله/ضایعات/برگشت) — سربرگ همه گردش‌های انبار؛ نوع سند تعیین‌کننده رفتار است.';


CREATE TABLE IF NOT EXISTS `inventory_document_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `document_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند انبار',
  `row_no` SMALLINT UNSIGNED NOT NULL COMMENT 'ردیف',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `unit_id` BIGINT UNSIGNED NOT NULL COMMENT 'واحد',
  `quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار در واحد ثبت',
  `base_quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار در واحد پایه',
  `unit_cost` DECIMAL(18,4) COMMENT 'بهای واحد',
  `total_cost` DECIMAL(18,2) COMMENT 'بهای کل ردیف',
  `waste_reason_id` BIGINT UNSIGNED COMMENT 'علت ضایعات',
  `description` VARCHAR(255) COMMENT 'شرح ردیف',
  PRIMARY KEY (`id`),
  KEY `ix_inventory_document_lines_document_id` (`document_id`),
  KEY `ix_inventory_document_lines_product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های اسناد انبار — اقلام هر حواله با مقدار و بهای واحد.';


CREATE TABLE IF NOT EXISTS `waste_reasons` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(80) NOT NULL COMMENT 'عنوان',
  `expense_account_id` BIGINT UNSIGNED COMMENT 'حساب هزینه ضایعات',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_waste_reasons_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='علل ضایعات — خرابی، شکستگی، تاریخ انقضا، گم شدن، سرقت و... .';


CREATE TABLE IF NOT EXISTS `stock_movements` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `movement_date` DATE NOT NULL COMMENT 'تاریخ',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `direction` ENUM('in','out') NOT NULL COMMENT 'جهت حرکت',
  `quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار (+/-) در واحد پایه',
  `unit_cost` DECIMAL(18,4) COMMENT 'بهای واحد',
  `total_cost` DECIMAL(18,2) COMMENT 'بهای کل',
  `balance_after` DECIMAL(18,4) COMMENT 'مانده پس از حرکت',
  `document_id` BIGINT UNSIGNED COMMENT 'سند انبار',
  `source_type` VARCHAR(40) COMMENT 'مرجع عملیاتی',
  `source_id` BIGINT UNSIGNED COMMENT 'شناسه مرجع',
  PRIMARY KEY (`id`),
  KEY `ix_stock_movements_movement_date` (`movement_date`),
  KEY `ix_stock_movements_document_id` (`document_id`),
  KEY `ix_stock_movements_business_id_warehouse_id_product_id_id` (`business_id`, `warehouse_id`, `product_id`, `id`),
  KEY `ix_stock_movements_product_id_movement_date` (`product_id`, `movement_date`),
  KEY `ix_stock_movements_source_type_source_id` (`source_type`, `source_id`),
  CONSTRAINT `chk_movement_qty` CHECK (quantity > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کاردکس موجودی — هر ورود/خروج انبار یک ردیف؛ مبنای گزارش کارت حساب کالا و مانده.';


CREATE TABLE IF NOT EXISTS `stock_cost_layers` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `in_date` DATE NOT NULL COMMENT 'تاریخ ورود',
  `document_id` BIGINT UNSIGNED COMMENT 'سند ورود',
  `qty_in` DECIMAL(18,4) NOT NULL COMMENT 'مقدار ورودی',
  `qty_remaining` DECIMAL(18,4) NOT NULL COMMENT 'مقدار باقی‌مانده',
  `unit_cost` DECIMAL(18,4) NOT NULL COMMENT 'بهای واحد',
  PRIMARY KEY (`id`),
  KEY `ix_stock_cost_layers_business_id_warehouse_id_product_79129b` (`business_id`, `warehouse_id`, `product_id`, `in_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='لایه‌های بهای تمام‌شده (FIFO) — هر ورود یک لایه با مقدار و بهای باقی‌مانده.';


CREATE TABLE IF NOT EXISTS `stock_layer_consumptions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `layer_id` BIGINT UNSIGNED NOT NULL COMMENT 'لایه',
  `movement_id` BIGINT UNSIGNED NOT NULL COMMENT 'حرکت خروج',
  `qty_used` DECIMAL(18,4) NOT NULL COMMENT 'مقدار مصرفی',
  `unit_cost` DECIMAL(18,4) NOT NULL COMMENT 'بهای واحد',
  PRIMARY KEY (`id`),
  KEY `ix_stock_layer_consumptions_layer_id` (`layer_id`),
  KEY `ix_stock_layer_consumptions_movement_id` (`movement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مصرف لایه‌ها — کدام لایه در کدام خروج مصرف شد (بهای تمام‌شده دقیق).';


CREATE TABLE IF NOT EXISTS `stock_balances` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED NOT NULL COMMENT 'تنوع',
  `quantity` DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'موجودی',
  `reserved_quantity` DECIMAL(18,4) NOT NULL DEFAULT 0 COMMENT 'رزرو‌شده',
  `available_quantity` DECIMAL(18,4) GENERATED ALWAYS AS (quantity - reserved_quantity) VIRTUAL COMMENT 'قابل فروش = موجودی − رزرو',
  `avg_unit_cost` DECIMAL(18,4) COMMENT 'میانگین بهای تمام‌شده',
  `last_movement_at` DATETIME COMMENT 'آخرین گردش',
  PRIMARY KEY (`warehouse_id`, `product_id`, `variant_id`),
  KEY `ix_stock_balances_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='موجودی جاری — مانده لحظه‌ای هر کالا در هر انبار (جدول مشتق و پرسرعت).';


CREATE TABLE IF NOT EXISTS `stock_reservations` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار رزرو',
  `source_type` VARCHAR(40) NOT NULL COMMENT 'مرجع مثال: invoice',
  `source_id` BIGINT UNSIGNED NOT NULL COMMENT 'شناسه مرجع',
  `expires_at` DATETIME COMMENT 'انقضای رزرو',
  `status` ENUM('active','released','consumed') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_stock_reservations_business_id_warehouse_id_product_a9a2c0` (`business_id`, `warehouse_id`, `product_id`, `variant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='رزرو موجودی — رزرو کالا برای پیش‌فاکتور/فاکتور/سفارش آنلاین.';


CREATE TABLE IF NOT EXISTS `stock_counts` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `count_date` DATE NOT NULL COMMENT 'تاریخ شمارش',
  `warehouse_id` BIGINT UNSIGNED NOT NULL COMMENT 'انبار',
  `period_type` ENUM('monthly','quarterly','yearly','adhoc') NOT NULL DEFAULT 'monthly' COMMENT 'دوره شمارش',
  `responsible_user_id` BIGINT UNSIGNED COMMENT 'مسئول شمارش',
  `status` ENUM('counting','done','approved','cancelled') NOT NULL DEFAULT 'counting' COMMENT 'وضعیت',
  `items_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد اقلام شمارش‌شده',
  `diff_items_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'اقلام دارای مغایرت',
  `diff_value` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'ارزش مغایرت',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند تعدیل موجودی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_stock_counts_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انبارگردانی — سربرگ شمارش انبار و مغایرت‌ها (صفحه «ثبت انبارگردانی»).';


CREATE TABLE IF NOT EXISTS `stock_count_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `stock_count_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند انبارگردانی',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `book_qty` DECIMAL(18,4) NOT NULL COMMENT 'موجودی دفتری',
  `counted_qty` DECIMAL(18,4) NOT NULL COMMENT 'موجودی شمارش‌شده',
  `diff_qty` DECIMAL(18,4) GENERATED ALWAYS AS (counted_qty - book_qty) VIRTUAL COMMENT 'مغایرت = شمارش − دفتری',
  `unit_cost` DECIMAL(18,4) COMMENT 'بهای واحد',
  `diff_value` DECIMAL(18,2) COMMENT 'ارزش مغایرت',
  `description` VARCHAR(255) COMMENT 'توضیح',
  PRIMARY KEY (`id`),
  KEY `ix_stock_count_lines_stock_count_id` (`stock_count_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های انبارگردانی — مقایسه موجودی دفتری و واقعی هر قلم.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: خرید و فروش  (۷ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `invoices` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `invoice_type` ENUM('sale','buy','sale_return','buy_return','quote') NOT NULL COMMENT 'نوع فاکتور',
  `invoice_no` VARCHAR(30) NOT NULL COMMENT 'شماره فاکتور',
  `invoice_date` DATE NOT NULL COMMENT 'تاریخ صدور',
  `due_date` DATE COMMENT 'سررسید',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'خریدار/فروشنده',
  `marketer_id` BIGINT UNSIGNED COMMENT 'بازاریاب',
  `warehouse_id` BIGINT UNSIGNED COMMENT 'انبار خروج/ورود',
  `project_id` BIGINT UNSIGNED COMMENT 'پروژه',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `reference_invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور مرجع (برگشتی/تبدیل پیش‌فاکتور)',
  `parent_invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور مبدأ برای برگشتی',
  `customer_order_no` VARCHAR(40) COMMENT 'شماره سفارش مشتری',
  `settlement_type` ENUM('cash','credit','cheque','mixed') NOT NULL DEFAULT 'cash' COMMENT 'نوع تسویه',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب دریافت/پرداخت در تسویه نقدی/بانکی',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `fx_rate` DECIMAL(18,6) NOT NULL DEFAULT 1 COMMENT 'نرخ تسعیر',
  `subtotal` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع اقلام',
  `line_discount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع تخفیف ردیف‌ها',
  `invoice_discount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'تخفیف کلی فاکتور',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع مالیات',
  `charges_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'هزینه‌های اضافه (حمل)',
  `total_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ قابل پرداخت',
  `paid_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ تسویه‌شده',
  `remaining_amount` DECIMAL(18,2) GENERATED ALWAYS AS (total_amount - paid_amount) VIRTUAL COMMENT 'مانده',
  `cost_amount` DECIMAL(18,2) COMMENT 'بهای تمام‌شده اقلام (برای سود فاکتور)',
  `profit_amount` DECIMAL(18,2) GENERATED ALWAYS AS (subtotal - line_discount - invoice_discount - IFNULL(cost_amount,0)) VIRTUAL COMMENT 'سود = خالص − بهای تمام‌شده',
  `status` ENUM('draft','registered','approved','posted','cancelled','returned') NOT NULL DEFAULT 'registered' COMMENT 'وضعیت سند',
  `settlement_status` ENUM('unpaid','partial','paid','overdue') NOT NULL DEFAULT 'unpaid' COMMENT 'وضعیت تسویه',
  `auto_journal_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'صدور خودکار سند',
  `inventory_doc_id` BIGINT UNSIGNED COMMENT 'حواله انبار مرتبط',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند حسابداری',
  `description` VARCHAR(500) COMMENT 'شرح',
  `posted_at` DATETIME COMMENT 'زمان قطعی‌سازی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_invoices_business_id_fiscal_year_id_invoice_type_in_f6290b` (`business_id`, `fiscal_year_id`, `invoice_type`, `invoice_no`),
  KEY `ix_invoices_invoice_type` (`invoice_type`),
  KEY `ix_invoices_invoice_date` (`invoice_date`),
  KEY `ix_invoices_settlement_status` (`settlement_status`),
  KEY `ix_invoices_business_id_invoice_type_invoice_date` (`business_id`, `invoice_type`, `invoice_date`),
  KEY `ix_invoices_business_id_person_id_invoice_date` (`business_id`, `person_id`, `invoice_date`),
  KEY `ix_invoices_business_id_settlement_status_due_date` (`business_id`, `settlement_status`, `due_date`),
  FULLTEXT KEY `ix_invoices_description_customer_order_no` (`description`, `customer_order_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فاکتورها و پیش‌فاکتورها — سربرگ فاکتور فروش، خرید، برگشتی‌ها و پیش‌فاکتور.';


CREATE TABLE IF NOT EXISTS `invoice_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `row_no` SMALLINT UNSIGNED NOT NULL COMMENT 'ردیف',
  `product_id` BIGINT UNSIGNED NOT NULL COMMENT 'کالا/خدمت',
  `variant_id` BIGINT UNSIGNED COMMENT 'تنوع',
  `unit_id` BIGINT UNSIGNED NOT NULL COMMENT 'واحد',
  `quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار',
  `base_quantity` DECIMAL(18,4) NOT NULL COMMENT 'مقدار در واحد پایه',
  `unit_price` DECIMAL(18,4) NOT NULL COMMENT 'مبلغ واحد',
  `discount_percent` DECIMAL(6,3) NOT NULL DEFAULT 0 COMMENT 'درصد تخفیف',
  `discount_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ تخفیف',
  `tax_id` BIGINT UNSIGNED COMMENT 'مالیات ردیف',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ مالیات',
  `line_total` DECIMAL(18,2) NOT NULL COMMENT 'جمع ردیف',
  `unit_cost` DECIMAL(18,4) COMMENT 'بهای واحد در لحظه فروش',
  `warehouse_id` BIGINT UNSIGNED COMMENT 'انبار ردیف (چند انباری)',
  `description` VARCHAR(255) COMMENT 'شرح ردیف',
  PRIMARY KEY (`id`),
  KEY `ix_invoice_lines_invoice_id` (`invoice_id`),
  KEY `ix_invoice_lines_product_id_invoice_id` (`product_id`, `invoice_id`),
  CONSTRAINT `chk_invoice_line_qty` CHECK (quantity <> 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های فاکتور — اقلام، مقدار، تخفیف و مالیات هر ردیف.';


CREATE TABLE IF NOT EXISTS `invoice_charges` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `charge_type` ENUM('shipping','packaging','insurance','other') NOT NULL DEFAULT 'shipping' COMMENT 'نوع هزینه',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `tax_id` BIGINT UNSIGNED COMMENT 'مالیات',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ مالیات',
  `account_id` BIGINT UNSIGNED COMMENT 'حساب درآمد هزینه حمل',
  PRIMARY KEY (`id`),
  KEY `ix_invoice_charges_invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='هزینه‌های فاکتور — هزینه حمل و سایر هزینه‌ها (ردیف‌های غیرکالایی).';


CREATE TABLE IF NOT EXISTS `invoice_settlements` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `settle_source` ENUM('receipt','payment','cheque','credit_note','manual') NOT NULL COMMENT 'منبع تسویه',
  `receipt_id` BIGINT UNSIGNED COMMENT 'سند دریافت',
  `payment_id` BIGINT UNSIGNED COMMENT 'سند پرداخت',
  `cheque_id` BIGINT UNSIGNED COMMENT 'چک',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ تخصیص',
  `settled_at` DATETIME NOT NULL COMMENT 'زمان تسویه',
  `note` VARCHAR(255) COMMENT 'یادداشت',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_invoice_settlements_invoice_id_settle_source_receip_9c107e` (`invoice_id`, `settle_source`, `receipt_id`, `payment_id`, `cheque_id`),
  KEY `ix_invoice_settlements_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تخصیص دریافت/پرداخت به فاکتور — اتصال اسناد خزانه به فاکتور و مانده‌گیری دقیق (تسویه جزئی).';


CREATE TABLE IF NOT EXISTS `invoice_status_history` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `from_status` VARCHAR(30) COMMENT 'وضعیت قبلی',
  `to_status` VARCHAR(30) NOT NULL COMMENT 'وضعیت جدید',
  `changed_by` BIGINT UNSIGNED COMMENT 'کاربر',
  `changed_at` DATETIME NOT NULL COMMENT 'زمان',
  `reason` VARCHAR(255) COMMENT 'علت',
  PRIMARY KEY (`id`),
  KEY `ix_invoice_status_history_invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تاریخچه وضعیت فاکتور — ردیابی چرخه: پیش‌نویس → ثبت → قطعی → تسویه/ابطال.';


CREATE TABLE IF NOT EXISTS `invoice_dispatches` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `channel` ENUM('sms','email','link','print','whatsapp') NOT NULL COMMENT 'کانال ارسال',
  `destination` VARCHAR(150) COMMENT 'مقصد',
  `share_token` CHAR(32) COMMENT 'توکن لینک عمومی فاکتور',
  `sent_at` DATETIME NOT NULL COMMENT 'زمان ارسال',
  `viewed_at` DATETIME COMMENT 'زمان مشاهده توسط مشتری',
  `status` ENUM('queued','sent','failed','viewed') NOT NULL DEFAULT 'queued' COMMENT 'وضعیت',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_invoice_dispatches_share_token` (`share_token`),
  KEY `ix_invoice_dispatches_business_id` (`business_id`),
  KEY `ix_invoice_dispatches_invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ارسال فاکتور — ارسال فاکتور/صورت‌حساب با پیامک، ایمیل یا لینک آنلاین.';


CREATE TABLE IF NOT EXISTS `invoice_commissions` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `marketer_id` BIGINT UNSIGNED NOT NULL COMMENT 'بازاریاب',
  `base_amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ مبنای محاسبه',
  `percent` DECIMAL(5,2) NOT NULL COMMENT 'درصد اعمال‌شده',
  `commission_amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ پورسانت',
  `status` ENUM('calculated','approved','settled','cancelled') NOT NULL DEFAULT 'calculated' COMMENT 'وضعیت',
  `settled_payment_id` BIGINT UNSIGNED COMMENT 'سند پرداخت پورسانت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_invoice_commissions_invoice_id_marketer_id` (`invoice_id`, `marketer_id`),
  KEY `ix_invoice_commissions_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پورسانت فاکتور — پورسانت هر فاکتور به‌همراه وضعیت تسویه با بازاریاب.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: خزانه‌داری، بانک و چک  (۱۱ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `cash_accounts` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(20) COMMENT 'کد حساب خزانه',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان مثال: بانک ملت — جاری ۱۲۳۴',
  `account_kind` ENUM('bank','cash_box','petty_cash','pos','other') NOT NULL COMMENT 'نوع',
  `bank_name` VARCHAR(80) COMMENT 'نام بانک',
  `branch_name` VARCHAR(120) COMMENT 'شعبه',
  `account_no` VARCHAR(30) COMMENT 'شماره حساب',
  `card_no` VARCHAR(20) COMMENT 'شماره کارت',
  `iban` VARCHAR(26) COMMENT 'شبا',
  `gl_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب معین متناظر',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `keeper_user_id` BIGINT UNSIGNED COMMENT 'مسئول صندوق/تنخواه',
  `opening_balance` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده اولیه',
  `current_balance` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده جاری (مشدد)',
  `show_in_dashboard` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش در نمودار داشبورد',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_cash_accounts_business_id_title` (`business_id`, `title`),
  KEY `ix_cash_accounts_account_kind` (`account_kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='حساب‌های نقدی و بانکی — بانک، صندوق و تنخواه‌گردان (صفحه «موجودی نقد و بانک»).';


CREATE TABLE IF NOT EXISTS `payment_methods` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `slug` VARCHAR(30) NOT NULL COMMENT 'شناسه مثال: bank_transfer',
  `title_fa` VARCHAR(60) NOT NULL COMMENT 'عنوان',
  `requires_cheque` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نیازمند اطلاعات چک',
  `requires_bank_ref` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نیازمند شماره پیگیری بانکی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_payment_methods_business_id_slug` (`business_id`, `slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='روش‌های دریافت و پرداخت — نقدی، واریز بانکی، کارت به کارت، چک، تنخواه.';


CREATE TABLE IF NOT EXISTS `receipts` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'دریافت‌کننده/شخص',
  `cash_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب دریافت‌کننده',
  `payment_method_id` BIGINT UNSIGNED NOT NULL COMMENT 'روش دریافت',
  `cheque_id` BIGINT UNSIGNED COMMENT 'چک دریافتی',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `fx_rate` DECIMAL(18,6) NOT NULL DEFAULT 1 COMMENT 'نرخ تسعیر',
  `bank_reference` VARCHAR(60) COMMENT 'شماره پیگیری/فیش',
  `allocation_mode` ENUM('on_account','invoice') NOT NULL DEFAULT 'on_account' COMMENT 'علی‌الحساب یا تخصیص به فاکتور',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند خودکار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `description` VARCHAR(400) COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_receipts_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`),
  KEY `ix_receipts_doc_date` (`doc_date`),
  KEY `ix_receipts_business_id_person_id_doc_date` (`business_id`, `person_id`, `doc_date`),
  KEY `ix_receipts_business_id_status_doc_date` (`business_id`, `status`, `doc_date`),
  CONSTRAINT `chk_receipt_amount` CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد دریافت — دریافت از مشتریان؛ نقدی/بانکی/چکی (صفحه «ثبت دریافت» و لیست دریافت‌ها).';


CREATE TABLE IF NOT EXISTS `receipt_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `receipt_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند دریافت',
  `invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ تخصیص',
  `description` VARCHAR(255) COMMENT 'شرح',
  PRIMARY KEY (`id`),
  KEY `ix_receipt_lines_receipt_id` (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های تخصیص دریافت — تخصیص یک دریافت به یک یا چند فاکتور فروش.';


CREATE TABLE IF NOT EXISTS `payments` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص/تأمین‌کننده',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `cash_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب پرداخت‌کننده',
  `payment_method_id` BIGINT UNSIGNED NOT NULL COMMENT 'روش پرداخت',
  `cheque_id` BIGINT UNSIGNED COMMENT 'چک پرداختی',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `fx_rate` DECIMAL(18,6) NOT NULL DEFAULT 1 COMMENT 'نرخ تسعیر',
  `bank_reference` VARCHAR(60) COMMENT 'شماره پیگیری',
  `allocation_mode` ENUM('on_account','invoice','expense') NOT NULL DEFAULT 'invoice' COMMENT 'نحوه تخصیص',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند خودکار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `description` VARCHAR(400) COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_payments_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`),
  KEY `ix_payments_doc_date` (`doc_date`),
  KEY `ix_payments_business_id_person_id_doc_date` (`business_id`, `person_id`, `doc_date`),
  KEY `ix_payments_business_id_status_doc_date` (`business_id`, `status`, `doc_date`),
  CONSTRAINT `chk_payment_amount` CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد پرداخت — پرداخت به تأمین‌کنندگان و هزینه‌ها (صفحه «ثبت پرداخت» و لیست پرداخت‌ها).';


CREATE TABLE IF NOT EXISTS `payment_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `payment_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند پرداخت',
  `invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور خرید',
  `expense_document_id` BIGINT UNSIGNED COMMENT 'سند هزینه',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ تخصیص',
  `description` VARCHAR(255) COMMENT 'شرح',
  PRIMARY KEY (`id`),
  KEY `ix_payment_lines_payment_id` (`payment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های تخصیص پرداخت — تخصیص یک پرداخت به فاکتور خرید یا مرکز هزینه.';


CREATE TABLE IF NOT EXISTS `transfers` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ',
  `from_cash_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'از حساب',
  `to_cash_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'به حساب',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `fee_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'کارمزد',
  `fee_cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه کارمزد',
  `bank_reference` VARCHAR(60) COMMENT 'شماره پیگیری بانکی',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند خودکار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `description` VARCHAR(400) COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_transfers_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`),
  KEY `ix_transfers_doc_date` (`doc_date`),
  CONSTRAINT `chk_transfer_amount` CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انتقال بین حساب‌ها — انتقال وجه بین بانک/صندوق/تنخواه (صفحه «ثبت انتقال»).';


CREATE TABLE IF NOT EXISTS `cheques` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `direction` ENUM('received','issued') NOT NULL COMMENT 'دریافتی/پرداختی',
  `cheque_no` VARCHAR(30) NOT NULL COMMENT 'شماره چک',
  `bank_name` VARCHAR(80) NOT NULL COMMENT 'بانک',
  `branch_name` VARCHAR(120) COMMENT 'شعبه',
  `account_no` VARCHAR(30) COMMENT 'شماره حساب صادرکننده',
  `sayad_id` VARCHAR(30) COMMENT 'شناسه صیادی',
  `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'طرف حساب',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `issue_date` DATE COMMENT 'تاریخ صدور',
  `due_date` DATE NOT NULL COMMENT 'سررسید',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب بانکی مرتبط',
  `status` ENUM('in_hand','deposited','cleared','bounced','spent','endorsed','cancelled') NOT NULL DEFAULT 'in_hand' COMMENT 'وضعیت چرخه چک',
  `spent_to_person_id` BIGINT UNSIGNED COMMENT 'خرج چک به شخص',
  `cleared_at` DATETIME COMMENT 'زمان وصول/پاس',
  `bounced_reason` VARCHAR(255) COMMENT 'علت برگشت',
  `receipt_id` BIGINT UNSIGNED COMMENT 'سند دریافت مرتبط',
  `payment_id` BIGINT UNSIGNED COMMENT 'سند پرداخت مرتبط',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند حسابداری',
  `description` VARCHAR(400) COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_cheques_direction` (`direction`),
  KEY `ix_cheques_due_date` (`due_date`),
  KEY `ix_cheques_status` (`status`),
  KEY `ix_cheques_business_id_status_due_date` (`business_id`, `status`, `due_date`),
  KEY `ix_cheques_business_id_person_id_due_date` (`business_id`, `person_id`, `due_date`),
  CONSTRAINT `chk_cheque_amount` CHECK (amount > 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='چک‌های دریافتی و پرداختی — چرخه کامل چک: در جریان، وصول، برگشتی، خرج‌شده (صفحات «چک‌های دریافتی/پرداختی»).';


CREATE TABLE IF NOT EXISTS `cheque_histories` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `cheque_id` BIGINT UNSIGNED NOT NULL COMMENT 'چک',
  `event` ENUM('register','deposit','clear','bounce','spend','endorse','cancel','transfer') NOT NULL COMMENT 'رویداد',
  `event_date` DATE NOT NULL COMMENT 'تاریخ رویداد',
  `from_status` VARCHAR(30) COMMENT 'وضعیت قبلی',
  `to_status` VARCHAR(30) COMMENT 'وضعیت جدید',
  `amount` DECIMAL(18,2) COMMENT 'مبلغ رویداد (برای خرج جزئی)',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند حسابداری',
  `user_id` BIGINT UNSIGNED COMMENT 'کاربر ثبت‌کننده',
  `note` VARCHAR(255) COMMENT 'توضیح',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_cheque_histories_cheque_id` (`cheque_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تاریخچه رویدادهای چک — هر تغییر وضعیت چک با تاریخ، کاربر و سند مرتبط.';


CREATE TABLE IF NOT EXISTS `bank_statements` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `cash_account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب بانکی',
  `from_date` DATE NOT NULL COMMENT 'از تاریخ',
  `to_date` DATE NOT NULL COMMENT 'تا تاریخ',
  `opening_balance` DECIMAL(18,2) COMMENT 'مانده ابتدای صورت‌حساب',
  `closing_balance` DECIMAL(18,2) COMMENT 'مانده پایان صورت‌حساب',
  `source` ENUM('manual','excel','bank_api') NOT NULL DEFAULT 'manual' COMMENT 'منبع ورود',
  `attachment_id` BIGINT UNSIGNED COMMENT 'فایل',
  `reconciled` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'مغایرت‌گیری انجام‌شده',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_bank_statements_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='صورت‌حساب بانکی — فایل صورت‌حساب بانک برای مغایرت‌گیری.';


CREATE TABLE IF NOT EXISTS `bank_statement_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `bank_statement_id` BIGINT UNSIGNED NOT NULL COMMENT 'صورت‌حساب',
  `line_date` DATE NOT NULL COMMENT 'تاریخ',
  `description` VARCHAR(255) COMMENT 'شرح بانک',
  `debit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'برداشت',
  `credit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'واریز',
  `balance` DECIMAL(18,2) COMMENT 'مانده',
  `matched_type` ENUM('receipt','payment','transfer','cheque','none') COMMENT 'نوع تطبیق',
  `matched_id` BIGINT UNSIGNED COMMENT 'شناسه سند تطبیق‌شده',
  PRIMARY KEY (`id`),
  KEY `ix_bank_statement_lines_bank_statement_id` (`bank_statement_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های صورت‌حساب بانکی — مغایرت‌گیری خودکار/دستی با اسناد خزانه.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: درآمد، هزینه و ضایعات  (۶ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `income_documents` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ',
  `title` VARCHAR(200) NOT NULL COMMENT 'عنوان درآمد',
  `income_category_id` BIGINT UNSIGNED COMMENT 'مرکز/دسته درآمد',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص مرتبط',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب دریافت',
  `project_id` BIGINT UNSIGNED COMMENT 'پروژه',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز درآمد',
  `revenue_account_id` BIGINT UNSIGNED COMMENT 'حساب درآمد',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `settlement_type` ENUM('cash','credit','cheque') NOT NULL DEFAULT 'cash' COMMENT 'نوع دریافت',
  `receipt_id` BIGINT UNSIGNED COMMENT 'سند دریافت مرتبط',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند خودکار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `description` TEXT COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_income_documents_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`),
  KEY `ix_income_documents_doc_date` (`doc_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد درآمد — درآمدهای عملیاتی/غیرعملیاتی (صفحه «ثبت درآمد» و لیست درآمدها).';


CREATE TABLE IF NOT EXISTS `income_document_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `income_document_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند درآمد',
  `row_no` SMALLINT UNSIGNED NOT NULL COMMENT 'ردیف',
  `title` VARCHAR(200) NOT NULL COMMENT 'عنوان',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب درآمد',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز درآمد',
  `tax_id` BIGINT UNSIGNED COMMENT 'مالیات',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مالیات',
  PRIMARY KEY (`id`),
  KEY `ix_income_document_lines_income_document_id` (`income_document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های سند درآمد — درآمد چندردیفی با حساب و مبلغ مستقل.';


CREATE TABLE IF NOT EXISTS `expense_documents` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ',
  `title` VARCHAR(200) NOT NULL COMMENT 'عنوان هزینه',
  `expense_category_id` BIGINT UNSIGNED COMMENT 'مرکز/دسته هزینه',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص/تأمین‌کننده',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب پرداخت',
  `project_id` BIGINT UNSIGNED COMMENT 'پروژه',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `expense_account_id` BIGINT UNSIGNED COMMENT 'حساب هزینه',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `refundable` ENUM('no','customer','insurance') NOT NULL DEFAULT 'no' COMMENT 'قابل بازیافت',
  `attachment_id` BIGINT UNSIGNED COMMENT 'پیوست فاکتور خرید',
  `payment_id` BIGINT UNSIGNED COMMENT 'سند پرداخت مرتبط',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند خودکار',
  `recurring_rule_id` BIGINT UNSIGNED COMMENT 'قاعده تکرار',
  `status` ENUM('draft','posted','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `description` TEXT COMMENT 'شرح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_expense_documents_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`),
  KEY `ix_expense_documents_doc_date` (`doc_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد هزینه — هزینه‌های اداری، فروش، حمل و... (صفحه «ثبت هزینه» و لیست هزینه‌ها).';


CREATE TABLE IF NOT EXISTS `expense_document_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `expense_document_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند هزینه',
  `row_no` SMALLINT UNSIGNED NOT NULL COMMENT 'ردیف',
  `title` VARCHAR(200) NOT NULL COMMENT 'عنوان',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب هزینه',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `tax_id` BIGINT UNSIGNED COMMENT 'مالیات',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مالیات',
  PRIMARY KEY (`id`),
  KEY `ix_expense_document_lines_expense_document_id` (`expense_document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های سند هزینه — هزینه چندردیفی با حساب، مرکز هزینه و مالیات مستقل.';


CREATE TABLE IF NOT EXISTS `profit_loss_categories` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `kind` ENUM('income','expense') NOT NULL COMMENT 'نوع',
  `parent_id` BIGINT UNSIGNED COMMENT 'والد',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان',
  `default_account_id` BIGINT UNSIGNED COMMENT 'حساب پیش‌فرض',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_profit_loss_categories_business_id` (`business_id`),
  KEY `ix_profit_loss_categories_kind` (`kind`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='دسته‌های درآمد و هزینه — دسته‌بندی گزارش سود و زیان (حقوق، اجاره، تبلیغات، حمل و...).';


CREATE TABLE IF NOT EXISTS `recurring_rules` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(150) NOT NULL COMMENT 'عنوان',
  `doc_kind` ENUM('income','expense') NOT NULL COMMENT 'نوع سند تولیدی',
  `frequency` ENUM('monthly','quarterly','yearly') NOT NULL DEFAULT 'monthly' COMMENT 'تناوب',
  `day_of_period` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'روز ماه برای تولید',
  `amount` DECIMAL(18,2) COMMENT 'مبلغ ثابت',
  `template_json` JSON COMMENT 'قالب سند',
  `next_run_date` DATE COMMENT 'اجرای بعدی',
  `last_run_date` DATE COMMENT 'آخرین اجرا',
  `status` ENUM('active','paused','finished') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_recurring_rules_business_id` (`business_id`),
  KEY `ix_recurring_rules_next_run_date` (`next_run_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قواعد اسناد تکرارشونده — هزینه/درآمد تکرارشونده ماهانه (اجاره، اشتراک) با تولید خودکار.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: حسابداری و دفاتر  (۹ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `chart_of_accounts` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `code` VARCHAR(30) NOT NULL COMMENT 'کد حساب مثال: ۱-۱۰۱',
  `parent_id` BIGINT UNSIGNED COMMENT 'حساب والد',
  `level_no` TINYINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'سطح (۱=گروه، ۲=کل، ۳=معین)',
  `title` VARCHAR(150) NOT NULL COMMENT 'عنوان حساب',
  `account_type` ENUM('asset','liability','equity','revenue','expense','cogs','other') NOT NULL COMMENT 'نوع حساب',
  `nature` ENUM('debit','credit','both') NOT NULL COMMENT 'ماهیت حساب',
  `is_group` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'حساب گروهی/سرفصل',
  `is_postable` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'قابل ثبت در آرتیکل',
  `currency_id` SMALLINT UNSIGNED COMMENT 'ارز اختصاصی حساب',
  `person_required` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ثبت شخص در آرتیکل الزامی',
  `full_path` VARCHAR(500) COMMENT 'مسیر درختی برای گزارش',
  `system_role` VARCHAR(40) COMMENT 'نقش سیستمی مثال: receivable',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_chart_of_accounts_business_id` (`business_id`),
  KEY `ix_chart_of_accounts_title` (`title`),
  KEY `ix_chart_of_accounts_account_type` (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کدینگ حساب‌ها — درخت حساب‌ها با ماهیت، سطح و حساب پیش‌فرض (صفحات «لیست حساب‌ها» و «تراز افتتاحیه»).';


CREATE TABLE IF NOT EXISTS `account_mappings` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `mapping_key` VARCHAR(60) NOT NULL COMMENT 'کلید مثال: ar_account',
  `title_fa` VARCHAR(150) NOT NULL COMMENT 'عنوان فارسی',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب متناظر',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_account_mappings_business_id_mapping_key` (`business_id`, `mapping_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نگاشت حساب‌های پیش‌فرض — کدینگ پیش‌فرض رویدادها (حساب نقد، دریافتنی، پرداختنی، فروش، بهای تمام‌شده).';


CREATE TABLE IF NOT EXISTS `journal_entries` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `fiscal_period_id` BIGINT UNSIGNED COMMENT 'دوره مالی',
  `entry_no` BIGINT UNSIGNED NOT NULL COMMENT 'شماره سند',
  `entry_date` DATE NOT NULL COMMENT 'تاریخ سند',
  `entry_type` ENUM('normal','opening','closing','adjustment','payroll','transfer') NOT NULL DEFAULT 'normal' COMMENT 'نوع سند',
  `reference_type` VARCHAR(40) COMMENT 'مرجع مثال: invoice',
  `reference_id` BIGINT UNSIGNED COMMENT 'شناسه مرجع',
  `reference_no` VARCHAR(40) COMMENT 'شماره مرجع',
  `description` VARCHAR(500) NOT NULL COMMENT 'شرح سند',
  `project_id` BIGINT UNSIGNED COMMENT 'پروژه',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `total_debit` DECIMAL(18,2) NOT NULL COMMENT 'جمع بدهکار',
  `total_credit` DECIMAL(18,2) NOT NULL COMMENT 'جمع بستانکار',
  `line_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد آرتیکل',
  `source` ENUM('manual','auto','import') NOT NULL DEFAULT 'manual' COMMENT 'منبع ایجاد',
  `is_locked` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قفل سند پس از قطعی‌سازی',
  `posted_at` DATETIME COMMENT 'زمان قطعی‌سازی',
  `status` ENUM('draft','posted','reversed') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_journal_entries_business_id_fiscal_year_id_entry_no` (`business_id`, `fiscal_year_id`, `entry_no`),
  KEY `ix_journal_entries_entry_date` (`entry_date`),
  KEY `ix_journal_entries_reference_type` (`reference_type`),
  KEY `ix_journal_entries_status` (`status`),
  FULLTEXT KEY `ix_journal_entries_description` (`description`),
  CONSTRAINT `chk_journal_balanced` CHECK (total_debit = total_credit)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد حسابداری — سربرگ سند (صفحه «ثبت سند» و «لیست اسناد»).';


CREATE TABLE IF NOT EXISTS `journal_entry_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `journal_entry_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند',
  `row_no` SMALLINT UNSIGNED NOT NULL COMMENT 'ردیف',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب',
  `description` VARCHAR(300) COMMENT 'شرح آرتیکل',
  `debit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بدهکار',
  `credit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بستانکار',
  `currency_id` SMALLINT UNSIGNED COMMENT 'ارز',
  `fx_amount` DECIMAL(18,2) COMMENT 'مبلغ ارزی',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص (ابعاد تحلیلی)',
  `product_id` BIGINT UNSIGNED COMMENT 'کالا',
  `project_id` BIGINT UNSIGNED COMMENT 'پروژه',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `cheque_id` BIGINT UNSIGNED COMMENT 'چک',
  PRIMARY KEY (`id`),
  KEY `ix_journal_entry_lines_journal_entry_id` (`journal_entry_id`),
  KEY `ix_journal_entry_lines_account_id_person_id` (`account_id`, `person_id`),
  KEY `ix_journal_entry_lines_account_id_journal_entry_id` (`account_id`, `journal_entry_id`),
  CONSTRAINT `chk_line_one_side` CHECK ((debit_amount > 0 AND credit_amount = 0) OR (credit_amount > 0 AND debit_amount = 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='آرتیکل‌های سند — ردیف‌های بدهکار/بستانکار با ابعاد تحلیلی.';


CREATE TABLE IF NOT EXISTS `auto_entry_rules` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `event_key` VARCHAR(60) NOT NULL COMMENT 'رویداد مثال: sale_invoice',
  `title_fa` VARCHAR(150) NOT NULL COMMENT 'عنوان',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  `priority` SMALLINT UNSIGNED NOT NULL DEFAULT 10 COMMENT 'اولویت در صورت تداخل',
  `condition_json` JSON COMMENT 'شرط اعمال (نوع تسویه، مرکز هزینه و...)',
  `description` VARCHAR(400) COMMENT 'توضیح',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_auto_entry_rules_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قواعد سند خودکار — موتور تولید سند برای رویدادها (فروش، خرید، دریافت، حواله، حقوق).';


CREATE TABLE IF NOT EXISTS `auto_entry_rule_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `rule_id` BIGINT UNSIGNED NOT NULL COMMENT 'قاعده',
  `side` ENUM('debit','credit') NOT NULL COMMENT 'سمت',
  `account_source` ENUM('fixed','mapping','person','cash_account','dynamic_tax','bank_statement') NOT NULL COMMENT 'منبع حساب',
  `account_id` BIGINT UNSIGNED COMMENT 'حساب ثابت',
  `mapping_key` VARCHAR(60) COMMENT 'کلید نگاشت',
  `amount_source` ENUM('invoice_total','invoice_net','tax','charges','cogs','amount','paid','remaining','net','insurance_payable','payroll_tax','expense_total') NOT NULL COMMENT 'منبع مبلغ',
  `row_order` SMALLINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'ترتیب',
  PRIMARY KEY (`id`),
  KEY `ix_auto_entry_rule_lines_rule_id` (`rule_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='آرتیکل‌های قاعده سند خودکار — تعریف قالب آرتیکل‌ها با حساب و منبع مبلغ.';


CREATE TABLE IF NOT EXISTS `opening_balances` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص (برای حساب‌های تفصیلی)',
  `warehouse_id` BIGINT UNSIGNED COMMENT 'انبار (برای افتتاحیه موجودی)',
  `debit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بدهکار',
  `credit_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بستانکار',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `is_locked` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قفل تراز افتتاحیه',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند افتتاحیه تولیدشده',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_opening_balances_business_id` (`business_id`),
  KEY `ix_opening_balances_account_id` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تراز افتتاحیه — مانده ابتدای دوره حساب‌ها/اشخاص (صفحه «تراز افتتاحیه»).';


CREATE TABLE IF NOT EXISTS `account_period_balances` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `fiscal_period_id` BIGINT UNSIGNED NOT NULL COMMENT 'دوره',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص',
  `opening_debit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده بدهکار ابتدای دوره',
  `opening_credit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده بستانکار ابتدای دوره',
  `turn_debit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'گردش بدهکار',
  `turn_credit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'گردش بستانکار',
  `closing_debit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده بدهکار پایان دوره',
  `closing_credit` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مانده بستانکار پایان دوره',
  PRIMARY KEY (`id`),
  KEY `ix_account_period_balances_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مانده دوره‌ای حساب‌ها — جدول مشتق برای سرعت گزارش تراز/دفاتر.';


CREATE TABLE IF NOT EXISTS `year_closing_logs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `from_fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی مبدأ',
  `to_fiscal_year_id` BIGINT UNSIGNED COMMENT 'سال مالی مقصد',
  `step` ENUM('precheck','closing_entry','transfer_balances','opening_entry','lock','completed') NOT NULL COMMENT 'گام',
  `status` ENUM('success','failed','warning') NOT NULL COMMENT 'نتیجه',
  `message` VARCHAR(500) COMMENT 'پیام/خطا',
  `closing_entry_id` BIGINT UNSIGNED COMMENT 'سند اختتامیه',
  `opening_entry_id` BIGINT UNSIGNED COMMENT 'سند افتتاحیه',
  `ran_by` BIGINT UNSIGNED COMMENT 'کاربر اجراکننده',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_year_closing_logs_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='لاگ بستن سال مالی — ردیابی فرایند بستن سال و اسناد اختتامیه/افتتاحیه.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: حقوق، دستمزد و حضور  (۹ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `employees` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `person_id` BIGINT UNSIGNED COMMENT 'شخص متناظر (برای پرداخت‌ها)',
  `code` VARCHAR(20) NOT NULL COMMENT 'کد پرسنلی',
  `full_name` VARCHAR(120) NOT NULL COMMENT 'نام',
  `national_id` VARCHAR(12) COMMENT 'کد ملی',
  `insurance_no` VARCHAR(30) COMMENT 'شماره بیمه',
  `job_title` VARCHAR(80) COMMENT 'سمت',
  `department` VARCHAR(80) COMMENT 'واحد سازمانی',
  `hire_date` DATE COMMENT 'تاریخ استخدام',
  `termination_date` DATE COMMENT 'تاریخ پایان همکاری',
  `employment_type` ENUM('full_time','part_time','contract','intern') NOT NULL DEFAULT 'full_time' COMMENT 'نوع همکاری',
  `status` ENUM('active','suspended','terminated') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_employees_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پرسنل — اطلاعات کارکنان برای اسناد حقوق.';


CREATE TABLE IF NOT EXISTS `employee_salary_settings` (
  `employee_id` BIGINT UNSIGNED NOT NULL COMMENT 'پرسنل',
  `base_salary` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'حقوق پایه',
  `housing_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'حق مسکن',
  `food_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'حق بن/خواربار',
  `child_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'حق اولاد',
  `other_allowances` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'سایر مزایا',
  `insurance_rate_employee` DECIMAL(5,2) NOT NULL DEFAULT 7 COMMENT 'بیمه سهم کارمند (٪)',
  `insurance_rate_employer` DECIMAL(5,2) NOT NULL DEFAULT 23 COMMENT 'بیمه سهم کارفرما (٪)',
  `tax_exemption_amount` DECIMAL(18,2) COMMENT 'سقف معافیت مالیاتی',
  `payment_method_id` BIGINT UNSIGNED COMMENT 'روش پرداخت',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب پرداخت پیش‌فرض',
  `effective_from` DATE NOT NULL COMMENT 'اعتبار از',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`employee_id`),
  UNIQUE KEY `k_employee_salary_settings_employee_id_effective_from` (`employee_id`, `effective_from`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات حقوق هر پرسنل — حقوق پایه، مزایای ثابت و کسورات هر پرسنل.';


CREATE TABLE IF NOT EXISTS `payroll_components` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(100) NOT NULL COMMENT 'عنوان جزء',
  `component_kind` ENUM('earning','deduction','employer_cost') NOT NULL COMMENT 'مزایا/کسورات/هزینه کارفرما',
  `calc_type` ENUM('fixed','percent_of_base','per_day','step_tax') NOT NULL COMMENT 'نحوه محاسبه',
  `rate_percent` DECIMAL(6,3) COMMENT 'درصد',
  `default_amount` DECIMAL(18,2) COMMENT 'مبلغ ثابت',
  `account_id` BIGINT UNSIGNED NOT NULL COMMENT 'حساب مرتبط',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'جزء سیستمی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_payroll_components_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اجزای حقوق و دستمزد — حقوق پایه، حق مسکن، بن، بیمه ۷٪/۲۳٪، مالیات، مساعده (صفحه «تنظیمات اسناد حقوق»).';


CREATE TABLE IF NOT EXISTS `payroll_documents` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `fiscal_period_id` BIGINT UNSIGNED COMMENT 'دوره مالی',
  `doc_no` VARCHAR(30) NOT NULL COMMENT 'شماره سند',
  `doc_date` DATE NOT NULL COMMENT 'تاریخ سند',
  `period_title` VARCHAR(40) NOT NULL COMMENT 'عنوان دوره مثال: مهر ۱۴۰۵',
  `employee_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد پرسنل',
  `gross_amount` DECIMAL(18,2) NOT NULL COMMENT 'جمع حقوق و مزایا',
  `insurance_employee` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بیمه سهم کارمند',
  `insurance_employer` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'بیمه سهم کارفرما',
  `tax_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مالیات بر درآمد حقوق',
  `deductions_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع کسورات',
  `net_amount` DECIMAL(18,2) NOT NULL COMMENT 'خالص پرداختی',
  `cash_account_id` BIGINT UNSIGNED COMMENT 'حساب پرداخت',
  `cost_center_id` BIGINT UNSIGNED COMMENT 'مرکز هزینه',
  `journal_entry_id` BIGINT UNSIGNED COMMENT 'سند حسابداری',
  `status` ENUM('draft','posted','paid','cancelled') NOT NULL DEFAULT 'posted' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_payroll_documents_business_id_fiscal_year_id_doc_no` (`business_id`, `fiscal_year_id`, `doc_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد حقوق — سربرگ حقوق ماهانه (صفحه «ثبت سند حقوق» و لیست اسناد حقوق).';


CREATE TABLE IF NOT EXISTS `payroll_document_lines` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `payroll_document_id` BIGINT UNSIGNED NOT NULL COMMENT 'سند حقوق',
  `employee_id` BIGINT UNSIGNED NOT NULL COMMENT 'پرسنل',
  `worked_days` DECIMAL(6,2) NOT NULL DEFAULT 30 COMMENT 'روزهای کارکرد',
  `gross_amount` DECIMAL(18,2) NOT NULL COMMENT 'جمع مزایا',
  `deductions_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع کسورات',
  `net_amount` DECIMAL(18,2) NOT NULL COMMENT 'خالص',
  `payment_id` BIGINT UNSIGNED COMMENT 'سند پرداخت/فیش',
  PRIMARY KEY (`id`),
  KEY `ix_payroll_document_lines_payroll_document_id` (`payroll_document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ردیف‌های سند حقوق (هر پرسنل) — حقوق هر پرسنل در هر ماه با کسورات و خالص پرداختی.';


CREATE TABLE IF NOT EXISTS `payroll_line_items` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `payroll_line_id` BIGINT UNSIGNED NOT NULL COMMENT 'ردیف حقوق',
  `component_id` BIGINT UNSIGNED NOT NULL COMMENT 'جزء',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `percent_used` DECIMAL(6,3) COMMENT 'درصد استفاده‌شده',
  PRIMARY KEY (`id`),
  KEY `ix_payroll_line_items_payroll_line_id` (`payroll_line_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='جزئیات اقلام حقوق — مقدار هر جزء (مزایا/کسورات) برای هر پرسنل.';


CREATE TABLE IF NOT EXISTS `attendance_devices` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(100) NOT NULL COMMENT 'نام دستگاه',
  `device_type` ENUM('fingerprint','face','card','mobile','manual') NOT NULL COMMENT 'نوع',
  `ip_address` VARCHAR(45) COMMENT 'IP دستگاه',
  `location` VARCHAR(120) COMMENT 'محل نصب',
  `last_sync_at` DATETIME COMMENT 'آخرین همگام‌سازی',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_attendance_devices_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='دستگاه‌های حضور و غیاب — دستگاه‌های تردد و تنظیمات اتصال (صفحه «تنظیمات اسناد حقوق»).';


CREATE TABLE IF NOT EXISTS `attendance_records` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `employee_id` BIGINT UNSIGNED NOT NULL COMMENT 'پرسنل',
  `device_id` BIGINT UNSIGNED COMMENT 'دستگاه',
  `work_date` DATE NOT NULL COMMENT 'تاریخ',
  `check_in_at` DATETIME COMMENT 'ورود',
  `check_out_at` DATETIME COMMENT 'خروج',
  `worked_minutes` INT UNSIGNED COMMENT 'دقیقه کارکرد',
  `overtime_minutes` INT UNSIGNED COMMENT 'اضافه‌کاری',
  `leave_type_id` BIGINT UNSIGNED COMMENT 'نوع مرخصی',
  `source` ENUM('device','manual','mobile') NOT NULL DEFAULT 'device' COMMENT 'منبع ثبت',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_attendance_records_business_id` (`business_id`),
  KEY `ix_attendance_records_work_date` (`work_date`),
  KEY `ix_attendance_records_employee_id_work_date` (`employee_id`, `work_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تردد پرسنل — ترددهای ورود/خروج برای محاسبه کارکرد و اضافه‌کاری.';


CREATE TABLE IF NOT EXISTS `leave_types` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(60) NOT NULL COMMENT 'عنوان',
  `is_paid` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'با حقوق',
  `annual_quota_days` SMALLINT UNSIGNED COMMENT 'سهمیه سالانه',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_leave_types_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انواع مرخصی — استحقاقی، استعلاجی، بدون حقوق و... .';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: مالیات و سامانه مودیان  (۴ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `moadian_settings` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `economic_code` VARCHAR(20) NOT NULL COMMENT 'کد اقتصادی',
  `taxpayer_id` VARCHAR(30) COMMENT 'شناسه یکتای حافظه مالیاتی',
  `private_key_pem` TEXT COMMENT 'کلید خصوصی (رمز‌شده در سطح برنامه)',
  `public_key_pem` TEXT COMMENT 'کلید عمومی',
  `certificate_serial` VARCHAR(60) COMMENT 'سریال گواهی',
  `environment` ENUM('sandbox','production') NOT NULL DEFAULT 'sandbox' COMMENT 'محیط',
  `api_base_url` VARCHAR(200) COMMENT 'آدرس سرویس',
  `auto_submit` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ارسال خودکار پس از ثبت فاکتور',
  `key_created_at` DATETIME COMMENT 'زمان تولید کلید',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_moadian_settings_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات سامانه مودیان — کلید عمومی/خصوصی، شناسه حافظه مالیاتی، محیط آزمون/عملیات (صفحه «خرید پکیج» و «پشتیبانی»).';


CREATE TABLE IF NOT EXISTS `moadian_invoices` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
  `tax_id_unique` VARCHAR(60) COMMENT 'شناسه یکتای صورتحساب',
  `tax_id_reference` VARCHAR(60) COMMENT 'شماره مالیاتی',
  `invoice_pattern` ENUM('type1','type2','type3') COMMENT 'الگوی صورتحساب',
  `submission_no` VARCHAR(60) COMMENT 'شماره ارسال',
  `status` ENUM('pending','signed','sent','accepted','rejected','failed') NOT NULL DEFAULT 'pending' COMMENT 'وضعیت',
  `error_code` VARCHAR(30) COMMENT 'کد خطا',
  `error_message` VARCHAR(500) COMMENT 'متن خطا',
  `sent_at` DATETIME COMMENT 'زمان ارسال',
  `verified_at` DATETIME COMMENT 'زمان استعلام نهایی',
  `retry_count` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد تلاش',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_moadian_invoices_business_id` (`business_id`),
  KEY `ix_moadian_invoices_invoice_id` (`invoice_id`),
  KEY `ix_moadian_invoices_tax_id_unique` (`tax_id_unique`),
  KEY `ix_moadian_invoices_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='صورتحساب‌های الکترونیکی — وضعیت ارسال هر فاکتور به سامانه مودیان.';


CREATE TABLE IF NOT EXISTS `moadian_logs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `moadian_invoice_id` BIGINT UNSIGNED COMMENT 'صورتحساب',
  `action` ENUM('get_server_info','get_token','submit','sign','inquiry') NOT NULL COMMENT 'عملیات',
  `request_body` MEDIUMTEXT COMMENT 'درخواست',
  `response_body` MEDIUMTEXT COMMENT 'پاسخ',
  `http_status` SMALLINT UNSIGNED COMMENT 'کد وضعیت',
  `duration_ms` INT UNSIGNED COMMENT 'زمان پاسخ',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_moadian_logs_business_id` (`business_id`),
  KEY `ix_moadian_logs_moadian_invoice_id` (`moadian_invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='لاگ ارتباط با مودیان — درخواست/پاسخ خام برای رفع خطا و پیگیری.';


CREATE TABLE IF NOT EXISTS `quarterly_tax_reports` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `fiscal_year_id` BIGINT UNSIGNED NOT NULL COMMENT 'سال مالی',
  `season` ENUM('spring','summer','autumn','winter') NOT NULL COMMENT 'فصل',
  `report_type` ENUM('purchases','sales','both') NOT NULL DEFAULT 'both' COMMENT 'نوع گزارش',
  `from_date` DATE NOT NULL COMMENT 'از تاریخ',
  `to_date` DATE NOT NULL COMMENT 'تا تاریخ',
  `rows_count` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد رکورد',
  `total_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ کل',
  `file_attachment_id` BIGINT UNSIGNED COMMENT 'فایل تولیدشده',
  `status` ENUM('draft','generated','filed') NOT NULL DEFAULT 'draft' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_quarterly_tax_reports_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='گزارش فصلی مالیات — گزارش صورت معاملات فصلی و فایل TTMS (صفحه گزارش‌ها).';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: پیامک، ایمیل و اعلان  (۵ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `message_templates` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `event_key` VARCHAR(50) NOT NULL COMMENT 'رویداد مثال: invoice_due_reminder',
  `channel` ENUM('sms','email','inapp') NOT NULL DEFAULT 'sms' COMMENT 'کانال',
  `title_fa` VARCHAR(120) NOT NULL COMMENT 'عنوان',
  `body_template` TEXT NOT NULL COMMENT 'متن با متغیر مثال: {person_name}',
  `variables_json` JSON COMMENT 'فهرست متغیرهای مجاز',
  `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قالب سیستمی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_message_templates_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قالب پیام‌ها — قالب پیامک/ایمیل: تشکر، سررسید فاکتور، سررسید چک، صورتحساب (بخش پیامک پنل).';


CREATE TABLE IF NOT EXISTS `messages` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `template_id` BIGINT UNSIGNED COMMENT 'قالب',
  `channel` ENUM('sms','email','inapp') NOT NULL COMMENT 'کانال',
  `person_id` BIGINT UNSIGNED COMMENT 'گیرنده (شخص)',
  `recipient` VARCHAR(150) NOT NULL COMMENT 'شماره/ایمیل مقصد',
  `body` TEXT NOT NULL COMMENT 'متن نهایی',
  `entity_type` VARCHAR(40) COMMENT 'موجودیت مرتبط',
  `entity_id` BIGINT UNSIGNED COMMENT 'شناسه مرتبط',
  `status` ENUM('queued','sent','delivered','failed','blocked') NOT NULL DEFAULT 'queued' COMMENT 'وضعیت',
  `provider` VARCHAR(40) COMMENT 'سرویس‌دهنده',
  `provider_ref` VARCHAR(80) COMMENT 'شناسه پیام در سرویس‌دهنده',
  `cost_amount` DECIMAL(12,2) COMMENT 'هزینه ارسال',
  `scheduled_at` DATETIME COMMENT 'زمان زمان‌بندی‌شده',
  `sent_at` DATETIME COMMENT 'زمان ارسال',
  `error_message` VARCHAR(300) COMMENT 'خطا',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_messages_business_id` (`business_id`),
  KEY `ix_messages_channel` (`channel`),
  KEY `ix_messages_status` (`status`),
  KEY `ix_messages_scheduled_at` (`scheduled_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پیام‌های ارسالی — صف و سابقه ارسال پیامک/ایمیل با وضعیت تحویل و هزینه.';


CREATE TABLE IF NOT EXISTS `message_credits` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `tx_type` ENUM('charge','consume','refund','expire') NOT NULL COMMENT 'نوع تراکنش',
  `units` INT NOT NULL COMMENT 'تعداد پیام (+/-)',
  `balance_after` INT NOT NULL COMMENT 'مانده پس از تراکنش',
  `unit_price` DECIMAL(12,2) COMMENT 'بهای هر پیام',
  `amount` DECIMAL(14,2) COMMENT 'مبلغ تراکنش',
  `invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور خرید اعتبار',
  `description` VARCHAR(255) COMMENT 'توضیح',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_message_credits_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اعتبار پیامک — تراکنش‌های شارژ و مصرف اعتبار پیامک (پنل پیامک).';


CREATE TABLE IF NOT EXISTS `notifications` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `user_id` BIGINT UNSIGNED COMMENT 'کاربر هدف (NULL = همه کاربران)',
  `notif_type` ENUM('cheque_due','invoice_overdue','low_stock','subscription','system','backup_failed','ticket_reply') NOT NULL COMMENT 'نوع',
  `title` VARCHAR(180) NOT NULL COMMENT 'عنوان',
  `body` VARCHAR(500) COMMENT 'متن',
  `severity` ENUM('info','warning','danger','success') NOT NULL DEFAULT 'info' COMMENT 'اهمیت',
  `entity_type` VARCHAR(40) COMMENT 'موجودیت',
  `entity_id` BIGINT UNSIGNED COMMENT 'شناسه',
  `read_at` DATETIME COMMENT 'زمان خواندن',
  `expires_at` DATETIME COMMENT 'انقضا',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_notifications_business_id` (`business_id`),
  KEY `ix_notifications_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اعلان‌های داخل پنل — اعلان‌های زنگ/زنگوله: چک نزدیک سررسید، فاکتور معوق، کمبود موجودی.';


CREATE TABLE IF NOT EXISTS `notification_rules` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `rule_key` VARCHAR(50) NOT NULL COMMENT 'کلید مثال: cheque_due',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  `days_before_json` JSON COMMENT 'روزهای هشدار مثال: [7,3,1]',
  `threshold_amount` DECIMAL(18,2) COMMENT 'آستانه مبلغ',
  `channels_json` JSON COMMENT 'کانال‌ها مثال: [inapp,sms]',
  `recipients_json` JSON COMMENT 'گیرندگان (نقش/کاربر)',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_notification_rules_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قواعد هشدار — آستانه‌ها و گیرندگان هر هشدار (مثال: ۷/۳/۱ روز قبل از سررسید چک).';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: فرم‌ساز و چاپ  (۳ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `print_templates` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(120) NOT NULL COMMENT 'نام قالب',
  `template_type` ENUM('invoice','voucher','label','statement','receipt','payment','payroll') NOT NULL COMMENT 'نوع قالب',
  `paper_size` ENUM('A4','A5','A4_landscape','thermal_80','label_50x30') NOT NULL DEFAULT 'A4' COMMENT 'اندازه کاغذ',
  `show_logo` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش لوگو',
  `logo_position` ENUM('right','center','left') NOT NULL DEFAULT 'right' COMMENT 'جای لوگو',
  `font_size` TINYINT UNSIGNED NOT NULL DEFAULT 12 COMMENT 'اندازه فونت',
  `show_signature` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش مهر و امضا',
  `amount_in_words` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'مبالغ به حروف',
  `show_economic_code` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش کد اقتصادی/شناسه ملی',
  `show_bank_info` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نمایش شبا و کارت',
  `show_barcode` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'درج بارکد سند',
  `layout_json` JSON COMMENT 'ساختار بخش‌ها و فیلدهای قالب',
  `current_version` SMALLINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'نسخه جاری',
  `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'قالب پیش‌فرض',
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_print_templates_business_id` (`business_id`),
  KEY `ix_print_templates_template_type` (`template_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قالب‌های چاپ — قالب فاکتور، حواله انبار و لیبل بارکد (صفحه «تنظیمات چاپ»).';


CREATE TABLE IF NOT EXISTS `print_template_versions` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `template_id` BIGINT UNSIGNED NOT NULL COMMENT 'قالب',
  `version_no` SMALLINT UNSIGNED NOT NULL COMMENT 'شماره نسخه',
  `layout_json` JSON NOT NULL COMMENT 'محتوای نسخه',
  `change_note` VARCHAR(255) COMMENT 'توضیح تغییر',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_print_template_versions_template_id` (`template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نسخه‌های قالب چاپ — تاریخچه نسخه‌ها برای بازگردانی قالب.';


CREATE TABLE IF NOT EXISTS `print_logs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `template_id` BIGINT UNSIGNED COMMENT 'قالب',
  `entity_type` VARCHAR(40) NOT NULL COMMENT 'نوع سند',
  `entity_id` BIGINT UNSIGNED NOT NULL COMMENT 'شناسه سند',
  `user_id` BIGINT UNSIGNED COMMENT 'کاربر',
  `copy_count` SMALLINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'تعداد نسخه',
  `printed_at` DATETIME NOT NULL COMMENT 'زمان چاپ',
  PRIMARY KEY (`id`),
  KEY `ix_print_logs_business_id` (`business_id`),
  KEY `ix_print_logs_entity_type` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سابقه چاپ — چه سندی، با چه قالبی، توسط چه کاربری و چند بار چاپ شد.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: پشتیبانی و تیکت  (۳ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `support_departments` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `title` VARCHAR(100) NOT NULL COMMENT 'عنوان',
  `slug` VARCHAR(40) NOT NULL COMMENT 'شناسه',
  `default_priority` ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal' COMMENT 'اولویت پیش‌فرض',
  `sla_hours` SMALLINT UNSIGNED COMMENT 'زمان پاسخ هدف (ساعت)',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_support_departments_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='دپارتمان‌های پشتیبانی — پشتیبانی فنی، نرم‌افزار، فرم‌ساز، فروش و مالی.';


CREATE TABLE IF NOT EXISTS `tickets` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `ticket_no` VARCHAR(20) NOT NULL COMMENT 'شماره تیکت',
  `subject` VARCHAR(250) NOT NULL COMMENT 'موضوع',
  `department_id` BIGINT UNSIGNED NOT NULL COMMENT 'دپارتمان',
  `request_type` ENUM('question','bug','suggestion','complaint','billing') NOT NULL DEFAULT 'question' COMMENT 'نوع درخواست',
  `priority` ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal' COMMENT 'اولویت',
  `status` ENUM('open','answered','pending','closed') NOT NULL DEFAULT 'open' COMMENT 'وضعیت',
  `created_by` BIGINT UNSIGNED NOT NULL COMMENT 'ایجادکننده',
  `assignee_id` BIGINT UNSIGNED COMMENT 'کارشناس مسئول',
  `contact_phone` VARCHAR(20) COMMENT 'شماره تماس',
  `last_reply_at` DATETIME COMMENT 'آخرین پاسخ',
  `closed_at` DATETIME COMMENT 'زمان بستن',
  `satisfaction_rate` TINYINT UNSIGNED COMMENT 'رضایت ۱ تا ۵',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_tickets_business_id` (`business_id`),
  KEY `ix_tickets_priority` (`priority`),
  KEY `ix_tickets_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تیکت‌های پشتیبانی — ثبت و پیگیری تیکت (صفحه «پشتیبانی»).';


CREATE TABLE IF NOT EXISTS `ticket_messages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `ticket_id` BIGINT UNSIGNED NOT NULL COMMENT 'تیکت',
  `sender_type` ENUM('user','support','system') NOT NULL COMMENT 'فرستنده',
  `sender_user_id` BIGINT UNSIGNED COMMENT 'کاربر فرستنده',
  `body` TEXT NOT NULL COMMENT 'متن',
  `is_internal_note` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'یادداشت داخلی',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_ticket_messages_ticket_id` (`ticket_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پیام‌های تیکت — گفتگوی تیکت با پیوست (attachment پلی‌مورفیک).';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: اشتراک و پکیج  (۵ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `plans` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `slug` VARCHAR(30) NOT NULL COMMENT 'شناسه مثال: pro',
  `title` VARCHAR(80) NOT NULL COMMENT 'عنوان',
  `description` VARCHAR(255) COMMENT 'توضیح',
  `price_amount` DECIMAL(18,2) NOT NULL COMMENT 'قیمت سالانه',
  `currency_id` SMALLINT UNSIGNED NOT NULL COMMENT 'واحد پول',
  `included_documents` INT UNSIGNED NOT NULL COMMENT 'تعداد سند حسابداری',
  `extra_document_price` DECIMAL(18,2) COMMENT 'بهای هر سند اضافه',
  `max_users` INT UNSIGNED COMMENT 'حداکثر کاربر همزمان',
  `max_businesses` INT UNSIGNED COMMENT 'حداکثر کسب‌وکار',
  `sms_credits` INT UNSIGNED COMMENT 'اعتبار پیامک هدیه',
  `is_popular` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'پیشنهاد ویژه',
  `sort_order` SMALLINT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'ترتیب نمایش',
  `status` ENUM('active','hidden','archived') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_plans_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پکیج‌های اشتراک — پکیج پایه، حرفه‌ای و سازمانی با تعداد اسناد (صفحه «خرید پکیج»).';


CREATE TABLE IF NOT EXISTS `plan_features` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `plan_id` BIGINT UNSIGNED NOT NULL COMMENT 'پکیج',
  `feature_key` VARCHAR(60) NOT NULL COMMENT 'کلید امکان مثال: moadian',
  `title_fa` VARCHAR(150) NOT NULL COMMENT 'عنوان',
  `included` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'شامل می‌شود',
  `limit_value` INT UNSIGNED COMMENT 'محدودیت عددی (NULL = نامحدود)',
  PRIMARY KEY (`id`),
  KEY `ix_plan_features_plan_id` (`plan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='امکانات هر پکیج — فهرست امکانات و وضعیت فعال/غیرفعال (جدول مقایسه پنل).';


CREATE TABLE IF NOT EXISTS `subscriptions` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `plan_id` BIGINT UNSIGNED NOT NULL COMMENT 'پکیج',
  `starts_at` DATE NOT NULL COMMENT 'شروع',
  `expires_at` DATE NOT NULL COMMENT 'پایان',
  `status` ENUM('trial','active','expired','suspended','cancelled') NOT NULL DEFAULT 'trial' COMMENT 'وضعیت',
  `documents_used` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'اسناد مصرف‌شده',
  `documents_limit` INT UNSIGNED NOT NULL COMMENT 'سقف اسناد',
  `auto_renew` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'تمدید خودکار',
  `trial_ends_at` DATE COMMENT 'پایان دوره آزمایشی',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  UNIQUE KEY `k_subscriptions_business_id_starts_at` (`business_id`, `starts_at`),
  KEY `ix_subscriptions_expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اشتراک کسب‌وکارها — وضعیت اشتراک، اعتبار و پکیج فعال هر کسب‌وکار.';


CREATE TABLE IF NOT EXISTS `subscription_usage` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `subscription_id` BIGINT UNSIGNED NOT NULL COMMENT 'اشتراک',
  `usage_date` DATE NOT NULL COMMENT 'تاریخ',
  `metric` ENUM('documents','users','sms','businesses','api_calls','storage_mb') NOT NULL COMMENT 'شاخص مصرف',
  `used_value` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'مقدار مصرف',
  PRIMARY KEY (`id`),
  KEY `ix_subscription_usage_business_id` (`business_id`),
  KEY `ix_subscription_usage_usage_date` (`usage_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مصرف اشتراک — شمارنده مصرف سند/کاربر/پیامک برای نمایش نوار پیشرفت پنل.';


CREATE TABLE IF NOT EXISTS `subscription_payments` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `subscription_id` BIGINT UNSIGNED NOT NULL COMMENT 'اشتراک',
  `plan_id` BIGINT UNSIGNED NOT NULL COMMENT 'پکیج خریداری‌شده',
  `amount` DECIMAL(18,2) NOT NULL COMMENT 'مبلغ',
  `discount_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'تخفیف',
  `payable_amount` DECIMAL(18,2) NOT NULL COMMENT 'قابل پرداخت',
  `payment_gateway` VARCHAR(40) COMMENT 'درگاه پرداخت',
  `gateway_ref` VARCHAR(80) COMMENT 'شماره پیگیری',
  `status` ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending' COMMENT 'وضعیت',
  `paid_at` DATETIME COMMENT 'زمان پرداخت',
  `invoice_id` BIGINT UNSIGNED COMMENT 'فاکتور صادرشده',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_subscription_payments_business_id` (`business_id`),
  KEY `ix_subscription_payments_subscription_id` (`subscription_id`),
  KEY `ix_subscription_payments_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پرداخت‌های اشتراک — تراکنش خرید/تمدید پکیج و ارتقای پلن.';



-- ────────────────────────────────────────────────────────────────────────────
-- دامنه: API، یکپارچگی، پشتیبان و زمان‌بندی  (۷ جدول)
-- ────────────────────────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS `integrations` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `provider` ENUM('woocommerce','wordpress','crm','pos','accounting','other') NOT NULL COMMENT 'سرویس',
  `title` VARCHAR(120) NOT NULL COMMENT 'عنوان اتصال',
  `credentials_json` JSON COMMENT 'کلیدها و توکن‌ها (رمز‌شده)',
  `settings_json` JSON COMMENT 'تنظیمات نگاشت کالا/مشتری/انبار',
  `last_sync_at` DATETIME COMMENT 'آخرین همگام‌سازی',
  `sync_direction` ENUM('pull','push','both') NOT NULL DEFAULT 'pull' COMMENT 'جهت همگام‌سازی',
  `status` ENUM('active','error','disabled') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_integrations_business_id` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='یکپارچگی با سیستم‌های بیرونی — فروشگاه‌ساز (ووکامرس/وردپرس)، CRM، صندوق فروشگاهی و API.';


CREATE TABLE IF NOT EXISTS `sync_jobs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `integration_id` BIGINT UNSIGNED NOT NULL COMMENT 'اتصال',
  `job_type` ENUM('import_orders','export_stock','export_prices','import_customers','full_sync') NOT NULL COMMENT 'نوع کار',
  `payload_json` JSON COMMENT 'داده',
  `status` ENUM('queued','running','success','failed','partial') NOT NULL DEFAULT 'queued' COMMENT 'وضعیت',
  `attempts` SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تلاش',
  `error_message` VARCHAR(500) COMMENT 'خطا',
  `started_at` DATETIME COMMENT 'شروع',
  `finished_at` DATETIME COMMENT 'پایان',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_sync_jobs_business_id` (`business_id`),
  KEY `ix_sync_jobs_integration_id` (`integration_id`),
  KEY `ix_sync_jobs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='صف همگام‌سازی — کارهای همگام‌سازی سفارش/کالا با سیستم بیرونی.';


CREATE TABLE IF NOT EXISTS `import_jobs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `entity_type` ENUM('persons','products','invoices','journal_entries','opening_balances','prices') NOT NULL COMMENT 'نوع داده',
  `attachment_id` BIGINT UNSIGNED COMMENT 'فایل اکسل',
  `total_rows` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'کل ردیف‌ها',
  `success_rows` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'موفق',
  `error_rows` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'خطادار',
  `mode` ENUM('insert','update','upsert','dry_run') NOT NULL DEFAULT 'insert' COMMENT 'حالت ورود',
  `status` ENUM('uploaded','processing','done','failed') NOT NULL DEFAULT 'uploaded' COMMENT 'وضعیت',
  `started_at` DATETIME COMMENT 'شروع',
  `finished_at` DATETIME COMMENT 'پایان',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_import_jobs_business_id` (`business_id`),
  KEY `ix_import_jobs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ورود گروهی اطلاعات — ورود اشخاص، کالا، فاکتور و سند از اکسل (صفحه «به‌روزرسانی اطلاعات»).';


CREATE TABLE IF NOT EXISTS `import_job_errors` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `import_job_id` BIGINT UNSIGNED NOT NULL COMMENT 'کار ورود',
  `row_no` INT UNSIGNED NOT NULL COMMENT 'شماره ردیف فایل',
  `column_name` VARCHAR(60) COMMENT 'ستون',
  `raw_value` VARCHAR(255) COMMENT 'مقدار خام',
  `error_message` VARCHAR(400) NOT NULL COMMENT 'پیام خطا',
  PRIMARY KEY (`id`),
  KEY `ix_import_job_errors_import_job_id` (`import_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خطاهای ورود گروهی — ردیف‌ها و ستون‌های خطادار برای اصلاح و ورود مجدد.';


CREATE TABLE IF NOT EXISTS `backup_jobs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `job_type` ENUM('manual','auto') NOT NULL DEFAULT 'auto' COMMENT 'نوع',
  `scope` ENUM('full','data_only','schema_only') NOT NULL DEFAULT 'full' COMMENT 'دامنه',
  `file_attachment_id` BIGINT UNSIGNED COMMENT 'فایل پشتیبان',
  `size_mb` DECIMAL(12,2) COMMENT 'حجم (مگابایت)',
  `status` ENUM('running','success','failed','deleted') NOT NULL DEFAULT 'running' COMMENT 'وضعیت',
  `retention_days` SMALLINT UNSIGNED NOT NULL DEFAULT 30 COMMENT 'نگهداری (روز)',
  `sent_to_email` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'ارسال به ایمیل مدیر',
  `error_message` VARCHAR(400) COMMENT 'خطا',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر عامل',
  PRIMARY KEY (`id`),
  KEY `ix_backup_jobs_business_id` (`business_id`),
  KEY `ix_backup_jobs_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پشتیبان‌گیری — پشتیبان خودکار/دستی، حجم و محل نگهداری (تنظیم «پشتیبان‌گیری روزانه»).';


CREATE TABLE IF NOT EXISTS `scheduled_jobs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `job_key` VARCHAR(60) NOT NULL COMMENT 'کلید کار مثال: cheque_reminder',
  `cron_expr` VARCHAR(60) COMMENT 'زمان‌بندی (cron)',
  `next_run_at` DATETIME COMMENT 'اجرای بعدی',
  `last_run_at` DATETIME COMMENT 'آخرین اجرا',
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  `params_json` JSON COMMENT 'پارامترها',
  `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'وضعیت فعال/غیرفعال',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان ایجاد',
  `created_by` BIGINT UNSIGNED COMMENT 'کاربر ایجادکننده',
  `updated_at` DATETIME COMMENT 'زمان آخرین ویرایش',
  `updated_by` BIGINT UNSIGNED COMMENT 'کاربر ویرایش‌کننده',
  `deleted_at` DATETIME COMMENT 'حذف نرم؛ NULL یعنی فعال',
  `row_version` INT UNSIGNED NOT NULL DEFAULT 1 COMMENT 'کنترل هم‌زمانی خوش‌بینانه',
  PRIMARY KEY (`id`),
  KEY `ix_scheduled_jobs_business_id` (`business_id`),
  KEY `ix_scheduled_jobs_next_run_at` (`next_run_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کارهای زمان‌بندی‌شده — زمان‌بندی هشدارها، اسناد تکرارشونده، پشتیبان و همگام‌سازی.';


CREATE TABLE IF NOT EXISTS `job_runs` (
  `business_id` BIGINT UNSIGNED NOT NULL COMMENT 'کسب‌وکار مالک رکورد (چند‌مستأجری)',
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'شناسه',
  `scheduled_job_id` BIGINT UNSIGNED COMMENT 'کار',
  `job_key` VARCHAR(60) NOT NULL COMMENT 'کلید کار',
  `started_at` DATETIME NOT NULL COMMENT 'شروع',
  `finished_at` DATETIME COMMENT 'پایان',
  `status` ENUM('running','success','failed','skipped') NOT NULL DEFAULT 'running' COMMENT 'وضعیت',
  `affected_count` INT UNSIGNED COMMENT 'تعداد رکورد متأثر',
  `message` VARCHAR(500) COMMENT 'پیام/خطا',
  PRIMARY KEY (`id`),
  KEY `ix_job_runs_business_id` (`business_id`),
  KEY `ix_job_runs_scheduled_job_id` (`scheduled_job_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سابقه اجرای کارها — نتیجه هر اجرا برای عیب‌یابی.';




-- ════════════════════════ فایل 02_foreign_keys.sql ════════════════════════

-- ============================================================================
-- ۰۲ — کلیدهای خارجی (پس از ساخت همه جداول اجرا شود)
-- تعداد کلید: ۵۲۴
-- قاعده: CASCADE فقط برای ردیف‌های فرزند یک سند؛ بقیه RESTRICT (اسناد حذف نمی‌شوند)
-- ============================================================================


-- businesses
ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_country_id` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_province_id` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_city_id` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_logo_attachment_id` FOREIGN KEY (`logo_attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_base_currency_id` FOREIGN KEY (`base_currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `businesses` ADD CONSTRAINT `fk_businesses_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- fiscal_years
ALTER TABLE `fiscal_years` ADD CONSTRAINT `fk_fiscal_years_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_years` ADD CONSTRAINT `fk_fiscal_years_closed_by` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_years` ADD CONSTRAINT `fk_fiscal_years_kept_earnings_account_id` FOREIGN KEY (`kept_earnings_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_years` ADD CONSTRAINT `fk_fiscal_years_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_years` ADD CONSTRAINT `fk_fiscal_years_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- fiscal_periods
ALTER TABLE `fiscal_periods` ADD CONSTRAINT `fk_fiscal_periods_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_periods` ADD CONSTRAINT `fk_fiscal_periods_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_periods` ADD CONSTRAINT `fk_fiscal_periods_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `fiscal_periods` ADD CONSTRAINT `fk_fiscal_periods_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- currencies
ALTER TABLE `currencies` ADD CONSTRAINT `fk_currencies_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `currencies` ADD CONSTRAINT `fk_currencies_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- currency_rates
ALTER TABLE `currency_rates` ADD CONSTRAINT `fk_currency_rates_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `currency_rates` ADD CONSTRAINT `fk_currency_rates_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `currency_rates` ADD CONSTRAINT `fk_currency_rates_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `currency_rates` ADD CONSTRAINT `fk_currency_rates_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- settings
ALTER TABLE `settings` ADD CONSTRAINT `fk_settings_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `settings` ADD CONSTRAINT `fk_settings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- number_sequences
ALTER TABLE `number_sequences` ADD CONSTRAINT `fk_number_sequences_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `number_sequences` ADD CONSTRAINT `fk_number_sequences_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `number_sequences` ADD CONSTRAINT `fk_number_sequences_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- projects
ALTER TABLE `projects` ADD CONSTRAINT `fk_projects_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `projects` ADD CONSTRAINT `fk_projects_manager_person_id` FOREIGN KEY (`manager_person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `projects` ADD CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `projects` ADD CONSTRAINT `fk_projects_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- cost_centers
ALTER TABLE `cost_centers` ADD CONSTRAINT `fk_cost_centers_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cost_centers` ADD CONSTRAINT `fk_cost_centers_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cost_centers` ADD CONSTRAINT `fk_cost_centers_linked_account_id` FOREIGN KEY (`linked_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cost_centers` ADD CONSTRAINT `fk_cost_centers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cost_centers` ADD CONSTRAINT `fk_cost_centers_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- attachments
ALTER TABLE `attachments` ADD CONSTRAINT `fk_attachments_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attachments` ADD CONSTRAINT `fk_attachments_uploaded_by` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attachments` ADD CONSTRAINT `fk_attachments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- audit_logs
ALTER TABLE `audit_logs` ADD CONSTRAINT `fk_audit_logs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `audit_logs` ADD CONSTRAINT `fk_audit_logs_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `audit_logs` ADD CONSTRAINT `fk_audit_logs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- provinces
ALTER TABLE `provinces` ADD CONSTRAINT `fk_provinces_country_id` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- cities
ALTER TABLE `cities` ADD CONSTRAINT `fk_cities_province_id` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- users
ALTER TABLE `users` ADD CONSTRAINT `fk_users_avatar_attachment_id` FOREIGN KEY (`avatar_attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `users` ADD CONSTRAINT `fk_users_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `users` ADD CONSTRAINT `fk_users_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- roles
ALTER TABLE `roles` ADD CONSTRAINT `fk_roles_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `roles` ADD CONSTRAINT `fk_roles_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `roles` ADD CONSTRAINT `fk_roles_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- permissions
ALTER TABLE `permissions` ADD CONSTRAINT `fk_permissions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `permissions` ADD CONSTRAINT `fk_permissions_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- role_permissions
ALTER TABLE `role_permissions` ADD CONSTRAINT `fk_role_permissions_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `role_permissions` ADD CONSTRAINT `fk_role_permissions_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;


-- user_business_roles
ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_role_id` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_default_warehouse_id` FOREIGN KEY (`default_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_default_cash_account_id` FOREIGN KEY (`default_cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_business_roles` ADD CONSTRAINT `fk_user_business_roles_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- sessions
ALTER TABLE `sessions` ADD CONSTRAINT `fk_sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `sessions` ADD CONSTRAINT `fk_sessions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- otp_codes
ALTER TABLE `otp_codes` ADD CONSTRAINT `fk_otp_codes_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- password_resets
ALTER TABLE `password_resets` ADD CONSTRAINT `fk_password_resets_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- api_clients
ALTER TABLE `api_clients` ADD CONSTRAINT `fk_api_clients_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `api_clients` ADD CONSTRAINT `fk_api_clients_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `api_clients` ADD CONSTRAINT `fk_api_clients_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- api_logs
ALTER TABLE `api_logs` ADD CONSTRAINT `fk_api_logs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `api_logs` ADD CONSTRAINT `fk_api_logs_api_client_id` FOREIGN KEY (`api_client_id`) REFERENCES `api_clients` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `api_logs` ADD CONSTRAINT `fk_api_logs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- user_settings
ALTER TABLE `user_settings` ADD CONSTRAINT `fk_user_settings_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_settings` ADD CONSTRAINT `fk_user_settings_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `user_settings` ADD CONSTRAINT `fk_user_settings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- persons
ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_country_id` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_province_id` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_city_id` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_introducer_person_id` FOREIGN KEY (`introducer_person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_marketer_id` FOREIGN KEY (`marketer_id`) REFERENCES `marketers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `persons` ADD CONSTRAINT `fk_persons_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_types
ALTER TABLE `person_types` ADD CONSTRAINT `fk_person_types_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_types` ADD CONSTRAINT `fk_person_types_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_types` ADD CONSTRAINT `fk_person_types_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_type_links
ALTER TABLE `person_type_links` ADD CONSTRAINT `fk_person_type_links_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `person_type_links` ADD CONSTRAINT `fk_person_type_links_person_type_id` FOREIGN KEY (`person_type_id`) REFERENCES `person_types` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;


-- person_contacts
ALTER TABLE `person_contacts` ADD CONSTRAINT `fk_person_contacts_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_bank_accounts
ALTER TABLE `person_bank_accounts` ADD CONSTRAINT `fk_person_bank_accounts_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_financial_settings
ALTER TABLE `person_financial_settings` ADD CONSTRAINT `fk_person_financial_settings_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_financial_settings` ADD CONSTRAINT `fk_person_financial_settings_receivable_account_id` FOREIGN KEY (`receivable_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_financial_settings` ADD CONSTRAINT `fk_person_financial_settings_payment_term_id` FOREIGN KEY (`payment_term_id`) REFERENCES `payment_terms` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_financial_settings` ADD CONSTRAINT `fk_person_financial_settings_default_price_type_id` FOREIGN KEY (`default_price_type_id`) REFERENCES `price_types` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payment_terms
ALTER TABLE `payment_terms` ADD CONSTRAINT `fk_payment_terms_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payment_terms` ADD CONSTRAINT `fk_payment_terms_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payment_terms` ADD CONSTRAINT `fk_payment_terms_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_product_prices
ALTER TABLE `person_product_prices` ADD CONSTRAINT `fk_person_product_prices_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_product_prices` ADD CONSTRAINT `fk_person_product_prices_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_product_prices` ADD CONSTRAINT `fk_person_product_prices_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_product_prices` ADD CONSTRAINT `fk_person_product_prices_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_product_prices` ADD CONSTRAINT `fk_person_product_prices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- marketers
ALTER TABLE `marketers` ADD CONSTRAINT `fk_marketers_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `marketers` ADD CONSTRAINT `fk_marketers_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `marketers` ADD CONSTRAINT `fk_marketers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `marketers` ADD CONSTRAINT `fk_marketers_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- shareholders
ALTER TABLE `shareholders` ADD CONSTRAINT `fk_shareholders_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `shareholders` ADD CONSTRAINT `fk_shareholders_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `shareholders` ADD CONSTRAINT `fk_shareholders_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `shareholders` ADD CONSTRAINT `fk_shareholders_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- person_opening_balances
ALTER TABLE `person_opening_balances` ADD CONSTRAINT `fk_person_opening_balances_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_opening_balances` ADD CONSTRAINT `fk_person_opening_balances_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_opening_balances` ADD CONSTRAINT `fk_person_opening_balances_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_opening_balances` ADD CONSTRAINT `fk_person_opening_balances_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `person_opening_balances` ADD CONSTRAINT `fk_person_opening_balances_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_categories
ALTER TABLE `product_categories` ADD CONSTRAINT `fk_product_categories_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_categories` ADD CONSTRAINT `fk_product_categories_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `product_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_categories` ADD CONSTRAINT `fk_product_categories_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_categories` ADD CONSTRAINT `fk_product_categories_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- units
ALTER TABLE `units` ADD CONSTRAINT `fk_units_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `units` ADD CONSTRAINT `fk_units_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `units` ADD CONSTRAINT `fk_units_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- products
ALTER TABLE `products` ADD CONSTRAINT `fk_products_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_category_id` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_main_unit_id` FOREIGN KEY (`main_unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_base_unit_id` FOREIGN KEY (`base_unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_default_warehouse_id` FOREIGN KEY (`default_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_accounting_account_id` FOREIGN KEY (`accounting_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_vat_rate_id` FOREIGN KEY (`vat_rate_id`) REFERENCES `taxes` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_image_attachment_id` FOREIGN KEY (`image_attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `products` ADD CONSTRAINT `fk_products_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_units
ALTER TABLE `product_units` ADD CONSTRAINT `fk_product_units_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `product_units` ADD CONSTRAINT `fk_product_units_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_barcodes
ALTER TABLE `product_barcodes` ADD CONSTRAINT `fk_product_barcodes_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `product_barcodes` ADD CONSTRAINT `fk_product_barcodes_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- price_types
ALTER TABLE `price_types` ADD CONSTRAINT `fk_price_types_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `price_types` ADD CONSTRAINT `fk_price_types_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `price_types` ADD CONSTRAINT `fk_price_types_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_prices
ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_price_type_id` FOREIGN KEY (`price_type_id`) REFERENCES `price_types` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_prices` ADD CONSTRAINT `fk_product_prices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- price_update_batches
ALTER TABLE `price_update_batches` ADD CONSTRAINT `fk_price_update_batches_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `price_update_batches` ADD CONSTRAINT `fk_price_update_batches_price_type_id` FOREIGN KEY (`price_type_id`) REFERENCES `price_types` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `price_update_batches` ADD CONSTRAINT `fk_price_update_batches_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `price_update_batches` ADD CONSTRAINT `fk_price_update_batches_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- taxes
ALTER TABLE `taxes` ADD CONSTRAINT `fk_taxes_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `taxes` ADD CONSTRAINT `fk_taxes_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `taxes` ADD CONSTRAINT `fk_taxes_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `taxes` ADD CONSTRAINT `fk_taxes_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_taxes
ALTER TABLE `product_taxes` ADD CONSTRAINT `fk_product_taxes_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `product_taxes` ADD CONSTRAINT `fk_product_taxes_tax_id` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;


-- product_attributes
ALTER TABLE `product_attributes` ADD CONSTRAINT `fk_product_attributes_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_attributes` ADD CONSTRAINT `fk_product_attributes_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_attributes` ADD CONSTRAINT `fk_product_attributes_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_variants
ALTER TABLE `product_variants` ADD CONSTRAINT `fk_product_variants_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `product_variants` ADD CONSTRAINT `fk_product_variants_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- product_warehouse_settings
ALTER TABLE `product_warehouse_settings` ADD CONSTRAINT `fk_product_warehouse_settings_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `product_warehouse_settings` ADD CONSTRAINT `fk_product_warehouse_settings_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;


-- warehouses
ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_keeper_user_id` FOREIGN KEY (`keeper_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_province_id` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_city_id` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `warehouses` ADD CONSTRAINT `fk_warehouses_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- inventory_documents
ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_dest_warehouse_id` FOREIGN KEY (`dest_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_documents` ADD CONSTRAINT `fk_inventory_documents_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- inventory_document_lines
ALTER TABLE `inventory_document_lines` ADD CONSTRAINT `fk_inventory_document_lines_document_id` FOREIGN KEY (`document_id`) REFERENCES `inventory_documents` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `inventory_document_lines` ADD CONSTRAINT `fk_inventory_document_lines_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_document_lines` ADD CONSTRAINT `fk_inventory_document_lines_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_document_lines` ADD CONSTRAINT `fk_inventory_document_lines_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `inventory_document_lines` ADD CONSTRAINT `fk_inventory_document_lines_waste_reason_id` FOREIGN KEY (`waste_reason_id`) REFERENCES `waste_reasons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- waste_reasons
ALTER TABLE `waste_reasons` ADD CONSTRAINT `fk_waste_reasons_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `waste_reasons` ADD CONSTRAINT `fk_waste_reasons_expense_account_id` FOREIGN KEY (`expense_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `waste_reasons` ADD CONSTRAINT `fk_waste_reasons_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `waste_reasons` ADD CONSTRAINT `fk_waste_reasons_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_movements
ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_movements` ADD CONSTRAINT `fk_stock_movements_document_id` FOREIGN KEY (`document_id`) REFERENCES `inventory_documents` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_cost_layers
ALTER TABLE `stock_cost_layers` ADD CONSTRAINT `fk_stock_cost_layers_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_cost_layers` ADD CONSTRAINT `fk_stock_cost_layers_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_cost_layers` ADD CONSTRAINT `fk_stock_cost_layers_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_cost_layers` ADD CONSTRAINT `fk_stock_cost_layers_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_cost_layers` ADD CONSTRAINT `fk_stock_cost_layers_document_id` FOREIGN KEY (`document_id`) REFERENCES `inventory_documents` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_layer_consumptions
ALTER TABLE `stock_layer_consumptions` ADD CONSTRAINT `fk_stock_layer_consumptions_layer_id` FOREIGN KEY (`layer_id`) REFERENCES `stock_cost_layers` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `stock_layer_consumptions` ADD CONSTRAINT `fk_stock_layer_consumptions_movement_id` FOREIGN KEY (`movement_id`) REFERENCES `stock_movements` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_balances
ALTER TABLE `stock_balances` ADD CONSTRAINT `fk_stock_balances_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_balances` ADD CONSTRAINT `fk_stock_balances_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_balances` ADD CONSTRAINT `fk_stock_balances_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_reservations
ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_reservations` ADD CONSTRAINT `fk_stock_reservations_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_counts
ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_responsible_user_id` FOREIGN KEY (`responsible_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_counts` ADD CONSTRAINT `fk_stock_counts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- stock_count_lines
ALTER TABLE `stock_count_lines` ADD CONSTRAINT `fk_stock_count_lines_stock_count_id` FOREIGN KEY (`stock_count_id`) REFERENCES `stock_counts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `stock_count_lines` ADD CONSTRAINT `fk_stock_count_lines_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `stock_count_lines` ADD CONSTRAINT `fk_stock_count_lines_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoices
ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_marketer_id` FOREIGN KEY (`marketer_id`) REFERENCES `marketers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_reference_invoice_id` FOREIGN KEY (`reference_invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_parent_invoice_id` FOREIGN KEY (`parent_invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_inventory_doc_id` FOREIGN KEY (`inventory_doc_id`) REFERENCES `inventory_documents` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoices` ADD CONSTRAINT `fk_invoices_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_lines
ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_variant_id` FOREIGN KEY (`variant_id`) REFERENCES `product_variants` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_tax_id` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_lines` ADD CONSTRAINT `fk_invoice_lines_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_charges
ALTER TABLE `invoice_charges` ADD CONSTRAINT `fk_invoice_charges_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_charges` ADD CONSTRAINT `fk_invoice_charges_tax_id` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_charges` ADD CONSTRAINT `fk_invoice_charges_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_settlements
ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_receipt_id` FOREIGN KEY (`receipt_id`) REFERENCES `receipts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_cheque_id` FOREIGN KEY (`cheque_id`) REFERENCES `cheques` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_settlements` ADD CONSTRAINT `fk_invoice_settlements_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_status_history
ALTER TABLE `invoice_status_history` ADD CONSTRAINT `fk_invoice_status_history_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_status_history` ADD CONSTRAINT `fk_invoice_status_history_changed_by` FOREIGN KEY (`changed_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_dispatches
ALTER TABLE `invoice_dispatches` ADD CONSTRAINT `fk_invoice_dispatches_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_dispatches` ADD CONSTRAINT `fk_invoice_dispatches_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_dispatches` ADD CONSTRAINT `fk_invoice_dispatches_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- invoice_commissions
ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_marketer_id` FOREIGN KEY (`marketer_id`) REFERENCES `marketers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_settled_payment_id` FOREIGN KEY (`settled_payment_id`) REFERENCES `payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `invoice_commissions` ADD CONSTRAINT `fk_invoice_commissions_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- cash_accounts
ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_gl_account_id` FOREIGN KEY (`gl_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_keeper_user_id` FOREIGN KEY (`keeper_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cash_accounts` ADD CONSTRAINT `fk_cash_accounts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payment_methods
ALTER TABLE `payment_methods` ADD CONSTRAINT `fk_payment_methods_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payment_methods` ADD CONSTRAINT `fk_payment_methods_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payment_methods` ADD CONSTRAINT `fk_payment_methods_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- receipts
ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_cheque_id` FOREIGN KEY (`cheque_id`) REFERENCES `cheques` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `receipts` ADD CONSTRAINT `fk_receipts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- receipt_lines
ALTER TABLE `receipt_lines` ADD CONSTRAINT `fk_receipt_lines_receipt_id` FOREIGN KEY (`receipt_id`) REFERENCES `receipts` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `receipt_lines` ADD CONSTRAINT `fk_receipt_lines_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payments
ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_cheque_id` FOREIGN KEY (`cheque_id`) REFERENCES `cheques` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payments` ADD CONSTRAINT `fk_payments_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payment_lines
ALTER TABLE `payment_lines` ADD CONSTRAINT `fk_payment_lines_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `payment_lines` ADD CONSTRAINT `fk_payment_lines_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payment_lines` ADD CONSTRAINT `fk_payment_lines_expense_document_id` FOREIGN KEY (`expense_document_id`) REFERENCES `expense_documents` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- transfers
ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_from_cash_account_id` FOREIGN KEY (`from_cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_to_cash_account_id` FOREIGN KEY (`to_cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_fee_cost_center_id` FOREIGN KEY (`fee_cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `transfers` ADD CONSTRAINT `fk_transfers_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- cheques
ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_spent_to_person_id` FOREIGN KEY (`spent_to_person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_receipt_id` FOREIGN KEY (`receipt_id`) REFERENCES `receipts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheques` ADD CONSTRAINT `fk_cheques_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- cheque_histories
ALTER TABLE `cheque_histories` ADD CONSTRAINT `fk_cheque_histories_cheque_id` FOREIGN KEY (`cheque_id`) REFERENCES `cheques` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `cheque_histories` ADD CONSTRAINT `fk_cheque_histories_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheque_histories` ADD CONSTRAINT `fk_cheque_histories_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `cheque_histories` ADD CONSTRAINT `fk_cheque_histories_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- bank_statements
ALTER TABLE `bank_statements` ADD CONSTRAINT `fk_bank_statements_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `bank_statements` ADD CONSTRAINT `fk_bank_statements_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `bank_statements` ADD CONSTRAINT `fk_bank_statements_attachment_id` FOREIGN KEY (`attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `bank_statements` ADD CONSTRAINT `fk_bank_statements_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- bank_statement_lines
ALTER TABLE `bank_statement_lines` ADD CONSTRAINT `fk_bank_statement_lines_bank_statement_id` FOREIGN KEY (`bank_statement_id`) REFERENCES `bank_statements` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- income_documents
ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_income_category_id` FOREIGN KEY (`income_category_id`) REFERENCES `profit_loss_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_revenue_account_id` FOREIGN KEY (`revenue_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_receipt_id` FOREIGN KEY (`receipt_id`) REFERENCES `receipts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_documents` ADD CONSTRAINT `fk_income_documents_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- income_document_lines
ALTER TABLE `income_document_lines` ADD CONSTRAINT `fk_income_document_lines_income_document_id` FOREIGN KEY (`income_document_id`) REFERENCES `income_documents` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `income_document_lines` ADD CONSTRAINT `fk_income_document_lines_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_document_lines` ADD CONSTRAINT `fk_income_document_lines_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `income_document_lines` ADD CONSTRAINT `fk_income_document_lines_tax_id` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- expense_documents
ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_expense_category_id` FOREIGN KEY (`expense_category_id`) REFERENCES `profit_loss_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_expense_account_id` FOREIGN KEY (`expense_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_attachment_id` FOREIGN KEY (`attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_recurring_rule_id` FOREIGN KEY (`recurring_rule_id`) REFERENCES `recurring_rules` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_documents` ADD CONSTRAINT `fk_expense_documents_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- expense_document_lines
ALTER TABLE `expense_document_lines` ADD CONSTRAINT `fk_expense_document_lines_expense_document_id` FOREIGN KEY (`expense_document_id`) REFERENCES `expense_documents` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `expense_document_lines` ADD CONSTRAINT `fk_expense_document_lines_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_document_lines` ADD CONSTRAINT `fk_expense_document_lines_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `expense_document_lines` ADD CONSTRAINT `fk_expense_document_lines_tax_id` FOREIGN KEY (`tax_id`) REFERENCES `taxes` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- profit_loss_categories
ALTER TABLE `profit_loss_categories` ADD CONSTRAINT `fk_profit_loss_categories_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `profit_loss_categories` ADD CONSTRAINT `fk_profit_loss_categories_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `profit_loss_categories` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `profit_loss_categories` ADD CONSTRAINT `fk_profit_loss_categories_default_account_id` FOREIGN KEY (`default_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `profit_loss_categories` ADD CONSTRAINT `fk_profit_loss_categories_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `profit_loss_categories` ADD CONSTRAINT `fk_profit_loss_categories_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- recurring_rules
ALTER TABLE `recurring_rules` ADD CONSTRAINT `fk_recurring_rules_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `recurring_rules` ADD CONSTRAINT `fk_recurring_rules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `recurring_rules` ADD CONSTRAINT `fk_recurring_rules_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- chart_of_accounts
ALTER TABLE `chart_of_accounts` ADD CONSTRAINT `fk_chart_of_accounts_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `chart_of_accounts` ADD CONSTRAINT `fk_chart_of_accounts_parent_id` FOREIGN KEY (`parent_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `chart_of_accounts` ADD CONSTRAINT `fk_chart_of_accounts_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `chart_of_accounts` ADD CONSTRAINT `fk_chart_of_accounts_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `chart_of_accounts` ADD CONSTRAINT `fk_chart_of_accounts_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- account_mappings
ALTER TABLE `account_mappings` ADD CONSTRAINT `fk_account_mappings_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_mappings` ADD CONSTRAINT `fk_account_mappings_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_mappings` ADD CONSTRAINT `fk_account_mappings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- journal_entries
ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_fiscal_period_id` FOREIGN KEY (`fiscal_period_id`) REFERENCES `fiscal_periods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entries` ADD CONSTRAINT `fk_journal_entries_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- journal_entry_lines
ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_product_id` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_project_id` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `journal_entry_lines` ADD CONSTRAINT `fk_journal_entry_lines_cheque_id` FOREIGN KEY (`cheque_id`) REFERENCES `cheques` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- auto_entry_rules
ALTER TABLE `auto_entry_rules` ADD CONSTRAINT `fk_auto_entry_rules_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `auto_entry_rules` ADD CONSTRAINT `fk_auto_entry_rules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `auto_entry_rules` ADD CONSTRAINT `fk_auto_entry_rules_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- auto_entry_rule_lines
ALTER TABLE `auto_entry_rule_lines` ADD CONSTRAINT `fk_auto_entry_rule_lines_rule_id` FOREIGN KEY (`rule_id`) REFERENCES `auto_entry_rules` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `auto_entry_rule_lines` ADD CONSTRAINT `fk_auto_entry_rule_lines_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- opening_balances
ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_warehouse_id` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `opening_balances` ADD CONSTRAINT `fk_opening_balances_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- account_period_balances
ALTER TABLE `account_period_balances` ADD CONSTRAINT `fk_account_period_balances_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_period_balances` ADD CONSTRAINT `fk_account_period_balances_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_period_balances` ADD CONSTRAINT `fk_account_period_balances_fiscal_period_id` FOREIGN KEY (`fiscal_period_id`) REFERENCES `fiscal_periods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_period_balances` ADD CONSTRAINT `fk_account_period_balances_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `account_period_balances` ADD CONSTRAINT `fk_account_period_balances_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- year_closing_logs
ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_from_fiscal_year_id` FOREIGN KEY (`from_fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_to_fiscal_year_id` FOREIGN KEY (`to_fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_closing_entry_id` FOREIGN KEY (`closing_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_opening_entry_id` FOREIGN KEY (`opening_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_ran_by` FOREIGN KEY (`ran_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `year_closing_logs` ADD CONSTRAINT `fk_year_closing_logs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- employees
ALTER TABLE `employees` ADD CONSTRAINT `fk_employees_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employees` ADD CONSTRAINT `fk_employees_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employees` ADD CONSTRAINT `fk_employees_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employees` ADD CONSTRAINT `fk_employees_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- employee_salary_settings
ALTER TABLE `employee_salary_settings` ADD CONSTRAINT `fk_employee_salary_settings_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employee_salary_settings` ADD CONSTRAINT `fk_employee_salary_settings_payment_method_id` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employee_salary_settings` ADD CONSTRAINT `fk_employee_salary_settings_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `employee_salary_settings` ADD CONSTRAINT `fk_employee_salary_settings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payroll_components
ALTER TABLE `payroll_components` ADD CONSTRAINT `fk_payroll_components_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_components` ADD CONSTRAINT `fk_payroll_components_account_id` FOREIGN KEY (`account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_components` ADD CONSTRAINT `fk_payroll_components_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_components` ADD CONSTRAINT `fk_payroll_components_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payroll_documents
ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_fiscal_period_id` FOREIGN KEY (`fiscal_period_id`) REFERENCES `fiscal_periods` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_cash_account_id` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_cost_center_id` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_journal_entry_id` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_documents` ADD CONSTRAINT `fk_payroll_documents_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payroll_document_lines
ALTER TABLE `payroll_document_lines` ADD CONSTRAINT `fk_payroll_document_lines_payroll_document_id` FOREIGN KEY (`payroll_document_id`) REFERENCES `payroll_documents` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `payroll_document_lines` ADD CONSTRAINT `fk_payroll_document_lines_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `payroll_document_lines` ADD CONSTRAINT `fk_payroll_document_lines_payment_id` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- payroll_line_items
ALTER TABLE `payroll_line_items` ADD CONSTRAINT `fk_payroll_line_items_payroll_line_id` FOREIGN KEY (`payroll_line_id`) REFERENCES `payroll_document_lines` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `payroll_line_items` ADD CONSTRAINT `fk_payroll_line_items_component_id` FOREIGN KEY (`component_id`) REFERENCES `payroll_components` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- attendance_devices
ALTER TABLE `attendance_devices` ADD CONSTRAINT `fk_attendance_devices_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_devices` ADD CONSTRAINT `fk_attendance_devices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_devices` ADD CONSTRAINT `fk_attendance_devices_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- attendance_records
ALTER TABLE `attendance_records` ADD CONSTRAINT `fk_attendance_records_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_records` ADD CONSTRAINT `fk_attendance_records_employee_id` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_records` ADD CONSTRAINT `fk_attendance_records_device_id` FOREIGN KEY (`device_id`) REFERENCES `attendance_devices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_records` ADD CONSTRAINT `fk_attendance_records_leave_type_id` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `attendance_records` ADD CONSTRAINT `fk_attendance_records_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- leave_types
ALTER TABLE `leave_types` ADD CONSTRAINT `fk_leave_types_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `leave_types` ADD CONSTRAINT `fk_leave_types_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `leave_types` ADD CONSTRAINT `fk_leave_types_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- moadian_settings
ALTER TABLE `moadian_settings` ADD CONSTRAINT `fk_moadian_settings_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `moadian_settings` ADD CONSTRAINT `fk_moadian_settings_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- moadian_invoices
ALTER TABLE `moadian_invoices` ADD CONSTRAINT `fk_moadian_invoices_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `moadian_invoices` ADD CONSTRAINT `fk_moadian_invoices_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `moadian_invoices` ADD CONSTRAINT `fk_moadian_invoices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- moadian_logs
ALTER TABLE `moadian_logs` ADD CONSTRAINT `fk_moadian_logs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `moadian_logs` ADD CONSTRAINT `fk_moadian_logs_moadian_invoice_id` FOREIGN KEY (`moadian_invoice_id`) REFERENCES `moadian_invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `moadian_logs` ADD CONSTRAINT `fk_moadian_logs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- quarterly_tax_reports
ALTER TABLE `quarterly_tax_reports` ADD CONSTRAINT `fk_quarterly_tax_reports_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `quarterly_tax_reports` ADD CONSTRAINT `fk_quarterly_tax_reports_fiscal_year_id` FOREIGN KEY (`fiscal_year_id`) REFERENCES `fiscal_years` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `quarterly_tax_reports` ADD CONSTRAINT `fk_quarterly_tax_reports_file_attachment_id` FOREIGN KEY (`file_attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `quarterly_tax_reports` ADD CONSTRAINT `fk_quarterly_tax_reports_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `quarterly_tax_reports` ADD CONSTRAINT `fk_quarterly_tax_reports_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- message_templates
ALTER TABLE `message_templates` ADD CONSTRAINT `fk_message_templates_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `message_templates` ADD CONSTRAINT `fk_message_templates_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `message_templates` ADD CONSTRAINT `fk_message_templates_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- messages
ALTER TABLE `messages` ADD CONSTRAINT `fk_messages_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `messages` ADD CONSTRAINT `fk_messages_template_id` FOREIGN KEY (`template_id`) REFERENCES `message_templates` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `messages` ADD CONSTRAINT `fk_messages_person_id` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `messages` ADD CONSTRAINT `fk_messages_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- message_credits
ALTER TABLE `message_credits` ADD CONSTRAINT `fk_message_credits_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `message_credits` ADD CONSTRAINT `fk_message_credits_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `message_credits` ADD CONSTRAINT `fk_message_credits_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- notifications
ALTER TABLE `notifications` ADD CONSTRAINT `fk_notifications_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_notifications_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `notifications` ADD CONSTRAINT `fk_notifications_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- notification_rules
ALTER TABLE `notification_rules` ADD CONSTRAINT `fk_notification_rules_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `notification_rules` ADD CONSTRAINT `fk_notification_rules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- print_templates
ALTER TABLE `print_templates` ADD CONSTRAINT `fk_print_templates_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `print_templates` ADD CONSTRAINT `fk_print_templates_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `print_templates` ADD CONSTRAINT `fk_print_templates_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- print_template_versions
ALTER TABLE `print_template_versions` ADD CONSTRAINT `fk_print_template_versions_template_id` FOREIGN KEY (`template_id`) REFERENCES `print_templates` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `print_template_versions` ADD CONSTRAINT `fk_print_template_versions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- print_logs
ALTER TABLE `print_logs` ADD CONSTRAINT `fk_print_logs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `print_logs` ADD CONSTRAINT `fk_print_logs_template_id` FOREIGN KEY (`template_id`) REFERENCES `print_templates` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `print_logs` ADD CONSTRAINT `fk_print_logs_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- support_departments
ALTER TABLE `support_departments` ADD CONSTRAINT `fk_support_departments_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `support_departments` ADD CONSTRAINT `fk_support_departments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `support_departments` ADD CONSTRAINT `fk_support_departments_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- tickets
ALTER TABLE `tickets` ADD CONSTRAINT `fk_tickets_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `tickets` ADD CONSTRAINT `fk_tickets_department_id` FOREIGN KEY (`department_id`) REFERENCES `support_departments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `tickets` ADD CONSTRAINT `fk_tickets_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `tickets` ADD CONSTRAINT `fk_tickets_assignee_id` FOREIGN KEY (`assignee_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `tickets` ADD CONSTRAINT `fk_tickets_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- ticket_messages
ALTER TABLE `ticket_messages` ADD CONSTRAINT `fk_ticket_messages_ticket_id` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

ALTER TABLE `ticket_messages` ADD CONSTRAINT `fk_ticket_messages_sender_user_id` FOREIGN KEY (`sender_user_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `ticket_messages` ADD CONSTRAINT `fk_ticket_messages_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- plans
ALTER TABLE `plans` ADD CONSTRAINT `fk_plans_currency_id` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `plans` ADD CONSTRAINT `fk_plans_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `plans` ADD CONSTRAINT `fk_plans_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- plan_features
ALTER TABLE `plan_features` ADD CONSTRAINT `fk_plan_features_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;


-- subscriptions
ALTER TABLE `subscriptions` ADD CONSTRAINT `fk_subscriptions_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscriptions` ADD CONSTRAINT `fk_subscriptions_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscriptions` ADD CONSTRAINT `fk_subscriptions_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscriptions` ADD CONSTRAINT `fk_subscriptions_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- subscription_usage
ALTER TABLE `subscription_usage` ADD CONSTRAINT `fk_subscription_usage_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscription_usage` ADD CONSTRAINT `fk_subscription_usage_subscription_id` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- subscription_payments
ALTER TABLE `subscription_payments` ADD CONSTRAINT `fk_subscription_payments_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscription_payments` ADD CONSTRAINT `fk_subscription_payments_subscription_id` FOREIGN KEY (`subscription_id`) REFERENCES `subscriptions` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscription_payments` ADD CONSTRAINT `fk_subscription_payments_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `plans` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscription_payments` ADD CONSTRAINT `fk_subscription_payments_invoice_id` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `subscription_payments` ADD CONSTRAINT `fk_subscription_payments_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- integrations
ALTER TABLE `integrations` ADD CONSTRAINT `fk_integrations_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `integrations` ADD CONSTRAINT `fk_integrations_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- sync_jobs
ALTER TABLE `sync_jobs` ADD CONSTRAINT `fk_sync_jobs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `sync_jobs` ADD CONSTRAINT `fk_sync_jobs_integration_id` FOREIGN KEY (`integration_id`) REFERENCES `integrations` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `sync_jobs` ADD CONSTRAINT `fk_sync_jobs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- import_jobs
ALTER TABLE `import_jobs` ADD CONSTRAINT `fk_import_jobs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `import_jobs` ADD CONSTRAINT `fk_import_jobs_attachment_id` FOREIGN KEY (`attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `import_jobs` ADD CONSTRAINT `fk_import_jobs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- import_job_errors
ALTER TABLE `import_job_errors` ADD CONSTRAINT `fk_import_job_errors_import_job_id` FOREIGN KEY (`import_job_id`) REFERENCES `import_jobs` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- backup_jobs
ALTER TABLE `backup_jobs` ADD CONSTRAINT `fk_backup_jobs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `backup_jobs` ADD CONSTRAINT `fk_backup_jobs_file_attachment_id` FOREIGN KEY (`file_attachment_id`) REFERENCES `attachments` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `backup_jobs` ADD CONSTRAINT `fk_backup_jobs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- scheduled_jobs
ALTER TABLE `scheduled_jobs` ADD CONSTRAINT `fk_scheduled_jobs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `scheduled_jobs` ADD CONSTRAINT `fk_scheduled_jobs_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `scheduled_jobs` ADD CONSTRAINT `fk_scheduled_jobs_updated_by` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;


-- job_runs
ALTER TABLE `job_runs` ADD CONSTRAINT `fk_job_runs_business_id` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

ALTER TABLE `job_runs` ADD CONSTRAINT `fk_job_runs_scheduled_job_id` FOREIGN KEY (`scheduled_job_id`) REFERENCES `scheduled_jobs` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;




-- ════════════════════════ فایل 03_views.sql ════════════════════════

-- ============================================================================
-- ۰۳ — نماهای گزارش‌گیری (۲۵ View)
-- هر نما متناظر یک گزارش/کارت پنل است. نماها فقط-خواندنی‌اند و روی داده‌های
-- «ثبت‌شده» (posted و غیرحذف‌شده) عمل می‌کنند تا با دفاتر حسابداری تراز باشند.
-- نکته: نماهای صورتی مالی (ترازنامه/سود و زیان) در سطح «حساب × تاریخ» تجمیع
-- شده‌اند تا لایه گزارش بتواند بازه/تاریخ مشخص را فیلتر و جمع بزند.
-- ============================================================================

-- ۱) مانده بدهکار/بستانکار هر شخص در سال مالی (بدهکاران و بستانکاران)
CREATE OR REPLACE VIEW `v_person_balances` AS
SELECT x.business_id,
       x.fiscal_year_id,
       x.person_id,
       p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       p.person_kind,
       SUM(x.debit_amount)  AS total_debit,
       SUM(x.credit_amount) AS total_credit,
       SUM(x.debit_amount - x.credit_amount) AS balance_amount
FROM (
  SELECT je.business_id, je.fiscal_year_id, jel.person_id, jel.debit_amount, jel.credit_amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted' AND je.entry_type <> 'opening'
    JOIN chart_of_accounts a ON a.id = jel.account_id AND a.person_required = 1
   WHERE jel.person_id IS NOT NULL
  UNION ALL
  SELECT ob.business_id, ob.fiscal_year_id, ob.person_id, ob.debit_amount, ob.credit_amount
    FROM person_opening_balances ob
) x
LEFT JOIN persons p ON p.id = x.person_id
GROUP BY x.business_id, x.fiscal_year_id, x.person_id, p.code, p.first_name, p.last_name, p.company_name, p.person_kind;


-- ۲) ریز سنی مطالبات (۰-۳۰، ۳۱-۶۰، ۶۱-۹۰، بیش از ۹۰ روز)
CREATE OR REPLACE VIEW `v_receivable_aging` AS
SELECT i.business_id, i.fiscal_year_id, i.id AS invoice_id, i.invoice_no, i.invoice_date, i.due_date,
       i.person_id, p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       i.total_amount, i.paid_amount, i.remaining_amount,
       DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) AS days_overdue,
       CASE WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 0 THEN 'not_due'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 30 THEN 'd0_30'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 60 THEN 'd31_60'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 90 THEN 'd61_90'
            ELSE 'd90_plus' END AS aging_bucket
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id
WHERE i.invoice_type IN ('sale','sale_return')
  AND i.status NOT IN ('draft','cancelled')
  AND i.remaining_amount > 0;


-- ۳) ریز سنی بدهی‌ها به تأمین‌کنندگان
CREATE OR REPLACE VIEW `v_payable_aging` AS
SELECT i.business_id, i.fiscal_year_id, i.id AS invoice_id, i.invoice_no, i.invoice_date, i.due_date,
       i.person_id, p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       i.total_amount, i.paid_amount, i.remaining_amount,
       DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) AS days_overdue,
       CASE WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 0 THEN 'not_due'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 30 THEN 'd0_30'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 60 THEN 'd31_60'
            WHEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) <= 90 THEN 'd61_90'
            ELSE 'd90_plus' END AS aging_bucket
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id
WHERE i.invoice_type IN ('buy','buy_return')
  AND i.status NOT IN ('draft','cancelled')
  AND i.remaining_amount > 0;


-- ۴) موجودی قابل فروش هر کالا در هر انبار
CREATE OR REPLACE VIEW `v_stock_available` AS
SELECT sb.business_id, sb.warehouse_id, w.title AS warehouse_title,
       sb.product_id, pr.code AS product_code, pr.title AS product_title, pr.item_type,
       pr.main_unit_id, u.title AS unit_title,
       sb.variant_id, sb.quantity, sb.reserved_quantity, sb.available_quantity,
       sb.avg_unit_cost, ROUND(sb.quantity * IFNULL(sb.avg_unit_cost,0), 2) AS stock_value,
       sb.last_movement_at
FROM stock_balances sb
JOIN products pr ON pr.id = sb.product_id
LEFT JOIN units u ON u.id = pr.main_unit_id
JOIN warehouses w ON w.id = sb.warehouse_id;


-- ۵) کارت حساب کالا با مانده تجمعی (کاردکس)
CREATE OR REPLACE VIEW `v_stock_card` AS
SELECT sm.business_id, sm.fiscal_year_id, sm.id AS movement_id, sm.movement_date,
       sm.warehouse_id, w.title AS warehouse_title,
       sm.product_id, pr.code AS product_code, pr.title AS product_title,
       sm.variant_id, sm.direction, sm.quantity, sm.unit_cost, sm.total_cost, sm.balance_after,
       d.doc_type, d.doc_no, sm.source_type, sm.source_id
FROM stock_movements sm
JOIN products pr ON pr.id = sm.product_id
JOIN warehouses w ON w.id = sm.warehouse_id
LEFT JOIN inventory_documents d ON d.id = sm.document_id;


-- ۶) ارزش موجودی انبار به تفکیک انبار و دسته‌بندی
CREATE OR REPLACE VIEW `v_inventory_value` AS
SELECT sb.business_id, sb.warehouse_id, w.title AS warehouse_title,
       pr.category_id, c.title AS category_title,
       COUNT(DISTINCT sb.product_id) AS product_count,
       SUM(sb.quantity) AS total_quantity,
       ROUND(SUM(sb.quantity * IFNULL(sb.avg_unit_cost,0)), 2) AS inventory_value
FROM stock_balances sb
JOIN products pr ON pr.id = sb.product_id
JOIN warehouses w ON w.id = sb.warehouse_id
LEFT JOIN product_categories c ON c.id = pr.category_id
GROUP BY sb.business_id, sb.warehouse_id, w.title, pr.category_id, c.title;


-- ۷) کالاهای رسیده به نقطه سفارش (هشدار کمبود موجودی)
CREATE OR REPLACE VIEW `v_low_stock` AS
SELECT sb.business_id, sb.warehouse_id, w.title AS warehouse_title,
       sb.product_id, pr.code AS product_code, pr.title AS product_title,
       sb.quantity, sb.reserved_quantity, sb.available_quantity,
       IFNULL(pws.reorder_point, IFNULL(pr.reorder_point,0)) AS reorder_point,
       IFNULL(pws.reorder_point, IFNULL(pr.reorder_point,0)) - sb.available_quantity AS shortage_quantity
FROM stock_balances sb
JOIN products pr ON pr.id = sb.product_id
JOIN warehouses w ON w.id = sb.warehouse_id
LEFT JOIN product_warehouse_settings pws
       ON pws.product_id = sb.product_id AND pws.warehouse_id = sb.warehouse_id
WHERE pr.item_type = 'goods'
  AND IFNULL(pws.reorder_point, IFNULL(pr.reorder_point,0)) > 0
  AND sb.available_quantity <= IFNULL(pws.reorder_point, IFNULL(pr.reorder_point,0));


-- ۸) تراز آزمایشی چهارستونه (گردش و مانده بدهکار/بستانکار هر حساب)
CREATE OR REPLACE VIEW `v_trial_balance` AS
SELECT x.business_id, x.fiscal_year_id, x.account_id,
       a.code AS account_code, a.title AS account_title, a.account_type, a.nature, a.level_no,
       SUM(x.opening_debit)  AS opening_debit,
       SUM(x.opening_credit) AS opening_credit,
       SUM(x.turn_debit)     AS turn_debit,
       SUM(x.turn_credit)    AS turn_credit,
       SUM(x.opening_debit + x.turn_debit)   AS closing_debit_total,
       SUM(x.opening_credit + x.turn_credit) AS closing_credit_total,
       SUM(x.opening_debit - x.opening_credit + x.turn_debit - x.turn_credit) AS balance_amount
FROM (
  SELECT je.business_id, je.fiscal_year_id, jel.account_id,
         0 AS opening_debit, 0 AS opening_credit, jel.debit_amount AS turn_debit, jel.credit_amount AS turn_credit
    FROM journal_entry_lines jel
    JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted' AND je.entry_type <> 'opening'
  UNION ALL
  SELECT ob.business_id, ob.fiscal_year_id, ob.account_id,
         ob.debit_amount, ob.credit_amount, 0, 0
    FROM opening_balances ob
) x
JOIN chart_of_accounts a ON a.id = x.account_id
GROUP BY x.business_id, x.fiscal_year_id, x.account_id, a.code, a.title, a.account_type, a.nature, a.level_no;


-- ۹) دفتر حساب‌ها با مانده تجمعی
CREATE OR REPLACE VIEW `v_ledger_account` AS
SELECT je.business_id, je.fiscal_year_id, jel.account_id,
       a.code AS account_code, a.title AS account_title, a.account_type,
       je.id AS journal_entry_id, je.entry_no, je.entry_date, je.entry_type,
       jel.row_no, jel.description, jel.person_id, jel.cost_center_id, jel.project_id,
       jel.debit_amount, jel.credit_amount,
       SUM(jel.debit_amount - jel.credit_amount)
         OVER (PARTITION BY je.business_id, je.fiscal_year_id, jel.account_id
               ORDER BY je.entry_date, je.entry_no, jel.row_no) AS running_balance
FROM journal_entry_lines jel
JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted'
JOIN chart_of_accounts a ON a.id = jel.account_id;


-- ۱۰) دفتر روزنامه (اسناد با آرتیکل‌ها)
CREATE OR REPLACE VIEW `v_journal_book` AS
SELECT je.business_id, je.fiscal_year_id, je.id AS journal_entry_id, je.entry_no, je.entry_date,
       je.entry_type, je.source, je.status, je.description AS entry_description,
       je.total_debit, je.total_credit, je.line_count,
       jel.row_no, jel.account_id, a.code AS account_code, a.title AS account_title,
       jel.description AS line_description, jel.debit_amount, jel.credit_amount,
       jel.person_id, jel.cost_center_id, jel.project_id
FROM journal_entries je
JOIN journal_entry_lines jel ON jel.journal_entry_id = je.id
LEFT JOIN chart_of_accounts a ON a.id = jel.account_id;


-- ۱۱) صورت سود و زیان (درآمد − بهای تمام‌شده − هزینه‌ها)
CREATE OR REPLACE VIEW `v_income_statement` AS
SELECT je.business_id, je.fiscal_year_id, je.entry_date,
       a.id AS account_id, a.code AS account_code, a.title AS account_title, a.account_type,
       jel.cost_center_id, cc.name AS cost_center_name, jel.project_id,
       SUM(jel.debit_amount)  AS debit_total,
       SUM(jel.credit_amount) AS credit_total,
       SUM(CASE WHEN a.nature = 'credit' THEN jel.credit_amount - jel.debit_amount
                ELSE jel.debit_amount - jel.credit_amount END) AS net_amount
FROM journal_entry_lines jel
JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted'
JOIN chart_of_accounts a ON a.id = jel.account_id AND a.account_type IN ('revenue','cogs','expense')
LEFT JOIN cost_centers cc ON cc.id = jel.cost_center_id
GROUP BY je.business_id, je.fiscal_year_id, je.entry_date, a.id, a.code, a.title, a.account_type,
         jel.cost_center_id, cc.name, jel.project_id;


-- ۱۲) ترازنامه (دارایی/بدهی/سرمایه) به تفکیک حساب و تاریخ
CREATE OR REPLACE VIEW `v_balance_sheet` AS
SELECT je.business_id, je.fiscal_year_id, je.entry_date,
       a.id AS account_id, a.code AS account_code, a.title AS account_title, a.account_type, a.level_no,
       SUM(jel.debit_amount)  AS debit_total,
       SUM(jel.credit_amount) AS credit_total,
       SUM(jel.debit_amount - jel.credit_amount) AS balance_amount
FROM journal_entry_lines jel
JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted'
JOIN chart_of_accounts a ON a.id = jel.account_id AND a.account_type IN ('asset','liability','equity')
GROUP BY je.business_id, je.fiscal_year_id, je.entry_date, a.id, a.code, a.title, a.account_type, a.level_no;


-- ۱۳) صورت تغییرات سرمایه
CREATE OR REPLACE VIEW `v_equity_changes` AS
SELECT je.business_id, je.fiscal_year_id,
       a.id AS account_id, a.code AS account_code, a.title AS account_title,
       MIN(je.entry_date) AS first_entry_date, MAX(je.entry_date) AS last_entry_date,
       SUM(jel.debit_amount) AS debit_total, SUM(jel.credit_amount) AS credit_total,
       SUM(jel.credit_amount - jel.debit_amount) AS net_change,
       MAX(sh.shareholder_count) AS shareholder_count,
       MAX(sh.declared_capital) AS declared_capital
FROM journal_entry_lines jel
JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted'
JOIN chart_of_accounts a ON a.id = jel.account_id AND a.account_type = 'equity'
LEFT JOIN (
  SELECT business_id, COUNT(*) AS shareholder_count, SUM(capital_amount) AS declared_capital
    FROM shareholders
   WHERE effective_to IS NULL
   GROUP BY business_id
) sh ON sh.business_id = je.business_id
GROUP BY je.business_id, je.fiscal_year_id, a.id, a.code, a.title;


-- ۱۴) سود هر فاکتور و حاشیه سود
CREATE OR REPLACE VIEW `v_profit_per_invoice` AS
SELECT i.business_id, i.fiscal_year_id, i.id AS invoice_id, i.invoice_type, i.invoice_no, i.invoice_date,
       i.person_id, p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       i.total_amount, i.cost_amount, i.profit_amount,
       ROUND(i.profit_amount / NULLIF(i.total_amount,0) * 100, 2) AS profit_percent
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id
WHERE i.invoice_type IN ('sale','sale_return')
  AND i.status NOT IN ('draft','cancelled');


-- ۱۵) خرید و فروش به تفکیک کالا (با سود ناخالص)
CREATE OR REPLACE VIEW `v_sales_by_item` AS
SELECT i.business_id, i.fiscal_year_id, il.product_id,
       pr.code AS product_code, pr.title AS product_title, pr.item_type,
       SUM(CASE WHEN i.invoice_type = 'sale' THEN il.base_quantity ELSE 0 END) AS sold_quantity,
       SUM(CASE WHEN i.invoice_type = 'sale' THEN il.line_total    ELSE 0 END) AS sold_amount,
       SUM(CASE WHEN i.invoice_type = 'buy'  THEN il.base_quantity ELSE 0 END) AS bought_quantity,
       SUM(CASE WHEN i.invoice_type = 'buy'  THEN il.line_total    ELSE 0 END) AS bought_amount,
       SUM(CASE WHEN i.invoice_type = 'sale' THEN IFNULL(il.unit_cost,0) * il.base_quantity ELSE 0 END) AS sold_cost_amount,
       SUM(CASE WHEN i.invoice_type = 'sale' THEN il.line_total - IFNULL(il.unit_cost,0) * il.base_quantity ELSE 0 END) AS gross_profit_amount
FROM invoice_lines il
JOIN invoices i ON i.id = il.invoice_id AND i.status NOT IN ('draft','cancelled')
JOIN products pr ON pr.id = il.product_id
GROUP BY i.business_id, i.fiscal_year_id, il.product_id, pr.code, pr.title, pr.item_type;


-- ۱۶) فروش و پورسانت به تفکیک بازاریاب
CREATE OR REPLACE VIEW `v_sales_by_marketer` AS
SELECT i.business_id, i.fiscal_year_id, i.marketer_id,
       m.code AS marketer_code, m.full_name AS marketer_name, m.commission_percent,
       COUNT(DISTINCT i.id) AS invoice_count,
       SUM(i.total_amount) AS sales_amount,
       SUM(IFNULL(ic.base_amount,0)) AS commission_base_amount,
       SUM(IFNULL(ic.commission_amount,0)) AS commission_amount
FROM invoices i
JOIN marketers m ON m.id = i.marketer_id
LEFT JOIN invoice_commissions ic ON ic.invoice_id = i.id AND ic.marketer_id = i.marketer_id
WHERE i.invoice_type = 'sale' AND i.status NOT IN ('draft','cancelled')
GROUP BY i.business_id, i.fiscal_year_id, i.marketer_id, m.code, m.full_name, m.commission_percent;


-- ۱۷) خلاصه فاکتور به تفکیک شخص
CREATE OR REPLACE VIEW `v_sales_by_person` AS
SELECT i.business_id, i.fiscal_year_id, i.person_id,
       p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       COUNT(DISTINCT CASE WHEN i.invoice_type = 'sale' THEN i.id END) AS sale_invoice_count,
       COUNT(DISTINCT CASE WHEN i.invoice_type = 'buy'  THEN i.id END) AS buy_invoice_count,
       SUM(CASE WHEN i.invoice_type = 'sale' THEN i.total_amount ELSE 0 END) AS sales_amount,
       SUM(CASE WHEN i.invoice_type = 'buy'  THEN i.total_amount ELSE 0 END) AS purchase_amount,
       SUM(i.paid_amount) AS paid_amount,
       SUM(i.remaining_amount) AS remaining_amount,
       MAX(i.invoice_date) AS last_invoice_date
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id
WHERE i.status NOT IN ('draft','cancelled')
GROUP BY i.business_id, i.fiscal_year_id, i.person_id, p.code, p.first_name, p.last_name, p.company_name;


-- ۱۸) چک‌های نزدیک سررسید (گزارش با شرط days_to_due <= N فیلتر می‌کند)
CREATE OR REPLACE VIEW `v_cheques_due` AS
SELECT c.business_id, c.id AS cheque_id, c.direction, c.cheque_no, c.bank_name, c.branch_name,
       c.sayad_id, c.person_id, p.code AS person_code, p.company_name AS person_company,
       c.amount, c.issue_date, c.due_date, c.status,
       DATEDIFF(c.due_date, CURDATE()) AS days_to_due,
       c.cash_account_id, ca.title AS cash_account_title
FROM cheques c
LEFT JOIN persons p ON p.id = c.person_id
LEFT JOIN cash_accounts ca ON ca.id = c.cash_account_id
WHERE c.status IN ('in_hand','deposited');


-- ۱۹) گردش حساب بانک/صندوق/تنخواه با مانده تجمعی
-- نکته مهم: چک در جریان (in_hand) هنوز پول نقد نیست و در گردش نقدی نمی‌آید؛
-- فقط چک وصول‌شده (cleared) وارد گردش می‌شود. فاکتورهای نقدی نیز مستقیماً (بدون
-- سند دریافت جداگانه) در گردش می‌آیند تا شمارش مضاعف رخ ندهد.
CREATE OR REPLACE VIEW `v_cash_flow_account` AS
SELECT m.business_id, m.fiscal_year_id, m.cash_account_id, ca.title AS cash_account_title, ca.account_kind,
       m.doc_date, m.doc_type, m.doc_no, m.ref_id,
       m.amount_in, m.amount_out,
       SUM(m.amount_in - m.amount_out)
         OVER (PARTITION BY m.cash_account_id ORDER BY m.doc_date, m.ref_id) AS running_balance
FROM (
  SELECT r.business_id, r.fiscal_year_id, r.cash_account_id, r.doc_date, 'receipt' AS doc_type,
         r.doc_no, r.id AS ref_id, r.amount AS amount_in, 0 AS amount_out
    FROM receipts r
   WHERE r.status <> 'cancelled' AND r.cheque_id IS NULL
  UNION ALL
  SELECT p.business_id, p.fiscal_year_id, p.cash_account_id, p.doc_date, 'payment',
         p.doc_no, p.id, 0, p.amount
    FROM payments p
   WHERE p.status <> 'cancelled' AND p.cheque_id IS NULL
  UNION ALL
  SELECT t.business_id, t.fiscal_year_id, t.from_cash_account_id, t.doc_date, 'transfer_out',
         t.doc_no, t.id, 0, t.amount + IFNULL(t.fee_amount,0)
    FROM transfers t WHERE t.status <> 'cancelled'
  UNION ALL
  SELECT t.business_id, t.fiscal_year_id, t.to_cash_account_id, t.doc_date, 'transfer_in',
         t.doc_no, t.id, t.amount, 0
    FROM transfers t WHERE t.status <> 'cancelled'
  UNION ALL
  SELECT i.business_id, i.fiscal_year_id, i.cash_account_id, i.invoice_date,
         CONCAT('invoice_', i.invoice_type), i.invoice_no, i.id,
         CASE WHEN i.invoice_type = 'sale'        THEN i.total_amount
              WHEN i.invoice_type = 'buy_return'  THEN i.total_amount ELSE 0 END,
         CASE WHEN i.invoice_type = 'buy'         THEN i.total_amount
              WHEN i.invoice_type = 'sale_return' THEN i.total_amount ELSE 0 END
    FROM invoices i
   WHERE i.status NOT IN ('draft','cancelled') AND i.settlement_type = 'cash' AND i.cash_account_id IS NOT NULL
  UNION ALL
  SELECT c.business_id, NULL AS fiscal_year_id, c.cash_account_id, DATE(c.cleared_at), 'cheque_in',
         c.cheque_no, c.id, c.amount, 0
    FROM cheques c
   WHERE c.direction = 'received' AND c.status = 'cleared' AND c.cleared_at IS NOT NULL
  UNION ALL
  SELECT c.business_id, NULL AS fiscal_year_id, c.cash_account_id, DATE(c.cleared_at), 'cheque_out',
         c.cheque_no, c.id, 0, c.amount
    FROM cheques c
   WHERE c.direction = 'issued' AND c.status = 'cleared' AND c.cleared_at IS NOT NULL
) m
JOIN cash_accounts ca ON ca.id = m.cash_account_id;


-- ۲۰) گزارش مالیات بر ارزش افزوده دوره
CREATE OR REPLACE VIEW `v_vat_report` AS
SELECT i.business_id, i.fiscal_year_id,
       DATE_FORMAT(i.invoice_date, '%Y-%m') AS period_month,
       il.tax_id, t.title AS tax_title, t.rate_percent,
       SUM(CASE WHEN i.invoice_type = 'sale'        THEN il.tax_amount
                WHEN i.invoice_type = 'sale_return' THEN -il.tax_amount ELSE 0 END) AS output_vat,
       SUM(CASE WHEN i.invoice_type = 'buy'         THEN il.tax_amount
                WHEN i.invoice_type = 'buy_return'  THEN -il.tax_amount ELSE 0 END) AS input_vat,
       SUM(CASE WHEN i.invoice_type = 'sale'        THEN il.tax_amount
                WHEN i.invoice_type = 'sale_return' THEN -il.tax_amount
                WHEN i.invoice_type = 'buy'         THEN -il.tax_amount
                WHEN i.invoice_type = 'buy_return'  THEN il.tax_amount ELSE 0 END) AS payable_vat,
       SUM(CASE WHEN i.invoice_type IN ('sale','sale_return') THEN il.line_total ELSE 0 END) AS sales_base_amount,
       SUM(CASE WHEN i.invoice_type IN ('buy','buy_return')   THEN il.line_total ELSE 0 END) AS purchase_base_amount
FROM invoice_lines il
JOIN invoices i ON i.id = il.invoice_id AND i.status NOT IN ('draft','cancelled')
LEFT JOIN taxes t ON t.id = il.tax_id
WHERE il.tax_amount <> 0
GROUP BY i.business_id, i.fiscal_year_id, DATE_FORMAT(i.invoice_date, '%Y-%m'), il.tax_id, t.title, t.rate_percent;


-- ۲۱) صورت معاملات فصلی (خروجی فایل TTMS)
CREATE OR REPLACE VIEW `v_quarterly_transactions` AS
SELECT i.business_id, i.fiscal_year_id,
       CONCAT(YEAR(i.invoice_date), '-Q', QUARTER(i.invoice_date)) AS gregorian_quarter,
       i.id AS invoice_id, i.invoice_type, i.invoice_no, i.invoice_date, i.settlement_type,
       i.person_id, p.code AS person_code, p.person_kind,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       p.national_id, p.national_legal_id, p.economic_code,
       i.subtotal, i.line_discount, i.invoice_discount, i.tax_amount, i.charges_amount,
       i.total_amount, i.currency_id, i.fx_rate
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id
WHERE i.invoice_type IN ('sale','buy','sale_return','buy_return')
  AND i.status NOT IN ('draft','cancelled');


-- ۲۲) کارت‌های داشبورد (یک ردیف به ازای هر کسب‌وکار)
CREATE OR REPLACE VIEW `v_dashboard_kpi` AS
SELECT b.id AS business_id, b.name AS business_name, CURDATE() AS report_date,
       (SELECT IFNULL(SUM(i.total_amount),0) FROM invoices i
         WHERE i.business_id = b.id AND i.invoice_type = 'sale' AND i.status NOT IN ('draft','cancelled')
           AND YEAR(i.invoice_date) = YEAR(CURDATE()) AND MONTH(i.invoice_date) = MONTH(CURDATE())) AS month_sales_amount,
       (SELECT IFNULL(SUM(i.total_amount),0) FROM invoices i
         WHERE i.business_id = b.id AND i.invoice_type = 'buy' AND i.status NOT IN ('draft','cancelled')
           AND YEAR(i.invoice_date) = YEAR(CURDATE()) AND MONTH(i.invoice_date) = MONTH(CURDATE())) AS month_purchase_amount,
       (SELECT IFNULL(SUM(d.amount),0) FROM income_documents d
         WHERE d.business_id = b.id AND d.status = 'posted'
           AND YEAR(d.doc_date) = YEAR(CURDATE()) AND MONTH(d.doc_date) = MONTH(CURDATE())) AS month_income_amount,
       (SELECT IFNULL(SUM(d.amount),0) FROM expense_documents d
         WHERE d.business_id = b.id AND d.status = 'posted'
           AND YEAR(d.doc_date) = YEAR(CURDATE()) AND MONTH(d.doc_date) = MONTH(CURDATE())) AS month_expense_amount,
       (SELECT IFNULL(SUM(ca.current_balance),0) FROM cash_accounts ca
         WHERE ca.business_id = b.id AND ca.account_kind IN ('bank','cash_box','petty_cash')) AS cash_and_bank_balance,
       (SELECT IFNULL(SUM(i.remaining_amount),0) FROM invoices i
         WHERE i.business_id = b.id AND i.invoice_type IN ('sale','sale_return')
           AND i.status NOT IN ('draft','cancelled') AND i.remaining_amount > 0) AS receivable_amount,
       (SELECT IFNULL(SUM(i.remaining_amount),0) FROM invoices i
         WHERE i.business_id = b.id AND i.invoice_type IN ('buy','buy_return')
           AND i.status NOT IN ('draft','cancelled') AND i.remaining_amount > 0) AS payable_amount,
       (SELECT ROUND(IFNULL(SUM(sb.quantity * IFNULL(sb.avg_unit_cost,0)),0), 2) FROM stock_balances sb
         WHERE sb.business_id = b.id) AS inventory_value,
       (SELECT COUNT(*) FROM cheques c
         WHERE c.business_id = b.id AND c.status IN ('in_hand','deposited')
           AND c.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)) AS due_cheques_count,
       (SELECT COUNT(*) FROM invoices i
         WHERE i.business_id = b.id AND i.settlement_status = 'overdue'
           AND i.status NOT IN ('draft','cancelled')) AS overdue_invoice_count
FROM businesses b
WHERE b.status = 'faal';


-- ۲۳) فهرست فاکتورها با وضعیت تسویه و تأخیر
CREATE OR REPLACE VIEW `v_invoice_list` AS
SELECT i.business_id, i.fiscal_year_id, i.id AS invoice_id, i.invoice_type, i.invoice_no, i.invoice_date, i.due_date,
       i.person_id, p.code AS person_code,
       COALESCE(NULLIF(TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''))),''), p.company_name) AS person_name,
       i.settlement_type, i.currency_id, i.fx_rate,
       i.subtotal, i.line_discount, i.invoice_discount, i.tax_amount, i.charges_amount,
       i.total_amount, i.paid_amount, i.remaining_amount, i.cost_amount, i.profit_amount,
       i.status, i.settlement_status, i.journal_entry_id, i.inventory_doc_id,
       CASE WHEN i.status NOT IN ('draft','cancelled') AND i.remaining_amount > 0
                 AND IFNULL(i.due_date, i.invoice_date) < CURDATE()
            THEN DATEDIFF(CURDATE(), IFNULL(i.due_date, i.invoice_date)) ELSE 0 END AS days_overdue,
       i.description, i.created_at
FROM invoices i
LEFT JOIN persons p ON p.id = i.person_id;


-- ۲۴) رهگیری تغییرات (قبل/بعد) با کاربر و IP
CREATE OR REPLACE VIEW `v_audit_trail` AS
SELECT al.business_id, al.id AS log_id, al.created_at, al.user_id, u.full_name AS user_name,
       al.action, al.entity_type, al.entity_id, al.before_json, al.after_json,
       al.device_type, INET6_NTOA(al.ip_address) AS ip_text, al.user_agent
FROM audit_logs al
LEFT JOIN users u ON u.id = al.user_id;


-- ۲۵) لاگ فعالیت کاربران (ورود/خروج و نشست‌های فعال)
CREATE OR REPLACE VIEW `v_user_activity` AS
SELECT al.business_id, al.user_id, u.full_name AS user_name, u.mobile, u.status AS user_status,
       al.action, al.created_at, al.device_type,
       INET6_NTOA(al.ip_address) AS ip_text, al.user_agent,
       (SELECT COUNT(*) FROM sessions s WHERE s.user_id = al.user_id AND s.revoked_at IS NULL) AS active_session_count,
       (SELECT MAX(s.expires_at) FROM sessions s
         WHERE s.user_id = al.user_id AND s.revoked_at IS NULL) AS last_session_expires_at
FROM audit_logs al
LEFT JOIN users u ON u.id = al.user_id
WHERE al.action IN ('login','logout','lock','unlock');




-- ════════════════════════ فایل 04_reference_data.sql ════════════════════════

-- ============================================================================
-- ۰۴ — داده مرجع سیستمی (کشور، استان، شهر، ارز، مجوزها، پکیج‌ها)
-- این داده‌ها وابسته به کسب‌وکار نیستند و برای همه نصب‌ها یکسان‌اند.
-- اجرای مکرر این فایل بی‌خطر است (INSERT IGNORE با شناسه ثابت).
-- ============================================================================

INSERT IGNORE INTO `countries` (`id`, `name`, `iso2`) VALUES
  (1, 'ایران', 'IR'),
  (2, 'افغانستان', 'AF'),
  (3, 'ترکیه', 'TR'),
  (4, 'امارات متحده عربی', 'AE'),
  (5, 'عراق', 'IQ'),
  (6, 'چین', 'CN'),
  (7, 'آلمان', 'DE'),
  (8, 'هند', 'IN'),
  (9, 'پاکستان', 'PK'),
  (10, 'روسیه', 'RU'),
  (11, 'ژاپن', 'JP'),
  (12, 'کره جنوبی', 'KR'),
  (13, 'مالزی', 'MY'),
  (14, 'عربستان سعودی', 'SA'),
  (15, 'قطر', 'QA'),
  (16, 'کویت', 'KW'),
  (17, 'عمان', 'OM'),
  (18, 'کانادا', 'CA'),
  (19, 'استرالیا', 'AU'),
  (20, 'سوئیس', 'CH'),
  (21, 'سوئد', 'SE'),
  (22, 'انگلستان', 'GB'),
  (23, 'آمریکا', 'US'),
  (24, 'فرانسه', 'FR'),
  (25, 'ایتالیا', 'IT'),
  (26, 'اسپانیا', 'ES'),
  (27, 'هلند', 'NL'),
  (28, 'بلژیک', 'BE'),
  (29, 'اتریش', 'AT'),
  (30, 'سایر', 'XX');


INSERT IGNORE INTO `provinces` (`id`, `country_id`, `name`) VALUES
  (1, 1, 'آذربایجان شرقی'),
  (2, 1, 'آذربایجان غربی'),
  (3, 1, 'اردبیل'),
  (4, 1, 'اصفهان'),
  (5, 1, 'البرز'),
  (6, 1, 'ایلام'),
  (7, 1, 'بوشهر'),
  (8, 1, 'تهران'),
  (9, 1, 'چهارمحال و بختیاری'),
  (10, 1, 'خراسان جنوبی'),
  (11, 1, 'خراسان رضوی'),
  (12, 1, 'خراسان شمالی'),
  (13, 1, 'خوزستان'),
  (14, 1, 'زنجان'),
  (15, 1, 'سمنان'),
  (16, 1, 'سیستان و بلوچستان'),
  (17, 1, 'فارس'),
  (18, 1, 'قزوین'),
  (19, 1, 'قم'),
  (20, 1, 'کردستان'),
  (21, 1, 'کرمان'),
  (22, 1, 'کرمانشاه'),
  (23, 1, 'کهگیلویه و بویراحمد'),
  (24, 1, 'گلستان'),
  (25, 1, 'گیلان'),
  (26, 1, 'لرستان'),
  (27, 1, 'مازندران'),
  (28, 1, 'مرکزی'),
  (29, 1, 'هرمزگان'),
  (30, 1, 'همدان'),
  (31, 1, 'یزد');


INSERT IGNORE INTO `cities` (`id`, `province_id`, `name`) VALUES
  (1, 8, 'تهران'),
  (2, 8, 'اسلامشهر'),
  (3, 8, 'شهریار'),
  (4, 8, 'ورامین'),
  (5, 8, 'رباط‌کریم'),
  (6, 5, 'کرج'),
  (7, 5, 'فردیس'),
  (8, 11, 'مشهد'),
  (9, 11, 'نیشابور'),
  (10, 11, 'سبزوار'),
  (11, 4, 'اصفهان'),
  (12, 4, 'کاشان'),
  (13, 4, 'خمینی‌شهر'),
  (14, 17, 'شیراز'),
  (15, 17, 'مرودشت'),
  (16, 1, 'تبریز'),
  (17, 1, 'مراغه'),
  (18, 13, 'اهواز'),
  (19, 13, 'آبادان'),
  (20, 13, 'دزفول'),
  (21, 19, 'قم'),
  (22, 21, 'کرمانشاه'),
  (23, 2, 'ارومیه'),
  (24, 25, 'رشت'),
  (25, 16, 'زاهدان'),
  (26, 30, 'همدان'),
  (28, 20, 'کرمان'),
  (29, 31, 'یزد'),
  (30, 3, 'اردبیل'),
  (31, 29, 'بندرعباس'),
  (32, 28, 'اراک'),
  (33, 14, 'زنجان'),
  (34, 21, 'سنندج'),
  (35, 18, 'قزوین'),
  (36, 26, 'خرم‌آباد'),
  (37, 24, 'گرگان'),
  (38, 27, 'ساری'),
  (39, 7, 'بوشهر'),
  (40, 10, 'بیرجند'),
  (41, 6, 'ایلام'),
  (42, 15, 'سمنان'),
  (43, 23, 'یاسوج'),
  (44, 12, 'بجنورد'),
  (45, 9, 'شهرکرد'),
  (46, 22, 'دوگنبدان'),
  (47, 8, 'پاکدشت'),
  (48, 4, 'نجف‌آباد'),
  (49, 11, 'تربت حیدریه'),
  (50, 26, 'بروجرد'),
  (51, 27, 'بابل'),
  (52, 25, 'انزلی'),
  (53, 13, 'ماهشهر'),
  (54, 21, 'پاوه');


INSERT IGNORE INTO `currencies` (`id`, `code`, `title`, `symbol`, `minor_unit`, `is_base`) VALUES
  (1, 'IRR', 'ریال ایران', 'ریال', 0, 0),
  (2, 'IRT', 'تومان', 'تومان', 0, 1),
  (3, 'USD', 'دلار آمریکا', '$', 2, 0),
  (4, 'EUR', 'یورو', '€', 2, 0),
  (5, 'AED', 'درهم امارات', 'د.إ', 2, 0),
  (6, 'TRY', 'لیر ترکیه', '₺', 2, 0),
  (7, 'GBP', 'پوند انگلیس', '£', 2, 0),
  (8, 'CNY', 'یوان چین', '¥', 2, 0),
  (9, 'JPY', 'ین ژاپن', '¥', 0, 0),
  (10, 'RUB', 'روبل روسیه', '₽', 2, 0),
  (11, 'AFN', 'افغانی', '؋', 2, 0),
  (12, 'IQD', 'دینار عراق', 'ع.د', 3, 0),
  (13, 'PKR', 'روپیه پاکستان', '₨', 2, 0),
  (14, 'INR', 'روپیه هند', '₹', 2, 0),
  (15, 'SAR', 'ریال عربستان', 'ر.س', 2, 0),
  (16, 'QAR', 'ریال قطر', 'ر.ق', 2, 0),
  (17, 'KWD', 'دینار کویت', 'د.ك', 3, 0),
  (18, 'OMR', 'ریال عمان', 'ر.ع', 3, 0),
  (19, 'CAD', 'دلار کانادا', 'C$', 2, 0),
  (20, 'AUD', 'دلار استرالیا', 'A$', 2, 0),
  (21, 'CHF', 'فرانک سوئیس', '₣', 2, 0),
  (22, 'SEK', 'کرون سوئد', 'kr', 2, 0),
  (23, 'MYR', 'رینگیت مالزی', 'RM', 2, 0),
  (24, 'KRW', 'وون کره', '₩', 0, 0),
  (25, 'SGD', 'دلار سنگاپور', 'S$', 2, 0);


-- نرخ ارز پایه (تومان) برای نمونه؛ نرخ واقعی را در پنل «تنظیمات → ارز» وارد کنید.
INSERT IGNORE INTO `currency_rates` (`business_id`, `currency_id`, `rate_date`, `buy_rate`, `sell_rate`, `avg_rate`, `source`) VALUES
  (1, 3, '2025-03-21', 900000, 910000, 905000, 'manual'),
  (1, 4, '2025-03-21', 980000, 995000, 987500, 'manual');


-- مجوزها: ۲۳۴ ردیف (۲۶ ماژول × ۹ عملیات)
INSERT IGNORE INTO `permissions` (`id`, `module`, `action`, `slug`, `title_fa`) VALUES
  (1, 'dashboard', 'view', 'dashboard.view', 'مشاهده داشبورد'),
  (2, 'dashboard', 'create', 'dashboard.create', 'ایجاد داشبورد'),
  (3, 'dashboard', 'edit', 'dashboard.edit', 'ویرایش داشبورد'),
  (4, 'dashboard', 'delete', 'dashboard.delete', 'حذف داشبورد'),
  (5, 'dashboard', 'print', 'dashboard.print', 'چاپ داشبورد'),
  (6, 'dashboard', 'export', 'dashboard.export', 'خروجی داشبورد'),
  (7, 'dashboard', 'approve', 'dashboard.approve', 'تأیید داشبورد'),
  (8, 'dashboard', 'lock', 'dashboard.lock', 'قفل سند داشبورد'),
  (9, 'dashboard', 'submit', 'dashboard.submit', 'ارسال داشبورد'),
  (10, 'persons', 'view', 'persons.view', 'مشاهده اشخاص'),
  (11, 'persons', 'create', 'persons.create', 'ایجاد اشخاص'),
  (12, 'persons', 'edit', 'persons.edit', 'ویرایش اشخاص'),
  (13, 'persons', 'delete', 'persons.delete', 'حذف اشخاص'),
  (14, 'persons', 'print', 'persons.print', 'چاپ اشخاص'),
  (15, 'persons', 'export', 'persons.export', 'خروجی اشخاص'),
  (16, 'persons', 'approve', 'persons.approve', 'تأیید اشخاص'),
  (17, 'persons', 'lock', 'persons.lock', 'قفل سند اشخاص'),
  (18, 'persons', 'submit', 'persons.submit', 'ارسال اشخاص'),
  (19, 'products', 'view', 'products.view', 'مشاهده کالاها و خدمات'),
  (20, 'products', 'create', 'products.create', 'ایجاد کالاها و خدمات'),
  (21, 'products', 'edit', 'products.edit', 'ویرایش کالاها و خدمات'),
  (22, 'products', 'delete', 'products.delete', 'حذف کالاها و خدمات'),
  (23, 'products', 'print', 'products.print', 'چاپ کالاها و خدمات'),
  (24, 'products', 'export', 'products.export', 'خروجی کالاها و خدمات'),
  (25, 'products', 'approve', 'products.approve', 'تأیید کالاها و خدمات'),
  (26, 'products', 'lock', 'products.lock', 'قفل سند کالاها و خدمات'),
  (27, 'products', 'submit', 'products.submit', 'ارسال کالاها و خدمات'),
  (28, 'inventory', 'view', 'inventory.view', 'مشاهده انبارداری'),
  (29, 'inventory', 'create', 'inventory.create', 'ایجاد انبارداری'),
  (30, 'inventory', 'edit', 'inventory.edit', 'ویرایش انبارداری'),
  (31, 'inventory', 'delete', 'inventory.delete', 'حذف انبارداری'),
  (32, 'inventory', 'print', 'inventory.print', 'چاپ انبارداری'),
  (33, 'inventory', 'export', 'inventory.export', 'خروجی انبارداری'),
  (34, 'inventory', 'approve', 'inventory.approve', 'تأیید انبارداری'),
  (35, 'inventory', 'lock', 'inventory.lock', 'قفل سند انبارداری'),
  (36, 'inventory', 'submit', 'inventory.submit', 'ارسال انبارداری'),
  (37, 'invoices', 'view', 'invoices.view', 'مشاهده خرید و فروش'),
  (38, 'invoices', 'create', 'invoices.create', 'ایجاد خرید و فروش'),
  (39, 'invoices', 'edit', 'invoices.edit', 'ویرایش خرید و فروش'),
  (40, 'invoices', 'delete', 'invoices.delete', 'حذف خرید و فروش'),
  (41, 'invoices', 'print', 'invoices.print', 'چاپ خرید و فروش'),
  (42, 'invoices', 'export', 'invoices.export', 'خروجی خرید و فروش'),
  (43, 'invoices', 'approve', 'invoices.approve', 'تأیید خرید و فروش'),
  (44, 'invoices', 'lock', 'invoices.lock', 'قفل سند خرید و فروش'),
  (45, 'invoices', 'submit', 'invoices.submit', 'ارسال خرید و فروش'),
  (46, 'receipts', 'view', 'receipts.view', 'مشاهده دریافت'),
  (47, 'receipts', 'create', 'receipts.create', 'ایجاد دریافت'),
  (48, 'receipts', 'edit', 'receipts.edit', 'ویرایش دریافت'),
  (49, 'receipts', 'delete', 'receipts.delete', 'حذف دریافت'),
  (50, 'receipts', 'print', 'receipts.print', 'چاپ دریافت'),
  (51, 'receipts', 'export', 'receipts.export', 'خروجی دریافت'),
  (52, 'receipts', 'approve', 'receipts.approve', 'تأیید دریافت'),
  (53, 'receipts', 'lock', 'receipts.lock', 'قفل سند دریافت'),
  (54, 'receipts', 'submit', 'receipts.submit', 'ارسال دریافت'),
  (55, 'payments', 'view', 'payments.view', 'مشاهده پرداخت'),
  (56, 'payments', 'create', 'payments.create', 'ایجاد پرداخت'),
  (57, 'payments', 'edit', 'payments.edit', 'ویرایش پرداخت'),
  (58, 'payments', 'delete', 'payments.delete', 'حذف پرداخت'),
  (59, 'payments', 'print', 'payments.print', 'چاپ پرداخت'),
  (60, 'payments', 'export', 'payments.export', 'خروجی پرداخت'),
  (61, 'payments', 'approve', 'payments.approve', 'تأیید پرداخت'),
  (62, 'payments', 'lock', 'payments.lock', 'قفل سند پرداخت'),
  (63, 'payments', 'submit', 'payments.submit', 'ارسال پرداخت'),
  (64, 'transfers', 'view', 'transfers.view', 'مشاهده انتقال وجه'),
  (65, 'transfers', 'create', 'transfers.create', 'ایجاد انتقال وجه'),
  (66, 'transfers', 'edit', 'transfers.edit', 'ویرایش انتقال وجه'),
  (67, 'transfers', 'delete', 'transfers.delete', 'حذف انتقال وجه'),
  (68, 'transfers', 'print', 'transfers.print', 'چاپ انتقال وجه'),
  (69, 'transfers', 'export', 'transfers.export', 'خروجی انتقال وجه'),
  (70, 'transfers', 'approve', 'transfers.approve', 'تأیید انتقال وجه'),
  (71, 'transfers', 'lock', 'transfers.lock', 'قفل سند انتقال وجه'),
  (72, 'transfers', 'submit', 'transfers.submit', 'ارسال انتقال وجه'),
  (73, 'cheques', 'view', 'cheques.view', 'مشاهده چک‌ها'),
  (74, 'cheques', 'create', 'cheques.create', 'ایجاد چک‌ها'),
  (75, 'cheques', 'edit', 'cheques.edit', 'ویرایش چک‌ها'),
  (76, 'cheques', 'delete', 'cheques.delete', 'حذف چک‌ها'),
  (77, 'cheques', 'print', 'cheques.print', 'چاپ چک‌ها'),
  (78, 'cheques', 'export', 'cheques.export', 'خروجی چک‌ها'),
  (79, 'cheques', 'approve', 'cheques.approve', 'تأیید چک‌ها'),
  (80, 'cheques', 'lock', 'cheques.lock', 'قفل سند چک‌ها'),
  (81, 'cheques', 'submit', 'cheques.submit', 'ارسال چک‌ها'),
  (82, 'income_expense', 'view', 'income_expense.view', 'مشاهده درآمد و هزینه'),
  (83, 'income_expense', 'create', 'income_expense.create', 'ایجاد درآمد و هزینه'),
  (84, 'income_expense', 'edit', 'income_expense.edit', 'ویرایش درآمد و هزینه'),
  (85, 'income_expense', 'delete', 'income_expense.delete', 'حذف درآمد و هزینه'),
  (86, 'income_expense', 'print', 'income_expense.print', 'چاپ درآمد و هزینه'),
  (87, 'income_expense', 'export', 'income_expense.export', 'خروجی درآمد و هزینه'),
  (88, 'income_expense', 'approve', 'income_expense.approve', 'تأیید درآمد و هزینه'),
  (89, 'income_expense', 'lock', 'income_expense.lock', 'قفل سند درآمد و هزینه'),
  (90, 'income_expense', 'submit', 'income_expense.submit', 'ارسال درآمد و هزینه'),
  (91, 'accounting', 'view', 'accounting.view', 'مشاهده حسابداری'),
  (92, 'accounting', 'create', 'accounting.create', 'ایجاد حسابداری'),
  (93, 'accounting', 'edit', 'accounting.edit', 'ویرایش حسابداری'),
  (94, 'accounting', 'delete', 'accounting.delete', 'حذف حسابداری'),
  (95, 'accounting', 'print', 'accounting.print', 'چاپ حسابداری'),
  (96, 'accounting', 'export', 'accounting.export', 'خروجی حسابداری'),
  (97, 'accounting', 'approve', 'accounting.approve', 'تأیید حسابداری'),
  (98, 'accounting', 'lock', 'accounting.lock', 'قفل سند حسابداری'),
  (99, 'accounting', 'submit', 'accounting.submit', 'ارسال حسابداری'),
  (100, 'reports', 'view', 'reports.view', 'مشاهده گزارشات'),
  (101, 'reports', 'create', 'reports.create', 'ایجاد گزارشات'),
  (102, 'reports', 'edit', 'reports.edit', 'ویرایش گزارشات'),
  (103, 'reports', 'delete', 'reports.delete', 'حذف گزارشات'),
  (104, 'reports', 'print', 'reports.print', 'چاپ گزارشات'),
  (105, 'reports', 'export', 'reports.export', 'خروجی گزارشات'),
  (106, 'reports', 'approve', 'reports.approve', 'تأیید گزارشات'),
  (107, 'reports', 'lock', 'reports.lock', 'قفل سند گزارشات'),
  (108, 'reports', 'submit', 'reports.submit', 'ارسال گزارشات'),
  (109, 'payroll', 'view', 'payroll.view', 'مشاهده حقوق و دستمزد'),
  (110, 'payroll', 'create', 'payroll.create', 'ایجاد حقوق و دستمزد'),
  (111, 'payroll', 'edit', 'payroll.edit', 'ویرایش حقوق و دستمزد'),
  (112, 'payroll', 'delete', 'payroll.delete', 'حذف حقوق و دستمزد'),
  (113, 'payroll', 'print', 'payroll.print', 'چاپ حقوق و دستمزد'),
  (114, 'payroll', 'export', 'payroll.export', 'خروجی حقوق و دستمزد'),
  (115, 'payroll', 'approve', 'payroll.approve', 'تأیید حقوق و دستمزد'),
  (116, 'payroll', 'lock', 'payroll.lock', 'قفل سند حقوق و دستمزد'),
  (117, 'payroll', 'submit', 'payroll.submit', 'ارسال حقوق و دستمزد'),
  (118, 'attendance', 'view', 'attendance.view', 'مشاهده حضور و غیاب'),
  (119, 'attendance', 'create', 'attendance.create', 'ایجاد حضور و غیاب'),
  (120, 'attendance', 'edit', 'attendance.edit', 'ویرایش حضور و غیاب'),
  (121, 'attendance', 'delete', 'attendance.delete', 'حذف حضور و غیاب'),
  (122, 'attendance', 'print', 'attendance.print', 'چاپ حضور و غیاب'),
  (123, 'attendance', 'export', 'attendance.export', 'خروجی حضور و غیاب'),
  (124, 'attendance', 'approve', 'attendance.approve', 'تأیید حضور و غیاب'),
  (125, 'attendance', 'lock', 'attendance.lock', 'قفل سند حضور و غیاب'),
  (126, 'attendance', 'submit', 'attendance.submit', 'ارسال حضور و غیاب'),
  (127, 'settings', 'view', 'settings.view', 'مشاهده تنظیمات'),
  (128, 'settings', 'create', 'settings.create', 'ایجاد تنظیمات'),
  (129, 'settings', 'edit', 'settings.edit', 'ویرایش تنظیمات'),
  (130, 'settings', 'delete', 'settings.delete', 'حذف تنظیمات'),
  (131, 'settings', 'print', 'settings.print', 'چاپ تنظیمات'),
  (132, 'settings', 'export', 'settings.export', 'خروجی تنظیمات'),
  (133, 'settings', 'approve', 'settings.approve', 'تأیید تنظیمات'),
  (134, 'settings', 'lock', 'settings.lock', 'قفل سند تنظیمات'),
  (135, 'settings', 'submit', 'settings.submit', 'ارسال تنظیمات'),
  (136, 'users', 'view', 'users.view', 'مشاهده کاربران'),
  (137, 'users', 'create', 'users.create', 'ایجاد کاربران'),
  (138, 'users', 'edit', 'users.edit', 'ویرایش کاربران'),
  (139, 'users', 'delete', 'users.delete', 'حذف کاربران'),
  (140, 'users', 'print', 'users.print', 'چاپ کاربران'),
  (141, 'users', 'export', 'users.export', 'خروجی کاربران'),
  (142, 'users', 'approve', 'users.approve', 'تأیید کاربران'),
  (143, 'users', 'lock', 'users.lock', 'قفل سند کاربران'),
  (144, 'users', 'submit', 'users.submit', 'ارسال کاربران'),
  (145, 'access', 'view', 'access.view', 'مشاهده سطح دسترسی'),
  (146, 'access', 'create', 'access.create', 'ایجاد سطح دسترسی'),
  (147, 'access', 'edit', 'access.edit', 'ویرایش سطح دسترسی'),
  (148, 'access', 'delete', 'access.delete', 'حذف سطح دسترسی'),
  (149, 'access', 'print', 'access.print', 'چاپ سطح دسترسی'),
  (150, 'access', 'export', 'access.export', 'خروجی سطح دسترسی'),
  (151, 'access', 'approve', 'access.approve', 'تأیید سطح دسترسی'),
  (152, 'access', 'lock', 'access.lock', 'قفل سند سطح دسترسی'),
  (153, 'access', 'submit', 'access.submit', 'ارسال سطح دسترسی'),
  (154, 'printing', 'view', 'printing.view', 'مشاهده چاپ'),
  (155, 'printing', 'create', 'printing.create', 'ایجاد چاپ'),
  (156, 'printing', 'edit', 'printing.edit', 'ویرایش چاپ'),
  (157, 'printing', 'delete', 'printing.delete', 'حذف چاپ'),
  (158, 'printing', 'print', 'printing.print', 'چاپ چاپ'),
  (159, 'printing', 'export', 'printing.export', 'خروجی چاپ'),
  (160, 'printing', 'approve', 'printing.approve', 'تأیید چاپ'),
  (161, 'printing', 'lock', 'printing.lock', 'قفل سند چاپ'),
  (162, 'printing', 'submit', 'printing.submit', 'ارسال چاپ'),
  (163, 'moadian', 'view', 'moadian.view', 'مشاهده مودیان'),
  (164, 'moadian', 'create', 'moadian.create', 'ایجاد مودیان'),
  (165, 'moadian', 'edit', 'moadian.edit', 'ویرایش مودیان'),
  (166, 'moadian', 'delete', 'moadian.delete', 'حذف مودیان'),
  (167, 'moadian', 'print', 'moadian.print', 'چاپ مودیان'),
  (168, 'moadian', 'export', 'moadian.export', 'خروجی مودیان'),
  (169, 'moadian', 'approve', 'moadian.approve', 'تأیید مودیان'),
  (170, 'moadian', 'lock', 'moadian.lock', 'قفل سند مودیان'),
  (171, 'moadian', 'submit', 'moadian.submit', 'ارسال مودیان'),
  (172, 'messages', 'view', 'messages.view', 'مشاهده پیام‌ها و اعلان'),
  (173, 'messages', 'create', 'messages.create', 'ایجاد پیام‌ها و اعلان'),
  (174, 'messages', 'edit', 'messages.edit', 'ویرایش پیام‌ها و اعلان'),
  (175, 'messages', 'delete', 'messages.delete', 'حذف پیام‌ها و اعلان'),
  (176, 'messages', 'print', 'messages.print', 'چاپ پیام‌ها و اعلان'),
  (177, 'messages', 'export', 'messages.export', 'خروجی پیام‌ها و اعلان'),
  (178, 'messages', 'approve', 'messages.approve', 'تأیید پیام‌ها و اعلان'),
  (179, 'messages', 'lock', 'messages.lock', 'قفل سند پیام‌ها و اعلان'),
  (180, 'messages', 'submit', 'messages.submit', 'ارسال پیام‌ها و اعلان'),
  (181, 'tickets', 'view', 'tickets.view', 'مشاهده پشتیبانی'),
  (182, 'tickets', 'create', 'tickets.create', 'ایجاد پشتیبانی'),
  (183, 'tickets', 'edit', 'tickets.edit', 'ویرایش پشتیبانی'),
  (184, 'tickets', 'delete', 'tickets.delete', 'حذف پشتیبانی'),
  (185, 'tickets', 'print', 'tickets.print', 'چاپ پشتیبانی'),
  (186, 'tickets', 'export', 'tickets.export', 'خروجی پشتیبانی'),
  (187, 'tickets', 'approve', 'tickets.approve', 'تأیید پشتیبانی'),
  (188, 'tickets', 'lock', 'tickets.lock', 'قفل سند پشتیبانی'),
  (189, 'tickets', 'submit', 'tickets.submit', 'ارسال پشتیبانی'),
  (190, 'subscription', 'view', 'subscription.view', 'مشاهده اشتراک و پکیج'),
  (191, 'subscription', 'create', 'subscription.create', 'ایجاد اشتراک و پکیج'),
  (192, 'subscription', 'edit', 'subscription.edit', 'ویرایش اشتراک و پکیج'),
  (193, 'subscription', 'delete', 'subscription.delete', 'حذف اشتراک و پکیج'),
  (194, 'subscription', 'print', 'subscription.print', 'چاپ اشتراک و پکیج'),
  (195, 'subscription', 'export', 'subscription.export', 'خروجی اشتراک و پکیج'),
  (196, 'subscription', 'approve', 'subscription.approve', 'تأیید اشتراک و پکیج'),
  (197, 'subscription', 'lock', 'subscription.lock', 'قفل سند اشتراک و پکیج'),
  (198, 'subscription', 'submit', 'subscription.submit', 'ارسال اشتراک و پکیج'),
  (199, 'api', 'view', 'api.view', 'مشاهده API و فروشگاه'),
  (200, 'api', 'create', 'api.create', 'ایجاد API و فروشگاه'),
  (201, 'api', 'edit', 'api.edit', 'ویرایش API و فروشگاه'),
  (202, 'api', 'delete', 'api.delete', 'حذف API و فروشگاه'),
  (203, 'api', 'print', 'api.print', 'چاپ API و فروشگاه'),
  (204, 'api', 'export', 'api.export', 'خروجی API و فروشگاه'),
  (205, 'api', 'approve', 'api.approve', 'تأیید API و فروشگاه'),
  (206, 'api', 'lock', 'api.lock', 'قفل سند API و فروشگاه'),
  (207, 'api', 'submit', 'api.submit', 'ارسال API و فروشگاه'),
  (208, 'backup', 'view', 'backup.view', 'مشاهده پشتیبان‌گیری'),
  (209, 'backup', 'create', 'backup.create', 'ایجاد پشتیبان‌گیری'),
  (210, 'backup', 'edit', 'backup.edit', 'ویرایش پشتیبان‌گیری'),
  (211, 'backup', 'delete', 'backup.delete', 'حذف پشتیبان‌گیری'),
  (212, 'backup', 'print', 'backup.print', 'چاپ پشتیبان‌گیری'),
  (213, 'backup', 'export', 'backup.export', 'خروجی پشتیبان‌گیری'),
  (214, 'backup', 'approve', 'backup.approve', 'تأیید پشتیبان‌گیری'),
  (215, 'backup', 'lock', 'backup.lock', 'قفل سند پشتیبان‌گیری'),
  (216, 'backup', 'submit', 'backup.submit', 'ارسال پشتیبان‌گیری'),
  (217, 'projects', 'view', 'projects.view', 'مشاهده پروژه‌ها'),
  (218, 'projects', 'create', 'projects.create', 'ایجاد پروژه‌ها'),
  (219, 'projects', 'edit', 'projects.edit', 'ویرایش پروژه‌ها'),
  (220, 'projects', 'delete', 'projects.delete', 'حذف پروژه‌ها'),
  (221, 'projects', 'print', 'projects.print', 'چاپ پروژه‌ها'),
  (222, 'projects', 'export', 'projects.export', 'خروجی پروژه‌ها'),
  (223, 'projects', 'approve', 'projects.approve', 'تأیید پروژه‌ها'),
  (224, 'projects', 'lock', 'projects.lock', 'قفل سند پروژه‌ها'),
  (225, 'projects', 'submit', 'projects.submit', 'ارسال پروژه‌ها'),
  (226, 'cost_centers', 'view', 'cost_centers.view', 'مشاهده مراکز هزینه'),
  (227, 'cost_centers', 'create', 'cost_centers.create', 'ایجاد مراکز هزینه'),
  (228, 'cost_centers', 'edit', 'cost_centers.edit', 'ویرایش مراکز هزینه'),
  (229, 'cost_centers', 'delete', 'cost_centers.delete', 'حذف مراکز هزینه'),
  (230, 'cost_centers', 'print', 'cost_centers.print', 'چاپ مراکز هزینه'),
  (231, 'cost_centers', 'export', 'cost_centers.export', 'خروجی مراکز هزینه'),
  (232, 'cost_centers', 'approve', 'cost_centers.approve', 'تأیید مراکز هزینه'),
  (233, 'cost_centers', 'lock', 'cost_centers.lock', 'قفل سند مراکز هزینه'),
  (234, 'cost_centers', 'submit', 'cost_centers.submit', 'ارسال مراکز هزینه');


INSERT IGNORE INTO `plans` (`id`, `slug`, `title`, `description`, `price_amount`, `currency_id`, `included_documents`, `extra_document_price`, `max_users`, `max_businesses`, `sms_credits`, `is_popular`, `sort_order`) VALUES
  (1, 'trial', 'رایگان آزمایشی', 'یک ماه استفاده آزمایشی با امکانات پایه', 0, 2, 100, NULL, 3, 1, 50, 0, 1),
  (2, 'basic', 'پایه', 'مناسب کسب‌وکارهای کوچک', 2500000, 2, 3000, 800, 5, 1, 200, 0, 2),
  (3, 'pro', 'حرفه‌ای', 'مناسب کسب‌وکارهای در حال رشد', 5900000, 2, 12000, 500, 20, 3, 1000, 1, 3),
  (4, 'enterprise', 'سازمانی', 'مناسب هلدینگ‌ها و مجموعه‌های چند‌کسب‌وکاری', 0, 2, 0, NULL, 100, 20, 5000, 0, 4);


INSERT IGNORE INTO `plan_features` (`id`, `plan_id`, `feature_key`, `title_fa`, `included`, `limit_value`) VALUES
  (1, 1, 'invoicing', 'صدور فاکتور و پیش‌فاکتور', 1, NULL),
  (2, 1, 'inventory', 'انبارداری و کاردکس', 1, NULL),
  (3, 1, 'multi_warehouse', 'چند انباره', 1, 1),
  (4, 1, 'double_entry', 'حسابداری دوبل و اسناد خودکار', 1, NULL),
  (5, 1, 'reports', 'گزارشات مالی و مدیریتی', 1, NULL),
  (6, 1, 'payroll', 'حقوق و دستمزد و بیمه', 0, NULL),
  (7, 1, 'moadian', 'سامانه مودیان', 0, NULL),
  (8, 1, 'pos', 'کارتخوان و فروشگاهی', 1, NULL),
  (9, 1, 'api', 'API و اتصال فروشگاه آنلاین', 0, NULL),
  (10, 1, 'sms', 'پیامک خودکار', 1, 200),
  (11, 1, 'attendance', 'حضور و غیاب', 0, NULL),
  (12, 1, 'support', 'پشتیبانی اختصاصی', 0, NULL),
  (13, 2, 'invoicing', 'صدور فاکتور و پیش‌فاکتور', 1, NULL),
  (14, 2, 'inventory', 'انبارداری و کاردکس', 1, NULL),
  (15, 2, 'multi_warehouse', 'چند انباره', 1, 3),
  (16, 2, 'double_entry', 'حسابداری دوبل و اسناد خودکار', 1, NULL),
  (17, 2, 'reports', 'گزارشات مالی و مدیریتی', 1, NULL),
  (18, 2, 'payroll', 'حقوق و دستمزد و بیمه', 1, NULL),
  (19, 2, 'moadian', 'سامانه مودیان', 1, NULL),
  (20, 2, 'pos', 'کارتخوان و فروشگاهی', 1, NULL),
  (21, 2, 'api', 'API و اتصال فروشگاه آنلاین', 1, NULL),
  (22, 2, 'sms', 'پیامک خودکار', 1, 200),
  (23, 2, 'attendance', 'حضور و غیاب', 1, NULL),
  (24, 2, 'support', 'پشتیبانی اختصاصی', 1, NULL),
  (25, 3, 'invoicing', 'صدور فاکتور و پیش‌فاکتور', 1, NULL),
  (26, 3, 'inventory', 'انبارداری و کاردکس', 1, NULL),
  (27, 3, 'multi_warehouse', 'چند انباره', 1, 20),
  (28, 3, 'double_entry', 'حسابداری دوبل و اسناد خودکار', 1, NULL),
  (29, 3, 'reports', 'گزارشات مالی و مدیریتی', 1, NULL),
  (30, 3, 'payroll', 'حقوق و دستمزد و بیمه', 1, NULL),
  (31, 3, 'moadian', 'سامانه مودیان', 1, NULL),
  (32, 3, 'pos', 'کارتخوان و فروشگاهی', 1, NULL),
  (33, 3, 'api', 'API و اتصال فروشگاه آنلاین', 1, NULL),
  (34, 3, 'sms', 'پیامک خودکار', 1, 200),
  (35, 3, 'attendance', 'حضور و غیاب', 1, NULL),
  (36, 3, 'support', 'پشتیبانی اختصاصی', 1, NULL),
  (37, 4, 'invoicing', 'صدور فاکتور و پیش‌فاکتور', 1, NULL),
  (38, 4, 'inventory', 'انبارداری و کاردکس', 1, NULL),
  (39, 4, 'multi_warehouse', 'چند انباره', 1, NULL),
  (40, 4, 'double_entry', 'حسابداری دوبل و اسناد خودکار', 1, NULL),
  (41, 4, 'reports', 'گزارشات مالی و مدیریتی', 1, NULL),
  (42, 4, 'payroll', 'حقوق و دستمزد و بیمه', 1, NULL),
  (43, 4, 'moadian', 'سامانه مودیان', 1, NULL),
  (44, 4, 'pos', 'کارتخوان و فروشگاهی', 1, NULL),
  (45, 4, 'api', 'API و اتصال فروشگاه آنلاین', 1, NULL),
  (46, 4, 'sms', 'پیامک خودکار', 1, 200),
  (47, 4, 'attendance', 'حضور و غیاب', 1, NULL),
  (48, 4, 'support', 'پشتیبانی اختصاصی', 1, NULL);



-- پایان داده مرجع.



-- (بخش داده نمایشی حذف شده است. برای شروع کار، از صفحه ثبت‌نام استفاده کنید.)
;
