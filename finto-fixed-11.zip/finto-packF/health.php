<?php
/**
 * بررسی سلامت نصب — این فایل را بعد از نصب باز کنید و در صورت سالم‌بودن حذف کنید.
 * آدرس:  https://your-domain.com/health.php   (یا /finto/health.php)
 */
declare(strict_types=1);
@ini_set('display_errors', '1');
error_reporting(E_ALL);
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function fa(string $n): string { return strtr($n, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); }

$root = __DIR__;
$checks = [];
$add = function (string $label, bool $ok, string $value = '', string $fix = '', bool $soft = false) use (&$checks): void {
    $checks[] = ['label' => $label, 'ok' => $ok, 'value' => $value, 'fix' => $fix, 'soft' => $soft];
};

/* ── پیکربندی ── */
$cfg = null;
try { $cfg = require $root.'/config.php'; } catch (Throwable $e) { }
$local = [];
if (is_file($root.'/config.local.php')) {
    try { $local = (array)(require $root.'/config.local.php'); } catch (Throwable $e) { }
}
$db = array_replace_recursive($cfg['db'] ?? [], $local['db'] ?? []);
$app = array_replace_recursive($cfg['app'] ?? [], $local['app'] ?? []);

$add('نسخه PHP ≥ ۸٫۰', version_compare(PHP_VERSION, '8.0.0', '>='), PHP_VERSION, 'در cPanel از Select PHP Version نسخه ۸٫۰ یا بالاتر را انتخاب کنید.');
$add('افزونه pdo_mysql', extension_loaded('pdo_mysql'), '', 'در بخش PHP Extensions فعال کنید.');
$add('افزونه mbstring', extension_loaded('mbstring'), '', 'در بخش PHP Extensions فعال کنید.');
$add('فایل config.local.php', is_file($root.'/config.local.php'), '', 'نصب‌کننده (install.php) را اجرا کنید.');
$add('قابل‌نوشتن بودن storage/', is_writable($root.'/storage'), '', 'سطح دسترسی پوشه را ۷۵۵ یا ۷۷۷ کنید.');
$add('قابل‌نوشتن بودن uploads/', is_writable($root.'/uploads'), '', 'سطح دسترسی پوشه را ۷۵۵ یا ۷۷۷ کنید.');
$add('فایل assets/theme.css', is_file($root.'/public/assets/theme.css'), '', 'پوشه public/assets را کامل آپلود کنید.');
$add('فایل .htaccess کنار index.php', is_file($root.'/index.php') && is_file($root.'/.htaccess'), '', 'فایل‌های مخفی (.htaccess) در هنگام آپلود ممکن است منتقل نشوند؛ آن‌ها را دستی آپلود کنید.');

/* ── اتصال دیتابیس ── */
$pdo = null; $dbErr = '';
try {
    $dsn = !empty($db['socket'])
        ? "mysql:unix_socket={$db['socket']};dbname={$db['name']};charset=utf8mb4"
        : "mysql:host={$db['host']};port={$db['port']};dbname={$db['name']};charset=utf8mb4";
    $pdo = new PDO($dsn, (string)$db['user'], (string)$db['pass'], [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
} catch (Throwable $e) { $dbErr = $e->getMessage(); }
$add('اتصال به دیتابیس', $pdo !== null, $pdo ? 'سرور '.$pdo->query('SELECT VERSION()')->fetchColumn() : $dbErr,
    'مشخصات دیتابیس در config.local.php را بررسی و در cPanel کاربر را به دیتابیس اضافه کنید (All Privileges).');

$counts = ['tables' => 0, 'views' => 0, 'users' => 0, 'businesses' => 0, 'fy' => 0];
if ($pdo) {
    try {
        $dbName = (string)$pdo->query('SELECT DATABASE()')->fetchColumn();
        $q = fn(string $sql) => (int)$pdo->query($sql)->fetchColumn();
        $counts['tables'] = $q("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=".$pdo->quote($dbName)." AND TABLE_TYPE='BASE TABLE'");
        $counts['views']  = $q("SELECT COUNT(*) FROM information_schema.VIEWS WHERE TABLE_SCHEMA=".$pdo->quote($dbName));
        $counts['users']  = $q('SELECT COUNT(*) FROM users');
        $counts['businesses'] = $q('SELECT COUNT(*) FROM businesses');
        $counts['fy']     = $q('SELECT COUNT(*) FROM fiscal_years');
    } catch (Throwable $e) { }
    $add('جدول‌های دیتابیس (۱۲۹ مورد)', $counts['tables'] >= 129, fa((string)$counts['tables']).' جدول', 'فایل db/finto.sql را در phpMyAdmin ایمپورت کنید یا install.php را اجرا کنید.');
    $add('نماهای گزارش‌گیری (۲۵ مورد)', $counts['views'] >= 25, fa((string)$counts['views']).' نما', 'فایل SQL ناقص ایمپورت شده است؛ از install.php استفاده کنید.');
    $add('کاربران ثبت‌شده', $counts['users'] > 0, fa((string)$counts['users']).' کاربر', 'از صفحه ثبت‌نام یک کسب‌وکار بسازید: /register', true);
    $add('سال مالی', $counts['fy'] > 0, fa((string)$counts['fy']).' سال مالی', 'پس از ثبت‌نام خودکار ساخته می‌شود (یا: php tools/roll_fiscal_year.php).', true);
}

/* ── اجرای واقعی برنامه (تست درون‌فرآیندی) ── */
$appOk = false; $appErr = '';
if ($pdo) {
    try {
        $bootstrap = $root.'/app/bootstrap.php';
        ob_start();
        require $bootstrap;
        $t = Database::val('SELECT COUNT(*) FROM chart_of_accounts');
        ob_end_clean();
        $appOk = ((int)$t) >= 0;
    } catch (Throwable $e) {
        ob_end_clean();
        $appErr = $e->getMessage().' ('.$e->getFile().':'.$e->getLine().')';
    }
}
$add('بارگذاری هسته برنامه و خواندن کدینگ حساب‌ها', $appOk, $appOk ? 'بدون خطا' : $appErr, 'storage/error.log را بررسی کنید.');

/* ── آدرس برنامه ── */
$base = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/');
$add('آدرس تشخیص‌داده‌شده برنامه', true, ($base ?: '').'/app  →  '.htmlspecialchars('http://'.($_SERVER['HTTP_HOST'] ?? 'localhost').($base ?: '').'/app'));
$add('حالت نمایشی کد تأیید (demo_mode)', !empty($app['demo_mode']), !empty($app['demo_mode']) ? 'فعال — کد تأیید روی صفحه نمایش داده می‌شود' : 'غیرفعال — پیامک واقعی لازم است', 'در config.local.php مقدار demo_mode را true کنید تا بدون سامانه پیامک، ثبت‌نام را تست کنید.');

$okCount = count(array_filter($checks, fn($c) => $c['ok'] || $c['soft']));
$allOk = $okCount === count($checks);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>بررسی سلامت نصب — فینتو</title>
<style>
 body{margin:0;background:#f6f4fb;color:#241b3a;font-family:Vazirmatn,Tahoma,system-ui,sans-serif;line-height:1.9}
 .wrap{max-width:820px;margin:0 auto;padding:28px 16px 60px}
 h1{font-size:22px;margin:10px 0 6px}
 .sub{color:#6b6480;font-size:14px;margin-bottom:18px}
 .card{background:#fff;border:1px solid #e6e1f2;border-radius:18px;padding:20px;box-shadow:0 12px 30px rgba(36,27,58,.07)}
 table{width:100%;border-collapse:collapse;font-size:14px}
 td{padding:10px 6px;border-bottom:1px dashed #e6e1f2;vertical-align:top}
 tr:last-child td{border-bottom:0}
 .ok{color:#16a34a;font-weight:700}.bad{color:#dc2626;font-weight:700}
 .fix{font-size:12.5px;color:#92400e;background:#fffbeb;border:1px solid #fde68a;border-radius:10px;padding:6px 9px;margin-top:5px;display:inline-block}
 .alert{border-radius:14px;padding:13px 15px;font-size:14.5px;margin:14px 0}
 .alert.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}
 .alert.err{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
 code{background:#f4f1fb;border-radius:8px;padding:2px 7px;direction:ltr;display:inline-block}
 .btn{display:inline-block;background:linear-gradient(135deg,#6d28d9,#8b5cf6);color:#fff;border-radius:12px;padding:10px 20px;text-decoration:none;font-weight:600;margin:4px 6px 0 0}
</style>
</head>
<body><div class="wrap">
  <h1>بررسی سلامت نصب نرم‌افزار فینتو</h1>
  <div class="sub"><?= fa((string)$okCount) ?> مورد از <?= fa((string)count($checks)) ?> مورد موفق</div>
  <div class="alert <?= $allOk ? 'ok' : 'err' ?>">
    <?= $allOk ? 'همه موارد سالم است؛ نرم‌افزار آماده استفاده است.' : 'موارد ناموفق را طبق راهنمای هر ردیف برطرف کنید و صفحه را دوباره باز کنید.' ?>
  </div>
  <div class="card">
    <table>
      <?php foreach ($checks as $c): ?>
      <tr>
        <td><?= h($c['label']) ?>
          <?php if (!$c['ok'] && $c['fix']): ?><div class="fix"><?= $c['soft'] ? 'راهنما' : 'راه‌حل' ?>: <?= h($c['fix']) ?></div><?php endif; ?>
        </td>
        <td style="width:44%"><?= $c['value'] !== '' ? h((string)$c['value']) : ($c['ok'] ? 'سالم' : 'ناموفق') ?></td>
        <td style="width:70px;text-align:left"><span class="<?= $c['ok'] ? 'ok' : ($c['soft'] ? 'warn' : 'bad') ?>"><?= $c['ok'] ? '✔' : ($c['soft'] ? '!' : '✘') ?></span></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
  <div class="alert err" style="margin-top:16px">پس از برطرف‌شدن موارد، این فایل (<code>health.php</code>) و <code>install.php</code> را از هاست حذف کنید.</div>
  <a class="btn" href="<?= h(($base ?: '').'/app') ?>">ورود به نرم‌افزار</a>
  <a class="btn" href="<?= h(($base ?: '').'/register') ?>">ثبت‌نام</a>
</div></body>
</html>
