/* ═══ فینتو — اسکریپت رابط کاربری: تقویم شمسی، ردیف‌های پویا، جست‌وجو، مودال، اعداد ═══ */
(function () {
  'use strict';
  /* ── تبدیل تاریخ میلادی ↔ شمسی ── */
  function g2j(gy, gm, gd) {
    const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    const gy2 = gm > 2 ? gy + 1 : gy;
    let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + gdm[gm - 1];
    let jy = -1595 + 33 * Math.floor(days / 12053); days %= 12053;
    jy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    let jm, jd;
    if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
    else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
    return [jy, jm, jd];
  }
  function j2g(jy, jm, jd) {
    jy += 1595;
    let days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    let gy = 400 * Math.floor(days / 146097); days %= 146097;
    if (days > 36524) { days--; gy += 100 * Math.floor(days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    let gd = days + 1;
    const leap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
    const m = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0; while (gm < 12 && gd > m[gm]) { gd -= m[gm]; gm++; }
    return [gy, gm + 1, gd];
  }
  const pad = (n) => String(n).padStart(2, '0');

  /* ── فیلدهای تاریخ شمسی: مقدار میلادی در فیلد مخفی، نمایش شمسی در فیلد قابل‌ویرایش ── */
  function initJalali(root) {
    (root || document).querySelectorAll('input.jalali').forEach(function (el) {
      if (el.dataset.jready) return;
      el.dataset.jready = '1';
      const hidden = document.createElement('input');
      hidden.type = 'hidden'; hidden.name = el.name + '_iso';
      el.parentNode.insertBefore(hidden, el.nextSibling);
      // مقدار اولیه: اگر data-value دارد از آن، وگرنه از خود مقدار نمایشی
      let val = el.getAttribute('data-value') || '';
      if (val && /^\d{4}-\d{2}-\d{2}/.test(val)) {
        const d = new Date(val.replace(' ', 'T'));
        const [jy, jm, jd] = g2j(d.getFullYear(), d.getMonth() + 1, d.getDate());
        el.value = jy + '/' + pad(jm) + '/' + pad(jd) + (val.length > 10 ? ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) : '');
      }
      const sync = function () {
        const m = el.value.trim().replace(/[۰-۹]/g, (ch) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch));
        const mm = m.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?$/);
        if (mm) {
          const [gy, gm, gd] = j2g(+mm[1], +mm[2], +mm[3]);
          hidden.value = gy + '-' + pad(gm) + '-' + pad(gd) + (mm[4] !== undefined ? ' ' + pad(+mm[4]) + ':' + pad(+mm[5]) + ':00' : '');
        } else hidden.value = '';
      };
      el.addEventListener('change', sync); el.addEventListener('input', sync);
      el.form && el.form.addEventListener('submit', sync, { once: false });
      sync();
    });
  }

  /* ── جداساز هزارگان برای فیلدهای مبلغ ── */
  function money(str) {
    let v = String(str).replace(/[^\d.\-]/g, '');
    if (v === '' || v === '-' || v === '.') return v;
    const neg = v.startsWith('-'); v = v.replace('-', '');
    const [i, d] = v.split('.');
    let out = i.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    if (d !== undefined) out += '.' + d.slice(0, 2);
    return (neg ? '-' : '') + out;
  }
  function numVal(s) { return parseFloat(String(s).replace(/,/g, '')) || 0; }
  function initMoney(root) {
    (root || document).querySelectorAll('input.money').forEach(function (el) {
      if (el.dataset.mready) return; el.dataset.mready = '1';
      el.addEventListener('input', function () { el.value = money(fa2en(el.value)); });
      el.addEventListener('blur', function () { const v = numVal(el.value); el.value = v ? money(v.toFixed(0)) : ''; });
    });
  }

  /* ── منو ── */
  function initNav() {
    document.querySelectorAll('.nav-group>.nav-head').forEach(function (h) {
      h.addEventListener('click', function () { h.parentNode.classList.toggle('open'); });
    });
    document.querySelectorAll('.nav-group.active').forEach(function (g) { g.classList.add('open'); });
    const sb = document.querySelector('.sidebar'), bd = document.querySelector('.sidebar-backdrop');
    document.querySelectorAll('[data-burger]').forEach(function (burger) {
      burger.addEventListener('click', function () { sb.classList.toggle('open'); bd.classList.toggle('on'); });
    });
    if (bd) bd.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
    document.querySelectorAll('.sidebar a').forEach(function (a) {
      a.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
    });
    if (bd) bd.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
  }

  /* ── جست‌وجوی سریع ── */
  function initSearch() {
    const input = document.querySelector('[data-quick-search]');
    if (!input) return;
    const box = document.querySelector('.search-results');
    let timer = null;
    input.addEventListener('input', function () {
      clearTimeout(timer);
      const q = input.value.trim();
      if (q.length < 2) { box.classList.remove('on'); box.innerHTML = ''; return; }
      timer = setTimeout(function () {
        fetch((window.APP_BASE || '') + '/app/search?q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } })
          .then((r) => r.json()).then(function (j) {
            if (!j.items || !j.items.length) { box.innerHTML = '<div class="empty small">نتیجه‌ای یافت نشد</div>'; box.classList.add('on'); return; }
            box.innerHTML = j.items.map((it) => '<a href="' + it.url + '"><span class="g">' + it.group + '</span><span>' + it.text + '</span></a>').join('');
            box.classList.add('on');
          }).catch(() => {});
      }, 250);
    });
    document.addEventListener('click', function (e) { if (!e.target.closest('.searchbox')) box.classList.remove('on'); });
  }

  /* ── مودال ── */
  function initModals() {
    document.querySelectorAll('[data-modal]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const m = document.getElementById(btn.getAttribute('data-modal'));
        if (!m) return;
        m.classList.add('on');
        const f = m.querySelector('form');
        if (f) { f.action = btn.getAttribute('data-action') || f.action; }
        const t = m.querySelector('[data-modal-target]');
        if (t && btn.getAttribute('data-target-name')) t.textContent = btn.getAttribute('data-target-name');
      });
    });
    document.querySelectorAll('.modal-backdrop').forEach(function (b) {
      b.addEventListener('click', function (e) { if (e.target === b || e.target.closest('[data-close]')) b.classList.remove('on'); });
    });
  }

  /* ── ردیف‌های پویا (فاکتور، حواله، سند) ── */
  const TPL = {};
  function tpl(id) {
    if (!TPL[id]) TPL[id] = document.getElementById(id).innerHTML;
    return TPL[id];
  }
  function initRows() {
    document.querySelectorAll('[data-rows]').forEach(function (wrap) {
      const key = wrap.getAttribute('data-rows');
      const addBtn = document.querySelector('[data-add-row="' + key + '"]');
      const body = wrap.querySelector('tbody') || wrap;
      let idx = body.querySelectorAll('tr[data-row], .rowline').length;
      function addRow() {
        const html = tpl('tpl-' + key).replace(/__i__/g, idx).replace(/__n__/g, idx + 1);
        const tr = document.createElement('tr');
        tr.setAttribute('data-row', ''); tr.innerHTML = html;
        body.appendChild(tr);
        initMoney(tr); initDigits(tr); initJalali(tr); initDatePicker(tr); initSelects(tr); idx++;
        recalc(key);
      }
      if (addBtn) addBtn.addEventListener('click', function (e) { e.preventDefault(); addRow(); });
      body.addEventListener('click', function (e) {
        const del = e.target.closest('[data-del-row]');
        if (del) { e.preventDefault(); const tr = del.closest('tr[data-row]') || del.closest('.rowline'); tr.remove(); recalc(key); }
      });
      body.addEventListener('input', function () { recalc(key); });
      body.addEventListener('change', function () { recalc(key); });
      if (!body.querySelectorAll('tr[data-row]').length && body.querySelectorAll('.rowline').length === 0) addRow();
      recalc(key);
      window['recalc_' + key] = () => recalc(key);
    });
  }

  function recalc(key) {
    const wrap = document.querySelector('[data-rows="' + key + '"]');
    if (!wrap) return;
    if (key === 'inv') {
      let sub = 0, disc = 0, tax = 0, qty = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const q = numVal(tr.querySelector('[name^="line_quantity"]')?.value);
        const p = numVal(tr.querySelector('[name^="line_unit_price"]')?.value);
        const d = numVal(tr.querySelector('[name^="line_discount"]')?.value);
        const t = tr.querySelector('[name^="line_tax_id"]');
        let rate = 0;
        if (t && t.value) rate = numVal(t.options[t.selectedIndex].getAttribute('data-rate'));
        const lt = Math.max(0, q * p - q * p * d / 100);
        const tt = lt * rate / 100;
        const cell = tr.querySelector('[data-line-total]');
        if (cell) cell.textContent = (lt + tt).toLocaleString('fa-IR');
        sub += q * p; disc += q * p * d / 100; tax += tt; qty += q;
      });
      let chg = 0, chgTax = 0;
      document.querySelectorAll('[data-charges] tr[data-row]').forEach(function (tr) {
        const a = numVal(tr.querySelector('[name^="charge_amount"]')?.value);
        const t = tr.querySelector('[name^="charge_tax_id"]');
        let rate = 0; if (t && t.value) rate = numVal(t.options[t.selectedIndex].getAttribute('data-rate'));
        chg += a; chgTax += a * rate / 100;
      });
      const invDisc = numVal(document.querySelector('[name="invoice_discount"]')?.value);
      const net = Math.max(0, sub - disc - invDisc);
      const total = net + tax + chg + chgTax;
      setText('sum_subtotal', sub); setText('sum_discount', disc + invDisc); setText('sum_tax', tax + chgTax);
      setText('sum_total', total); setText('sum_qty', qty);
      const pay = document.querySelector('[name="pay_amount"]');
      if (pay) { pay.value = money(total.toFixed(0)); }
    }
    if (key === 'jv') {
      let dr = 0, cr = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        dr += numVal(tr.querySelector('[name^="line_debit"]')?.value);
        cr += numVal(tr.querySelector('[name^="line_credit"]')?.value);
      });
      setText('sum_debit', dr); setText('sum_credit', cr);
      const diff = document.getElementById('jv_diff');
      if (diff) {
        diff.textContent = (dr - cr).toLocaleString('fa-IR');
        diff.className = Math.abs(dr - cr) < 0.01 ? 'badge on' : 'badge off';
      }
    }
    if (key === 'alloc') {
      let sum = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const a = numVal(tr.querySelector('[name^="alloc_amount"]')?.value); sum += a;
        const rem = numVal(tr.querySelector('[data-remain]')?.getAttribute('data-remain'));
        const cell = tr.querySelector('[data-after]');
        if (cell) cell.textContent = Math.max(0, rem - a).toLocaleString('fa-IR');
      });
      setText('sum_alloc', sum);
      const amt = numVal(document.querySelector('[name="amount"]')?.value);
      const hint = document.getElementById('alloc_hint');
      if (hint) {
        const rest = amt - sum;
        hint.className = 'alert ' + (rest < -0.01 ? 'error' : (Math.abs(rest) < 0.01 ? 'success' : 'info'));
        hint.textContent = rest < -0.01 ? 'جمع تخصیص از مبلغ سند بیشتر است!' : (Math.abs(rest) < 0.01 ? 'مبلغ سند کاملاً تخصیص داده شد.' : 'مانده تخصیص‌نشده: ' + rest.toLocaleString('fa-IR') + ' (علی‌الحساب)');
      }
    }
    if (key === 'stock') {
      let qty = 0, cost = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const q = numVal(tr.querySelector('[name^="line_quantity"]')?.value);
        const c = numVal(tr.querySelector('[name^="line_unit_cost"]')?.value);
        qty += q; cost += q * c;
      });
      setText('sum_qty', qty); setText('sum_cost', cost);
    }
  }
  function setText(id, v) { const el = document.getElementById(id); if (el) el.textContent = (Math.round(v * 100) / 100).toLocaleString('fa-IR'); }

  /* ── انتخاب کالا: پرکردن قیمت و واحد ── */
  function initSelects(root) {
    (root || document).querySelectorAll('select.select-search').forEach(function (el) {
      if (el.dataset.sready) return; el.dataset.sready = '1';
      el.addEventListener('change', function () {
        const opt = el.options[el.selectedIndex];
        if (!opt) return;
        const tr = el.closest('tr[data-row]');
        if (tr) {
          const priceField = tr.querySelector('[name^="line_unit_price"]');
          const type = document.querySelector('[name="invoice_type"]')?.value || 'sale';
          if (priceField && !numVal(priceField.value)) {
            const p = type === 'buy' || type === 'buy_return' ? opt.getAttribute('data-buy') : opt.getAttribute('data-sale');
            if (p) priceField.value = money(Number(p).toFixed(0));
          }
          const stockHint = tr.querySelector('[data-stock]');
          if (stockHint && opt.getAttribute('data-stock') !== null) stockHint.textContent = Number(opt.getAttribute('data-stock')).toLocaleString('fa-IR');
          const unitSel = tr.querySelector('[name^="line_unit_id"]');
          if (unitSel && !unitSel.value && opt.getAttribute('data-unit')) unitSel.value = opt.getAttribute('data-unit');
        }
        if (window['recalc_' + (tr ? (tr.closest('[data-rows]')?.getAttribute('data-rows')) : '')]) window['recalc_' + tr.closest('[data-rows]').getAttribute('data-rows')]();
      });
    });
    (root || document).querySelectorAll('[data-person-select]').forEach(function (el) {
      el.addEventListener('change', function () {
        el.closest('form').querySelectorAll('[data-person-reload]').forEach(function (l) {
          const base = l.getAttribute('data-href') || l.href.split('?')[0];
          l.href = base + '?person_id=' + el.value;
        });
        const hidden = document.querySelector('[name="person_name"]');
        if (hidden) hidden.value = el.options[el.selectedIndex]?.text || '';
        if (el.dataset.autoload === '1') window.location = el.dataset.base + '?person_id=' + el.value;
      });
    });
  }

  /* ── تب‌ها ── */
  function initTabs() {
    document.querySelectorAll('[data-tabs]').forEach(function (group) {
      const links = group.querySelectorAll('a,button');
      links.forEach(function (l, i) {
        l.addEventListener('click', function (e) {
          if (l.tagName === 'A' && !l.getAttribute('href').startsWith('#')) return;
          e.preventDefault();
          links.forEach((x) => x.classList.remove('on')); l.classList.add('on');
          const scope = document.querySelector(group.getAttribute('data-tabs'));
          if (scope) scope.querySelectorAll('[data-tab]').forEach(function (p) {
            p.style.display = p.getAttribute('data-tab') === l.getAttribute('data-tab') ? '' : 'none';
          });
        });
      });
      const active = group.querySelector('.on') || links[0];
      if (active && group.getAttribute('data-tabs')) active.click();
    });
  }

  /* ── تأیید حذف ── */
  function initConfirm() {
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
      f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
    });
  }
  function initToasts() {
    document.querySelectorAll('.toast').forEach(function (t) {
      setTimeout(function () { t.style.transition = 'opacity .4s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 450); }, 5200);
    });
  }
  function initOtp() {
    const el = document.querySelector('.otp-input');
    if (!el) return;
    el.addEventListener('input', function () { el.value = el.value.replace(/\D/g, '').slice(0, 6); });
  }

  document.addEventListener('DOMContentLoaded', function () {
  
  /* تبدیل خودکار ارقام فارسی/عربی به انگلیسی در فیلدهای عددی */
  function fa2en(str) {
    return String(str)
      .replace(/[۰-۹]/g, function (ch) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch); })
      .replace(/[٠-٩]/g, function (ch) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(ch); });
  }
  function initDigits(root) {
    (root || document).querySelectorAll(
      'input.money, input[type=number], input.num, input.qty, input.percent, input.jalali, .otp-input, input[inputmode=decimal], input[inputmode=numeric]'
    ).forEach(function (el) {
      if (el.dataset.dready) return;
      el.dataset.dready = '1';
      if (el.type === 'number') { el.type = 'text'; el.setAttribute('inputmode', 'decimal'); }
      el.setAttribute('dir', 'ltr');
      el.style.textAlign = 'left';
      el.addEventListener('input', function () {
        const v = fa2en(el.value);
        if (v !== el.value) {
          const pos = el.selectionStart;
          el.value = v;
          try { el.setSelectionRange(pos, pos); } catch (e) { }
        }
      });
      el.addEventListener('change', function () { el.value = fa2en(el.value); });
    });
  }

  /* ═══ دراپ‌داون جستجو‌دار (combobox) برای select.select-search ═══ */
  function initCombo(root) {
    (root || document).querySelectorAll('select.select-search').forEach(function (sel) {
      if (sel.dataset.cbready) return;
      sel.dataset.cbready = '1';
      sel.style.display = 'none';
      const wrap = document.createElement('div');
      wrap.className = 'cbx';
      const box = document.createElement('input');
      box.type = 'text'; box.className = 'inp cbx-input'; box.autocomplete = 'off';
      box.placeholder = 'جست‌وجو و انتخاب…';
      const list = document.createElement('div');
      list.className = 'cbx-list';
      wrap.appendChild(box); wrap.appendChild(list);
      sel.parentNode.insertBefore(wrap, sel);
      wrap.appendChild(sel);

      function syncBox() {
        const opt = sel.options[sel.selectedIndex];
        box.value = opt && opt.value ? opt.text : '';
      }
      syncBox();

      function renderList(filter) {
        const f = (filter || '').trim().toLowerCase();
        let html = '', count = 0;
        for (const o of sel.options) {
          if (!o.value || o.hidden) continue;
          if (f && o.text.toLowerCase().indexOf(f) === -1 && o.value.toLowerCase().indexOf(f) === -1) continue;
          html += '<div class="cbx-item' + (o.selected ? ' on' : '') + '" data-v="' + o.value + '">' + o.text + '</div>';
          if (++count >= 300) break;
        }
        list.innerHTML = html || '<div class="cbx-empty">موردی یافت نشد</div>';
        list.scrollTop = 0;
      }
      function openList() {
        document.querySelectorAll('.cbx-list.on').forEach(function (l) { if (l !== list) l.classList.remove('on'); });
        renderList('');
        list.classList.add('on');
        box.focus();
      }
      function closeList() { list.classList.remove('on'); }
      box.addEventListener('mousedown', function (e) { if (!list.classList.contains('on')) { openList(); e.preventDefault(); } });
      box.addEventListener('focus', function () { if (!list.classList.contains('on')) openList(); });
      box.addEventListener('input', function () { renderList(box.value); });
      box.addEventListener('blur', function () { setTimeout(closeList, 160); });
      list.addEventListener('mousedown', function (e) {
        const it = e.target.closest('.cbx-item');
        if (!it) return;
        e.preventDefault();
        sel.value = it.getAttribute('data-v');
        sel.dispatchEvent(new Event('change'));
        syncBox();
        closeList();
        box.blur();
      });
      box.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          const items = list.querySelectorAll('.cbx-item');
          if (!items.length) return;
          let idx = Array.from(items).findIndex(function (i) { return i.classList.contains('hl'); });
          const next = e.key === 'ArrowDown' ? Math.min(idx + 1, items.length - 1) : Math.max(idx - 1, 0);
          items.forEach(function (i) { i.classList.remove('hl'); });
          items[next].classList.add('hl');
          items[next].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter') {
          e.preventDefault();
          const hl = list.querySelector('.cbx-item.hl') || list.querySelector('.cbx-item.on');
          if (hl) { sel.value = hl.getAttribute('data-v'); sel.dispatchEvent(new Event('change')); syncBox(); closeList(); }
        } else if (e.key === 'Escape') { closeList(); box.blur(); }
      });
      // آبشاری: استان → شهر
      if (sel.dataset.provinceSource || sel.getAttribute('data-province-source')) {
        const srcId = sel.getAttribute('data-province-source');
        const src = srcId && document.getElementById(srcId);
        if (src) {
          src.addEventListener('change', function () {
            const prov = src.value;
            for (const o of sel.options) {
              if (!o.value) { o.hidden = false; continue; }
              o.hidden = !!prov && o.getAttribute('data-prov') !== prov;
            }
            const cur = sel.options[sel.selectedIndex];
            if (prov && cur && cur.value && cur.getAttribute('data-prov') !== prov) { sel.value = ''; syncBox(); }
          });
        }
      }
    });
  }

    initNav(); initSearch(); initModals(); initRows(); initMoney(); initDigits(); initCombo(); 
  /* ═══ تقویم شمسی بازشو (datepicker) برای input.jalali ═══ */
  const JMONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  const JWDAYS = ['ش','ی','د','س','چ','پ','ج'];
  function jIsLeap(jy) { const r = jy % 33; return [1,5,9,13,17,22,26,30].indexOf(r) > -1; }
  function jMonthLen(jy, jm) { return jm <= 6 ? 31 : (jm <= 11 ? 30 : (jIsLeap(jy) ? 30 : 29)); }
  function jalaliToDate(jy, jm, jd) {
    const [gy, gm, gd] = j2g(jy, jm, jd);
    return new Date(gy, gm - 1, gd);
  }
  function dateToJalali(d) { return g2j(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function jToday() { return dateToJalali(new Date()); }

  let dpEl = null, dpTarget = null, dpState = null;

  function dpBuild(jy, jm) {
    dpState = { jy: jy, jm: jm };
    const first = jalaliToDate(jy, jm, 1);
    let startWd = (first.getDay() + 1) % 7; // شنبه = ۰
    const len = jMonthLen(jy, jm);
    const [ty, tm, td] = jToday();
    const cur = dpTarget && dpTarget.value.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})/);
    const sel = cur ? [+cur[1], +cur[2], +cur[3]] : null;
    let html = '<div class="dp-head"><button type="button" class="dp-nav" data-dp="prev">‹</button>' +
      '<select class="dp-month">' + JMONTHS.map(function (m, i) { return '<option value="' + (i + 1) + '"' + ((i + 1) === jm ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select>' +
      '<select class="dp-year">' + (function () { let s = ''; for (let y = ty - 40; y <= ty + 6; y++) s += '<option value="' + y + '"' + (y === jy ? ' selected' : '') + '>' + y + '</option>'; return s; })() + '</select>' +
      '<button type="button" class="dp-nav" data-dp="next">›</button></div>';
    html += '<div class="dp-grid">' + JWDAYS.map(function (w) { return '<span class="dp-wd">' + w + '</span>'; }).join('');
    for (let i = 0; i < startWd; i++) html += '<span></span>';
    for (let d = 1; d <= len; d++) {
      const isToday = (ty === jy && tm === jm && td === d);
      const isSel = sel && sel[0] === jy && sel[1] === jm && sel[2] === d;
      html += '<button type="button" class="dp-day' + (isToday ? ' today' : '') + (isSel ? ' sel' : '') + '" data-dp-day="' + d + '">' + d + '</button>';
    }
    html += '</div><div class="dp-foot"><button type="button" class="dp-btn" data-dp="today">امروز</button>' +
      '<button type="button" class="dp-btn" data-dp="clear">پاک کردن</button></div>';
    return html;
  }

  function dpOpen(input) {
    dpClose();
    dpTarget = input;
    const m = input.value.match(/^(\d{4})\/(\d{1,2})/);
    let jy, jm;
    if (m) { jy = +m[1]; jm = +m[2]; }
    else { const t = jToday(); jy = t[0]; jm = t[1]; }
    dpEl = document.createElement('div');
    dpEl.className = 'jdp';
    dpEl.innerHTML = dpBuild(jy, jm);
    document.body.appendChild(dpEl);
    const r = input.getBoundingClientRect();
    const W = 260, H = 330;
    let x = r.right - W, y = r.bottom + 6;
    if (x < 6) x = 6;
    if (y + H > window.innerHeight) y = Math.max(6, r.top - H - 6);
    dpEl.style.left = x + 'px'; dpEl.style.top = y + 'px';
    dpEl.querySelectorAll('[data-dp]').forEach(function (b) {
      b.addEventListener('click', function (e) {
        e.preventDefault();
        const a = b.getAttribute('data-dp');
        if (a === 'prev') { let { jy: y, jm: m2 } = dpState; m2--; if (m2 < 1) { m2 = 12; y--; } dpEl.innerHTML = dpBuild(y, m2); }
        else if (a === 'next') { let { jy: y, jm: m2 } = dpState; m2++; if (m2 > 12) { m2 = 1; y++; } dpEl.innerHTML = dpBuild(y, m2); }
        else if (a === 'today') { const t = jToday(); dpPick(t[0], t[1], t[2]); }
        else if (a === 'clear') { dpTarget.value = ''; dpTarget.dispatchEvent(new Event('change')); dpClose(); }
      });
    });
    dpEl.querySelectorAll('.dp-month,.dp-year').forEach(function (s) {
      s.addEventListener('change', function () { dpEl.innerHTML = dpBuild(+dpEl.querySelector('.dp-year').value, +dpEl.querySelector('.dp-month').value); bindDays(); });
    });
    bindDays();
    function bindDays() {
      dpEl.querySelectorAll('[data-dp-day]').forEach(function (b) {
        b.addEventListener('click', function () { dpPick(dpState.jy, dpState.jm, +b.getAttribute('data-dp-day')); });
      });
    }
    setTimeout(function () { document.addEventListener('mousedown', dpOutside); }, 0);
  }
  function dpOutside(e) { if (dpEl && !dpEl.contains(e.target) && e.target !== dpTarget && !dpTarget.contains(e.target)) dpClose(); }
  function dpClose() { if (dpEl) { dpEl.remove(); dpEl = null; } document.removeEventListener('mousedown', dpOutside); }
  function dpPick(jy, jm, jd) {
    dpTarget.value = jy + '/' + pad(jm) + '/' + pad(jd);
    dpTarget.dispatchEvent(new Event('change'));
    dpClose();
  }

  function initDatePicker(root) {
    (root || document).querySelectorAll('input.jalali').forEach(function (el) {
      if (el.dataset.dpready) return;
      el.dataset.dpready = '1';
      el.setAttribute('readonly', 'readonly'); // انتخاب فقط از تقویم
      el.style.cursor = 'pointer';
      el.addEventListener('click', function () { dpOpen(el); });
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); dpOpen(el); } });
    });
  }

  initJalali();
  initDatePicker(); initSelects(); initTabs(); initConfirm(); initToasts(); initOtp();
    const form = document.querySelector('form[data-guard]');
  });
  window.FintoApp = { g2j, j2g, initJalali, initMoney, initDigits, money, numVal, fa2en };
})();
