<?php
/** نقطه ورود نرم‌افزار */
require __DIR__.'/../app/bootstrap.php';
$router = new Router();
(require __DIR__.'/../app/routes.php')($router);
$router->dispatch($_SERVER['REQUEST_URI'] ?? '/');
