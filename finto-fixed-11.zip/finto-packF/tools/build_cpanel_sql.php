<?php
/**
 * سازنده فایل‌های SQL مناسب میزبانی اشتراکی (cPanel):
 *   db/finto.sql        → جداول + کلیدها + نماها + داده مرجع + داده نمایشی
 *   db/finto-empty.sql  → فقط ساختار و داده مرجع (بدون داده نمایشی)
 * در این فایل‌ها دستورهای CREATE DATABASE و USE حذف شده‌اند تا در phpMyAdmin
 * روی دیتابیس انتخابی کاربر (با نام دلخواه و پیشوند cPanel) اجرا شوند.
 *
 * اجرا:  php tools/build_cpanel_sql.php [مسیر فایل منبع]
 */
$src = $argv[1] ?? __DIR__.'/../../db-design/mysql/99_install_all.sql';
if (!is_file($src)) { fwrite(STDERR, "فایل منبع پیدا نشد: $src\n"); exit(1); }
$sql = file_get_contents($src);
$lines = explode("\n", $sql);

/* جداکردن بخش داده نمایشی */
$demoAt = null;
foreach ($lines as $i => $l) if (str_contains($l, 'فایل 05_demo_data.sql') && str_contains($l, '═')) { $demoAt = $i; break; }
if ($demoAt === null) { fwrite(STDERR, "نشانگر بخش داده نمایشی پیدا نشد.\n"); exit(1); }

$head = implode("\n", array_slice($lines, 0, $demoAt));
$full = $sql;
$empty = $head . "\n-- (بخش داده نمایشی حذف شده است. برای شروع کار، از صفحه ثبت‌نام استفاده کنید.)\n";

/** حذف دستورهای CREATE DATABASE و USE از متن SQL (با احترام به رشته‌ها و توضیحات) */
function strip_db_statements(string $sql): array
{
    $out = []; $stmt = ''; $len = strlen($sql); $i = 0; $removed = 0;
    $flush = function (string $s) use (&$out, &$removed): void {
        $t = trim($s);
        if ($t === '') return;
        if (preg_match('/^CREATE\s+DATABASE\b/i', $t) || preg_match('/^USE\s+`?[\w$]+`?\s*$/i', $t)) { $removed++; return; }
        $out[] = $s;
    };
    while ($i < $len) {
        $ch = $sql[$i];
        // توضیحات ابتدای خط
        if (($ch === '-' && substr($sql, $i, 2) === '--') || $ch === '#') {
            $e = strpos($sql, "\n", $i); $e = $e === false ? $len : $e;
            // حفظ توضیحات در متن خروجی (به‌عنوان بخشی از دستور جاری یا مستقل)
            $stmt .= substr($sql, $i, $e - $i + 1); $i = $e + 1; continue;
        }
        if ($ch === '/' && substr($sql, $i, 2) === '/*') {
            $e = strpos($sql, '*/', $i + 2); $e = $e === false ? $len : $e + 2;
            $stmt .= substr($sql, $i, $e - $i); $i = $e; continue;
        }
        if ($ch === "'" || $ch === '"' || $ch === '`') {
            $q = $ch; $j = $i + 1;
            while ($j < $len) {
                if ($sql[$j] === '\\' && $q !== '`') { $j += 2; continue; }
                if ($sql[$j] === $q) { if ($q !== '`' && $j + 1 < $len && $sql[$j + 1] === $q) { $j += 2; continue; } $j++; break; }
                $j++;
            }
            $stmt .= substr($sql, $i, $j - $i); $i = $j; continue;
        }
        if ($ch === ';') { $flush($stmt); $stmt = ''; $i++; continue; }
        $stmt .= $ch; $i++;
    }
    $flush($stmt);
    return [$out, $removed];
}

foreach (['finto.sql' => $full, 'finto-empty.sql' => $empty] as $name => $body) {
    [$stmts, $removed] = strip_db_statements($body);
    $header = "-- ════════════════════════════════════════════════════════════════════\n"
        . "--  نرم‌افزار حسابداری و انبارداری فینتو — فایل نصب دیتابیس\n"
        . "--  $name  |  " . ($name === 'finto.sql' ? 'همراه با داده نمایشی' : 'بدون داده نمایشی (ساختار + داده مرجع)') . "\n"
        . "--  -----------------------------------------------------------------\n"
        . "--  روش ۱ (پیشنهادی): این فایل را در نصب‌کننده وبی برنامه (install.php) استفاده کنید.\n"
        . "--  روش ۲ (دستی): در cPanel → phpMyAdmin یک دیتابیس بسازید، آن را انتخاب کنید،\n"
        . "--                 سپس Import → Choose File → همین فایل → Go\n"
        . "--  نیازمندی: MySQL 8.0.16+ یا MariaDB 10.5+ (به دلیل قیدهای CHECK و نماها)\n"
        . "--  $removed دستور CREATE DATABASE/USE حذف شده است تا روی دیتابیس انتخابی شما اجرا شود.\n"
        . "-- ════════════════════════════════════════════════════════════════════\n\n";
    $target = __DIR__.'/../db/'.$name;
    @mkdir(dirname($target), 0775, true);
    file_put_contents($target, $header . implode(";\n", $stmts) . ";\n");
    printf("%-16s %8.1f KB  (%d دستور)\n", $name, filesize($target) / 1024, count($stmts));
}
