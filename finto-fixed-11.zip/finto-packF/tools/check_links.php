<?php
require __DIR__.'/../app/bootstrap.php';

/** بررسی ایستا: همه url('app/...') در نماها و کنترلرها با مسیرهای تعریف‌شده در routes.php مقایسه می‌شود */
$routes = file_get_contents(__DIR__.'/../app/routes.php');
preg_match_all('#->(get|post|any|put|delete)\(\s*\'([^\']+)#', $routes, $m, PREG_SET_ORDER);
$paths = array_unique(array_column($m, 2));
$patterns = [];
foreach ($paths as $p) {
    $segs = array_map(function ($seg) {
        return str_starts_with($seg, '{') ? '[A-Za-z0-9_\\-]+' : preg_quote($seg, '#');
    }, explode('/', ltrim($p, '/')));
    $patterns[] = '#^'.implode('/', $segs).'$#';
}

$files = array_merge(glob(__DIR__.'/../app/Views/pages/*.php'), glob(__DIR__.'/../app/Views/pages/*/*.php'), glob(__DIR__.'/../app/Controllers/*.php'));
$bad = [];
foreach ($files as $f) {
    $src = file_get_contents($f);
    // لینک‌های ثابت
    preg_match_all("#url\(\s*'([a-zA-Z0-9_/\-\.]+)'\s*\)#", $src, $mm);
    foreach ($mm[1] as $u) {
        if (!str_starts_with($u, 'app')) continue;
        $u = rtrim($u, '/');
        $ok = false;
        foreach ($patterns as $pt) if (preg_match($pt, $u)) { $ok = true; break; }
        if (!$ok) $bad[] = basename($f).' → url('.$u.')';
    }
}
$bad = array_values(array_unique($bad));
if ($bad) { echo "لینک‌های بدون مسیر:\n - ".implode("\n - ", $bad)."\n"; exit(1); }
echo "همه لینک‌های ثابت معتبرند ✅\n";

/* ── بررسی وجود متد کنترلر برای هر مسیر ── */
$routes2 = file_get_contents(__DIR__.'/../app/routes.php');
preg_match_all('#->(get|post|any|put|delete)\(\s*\'([^\']+)\'\s*,\s*\'([A-Za-z0-9_]+)@([A-Za-z0-9_]+)\'#', $routes2, $rm, PREG_SET_ORDER);
$missing = [];
foreach ($rm as $r) {
    [$all, $verb, $path, $class, $method] = $r;
    if (!class_exists($class) || !method_exists($class, $method)) $missing[] = strtoupper($verb).' '.$path.' → '.$class.'@'.$method;
}
if ($missing) { echo "مسیرهای بدون متد کنترلر:\n - ".implode("\n - ", array_unique($missing))."\n"; exit(1); }
echo "همه مسیرها متد کنترلر معتبر دارند ✅ (".count($rm)." مسیر)\n";
