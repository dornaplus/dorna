<?php
/** بررسی ایستا: مسیرهای منو و لینک‌های url('app/<module>') با ماژول‌ها/مسیرهای ثابت مطابقت دارد */
require __DIR__.'/../app/bootstrap.php';
$routes = file_get_contents(__DIR__.'/../app/routes.php');
preg_match_all('#->(get|post|any|put|delete)\(\s*\'([^\']+)#', $routes, $m, PREG_SET_ORDER);
$static = [];
foreach (array_column($m, 2) as $p) {
    $segs = explode('/', ltrim($p, '/'));
    if (($segs[0] ?? '') === 'app' && isset($segs[1]) && !str_starts_with($segs[1], '{')) $static[$segs[1]] = true;
}
$modules = [];
foreach (Meta::MODULES as $k => $v) $modules[$k] = true;

$bad = [];
foreach (Meta::NAV as $g) {
    foreach ($g['items'] as $it) {
        $route = explode('?', ltrim((string)($it['route'] ?? ''), '/'))[0];
        if ($route === 'app' || $route === '') continue;
        $segs = explode('/', $route);
        $key = $segs[1] ?? '';
        if (isset($static[$key]) || isset($modules[$key])) continue;
        $bad[] = 'NAV: '.$g['title'].' → '.$route;
    }
}
$files = array_merge(glob(__DIR__.'/../app/Views/pages/*.php'), glob(__DIR__.'/../app/Views/pages/*/*.php'), glob(__DIR__.'/../app/Controllers/*.php'));
foreach ($files as $f) {
    $src = file_get_contents($f);
    preg_match_all("#url\(\s*'app/([a-zA-Z0-9_\-]+)(?:[/'?])#", $src, $mm2);
    foreach (array_unique($mm2[1]) as $key) {
        if (isset($static[$key]) || isset($modules[$key])) continue;
        $bad[] = basename($f).' → app/'.$key;
    }
}
$bad = array_values(array_unique($bad));
if ($bad) { echo "مسیرهای نامعتبر:\n - ".implode("\n - ", $bad)."\n"; exit(1); }
echo "همه مسیرهای منو و لینک‌ها معتبرند ✅ (".count($modules)." ماژول + ".count($static)." مسیر ثابت)\n";
