<?php
/**
 * بازبین ایستا: کلیدهای آرایه‌های Database::insert()/Database::update() را با ستون‌های واقعی دیتابیس مقایسه می‌کند.
 * اجرا:  php tools/check_schema_usage.php
 */
require __DIR__.'/../app/bootstrap.php';
if (!function_exists('view')) require __DIR__.'/../app/Helpers.php';

$files = array_merge(glob(__DIR__.'/../app/*.php'), glob(__DIR__.'/../app/Controllers/*.php'));
$problems = []; $checked = 0;

function extract_keys(string $src, int $openBracket): array
{
    // از محل «[» شروع کرده و کلیدهای سطح اول را برمی‌گرداند
    $depth = 0; $i = $openBracket; $len = strlen($src); $keys = [];
    $inStr = false; $strCh = ''; $buf = '';
    for (; $i < $len; $i++) {
        $ch = $src[$i];
        if ($inStr) {
            if ($ch === '\\') { $buf .= $src[++$i]; continue; }
            if ($ch === $strCh) { $inStr = false; continue; }
            $buf .= $ch; continue;
        }
        if ($ch === "'" || $ch === '"') { $inStr = true; $strCh = $ch; $buf = ''; continue; }
        if ($ch === '[') { $depth++; continue; }
        if ($ch === ']') { $depth--; if ($depth === 0) break; continue; }
        if ($depth === 1) {
            $rest = substr($src, $i);
            if (preg_match('/^\s*=>/u', $rest)) {
                $prev = substr($src, 0, $i);
                if (preg_match('/[\'"]([A-Za-z0-9_]+)[\'"]\s*$/u', $prev, $m)) $keys[] = $m[1];
            }
        }
    }
    return array_values(array_unique($keys));
}

foreach ($files as $f) {
    $src = file_get_contents($f);
    foreach ([['insert', 'Database::insert('], ['update', 'Database::update(']] as [$kind, $needle]) {
        $offset = 0;
        while (($pos = strpos($src, $needle, $offset)) !== false) {
            $offset = $pos + strlen($needle);
            // نام جدول
            if (!preg_match('/^\s*[\'"]([A-Za-z0-9_]+)[\'"]/u', substr($src, $pos + strlen($needle)), $m)) continue;
            $table = $m[1];
            if (!in_array($table, Schema::tables(), true)) continue;
            // اولین «[» بعد از نام جدول — فقط اگر بلافاصله (با فاصله/کاما) آمده باشد
            $tail = substr($src, $pos + strlen($needle), 80);
            if (!preg_match('/^\s*[\'\"][A-Za-z0-9_]+[\'\"][^\[]*\[/u', $tail)) continue;
            $b = strpos($src, '[', $pos);
            if ($b === false) continue;
            if (strlen(trim(substr($src, $pos + strlen($needle), $b - $pos - strlen($needle)))) > 60) continue;
            $keys = extract_keys($src, $b);
            if (!$keys) continue;
            $meta = Schema::columns($table);
            $cols = array_keys($meta);
            if ($kind === 'update') $keys = array_values(array_diff($keys, ['pk', 'pid', 'id']));
            $bad = array_values(array_diff($keys, $cols));
            $checked++;
            if ($bad) $problems[] = sprintf('%s → %s (%s) کلیدهای نامعتبر: %s', basename($f), $kind, $table, implode(', ', $bad));
            if ($kind === 'insert' && !str_contains($src, 'Database::insert($table')) {
                $missing = [];
                foreach ($meta as $c => $mm) {
                    if ($mm['null'] !== false) continue;              // فقط NOT NULL
                    if ($mm['default'] !== null) continue;            // دارای مقدار پیش‌فرض
                    if (str_contains((string)$mm['extra'], 'auto_increment')) continue;
                    if (str_contains((string)$mm['extra'], 'GENERATED')) continue;
                    if (!in_array($c, $keys, true)) $missing[] = $c;
                }
                if ($missing) $problems[] = sprintf('%s → insert (%s) ستون‌های اجباری غایب: %s', basename($f), $table, implode(', ', $missing));
            }
        }
    }
}
echo "بررسی‌شده: $checked فراخوانی insert/update\n";
if ($problems) { echo "مشکلات:\n".implode("\n", array_unique($problems))."\n"; exit(1); }
echo "همه کلیدها با ستون‌های دیتابیس مطابقت دارند ✅\n";
