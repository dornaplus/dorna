<?php
/** بررسی ایستا: ستون‌های «جدول.ستون» در کوئری‌های SQL با ستون‌های واقعی دیتابیس مقایسه می‌شود. */
require __DIR__.'/../app/bootstrap.php';


/** استخراج رشته‌های SQL از یک فایل PHP با تحلیل توکن‌ها */
function extract_sql(string $file): array
{
    $tokens = token_get_all(file_get_contents($file));
    $out = []; $buf = '';
    foreach ($tokens as $tk) {
        if (is_array($tk) && in_array($tk[0], [T_CONSTANT_ENCAPSED_STRING, T_ENCAPSED_AND_WHITESPACE], true)) {
            $txt = $tk[1];
            if ($tk[0] === T_CONSTANT_ENCAPSED_STRING) {
                $q = $txt[0];
                $txt = substr($txt, 1, -1);
                $txt = str_replace(['\\'.$q, '\\\\'], [$q, '\\'], $txt);
            }
            $buf .= $txt;
            continue;
        }
        if ($buf !== '') {
            if (preg_match('/\b(SELECT|INSERT INTO|UPDATE|DELETE FROM|FROM)\b/i', $buf)) $out[] = $buf;
            $buf = '';
        }
    }
    if ($buf !== '' && preg_match('/\b(SELECT|INSERT INTO|UPDATE|DELETE FROM|FROM)\b/i', $buf)) $out[] = $buf;
    return $out;
}


/** آیا کوئری بیش از یک جدول دارد؟ */
function multiTables(string $sql, array $map): bool
{
    return (bool)preg_match('/\bJOIN\b/i', $sql) || count($map) > 1;
}
/** قطعه‌های فهرست SELECT را در سطح پرانتز جدا می‌کند */
function select_items(string $list): array
{
    $out = []; $buf = ''; $depth = 0;
    for ($i = 0; $i < strlen($list); $i++) {
        $ch = $list[$i];
        if ($ch === '(') $depth++;
        elseif ($ch === ')') $depth--;
        if ($ch === ',' && $depth === 0) { $out[] = trim($buf); $buf = ''; continue; }
        $buf .= $ch;
    }
    if (trim($buf) !== '') $out[] = trim($buf);
    return $out;
}

$files = array_merge(glob(__DIR__.'/../app/*.php'), glob(__DIR__.'/../app/Controllers/*.php'), glob(__DIR__.'/../app/Views/pages/*/*.php'));
$problems = []; $checked = 0;
foreach ($files as $f) {
    $sqls = extract_sql($f);
    foreach ($sqls as $sql) {
        // نگاشت نام جدول به نام مستعار
        $map = [];
        if (preg_match_all('/(?:FROM|JOIN)\s+`?([a-z0-9_]+)`?(?:\s+(?:AS\s+)?([a-z][a-z0-9_]*))?/i', $sql, $tm, PREG_SET_ORDER)) {
            foreach ($tm as $t) {
                $alias = $t[2] ?? '';
                if ($alias === '' || preg_match('/^(where|on|order|group|left|inner|join|set|and|as|limit|using)$/i', $alias)) $alias = $t[1];
                $map[strtolower($alias)] = strtolower($t[1]);
            }
        }
        foreach ($map as $alias => $table) {
            if (!in_array($table, Schema::tables(), true) && !in_array($table, Schema::views(), true)) continue;
            $cols = array_keys(Schema::columns($table));
            if (!$cols) continue;
            preg_match_all('/\b'.preg_quote($alias, '/').'\.([a-z0-9_]+)/i', $sql, $cm);
            foreach (array_unique($cm[1]) as $col) {
                $checked++;
                if (!in_array($col, $cols, true)) $problems[] = basename($f).': '.$table.'.'.$col.' (alias '.$alias.')';
            }
        }
        // ستون‌های بدون پیشوند در فهرست SELECT کوئری‌های تک‌جدولی
        if (!multiTables($sql, $map)) {
            if (preg_match('/\bSELECT\b(.*?)\bFROM\s+`?([a-z0-9_]+)`?/is', $sql, $sm2)) {
                $t = strtolower($sm2[2]);
                if (in_array($t, Schema::tables(), true) || in_array($t, Schema::views(), true)) {
                    $cols = array_keys(Schema::columns($t));
                    if ($cols) foreach (select_items($sm2[1]) as $piece) {
                        $p2 = preg_replace('/\s+AS\s+[a-z0-9_]+$/i', '', $piece);
                        $p2 = preg_replace('/\s+[a-z0-9_]+$/', '', $p2) ?: $p2; // حذف نام مستعار بدون AS
                        $p2 = trim($p2);
                        if ($p2 === '' || $p2 === '*' || str_contains($p2, '(') || str_contains($p2, ' ')) continue;
                        if (in_array(strtolower($p2), ['distinct','all','sql_calc_found_rows'], true)) continue;
                        if (str_contains($p2, '.')) {
                            [$pre, $col] = explode('.', $p2, 2);
                            if (strtolower($pre) !== $t) continue;
                            $p2 = $col;
                        }
                        $checked++;
                        if (!in_array($p2, $cols, true) && !in_array(strtolower($p2), $aliases, true)) $problems[] = basename($f).': SELECT '.$t.'.'.$p2;
                    }
                }
            }
        }
        // نام‌های مستعار SELECT و کوئری‌های چندجدولی را نادیده بگیر (ستون‌های بدون پیشوند به جدول اول نسبت داده نمی‌شوند)
        preg_match_all('/\bAS\s+([a-z0-9_]+)/i', $sql, $am);
        $aliases = array_map('strtolower', $am[1]);
        $multi = (bool)preg_match('/\bJOIN\b/i', $sql) || count($map) > 1;
        if (!$multi && preg_match('/\bFROM\s+`?([a-z0-9_]+)`?\s*(?:WHERE|GROUP BY|ORDER BY|LIMIT|HAVING|$)/i', $sql, $sm)) {
            $t = strtolower($sm[1]);
            if (in_array($t, Schema::tables(), true) || in_array($t, Schema::views(), true)) {
                $cols = array_keys(Schema::columns($t));
                foreach (['ORDER BY', 'GROUP BY'] as $kw) {
                    if (preg_match('/'.str_replace(' ', '\s+', $kw).'\s+([^)]+?)(?:\s+(?:LIMIT|OFFSET|HAVING)|$)/i', $sql, $om)) {
                        foreach (preg_split('/\s*,\s*/', $om[1]) as $piece) {
                            $piece = trim(preg_replace('/\s+(ASC|DESC)$/i', '', trim($piece)), "` \t\n\r'\"[],;");
                            if ($piece === '' || str_contains($piece, '(') || str_contains($piece, ' ')) continue;
                            $col = preg_replace('/^\w+\./', '', $piece);
                            if (in_array(strtolower($col), $aliases, true)) continue;
                            $checked++;
                            if (!in_array($col, $cols, true)) $problems[] = basename($f).': ORDER/GROUP BY '.$t.'.'.$col;
                        }
                    }
                }
            }
        }
    }
}
echo "بررسی‌شده: $checked ارجاع ستون\n";
$problems = array_values(array_unique($problems));
if ($problems) { echo "ستون‌های مشکوک (".count($problems)."):\n - ".implode("\n - ", $problems)."\n"; exit(1); }
echo "همه ستون‌ها معتبرند ✅\n";
