<?php
/** بررسی ایستا: فراخوانی redirect()/exit داخل Database::transaction() — تراکنش هرگز commit نمی‌شود */
foreach (array_merge(glob(__DIR__.'/../app/*.php'), glob(__DIR__.'/../app/Controllers/*.php')) as $f) {
    $src = file_get_contents($f);
    $offset = 0; $bad = [];
    while (($pos = strpos($src, 'Database::transaction(', $offset)) !== false) {
        $start = strpos($src, '{', strpos($src, 'function', $pos));
        if ($start === false) break;
        $depth = 0; $i = $start; $len = strlen($src);
        for (; $i < $len; $i++) {
            if ($src[$i] === '{') $depth++;
            elseif ($src[$i] === '}') { $depth--; if ($depth === 0) break; }
        }
        $body = substr($src, $start, $i - $start);
        $line = substr_count(substr($src, 0, $pos), "\n") + 1;
        if (preg_match('/\b(redirect|abort)\s*\(/', $body)) $bad[] = $line;
        $offset = $i;
    }
    foreach ($bad as $l) echo basename($f).":$l\n";
}
