<?php
/**
 * آزمون خودکار CRUD: برای هر ماژول قابل‌نوشتن، فرم «ایجاد» از سایت خوانده می‌شود،
 * فیلدهای الزامی با مقادیر معقول پر می‌شوند و ثبت رکورد بررسی می‌گردد.
 * اجرا: php tools/crud_test.php [base_url]
 */
require __DIR__.'/../app/bootstrap.php';
$base = rtrim($argv[1] ?? 'http://127.0.0.1:8080', '/');
$jar = sys_get_temp_dir().'/finto_crud_cookies.txt'; @unlink($jar);
$only = $argv[2] ?? null;

function R(string $m, string $p, array $post = null): array
{
    global $base, $jar;
    $ch = curl_init($base.$p);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        CURLOPT_HEADER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 60]);
    if ($m === 'POST') { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post ?? [])); }
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $hl = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE); curl_close($ch);
    preg_match('/^Location:\s*(.+)$/mi', substr((string)$raw, 0, $hl), $l);
    return ['code' => $code, 'body' => substr((string)$raw, $hl), 'location' => trim($l[1] ?? '')];
}
function T(string $p): string { $r = R('GET', $p); preg_match('/name="_token" value="([^"]+)"/', $r['body'], $m); return $m[1] ?? ''; }
function toasts(array $r): array
{
    preg_match_all('#<div class="toast (success|error|info|warn)">(.*?)</div>#su', $r['body'], $fm);
    $o = []; foreach ($fm[2] as $i => $x) $o[] = $fm[1][$i].': '.trim(strip_tags($x)); return $o;
}
/** فیلدهای فرم ایجاد را از HTML استخراج می‌کند */
function form_fields(string $html): array
{
    $fields = [];
    // ابتدا عناصر select با محتوای کامل، سپس input/textarea
    preg_match_all('/<select\b([^>]*)>(.*?)<\/select>/su', $html, $sel, PREG_SET_ORDER);
    preg_match_all('/<(input|textarea)\b([^>]*)\/?>(?:(.*?)<\/\1>)?/su', $html, $inp, PREG_SET_ORDER);
    $mm = [];
    foreach ($sel as $x) {
        if (preg_match('/name="([^"]+)"/', $x[1], $nm)) $mm[] = ['select', $x[1], $x[2], $nm[1]];
    }
    foreach ($inp as $x) {
        if (preg_match('/name="([^"]+)"/', $x[2], $nm)) $mm[] = [$x[1], $x[2], $x[3] ?? '', $nm[1]];
    }
    foreach ($mm as $tag) {
        $attrs = $tag[1]; $inner = $tag[2]; $name = $tag[3];
        if ($name === '_token' || str_starts_with($name, 'line_') || str_starts_with($name, 'charge_') || str_ends_with($name, '[]')) continue;
        if (preg_match('/type="hidden"/', $attrs)) continue;
        $type = preg_match('/type="([^"]+)"/', $attrs, $tm) ? $tm[1] : $tag[0];
        $required = (bool)preg_match('/\srequired/', $attrs);
        $opts = [];
        if ($tag[0] === 'select' && preg_match_all('/<option[^>]*value="([^"]*)"/su', $inner, $om)) $opts = $om[1];
        $fields[$name] = ['type' => $type, 'required' => $required, 'options' => $opts, 'class' => preg_match('/class="([^"]*)"/', $attrs, $cm) ? $cm[1] : ''];
    }
    return $fields;
}
function fill(array $fields, string $table): array
{
    $post = [];
    foreach ($fields as $name => $f) {
        $val = null;
        if ($f['type'] === 'select') {
            foreach ($f['options'] as $o) if ($o !== '') { $val = $o; break; }
            if ($val === null) { if ($f['required']) $val = ''; else continue; }
        } elseif ($f['type'] === 'checkbox') { $val = '1'; }
        elseif (str_contains($f['class'], 'jalali') || str_contains($name, 'date')) { $val = jdate(today()); }
        elseif (str_contains($f['class'], 'money')) { $val = '250000'; }
        elseif (str_contains($name, 'email')) { $val = 'test'.random_int(100, 999).'@example.com'; }
        elseif (str_contains($name, 'mobile') || str_contains($name, 'phone')) { $val = '0912'.random_int(1000000, 9999999); }
        elseif (str_contains($name, 'code') || str_contains($name, 'no')) { $val = 'T'.random_int(10000, 99999); }
        elseif (str_contains($name, 'percent') || str_contains($name, 'rate') || str_contains($name, 'days')) { $val = '10'; }
        elseif (preg_match('/qty|quantity|amount|price|salary|balance|limit/', $name)) { $val = '1000'; }
        elseif (str_contains($name, 'national_id')) { $val = '1234567891'; }
        elseif ($f['required'] || true) { $val = 'آزمون ' . random_int(100, 999); }
        $post[$name] = $val;
    }
    return $post;
}

/* ورود */
$t = T('/login');
$login = R('POST', '/login', ['_token' => $t, 'mobile' => '09120000001', 'password' => 'demo1234']);
if (!in_array($login['code'], [301, 302, 303], true)) { fwrite(STDERR, "ورود ناموفق\n"); exit(1); }

$skip = ['invoices','receipts','payments','cheques','transfers','inventory-documents','stock-transfers','stock-counts','expenses','incomes','journal',
    'expense-documents','income-documents','plans','subscription-payments','audit-logs','bank-statements','import-jobs','backup-jobs','number-sequences','print-templates','moadian-settings'];
$pass = 0; $fail = 0; $fails = [];
foreach (Meta::MODULES as $key => $def) {
    $m = Meta::module($key);
    if ($m['readonly'] || in_array($key, $skip, true)) continue;
    if ($m['custom']) continue; // ماژول‌های با فرم اختصاصی جداگانه آزمون می‌شوند
    if ($only && $key !== $only) continue;
    $formPage = R('GET', '/app/'.$key.'/create');
    if ($formPage['code'] !== 200) { $fail++; $fails[] = "$key: فرم ایجاد باز نشد ({$formPage['code']})"; continue; }
    $fields = form_fields($formPage['body']);
    $post = ['_token' => T('/app/'.$key.'/create')] + fill($fields, $m['table']);
    $bizId = 1; $before = (int)Database::val('SELECT COUNT(*) FROM `'.$m['table'].'` WHERE business_id=?', [$bizId], 0);
    $r = R('POST', '/app/'.$key, $post);
    $after = (int)Database::val('SELECT COUNT(*) FROM `'.$m['table'].'` WHERE business_id=?', [$bizId], 0);
    if ($after > $before) { $pass++; echo "PASS  $key  →  ".$m['singular'].' ثبت شد ('.($after - $before).")\n"; }
    else {
        $fail++; $page = R('GET', '/app/'.$key.'/create');
        $msg = implode(' | ', toasts($page)) ?: ('هدایت به '.$r['location']);
        $fails[] = "$key ({$m['table']}): " . mb_substr($msg, 0, 300);
        echo "FAIL  $key  →  ".mb_substr($msg, 0, 200)."\n";
    }
}
echo str_repeat('─', 46)."\nنتیجه CRUD: $pass موفق، $fail ناموفق\n";
if ($fails) echo "موارد ناموفق:\n - ".implode("\n - ", $fails)."\n";
exit($fail ? 1 : 0);
