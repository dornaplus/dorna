<?php
/**
 * استخراج «قالب پیش‌فرض کسب‌وکار» از یک کسب‌وکار مرجع (پیش‌فرض: شناسه ۱)
 * خروجی: app/Data/business_template.php — در راه‌اندازی کسب‌وکار جدید کپی می‌شود.
 * اجرا:  php tools/export_template.php [business_id]
 */
require __DIR__.'/../app/Helpers.php';
require __DIR__.'/../app/Database.php';
$biz = (int)($argv[1] ?? 1);
$acc = [];
foreach (Database::all('SELECT * FROM chart_of_accounts WHERE business_id=? ORDER BY code', [$biz]) as $a) $acc[(int)$a['id']] = $a;
$code = fn($id) => $id ? ($acc[(int)$id]['code'] ?? null) : null;

$t = [];
$t['chart_of_accounts'] = array_map(fn($a) => [
    'code' => $a['code'], 'parent_code' => $code($a['parent_id']), 'title' => $a['title'], 'level_no' => (int)$a['level_no'],
    'account_type' => $a['account_type'], 'nature' => $a['nature'], 'is_group' => (int)$a['is_group'], 'is_postable' => (int)$a['is_postable'],
    'person_required' => (int)$a['person_required'], 'system_role' => $a['system_role'], 'full_path' => $a['full_path'],
], array_values($acc));
$t['account_mappings'] = array_map(fn($m) => ['mapping_key' => $m['mapping_key'], 'title_fa' => $m['title_fa'], 'account_code' => $code($m['account_id'])],
    Database::all('SELECT * FROM account_mappings WHERE business_id=? ORDER BY id', [$biz]));
$t['taxes'] = array_map(fn($x) => ['title' => $x['title'], 'tax_kind' => $x['tax_kind'], 'rate_percent' => (float)$x['rate_percent'],
    'is_inclusive' => (int)$x['is_inclusive'], 'account_code' => $code($x['account_id']), 'moadian_tax_code' => $x['moadian_tax_code']],
    Database::all('SELECT * FROM taxes WHERE business_id=? ORDER BY id', [$biz]));
$t['units'] = array_map(fn($x) => ['title' => $x['title'], 'symbol' => $x['symbol']], Database::all('SELECT * FROM units WHERE business_id=? ORDER BY id', [$biz]));
$t['person_types'] = array_map(fn($x) => ['slug' => $x['slug'], 'title_fa' => $x['title_fa'], 'is_system' => (int)$x['is_system']],
    Database::all('SELECT * FROM person_types WHERE business_id=? ORDER BY id', [$biz]));
$t['price_types'] = array_map(fn($x) => ['slug' => $x['slug'], 'title_fa' => $x['title_fa']], Database::all('SELECT * FROM price_types WHERE business_id=? ORDER BY id', [$biz]));
$t['payment_methods'] = array_map(fn($x) => ['slug' => $x['slug'], 'title_fa' => $x['title_fa']], Database::all('SELECT * FROM payment_methods WHERE business_id=? ORDER BY id', [$biz]));
$t['payment_terms'] = array_map(fn($x) => ['title' => $x['title'], 'days' => (int)$x['days'], 'is_cash' => (int)$x['is_cash']],
    Database::all('SELECT * FROM payment_terms WHERE business_id=? ORDER BY id', [$biz]));
$t['pl_categories'] = array_map(fn($x) => ['kind' => $x['kind'], 'title' => $x['title'], 'account_code' => $code($x['default_account_id'])],
    Database::all('SELECT * FROM profit_loss_categories WHERE business_id=? ORDER BY id', [$biz]));
$t['waste_reasons'] = array_map(fn($x) => ['title' => $x['title'], 'expense_account_code' => $code($x['expense_account_id'])],
    Database::all('SELECT * FROM waste_reasons WHERE business_id=? ORDER BY id', [$biz]));
$t['settings'] = array_map(fn($x) => ['category' => $x['category'], 'setting_key' => $x['setting_key'], 'value_json' => $x['value_json'],
    'value_type' => $x['value_type'], 'title_fa' => $x['title_fa'], 'group_fa' => $x['group_fa']],
    Database::all('SELECT * FROM settings WHERE business_id=? ORDER BY id', [$biz]));
$t['number_sequences'] = array_map(fn($x) => ['doc_type' => $x['doc_type'], 'template' => $x['template'], 'next_value' => (int)$x['next_value'],
    'step' => (int)$x['step'], 'reset_yearly' => (int)$x['reset_yearly']],
    Database::all('SELECT * FROM number_sequences WHERE business_id=? ORDER BY id', [$biz]));
$t['print_templates'] = array_map(fn($x) => ['title' => $x['title'], 'template_type' => $x['template_type'], 'paper_size' => $x['paper_size'],
    'show_logo' => (int)$x['show_logo'], 'logo_position' => $x['logo_position'], 'font_size' => (int)$x['font_size'],
    'show_signature' => (int)$x['show_signature'], 'amount_in_words' => (int)$x['amount_in_words'], 'show_economic_code' => (int)$x['show_economic_code'],
    'show_bank_info' => (int)$x['show_bank_info'], 'show_barcode' => (int)$x['show_barcode'], 'is_default' => (int)$x['is_default'], 'status' => $x['status']],
    Database::all('SELECT * FROM print_templates WHERE business_id=? ORDER BY id', [$biz]));
// قواعد سند خودکار
$rules = [];
foreach (Database::all('SELECT * FROM auto_entry_rules WHERE business_id=? ORDER BY id', [$biz]) as $r) {
    $lines = [];
    foreach (Database::all('SELECT * FROM auto_entry_rule_lines WHERE rule_id=? ORDER BY row_order, id', [$r['id']]) as $l) {
        $lines[] = ['side' => $l['side'], 'account_source' => $l['account_source'], 'mapping_key' => $l['mapping_key'],
            'account_code' => $code($l['account_id']), 'amount_source' => $l['amount_source'], 'row_order' => (int)$l['row_order']];
    }
    $rules[] = ['event_key' => $r['event_key'], 'title_fa' => $r['title_fa'], 'priority' => (int)$r['priority'],
        'is_enabled' => (int)$r['is_enabled'], 'description' => $r['description'], 'lines' => $lines];
}
$t['auto_entry_rules'] = $rules;
// نقش‌ها و مجوزها
$roles = [];
foreach (Database::all('SELECT * FROM roles WHERE business_id=? ORDER BY id', [$biz]) as $r) {
    $perms = Database::all('SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id WHERE rp.role_id=?', [$r['id']]);
    $roles[] = ['name' => $r['name'], 'slug' => $r['slug'], 'description' => $r['description'], 'is_system' => (int)$r['is_system'],
        'permissions' => array_column($perms, 'slug')];
}
$t['roles'] = $roles;
$t['meta'] = ['source_business_id' => $biz, 'exported_at' => date('c'), 'accounts' => count($t['chart_of_accounts']),
    'rules' => count($rules), 'settings' => count($t['settings']), 'permissions_total' => (int)Database::val('SELECT COUNT(*) FROM permissions', [], 0)];
$out = "<?php\n/** قالب پیش‌فرض کسب‌وکار — تولیدشده در ".date('Y-m-d H:i')." از کسب‌وکار #{$biz}\n *  در راه‌اندازی کسب‌وکار جدید، این ساختار کپی می‌شود (کدینگ، نگاشت‌ها، قواعد سند، مالیات‌ها، تنظیمات، شماره‌گذاری، نقش‌ها).\n */\nreturn ".var_export($t, true).";\n";
file_put_contents(__DIR__.'/../app/Data/business_template.php', $out);
echo "Template written: accounts=".count($t['chart_of_accounts'])." mappings=".count($t['account_mappings'])." rules=".count($rules)
   ." taxes=".count($t['taxes'])." settings=".count($t['settings'])." roles=".count($roles)." size=".round(strlen($out)/1024)."KB\n";
