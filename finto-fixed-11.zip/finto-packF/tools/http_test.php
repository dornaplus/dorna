<?php
/**
 * آزمون سرتاسری HTTP: زنجیره ثبت‌نام/راه‌اندازی + پیمایش همه صفحه‌های نرم‌افزار.
 * اجرا:  php tools/http_test.php [base_url]      (سرور باید در حال اجرا باشد)
 * مثال:  php -S 0.0.0.0:8080 -t public tools/serve.php
 */
require __DIR__.'/../app/bootstrap.php';   // برای دسترسی به Meta::reports() در فهرست گزارش‌ها
$base = rtrim($argv[1] ?? 'http://127.0.0.1:8080', '/');
$jar  = sys_get_temp_dir().'/finto_http_cookies.txt';
@unlink($jar);
$pass = 0; $fail = 0; $problems = [];
$logMark = is_file(__DIR__.'/../storage/error.log') ? filesize(__DIR__.'/../storage/error.log') : 0;
if (is_file(__DIR__.'/../storage/sms.log')) @unlink(__DIR__.'/../storage/sms.log');

function curl_req(string $base, string $jar, string $method, string $path, array $post = null, array $opt = []): array
{
    $ch = curl_init($base.str_replace(' ', '%20', $path));
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        CURLOPT_FOLLOWLOCATION => false, CURLOPT_HEADER => true, CURLOPT_TIMEOUT => 30,
        CURLOPT_USERAGENT => 'FintoTest/1.0',
    ]);
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post ?? []));
    }
    if (!empty($opt['follow'])) { curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); curl_setopt($ch, CURLOPT_MAXREDIRS, 5); }
    $raw = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hlen = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    $headers = substr((string)$raw, 0, $hlen);
    $body = substr((string)$raw, $hlen);
    preg_match('/^Location:\s*(.+)$/mi', $headers, $lm);
    return ['code' => $code, 'body' => $body, 'location' => trim($lm[1] ?? ''), 'headers' => $headers];
}
function token(string $base, string $jar, string $path): string
{
    $r = curl_req($base, $jar, 'GET', $path);
    preg_match('/name="_token" value="([^"]+)"/', $r['body'], $m);
    return $m[1] ?? '';
}

/** تولید کد ملی معتبر (با رقم کنترل صحیح) برای آزمون */
function valid_national_id(): string
{
    do {
        $d = [];
        for ($i = 0; $i < 9; $i++) $d[] = random_int(0, 9);
        $sum = 0;
        foreach ($d as $i => $v) $sum += $v * (10 - $i);
        $r = $sum % 11;
        $check = $r < 2 ? $r : 11 - $r;
        $code = implode('', $d).$check;
    } while (count(array_unique(str_split($code))) === 1);
    return $code;
}

function t(string $name, callable $fn): void
{
    global $pass, $fail, $problems;
    try {
        $msg = $fn();
        $pass++; echo "PASS  $name  →  $msg\n";
    } catch (Throwable $e) {
        $fail++; $problems[] = $name.': '.$e->getMessage();
        echo "FAIL  $name\n        ".str_replace("\n", "\n        ", $e->getMessage())."\n";
    }
}
function expect(bool $ok, string $msg): void { if (!$ok) throw new RuntimeException($msg); }
function expect_ok(array $r, string $what): string
{
    expect($r['code'] === 200, "$what — کد پاسخ {$r['code']} (انتظار 200)".(str_contains($r['body'], 'خطا در پردازش') ? " | خطای برنامه: ".mb_substr(strip_tags($r['body']), 0, 260) : ''));
    expect(!str_contains($r['body'], 'خطا در پردازش درخواست'), "$what — صفحه خطا برگشت");
    return "$what OK (".strlen($r['body'])." بایت)";
}

/* ─────────── ۱) صفحه عمومی ─────────── */
t('صفحه اصلی (landing)', fn() => expect_ok(curl_req($base, $jar, 'GET', '/'), 'landing'));
t('ورود (login)', fn() => expect_ok(curl_req($base, $jar, 'GET', '/login'), 'login'));
t('قوانین و شرایط', fn() => expect_ok(curl_req($base, $jar, 'GET', '/terms'), 'terms'));

/* ─────────── ۲) زنجیره ثبت‌نام ─────────── */
$mobile = '0912'.random_int(1000000, 9999999);
$password = 'Test@1404';
t('۱) ثبت‌نام: موبایل + رمز عبور', function () use ($base, $jar, $mobile, $password) {
    $tok = token($base, $jar, '/register');
    $r = curl_req($base, $jar, 'POST', '/register', ['_token' => $tok, 'mobile' => $mobile, 'password' => $password,
        'password_confirmation' => $password, 'accept_terms' => '1']);
    expect(in_array($r['code'], [302, 303], true), 'کد پاسخ '.$r['code'].' — انتظار هدایت به صفحه کد تایید');
    expect(str_contains($r['location'], '/verify'), 'هدایت به '.$r['location'].' (انتظار /verify)');
    return "موبایل $mobile → $r[location]";
});
t('۲) کد تایید: دریافت و تایید کد', function () use ($base, $jar) {
    $page = curl_req($base, $jar, 'GET', '/verify');
    expect_ok($page, 'صفحه کد تایید');
    $code = '';
    // ۱) کد نمایشی روی همان صفحه (حالت demo_mode)
    if (preg_match('/کد تایید این شماره «(\d{6})»/u', $page['body'], $m)) $code = $m[1];
    // ۲) فایل sms.log
    if ($code === '') {
        $log = @file_get_contents(__DIR__.'/../storage/sms.log') ?: '';
        preg_match_all('/(\d{6})/', $log, $mm);
        $code = (string)(end($mm[1]) ?: '');
    }
    // ۳) جدول messages (متن پیامک)
    if ($code === '') {
        $body = (string)Database::val('SELECT body FROM messages WHERE channel="sms" ORDER BY id DESC LIMIT 1', [], '');
        preg_match_all('/(\d{6})/', $body, $mm);
        $code = (string)(end($mm[1]) ?: '');
    }
    expect(strlen($code) === 6, 'کد تایید در صفحه/لاگ/جدول messages یافت نشد');
    $tok = token($base, $jar, '/verify');
    $r = curl_req($base, $jar, 'POST', '/verify', ['_token' => $tok, 'code' => $code]);
    expect(in_array($r['code'], [302, 303], true), 'کد پاسخ '.$r['code']);
    expect(str_contains($r['location'], '/onboarding/profile'), 'هدایت به '.$r['location'].' (انتظار /onboarding/profile)');
    return "کد $code → $r[location]";
});
t('۳) اطلاعات شخصی (نام، نام خانوادگی، کد ملی)', function () use ($base, $jar) {
    $tok = token($base, $jar, '/onboarding/profile');
    $r = curl_req($base, $jar, 'POST', '/onboarding/profile', ['_token' => $tok, 'first_name' => 'آزمون',
        'last_name' => 'سرتاسری', 'national_id' => valid_national_id(), 'email' => 'test'.random_int(100, 999).'@example.com']);
    expect(in_array($r['code'], [302, 303], true), 'کد پاسخ '.$r['code'].' — '.mb_substr(strip_tags($r['body']), 0, 200));
    expect(str_contains($r['location'], '/onboarding/business'), 'هدایت به '.$r['location']);
    return 'ذخیره شد → '.$r['location'];
});
t('۴) اطلاعات کسب‌وکار', function () use ($base, $jar) {
    $tok = token($base, $jar, '/onboarding/business');
    $r = curl_req($base, $jar, 'POST', '/onboarding/business', ['_token' => $tok, 'name' => 'شرکت آزمون سرتاسری',
        'activity_type' => 'bazargardani', 'legal_type' => 'hoqoqi', 'currency_id' => '2', 'province_id' => '1', 'city_id' => '1',
        'national_id' => '10101010101', 'economic_code' => '411111111111', 'phone' => '02188889999', 'mobile' => '09121112233',
        'fy_title' => 'سال مالی ۱۴۰۵', 'fy_start' => '1405/01/01', 'fy_end' => '1405/12/29']);
    expect(in_array($r['code'], [302, 303], true), 'کد پاسخ '.$r['code'].' — '.mb_substr(strip_tags($r['body']), 0, 300));
    expect(str_contains($r['location'], '/onboarding/done'), 'هدایت به '.$r['location']);
    return 'کسب‌وکار ایجاد شد → '.$r['location'];
});
t('۵) اجرای نرم‌افزار (پس از راه‌اندازی)', function () use ($base, $jar) {
    expect_ok(curl_req($base, $jar, 'GET', '/onboarding/done'), 'صفحه پایان راه‌اندازی');
    return expect_ok(curl_req($base, $jar, 'GET', '/app'), 'داشبورد');
});

/* ─────────── ۳) پیمایش همه صفحه‌ها ─────────── */
$pages = ['/app', '/app/my-account', '/app/invoices', '/app/invoices?type=buy', '/app/invoices?type=sale_return',
    '/app/invoices/create?type=sale', '/app/receipts', '/app/receipts/create', '/app/payments', '/app/payments/create', '/app/cheques?direction=received',
    '/app/cheques?direction=issued', '/app/cheques/create?direction=received', '/app/transfers/create', '/app/inventory-documents', '/app/inventory-documents/create?doc_type=receive',
    '/app/inventory-documents/create?doc_type=issue', '/app/inventory-documents/create?doc_type=waste', '/app/stock-transfers/create', '/app/stock-counts', '/app/stock-counts/create',
    '/app/expenses', '/app/expenses/create', '/app/incomes', '/app/incomes/create', '/app/journal', '/app/journal/create', '/app/opening-balances/setup',
    '/app/payroll-documents/create', '/app/reports', '/app/settings/business', '/app/settings/financial', '/app/settings/hr', '/app/settings/sms',
    '/app/plans', '/app/subscription', '/app/tickets', '/app/tickets/create',
    '/app/persons', '/app/persons/create', '/app/users', '/app/users/create', '/app/roles', '/app/roles/create',
    '/app/products', '/app/products/create', '/app/units', '/app/units/create', '/app/person-types', '/app/person-types/create',
    '/app/taxes', '/app/taxes/create', '/app/fiscal-years', '/app/account-mappings', '/app/leave-types', '/app/leave-types/create',
    '/app/attendance-devices', '/app/attendance-devices/create', '/app/message-templates', '/app/message-credits', '/app/messages',
    '/app/employees', '/app/employees/create', '/app/warehouses', '/app/warehouses/create', '/app/cash-accounts', '/app/cash-accounts/create',
    '/app/chart-of-accounts', '/app/chart-of-accounts/create', '/app/projects', '/app/projects/create', '/app/cost-centers', '/app/cost-centers/create',
    '/app/shareholders', '/app/marketers', '/app/pl-categories', '/app/waste-reasons', '/app/price-types', '/app/payment-methods', '/app/payment-terms',
    '/app/number-sequences', '/app/print-templates', '/app/audit-logs', '/app/subscription-payments', '/app/stock-available', '/app/bank-statements',
    '/app/import-jobs', '/app/backup-jobs', '/app/auto-rules', '/app/moadian-settings'];
$pages[] = '/app/search?q='.rawurlencode('نمونه');
foreach ($pages as $p) {
    t('صفحه '.$p, function () use ($base, $jar, $p) { return expect_ok(curl_req($base, $jar, 'GET', $p), $p); });
}

/* ─────────── ۴) گزارش‌ها ─────────── */
foreach (array_keys(Meta::reports()) as $key) {
    t('گزارش '.$key, function () use ($base, $jar, $key) { return expect_ok(curl_req($base, $jar, 'GET', '/app/reports/'.$key), $key); });
}

/* ─────────── ۵) خطاهای ثبت‌شده در سرور ─────────── */
t('بدون خطای PHP در لاگ برنامه', function () use ($logMark) {
    $f = __DIR__.'/../storage/error.log';
    if (!is_file($f)) return 'لاگ خطایی وجود ندارد';
    $new = substr((string)file_get_contents($f), $logMark);
    expect(trim($new) === '', "خطاهای جدید:\n".mb_substr($new, 0, 2500));
    return 'لاگ تمیز است';
});

echo str_repeat('─', 46)."\nنتیجه: $pass موفق، $fail ناموفق\n";
if ($problems) { echo "موارد ناموفق:\n - ".implode("\n - ", array_map(fn($p) => mb_substr($p, 0, 220), $problems))."\n"; }
exit($fail ? 1 : 0);
