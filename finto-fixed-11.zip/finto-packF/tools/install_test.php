<?php
/**
 * آزمون خودکار نصب‌کننده وبی (همان کاری که مرورگر انجام می‌دهد):
 * پیش‌نیازها → آزمون اتصال → درون‌ریزی بخش‌به‌بخش → پایان نصب → بررسی سلامت → ورود به برنامه.
 *
 * اجرا:  php tools/install_test.php [base_url] [db_name] [db_user] [db_pass] [demo(1|0)]
 * مثال:  php tools/install_test.php http://127.0.0.1:8082 finto_cpanel root '' 1
 */
$base = rtrim($argv[1] ?? 'http://127.0.0.1:8082', '/');
$dbName = $argv[2] ?? 'finto_cpanel';
$dbUser = $argv[3] ?? 'root';
$dbPass = $argv[4] ?? '';
$demo   = ($argv[5] ?? '1') === '1';
$wipe   = ($argv[6] ?? '0') === '1';   // ۱ = پاک‌سازی و نصب از نو
$jar = sys_get_temp_dir().'/finto_install_cookies.txt';
@unlink($jar);

function R(string $m, string $p, array $post = null): array
{
    global $base, $jar;
    $ch = curl_init($base.$p);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        CURLOPT_HEADER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 180]);
    if ($m === 'POST') { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post ?? [])); }
    $raw = (string)curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hl = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);
    preg_match('/^Location:\s*(.+)$/mi', substr($raw, 0, $hl), $l);
    return ['code' => $code, 'body' => substr($raw, $hl), 'location' => trim($l[1] ?? '')];
}
function J(string $action, array $post = []): array
{
    $r = R('POST', '/install.php?action='.$action, $post);
    $d = json_decode($r['body'], true);
    if (!is_array($d)) throw new RuntimeException("پاسخ JSON نامعتبر از action=$action (HTTP {$r['code']}): ".mb_substr(strip_tags($r['body']), 0, 300));
    return $d;
}
$fail = 0;
$ok = function (string $msg): void { echo "PASS  $msg\n"; };
$bad = function (string $msg) use (&$fail): void { $fail++; echo "FAIL  $msg\n"; };

/* ۰) صفحه نصب‌کننده باز می‌شود */
$page = R('GET', '/install.php');
if ($page['code'] === 200 && str_contains($page['body'], 'نصب نرم‌افزار حسابداری')) $ok('صفحه نصب‌کننده باز شد ('.strlen($page['body']).' بایت)');
else $bad('صفحه نصب‌کننده باز نشد (HTTP '.$page['code'].')');

/* ۱) پیش‌نیازها */
$d = J('requirements');
$badRows = array_values(array_filter($d['rows'] ?? [], fn($r) => !$r['ok'] && empty($r['soft'])));
if (($d['ok'] ?? false)) $ok('بررسی پیش‌نیازها: همه '.count($d['rows']).' مورد موفق');
else $bad('پیش‌نیازها ناموفق: '.implode(' | ', array_map(fn($r) => $r['label'].'='.$r['value'], $badRows)));

/* ۲) آزمون اتصال دیتابیس */
$d = J('testdb', ['host' => 'localhost', 'port' => 3306, 'name' => $dbName, 'user' => $dbUser, 'pass' => $dbPass, 'socket' => '']);
if (($d['ok'] ?? false)) $ok('اتصال دیتابیس برقرار شد — '.$d['version'].' | '.$d['pretty']);
else $bad('اتصال دیتابیس ناموفق: '.($d['error'] ?? '?'));

/* ۳) درون‌ریزی بخش‌به‌بخش */
$part = 0; $guard = 0; $imported = 0; $skipped = false;
while (true) {
    $d = J('import', ['part' => $part, 'demo' => $demo ? '1' : '0', 'wipe' => $wipe ? '1' : '0']);
    if (!($d['ok'] ?? false)) { $bad('خطا در درون‌ریزی: '.($d['error'] ?? '?')); break; }
    $imported = $d['done'] ? $d['sent'] : $d['doneCount'];
    if (!empty($d['existing'])) $skipped = true;
    if ($d['done']) break;
    $part++;
    if (++$guard > 200) { $bad('حلقه درون‌ریزی بیش از حد طول کشید'); break; }
}
if (!$fail) $ok(($skipped ? 'ساختار دیتابیس از قبل موجود بود؛ درون‌ریزی انجام نشد' : 'درون‌ریزی کامل شد — '.$imported.' دستور SQL در '.($part + 1).' بخش'));

/* ۴) پایان نصب */
$d = J('finalize', ['demo' => $demo ? '1' : '0', 'demomode' => '1']);
if (($d['ok'] ?? false)) $ok('پایان نصب: '.$d['tables'].' جدول، '.$d['views'].' نما | '.$d['fiscal']);
else $bad('پایان نصب ناموفق: '.($d['error'] ?? '?'));

/* ۵) بررسی سلامت */
$d = J('health');
$badRows = array_values(array_filter($d['rows'] ?? [], fn($r) => !$r['ok'] && empty($r['soft'])));
if (($d['ok'] ?? false) && !$badRows) $ok('بررسی سلامت: همه موارد سالم');
else $bad('بررسی سلامت: '.(implode(' | ', array_map(fn($r) => $r['label'], $badRows)) ?: 'ناموفق'));

/* ۶) صفحه health.php */
$page = R('GET', '/health.php');
$badCount = substr_count($page['body'], '✘');
if ($page['code'] === 200 && $badCount === 0) $ok('صفحه health.php: همه موارد ✔');
else $bad("صفحه health.php: $badCount مورد ناموفق");

/* ۷) ورود به برنامه (بدون داده نمایشی، ابتدا ثبت‌نام) */
if ($demo) {
    $login = R('GET', '/login');
    preg_match('/name="_token" value="([^"]+)"/', $login['body'], $m);
    $r = R('POST', '/login', ['_token' => $m[1] ?? '', 'mobile' => '09120000001', 'password' => 'demo1234']);
    $dash = R('GET', '/app');
    if (in_array($r['code'], [301, 302, 303], true) && $dash['code'] === 200 && str_contains($dash['body'], 'kpi')) {
        $ok('ورود با کاربر نمایشی و باز شدن داشبورد ('.strlen($dash['body']).' بایت)');
    } else {
        $bad('ورود/داشبورد ناموفق (login '.$r['code'].'، dashboard '.$dash['code'].')');
    }
} else {
    $reg = R('GET', '/register');
    if ($reg['code'] === 200) $ok('صفحه ثبت‌نام باز شد (برای ساخت کسب‌وکار جدید)');
    else $bad('صفحه ثبت‌نام باز نشد ('.$reg['code'].')');
}

/* ۸) دارایی‌ها و مسدودسازی مسیرهای حساس */
foreach ([['/assets/theme.css', 200], ['/assets/app.js', 200], ['/config.local.php', 403], ['/app/Database.php', 403], ['/db/finto.sql', 403], ['/storage/error.log', 403]] as [$p, $expect]) {
    $r = R('GET', $p);
    if ($r['code'] === $expect) $ok("مسیر $p → HTTP {$r['code']}");
    else $bad("مسیر $p → HTTP {$r['code']} (انتظار $expect)");
}

echo str_repeat('─', 52)."\n";
echo $fail ? "نتیجه آزمون نصب: ناموفق ($fail مورد)\n" : "نتیجه آزمون نصب: همه مراحل موفق ✅\n";
exit($fail ? 1 : 0);
