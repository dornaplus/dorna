<?php
/**
 * آزمون عملیاتی (سرتاسری) اسناد اصلی: فاکتور، دریافت، پرداخت، چک، انتقال، اسناد انبار، انبارگردانی،
 * هزینه/درآمد، سند دستی، حقوق و دستمزد، خرید اشتراک، تنظیمات و پشتیبانی.
 * اجرا:  FINTO_DB_NAME=finto_test php tools/ops_test.php [base_url]
 * پیش‌نیاز:  php -S 0.0.0.0:8081 -t public tools/serve.php   (با FINTO_DB_NAME=finto_test)
 */
require __DIR__.'/../app/bootstrap.php';
$base = rtrim($argv[1] ?? 'http://127.0.0.1:8081', '/');
$jar = sys_get_temp_dir().'/finto_ops_cookies.txt'; @unlink($jar);
$BIZ = 1; $USER = '09120000001'; $PASS = 'demo1234';
$pass = 0; $fail = 0; $fails = [];

function R(string $m, string $p, array $post = null): array
{
    global $base, $jar;
    $ch = curl_init($base.$p);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_COOKIEJAR => $jar, CURLOPT_COOKIEFILE => $jar,
        CURLOPT_HEADER => true, CURLOPT_FOLLOWLOCATION => false, CURLOPT_TIMEOUT => 60]);
    if ($m === 'POST') { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post ?? [])); }
    $raw = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); $hl = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE); curl_close($ch);
    preg_match('/^Location:\s*(.+)$/mi', substr((string)$raw, 0, $hl), $l);
    return ['code' => $code, 'body' => substr((string)$raw, $hl), 'location' => trim($l[1] ?? '')];
}
function T(string $p): string { $r = R('GET', $p); preg_match('/name="_token" value="([^"]+)"/', $r['body'], $m); return $m[1] ?? ''; }
function toasts(array $r): array
{
    preg_match_all('#<div class="toast (success|error|info|warn)">(.*?)</div>#su', $r['body'], $fm);
    $o = []; foreach ($fm[2] as $i => $x) $o[] = $fm[1][$i].': '.trim(strip_tags($x)); return $o;
}
function step(string $name, callable $fn): void
{
    global $pass, $fail, $fails;
    try { $msg = $fn(); $pass++; echo "PASS  $name  →  $msg\n"; }
    catch (Throwable $e) { $fail++; $fails[] = $name.': '.$e->getMessage(); echo "FAIL  $name\n        ".mb_substr($e->getMessage(), 0, 400)."\n"; }
}

/* ورود */
$t = T('/login');
$r = R('POST', '/login', ['_token' => $t, 'mobile' => $USER, 'password' => $PASS]);
if (!in_array($r['code'], [301, 302, 303], true)) { fwrite(STDERR, "ورود ناموفق: {$r['code']}\n"); exit(1); }

$wh = (int)Database::val('SELECT id FROM warehouses WHERE business_id=? ORDER BY id LIMIT 1', [$BIZ], 1);
$pid = (int)Database::val("SELECT b.product_id FROM stock_balances b JOIN products p ON p.id=b.product_id
                            WHERE b.business_id=? AND b.warehouse_id=? AND b.quantity>0 AND p.item_type='goods' ORDER BY b.quantity DESC LIMIT 1", [$BIZ, $wh], 0);
$person = (int)Database::val("SELECT id FROM persons WHERE business_id=? AND person_kind='haqiqi' ORDER BY id LIMIT 1", [$BIZ], 1);
$supplier = (int)Database::val("SELECT id FROM persons WHERE business_id=? AND person_kind='hoqoqi' ORDER BY id DESC LIMIT 1", [$BIZ], $person);
$cash = (int)Database::val('SELECT id FROM cash_accounts WHERE business_id=? ORDER BY id LIMIT 1', [$BIZ], 1);
$cash2 = (int)Database::val('SELECT id FROM cash_accounts WHERE business_id=? ORDER BY id DESC LIMIT 1', [$BIZ], $cash);

step('ورود کاربر نمایشی', fn() => 'وارد شد (' . $USER . ')');

/* ۱) فاکتور فروش + قطعی‌سازی */
$invId = 0;
step('فاکتور فروش + قطعی‌سازی', function () use ($person, $wh, $pid, $BIZ, &$invId) {
    $t = T('/app/invoices/create?type=sale');
    $r = R('POST', '/app/invoices', ['_token' => $t, 'invoice_type' => 'sale', 'person_id' => $person, 'warehouse_id' => $wh,
        'invoice_date' => jdate(today()), 'settlement_type' => 'credit', 'invoice_discount' => '0', 'save_mode' => 'post',
        'line_product_id' => [$pid], 'line_quantity' => ['2'], 'line_unit_price' => ['5000000'], 'line_discount' => ['0'], 'line_desc' => ['آزمون']]);
    $invId = (int)preg_replace('/\D/', '', $r['location']);
    $inv = Database::one('SELECT invoice_no,status,journal_entry_id,total_amount FROM invoices WHERE id=?', [$invId]);
    if (!$inv) throw new RuntimeException('فاکتور ثبت نشد: '.implode('|', toasts(R('GET', '/app/invoices/create?type=sale'))));
    if ($inv['status'] !== 'posted' || !$inv['journal_entry_id']) throw new RuntimeException('فاکتور قطعی/سند نشد ('.$inv['status'].')');
    $doc = Database::val('SELECT id FROM inventory_documents WHERE business_id=? AND source_type="invoice" AND source_id=?', [$BIZ, $invId], 0);
    return $inv['invoice_no'].' | مبلغ '.number_format((float)$inv['total_amount']).' | سند #'.$inv['journal_entry_id'].' | سند انبار #'.$doc;
});

/* ۲) دریافت از مشتری و تسویه */
step('دریافت از مشتری (تسویه فاکتور)', function () use ($person, $cash, $invId) {
    $t = T('/app/receipts/create');
    $r = R('POST', '/app/receipts', ['_token' => $t, 'person_id' => $person, 'cash_account_id' => $cash, 'doc_date' => jdate(today()),
        'amount' => '4000000', 'payment_method_id' => 1, 'payment_kind' => 'cash',
        'alloc_invoice_id' => [$invId], 'alloc_amount' => ['4000000']]);
    $rec = Database::one('SELECT * FROM receipts WHERE business_id=? ORDER BY id DESC LIMIT 1', [1]);
    $st = Database::val('SELECT settlement_status FROM invoices WHERE id=?', [$invId], '—');
    if (!$rec) throw new RuntimeException('دریافت ثبت نشد: '.implode('|', toasts(R('GET', '/app/receipts/create'))));
    return $rec['doc_no'].' | وضعیت تسویه فاکتور: '.$st;
});

/* ۳) فاکتور خرید + پرداخت */
step('فاکتور خرید و پرداخت به تأمین‌کننده', function () use ($supplier, $cash, $pid) {
    $t = T('/app/invoices/create?type=buy');
    $r = R('POST', '/app/invoices', ['_token' => $t, 'invoice_type' => 'buy', 'person_id' => $supplier, 'warehouse_id' => $wh ?? 1,
        'invoice_date' => jdate(today()), 'settlement_type' => 'credit', 'save_mode' => 'post',
        'line_product_id' => [$pid], 'line_quantity' => ['3'], 'line_unit_price' => ['2000000'], 'line_discount' => ['0'], 'line_desc' => ['خرید آزمون']]);
    $invId = (int)preg_replace('/\D/', '', $r['location']);
    if (!$invId) throw new RuntimeException('فاکتور خرید ثبت نشد: '.implode('|', toasts(R('GET', '/app/invoices/create?type=buy'))));
    $t2 = T('/app/payments/create');
    $r2 = R('POST', '/app/payments', ['_token' => $t2, 'person_id' => $supplier, 'cash_account_id' => $cash, 'doc_date' => jdate(today()),
        'amount' => '3000000', 'payment_method_id' => 1, 'alloc_invoice_id' => [$invId], 'alloc_amount' => ['3000000']]);
    $pay = Database::one('SELECT * FROM payments WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    $inv = Database::one('SELECT invoice_no FROM invoices WHERE id=?', [$invId]);
    if (!$pay) throw new RuntimeException('پرداخت ثبت نشد: '.implode('|', toasts(R('GET', '/app/payments/create'))));
    return $inv['invoice_no'].' + '.$pay['doc_no'];
});

/* ۴) چک دریافتی و رویداد خواباندن/وصول */
step('چک دریافتی (ثبت + وصول)', function () use ($person, $cash) {
    $t = T('/app/cheques/create?direction=received');
    $r = R('POST', '/app/cheques', ['_token' => $t, 'direction' => 'received', 'cheque_no' => 'CHK'.random_int(100000, 999999),
        'bank_name' => 'بانک ملت', 'person_id' => $person, 'amount' => '2500000', 'issue_date' => jdate(today()), 'due_date' => jdate(today()),
        'cash_account_id' => $cash, 'description' => 'آزمون']);
    $ch = Database::one('SELECT * FROM cheques WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$ch) throw new RuntimeException('چک ثبت نشد: '.implode('|', toasts(R('GET', '/app/cheques/create?direction=received'))));
    foreach (['deposited', 'cleared'] as $ev) {
        $t2 = T('/app/cheques/'.$ch['id']);
        R('POST', '/app/cheques/'.$ch['id'].'/event', ['_token' => $t2, 'event' => $ev, 'event_date' => jdate(today()), 'cash_account_id' => $cash]);
    }
    $ch2 = Database::one('SELECT status FROM cheques WHERE id=?', [$ch['id']]);
    return $ch['cheque_no'].' → وضعیت '.$ch2['status'];
});

/* ۵) انتقال وجه */
step('انتقال وجه بین حساب‌ها', function () use ($cash, $cash2) {
    $t = T('/app/transfers/create');
    $r = R('POST', '/app/transfers', ['_token' => $t, 'from_cash_account_id' => $cash, 'to_cash_account_id' => $cash2,
        'doc_date' => jdate(today()), 'amount' => '1000000', 'description' => 'آزمون انتقال']);
    $tr = Database::one('SELECT * FROM transfers WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$tr) throw new RuntimeException('انتقال ثبت نشد: '.implode('|', toasts(R('GET', '/app/transfers/create'))));
    return $tr['doc_no'];
});

/* ۶) اسناد انبار: ورود، خروج، ضایعات، انتقال */
step('اسناد انبار (ورود/خروج/ضایعات/انتقال)', function () use ($pid, $wh, $cash2) {
    $before = (float)Database::val('SELECT quantity FROM stock_balances WHERE business_id=1 AND warehouse_id=? AND product_id=?', [$wh, $pid], 0);
    $out = [];
    foreach ([['receive', '10'], ['issue', '2'], ['waste', '1']] as [$dt, $qty]) {
        $t = T('/app/inventory-documents/create?doc_type='.$dt);
        $r = R('POST', '/app/inventory-documents', ['_token' => $t, 'doc_type' => $dt, 'doc_date' => jdate(today()), 'warehouse_id' => $wh,
            'description' => 'آزمون '.$dt, 'line_product_id' => [$pid], 'line_quantity' => [$qty], 'line_unit_cost' => ['1500000']]);
        $doc = Database::one('SELECT * FROM inventory_documents WHERE business_id=1 ORDER BY id DESC LIMIT 1');
        if (!$doc) throw new RuntimeException("سند $dt ثبت نشد: ".implode('|', toasts(R('GET', '/app/inventory-documents/create?doc_type='.$dt))));
        $out[] = $doc['doc_no'];
    }
    $t = T('/app/stock-transfers/create');
    R('POST', '/app/stock-transfers', ['_token' => $t, 'doc_date' => jdate(today()), 'warehouse_id' => $wh, 'dest_warehouse_id' => $cash2 ? (int)Database::val('SELECT id FROM warehouses WHERE business_id=1 ORDER BY id DESC LIMIT 1') : 1,
        'line_product_id' => [$pid], 'line_quantity' => ['1']]);
    $after = (float)Database::val('SELECT quantity FROM stock_balances WHERE business_id=1 AND warehouse_id=? AND product_id=?', [$wh, $pid], 0);
    return implode('، ', $out).' | موجودی '.num($before, 0).' → '.num($after, 0);
});

/* ۷) انبارگردانی */
step('انبارگردانی (اختلاف و سند اصلاحی)', function () use ($pid, $wh) {
    $book = (float)Database::val('SELECT quantity FROM stock_balances WHERE business_id=1 AND warehouse_id=? AND product_id=?', [$wh, $pid], 0);
    $counted = max(0, $book - 1);
    $t = T('/app/stock-counts/create?warehouse_id='.$wh);
    $r = R('POST', '/app/stock-counts', ['_token' => $t, 'warehouse_id' => $wh, 'count_date' => jdate(today()), 'period_type' => 'adhoc',
        'counted' => [$pid => (string)$counted]]);
    $cnt = Database::one('SELECT * FROM stock_counts WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$cnt) throw new RuntimeException('انبارگردانی ثبت نشد: '.implode('|', toasts(R('GET', '/app/stock-counts/create?warehouse_id='.$wh))));
    $after = (float)Database::val('SELECT quantity FROM stock_balances WHERE business_id=1 AND warehouse_id=? AND product_id=?', [$wh, $pid], 0);
    return $cnt['doc_no'].' | اختلاف '.num($book - $counted, 0).' | موجودی '.num($after, 0).' | سند #'.(int)$cnt['journal_entry_id'];
});

/* ۸) هزینه و درآمد */
step('سند هزینه و سند درآمد', function () use ($person) {
    $out = [];
    foreach ([['expenses', 'expense'], ['incomes', 'income']] as [$path, $kind]) {
        $t = T('/app/'.$path.'/create');
        $r = R('POST', '/app/'.$path, ['_token' => $t, 'doc_date' => jdate(today()), 'title' => ($kind === 'expense' ? 'هزینه آزمون' : 'درآمد آزمون'),
            'person_id' => $person, 'cash_account_id' => '', 'refundable' => 'no', 'account_id' => '',
            'line_title' => ['ردیف آزمون'], 'line_account_id' => [''], 'line_amount' => ['750000'], 'line_tax_id' => ['']]);
        $tbl = $kind === 'expense' ? 'expense_documents' : 'income_documents';
        $doc = Database::one("SELECT * FROM `$tbl` WHERE business_id=1 ORDER BY id DESC LIMIT 1");
        if (!$doc) throw new RuntimeException("سند $kind ثبت نشد: ".implode('|', toasts(R('GET', '/app/'.$path.'/create'))));
        $out[] = $doc['doc_no'].' ('.number_format((float)$doc['amount']).')';
    }
    return implode(' ، ', $out);
});

/* ۹) سند دستی حسابداری */
step('سند دستی حسابداری', function () {
    $accDr = (int)Database::val('SELECT id FROM chart_of_accounts WHERE business_id=1 AND is_postable=1 AND account_type="asset" ORDER BY code LIMIT 1', [], 0);
    $accCr = (int)Database::val('SELECT id FROM chart_of_accounts WHERE business_id=1 AND is_postable=1 AND account_type="revenue" ORDER BY code LIMIT 1', [], 0);
    $t = T('/app/journal/create');
    $r = R('POST', '/app/journal', ['_token' => $t, 'entry_date' => jdate(today()), 'entry_type' => 'normal', 'description' => 'سند آزمون',
        'line_account_id' => [$accDr, $accCr], 'line_debit' => ['500000', ''], 'line_credit' => ['', '500000'],
        'line_desc' => ['بدهکار', 'بستانکار'], 'line_person_id' => ['', ''], 'line_cost_center_id' => ['', '']]);
    $je = Database::one('SELECT * FROM journal_entries WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$je || $je['status'] !== 'posted') throw new RuntimeException('سند ثبت نشد: '.implode('|', toasts(R('GET', '/app/journal/create'))));
    return 'سند '.$je['entry_no'].' | بدهکار '.number_format((float)$je['total_debit']);
});

/* ۱۰) سند حقوق و دستمزد */
step('سند حقوق و دستمزد', function () {
    $emp = Database::one('SELECT * FROM employees WHERE business_id=1 AND status="active" ORDER BY id LIMIT 1');
    if (!$emp) throw new RuntimeException('پرسنلی برای آزمون وجود ندارد.');
    $comps = Database::all('SELECT id FROM payroll_components WHERE business_id=1 AND is_active=1', []);
    $t = T('/app/payroll-documents/create');
    $post = ['_token' => $t, 'doc_date' => jdate(today()), 'period_title' => 'حقوق آزمون', 'cash_account_id' => '1',
        'employee_id' => [0 => $emp['id']], 'worked_days' => [0 => '30'], 'base_salary' => [0 => '120000000'], 'deductions' => [0 => '0']];
    foreach ($comps as $i => $c) $post['comp_amount'][0][$c['id']] = '0';
    $r = R('POST', '/app/payroll-documents', $post);
    $doc = Database::one('SELECT * FROM payroll_documents WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$doc) throw new RuntimeException('سند حقوق ثبت نشد: '.implode('|', toasts(R('GET', '/app/payroll-documents/create'))));
    return $doc['doc_no'].' | خالص '.number_format((float)$doc['net_amount']);
});

/* ۱۱) خرید اشتراک */
step('خرید اشتراک', function () {
    $plan = Database::one('SELECT * FROM plans WHERE is_active=1 ORDER BY id LIMIT 1');
    $t = T('/app/plans');
    R('POST', '/app/plans/'.$plan['id'].'/subscribe', ['_token' => $t, 'plan_id' => $plan['id'], 'months' => 12]);
    $sub = Database::one('SELECT * FROM subscriptions WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$sub) throw new RuntimeException('اشتراک ثبت نشد.');
    return 'اشتراک #'.$sub['id'].' — وضعیت '.$sub['status'].' (' . $plan['title'] . ')';
});

/* ۱۲) تنظیمات: ذخیره کلید */
step('ذخیره تنظیمات مالی', function () {
    $t = T('/app/settings/financial');
    R('POST', '/app/settings/financial', ['_token' => $t, 'setting' => ['financial.test_key' => 'ok'], 'type' => ['financial.test_key' => 'string']]);
    $v = Database::val('SELECT value_json FROM settings WHERE business_id=1 AND setting_key=?', ['financial.test_key'], '—');
    if ($v === '—') throw new RuntimeException('تنظیمات ذخیره نشد.');
    return 'financial.test_key = '.$v;
});

/* ۱۳) پشتیبانی: تیکت + پاسخ */
step('تیکت پشتیبانی + پاسخ', function () {
    $t = T('/app/tickets/create');
    R('POST', '/app/tickets/create', ['_token' => $t, 'subject' => 'آزمون پشتیبانی', 'request_type' => 'question', 'priority' => 'normal',
        'message' => 'سلام، این تیکت آزمایشی است.']);
    $tk = Database::one('SELECT * FROM tickets WHERE business_id=1 ORDER BY id DESC LIMIT 1');
    if (!$tk) throw new RuntimeException('تیکت ثبت نشد.');
    $t2 = T('/app/tickets/'.$tk['id']);
    R('POST', '/app/tickets/'.$tk['id'].'/reply', ['_token' => $t2, 'message' => 'پاسخ آزمایشی به تیکت']);
    $n = (int)Database::val('SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=?', [$tk['id']], 0);
    return $tk['ticket_no'].' | پیام‌ها: '.$n;
});

/* ۱۴) لاگ خطا */
step('لاگ خطای PHP تمیز', function () {
    $log = trim((string)@file_get_contents(__DIR__.'/../storage/error.log'));
    if ($log !== '') throw new RuntimeException("خطاهای ثبت‌شده:\n".mb_substr($log, -1500));
    return 'بدون خطا';
});

echo str_repeat('─', 46)."\nنتیجه عملیاتی: $pass موفق، $fail ناموفق\n";
if ($fails) echo "موارد ناموفق:\n - ".implode("\n - ", $fails)."\n";
exit($fail ? 1 : 0);
