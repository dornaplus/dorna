<?php
/**
 * ابزار نگهداری: ایجاد سال مالی جاری (بر اساس تاریخ امروز) برای کسب‌وکارهایی که سال مالی آن‌ها منقضی شده است.
 * اجرا:  php tools/roll_fiscal_year.php [business_id]
 * اگر شناسه کسب‌وکار داده نشود، برای همه کسب‌وکارها بررسی و در صورت نیاز سال مالی جدید ساخته می‌شود.
 */
require __DIR__.'/../app/bootstrap.php';
if (!function_exists('view')) require __DIR__.'/../app/Helpers.php';

$only = isset($argv[1]) ? (int)$argv[1] : 0;
$bizList = $only ? Database::all('SELECT id, name FROM businesses WHERE id=?', [$only])
                 : Database::all('SELECT id, name FROM businesses WHERE deleted_at IS NULL ORDER BY id');
if (!$bizList) { fwrite(STDERR, "کسب‌وکاری یافت نشد.\n"); exit(1); }

$today = today();
[$jy] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
$created = 0;

foreach ($bizList as $b) {
    $bizId = (int)$b['id'];
    $has = Database::val('SELECT COUNT(*) FROM fiscal_years WHERE business_id=? AND ? BETWEEN start_date AND end_date', [$bizId, $today]);
    echo "کسب‌وکار #$bizId — ".$b['name'].": ";
    if ($has) {
        $fy = Database::one('SELECT * FROM fiscal_years WHERE business_id=? AND ? BETWEEN start_date AND end_date ORDER BY id DESC LIMIT 1', [$bizId, $today]);
        if (!$fy['is_current']) {
            Database::run('UPDATE fiscal_years SET is_current=0 WHERE business_id=?', [$bizId]);
            Database::run('UPDATE fiscal_years SET is_current=1 WHERE id=?', [$fy['id']]);
        }
        echo "سال مالی جاری «{$fy['title']}» موجود است (".$fy['start_date']." تا ".$fy['end_date'].").\n";
        continue;
    }
    [$start, $end] = jalali_year_range($jy);
    $fyId = Provisioner::createFiscalYear($bizId, 'سال مالی '.$jy, $start, $end, Auth::id());
    $periods = (int)Database::val('SELECT COUNT(*) FROM fiscal_periods WHERE fiscal_year_id=?', [$fyId]);
    // انتقال مانده حساب‌ها به سال جدید: هیچ سندی صادر نمی‌شود؛ مانده ابتدای دوره از دفاتر سال‌های قبل خوانده می‌شود
    printf("سال مالی %d ساخته شد (شناسه %d، %d دوره).\n", $jy, $fyId, $periods);
    $created++;
}
echo $created ? "تعداد سال مالی ایجادشده: $created\n" : "نیازی به ایجاد سال مالی جدید نبود.\n";
