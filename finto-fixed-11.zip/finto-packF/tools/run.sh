#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
#  اجرای یک‌دستوری نرم‌افزار حسابداری فینتو
#  استفاده:  bash tools/run.sh            (پورت پیش‌فرض ۸۰۸۰)
#            PORT=9000 bash tools/run.sh (پورت دلخواه)
#  این اسکریپت: ۱) نصب پیش‌نیازها  ۲) راه‌اندازی MariaDB  ۳) ساخت/ورود دیتابیس
#               ۴) اجرای سرور وب روی پورت مشخص
# ─────────────────────────────────────────────────────────────
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${PORT:-8080}"
DB_NAME="${FINTO_DB_NAME:-finto_accounting}"
DB_USER="finto_app"
DB_PASS='Finto@1404#app'
SQL_FILE="${DB_SQL:-}"
PHP_EXT="php-cli php-mysql php-mbstring php-curl"

say() { printf '\033[1;35m▸\033[0m %s\n' "$*"; }
ok()  { printf '\033[1;32m✔\033[0m %s\n' "$*"; }
die() { printf '\033[1;31m✘\033[0m %s\n' "$*" >&2; exit 1; }

# مسیر فایل نصب دیتابیس را پیدا کن
if [ -z "$SQL_FILE" ]; then
  for c in "$ROOT/../db-design/mysql/99_install_all.sql" "$ROOT/db/99_install_all.sql" "$ROOT/../db/99_install_all.sql"; do
    [ -f "$c" ] && SQL_FILE="$c" && break
  done
fi

SUDO=""; [ "$(id -u)" != "0" ] && SUDO="sudo -n"

# ── ۱) پیش‌نیازهای PHP ──────────────────────────────────────
if ! command -v php >/dev/null 2>&1; then
  say "نصب PHP ..."
  $SUDO apt-get update -qq >/dev/null 2>&1 || true
  $SUDO apt-get install -y -qq $PHP_EXT >/dev/null 2>&1 || die "نصب PHP ناموفق بود. دستی نصب کنید: $PHP_EXT"
fi
for m in pdo_mysql mbstring curl; do
  php -m | grep -qi "^$m$" || { say "افزودن افزونه $m ..."; $SUDO apt-get install -y -qq $PHP_EXT >/dev/null 2>&1; break; }
done
ok "PHP $(php -r 'echo PHP_VERSION;')"
[ -n "$SQL_FILE" ] && [ -f "$SQL_FILE" ] && ok "فایل دیتابیس: $SQL_FILE" || say "هشدار: فایل نصب دیتابیس پیدا نشد (اگر دیتابیس از قبل نصب است مشکلی نیست)."

# ── ۲) MariaDB ──────────────────────────────────────────────
if ! command -v mariadbd >/dev/null 2>&1 && ! command -v mysqld >/dev/null 2>&1; then
  say "نصب MariaDB ..."
  $SUDO apt-get install -y -qq mariadb-server >/dev/null 2>&1 || die "نصب MariaDB ناموفق بود."
fi
if ! $SUDO mariadb-admin ping >/dev/null 2>&1; then
  say "راه‌اندازی سرویس دیتابیس ..."
  $SUDO mkdir -p /run/mysqld && $SUDO chown mysql:mysql /run/mysqld
  ($SUDO -u mysql mariadbd --user=mysql >/tmp/mariadb.log 2>&1 &)
  for i in $(seq 1 30); do $SUDO mariadb-admin ping >/dev/null 2>&1 && break; sleep 1; done
fi
$SUDO mariadb-admin ping >/dev/null 2>&1 || die "MariaDB بالا نیامد. لاگ: /tmp/mariadb.log"
ok "دیتابیس MariaDB بالا است"

# ── ۳) ساخت دیتابیس در صورت نبود ────────────────────────────
exists() { $SUDO mariadb -N -e "SHOW DATABASES LIKE '$1'" 2>/dev/null | grep -q "$1"; }
if ! exists "$DB_NAME"; then
  [ -n "$SQL_FILE" ] && [ -f "$SQL_FILE" ] || die "دیتابیس «$DB_NAME» وجود ندارد و فایل نصب هم پیدا نشد."
  say "ایجاد دیتابیس $DB_NAME (ممکن است ~۱۵ ثانیه طول بکشد) ..."
  $SUDO mariadb --default-character-set=utf8mb4 -e "CREATE DATABASE \`$DB_NAME\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
  $SUDO bash -c "mariadb --default-character-set=utf8mb4 < '$SQL_FILE'" || die "اجرای فایل SQL ناموفق بود."
  ok "دیتابیس ساخته شد (۱۲۹ جدول، ۲۵ نما، داده نمایشی)"
fi
$SUDO mariadb -e "CREATE USER IF NOT EXISTS '$DB_USER'@'%' IDENTIFIED BY '$DB_PASS';
GRANT ALL PRIVILEGES ON \`$DB_NAME\`.* TO '$DB_USER'@'%'; FLUSH PRIVILEGES;" >/dev/null 2>&1
ok "کاربر دیتابیس $DB_USER آماده است"

# سال مالی جاری (اگر وجود نداشته باشد ساخته می‌شود)
php -r '
$c = @include "config.local.php";' >/dev/null 2>&1 || true
cd "$ROOT" && php tools/roll_fiscal_year.php >/dev/null 2>&1 || true

# ── ۴) اجرای سرور ───────────────────────────────────────────
IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
if [ ! -f "$ROOT/config.local.php" ]; then
  cat <<EOM

⚠️  فایل config.local.php وجود ندارد (اجرای اول).
    پس از بالا آمدن سرور، این آدرس را در مرورگر باز کنید و مرحله‌ها را طی کنید:
        http://localhost:$PORT/install.php
EOM
fi
cat <<EOM

╭────────────────────────────────────────────────────────╮
│  نرم‌افزار حسابداری و انبارداری فینتو — آماده اجرا      │
╰────────────────────────────────────────────────────────╯
   آدرس محلی:      http://localhost:$PORT
   آدرس شبکه:      http://${IP:-<ip>}:$PORT
   ورود نمایشی:    09120000001  /  demo1234
   نصب‌کننده وبی:   /install.php   (اگر دیتابیس نصب نشده است)
   ثبت‌نام جدید:    /register  (کد تأیید در صفحه «تأیید موبایل» نمایش داده می‌شود)
   کاربران نمونه:   09120000001 تا 09120000004  /  demo1234
   توقف سرور:       Ctrl + C
────────────────────────────────────────────────────────
EOM
# سرور محلی با همان قواعد .htaccess هاست اشتراکی
cd "$ROOT" && exec php -S 0.0.0.0:"$PORT" tools/serve_local.php
