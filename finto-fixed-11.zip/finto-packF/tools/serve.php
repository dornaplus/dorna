<?php
/**
 * روتر سرور توکار PHP برای اجرای نرم‌افزار بدون Apache:
 *   php -S 0.0.0.0:8080 -t public tools/serve.php
 * فایل‌های واقعی داخل public/ مستقیم سرو می‌شوند و بقیه درخواست‌ها به front controller می‌روند.
 */
$path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
$file = __DIR__.'/../public'.$path;
if ($path !== '/' && is_file($file)) return false;
$_SERVER['SCRIPT_NAME'] = '/index.php';
require __DIR__.'/../public/index.php';
