<?php
/**
 * سرور محلی برای آزمون همان ساختاری که روی هاست اشتراکی (cPanel) اجرا می‌شود.
 *
 *   روش ۱ — پروژه = ریشه سایت (شبیه public_html):
 *        php -S 0.0.0.0:8080 tools/serve_local.php
 *
 *   روش ۲ — پروژه در زیرپوشه (شبیه public_html/finto):
 *        php -S 0.0.0.0:8080 -t /path/to/public_html /path/to/public_html/finto/tools/serve_local.php
 *
 * این فایل همان قواعد .htaccess را شبیه‌سازی می‌کند:
 *   • /assets/...        → از پوشه public سرو می‌شود
 *   • پوشه‌های داخلی (app، storage، db، tools، _meta) و فایل‌های حساس مسدود می‌شوند
 *   • بقیه مسیرها → index.php (کنترلر جلویی)
 */
$appRoot = rtrim(str_replace('\\', '/', dirname(__DIR__)), '/');
$docroot = rtrim(str_replace('\\', '/', (string)(realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: $appRoot)), '/');

/* مسیر پایه برنامه نسبت به ریشه سایت: '' یا '/finto' و مانند آن */
$base = '';
if ($appRoot !== $docroot && str_starts_with($appRoot, $docroot.'/')) $base = substr($appRoot, strlen($docroot));

$uri = rawurldecode((string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH));
if ($uri === '') $uri = '/';

/* مسیر داخلی برنامه (بدون پیشوند زیرپوشه) */
$rel = $uri;
if ($base !== '' && ($rel === $base || str_starts_with($rel, $base.'/'))) $rel = substr($rel, strlen($base)) ?: '/';

/* ── مسدودسازی مسیرهای حساس (لایه دوم امنیتی، مکمل .htaccess) ── */
$deny = function (string $msg): bool {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo $msg;
    return true;
};
// فقط فایل‌های واقعی داخل پوشه‌های داخلی مسدود می‌شوند؛ مسیرهای مجازی نرم‌افزار (مثل /app/invoices) آزادند
if (preg_match('#^/(app|storage|_meta|db|tools|vendor)/.+\.[a-z0-9]{1,5}$#i', $rel)) return $deny('دسترسی به این فایل مسدود است.');
if (preg_match('#^/(\.htaccess|\.env)$#i', $rel) || preg_match('#/(config\.php|config\.local\.php)$#i', $rel)) return $deny('دسترسی به این فایل مسدود است.');
if (preg_match('#\.(sql|md|log|lock|sh|tsv|bak|ini|yml|env)$#i', $rel)) return $deny('دسترسی به این فایل مسدود است.');

/* ── دارایی‌ها: /assets/... → public/assets/... ── */
if (preg_match('#^/assets/(.+)$#', $rel, $m)) {
    $f = $appRoot.'/public/assets/'.$m[1];
    if (!is_file($f)) { http_response_code(404); echo 'فایل یافت نشد'; return true; }
    $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
    $types = ['css' => 'text/css', 'js' => 'application/javascript', 'json' => 'application/json', 'woff2' => 'font/woff2',
              'woff' => 'font/woff', 'ttf' => 'font/ttf', 'svg' => 'image/svg+xml', 'png' => 'image/png', 'jpg' => 'image/jpeg',
              'jpeg' => 'image/jpeg', 'gif' => 'image/gif', 'ico' => 'image/x-icon', 'webp' => 'image/webp'];
    header('Content-Type: '.($types[$ext] ?? 'application/octet-stream'));
    header('Content-Length: '.filesize($f));
    readfile($f);
    return true;
}

/* ── فایل‌های واقعی (install.php، health.php، فایل‌های عمومی) ── */
$phys = $appRoot.$rel;
if ($rel !== '/' && is_file($phys)) return false;   // سرور همان فایل را سرو می‌کند

/* ── پوشه دارای index.php ── */
if (is_dir($phys) && is_file(rtrim($phys, '/').'/index.php')) {
    $_SERVER['SCRIPT_NAME'] = $base.'/index.php';
    $_SERVER['SCRIPT_FILENAME'] = rtrim($phys, '/').'/index.php';
    require rtrim($phys, '/').'/index.php';
    return true;
}

/* ── کنترلر جلویی ── */
$_SERVER['SCRIPT_NAME'] = $base.'/index.php';
$_SERVER['SCRIPT_FILENAME'] = $appRoot.'/index.php';
require $appRoot.'/index.php';
return true;
