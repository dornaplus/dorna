<?php
/**
 * آزمون دودی موتورهای نرم‌افزار (روی دیتابیس آزمایشی اجرا شود)
 * اجرا:  FINTO_DB_NAME=finto_test php tools/smoke.php
 */
require __DIR__.'/../app/bootstrap.php';
if (!function_exists('view')) require __DIR__.'/../app/Helpers.php';

$pass = 0; $fail = 0; $log = [];
function t(string $name, callable $fn) {
    global $pass, $fail, $log;
    try {
        $r = $fn();
        $pass++;
        $log[] = "PASS  $name".($r !== null && $r !== true ? "  → $r" : '');
    } catch (Throwable $e) {
        $fail++;
        $log[] = "FAIL  $name\n        ".$e->getMessage()."\n        @ ".basename($e->getFile()).":".$e->getLine();
    }
}

$_SESSION['user_id'] = 1;
$_SESSION['business_id'] = 1;
$BIZ = 1;
echo "دیتابیس: ".config('db')['name']."\n";
echo "──── موتورها ────\n";

t('Schema/Meta', function () {
    $tables = count(Schema::tables()); $views = count(Schema::views()); $mods = count(Meta::MODULES); $reps = count(Meta::reports());
    if ($tables < 100 || $views < 20 || $mods < 40 || $reps < 20) throw new RuntimeException("counts low: $tables/$views/$mods/$reps");
    return "$tables جدول، $views نما، $mods ماژول، $reps گزارش";
});

t('Sequence::next/peek', function () use ($BIZ) {
    $fy = Auth::fiscalYearId();
    $a = Sequence::next($BIZ, $fy, 'sale', ['fy' => 1404]);
    $b = Sequence::peek($BIZ, $fy, 'sale');
    if (!$a || !$b) throw new RuntimeException('شماره صادر نشد');
    return "$a / بعدی $b";
});

t('Otto::create/verify', function () {
    $mobile = '0912'.random_int(1000000, 9999999);
    $code = Otp::create(null, $mobile, 'register');
    [$ok, $msg] = Otp::verify($mobile, $code, 'register');
    if (!$ok) throw new RuntimeException('verify failed: '.$msg);
    return 'کد '.$code;
});

t('Settings set/get', function () use ($BIZ) {
    Settings::set($BIZ, 'test.smoke.key', 12345.5);
    $v = Settings::get('test.smoke.key');
    if ((float)$v !== 12345.5) throw new RuntimeException('roundtrip failed');
    return 'ok';
});

t('فاکتور فروش + قطعی‌سازی (سند حسابداری و انبار)', function () use ($BIZ) {
    $prod = Database::one('SELECT id, main_unit_id FROM products WHERE business_id=? AND item_type="goods" AND id BETWEEN 1 AND 100000 ORDER BY id LIMIT 1', [$BIZ]);
    $price = (float)Database::val('SELECT price FROM product_prices WHERE product_id=? ORDER BY id DESC LIMIT 1', [$prod['id']], 10000000);
    $before = Inventory::currentQty($BIZ, 1, (int)$prod['id']);
    $id = Trade::createInvoice(['business_id' => $BIZ, 'invoice_type' => 'sale', 'invoice_date' => today(), 'due_date' => date('Y-m-d', strtotime('+10 days')),
        'person_id' => 1, 'warehouse_id' => 1, 'settlement_type' => 'credit', 'invoice_discount' => 0],
        [['product_id' => (int)$prod['id'], 'unit_id' => (int)$prod['main_unit_id'], 'quantity' => 2, 'unit_price' => $price ?: 10000000, 'discount_percent' => 0, 'description' => 'آزمون']], [], true);
    $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$id]);
    $je = Database::one('SELECT * FROM journal_entries WHERE id=?', [$inv['journal_entry_id']]);
    if (!$je) throw new RuntimeException('سند حسابداری صادر نشد');
    if (abs((float)$je['total_debit'] - (float)$je['total_credit']) > 0.01) throw new RuntimeException('سند نامتراز');
    $after = Inventory::currentQty($BIZ, 1, (int)$prod['id']);
    if ($after >= $before) throw new RuntimeException("موجودی کاهش نیافت: $before → $after");
    return "فاکتور {$inv['invoice_no']} مبلغ ".num($inv['total_amount'])." | سند {$je['entry_no']} | موجودی ".num($before, 2)." → ".num($after, 2);
});

t('فاکتور خرید + قطعی‌سازی', function () use ($BIZ) {
    $prod = Database::one('SELECT id, main_unit_id FROM products WHERE business_id=? AND item_type="goods" ORDER BY id LIMIT 1', [$BIZ]);
    $before = Inventory::currentQty($BIZ, 1, (int)$prod['id']);
    $id = Trade::createInvoice(['business_id' => $BIZ, 'invoice_type' => 'buy', 'invoice_date' => today(), 'person_id' => 6,
        'warehouse_id' => 1, 'settlement_type' => 'credit'], [['product_id' => (int)$prod['id'], 'unit_id' => (int)$prod['main_unit_id'],
        'quantity' => 5, 'unit_price' => 9000000, 'discount_percent' => 0]], [], true);
    $inv = Database::one('SELECT * FROM invoices WHERE id=?', [$id]);
    $after = Inventory::currentQty($BIZ, 1, (int)$prod['id']);
    if ($after <= $before) throw new RuntimeException('موجودی افزایش نیافت');
    return "فاکتور {$inv['invoice_no']} | موجودی ".num($before, 2)." → ".num($after, 2);
});

t('دریافت + تسویه فاکتور', function () use ($BIZ) {
    $inv = Database::one('SELECT * FROM invoices WHERE business_id=? AND invoice_type="sale" AND status="posted" ORDER BY id DESC LIMIT 1', [$BIZ]);
    $part = round((float)$inv['total_amount'] / 2, 0);
    $id = Trade::createReceipt(['doc_date' => today(), 'person_id' => (int)$inv['person_id'], 'cash_account_id' => 1,
        'payment_method_id' => 1, 'amount' => $part, 'description' => 'آزمون دریافت', 'person_name' => 'آزمون'],
        [['invoice_id' => (int)$inv['id'], 'amount' => $part]], true);
    $r = Database::one('SELECT * FROM receipts WHERE id=?', [$id]);
    $inv2 = Database::one('SELECT * FROM invoices WHERE id=?', [$inv['id']]);
    if ($r['status'] !== 'posted') throw new RuntimeException('سند دریافت قطعی نشد');
    if ((float)$inv2['paid_amount'] <= 0) throw new RuntimeException('تسویه فاکتور اعمال نشد');
    return "دریافت {$r['doc_no']} مبلغ ".num($part)." → وضعیت تسویه: ".Meta::enumLabel($inv2['settlement_status']);
});

t('پرداخت به تأمین‌کننده', function () use ($BIZ) {
    $inv = Database::one('SELECT * FROM invoices WHERE business_id=? AND invoice_type="buy" AND status="posted" ORDER BY id DESC LIMIT 1', [$BIZ]);
    $amt = round((float)$inv['total_amount'] * 0.3, 0);
    $id = Trade::createPayment(['doc_date' => today(), 'person_id' => (int)$inv['person_id'], 'cash_account_id' => 1,
        'payment_method_id' => 1, 'amount' => $amt, 'description' => 'آزمون پرداخت'], [['invoice_id' => (int)$inv['id'], 'amount' => $amt]], true);
    $p = Database::one('SELECT * FROM payments WHERE id=?', [$id]);
    return "پرداخت {$p['doc_no']} مبلغ ".num($amt);
});

t('انتقال وجه بین حساب‌ها', function () use ($BIZ) {
    $id = Trade::createTransfer(['from_cash_account_id' => 1, 'to_cash_account_id' => 2, 'amount' => 5000000,
        'fee_amount' => 50000, 'doc_date' => today(), 'description' => 'آزمون انتقال']);
    $t = Database::one('SELECT * FROM transfers WHERE id=?', [$id]);
    $je = Database::one('SELECT * FROM journal_entries WHERE id=?', [$t['journal_entry_id']]);
    if (abs((float)$je['total_debit'] - (float)$je['total_credit']) > 0.01) throw new RuntimeException('سند انتقال نامتراز');
    return "انتقال {$t['doc_no']}";
});

t('چرخه چک دریافتی و پرداختی', function () use ($BIZ) {
    $rid = Trade::createCheque(['direction' => 'received', 'cheque_no' => 'SMK-'.random_int(1000, 9999), 'amount' => 4000000,
        'bank_name' => 'ملت', 'person_id' => 1, 'issue_date' => today(), 'due_date' => date('Y-m-d', strtotime('+20 days'))]);
    Trade::chequeEvent($rid, 'deposited', today(), 'آزمون واگذاری');
    Trade::chequeEvent($rid, 'cleared', today(), 'آزمون وصول');
    $r = Database::one('SELECT * FROM cheques WHERE id=?', [$rid]);
    $iid = Trade::createCheque(['direction' => 'issued', 'cheque_no' => 'SMI-'.random_int(1000, 9999), 'amount' => 2500000,
        'bank_name' => 'صادرات', 'person_id' => 6, 'issue_date' => today(), 'due_date' => date('Y-m-d', strtotime('+15 days')), 'cash_account_id' => 1]);
    Trade::chequeEvent($iid, 'cleared', today(), 'آزمون پرداخت چک');
    $i = Database::one('SELECT * FROM cheques WHERE id=?', [$iid]);
    if ($r['status'] !== 'cleared') throw new RuntimeException('چک دریافتی وصول نشد ('.$r['status'].')');
    if ($i['status'] !== 'cleared') throw new RuntimeException('چک پرداختی تسویه نشد ('.$i['status'].')');
    $hist = (int)Database::val('SELECT COUNT(*) FROM cheque_histories WHERE cheque_id=?', [$rid]);
    return "چک دریافتی {$r['cheque_no']} ({$r['status']}، {$hist} رویداد) / چک پرداختی {$i['cheque_no']} ({$i['status']})";
});

t('سند هزینه و درآمد', function () use ($BIZ) {
    $cat = Database::one('SELECT id FROM profit_loss_categories WHERE business_id=? AND kind="expense" LIMIT 1', [$BIZ]);
    $eid = Trade::createExpenseOrIncome('expense', ['title' => 'آزمون هزینه', 'doc_date' => today(), 'person_id' => 7,
        'cash_account_id' => 1, 'category_id' => $cat['id'] ?? null], [['title' => 'اجاره', 'amount' => 1500000, 'tax_amount' => 0]]);
    $e = Database::one('SELECT * FROM expense_documents WHERE id=?', [$eid]);
    $iid = Trade::createExpenseOrIncome('income', ['title' => 'آزمون درآمد', 'doc_date' => today(), 'person_id' => 1,
        'cash_account_id' => 1], [['title' => 'درآمد متفرقه', 'amount' => 800000]]);
    $i = Database::one('SELECT * FROM income_documents WHERE id=?', [$iid]);
    if (!$e['journal_entry_id'] || !$i['journal_entry_id']) throw new RuntimeException('سند حسابداری صادر نشد');
    return "هزینه {$e['doc_no']} / درآمد {$i['doc_no']}";
});

t('اسناد انبار: ورود، خروج (FIFO)، ضایعات، انتقال', function () use ($BIZ) {
    $prod = Database::one('SELECT id, main_unit_id FROM products WHERE business_id=? AND item_type="goods" ORDER BY id LIMIT 1', [$BIZ]);
    $wh2 = (int)Database::val('SELECT id FROM warehouses WHERE business_id=? ORDER BY id DESC LIMIT 1', [$BIZ]);
    $pid = (int)$prod['id'];
    $q0 = Inventory::currentQty($BIZ, 2, $pid);
    $r1 = Inventory::createDocument(['business_id' => $BIZ, 'doc_type' => 'receive', 'doc_date' => today(), 'warehouse_id' => 2, 'source_type' => 'manual', 'description' => 'آزمون ورود'],
        [['product_id' => $pid, 'quantity' => 10, 'unit_cost' => 1000000]], true);
    $q1 = Inventory::currentQty($BIZ, 2, $pid);
    $r2 = Inventory::createDocument(['business_id' => $BIZ, 'doc_type' => 'issue', 'doc_date' => today(), 'warehouse_id' => 2, 'source_type' => 'manual'],
        [['product_id' => $pid, 'quantity' => 4]], true);
    $q2 = Inventory::currentQty($BIZ, 2, $pid);
    $r3 = Inventory::createDocument(['business_id' => $BIZ, 'doc_type' => 'waste', 'doc_date' => today(), 'warehouse_id' => 2, 'source_type' => 'manual'],
        [['product_id' => $pid, 'quantity' => 1]], true);
    $q3 = Inventory::currentQty($BIZ, 2, $pid);
    if (!(abs($q1 - $q0 - 10) < 0.001 && abs($q2 - $q1 + 4) < 0.001 && abs($q3 - $q2 + 1) < 0.001)) throw new RuntimeException("مقادیر نامعتبر: $q0/$q1/$q2/$q3");
    $cost = (float)Database::val('SELECT avg_unit_cost FROM stock_balances WHERE business_id=? AND warehouse_id=2 AND product_id=?', [$BIZ, $pid], 0);
    return "ورود ۱۰ → خروج ۴ → ضایعات ۱ = موجودی ".num($q3, 0)." (از ".num($q0, 0).") | بهای واحد ".num($cost);
});

t('سند حقوق و دستمزد', function () use ($BIZ) {
    $emp = Database::one('SELECT e.id, e.person_id FROM employees e WHERE e.business_id=? LIMIT 1', [$BIZ]);
    if (!$emp) throw new RuntimeException('پرسنلی در داده نمونه نیست');
    Database::run('UPDATE employee_salary_settings SET base_salary=250000000 WHERE employee_id=?', [$emp['id']]);
    $id = Trade::createPayroll(['doc_date' => today(), 'period_title' => 'آزمون حقوق', 'cash_account_id' => null],
        [['employee_id' => (int)$emp['id'], 'worked_days' => 30, 'base_salary' => 250000000, 'deductions' => 0, 'components' => []]]);
    $doc = Database::one('SELECT * FROM payroll_documents WHERE id=?', [$id]);
    if (!$doc['journal_entry_id']) throw new RuntimeException('سند حسابداری حقوق صادر نشد');
    return "{$doc['doc_no']} — ناخالص ".num($doc['gross_amount'])." بیمه ".num($doc['insurance_employee'] + $doc['insurance_employer'])." مالیات ".num($doc['tax_amount'])." خالص ".num($doc['net_amount']);
});

t('سند دستی + برگشت سند', function () use ($BIZ) {
    $acc = Database::all('SELECT id FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code LIMIT 2', [$BIZ]);
    $je = Posting::create($BIZ, ['entry_date' => today(), 'entry_type' => 'adjustment', 'source' => 'manual', 'description' => 'آزمون سند دستی'],
        [['account_id' => (int)$acc[0]['id'], 'debit' => 1000000], ['account_id' => (int)$acc[1]['id'], 'credit' => 1000000]]);
    $rev = Posting::reverse($je, 'آزمون برگشت');
    $r = Database::one('SELECT * FROM journal_entries WHERE id=?', [$rev]);
    if ($r['status'] !== 'posted') throw new RuntimeException('سند برگشتی ثبت نشد');
    return "سند $je → برگشتی $rev ({$r['entry_no']})";
});

t('تراز افتتاحیه کنترل‌شده', function () use ($BIZ) {
    $acc = Database::all('SELECT id FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code LIMIT 2', [$BIZ]);
    $sum = (float)Database::val('SELECT IFNULL(SUM(debit_amount - credit_amount),0) FROM opening_balances WHERE business_id=?', [$BIZ], 0);
    return 'جمع مانده افتتاحیه فعلی: '.num($sum);
});

t('همه ۲۵ نمای گزارش قابل پرس‌وجو هستند', function () use ($BIZ) {
    $bad = []; $ok = 0;
    foreach (Meta::reports() as $key => $r) {
        try {
            $cols = Schema::columns($r['view']);
            $w = isset($cols['business_id']) ? ' WHERE business_id='.$BIZ : '';
            Database::all("SELECT * FROM `{$r['view']}`$w LIMIT 3");
            $ok++;
        } catch (Throwable $e) { $bad[] = "$key: ".$e->getMessage(); }
    }
    if ($bad) throw new RuntimeException(implode(' | ', $bad));
    return "$ok گزارش";
});

t('راه‌اندازی کسب‌وکار جدید از قالب (Provisioner)', function () {
    $uid = Database::insert('users', ['full_name' => 'کاربر آزمون', 'mobile' => '0912'.random_int(1000000, 9999999), 'password_hash' => password_hash('test12345', PASSWORD_BCRYPT),
        'status' => 'active', 'is_active' => 1, 'created_at' => now()]);
    $bizId = Provisioner::provision($uid, ['name' => 'کسب‌وکار آزمون', 'activity_type' => 'bazargardani', 'legal_type' => 'haqiqi']);
    $bizId = is_array($bizId) ? (int)($bizId['business_id'] ?? $bizId[0] ?? 0) : (int)$bizId;
    $counts = [
        'accounts' => (int)Database::val('SELECT COUNT(*) FROM chart_of_accounts WHERE business_id=?', [$bizId]),
        'mappings' => (int)Database::val('SELECT COUNT(*) FROM account_mappings WHERE business_id=?', [$bizId]),
        'rules' => (int)Database::val('SELECT COUNT(*) FROM auto_entry_rules WHERE business_id=?', [$bizId]),
        'settings' => (int)Database::val('SELECT COUNT(*) FROM settings WHERE business_id=?', [$bizId]),
        'roles' => (int)Database::val('SELECT COUNT(*) FROM roles WHERE business_id=?', [$bizId]),
        'periods' => (int)Database::val('SELECT COUNT(*) FROM fiscal_periods WHERE business_id=?', [$bizId]),
    ];
    if ($counts['accounts'] < 50 || $counts['mappings'] < 30 || $counts['rules'] < 30 || $counts['settings'] < 50 || $counts['periods'] < 12)
        throw new RuntimeException('پرچم‌زنی ناقص: '.json_encode($counts, JSON_UNESCAPED_UNICODE));
    return 'کسب‌وکار #'.$bizId.' — '.json_encode($counts, JSON_UNESCAPED_UNICODE);
});

echo implode("\n", $log)."\n";
echo "════════════════════════════════\n";
echo "نتیجه: $pass موفق، $fail ناموفق\n";
exit($fail > 0 ? 1 : 0);
