<?php
/**
 * لایهٔ اتصال به هوش مصنوعی — سازگار با OpenAI (Chat Completions).
 * پیش‌فرض پروژه: AvalAI (https://api.avalai.ir/v1) با مدل DeepSeek V4.1 Flash.
 * کلید در config.php → ai.api_key یا متغیر محیطی AVALAI_API_KEY.
 */
final class Ai
{
    /** تنظیمات مؤثر (config + متغیر محیطی) */
    public static function config(): array
    {
        $c = config('ai');
        if (!is_array($c)) $c = [];
        $cfg = array_merge([
            'enabled'     => false,
            'base_url'    => 'https://api.avalai.ir/v1',
            'api_key'     => '',
            'model'       => 'deepseek-v4.1-flash',
            'timeout'     => 70,
            'max_tokens'  => 2000,
            'temperature' => 0.2,
            'thinking'    => false,
        ], $c);
        // بازنویسی با تنظیمات ذخیره‌شده در پنل «تنظیمات هوش مصنوعی»
        try {
            if (class_exists('Settings') && class_exists('Auth') && Auth::businessId()) {
                $map = ['enabled' => 'ai.enabled', 'base_url' => 'ai.base_url', 'api_key' => 'ai.api_key', 'model' => 'ai.model', 'thinking' => 'ai.thinking'];
                foreach ($map as $k => $sk) {
                    $v = Settings::get($sk, null);
                    if ($v === null || $v === '') continue;
                    $cfg[$k] = in_array($k, ['enabled', 'thinking'], true) ? (bool)$v : (string)$v;
                }
            }
        } catch (Throwable $e) { /* در نبود دیتابیس، از config استفاده می‌شود */ }
        $env = getenv('AVALAI_API_KEY');
        if ($env !== false && $env !== '') $cfg['api_key'] = $env;
        return $cfg;
    }

    public static function enabled(): bool
    {
        $c = self::config();
        return !empty($c['enabled']) && trim((string)$c['api_key']) !== '' && function_exists('curl_init');
    }

    /** فراخوانی چت (messages به سبک OpenAI). خروجی: ['ok'=>bool, 'text'=>string, 'usage'=>array, 'error'=>string] */
    public static function chat(array $messages, array $opts = []): array
    {
        $c = self::config();
        if (!self::enabled()) return ['ok' => false, 'error' => 'سرویس هوش مصنوعی فعال یا تنظیم نشده است.', 'text' => ''];

        $payload = [
            'model'       => (string)($opts['model'] ?? $c['model']),
            'messages'    => $messages,
            'max_tokens'  => (int)($opts['max_tokens'] ?? $c['max_tokens']),
            'temperature' => $opts['temperature'] ?? $c['temperature'],
        ];
        if (!empty($opts['json'])) $payload['response_format'] = ['type' => 'json_object'];
        if (empty($c['thinking'])) $payload['thinking'] = ['type' => 'disabled'];
        if (!empty($opts['reasoning_effort'])) $payload['reasoning_effort'] = $opts['reasoning_effort'];

        $ch = curl_init(rtrim((string)$c['base_url'], '/') . '/chat/completions');
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => (int)$c['timeout'],
            CURLOPT_CONNECTTIMEOUT => 15,
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $c['api_key']],
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        ]);
        $raw  = curl_exec($ch);
        $err  = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($raw === false) {
            self::log(['type' => $opts['type'] ?? 'chat', 'ok' => false, 'error' => $err]);
            return ['ok' => false, 'error' => 'اتصال به سرویس هوش مصنوعی برقرار نشد.', 'text' => ''];
        }
        $j = json_decode((string)$raw, true);
        if ($code !== 200 || !is_array($j)) {
            $msg = is_array($j) && isset($j['error']['message']) ? (string)$j['error']['message'] : 'خطای سرویس هوش مصنوعی (HTTP ' . $code . ')';
            self::log(['type' => $opts['type'] ?? 'chat', 'ok' => false, 'http' => $code, 'error' => $msg]);
            return ['ok' => false, 'error' => 'سرویس هوش مصنوعی پاسخ درستی نداد؛ لطفاً دوباره تلاش کنید.', 'text' => ''];
        }
        $text = (string)($j['choices'][0]['message']['content'] ?? '');
        self::log(['type' => $opts['type'] ?? 'chat', 'ok' => true, 'http' => $code, 'usage' => $j['usage'] ?? []]);
        return ['ok' => true, 'text' => $text, 'usage' => $j['usage'] ?? [], 'raw' => $j];
    }

    /** فراخوانی با خروجی JSON اعتبارسنجی‌شده */
    public static function json(array $messages, array $opts = []): array
    {
        $opts['json'] = true;
        $r = self::chat($messages, $opts);
        if (empty($r['ok'])) return $r;
        $data = json_decode((string)$r['text'], true);
        if (!is_array($data) && preg_match('/\{.*\}/s', (string)$r['text'], $m)) $data = json_decode($m[0], true);
        if (!is_array($data)) return ['ok' => false, 'error' => 'پاسخ هوش مصنوعی قابل تفسیر نبود.', 'text' => (string)$r['text']];
        return ['ok' => true, 'data' => $data, 'usage' => $r['usage'] ?? [], 'text' => (string)$r['text']];
    }

    /** آخرین خطاها/مصرف در storage/ai.log */
    private static function log(array $row): void
    {
        @file_put_contents(__DIR__ . '/../storage/ai.log', date('c') . ' | ' . json_encode($row, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
    }
}
