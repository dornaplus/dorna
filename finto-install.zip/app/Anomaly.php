<?php
/**
 * تشخیص ناهنجاری اسناد — مبالغ بسیار بزرگ، تکرار مشکوک و فروش به مشتریان بدحساب.
 */
final class Anomaly
{
    /** آستانهٔ «مبلغ بزرگ»: چند برابر میانگین فاکتورهای همین کسب‌وکار */
    private static function bigThreshold(int $biz): float
    {
        $avg = (float)Database::val("SELECT IFNULL(AVG(total_amount),0) FROM invoices WHERE business_id=? AND deleted_at IS NULL AND status='posted'", [$biz], 0);
        if ($avg < 1) $avg = 100000000;   // اگر داده‌ای نبود، آستانهٔ پیش‌فرض ۱۰۰ میلیون
        return max($avg * 3, 100000000);   // حداقل ۱۰۰ میلیون
    }

    /** مبالغ بسیار بزرگ (فاکتورهای فروش) */
    private static function bigInvoices(int $biz): array
    {
        $th = self::bigThreshold($biz);
        return Database::all(
            "SELECT i.id, i.invoice_no, i.total_amount, i.invoice_date,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who
               FROM invoices i JOIN persons p ON p.id=i.person_id
              WHERE i.business_id=? AND i.deleted_at IS NULL AND i.status='posted' AND i.invoice_type='sale'
                AND i.total_amount >= ?
              ORDER BY i.total_amount DESC LIMIT 10", [$biz, $th]);
    }

    /** تکرار مشکوک: چند فاکتور با مبلغ یکسان برای یک شخص در بازهٔ کوتاه */
    private static function suspiciousRepetition(int $biz): array
    {
        return Database::all(
            "SELECT i.person_id, i.total_amount, COUNT(*) AS cnt,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who,
                    MIN(i.invoice_no) AS first_no, MAX(i.invoice_no) AS last_no
               FROM invoices i JOIN persons p ON p.id=i.person_id
              WHERE i.business_id=? AND i.deleted_at IS NULL AND i.status='posted' AND i.invoice_type='sale'
                AND i.total_amount > 0
              GROUP BY i.person_id, i.total_amount
             HAVING cnt >= 3
              ORDER BY cnt DESC, i.total_amount DESC LIMIT 10", [$biz]);
    }

    /** فروش به مشتریان بدحساب (دارای فاکتور معوق) */
    private static function badDebtSales(int $biz): array
    {
        return Database::all(
            "SELECT p.id AS person_id, p.code,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who,
                    SUM(CASE WHEN i.settlement_status='overdue' AND i.remaining_amount>0 THEN i.remaining_amount ELSE 0 END) AS overdue_amount,
                    SUM(i.total_amount) AS recent_sales
               FROM persons p
               JOIN invoices i ON i.person_id = p.id AND i.business_id = ? AND i.deleted_at IS NULL AND i.status='posted' AND i.invoice_type='sale'
              WHERE p.deleted_at IS NULL
              GROUP BY p.id, p.code, p.first_name, p.last_name, p.company_name
             HAVING overdue_amount > 0
              ORDER BY overdue_amount DESC LIMIT 10", [$biz]);
    }

    /** جمع‌آوری همهٔ ناهنجاری‌ها */
    public static function detect(?int $biz = null): array
    {
        $biz = $biz ?? (int)Auth::businessId();
        return [
            'big_invoices' => self::bigInvoices($biz),
            'repetition' => self::suspiciousRepetition($biz),
            'bad_debt' => self::badDebtSales($biz),
            'threshold' => self::bigThreshold($biz),
        ];
    }

    /** تعداد کل ناهنجاری‌ها (برای اعلان) */
    public static function total(?int $biz = null): int
    {
        $a = self::detect($biz);
        return count($a['big_invoices']) + count($a['repetition']) + count($a['bad_debt']);
    }
}
