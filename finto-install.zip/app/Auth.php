<?php
/** احراز هویت، نشست و کنترل دسترسی */
final class Auth
{
    private static ?array $user = null;
    private static ?array $biz = null;
    private static ?array $perms = null;

    public static function start(): void
    {
        $c = config('app');
        if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
            session_name($c['session_name']);
            session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
            session_start();
        }
    }

    public static function user(): ?array
    {
        if (self::$user !== null) return self::$user ?: null;
        $id = $_SESSION['user_id'] ?? null;
        if (!$id) { self::$user = []; return null; }
        $u = Database::one('SELECT * FROM users WHERE id=? AND deleted_at IS NULL', [$id]);
        if (!$u || !$u['is_active']) { self::$user = []; return null; }
        self::$user = $u;
        return $u;
    }
    public static function id(): ?int { $u = self::user(); return $u ? (int)$u['id'] : null; }
    public static function pendingUser(): ?array
    {
        $id = $_SESSION['pending_user_id'] ?? null;
        return $id ? Database::one('SELECT * FROM users WHERE id=?', [$id]) : null;
    }
    public static function setPending(int $userId): void { $_SESSION['pending_user_id'] = $userId; }
    public static function clearPending(): void { unset($_SESSION['pending_user_id']); }

    public static function attempt(string $mobile, string $password): array
    {
        $u = Database::one('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL', [$mobile]);
        if (!$u) return [false, 'کاربری با این شماره موبایل یافت نشد.'];
        if ($u['locked_until'] && strtotime($u['locked_until']) > time()) return [false, 'حساب شما موقتاً قفل است. '.jdate($u['locked_until'], '/', true)];
        if (!$u['is_active'] || $u['status'] !== 'active') return [false, 'حساب کاربری فعال نیست. با پشتیبانی تماس بگیرید.'];
        if (!password_verify($password, $u['password_hash'])) {
            $tries = (int)$u['failed_attempts'] + 1;
            $lock = $tries >= 5 ? date('Y-m-d H:i:s', time() + 900) : null;
            Database::update('users', ['failed_attempts' => $tries, 'locked_until' => $lock], 'id=:id', ['id' => $u['id']]);
            return [false, $lock ? 'رمز اشتباه بود؛ حساب برای ۱۵ دقیقه قفل شد.' : 'رمز عبور اشتباه است.'];
        }
        Database::update('users', ['failed_attempts' => 0, 'locked_until' => null, 'last_login_at' => now()], 'id=:id', ['id' => $u['id']]);
        return [true, $u];
    }

    public static function loginUser(array $u): void
    {
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$u['id'];
        self::$user = $u;
        Database::insert('sessions', [
            'id' => uuid4(), 'user_id' => $u['id'], 'refresh_token_hash' => hash('sha256', bin2hex(random_bytes(32))),
            'ip_address' => inet_pton($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') ?: null,
            'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
            'expires_at' => date('Y-m-d H:i:s', time() + config('security')['session_ttl_days'] * 86400), 'created_at' => now(),
        ]);
        Audit::log('login', 'users', (int)$u['id'], 'ورود به سامانه');
    }
    public static function logout(): void
    {
        Audit::log('logout', 'users', self::id(), 'خروج از سامانه');
        $_SESSION = [];
        if (ini_get('session.use_cookies')) setcookie(session_name(), '', time() - 42000, '/');
        session_destroy();
        self::$user = self::$biz = self::$perms = null;
    }

    /* ---------- کسب‌وکار جاری ---------- */
    public static function businesses(): array
    {
        $uid = self::id(); if (!$uid) return [];
        return Database::all('SELECT b.*, r.name AS role_name, r.slug AS role_slug, ubr.is_active AS membership_active, ubr.default_warehouse_id, ubr.default_cash_account_id
                                FROM user_business_roles ubr
                                JOIN businesses b ON b.id = ubr.business_id
                                JOIN roles r ON r.id = ubr.role_id
                               WHERE ubr.user_id = ? AND ubr.is_active = 1 AND b.deleted_at IS NULL
                               ORDER BY b.id', [$uid]);
    }
    public static function businessId(): ?int
    {
        $id = $_SESSION['business_id'] ?? null;
        if ($id) return (int)$id;
        $list = self::businesses();
        if (!$list) return null;
        self::switchBusiness((int)$list[0]['id']);
        return (int)$list[0]['id'];
    }
    public static function switchBusiness(int $id): void
    {
        $uid = self::id();
        $ok = Database::val('SELECT COUNT(*) FROM user_business_roles WHERE user_id=? AND business_id=? AND is_active=1', [$uid, $id]);
        if (!$ok) return;
        $_SESSION['business_id'] = $id;
        self::$biz = null; self::$perms = null;
    }
    public static function business(): ?array
    {
        if (self::$biz !== null) return self::$biz ?: null;
        $id = self::businessId();
        if (!$id) { self::$biz = []; return null; }
        $b = Database::one('SELECT b.*, c.title AS currency_title, c.symbol AS currency_symbol FROM businesses b LEFT JOIN currencies c ON c.id=b.base_currency_id WHERE b.id=?', [$id]);
        if ($b) {
            $fy = Database::one('SELECT * FROM fiscal_years WHERE business_id=? AND is_current=1 AND deleted_at IS NULL LIMIT 1', [$id]);
            if (!$fy) $fy = Database::one('SELECT * FROM fiscal_years WHERE business_id=? ORDER BY id DESC LIMIT 1', [$id]);
            $b['fiscal_year'] = $fy;
        }
        self::$biz = $b ?: [];
        return $b;
    }
    public static function fiscalYearId(): ?int { $b = self::business(); return $b['fiscal_year']['id'] ?? null; }
    public static function fiscalYear(): ?array { $b = self::business(); return $b['fiscal_year'] ?? null; }
    public static function currency(): string { $b = self::business(); return $b['currency_title'] ?? 'ریال'; }

    /* ---------- دسترسی ---------- */
    public static function roleSlug(): string
    {
        $uid = self::id(); $bid = self::businessId();
        if (!$uid || !$bid) return '';
        return (string)Database::val('SELECT r.slug FROM user_business_roles ubr JOIN roles r ON r.id=ubr.role_id WHERE ubr.user_id=? AND ubr.business_id=? AND ubr.is_active=1 LIMIT 1', [$uid, $bid], '');
    }
    public static function isAdmin(): bool
    {
        if (in_array(self::roleSlug(), ['admin', 'owner', 'manager', 'modir'], true)) return true;
        $uid = self::id(); $bid = self::businessId();
        if (!$uid || !$bid) return false;
        $total = (int)Database::val('SELECT COUNT(*) FROM permissions WHERE is_active=1', [], 0);
        $mine  = self::permissions();
        return $total > 0 && count($mine) >= $total * 0.9;
    }
    public static function permissions(): array
    {
        if (self::$perms !== null) return self::$perms;
        $uid = self::id(); $bid = self::businessId();
        if (!$uid || !$bid) return self::$perms = [];
        $rows = Database::all('SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id
                               JOIN user_business_roles ubr ON ubr.role_id = rp.role_id
                               WHERE ubr.user_id=? AND ubr.business_id=? AND ubr.is_active=1 AND p.is_active=1', [$uid, $bid]);
        return self::$perms = array_column($rows, 'slug');
    }
    /** مجوزهای تعریف‌شده در سامانه (کش) */
    private static ?array $permSet = null;
    private static function permExists(string $perm): bool
    {
        if (self::$permSet === null) {
            self::$permSet = array_flip(array_column(
                Database::all('SELECT slug FROM permissions WHERE is_active=1'), 'slug'));
        }
        return isset(self::$permSet[$perm]);
    }
    public static function can(string $perm): bool
    {
        if (self::isAdmin()) return true;
        if (!$perm) return true;
        $list = self::permissions();
        if (in_array($perm, $list, true)) return true;
        // «مشاهدهٔ ماژول» فقط زمانی جای مجوزهای دیگر را می‌گیرد که آن مجوز در سامانه تعریف نشده باشد.
        // اگر مجوز تعریف شده ولی به این نقش داده نشده → دسترسی رد است (اصل کمترین دسترسی).
        if (self::permExists($perm)) return false;
        [$mod] = explode('.', $perm);
        return in_array($mod.'.view', $list, true);
    }
    public static function requireLogin(): void
    {
        if (!self::id()) { $_SESSION['intended'] = current_path(); redirect('login'); }
    }
    public static function requireApp(): void
    {
        self::requireLogin();
        if (isset($_SESSION['pending_user_id'])) redirect('onboarding/profile');
        if (!self::businessId()) redirect('onboarding/business');
    }
}
