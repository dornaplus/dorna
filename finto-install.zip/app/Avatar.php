<?php
/**
 * آواتار (تصویر پروفایل) کاربران.
 * فایل تصویر در public/uploads/avatars/{userId}/ ذخیره و مسیر نسبی آن در
 * ستون users.avatar_path نگه‌داری می‌شود تا در هدر، گفت‌وگو، برنامه‌ریز و …
 * بدون کوئری اضافه قابل نمایش باشد. در نبود عکس، حروف اول نام جایگزین می‌شود.
 */
final class Avatar
{
    /** پوشهٔ عمومی (public) برنامه */
    public static function publicDir(): string { return dirname(__DIR__) . '/public'; }

    /** مسیر نسبی (نسبت به public) برای ذخیرهٔ آواتار کاربر */
    public const BASE = 'uploads/avatars';

    /** آدرس کامل تصویر پروفایل (یا رشتهٔ خالی) */
    public static function url(?string $path): string
    {
        $path = trim((string)($path ?? ''));
        if ($path === '') return '';
        return url($path);
    }

    /** حروف اول نام (برای حالت بدون عکس) */
    public static function initials(?string $name): string
    {
        $name = trim(preg_replace('/\s+/u', ' ', (string)($name ?? '')));
        if ($name === '') return '؟';
        $parts = explode(' ', $name);
        $out = mb_substr($parts[0], 0, 1);
        if (isset($parts[1]) && $parts[1] !== '') $out .= mb_substr($parts[1], 0, 1);
        return $out;
    }

    /**
     * رندر آواتار (عکس در صورت وجود، وگرنه حروف اول نام).
     * @param string|null $name  نام نمایشی
     * @param string|null $path  مقدار users.avatar_path
     * @param string      $class کلاس CSS (avatar / pm-av / …)
     * @param int         $size  اندازهٔ دلخواه به پیکسل (۰ = از CSS)
     */
    public static function html(?string $name, ?string $path, string $class = 'avatar', int $size = 0): string
    {
        $title = e((string)($name ?? ''));
        $style = '';
        if ($size > 0) $style = ' style="width:' . $size . 'px;height:' . $size . 'px;font-size:' . max(10, (int)round($size * 0.42)) . 'px"';
        $src = self::url($path);
        if ($src !== '') {
            return '<span class="' . e($class) . ' av-img" title="' . $title . '"' . $style . '><img src="' . e($src) . '" alt="' . $title . '" loading="lazy"></span>';
        }
        return '<span class="' . e($class) . '" title="' . $title . '"' . $style . '>' . e(self::initials($name)) . '</span>';
    }

    /**
     * ذخیرهٔ تصویر پروفایل کاربر (از $_FILES) و ثبت مسیر در users.avatar_path.
     * @return array{ok:bool,error:?string,empty:bool,id:?int}
     */
    public static function save(int $userId, string $field = 'avatar'): array
    {
        $out = ['ok' => false, 'error' => null, 'empty' => true, 'id' => null];
        if ($userId <= 0) { $out['error'] = 'کاربر نامعتبر است.'; return $out; }
        if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return $out;
        $f = $_FILES[$field];
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) return $out;
        $out['empty'] = false;
        if ($err !== UPLOAD_ERR_OK) { $out['error'] = 'آپلود تصویر ناموفق بود (کد ' . $err . ').'; return $out; }
        if ((int)$f['size'] > 3 * 1024 * 1024) { $out['error'] = 'حجم تصویر باید کمتر از ۳ مگابایت باشد.'; return $out; }
        if (!is_uploaded_file((string)$f['tmp_name'])) { $out['error'] = 'فایل نامعتبر است.'; return $out; }
        $info = @getimagesize((string)$f['tmp_name']);
        $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $type = is_array($info) ? (int)$info[2] : 0;
        if (!isset($allowed[$type])) { $out['error'] = 'فقط تصویر JPG، PNG، WEBP یا GIF مجاز است.'; return $out; }

        $dir = self::publicDir() . '/' . self::BASE . '/' . max(1, $userId);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) { $out['error'] = 'ساخت پوشهٔ آپلود ممکن نشد.'; return $out; }
        $name = 'avatar-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$type];
        if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $name)) { $out['error'] = 'ذخیرهٔ تصویر ممکن نشد.'; return $out; }
        @chmod($dir . '/' . $name, 0644);

        self::clear($userId);   // تصویر قبلی حذف شود
        $rel = self::BASE . '/' . max(1, $userId) . '/' . $name;
        Database::update('users', ['avatar_path' => $rel, 'updated_at' => now(), 'updated_by' => $userId], 'id=:pk', ['pk' => $userId]);
        return ['ok' => true, 'error' => null, 'empty' => false, 'id' => null];
    }

    /** حذف تصویر پروفایل کاربر (فایل + مقدار ستون) */
    public static function clear(int $userId): void
    {
        if ($userId <= 0) return;
        $prev = (string)Database::val('SELECT avatar_path FROM users WHERE id=?', [$userId], '');
        if ($prev !== '') {
            if (str_contains($prev, self::BASE . '/')) {
                $p = self::publicDir() . '/' . ltrim($prev, '/');
                if (is_file($p)) @unlink($p);
            }
        }
        Database::run('UPDATE users SET avatar_path=NULL, updated_at=NOW() WHERE id=?', [$userId]);
    }

    /** نام کاربر + آواتار (برای نمایش کنار هم در هدر و …) */
    public static function chip(?array $user, string $class = 'avatar', int $size = 0): string
    {
        $name = (string)($user['full_name'] ?? ($user['name'] ?? ''));
        return self::html($name, (string)($user['avatar_path'] ?? ''), $class, $size)
             . '<span class="av-name">' . e($name) . '</span>';
    }
}
