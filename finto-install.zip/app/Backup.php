<?php
/**
 * پشتیبان‌گیری و بازگردانی «هر کسب‌وکار به‌صورت مستقل».
 *  • خروجی JSON (قابل بازگردانی) + CSV (همهٔ بخش‌ها در یک فایل)
 *  • بازگردانی فقط روی همان کسب‌وکار انجام می‌شود → هیچ تداخلی با کسب‌وکارهای دیگر
 *  • فایل‌ها در storage/backups/{business_id}/ نگهداری می‌شوند (بیرون از پوشهٔ وب)
 */
final class Backup
{
    /** جدول‌های فرزند که business_id ندارند اما از والدِ کسب‌وکاری مشتق می‌شوند */
    private const CHILD_TABLES = [
        'auto_entry_rule_lines'    => ['rule_id', 'auto_entry_rules'],
        'bank_statement_lines'     => ['bank_statement_id', 'bank_statements'],
        'cheque_histories'         => ['cheque_id', 'cheques'],
        'employee_salary_settings' => ['employee_id', 'employees'],
        'expense_document_lines'   => ['expense_document_id', 'expense_documents'],
    ];

    /** جدول‌هایی که در پشتیبان نمی‌آیند (فرادادهٔ خودِ پشتیبان‌گیری) */
    private const EXCLUDE = ['backup_jobs'];

    public const FORMAT_VERSION = 1;

    /* ───────────── مسیرها ───────────── */

    public static function dir(int $bid): string { return storage_path('backups/' . max(0, $bid)); }

    public static function filePath(array $job): string
    {
        return self::dir((int)$job['business_id']) . '/' . basename((string)$job['file_name']);
    }

    /* ───────────── فهرست جدول‌ها ───────────── */

    /** جدول‌های کسب‌وکاری (دارای business_id) + جدول‌های فرزند */
    public static function tables(): array
    {
        static $cache = null;
        if ($cache !== null) return $cache;
        $rows = Database::all(
            "SELECT c.TABLE_NAME AS t FROM information_schema.COLUMNS c
               JOIN information_schema.TABLES t ON t.TABLE_SCHEMA = c.TABLE_SCHEMA AND t.TABLE_NAME = c.TABLE_NAME
              WHERE c.TABLE_SCHEMA = DATABASE() AND c.COLUMN_NAME = 'business_id' AND t.TABLE_TYPE = 'BASE TABLE'
              ORDER BY c.TABLE_NAME");
        $out = [];
        foreach ($rows as $r) {
            $name = (string)$r['t'];
            if (in_array($name, self::EXCLUDE, true)) continue;
            $out[] = $name;
        }
        foreach (array_keys(self::CHILD_TABLES) as $t) {
            if (!in_array($t, $out, true)) $out[] = $t;
        }
        return $cache = $out;
    }

    /* ───────────── ساخت پشتیبان ───────────── */

    /** ردیف‌های یک جدول برای این کسب‌وکار */
    private static function rowsOf(string $table, int $bid): array
    {
        if (isset(self::CHILD_TABLES[$table])) {
            [$fk, $parent] = self::CHILD_TABLES[$table];
            if (!self::tableHas($parent)) return [];
            return Database::all(
                "SELECT c.* FROM `{$table}` c JOIN `{$parent}` p ON p.id = c.`{$fk}` WHERE p.business_id = ?", [$bid]);
        }
        if ($table === 'businesses') {
            $b = Database::one('SELECT * FROM businesses WHERE id=?', [$bid]);
            return $b ? [$b] : [];
        }
        if (!self::tableHas($table)) return [];
        return Database::all("SELECT * FROM `{$table}` WHERE business_id = ?", [$bid]);
    }

    private static function tableHas(string $t): bool
    {
        static $cache = [];
        if (array_key_exists($t, $cache)) return $cache[$t];
        return $cache[$t] = ((int)Database::val(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND TABLE_TYPE='BASE TABLE'",
            [$t], 0) > 0);
    }

    /** ساخت پشتیبان و ثبت رکورد؛ خروجی: ردیف backup_jobs */
    public static function create(int $bid, ?int $userId = null, string $type = 'manual'): array
    {
        if ($bid <= 0) throw new RuntimeException('کسب‌وکار نامعتبر است.');
        $jobId = Database::insert('backup_jobs', [
            'business_id' => $bid, 'job_type' => in_array($type, ['manual', 'auto'], true) ? $type : 'manual',
            'scope' => 'full', 'status' => 'running', 'retention_days' => 30, 'sent_to_email' => 0,
            'created_at' => now(), 'created_by' => $userId,
        ]);
        $dir = self::dir($bid);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            Database::update('backup_jobs', ['status' => 'failed', 'error_message' => 'ساخت پوشهٔ پشتیبان ممکن نشد.'], 'id=:pk', ['pk' => $jobId]);
            throw new RuntimeException('ساخت پوشهٔ پشتیبان ممکن نشد.');
        }

        $stamp = date('Ymd-His');
        $base  = 'backup-' . $bid . '-' . $stamp . '-' . bin2hex(random_bytes(3));   // جلوگیری از بازنویسی دو پشتیبان در یک ثانیه
        $jsonF = $dir . '/' . $base . '.json';
        $csvF  = $dir . '/' . $base . '.csv';

        $payload = [
            'format'      => 'finto-backup',
            'version'     => self::FORMAT_VERSION,
            'business_id' => $bid,
            'business'    => (string)Database::val('SELECT name FROM businesses WHERE id=?', [$bid], ''),
            'created_at'  => date('c'),
            'tables'      => [],
            'counts'      => [],
        ];
        $csv = fopen($csvF, 'w');
        fwrite($csv, "\xEF\xBB\xBF");   // BOM برای اکسل فارسی
        fputcsv($csv, ['#finto-backup', (string)self::FORMAT_VERSION, (string)$bid, date('c')]);

        $total = 0;
        foreach (self::tables() as $t) {
            try { $rows = self::rowsOf($t, $bid); } catch (Throwable $e) { continue; }
            if (!$rows) continue;
            $payload['tables'][$t] = $rows;
            $payload['counts'][$t] = count($rows);
            $total += count($rows);
            // سرسطر CSV با نوع ستون‌ها (برای بازگردانی دقیق)
            $cols = array_keys($rows[0]);
            fputcsv($csv, array_merge(['#table', $t], array_map(fn($c) => $c . '|' . self::colType($rows, $c), $cols)));
            foreach ($rows as $r) {
                $line = [];
                foreach ($cols as $c) { $v = $r[$c] ?? null; $line[] = $v === null ? '\\N' : (string)$v; }
                fputcsv($csv, $line);
            }
        }
        fclose($csv);

        $okJson = @file_put_contents($jsonF, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR)) !== false;

        $sizeMb = round(((is_file($jsonF) ? filesize($jsonF) : 0) + (is_file($csvF) ? filesize($csvF) : 0)) / 1048576, 2);
        Database::update('backup_jobs', [
            'file_name' => basename($jsonF), 'size_mb' => $sizeMb, 'row_count' => $total,
            'status' => $okJson ? 'success' : 'failed',
            'error_message' => $okJson ? null : 'نوشتن فایل پشتیبان ناموفق بود.',
        ], 'id=:pk', ['pk' => $jobId]);
        if (!$okJson) throw new RuntimeException('نوشتن فایل پشتیبان ناموفق بود.');

        return Database::one('SELECT * FROM backup_jobs WHERE id=?', [$jobId]);
    }

    /** تشخیص نوع ستون از داده‌ها (برای سرسطر CSV) */
    private static function colType(array $rows, string $col): string
    {
        foreach ($rows as $r) {
            $v = $r[$col] ?? null;
            if ($v === null) continue;
            if (is_int($v)) return 'int';
            if (is_float($v)) return 'num';
            $s = (string)$v;
            if (preg_match('/^-?\d+$/', $s)) return 'int';
            if (preg_match('/^-?\d*\.\d+$/', $s)) return 'num';
            if (strlen($s) > 1 && ($s[0] === '{' || $s[0] === '[')) return 'json';
            return 'str';
        }
        return 'str';
    }

    /* ───────────── فهرست/حذف ───────────── */

    public static function jobs(int $bid, int $limit = 100): array
    {
        return Database::all('SELECT * FROM backup_jobs WHERE business_id=? ORDER BY id DESC LIMIT ' . (int)$limit, [$bid]);
    }

    public static function job(int $bid, int $id): ?array
    {
        // ایزوله‌سازی: فقط پشتیبان‌های همین کسب‌وکار
        return Database::one('SELECT * FROM backup_jobs WHERE id=? AND business_id=?', [$id, $bid]);
    }

    public static function remove(int $bid, int $id): bool
    {
        $job = self::job($bid, $id);
        if (!$job) return false;
        foreach (['.json', '.csv'] as $ext) {
            $f = self::dir($bid) . '/' . pathinfo((string)$job['file_name'], PATHINFO_FILENAME) . $ext;
            if (is_file($f)) @unlink($f);
        }
        Database::run('DELETE FROM backup_jobs WHERE id=? AND business_id=?', [$id, $bid]);
        return true;
    }

    /* ───────────── بازگردانی ───────────── */

    /** خواندن فایل پشتیبان (JSON یا CSV) → ساختار tables */
    public static function read(string $file, string $ext): array
    {
        if ($ext === 'json') {
            $raw = (string)@file_get_contents($file);
            $j = json_decode($raw, true);
            if (!is_array($j) || ($j['format'] ?? '') !== 'finto-backup') throw new RuntimeException('فایل پشتیبان معتبر نیست.');
            return $j;
        }
        if ($ext === 'csv') return self::readCsv($file);
        throw new RuntimeException('فقط فایل پشتیبان (JSON یا CSV همین سامانه) قابل بازگردانی است.');
    }

    /** خواندن CSV چندبخشی با سرسطر نوع‌دار */
    private static function readCsv(string $file): array
    {
        $fh = fopen($file, 'r');
        if (!$fh) throw new RuntimeException('فایل قابل خواندن نیست.');
        $bom = fread($fh, 3);                 // حذف BOM (برای اکسل فارسی نوشته می‌شود)
        if ($bom !== "\xEF\xBB\xBF") rewind($fh);
        $payload = ['format' => 'finto-backup', 'version' => self::FORMAT_VERSION, 'business_id' => 0, 'created_at' => '', 'tables' => [], 'counts' => []];
        $table = null; $cols = []; $types = [];
        while (($row = fgetcsv($fh)) !== false) {
            if (!$row) continue;
            $first = (string)($row[0] ?? '');
            if ($first === "#finto-backup") {
                $payload['version'] = (int)($row[1] ?? 1);
                $payload['business_id'] = (int)($row[2] ?? 0);
                $payload['created_at'] = (string)($row[3] ?? '');
                continue;
            }
            if ($first === '#table') {
                $table = (string)($row[1] ?? '');
                $cols = []; $types = [];
                for ($i = 2; $i < count($row); $i++) {
                    $p = explode('|', (string)$row[$i]);
                    $cols[] = $p[0];
                    $types[] = $p[1] ?? 'str';
                }
                if ($table !== '') $payload['tables'][$table] = [];
                continue;
            }
            if ($table === null || !$cols) continue;
            $data = [];
            foreach ($cols as $i => $c) {
                $v = $row[$i] ?? null;
                if ($v === '\\N' || $v === null) { $data[$c] = null; continue; }
                $t = $types[$i] ?? 'str';
                $data[$c] = $t === 'int' ? (int)$v : ($t === 'num' ? (float)$v : $v);
            }
            $payload['tables'][$table][] = $data;
        }
        fclose($fh);
        foreach ($payload['tables'] as $t => $rows) $payload['counts'][$t] = count($rows);
        return $payload;
    }

    /**
     * بازگردانی روی کسب‌وکار جاری.
     * فقط ردیف‌های همین کسب‌وکار پاک/بازنویسی می‌شوند؛ سایر کسب‌وکارها دست‌نخورده می‌مانند.
     */
    public static function restore(int $bid, array $payload): array
    {
        if ($bid <= 0) throw new RuntimeException('کسب‌وکار نامعتبر است.');
        $srcBid = (int)($payload['business_id'] ?? 0);
        if ($srcBid !== $bid) {
            throw new RuntimeException('این فایل پشتیبان مربوط به کسب‌وکار دیگری است (#' . $srcBid . ') و برای حفظ ایزوله‌بودن داده‌ها بازگردانی نمی‌شود.');
        }
        $tables = $payload['tables'] ?? [];
        if (!is_array($tables) || !$tables) throw new RuntimeException('فایل پشتیبان خالی است.');

        $known = array_flip(self::tables());
        $ins = 0;
        Database::transaction(function () use ($bid, $tables, $known, &$ins) {
            $pdo = Database::pdo();
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            try {
                // ۱) پاک‌کردن داده‌های همین کسب‌وکار (فرزندها اول)
                foreach (array_keys(self::CHILD_TABLES) as $t) {
                    if (!isset($known[$t]) || !isset($tables[$t])) continue;
                    [$fk, $parent] = self::CHILD_TABLES[$t];
                    $pdo->prepare("DELETE c FROM `{$t}` c JOIN `{$parent}` p ON p.id = c.`{$fk}` WHERE p.business_id = ?")->execute([$bid]);
                }
                foreach (array_keys($tables) as $t) {
                    if (!isset($known[$t]) || $t === 'businesses' || isset(self::CHILD_TABLES[$t])) continue;
                    if (!self::tableHas($t)) continue;
                    $pdo->prepare("DELETE FROM `{$t}` WHERE business_id = ?")->execute([$bid]);
                }
                // ۲) درج ردیف‌های پشتیبان (business_id به کسب‌وکار جاری اجبار می‌شود)
                foreach ($tables as $t => $rows) {
                    if (!isset($known[$t]) || !self::tableHas($t) || !is_array($rows) || !$rows) continue;
                    // ردیف «کسب‌وکار» پاک نمی‌شود؛ فقط به‌روزرسانی می‌شود (وگرنه کلید تکراری می‌خورد)
                    if ($t === 'businesses') {
                        foreach ($rows as $row) {
                            if (!is_array($row) || !$row) continue;
                            $data = $row; unset($data['id']);
                            foreach (['slug'] as $uniq) if (isset($data[$uniq])) unset($data[$uniq]);   // کلیدهای یگانه
                            if (!$data) continue;
                            $set = implode(',', array_map(fn($c) => "`" . str_replace('`', '', $c) . "`=?", array_keys($data)));
                            $st = $pdo->prepare("UPDATE `businesses` SET {$set} WHERE id=?");
                            $st->execute(array_merge(array_values($data), [$bid]));
                        }
                        continue;
                    }
                    $isChild = isset(self::CHILD_TABLES[$t]);
                    foreach ($rows as $row) {
                        if (!is_array($row) || !$row) continue;
                        // ایزوله‌سازی: جدول‌های اصلی همیشه به کسب‌وکار جاری نسبت داده می‌شوند
                        // (جدول‌های فرزند business_id ندارند و از والدشان مشتق می‌شوند)
                        if (!$isChild) $row['business_id'] = $bid;
                        self::insertRow($pdo, $t, $row);
                        $ins++;
                    }
                }
            } finally {
                $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            }
        });
        return ['rows' => $ins, 'tables' => count($tables)];
    }

    private static function insertRow(PDO $pdo, string $table, array $row): void
    {
        $cols = array_keys($row);
        $colSql = implode(',', array_map(fn($c) => "`" . str_replace('`', '', $c) . "`", $cols));
        $ph = implode(',', array_fill(0, count($cols), '?'));
        $st = $pdo->prepare("INSERT INTO `{$table}` ({$colSql}) VALUES ({$ph})");
        $vals = [];
        foreach ($cols as $c) {
            $v = $row[$c];
            $vals[] = is_bool($v) ? (int)$v : $v;
        }
        $st->execute($vals);
    }
}
