<?php
/**
 * درگاه پرداخت کافه‌بازار (پرداخت درون‌برنامه‌ای — «پیشخان بازار»)
 *
 * جریان کار:
 *   ۱) کاربر در صفحهٔ اشتراک فیدا روی «پرداخت با کافه‌بازار» می‌زند.
 *   ۲) اپ/مرورگر دیپ‌لینک bazaar://in_app?...sku=...&dealerPackageName=... را باز می‌کند
 *      و کاربر در اپلیکیشن بازار پرداخت را انجام می‌دهد.
 *   ۳) بازار کاربر را به آدرس بازگشت برمی‌گرداند و purchaseToken را در آدرس می‌گذارد.
 *   ۴) سرور با «API پیشخان بازار» توکن را بررسی می‌کند (validate) و اگر سالم بود،
 *      اشتراک را فعال و خرید را مصرف (consume) می‌کند.
 *
 * کلید API از پنل توسعه‌دهندگان بازار ساخته می‌شود:
 *   اپ‌ها → [اپ شما] → «API پیشخان بازار» → دریافت توکن جدید  (با حساب اصلی ناشر)
 */
final class Bazaar
{
    public const API_BASE = 'https://pardakht.cafebazaar.ir/devapi/v2/api/';

    public static function config(): array
    {
        $c = function_exists('config') ? config('bazaar') : null;
        return is_array($c) ? $c : [];
    }

    /** درگاه روی نرم‌افزار فعال است؟ */
    public static function enabled(): bool
    {
        // حالت آزمون محلی (پرچم موقت؛ همان الگوی storage/billing_unlock.flag و در بسته ارسال نمی‌شود)
        if (is_file(storage_path('bazaar_sandbox.flag'))) return true;
        return !empty(self::config()['enabled']) && self::package() !== '';
    }

    /** حالت آزمایشی (بدون تماس با بازار — فقط برای تست محلی) */
    public static function sandbox(): bool
    {
        if (is_file(storage_path('bazaar_sandbox.flag'))) return true;
        return !empty(self::config()['sandbox']);
    }

    public static function sandboxFlag(): string
    {
        return storage_path('bazaar_sandbox.flag');
    }

    public static function package(): string
    {
        return trim((string)(self::config()['package'] ?? ''));
    }

    public static function dealer(): string
    {
        $d = trim((string)(self::config()['dealer'] ?? ''));
        return $d !== '' ? $d : self::package();
    }

    public static function secret(): string
    {
        return trim((string)(self::config()['api_secret'] ?? ''));
    }

    /** درگاه فعال و آمادهٔ استفاده است؟ (کلید API موجود یا حالت آزمایشی) */
    public static function ready(): bool
    {
        return self::enabled() && (self::sandbox() || self::secret() !== '');
    }

    /** شناسهٔ محصول (SKU) هر پلن بر اساس مدت آن (به ماه) */
    public static function skuFor(array $plan): string
    {
        $skus = (array)(self::config()['skus'] ?? []);
        $m = (int)($plan['duration_months'] ?? 0);
        $sku = $skus[$m] ?? $skus[(string)$m] ?? '';
        return trim((string)$sku);
    }

    /** لینک پرداخت (دیپ‌لینک اپ کافه‌بازار) */
    public static function paymentLink(string $sku, string $returnUrl): string
    {
        return 'bazaar://in_app?redirectUrl=' . rawurlencode($returnUrl)
            . '&sku=' . rawurlencode($sku)
            . '&dealerPackageName=' . rawurlencode(self::dealer());
    }

    /** دیپ‌لینک ورود به حساب بازار (برای گرفتن accountId در اپ بازار) */
    public static function loginLink(string $returnUrl): string
    {
        return 'bazaar://inapplogin?redirectUrl=' . rawurlencode($returnUrl)
            . '&packageName=' . rawurlencode(self::package())
            . '&permissionScope=1';
    }

    /* ─────────────── تماس با API بازار ─────────────── */

    /** بررسی وضعیت یک خرید */
    public static function validate(string $sku, string $token): array
    {
        return self::request('GET', 'validate/' . rawurlencode(self::package()) . '/inapp/'
            . rawurlencode($sku) . '/purchases/' . rawurlencode($token) . '/');
    }

    /** مصرف خرید (تا کاربر بتواند بعداً دوباره بخرد) */
    public static function consume(string $token): array
    {
        return self::request('POST', 'consume/' . rawurlencode(self::package()) . '/purchases/', ['token' => $token]);
    }

    /** اشتراک‌های فعال یک توکن */
    public static function activeSubscriptions(string $token): array
    {
        return self::request('GET', 'applications/' . rawurlencode(self::package())
            . '/active-subscriptions/' . rawurlencode($token) . '/');
    }

    /** نتیجهٔ نهایی بررسی خرید: ok / دلیل خطا */
    public static function verify(string $sku, string $token): array
    {
        if ($sku === '' || $token === '') {
            return ['ok' => false, 'reason' => 'invalid_args', 'message' => 'اطلاعات خرید ناقص است.'];
        }
        $r = self::validate($sku, $token);
        if (empty($r['ok'])) {
            $key = (string)($r['data']['error'] ?? '');
            $msg = (string)($r['data']['error_description'] ?? ($r['message'] ?? ''));
            $map = [
                'not_found'     => 'این خرید در کافه‌بازار پیدا نشد.',
                'invalid_value' => 'اطلاعات خرید با این برنامه هم‌خوانی ندارد.',
            ];
            return ['ok' => false, 'reason' => $key !== '' ? $key : 'http_' . (int)$r['status'],
                'message' => $msg !== '' ? ($map[$key] ?? $msg) : 'ارتباط با کافه‌بازار برقرار نشد.', 'data' => $r['data'] ?? []];
        }
        $data = (array)($r['data'] ?? []);
        if ((int)($data['purchaseState'] ?? 0) !== 0) {
            return ['ok' => false, 'reason' => 'refunded', 'message' => 'این خرید مرجوع شده است.', 'data' => $data];
        }
        return ['ok' => true, 'reason' => 'ok', 'message' => '', 'data' => $data];
    }

    private static function request(string $method, string $path, ?array $body = null): array
    {
        if (self::sandbox()) return self::sandboxResponse($path, $body);
        if (self::secret() === '') {
            return ['ok' => false, 'status' => 0, 'data' => ['error' => 'api_secret_missing'],
                'message' => 'کلید API کافه‌بازار تنظیم نشده است.'];
        }
        $headers = ['CAFEBAZAAR-PISHKHAN-API-SECRET: ' . self::secret(), 'Accept: application/json'];
        $opts = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_CUSTOMREQUEST  => strtoupper($method),
            CURLOPT_SSL_VERIFYPEER => true,
        ];
        if ($body !== null) {
            $headers[] = 'Content-Type: application/json';
            $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE);
        }
        $opts[CURLOPT_HTTPHEADER] = $headers;

        $ch = curl_init(self::API_BASE . $path);
        curl_setopt_array($ch, $opts);
        $raw = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err = (string)curl_error($ch);
        $json = json_decode($raw !== '' ? $raw : '[]', true);
        if (!is_array($json)) $json = [];
        return ['ok' => $code >= 200 && $code < 300, 'status' => $code, 'data' => $json,
            'raw' => $raw, 'message' => $err];
    }

    /** پاسخ شبیه‌سازی‌شده برای آزمون محلی (sandbox) */
    private static function sandboxResponse(string $path, ?array $body): array
    {
        $token = (string)($body['token'] ?? '');
        if ($token === '' && preg_match('#/purchases/([^/]+)/#', $path, $m)) $token = urldecode($m[1]);
        if (str_contains($token, 'invalid')) {
            return ['ok' => false, 'status' => 404, 'data' => ['error' => 'not_found', 'error_description' => 'The requested purchase is not found!'], 'message' => ''];
        }
        if (str_starts_with($path, 'validate/')) {
            $refunded = str_contains($token, 'refund') || str_contains($token, 'refunded');
            return ['ok' => true, 'status' => 200, 'data' => [
                'consumptionState' => 1,
                'purchaseState'    => $refunded ? 1 : 0,
                'kind'             => 'androidpublisher#inappPurchase',
                'developerPayload' => 'sandbox',
                'purchaseTime'     => time() * 1000,
            ], 'message' => ''];
        }
        if (str_starts_with($path, 'consume/')) {
            return ['ok' => true, 'status' => 200, 'data' => [], 'message' => ''];
        }
        return ['ok' => true, 'status' => 200, 'data' => ['subscriptions' => []], 'message' => ''];
    }
}
