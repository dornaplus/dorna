<?php
/**
 * کنترلر دستیار هوشمند فینتو — پرسش‌وپاسخ روی داده (Text-to-SQL امن)،
 * پیشنهاد حساب برای اسناد هزینه/درآمد و خلاصهٔ مدیریتی.
 */
final class AiController
{
    /* ─────────── صفحهٔ دستیار ─────────── */
    public function assistant(array $p): string
    {
        Auth::requireApp();
        return view('pages/assistant/index', ['title' => 'دستیار هوشمند', 'enabled' => Ai::enabled(), 'model' => Ai::config()['model']]);
    }

    /* ─────────── پرسش و پاسخ روی داده ─────────── */
    public function ask(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $q = trim((string)post('question'));
        if ($q === '') return $this->json(['ok' => false, 'error' => 'سؤال خالی است.']);
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);

        $allowed = $this->allowedSources();
        $schema  = $this->schemaContext();
        $today   = jdate(today());

        $sys = implode("\n", [
            'تو «دستیار حسابداری فینتو» هستی. فقط بر اساس دادهٔ همین کسب‌وکار پاسخ می‌دهی.',
            'وظیفه: از سؤال کاربر یک کوئری SQL فقط-خواندنی (SELECT) بسازی.',
            'قواعد الزامی:',
            '1) فقط SELECT (یا WITH). هرگز INSERT/UPDATE/DELETE/DROP/ALTER ننویس.',
            '2) فقط از جدول‌ها/نماهای فهرست‌شده استفاده کن؛ به information_schema دست نزن.',
            '3) همیشه شرط «business_id = :biz» را در WHERE بگذار (پارامتر با نام :biz).',
            '4) نام جدول/ستون‌ها را با بک‌تیک بنویس. حداکثر ۲۰۰ ردیف.',
            '5) اگر پاسخ در نماها نیست، ساده‌ترین کوئری ممکن را بساز.',
            '6) برای پرسش‌های مشتری/کالا/بازاریاب از نماهای اختصاصی مانند v_sales_by_person، v_sales_by_item، v_sales_by_marketer استفاده کن و نام موجودیت‌ها را هم برگردان.',
            'امروز: ' . $today . ' — کسب‌وکار: ' . (Auth::business()['name'] ?? '') . ' (business_id = :biz).',
            'خروجی را فقط JSON با این ساختار بده: {"sql":"...","title":"عنوان کوتاه فارسی","columns_fa":{"نام_ستون_خروجی":"برچسب فارسی"},"chart":null}',
            '۷) برای «هر» ستون خروجی کوئری، یک برچسب کوتاه فارسی در columns_fa بگذار (مثال: {"total_amount":"مبلغ کل","cnt":"تعداد"}).',
            '۸) مقادیر خروجی باید فارسی باشند: برای ستون‌های وضعیت/نوع، متن فارسی را با CASE برگردان (مثال: CASE status WHEN "posted" THEN "قطعی" WHEN "draft" THEN "پیش‌نویس" ELSE status END AS وضعیت).',
            '۹) تاریخ‌ها را با تابع شمسی برنگردان؛ فقط ستون تاریخ خام را بده (برچسب فارسی‌اش را در columns_fa بگذار).',
            'chart اختیاری: اگر نمودار مفید است {"type":"bar","x":"نام ستون دسته","y":"نام ستون مقدار"}.',
            '',
            'منابع مجاز (نما/جدول: ستون‌ها):',
            $schema,
        ]);

        $first = Ai::json([
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user', 'content' => 'سؤال: ' . $q],
        ], ['type' => 'sql', 'max_tokens' => 1200, 'temperature' => 0]);
        if (empty($first['ok'])) return $this->json(['ok' => false, 'error' => $first['error'] ?? 'خطای هوش مصنوعی']);

        $sql = (string)($first['data']['sql'] ?? '');
        $bad = $this->safeSql($sql, $allowed);
        if ($bad !== null) return $this->json(['ok' => false, 'error' => 'نتوانستم پرسش شما را به دادهٔ مناسب تبدیل کنم؛ لطفاً دقیق‌تر و ساده‌تر بپرسید.']);

        // اجرای کوئری؛ در صورت خطا یک‌بار از هوش مصنوعی اصلاح خواسته می‌شود
        $rows = null; $runErr = '';
        for ($attempt = 1; $attempt <= 2; $attempt++) {
            try {
                $rows = Database::all($sql, ['biz' => Auth::businessId()]);
                $runErr = '';
                break;
            } catch (Throwable $e) {
                $runErr = $e->getMessage();
                if ($attempt === 2) break;
                $fix = Ai::json([
                    ['role' => 'system', 'content' => $sys],
                    ['role' => 'user', 'content' => 'اگر کوئری زیر خطا داده، آن را با خطای گزارش‌شده اصلاح کن و فقط JSON معتبر با همان ساختار برگردان.\n'
                        . 'کوئری خطادار: ' . $sql . "\n" . 'خطای دیتابیس: ' . $runErr],
                ], ['type' => 'sql', 'max_tokens' => 1200, 'temperature' => 0]);
                $sql2 = (string)($fix['data']['sql'] ?? '');
                if (!$fix['ok'] || $sql2 === '' || $this->safeSql($sql2, $allowed) !== null) break;
                $sql = $sql2;
                if (isset($fix['data']['columns_fa']) && is_array($fix['data']['columns_fa'])) $first['data']['columns_fa'] = $fix['data']['columns_fa'];
                if (!empty($fix['data']['title'])) $first['data']['title'] = $fix['data']['title'];
            }
        }
        if ($rows === null) {
            return $this->json(['ok' => false, 'error' => 'نتوانستم پاسخ این پرسش را از داده‌ها استخراج کنم؛ لطفاً پرسش را ساده‌تر بپرسید.']);
        }
        $cols = $rows ? array_keys($rows[0]) : [];

        // مرحلهٔ دوم: پاسخ طبیعی فارسی
        $sample = array_slice($rows, 0, 40);
        $ansSys = 'تو دستیار حسابداری فینتو هستی. بر اساس «شماره/دادهٔ» زیر، پاسخ کوتاه، دقیق و فارسی بده. '
                . 'از اعداد و واحد پول (ریال) درست استفاده کن. اگر داده خالی است بگو موردی یافت نشد. '
                . 'هرگز ادعا نکن «داده وجود ندارد» مگر اینکه واقعاً صفر ردیف برگشته باشد. '
                . 'پاسخ را همیشه فارسی و با ارقام فارسی بنویس و نام ستون‌ها را هم فارسی (نه انگلیسی) به کار ببر. '
                . 'در پایان در صورت مفید بودن، یک «نکته» یا «اقدام پیشنهادی» کوتاه بنویس. پاسخ فقط متن ساده باشد.';
        $ansUser = 'سؤال: ' . $q . "\n" . 'ستون‌ها: ' . implode(', ', $cols) . "\n"
                 . 'تعداد ردیف‌ها: ' . count($rows) . "\n"
                 . 'داده (JSON، حداکثر ۴۰ ردیف): ' . json_encode($sample, JSON_UNESCAPED_UNICODE);
        $second = Ai::chat([
            ['role' => 'system', 'content' => $ansSys],
            ['role' => 'user', 'content' => $ansUser],
        ], ['type' => 'answer', 'max_tokens' => 900, 'temperature' => 0.3]);

        // ── فارسی‌سازی خروجی: برچسب ستون‌ها و مقادیر (تاریخ شمسی، enumها) ──
        $colsFa = self::faColumns($cols, is_array($first['data']['columns_fa'] ?? null) ? $first['data']['columns_fa'] : []);
        $rowsFa = array_map(fn($r) => self::faRow($r, $colsFa), $rows);

        return $this->json([
            'ok'         => true,
            'title'      => (string)($first['data']['title'] ?? ''),
            'answer'     => $second['ok'] ? trim((string)$second['text']) : 'نتیجه بدست آمد اما تولید توضیح ناموفق بود.',
            'columns_fa' => $colsFa,
            'rows'       => $rowsFa,
            'count'      => count($rows),
            'chart'      => is_array($first['data']['chart'] ?? null) ? $first['data']['chart'] : null,
        ]);
    }

    /** واژه‌نامهٔ برچسب فارسی ستون‌های متداول (پشتیبان در صورت نبود برچسب از هوش مصنوعی) */
    private const COL_FA = [
        'first_name' => 'نام', 'last_name' => 'نام خانوادگی', 'full_name' => 'نام کامل', 'company_name' => 'نام شرکت',
        'person_name' => 'نام شخص', 'person_code' => 'کد شخص', 'code' => 'کد', 'title' => 'عنوان', 'name' => 'نام',
        'invoice_no' => 'شمارهٔ فاکتور', 'invoice_code' => 'کد فاکتور', 'doc_no' => 'شمارهٔ سند', 'entry_no' => 'شمارهٔ سند',
        'cheque_no' => 'شمارهٔ چک', 'bank_name' => 'نام بانک', 'reference_no' => 'شمارهٔ پیگیری',
        'total_amount' => 'جمع کل', 'final_amount' => 'مبلغ نهایی', 'remaining_amount' => 'ماندهٔ فاکتور',
        'paid_amount' => 'پرداخت‌شده', 'balance_amount' => 'مانده', 'amount' => 'مبلغ', 'total' => 'جمع',
        'subtotal' => 'جمع اقلام', 'quantity' => 'مقدار', 'qty' => 'مقدار', 'count' => 'تعداد', 'cnt' => 'تعداد',
        'invoice_date' => 'تاریخ فاکتور', 'doc_date' => 'تاریخ سند', 'entry_date' => 'تاریخ سند', 'due_date' => 'سررسید',
        'created_at' => 'تاریخ ثبت', 'updated_at' => 'آخرین ویرایش', 'invoice_jalali' => 'تاریخ',
        'invoice_type' => 'نوع فاکتور', 'status' => 'وضعیت', 'settlement_status' => 'وضعیت تسویه',
        'pay_method' => 'روش پرداخت', 'person_kind' => 'نوع شخص', 'direction' => 'جهت',
        'product_title' => 'نام کالا', 'product_code' => 'کد کالا', 'item_title' => 'کالا/خدمت',
        'warehouse_title' => 'انبار', 'unit_title' => 'واحد', 'mobile' => 'موبایل', 'phone' => 'تلفن',
        'national_id' => 'کد ملی', 'address' => 'نشانی', 'city' => 'شهر', 'description' => 'توضیحات',
        'note' => 'یادداشت', 'account_code' => 'کد حساب', 'account_title' => 'عنوان حساب',
        'cash_account_title' => 'حساب نقد/بانک', 'cost_center_name' => 'مرکز هزینه', 'category' => 'دسته',
        'profit_amount' => 'سود', 'tax_amount' => 'مالیات', 'discount_amount' => 'تخفیف', 'ship_amount' => 'هزینهٔ ارسال',
        'opening_balance' => 'ماندهٔ افتتاحیه', 'closing_balance' => 'ماندهٔ پایان', 'balance' => 'مانده',
        'debit' => 'بدهکار', 'credit' => 'بستانکار', 'account_type' => 'نوع حساب', 'nature' => 'ماهیت',
        'marketer_name' => 'بازاریاب', 'aging_bucket' => 'بازهٔ سنی', 'days_overdue' => 'روز تأخیر',
        'expense' => 'هزینه', 'income' => 'درآمد', 'revenue' => 'درآمد', 'month' => 'ماه', 'year' => 'سال',
    ];

    /** ستون‌هایی که مقدارشان باید به معادل فارسی تبدیل شود */
    private const VALUE_COLS = ['status', 'settlement_status', 'invoice_type', 'entry_type', 'pay_method', 'payment_kind',
        'person_kind', 'person_type', 'direction', 'account_type', 'nature', 'source', 'action', 'severity', 'doc_type',
        'kind', 'item_type', 'cost_method', 'tax_kind', 'center_type', 'warehouse_type', 'frequency', 'type', 'unit',
        'is_system', 'is_active', 'refundable'];

    /** برچسب فارسی ستون‌های خروجی: اول برچسب هوش مصنوعی، بعد واژه‌نامه، بعد بخش پایانی نام */
    private static function faColumns(array $cols, array $fromAi): array
    {
        $ai = [];
        foreach ($fromAi as $k => $v) { if (is_string($v) && $v !== '') { $ai[strtolower(trim((string)$k))] = trim($v); } }
        $out = [];
        foreach ($cols as $c) {
            $key = strtolower((string)$c);
            $tail = preg_replace('/^.*_/', '', $key);
            $out[$c] = $ai[$key] ?? self::COL_FA[$key] ?? self::COL_FA[$tail] ?? (string)$c;
        }
        return $out;
    }

    /** یکسان‌سازی مقدارهای یک سطر: تاریخ → شمسی، مقادیر وضعیت/نوع → فارسی */
    private static function faRow(array $row, array $colsFa = []): array
    {
        foreach ($row as $k => $v) {
            if ($v === null || is_array($v)) continue;
            $key = strtolower((string)$k);
            $tail = preg_replace('/^.*_/', '', $key);
            $label = (string)($colsFa[$k] ?? '');
            // تاریخ میلادی → شمسی
            if (is_string($v) && preg_match('/^\d{4}-\d{2}-\d{2}( \d{2}:\d{2}:\d{2})?$/', $v)
                && (str_contains($key, 'date') || str_ends_with($key, '_at'))) {
                $row[$k] = jdate(substr($v, 0, 10));
                continue;
            }
            // مقادیر وضعیت/نوع → معادل فارسی
            $looksEnum = in_array($key, self::VALUE_COLS, true) || in_array($tail, self::VALUE_COLS, true)
                || preg_match('/وضعیت|نوع|روش|ماهیت|جهت|دسته|کلاس|source/u', $label) === 1;
            if (is_string($v) && $v !== '' && $looksEnum && strlen($v) <= 30) {
                $fa = Meta::enumLabel($v);
                if ($fa !== $v) $row[$k] = $fa;
            }
        }
        return $row;
    }

    /* ─────────── پیشنهاد حساب برای هزینه/درآمد ─────────── */
    public function categorize(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);
        $desc = trim((string)post('description'));
        $kind = post('kind') === 'income' ? 'income' : 'expense';
        if (mb_strlen($desc) < 2) return $this->json(['ok' => false, 'error' => 'توضیح کوتاه است.']);

        $types = $kind === 'income' ? "('revenue')" : "('expense','cogs')";
        $accs = Database::all("SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status='active' AND account_type IN $types ORDER BY code", [Auth::businessId()]);
        if (!$accs) $accs = Database::all("SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status='active' ORDER BY code", [Auth::businessId()]);
        if (!$accs) return $this->json(['ok' => false, 'error' => 'حساب قابل انتخاب یافت نشد.']);

        $list = implode("\n", array_map(fn($a) => $a['id'] . ' | ' . $a['code'] . ' | ' . $a['title'], $accs));
        $sys = 'تو حسابدار خبرهٔ ایرانی هستی. از میان «فهرست حساب‌های مجاز» بهترین حساب برای ثبت سند دادهٔ کاربر را انتخاب کن. '
             . 'خروجی فقط JSON: {"account_id": عدد, "reason": "دلیل کوتاه فارسی", "confidence": عدد بین ۰ تا ۱, "alternatives": [{"account_id": عدد, "reason": "دلیل کوتاه"}]} '
             . 'account_id باید دقیقاً یکی از شناسه‌های فهرست باشد.';
        $user = 'نوع سند: ' . ($kind === 'income' ? 'درآمد' : 'هزینه') . "\n"
              . 'شرح/بابت: ' . $desc . "\n"
              . (post('amount') ? ('مبلغ: ' . post('amount') . "\n") : '')
              . "حساب‌های مجاز (id | کد | عنوان):\n" . $list;

        $r = Ai::json([
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user', 'content' => $user],
        ], ['type' => 'categorize', 'max_tokens' => 700, 'temperature' => 0]);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => $r['error'] ?? 'خطای هوش مصنوعی']);

        $byId = []; foreach ($accs as $a) $byId[(int)$a['id']] = $a;
        $id = (int)($r['data']['account_id'] ?? 0);
        if (!isset($byId[$id])) $id = (int)$accs[0]['id'];
        $alts = [];
        foreach ((array)($r['data']['alternatives'] ?? []) as $al) {
            $aid = (int)($al['account_id'] ?? 0);
            if (isset($byId[$aid]) && $aid !== $id) $alts[] = ['account_id' => $aid, 'code' => $byId[$aid]['code'], 'title' => $byId[$aid]['title'], 'reason' => (string)($al['reason'] ?? '')];
            if (count($alts) >= 3) break;
        }
        return $this->json([
            'ok'           => true,
            'account_id'   => $id,
            'code'         => $byId[$id]['code'],
            'title'        => $byId[$id]['title'],
            'reason'       => (string)($r['data']['reason'] ?? ''),
            'confidence'   => min(1, max(0, (float)($r['data']['confidence'] ?? 0))),
            'alternatives' => $alts,
        ]);
    }

    /* ─────────── خلاصهٔ مدیریتی ─────────── */
    public function summary(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);
        $biz = Auth::businessId();

        $kpi = Database::one('SELECT * FROM v_dashboard_kpi WHERE business_id=? LIMIT 1', [$biz]) ?? [];
        $top = Database::all('SELECT person_name, sales_amount FROM v_sales_by_person WHERE business_id=? ORDER BY sales_amount DESC LIMIT 5', [$biz]);
        $overdue = Database::all('SELECT invoice_no, person_name, remaining_amount, days_overdue FROM v_invoice_list WHERE business_id=? AND days_overdue>0 ORDER BY days_overdue DESC LIMIT 5', [$biz]);
        $low = Database::all('SELECT product_title, warehouse_title, available_quantity, reorder_point FROM v_low_stock WHERE business_id=? LIMIT 5', [$biz]);
        $chq = Database::all('SELECT cheque_no, person_company, amount, days_to_due FROM v_cheques_due WHERE business_id=? AND days_to_due <= 14 ORDER BY days_to_due LIMIT 5', [$biz]);

        $snap = [
            'فروش این ماه' => (float)($kpi['month_sales_amount'] ?? 0),
            'خرید این ماه' => (float)($kpi['month_purchase_amount'] ?? 0),
            'درآمد این ماه' => (float)($kpi['month_income_amount'] ?? 0),
            'هزینه این ماه' => (float)($kpi['month_expense_amount'] ?? 0),
            'موجودی نقد و بانک' => (float)($kpi['cash_and_bank_balance'] ?? 0),
            'طلب از مشتریان' => (float)($kpi['receivable_amount'] ?? 0),
            'بدهی به تأمین‌کنندگان' => (float)($kpi['payable_amount'] ?? 0),
            'ارزش موجودی انبار' => (float)($kpi['inventory_value'] ?? 0),
            'فاکتورهای معوق' => (int)($kpi['overdue_invoice_count'] ?? 0),
            'چک‌های نزدیک سررسید (۷ روز)' => (int)($kpi['due_cheques_count'] ?? 0),
        ];
        $sys = 'تو مشاور مالی مدیرعامل هستی. بر اساس دادهٔ زیر یک «خلاصهٔ مدیریتی» کوتاه و حرفه‌ای به فارسی بنویس '
             . '(حداکثر ۵ جمله) و سپس ۳ «اقدام پیشنهادی» عملی و کوتاه بده. '
             . 'خروجی فقط JSON: {"summary":"...","actions":["...","...","..."],"health":"good|warn|bad"}';
        $user = 'کسب‌وکار: ' . (Auth::business()['name'] ?? '') . "\n"
              . 'شاخص‌ها: ' . json_encode($snap, JSON_UNESCAPED_UNICODE) . "\n"
              . 'برترین مشتریان: ' . json_encode($top, JSON_UNESCAPED_UNICODE) . "\n"
              . 'معوق‌ها: ' . json_encode($overdue, JSON_UNESCAPED_UNICODE) . "\n"
              . 'کالاهای زیر نقطه سفارش: ' . json_encode($low, JSON_UNESCAPED_UNICODE) . "\n"
              . 'چک‌های نزدیک سررسید: ' . json_encode($chq, JSON_UNESCAPED_UNICODE)
              . "\n(مبالغ به ریال)";

        $r = Ai::json([
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user', 'content' => $user],
        ], ['type' => 'summary', 'max_tokens' => 900, 'temperature' => 0.4]);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => $r['error'] ?? 'خطای هوش مصنوعی']);

        $actions = array_values(array_filter(array_map('strval', (array)($r['data']['actions'] ?? []))));
        return $this->json([
            'ok'      => true,
            'summary' => (string)($r['data']['summary'] ?? ''),
            'actions' => array_slice($actions, 0, 4),
            'health'  => in_array(($r['data']['health'] ?? ''), ['good', 'warn', 'bad'], true) ? $r['data']['health'] : 'warn',
        ]);
    }

    /* ─────────── کمکی‌ها ─────────── */

    /** منابع خواندنی مجاز برای Text-to-SQL */
    private function allowedSources(): array
    {
        return array_values(array_unique(array_merge(
            Schema::views(),
            ['persons', 'products', 'chart_of_accounts', 'fiscal_years', 'cash_accounts', 'warehouses']
        )));
    }

    /** ساخت متن فشردهٔ ساختار داده برای مدل */
    private function schemaContext(): string
    {
        $lines = [];
        foreach (Schema::views() as $v) {
            $cols = Schema::columns($v); if (!$cols) continue;
            $parts = []; $i = 0;
            foreach ($cols as $c => $m) { if ($i++ >= 20) break; $parts[] = $c . '=' . Schema::label($v, $c); }
            $lines[] = $v . ': ' . implode(', ', $parts);
        }
        foreach (['persons', 'products', 'chart_of_accounts', 'fiscal_years', 'cash_accounts', 'warehouses'] as $t) {
            $cols = Schema::columns($t); if (!$cols) continue;
            $parts = []; $i = 0;
            foreach ($cols as $c => $m) { if ($i++ >= 22) break; $parts[] = $c; }
            $lines[] = $t . ': ' . implode(', ', $parts);
        }
        return implode("\n", $lines);
    }

    /** اعتبارسنجی کوئری: فقط SELECT روی منابع مجاز با محدودیت کسب‌وکار */
    private function safeSql(string $sql, array $allowed): ?string
    {
        $s = trim($sql);
        $s = rtrim($s, "; \t\n\r");
        if ($s === '') return 'کوئری خالی است';
        if (str_contains($s, ';')) return 'چند دستور مجاز نیست';
        if (!preg_match('/^\s*(select|with)\b/i', $s)) return 'فقط SELECT مجاز است';
        if (preg_match('/\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|replace|call|execute|handler|load_file|outfile|dumpfile|rename|lock|unlock|information_schema|performance_schema|mysql\s*\.)/i', $s)) return 'عبارت غیرمجاز در کوئری';
        if (preg_match_all('/\b(?:from|join)\s+`?([a-zA-Z0-9_]+)`?/i', $s, $m)) {
            foreach ($m[1] as $tbl) if (!in_array($tbl, $allowed, true)) return 'منبع غیرمجاز: ' . $tbl;
        } else {
            return 'جدول مشخص نشده است';
        }
        if (!preg_match('/\bbusiness_id\b/i', $s)) return 'شرط business_id لازم است';
        if (!str_contains($s, ':biz')) return 'پارامتر :biz لازم است';
        if (!preg_match('/\blimit\b/i', $s)) $s .= ' LIMIT 200';
        return null;
    }

    private function json(array $data): string
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        return '';
    }
}
