<?php
/**
 * استخراج هوشمند اطلاعات از سند (PDF/تصویر) و پیش‌پرکردن فرم‌های «ثبت».
 * - PDF: رَسترسازی چندلایه (Imagick با Ghostscript → gs → pdftoppm → sips).
 * - مدل بینایی، سند را می‌خواند و اطلاعات را به فیلدها + اشخاص/کالاهای موجود نگاشت می‌کند.
 * - هیچ‌چیز خودکار ثبت نمی‌شود.
 */
final class AiExtractController
{
    public function extract(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);

        $kind = (string)post('kind', 'invoice');
        $name = (string)post('filename', 'document');
        $data = (string)post('file_data');
        if ($data === '') return $this->json(['ok' => false, 'error' => 'فایلی انتخاب نشده است.']);
        $data = preg_replace('/^data:[^;]+;base64,/', '', $data);
        $bytes = base64_decode($data, true);
        if ($bytes === false || strlen($bytes) < 100) return $this->json(['ok' => false, 'error' => 'فایل نامعتبر است.']);
        if (strlen($bytes) > 9 * 1024 * 1024) return $this->json(['ok' => false, 'error' => 'حجم فایل باید کمتر از ۸ مگابایت باشد.']);

        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $mime = ['pdf' => 'application/pdf', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'webp' => 'image/webp', 'gif' => 'image/gif'][$ext] ?? '';
        if ($mime === '') $mime = (str_starts_with($bytes, '%PDF') ? 'application/pdf' : 'image/png');

        $images = $this->rasterize($bytes, $mime);
        if (!$images) return $this->json(['ok' => false, 'error' => 'خواندن PDF روی این سرور ممکن نشد. لطفاً تصویر سند را JPG/PNG بارگذاری کنید.']);

        $spec = $this->spec($kind);
        [$persons, $products] = $this->candidates();

        $pList = ''; foreach ($persons as $x) $pList .= $x['id'] . '|' . $x['code'] . '|' . trim((string)$x['name']) . "\n";
        $kList = ''; foreach ($products as $x) $kList .= $x['id'] . '|' . $x['code'] . '|' . $x['title'] . '|' . $x['item_type'] . "\n";

        $fieldList = ''; foreach ($spec['fields'] as $f) $fieldList .= '- ' . $f['key'] . ' : ' . $f['label'] . "\n";

        $sys = 'تو دستیار خبرهٔ استخراج اسناد حسابداری ایرانی هستی. تصویر یک «' . $spec['title'] . '» است. '
             . 'اطلاعات را با دقت استخراج کن و تا حد امکان به رکوردهای موجودِ سیستم نگاشت کن. '
             . 'خروجی را فقط به‌صورت JSON با این ساختار بده: '
             . '{"fields":{...},"person_id":عدد یا null,"person_name":"...","items":[{"product_id":عدد یا null,"name":"...","quantity":عدد,"unit_price":عدد,"unit_cost":عدد,"tax_rate":عدد,"line_total":عدد}],'
             . '"totals":{"subtotal":عدد یا null,"discount":عدد یا null,"tax":عدد یا null,"grand_total":عدد یا null},"doc":{"number":"...","date":"...","due_date":"..."},"notes":"ابهامات کوتاه","confidence":عدد۰تا۱}. '
             . 'قواعد: اگر شخص/کالا در فهرست موجود بود، شناسهٔ آن را در person_id/product_id بگذار؛ وگرنه null. '
             . 'مبالغ و اعداد را بدون جداکننده و فقط عددی برگردان. تاریخ‌ها را عیناً همان‌طور که در سند آمده. اگر فیلدی در سند نبود null بگذار و از خودت نساز.';

        $userText = 'کسب‌وکار: ' . (Auth::business()['name'] ?? '') . "\nامروز: " . jdate(today()) . "\n\nفیلدهای موردنیاز:\n" . $fieldList;
        if (!empty($spec['items'])) $userText .= "\nاقلام سند را در آرایهٔ items برگردان (نام، مقدار، قیمت/بهای واحد، درصد مالیات، جمع سطر).\n";
        $userText .= "\nاشخاص موجود (id | کد | نام):\n" . ($pList ?: '(خالی)') . "\nکالاها/خدمات موجود (id | کد | عنوان | نوع):\n" . ($kList ?: '(خالی)');

        $content = [['type' => 'text', 'text' => $userText]];
        foreach ($images as $img) $content[] = ['type' => 'image_url', 'image_url' => ['url' => $img]];

        $r = Ai::json([['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $content]], ['type' => 'extract.' . $kind, 'max_tokens' => 1600, 'temperature' => 0]);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => $r['error'] ?? 'خطای هوش مصنوعی']);

        $d = $r['data'];
        $fields = is_array($d['fields'] ?? null) ? $d['fields'] : [];

        $assign = [];
        foreach ($spec['fields'] as $f) {
            $v = $fields[$f['key']] ?? null;
            if ($v === null || $v === '' || !empty($f['skip_assign'])) continue;
            if (!empty($f['date'])) $v = $this->toJalali((string)$v);
            $assign[$f['sel']] = is_scalar($v) ? (string)$v : $v;
        }

        // شخص: id معتبر یا جست‌وجوی نام
        $personId = (int)($d['person_id'] ?? 0);
        $validPerson = false;
        if ($personId && Database::val('SELECT id FROM persons WHERE id=? AND business_id=?', [$personId, Auth::businessId()])) $validPerson = true;
        $personName = trim((string)($d['person_name'] ?? ''));

        // اقلام: اعتبارسنجی product_id
        $items = [];
        if (!empty($spec['items']) && is_array($d['items'] ?? null)) {
            foreach (array_slice($d['items'], 0, 50) as $it) {
                if (!is_array($it)) continue;
                $nm = trim((string)($it['name'] ?? ''));
                $pid = (int)($it['product_id'] ?? 0);
                if ($pid && !Database::val('SELECT id FROM products WHERE id=? AND business_id=?', [$pid, Auth::businessId()])) $pid = 0;
                if ($nm === '' && !$pid) continue;
                $items[] = ['product_id' => $pid ?: null, 'name' => $nm,
                    'quantity' => (float)($it['quantity'] ?? 0), 'unit_price' => (float)($it['unit_price'] ?? 0),
                    'unit_cost' => (float)($it['unit_cost'] ?? 0), 'tax_rate' => (float)($it['tax_rate'] ?? 0),
                    'line_total' => (float)($it['line_total'] ?? 0)];
            }
        }

        $tot = is_array($d['totals'] ?? null) ? $d['totals'] : [];
        $doc = is_array($d['doc'] ?? null) ? $d['doc'] : [];
        foreach (['date', 'due_date'] as $k) if (!empty($doc[$k])) $doc[$k] = $this->toJalali((string)$doc[$k]);

        return $this->json([
            'ok'          => true,
            'assign'      => (object)$assign,
            'person_id'   => $validPerson ? $personId : null,
            'person_name' => $personName,
            'items'       => $items,
            'totals'      => (object)array_map(fn($v) => $v === null ? null : (float)$v, $tot),
            'doc'         => (object)$doc,
            'notes'       => (string)($d['notes'] ?? ''),
            'confidence'  => min(1, max(0, (float)($d['confidence'] ?? 0))),
        ]);
    }

    /** رَسترسازی سند به تصویر(ها) با چند موتور — مستقل از محیط */
    private function rasterize(string $bytes, string $mime): array
    {
        if ($mime !== 'application/pdf') return ['data:' . $mime . ';base64,' . base64_encode($bytes)];

        // ۱) Imagick (روی سرورهای دارای Ghostscript)
        if (class_exists('Imagick')) {
            try {
                $im = new Imagick();
                $im->setResolution(150, 150);
                $im->readImageBlob($bytes);
                $n = min(3, $im->getNumberImages());
                $out = [];
                for ($i = 0; $i < $n; $i++) {
                    $im->setIteratorIndex($i);
                    $pg = clone $im->getImage();
                    try { $pg->setImageBackgroundColor('white'); $pg->setImageAlphaChannel(Imagick::ALPHACHANNEL_REMOVE); } catch (Throwable $e) { }
                    $pg->setImageFormat('jpeg');
                    $pg->setImageCompressionQuality(85);
                    $out[] = 'data:image/jpeg;base64,' . base64_encode($pg->getImageBlob());
                    $pg->clear();
                }
                $im->clear();
                if ($out) return $out;
            } catch (Throwable $e) { /* ادامه با روش‌های بعدی */ }
        }

        $tmp = storage_path('tmp'); if (!is_dir($tmp)) @mkdir($tmp, 0775, true);
        if (!is_dir($tmp) || !function_exists('exec')) return [];
        $base = $tmp . '/ai_' . bin2hex(random_bytes(5));
        $pdf = $base . '.pdf'; @file_put_contents($pdf, $bytes);
        $out = [];
        try {
            // ۲) gs
            if ($this->hasBin('gs')) {
                @exec('gs -q -dNOPAUSE -dBATCH -sDEVICE=jpeg -dJPEGQ=85 -r150 -dFirstPage=1 -dLastPage=3 -sOutputFile=' . escapeshellarg($base . '-%d.jpg') . ' ' . escapeshellarg($pdf) . ' 2>/dev/null');
                $out = $this->collectImages($base);
            }
            // ۳) pdftoppm
            if (!$out && $this->hasBin('pdftoppm')) {
                @exec('pdftoppm -jpeg -jpegopt quality=85 -r 150 -f 1 -l 3 ' . escapeshellarg($pdf) . ' ' . escapeshellarg($base) . ' 2>/dev/null');
                $out = $this->collectImages($base);
            }
            // ۴) sips (macOS)
            if (!$out && $this->hasBin('sips')) {
                @exec('sips -s format jpeg -s formatOptions 85 ' . escapeshellarg($pdf) . ' --out ' . escapeshellarg($base . '-sips.jpg') . ' 2>/dev/null');
                $out = $this->collectImages($base . '-sips');
            }
        } finally {
            foreach (glob($base . '*') as $f) @unlink($f);
        }
        return $out;
    }

    private function hasBin(string $bin): bool
    {
        static $cache = [];
        if (isset($cache[$bin])) return $cache[$bin];
        $ok = false;
        @exec('command -v ' . escapeshellarg($bin) . ' 2>/dev/null', $o, $c);
        return $cache[$bin] = ($c === 0 && !empty($o));
    }

    private function collectImages(string $prefix): array
    {
        $out = [];
        $fs = array_merge(glob($prefix . '*.jpg') ?: [], glob($prefix . '*.jpeg') ?: [], glob($prefix . '*.png') ?: []);
        sort($fs);
        foreach (array_slice($fs, 0, 3) as $f) {
            $b = @file_get_contents($f);
            if ($b === false || strlen($b) < 500) continue;
            $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
            $mime = ($ext === 'png') ? 'image/png' : 'image/jpeg';
            $out[] = 'data:' . $mime . ';base64,' . base64_encode($b);
        }
        return $out;
    }

    /** تبدیل تاریخ میلادی (YYYY-MM-DD) به شمسی برای نمایش در فیلدهای تاریخ */
    private function toJalali(string $v): string
    {
        $v = trim($v);
        if (preg_match('/^(\d{4})-(\d{1,2})-(\d{1,2})/', $v, $m)) {
            [$jy, $jm, $jd] = gregorian_to_jalali((int)$m[1], (int)$m[2], (int)$m[3]);
            return sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
        }
        return $v;
    }

    /** فهرست اشخاص و کالاهای موجود برای نگاشت */
    private function candidates(): array
    {
        $biz = Auth::businessId();
        $persons = Database::all('SELECT id, code, CONCAT(IFNULL(first_name,"")," ",IFNULL(last_name,"")," ",IFNULL(company_name,"")) AS name
            FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 250', [$biz]);
        $products = Database::all('SELECT id, code, title, item_type FROM products WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 350', [$biz]);
        return [$persons, $products];
    }

    private function spec(string $kind): array
    {
        $m = [
            'invoice' => ['title' => 'فاکتور خرید/فروش', 'items' => true, 'fields' => [
                ['key' => 'date', 'label' => 'تاریخ فاکتور', 'sel' => '[name="invoice_date"]', 'date' => true],
                ['key' => 'due_date', 'label' => 'تاریخ سررسید', 'sel' => '[name="due_date"]', 'date' => true],
                ['key' => 'discount', 'label' => 'تخفیف کل', 'sel' => '[name="invoice_discount"]'],
                ['key' => 'description', 'label' => 'توضیحات', 'sel' => '[name="description"]'],
            ]],
            'receipt' => ['title' => 'رسید دریافت وجه', 'items' => false, 'fields' => [
                ['key' => 'date', 'label' => 'تاریخ', 'sel' => '[name="doc_date"]', 'date' => true],
                ['key' => 'amount', 'label' => 'مبلغ', 'sel' => '[name="amount"]'],
                ['key' => 'description', 'label' => 'بابت/شرح', 'sel' => '[name="description"]'],
                ['key' => 'cheque_no', 'label' => 'شمارهٔ چک', 'sel' => '[name="cheque_no"]'],
                ['key' => 'bank_name', 'label' => 'بانک', 'sel' => '[name="bank_name"]'],
                ['key' => 'due_date', 'label' => 'سررسید چک', 'sel' => '[name="due_date"]', 'date' => true],
            ]],
            'payment' => ['title' => 'سند پرداخت وجه', 'items' => false, 'fields' => [
                ['key' => 'date', 'label' => 'تاریخ', 'sel' => '[name="doc_date"]', 'date' => true],
                ['key' => 'amount', 'label' => 'مبلغ', 'sel' => '[name="amount"]'],
                ['key' => 'description', 'label' => 'بابت/شرح', 'sel' => '[name="description"]'],
                ['key' => 'cheque_no', 'label' => 'شمارهٔ چک', 'sel' => '[name="cheque_no"]'],
                ['key' => 'bank_name', 'label' => 'بانک', 'sel' => '[name="bank_name"]'],
                ['key' => 'due_date', 'label' => 'سررسید چک', 'sel' => '[name="due_date"]', 'date' => true],
            ]],
            'cheque' => ['title' => 'چک', 'items' => false, 'fields' => [
                ['key' => 'cheque_no', 'label' => 'شمارهٔ چک', 'sel' => '[name="cheque_no"]'],
                ['key' => 'bank_name', 'label' => 'نام بانک', 'sel' => '[name="bank_name"]'],
                ['key' => 'branch_name', 'label' => 'شعبه', 'sel' => '[name="branch_name"]'],
                ['key' => 'sayad_id', 'label' => 'شناسهٔ صیاد', 'sel' => '[name="sayad_id"]'],
                ['key' => 'amount', 'label' => 'مبلغ', 'sel' => '[name="amount"]'],
                ['key' => 'issue_date', 'label' => 'تاریخ صدور', 'sel' => '[name="issue_date"]', 'date' => true],
                ['key' => 'due_date', 'label' => 'تاریخ سررسید', 'sel' => '[name="due_date"]', 'date' => true],
                ['key' => 'account_no', 'label' => 'شمارهٔ حساب', 'sel' => '[name="account_no"]'],
            ]],
            'stock_doc' => ['title' => 'سند انبار (رسید/حواله/ضایعات)', 'items' => true, 'fields' => [
                ['key' => 'date', 'label' => 'تاریخ سند', 'sel' => '[name="doc_date"]', 'date' => true],
                ['key' => 'description', 'label' => 'توضیحات', 'sel' => '[name="description"]'],
            ]],
            'stock_transfer' => ['title' => 'حوالهٔ انتقال بین انبارها', 'items' => true, 'fields' => [
                ['key' => 'date', 'label' => 'تاریخ', 'sel' => '[name="doc_date"]', 'date' => true],
                ['key' => 'description', 'label' => 'توضیحات', 'sel' => '[name="description"]'],
            ]],
        ];
        return $m[$kind] ?? $m['invoice'];
    }

    private function json(array $data): string
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        return '';
    }
}
