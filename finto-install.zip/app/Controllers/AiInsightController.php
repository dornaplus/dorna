<?php
/**
 * هوش مصنوعی سرتاسری: «بینش» هر بخش/رکورد/گزارش + «تولید متن» (شرح، پیامک وصول، پاسخ تیکت).
 * همه‌جا فقط-خواندنی و محدود به کسب‌وکار جاری.
 */
final class AiInsightController
{
    /* ═══════════ بینش (Insight) ═══════════ */
    public function insight(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);
        $scope = (string)post('scope', 'dashboard');
        $biz   = Auth::businessId();

        $snap = [];
        $label = 'کسب‌وکار';
        try {
            switch ($scope) {
                case 'resource':
                    $m = Meta::module((string)post('module'));
                    if (!$m) return $this->json(['ok' => false, 'error' => 'ماژول نامعتبر']);
                    $label = $m['title'];
                    $snap = $this->snapResource($m);
                    break;
                case 'record':
                    $m = Meta::module((string)post('module'));
                    if (!$m) return $this->json(['ok' => false, 'error' => 'ماژول نامعتبر']);
                    $label = $m['singular'];
                    $snap = $this->snapRecord($m, (string)post('id'));
                    break;
                case 'report':
                    $label = (string)post('title', 'گزارش');
                    $snap = $this->snapReport();
                    break;
                case 'audit':
                    $label = 'بازبینی اسناد';
                    $snap = $this->snapAudit();
                    break;
                default:
                    $label = 'داشبورد مدیریتی';
                    $snap = $this->snapDashboard();
            }
        } catch (Throwable $e) {
            return $this->json(['ok' => false, 'error' => 'داده‌ای برای تحلیل یافت نشد.']);
        }
        if (!$snap) return $this->json(['ok' => false, 'error' => 'داده‌ای برای تحلیل این بخش وجود ندارد.']);

        $sys = 'تو تحلیلگر مالی و عملیاتی نرم‌افزار حسابداری فینتو هستی. بر اساس دادهٔ JSON بخش «' . $label . '» یک تحلیل کوتاه و کاربردی ارائه بده. '
             . 'خروجی فقط JSON: {"headline":"یک جمله","score":عدد۰تا۱۰۰,"band":"good|warn|bad","bullets":["حداکثر ۴ نکته"],"actions":["حداکثر ۳ اقدام"]}. '
             . 'مبالغ به ریال‌اند. عدد score = سلامت/ریسک (بالاتر بهتر). نکات باید مشخص و قابل اقدام باشند.';
        $user = 'بخش: ' . $label . "\nداده: " . json_encode($snap, JSON_UNESCAPED_UNICODE);

        $r = Ai::json([
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user', 'content' => $user],
        ], ['type' => 'insight.' . $scope, 'max_tokens' => 900, 'temperature' => 0.3]);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => $r['error'] ?? 'خطای هوش مصنوعی']);

        $d = $r['data'];
        return $this->json([
            'ok'       => true,
            'headline' => (string)($d['headline'] ?? ''),
            'score'    => max(0, min(100, (int)($d['score'] ?? 0))),
            'band'     => in_array(($d['band'] ?? ''), ['good', 'warn', 'bad'], true) ? $d['band'] : 'warn',
            'bullets'  => array_slice(array_values(array_filter(array_map('strval', (array)($d['bullets'] ?? [])))), 0, 4),
            'actions'  => array_slice(array_values(array_filter(array_map('strval', (array)($d['actions'] ?? [])))), 0, 3),
        ]);
    }

    /* ═══════════ تولید متن (Compose) ═══════════ */
    public function compose(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'سرویس هوش مصنوعی تنظیم نشده است.']);
        $type = (string)post('type', 'invoice_desc');
        $ctx  = trim((string)post('context'));
        $biz  = Auth::business()['name'] ?? '';

        $specs = [
            'invoice_desc'   => ['شرح/توضیحات یک فاکتور فروش یا خرید', 'یک توضیح کوتاه و رسمی (حداکثر ۲۰ کلمه) بنویس.'],
            'expense_desc'   => ['عنوان و شرح یک سند هزینه یا درآمد', 'یک عنوان کوتاه (حداکثر ۸ کلمه) و یک شرح تک‌خطی بنویس.'],
            'journal_desc'   => ['شرح یک سند حسابداری دستی', 'یک شرح رسمی و کوتاه (حداکثر ۱۵ کلمه) بنویس.'],
            'collection_sms' => ['پیامک یادآوری وصول مطالبات', 'یک پیامک مؤدبانه و کوتاه فارسی (حداکثر ۱۶۰ کاراکتر) برای یادآوری پرداخت بنویس؛ لحن محترمانه و پیگیری‌محور.'],
            'ticket_reply'   => ['پاسخ به تیکت پشتیبانی نرم‌افزار حسابداری', 'یک پاسخ حرفه‌ای، همدلانه و راهنما (۳ تا ۵ خط) پیشنهاد بده؛ اگر اطلاعات کافی نیست، سؤال روشنگر بپرس.'],
            'product_desc'   => ['توضیح یک کالا/خدمت', 'یک توضیح کوتاه بازاریابی‌محور (حداکثر ۲۰ کلمه) بنویس.'],
        ];
        [$what, $how] = $specs[$type] ?? $specs['invoice_desc'];

        $sys = 'تو دستیار محتوای نرم‌افزار حسابداری فینتو هستی. برای «' . $what . '» متن تولید کن. ' . $how
             . ' خروجی فقط JSON: {"text":"متن نهایی","title":"عنوان پیشنهادی (اختیاری)"}. متن فارسی، روان و بدون توضیح اضافه باشد.';
        $user = 'کسب‌وکار: ' . $biz . "\nزمینه/داده: " . ($ctx !== '' ? $ctx : '(خالی)');

        $r = Ai::json([
            ['role' => 'system', 'content' => $sys],
            ['role' => 'user', 'content' => $user],
        ], ['type' => 'compose.' . $type, 'max_tokens' => 600, 'temperature' => 0.5]);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => $r['error'] ?? 'خطای هوش مصنوعی']);

        return $this->json(['ok' => true, 'text' => (string)($r['data']['text'] ?? ''), 'title' => (string)($r['data']['title'] ?? '')]);
    }

    /* ═══════════ سازنده‌های دادهٔ هر بخش ═══════════ */

    private function snapDashboard(): array
    {
        $biz = Auth::businessId();
        $kpi = Database::one('SELECT * FROM v_dashboard_kpi WHERE business_id=? LIMIT 1', [$biz]) ?? [];
        $top = Database::all('SELECT person_name, sales_amount FROM v_sales_by_person WHERE business_id=? ORDER BY sales_amount DESC LIMIT 5', [$biz]);
        $over = Database::all('SELECT invoice_no, person_name, remaining_amount, days_overdue FROM v_invoice_list WHERE business_id=? AND days_overdue>0 ORDER BY days_overdue DESC LIMIT 5', [$biz]);
        $low = Database::all('SELECT product_title, available_quantity, reorder_point FROM v_low_stock WHERE business_id=? LIMIT 5', [$biz]);
        return ['شاخص‌ها' => $kpi, 'برترین_مشتریان' => $top, 'معوق‌ها' => $over, 'کم‌موجود' => $low];
    }

    /* بینش عمومی یک ماژول (اشخاص، کالا، چک، …) */
    private function snapResource(array $m): array
    {
        $t = $m['table'];
        $cols = Schema::columns($t);
        $where = []; $params = [];
        if (isset($cols['business_id'])) { $where[] = 'business_id = ?'; $params[] = Auth::businessId(); }
        if (isset($cols['deleted_at'])) $where[] = 'deleted_at IS NULL';
        $w = $where ? ' WHERE ' . implode(' AND ', $where) : '';
        $total = (int)Database::val("SELECT COUNT(*) FROM `$t`$w", $params, 0);
        $out = ['تعداد' => $total];

        // نمونهٔ رکوردها با ستون‌های متنی مهم
        $sel = ['id'];
        foreach (array_slice(array_keys($cols), 0, 40) as $c) {
            if (in_array($c, ['business_id', 'created_at', 'updated_at', 'deleted_at', 'created_by', 'updated_by', 'row_version', 'password_hash', 'value_json', 'layout_json', 'scopes_json', 'condition_json'], true)) continue;
            $sel[] = $c;
            if (count($sel) >= 9) break;
        }
        $rows = Database::all('SELECT `' . implode('`,`', $sel) . "` FROM `$t`$w ORDER BY id DESC LIMIT 8", $params);
        // برچسب فارسی ستون‌ها
        $labels = []; foreach ($sel as $c) $labels[$c] = Schema::label($t, $c);
        $out['نمونه'] = ['برچسب‌ها' => $labels, 'ردیف‌ها' => $rows];

        // اگر مبلغ زیاد و تاریخ دارد، جمع‌ها را اضافه کن
        foreach (['total_amount', 'amount', 'remaining_amount', 'paid_amount', 'current_balance'] as $c) {
            if (isset($cols[$c])) {
                $sum = (float)Database::val("SELECT IFNULL(SUM(`$c`),0) FROM `$t`$w", $params, 0);
                $out['جمع_' . Schema::label($t, $c)] = $sum;
            }
        }
        return $out;
    }

    private function snapRecord(array $m, string $id): array
    {
        $t = $m['table'];
        $row = Database::one('SELECT * FROM `' . $t . '` WHERE `' . Schema::pk($t)[0] . '`=?', [$id]);
        if (!$row) return [];
        $cols = Schema::columns($t);
        $out = [];
        foreach ($row as $c => $v) {
            if ($v === null || $v === '' || in_array($c, ['password_hash', 'value_json', 'layout_json', 'scopes_json', 'condition_json'], true)) continue;
            if ($c === 'business_id' && (int)$v !== Auth::businessId()) abort(404, 'رکورد یافت نشد.');
            $out[Schema::label($t, $c)] = is_numeric($v) && strlen((string)$v) > 6 ? (float)$v : $v;
        }
        // فرزندان/وابستگی‌ها
        foreach (($m['children'] ?? []) as $ch) {
            try { $out['تعداد_' . ($ch['title'] ?? $ch['table'])] = (int)Database::val('SELECT COUNT(*) FROM `' . $ch['table'] . '` WHERE `' . $ch['fk'] . '`=?', [$id], 0); } catch (Throwable $e) { }
        }
        return $out;
    }

    /* گزارش: دادهٔ نمونه را سمت کلاینت می‌فرستیم و اینجا خلاصه می‌کنیم */
    private function snapReport(): array
    {
        $sample = json_decode((string)post('sample'), true);
        $out = ['تعداد_ردیف' => (int)post('count', 0)];
        if (is_array($sample)) $out['نمونه'] = array_slice($sample, 0, 30);
        return $out;
    }

    /* بازبینی اسناد اخیر: عدم توازن، مالیات، موارد مشکوک */
    private function snapAudit(): array
    {
        $biz = Auth::businessId();
        $recent = Database::all("SELECT entry_no, entry_type, entry_date, total_debit, total_credit, line_count, description
            FROM journal_entries WHERE business_id=? AND status='posted' ORDER BY id DESC LIMIT 30", [$biz]);
        $unbalanced = array_values(array_filter($recent, fn($e) => abs((float)$e['total_debit'] - (float)$e['total_credit']) > 0.01));
        $dups = Database::all("SELECT amount, cash_account_id, doc_date, COUNT(*) AS c FROM payments WHERE business_id=? AND status<>'cancelled'
            GROUP BY amount, cash_account_id, doc_date HAVING COUNT(*) > 1 ORDER BY COUNT(*) DESC LIMIT 5", [$biz]);
        $bigInv = Database::all("SELECT invoice_no, total_amount, invoice_type FROM invoices WHERE business_id=? AND status NOT IN ('draft','cancelled') ORDER BY total_amount DESC LIMIT 5", [$biz]);
        return ['آخرین_اسناد' => $recent, 'اسناد_نامتوازن' => $unbalanced, 'پرداخت‌های_تکراری' => $dups, 'بزرگ‌ترین_فاکتورها' => $bigInv];
    }

    private function json(array $data): string
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        return '';
    }
}
