<?php
/** تشخیص ناهنجاری اسناد */
final class AnomalyController
{
    public function index(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('reports.view') && !Auth::isAdmin()) abort(403, 'مجوز مشاهده ندارید.');
        return view('pages/reports/anomalies', ['title' => 'ناهنجاری‌ها', 'a' => Anomaly::detect()]);
    }
}
