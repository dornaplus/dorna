<?php
/** ورود، ثبت‌نام با کد تایید، فراموشی رمز */
final class AuthController
{
    public const PURP_REGISTER = 'register';
    public const PURP_RESET = 'reset';

    public function login(array $p): string
    {
        if (Auth::id() && !is_post()) redirect($_SESSION['business_id'] ?? null ? 'app' : 'onboarding/business');
        // گام صفر: انتخاب سامانه (فینتو / فیدا) پیش از ورود
        if (!is_post() && !isset($_GET['mode'])) {
            return view('pages/auth/choose', ['title' => 'ورود — انتخاب سامانه', 'variant' => 'login']);
        }
        $error = null;
        if (is_post()) {
            csrf_verify();
            $mobile = $this->normalizeMobile((string)post('mobile'));
            $password = (string)($_POST['password'] ?? '');
            if (!$mobile || !$password) $error = 'شماره موبایل و رمز عبور را وارد کنید.';
            else {
                [$ok, $res] = Auth::attempt($mobile, $password);
                if ($ok) {
                    Auth::loginUser($res);
                    if (!Auth::businessId()) redirect('onboarding/business');
                    redirect($_SESSION['intended'] ?? nav_home());
                }
                $error = $res;
            }
        }
        return view('pages/auth/login', ['title' => 'ورود به نرم‌افزار', 'error' => $error]);
    }

    public function register(array $p): string
    {
        if (Auth::id()) redirect('app');
        // گام صفر: انتخاب نوع سامانه پیش از فرم ثبت‌نام
        if (!is_post() && !isset($_GET['mode'])) {
            return view('pages/auth/choose', ['title' => 'انتخاب سامانه']);
        }
        $error = null;
        if (is_post()) {
            csrf_verify();
            $mobile = $this->normalizeMobile((string)post('mobile'));
            $password = (string)($_POST['password'] ?? '');
            $confirm = (string)($_POST['password_confirmation'] ?? '');
            $purposes = $_POST['accept_terms'] ?? null;
            $cfg = config('security');
            if (!$mobile) $error = 'شماره موبایل معتبر نیست (مثال: 09121234567).';
            elseif (mb_strlen($password) < $cfg['password_min']) $error = 'رمز عبور باید حداقل '.$cfg['password_min'].' کاراکتر باشد.';
            elseif ($password !== $confirm) $error = 'تکرار رمز عبور مطابقت ندارد.';
            elseif (!$purposes) $error = 'پذیرش قوانین و شرایط استفاده الزامی است.';
            else {
                $exists = Database::one('SELECT * FROM users WHERE mobile=?', [$mobile]);
                try {
                    if ($exists) {
                        Otp::create((int)$exists['id'], $mobile, self::PURP_REGISTER);
                    } else {
                        $uid = Database::insert('users', ['full_name' => '', 'mobile' => $mobile,
                            'password_hash' => password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]),
                            'status' => 'active', 'preferred_language' => 'fa', 'theme' => 'light', 'is_active' => 1, 'created_at' => now()]);
                        Otp::create($uid, $mobile, self::PURP_REGISTER);
                    }
                    $_SESSION['otp_mobile'] = $mobile;
                    $_SESSION['otp_purpose'] = self::PURP_REGISTER;
                    redirect('verify');
                } catch (Throwable $e) { $error = $e->getMessage(); }
            }
        }
        return view('pages/auth/register', ['title' => 'ثبت‌نام', 'error' => $error]);
    }

    public function verify(array $p): string
    {
        $mobile = $_SESSION['otp_mobile'] ?? null;
        if (!$mobile) redirect('register');
        $purpose = $_SESSION['otp_purpose'] ?? self::PURP_REGISTER;
        $error = null; $info = null;
        if (config('app')['demo_mode']) {
            $demoCode = $_SESSION['_demo_otp'][$mobile] ?? '';
            if (!$demoCode) {
                $log = @file_get_contents(storage_path('sms.log')) ?: '';
                if (preg_match_all('/(?:^|\n)[^|]*\| '.preg_quote($mobile, '/').' \| [^0-9]*(\d{6})/', $log, $mm)) $demoCode = (string)end($mm[1]);
            }
            $info = $demoCode
                ? 'حالت نمایشی: کد تایید این شماره «'.$demoCode.'» است. در محیط عملیاتی این کد به‌صورت پیامک (کاوه‌نگار) ارسال می‌شود.'
                : 'حالت نمایشی: کد تایید در فایل storage/sms.log و جدول messages ثبت شده است.';
        }
        if (is_post()) {
            csrf_verify();
            $code = strtr((string)post('code'), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
            $code = preg_replace('/\D/', '', $code);
            [$ok, $res] = Otp::verify($mobile, (string)$code, $purpose);
            if ($ok) {
                $u = Database::one('SELECT * FROM users WHERE mobile=?', [$mobile]);
                if (!$u) { $error = 'کاربر یافت نشد.'; }
                elseif ($purpose === self::PURP_RESET) {
                    $_SESSION['reset_user_id'] = (int)$u['id'];
                    unset($_SESSION['otp_mobile'], $_SESSION['otp_purpose']);
                    redirect('reset');
                } else {
                    unset($_SESSION['otp_mobile'], $_SESSION['otp_purpose']);
                    Auth::setPending((int)$u['id']);
                    Database::run('UPDATE users SET last_login_at=NOW() WHERE id=?', [$u['id']]);
                    redirect('onboarding/profile');
                }
            } else $error = $res;
        }
        return view('pages/auth/verify', ['title' => 'کد تایید', 'mobile' => $mobile, 'error' => $error, 'info' => $info]);
    }

    public function resend(array $p): string
    {
        csrf_verify();
        $mobile = $_SESSION['otp_mobile'] ?? '';
        $purpose = $_SESSION['otp_purpose'] ?? self::PURP_REGISTER;
        if (!$mobile) { Flash::push('error', 'ابتدا شماره موبایل را وارد کنید.'); redirect('register'); }
        $u = Database::one('SELECT * FROM users WHERE mobile=?', [$mobile]);
        try { Otp::create($u['id'] ?? null, $mobile, $purpose); Flash::push('success', 'کد تایید جدید ارسال شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('verify');
    }

    public function forgot(array $p): string
    {
        $error = null;
        if (is_post()) {
            csrf_verify();
            $mobile = $this->normalizeMobile((string)post('mobile'));
            $u = $mobile ? Database::one('SELECT * FROM users WHERE mobile=?', [$mobile]) : null;
            if (!$u) $error = 'کاربری با این شماره موبایل ثبت نشده است.';
            else {
                try {
                    Otp::create((int)$u['id'], $mobile, self::PURP_RESET);
                    $_SESSION['otp_mobile'] = $mobile; $_SESSION['otp_purpose'] = self::PURP_RESET;
                    redirect('verify');
                } catch (Throwable $e) { $error = $e->getMessage(); }
            }
        }
        return view('pages/auth/forgot', ['title' => 'فراموشی رمز عبور', 'error' => $error]);
    }

    public function reset(array $p): string
    {
        $uid = $_SESSION['reset_user_id'] ?? null;
        if (!$uid) redirect('forgot');
        $error = null;
        if (is_post()) {
            csrf_verify();
            $password = (string)($_POST['password'] ?? '');
            $confirm = (string)($_POST['password_confirmation'] ?? '');
            $cfg = config('security');
            if (mb_strlen($password) < $cfg['password_min']) $error = 'رمز عبور باید حداقل '.$cfg['password_min'].' کاراکتر باشد.';
            elseif ($password !== $confirm) $error = 'تکرار رمز عبور مطابقت ندارد.';
            else {
                Database::run('UPDATE users SET password_hash=?, password_changed_at=NOW(), failed_attempts=0, locked_until=NULL WHERE id=?',
                    [password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]), $uid]);
                $u = Database::one('SELECT * FROM users WHERE id=?', [$uid]);
                unset($_SESSION['reset_user_id']);
                Auth::loginUser($u);
                Flash::push('success', 'رمز عبور با موفقیت تغییر کرد.');
                redirect(Auth::businessId() ? 'app' : 'onboarding/business');
            }
        }
        return view('pages/auth/reset', ['title' => 'تعیین رمز جدید', 'error' => $error]);
    }

    public function logout(array $p): string { Auth::logout(); redirect('login'); }

    public static function normalizeMobile(string $m): ?string
    {
        $m = strtr(trim($m), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',' '=>'', '-'=>'']);
        $m = preg_replace('/^\+?98/', '0', $m);
        return preg_match('/^09\d{9}$/', (string)$m) ? $m : null;
    }
    /** اعتبارسنجی کد ملی ایران (الگوریتم رقم کنترل) */
    public static function validNationalId(string $code): bool
    {
        $code = strtr(trim($code), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
        if (!preg_match('/^\d{10}$/', $code)) return false;
        if (preg_match('/^(\d)\1{9}$/', $code)) return false;
        $sum = 0;
        for ($i = 0; $i < 9; $i++) $sum += (int)$code[$i] * (10 - $i);
        $r = $sum % 11;
        $c = (int)$code[9];
        return ($r < 2 && $c === $r) || ($r >= 2 && $c === 11 - $r);
    }
}
