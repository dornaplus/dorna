<?php
/**
 * پشتیبان‌گیری و بازگردانی — کنترلر.
 * همهٔ عملیات روی «کسب‌وکار جاری» انجام می‌شود؛ پشتیبان هر کسب‌وکار فقط برای خودش قابل دانلود/حذف/بازگردانی است.
 */
final class BackupController
{
    private function bid(): int
    {
        Auth::requireApp();
        if (!Auth::can('backup.view')) abort(403, 'مجوز دسترسی به پشتیبان‌گیری را ندارید.');
        return (int)Auth::businessId();
    }

    /* ── فهرست پشتیبان‌ها ── */
    public function index(array $p): string
    {
        $bid = $this->bid();
        $msg = $_SESSION['backup_result'] ?? null; unset($_SESSION['backup_result']);
        $jobs = Backup::jobs($bid);
        // اگر فایل یک پشتیبانِ موفق روی سرور نباشد (مثلاً با پاک‌سازی دستی حذف شده) وضعیتش اصلاح شود
        foreach ($jobs as $j) {
            if ($j['status'] !== 'success' || empty($j['file_name'])) continue;
            $base = pathinfo((string)$j['file_name'], PATHINFO_FILENAME);
            if (!is_file(Backup::dir($bid) . '/' . $base . '.json') && !is_file(Backup::dir($bid) . '/' . $base . '.csv')) {
                Database::update('backup_jobs', ['status' => 'failed', 'error_message' => 'فایل پشتیبان روی سرور موجود نیست.'], 'id=:pk', ['pk' => (int)$j['id']]);
                $j['status'] = 'failed';
            }
        }
        $jobs = Backup::jobs($bid);
        return view('pages/settings/backups', [
            'title'   => 'پشتیبان‌گیری و بازگردانی',
            'jobs'    => $jobs,
            'result'  => $msg,
            'canMake' => Auth::can('backup.create'),
        ]);
    }

    /* ── ساخت پشتیبان ── */
    public function create(array $p): string
    {
        $bid = $this->bid(); csrf_verify();
        if (!Auth::can('backup.create')) { Flash::push('error', 'مجوز ساخت پشتیبان را ندارید.'); redirect('app/backups'); }
        try {
            $job = Backup::create($bid, Auth::id(), 'manual');
            $n = (int)Database::val('SELECT row_count FROM backup_jobs WHERE id=?', [(int)$job['id']], 0);
            Flash::push('success', 'پشتیبان با موفقیت گرفته شد (' . num($n) . ' ردیف از ' . num(count(Backup::tables())) . ' جدول).');
        } catch (Throwable $e) {
            Flash::push('error', 'پشتیبان‌گیری ناموفق: ' . $e->getMessage());
        }
        redirect('app/backups');
        return '';
    }

    /* ── دانلود فایل پشتیبان (JSON یا CSV) ── */
    public function download(array $p): string
    {
        $bid = $this->bid();
        $id  = (int)($p['id'] ?? 0);
        $job = Backup::job($bid, $id);                      // بررسی مالکیت
        if (!$job) { http_response_code(404); exit('پشتیبان یافت نشد.'); }
        $fmt = ($_GET['format'] ?? 'json') === 'csv' ? 'csv' : 'json';
        $base = pathinfo((string)$job['file_name'], PATHINFO_FILENAME);
        $file = Backup::dir($bid) . '/' . $base . '.' . $fmt;
        if (!is_file($file)) {
            // اگر فایل نیست، وضعیت را اصلاح کن و با پیام روشن برگردان
            if (!is_file(Backup::dir($bid) . '/' . $base . '.json') && !is_file(Backup::dir($bid) . '/' . $base . '.csv')) {
                Database::update('backup_jobs', ['status' => 'failed', 'error_message' => 'فایل پشتیبان روی سرور موجود نیست.'], 'id=:pk', ['pk' => (int)$job['id']]);
            }
            Flash::push('error', 'فایل ' . strtoupper($fmt) . ' این پشتیبان روی سرور موجود نیست. یک پشتیبان تازه بگیرید.');
            redirect('app/backups');
        }
        $name = 'finto-backup-b' . $bid . '-' . substr($base, -15) . '.' . $fmt;
        if (headers_sent()) exit('خطا در ارسال فایل.');
        header('Content-Type: ' . ($fmt === 'csv' ? 'text/csv; charset=utf-8' : 'application/json; charset=utf-8'));
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($file));
        header('Cache-Control: no-store');
        readfile($file);
        exit;
    }

    /* ── حذف پشتیبان ── */
    public function delete(array $p): string
    {
        $bid = $this->bid(); csrf_verify();
        $id = (int)($p['id'] ?? 0);
        if (Backup::remove($bid, $id)) Flash::push('success', 'پشتیبان حذف شد.');
        else Flash::push('error', 'پشتیبان یافت نشد.');
        redirect('app/backups');
        return '';
    }

    /* ── بازگردانی از فایل ── */
    public function import(array $p): string
    {
        $bid = $this->bid(); csrf_verify();
        if (!Auth::can('backup.create')) { Flash::push('error', 'مجوز بازگردانی را ندارید.'); redirect('app/backups'); }
        $f = $_FILES['backup_file'] ?? null;
        if (!$f || (int)($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) { Flash::push('error', 'فایل پشتیبان را انتخاب کنید.'); redirect('app/backups'); }
        if ((int)$f['error'] !== UPLOAD_ERR_OK) { Flash::push('error', 'آپلود فایل ناموفق بود (کد ' . (int)$f['error'] . ').'); redirect('app/backups'); }
        if ((int)$f['size'] > 200 * 1024 * 1024) { Flash::push('error', 'حجم فایل پشتیبان بیش از ۲۰۰ مگابایت است.'); redirect('app/backups'); }
        $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['json', 'csv'], true)) { Flash::push('error', 'فقط فایل پشتیبان JSON یا CSV قابل بازگردانی است.'); redirect('app/backups'); }

        // ذخیرهٔ موقت برای خواندن
        $tmpDir = storage_path('backups/tmp');
        if (!is_dir($tmpDir)) @mkdir($tmpDir, 0775, true);
        $tmp = $tmpDir . '/upload-' . bin2hex(random_bytes(6)) . '.' . $ext;
        if (!@move_uploaded_file((string)$f['tmp_name'], $tmp)) { Flash::push('error', 'ذخیرهٔ موقت فایل ممکن نشد.'); redirect('app/backups'); }

        try {
            // اول یک پشتیبان ایمنی از وضعیت فعلی بگیر (اگر بازگردانی خراب بود، قابل بازگشت باشد)
            $safety = Backup::create($bid, Auth::id(), 'manual');

            $payload = Backup::read($tmp, $ext);
            $res = Backup::restore($bid, $payload);
            @unlink($tmp);
            Flash::push('success', 'بازگردانی انجام شد: ' . num($res['rows']) . ' ردیف از ' . num($res['tables'])
                . ' بخش. (پشتیبان ایمنی قبل از بازگردانی هم ذخیره شد.)');
        } catch (Throwable $e) {
            @unlink($tmp);
            Flash::push('error', 'بازگردانی ناموفق: ' . $e->getMessage());
        }
        redirect('app/backups');
        return '';
    }
}
