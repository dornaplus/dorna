<?php
/** کالاها و خدمات: فرم اختصاصی کالا با مالیات، قیمت و واحد */
final class CatalogController
{
    public function formCreate(array $m, array $p): string { return $this->form($m, []); }
    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM products WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$row) abort(404, 'کالا یافت نشد.');
        return $this->form($m, $row);
    }
    private function form(array $m, array $row): string
    {
        $cols = Schema::columns('products');
        $only = array_values(array_filter(['code','item_type','title','category_id','main_unit_id','base_unit_id','pack_factor','has_variants',
            'default_warehouse_id','accounting_account_id','cost_method','is_taxable','vat_rate_id','reorder_point','min_sale_qty',
            'allowed_discount_percent','show_in_online_store','description','status','is_active'], fn($c) => isset($cols[$c])));
        $groups = Fields::groups('products', ['only' => $only]);
        $taxes = Database::all('SELECT id FROM taxes WHERE business_id=? AND is_active=1', [Auth::businessId()]);
        $selectedTax = !empty($row['id']) ? Database::val('SELECT tax_id FROM product_taxes WHERE product_id=? LIMIT 1', [$row['id']]) : null;
        $prices = !empty($row['id']) ? Database::all('SELECT pp.*, pt.title_fa FROM product_prices pp JOIN price_types pt ON pt.id=pp.price_type_id WHERE pp.product_id=? ORDER BY pp.id', [$row['id']]) : [];
        $units = !empty($row['id']) ? Database::all('SELECT pu.*, u.title AS unit_title FROM product_units pu JOIN units u ON u.id=pu.unit_id WHERE pu.product_id=?', [$row['id']]) : [];
        return view('pages/catalog/form', ['m' => $m, 'groups' => $groups, 'row' => $row, 'selectedTax' => $selectedTax,
            'autoCodeNext' => empty($row['id']) ? $this->nextNumericCode((int)Auth::businessId(), true) : null,
            'prices' => $prices, 'units' => $units, 'priceTypes' => Database::all('SELECT * FROM price_types WHERE business_id=? AND is_active=1', [Auth::businessId()]),
            'action' => $row ? url('app/products/'.$row['id']) : url('app/products'), 'title' => $row ? 'ویرایش کالا / خدمت' : 'تعریف کالا / خدمت']);
    }

    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $biz = Auth::businessId();
        $title = (string)post('title');
        $itemType = (string)post('item_type', 'goods');
        if (mb_strlen($title) < 2) { Flash::keep($_POST); Flash::push('error', 'عنوان کالا/خدمت را وارد کنید.'); redirect($id ? 'app/products/'.$id.'/edit' : 'app/products/create'); }
        $data = [
            'business_id' => $biz, 'item_type' => $itemType, 'title' => $title,
            'category_id' => post('category_id') ? (int)post('category_id') : null,
            'main_unit_id' => post('main_unit_id') ? (int)post('main_unit_id') : null,
            'base_unit_id' => post('base_unit_id') ? (int)post('base_unit_id') : (post('main_unit_id') ? (int)post('main_unit_id') : null),
            'pack_factor' => (float)post('pack_factor', 1) ?: 1, 'has_variants' => post('has_variants') ? 1 : 0,
            'default_warehouse_id' => post('default_warehouse_id') ? (int)post('default_warehouse_id') : null,
            'accounting_account_id' => post('accounting_account_id') ? (int)post('accounting_account_id') : null,
            'cost_method' => (string)post('cost_method', 'fifo'), 'is_taxable' => post('is_taxable') ? 1 : 0,
            'vat_rate_id' => post('vat_rate_id') ? (int)post('vat_rate_id') : null,
            'reorder_point' => (float)post('reorder_point', 0), 'min_sale_qty' => (float)post('min_sale_qty', 1) ?: 1,
            'allowed_discount_percent' => (float)post('allowed_discount_percent', 0),
            'show_in_online_store' => post('show_in_online_store') ? 1 : 0,
            'description' => (string)post('description') ?: null, 'status' => (string)post('status', 'active'),
            'is_active' => post('is_active') ? 1 : 0,
        ];
        $autoCode = ((string)post('auto_code') === '1');
        $data['code'] = $autoCode ? $this->resolveAutoCode($biz)
            : ((string)post('code') ?: $this->nextCode($biz, $itemType));
        try {
            $pid = Database::transaction(function () use ($id, $data, $biz) {
                if ($id) {
                    $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                    Database::update('products', $data, 'id=:pk', ['pk' => $id]);
                    $pid = (int)$id;
                } else {
                    $data['created_at'] = now(); $data['created_by'] = Auth::id();
                    $pid = Database::insert('products', $data);
                }
                if ($data['main_unit_id']) {
                    $exists = Database::val('SELECT COUNT(*) FROM product_units WHERE product_id=? AND unit_id=?', [$pid, $data['main_unit_id']]);
                    if (!$exists) Database::insert('product_units', ['product_id' => $pid, 'unit_id' => $data['main_unit_id'], 'factor' => 1]);
                }
                // مالیات
                Database::run('DELETE FROM product_taxes WHERE product_id=?', [$pid]);
                if (!empty($_POST['tax_id'])) Database::insert('product_taxes', ['product_id' => $pid, 'tax_id' => (int)$_POST['tax_id']]);
                // قیمت‌های ارسالی
                foreach ((array)($_POST['price'] ?? []) as $ptId => $price) {
                    $price = (float)str_replace(',', '', (string)$price);
                    if ($price <= 0) continue;
                    $rowId = Database::val('SELECT id FROM product_prices WHERE product_id=? AND price_type_id=?', [$pid, (int)$ptId]);
                    if ($rowId) Database::run('UPDATE product_prices SET price=? WHERE id=?', [$price, $rowId]);
                    else Database::insert('product_prices', ['business_id' => $biz, 'product_id' => $pid, 'price_type_id' => (int)$ptId, 'price' => $price, 'currency_id' => base_currency_id($biz), 'from_date' => today(), 'created_at' => now(), 'created_by' => Auth::id()]);
                }
                return $pid;
            });
            Audit::log($id ? 'update' : 'create', 'products', $pid, ($id ? 'ویرایش' : 'ایجاد').' کالا '.$data['code']);
            Flash::push('success', 'کالا / خدمت ذخیره شد.');
            Flash::clearOld();
            redirect('app/products/'.$pid);
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', 'خطا در ذخیره کالا: '.$e->getMessage());
            redirect($id ? 'app/products/'.$id.'/edit' : 'app/products/create');
        }
        return '';
    }

    /**
     * کد ۴ رقمی خودکار: بزرگ‌ترین کد عددی موجود + ۱ (شروع از ۱۰۰۱).
     * با $advance=true در هر بار باز شدن فرم یک شمارهٔ تازه پیشنهاد می‌شود.
     */
    public function nextNumericCode(int $biz, bool $advance = false): string
    {
        // مبنای پیشنهاد: «آخرین کد کالایی که همین کسب‌وکار ثبت کرده» + ۱ (با حفظ پیشوند و تعداد ارقام)
        $last = (string)Database::val('SELECT code FROM products WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz], '');
        $cand = '';
        if ($last !== '' && preg_match('/^(.*?)([0-9]+)$/', $last, $m)) {
            $next = (string)((int)$m[2] + 1);
            if (strlen($m[2]) > 1 && strlen($next) < strlen($m[2])) $next = str_pad($next, strlen($m[2]), '0', STR_PAD_LEFT);
            $cand = $m[1] . $next;
        }
        if ($cand !== '' && !Database::val('SELECT COUNT(*) FROM products WHERE business_id=? AND code=?', [$biz, $cand])) return $cand;

        // پشتیبان: بزرگ‌ترین کد عددی موجود + ۱ (کمینه ۱۰۰۱ تا ۴ رقمی بماند)
        $max = (int)Database::val("SELECT MAX(CAST(code AS UNSIGNED)) FROM products WHERE business_id=? AND code REGEXP '^[0-9]+$'", [$biz], 0);
        $n = max(1001, $max + 1);
        while (Database::val('SELECT COUNT(*) FROM products WHERE business_id=? AND code=?', [$biz, (string)$n])) $n++;
        return (string)$n;
    }

    /** کد نهایی هنگام ثبت خودکار: همان مقدار نمایش‌داده‌شده، و اگر تکراری بود شمارهٔ آزاد بعدی */
    private function resolveAutoCode(int $biz): string
    {
        $posted = trim((string)post('code'));
        if ($posted !== '' && preg_match('/^[0-9]+$/', $posted)
            && !Database::val('SELECT COUNT(*) FROM products WHERE business_id=? AND code=?', [$biz, $posted])) {
            return $posted;
        }
        return $this->nextNumericCode($biz, false);
    }

    public function nextCode(int $biz, string $itemType = 'goods'): string
    {
        $prefix = $itemType === 'service' ? 'S' : 'P';
        $n = (int)Database::val('SELECT COUNT(*) FROM products WHERE business_id=?', [$biz], 0) + 1000;
        do { $code = $prefix.'-'.$n; $n++; } while (Database::val('SELECT COUNT(*) FROM products WHERE business_id=? AND code=?', [$biz, $code]));
        return $code;
    }
}
