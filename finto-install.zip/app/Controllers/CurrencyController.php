<?php
/** نرخ ارز — مدیریت نرخ‌های لحظه‌ای ارزهای خارجی */
final class CurrencyController
{
    private function guard(): void { Auth::requireApp(); if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی ندارید.'); }

    public function index(array $p): string
    {
        $this->guard();
        $biz = Auth::businessId();
        $currencies = Database::all('SELECT * FROM currencies WHERE is_active=1 ORDER BY is_base DESC, code');
        $today = today();
        $rows = [];
        foreach ($currencies as $c) {
            if ((int)$c['is_base'] === 1) continue;
            $last = Database::one('SELECT * FROM currency_rates WHERE business_id=? AND currency_id=? ORDER BY rate_date DESC, id DESC LIMIT 1', [$biz, $c['id']]);
            $rows[] = ['currency' => $c, 'rate' => $last];
        }
        return view('pages/settings/currency', ['title' => 'نرخ ارز', 'rows' => $rows, 'today' => $today]);
    }

    public function store(array $p): string
    {
        $this->guard(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش ندارید.');
        $biz = Auth::businessId();
        $today = today();
        $n = 0;
        foreach ((array)($_POST['currency_id'] ?? []) as $i => $cid) {
            $cid = (int)$cid;
            if (!$cid) continue;
            $buy = (float)str_replace(',', '', (string)($_POST['buy_rate'][$i] ?? '0'));
            $sell = (float)str_replace(',', '', (string)($_POST['sell_rate'][$i] ?? '0'));
            if ($buy <= 0 && $sell <= 0) continue;
            $avg = $buy > 0 && $sell > 0 ? round(($buy + $sell) / 2, 2) : ($buy > 0 ? $buy : $sell);
            Database::insert('currency_rates', [
                'business_id' => $biz, 'currency_id' => $cid, 'rate_date' => $today,
                'buy_rate' => $buy, 'sell_rate' => $sell, 'avg_rate' => $avg,
                'source' => 'manual', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            $n++;
        }
        Flash::push('success', $n > 0 ? num($n) . ' نرخ ثبت شد.' : 'نرخی وارد نشد.');
        redirect('app/settings/currency');
        return '';
    }
}
