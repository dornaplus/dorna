<?php
/**
 * پشتیبان‌گیری و بازگردانی فیدا — کنترلر.
 * همهٔ عملیات روی «کاربر جاری» انجام می‌شود؛ پشتیبان هر کاربر فقط برای خودش قابل دانلود/حذف/بازگردانی است.
 */
final class FidaBackupController
{
    private function uid(): int
    {
        if (!Auth::id()) redirect('fida/login');
        Fida::ensureProfile((int)Auth::id());
        return (int)Auth::id();
    }

    /* ── فهرست پشتیبان‌ها ── */
    public function index(array $p): string
    {
        $uid = $this->uid();
        $jobs = FidaBackup::jobs($uid);
        // اگر فایل یک پشتیبانِ موفق روی سرور نباشد، وضعیتش اصلاح شود
        foreach ($jobs as $j) {
            if ($j['status'] !== 'success' || empty($j['file_name'])) continue;
            $base = pathinfo((string)$j['file_name'], PATHINFO_FILENAME);
            if (!is_file(FidaBackup::dir($uid) . '/' . $base . '.json') && !is_file(FidaBackup::dir($uid) . '/' . $base . '.csv')) {
                Database::update('fida_backups', ['status' => 'failed', 'error_message' => 'فایل پشتیبان روی سرور موجود نیست.'], 'id=:pk', ['pk' => (int)$j['id']]);
                $j['status'] = 'failed';
            }
        }
        return view('pages/fida/backups', [
            'title'  => 'پشتیبان‌گیری و بازیابی',
            'jobs'   => FidaBackup::jobs($uid),
            'counts' => FidaBackup::counts($uid),
            'labels' => FidaBackup::labels(),
        ]);
    }

    /* ── ساخت پشتیبان ── */
    public function create(array $p): string
    {
        $uid = $this->uid(); csrf_verify();
        try {
            $job = FidaBackup::create($uid, 'manual');
            $n = (int)($job['row_count'] ?? 0);
            Flash::push('success', 'پشتیبان با موفقیت گرفته شد (' . num($n) . ' ردیف از ' . num(count(FidaBackup::tables())) . ' بخش).');
        } catch (Throwable $e) {
            Flash::push('error', 'پشتیبان‌گیری ناموفق: ' . $e->getMessage());
        }
        redirect('fida/backups');
        return '';
    }

    /* ── دانلود فایل پشتیبان (JSON یا CSV) ── */
    public function download(array $p): string
    {
        $uid = $this->uid();
        $job = FidaBackup::job($uid, (int)($p['id'] ?? 0));      // بررسی مالکیت
        if (!$job) { http_response_code(404); exit('پشتیبان یافت نشد.'); }
        $fmt = ($_GET['format'] ?? 'json') === 'csv' ? 'csv' : 'json';
        $base = pathinfo((string)$job['file_name'], PATHINFO_FILENAME);
        $file = FidaBackup::dir($uid) . '/' . $base . '.' . $fmt;
        if (!is_file($file)) {
            if (!is_file(FidaBackup::dir($uid) . '/' . $base . '.json') && !is_file(FidaBackup::dir($uid) . '/' . $base . '.csv')) {
                Database::update('fida_backups', ['status' => 'failed', 'error_message' => 'فایل پشتیبان روی سرور موجود نیست.'], 'id=:pk', ['pk' => (int)$job['id']]);
            }
            Flash::push('error', 'فایل ' . strtoupper($fmt) . ' این پشتیبان روی سرور موجود نیست. یک پشتیبان تازه بگیرید.');
            redirect('fida/backups');
        }
        $name = 'fida-backup-u' . $uid . '-' . substr($base, -15) . '.' . $fmt;
        if (headers_sent()) exit('خطا در ارسال فایل.');
        header('Content-Type: ' . ($fmt === 'csv' ? 'text/csv; charset=utf-8' : 'application/json; charset=utf-8'));
        header('Content-Disposition: attachment; filename="' . $name . '"');
        header('Content-Length: ' . filesize($file));
        header('Cache-Control: no-store');
        readfile($file);
        exit;
    }

    /* ── حذف پشتیبان ── */
    public function delete(array $p): string
    {
        $uid = $this->uid(); csrf_verify();
        if (FidaBackup::remove($uid, (int)($p['id'] ?? 0))) Flash::push('success', 'پشتیبان حذف شد.');
        else Flash::push('error', 'پشتیبان یافت نشد.');
        redirect('fida/backups');
        return '';
    }

    /* ── بازگردانی از فایل ── */
    public function import(array $p): string
    {
        $uid = $this->uid(); csrf_verify();
        $f = $_FILES['backup_file'] ?? null;
        if (!$f || (int)($f['error'] ?? 4) === UPLOAD_ERR_NO_FILE) { Flash::push('error', 'فایل پشتیبان را انتخاب کنید.'); redirect('fida/backups'); }
        if ((int)$f['error'] !== UPLOAD_ERR_OK) { Flash::push('error', 'آپلود فایل ناموفق بود (کد ' . (int)$f['error'] . ').'); redirect('fida/backups'); }
        if ((int)$f['size'] > 200 * 1024 * 1024) { Flash::push('error', 'حجم فایل پشتیبان بیش از ۲۰۰ مگابایت است.'); redirect('fida/backups'); }
        $ext = strtolower(pathinfo((string)$f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['json', 'csv'], true)) { Flash::push('error', 'فقط فایل پشتیبان JSON یا CSV قابل بازگردانی است.'); redirect('fida/backups'); }

        $tmpDir = storage_path('fida-backups/tmp');
        if (!is_dir($tmpDir)) @mkdir($tmpDir, 0775, true);
        $tmp = $tmpDir . '/upload-' . bin2hex(random_bytes(6)) . '.' . $ext;
        if (!@move_uploaded_file((string)$f['tmp_name'], $tmp)) { Flash::push('error', 'ذخیرهٔ موقت فایل ممکن نشد.'); redirect('fida/backups'); }

        try {
            // پشتیبان ایمنی از وضعیت فعلی (اگر بازگردانی خراب بود، قابل بازگشت باشد)
            FidaBackup::create($uid, 'manual');
            $payload = FidaBackup::read($tmp, $ext);
            $res = FidaBackup::restore($uid, $payload);
            @unlink($tmp);
            Flash::push('success', 'بازیابی انجام شد: ' . num($res['rows']) . ' ردیف از ' . num($res['tables'])
                . ' بخش. (پشتیبان ایمنی قبل از بازیابی هم ذخیره شد.)');
        } catch (Throwable $e) {
            @unlink($tmp);
            Flash::push('error', 'بازیابی ناموفق: ' . $e->getMessage());
        }
        redirect('fida/backups');
        return '';
    }
}
