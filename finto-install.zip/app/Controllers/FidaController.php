<?php
/** اپ فاکتورزنی فیدا — هر کاربر پروفایل و دادهٔ اختصاصی خودش را دارد (احراز هویت مشترک با فینتو) */
final class FidaController
{
    /** کد تایید تستی — فقط در حالت نمایشی (demo_mode) پذیرفته می‌شود */
    private const DEMO_OTP = '111111';

    public function dashboard(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $kpi = [
            'invoices' => (int)Database::val('SELECT COUNT(*) FROM fida_invoices WHERE user_id=?', [$u], 0),
            'month'    => (float)Database::val('SELECT IFNULL(SUM(final_amount),0) FROM fida_invoices WHERE user_id=? AND invoice_type="sale" AND YEAR(invoice_date)=YEAR(CURDATE()) AND MONTH(invoice_date)=MONTH(CURDATE())', [$u], 0),
            'persons'  => (int)Database::val('SELECT COUNT(*) FROM fida_persons WHERE user_id=?', [$u], 0),
            'items'    => (int)Database::val('SELECT COUNT(*) FROM fida_items WHERE user_id=? AND is_active=1', [$u], 0),
            'debt'     => (float)Database::val('SELECT IFNULL(SUM(final_amount - paid_amount),0) FROM fida_invoices WHERE user_id=? AND status="credit"', [$u], 0),
        ];
        $recent = Database::all('SELECT * FROM v_fida_invoices_full WHERE user_id=? ORDER BY id DESC LIMIT 8', [$u]);
        $months = Database::all('SELECT * FROM v_fida_sales_monthly WHERE user_id=? ORDER BY year DESC, month DESC LIMIT 6', [$u]);
        $chequeSum = Database::one(
            "SELECT
               IFNULL(SUM(CASE WHEN direction='received' AND status IN ('in_hand','deposited') THEN amount END),0) AS recv,
               IFNULL(SUM(CASE WHEN direction='issued'   AND status IN ('in_hand','deposited') THEN amount END),0) AS issued,
               IFNULL(SUM(CASE WHEN status IN ('in_hand','deposited') AND due_date <= DATE_ADD(CURDATE(), INTERVAL " . FidaNotice::WINDOW_DAYS . " DAY) THEN amount END),0) AS due_soon,
               IFNULL(SUM(CASE WHEN status IN ('in_hand','deposited') AND due_date <= DATE_ADD(CURDATE(), INTERVAL " . FidaNotice::WINDOW_DAYS . " DAY) THEN 1 END),0) AS due_count
             FROM fida_cheques WHERE user_id=?", [$u]) ?: ['recv'=>0,'issued'=>0,'due_soon'=>0,'due_count'=>0];
        $cheques = Database::all("SELECT * FROM v_fida_cheques_full WHERE user_id=? AND status IN ('in_hand','deposited') ORDER BY due_date ASC LIMIT 5", [$u]);
        $notices = array_slice(FidaNotice::feed($u), 0, 4);
        return view('pages/fida/dashboard', ['title' => 'داشبورد فاکتورزنی', 'kpi' => $kpi, 'recent' => $recent,
            'months' => array_reverse($months), 'chequeSum' => $chequeSum, 'cheques' => $cheques, 'notices' => $notices]);
    }

    public function invoices(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $q = trim((string)($_GET['q'] ?? ''));
        $type = (string)($_GET['type'] ?? '');
        $w = ['user_id = ?']; $par = [$u];
        if ($q !== '') { $w[] = '(invoice_code LIKE ? OR person_name LIKE ?)'; $par[] = "%$q%"; $par[] = "%$q%"; }
        if (in_array($type, ['sale','pre_invoice','purchase'], true)) { $w[] = 'invoice_type = ?'; $par[] = $type; }
        $where = ' WHERE ' . implode(' AND ', $w);
        $rows = Database::all("SELECT * FROM v_fida_invoices_full$where ORDER BY id DESC LIMIT 100", $par);
        return view('pages/fida/invoices', ['title' => 'فاکتورها', 'rows' => $rows, 'q' => $q, 'type' => $type]);
    }

    public function persons(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $rows = Database::all('SELECT * FROM v_fida_person_summary WHERE user_id=? ORDER BY total_amount DESC LIMIT 200', [$u]);
        return view('pages/fida/persons', ['title' => 'اشخاص (مشتریان/تأمین‌کنندگان)', 'rows' => $rows]);
    }

    public function items(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $rows = Database::all('SELECT * FROM fida_items WHERE user_id=? AND is_active=1 ORDER BY title LIMIT 300', [$u]);
        return view('pages/fida/items', ['title' => 'کالاها و خدمات', 'rows' => $rows]);
    }

    public function reports(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $daily = Database::all('SELECT * FROM v_fida_sales_daily WHERE user_id=? ORDER BY invoice_date DESC LIMIT 30', [$u]);
        $topItems = Database::all('SELECT * FROM v_fida_top_items WHERE user_id=? LIMIT 10', [$u]);
        $topPersons = Database::all('SELECT * FROM v_fida_top_persons WHERE user_id=? LIMIT 10', [$u]);
        $pay = Database::all('SELECT * FROM v_fida_payment_breakdown WHERE user_id=?', [$u]);
        return view('pages/fida/reports', ['title' => 'گزارش‌های فاکتورزنی', 'daily' => $daily, 'topItems' => $topItems, 'topPersons' => $topPersons, 'pay' => $pay]);
    }

    /* ── فرم ثبت فاکتور ── */
    public function invoiceCreate(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $type = in_array($_GET['type'] ?? '', ['sale','pre_invoice','purchase'], true) ? $_GET['type'] : 'sale';
        return view('pages/fida/invoice_form', [
            'title' => ['sale' => 'فاکتور فروش', 'pre_invoice' => 'پیش‌فاکتور', 'purchase' => 'فاکتور خرید'][$type],
            'type' => $type,
            'persons' => Database::all('SELECT id, full_name, phone FROM fida_persons WHERE user_id=? AND status="active" ORDER BY full_name LIMIT 500', [$u]),
            'items' => Database::all('SELECT id, title, unit, unit_price FROM fida_items WHERE user_id=? AND is_active=1 ORDER BY title LIMIT 500', [$u]),
            'units' => Fida::units($u),
            'settings' => Fida::settings(),
            'templates' => (function () use ($u) { $out = []; foreach (Database::all('SELECT id,name FROM fida_invoice_templates WHERE user_id=? ORDER BY id DESC LIMIT 60', [$u]) as $t) { $t['items'] = Database::all('SELECT item_title,unit,quantity,unit_price FROM fida_template_items WHERE template_id=? ORDER BY position', [$t['id']]); $out[] = $t; } return $out; })(),
        ]);
    }

    public function invoiceStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $type = in_array((string)post('invoice_type'), ['sale','pre_invoice','purchase'], true) ? (string)post('invoice_type') : 'sale';
        $back = 'fida/invoices/create?type=' . $type;
        // سهم رایگان (۵ فاکتور) — پس از آن باید اشتراک طلایی فعال باشد
        $st = Fida::accessState($u);
        if ($st['blocked']) {
            $m = Fida::upgradeMessages($st);
            Flash::push('error', $m['title'] . ' — ' . $m['sub']);
            redirect('fida/gold');
        }
        $personId = (int)post('person_id');
        if (!$personId || !Database::val('SELECT id FROM fida_persons WHERE id=? AND user_id=?', [$personId, $u])) { Flash::push('error', 'شخص را انتخاب کنید.'); redirect($back); }
        $pids = (array)($_POST['item_id'] ?? []); $qtys = (array)($_POST['quantity'] ?? []); $prices = (array)($_POST['unit_price'] ?? []);
        $units = (array)($_POST['unit'] ?? []);
        $rows = []; $total = 0;
        foreach ($pids as $i => $pid) {
            $q = fa_num($qtys[$i] ?? 0); $pr = fa_num($prices[$i] ?? 0);
            if ($pid === '' || $q <= 0) continue;
            $it = Database::one('SELECT title, unit FROM fida_items WHERE id=? AND user_id=?', [(int)$pid, $u]);
            if (!$it) continue;
            // واحدِ واردشده در فرم مقدم است؛ در غیر این صورت واحدِ خودِ کالا
            $rowUnit = trim((string)($units[$i] ?? ''));
            if ($rowUnit === '') $rowUnit = (string)$it['unit'];
            $rowUnit = mb_substr($rowUnit, 0, 30) ?: 'عدد';
            $tp = (int)round($q * $pr); $total += $tp;
            $rows[] = ['item_id' => (int)$pid, 'item_title' => $it['title'], 'unit' => $rowUnit, 'quantity' => $q, 'unit_price' => (int)$pr, 'total_price' => $tp, 'position' => $i + 1];
        }
        if (!$rows) { Flash::push('error', 'حداقل یک قلم کالا/خدمت اضافه کنید.'); redirect($back); }
        // ── تنظیمات کاربر تعیین می‌کند کدام بخش‌ها فعال‌اند (اگر خاموش باشد مقدار صفر می‌شود)
        $fs = Fida::settings();
        // ── تخفیف: بر اساس «حالت تخفیف» تنظیمات (درصدی = درصدِ جمع اقلام)
        // حالت تخفیف فقط وقتی صریحاً ارسال شود اعمال می‌شود؛ در غیر این صورت مقدار «مبلغی» است (سازگاری با ورودی‌های قدیمی)
        $dmode = post('discount_mode') === 'percent' ? 'percent' : 'amount';
        $discRaw = post('discount_value') !== null ? post('discount_value') : post('discount_amount');
        $discVal = max(0, (float)fa_num((string)$discRaw));
        $disc = !empty($fs['show_discount'])
            ? ($dmode === 'percent' ? (int)round($total * min(100.0, $discVal) / 100) : (int)round($discVal))
            : 0;
        $ship = !empty($fs['show_ship']) ? max(0, (int)fa_num((string)post('ship_amount'))) : 0;
        $adv  = !empty($fs['show_advance']) ? max(0, (int)fa_num((string)post('advance_amount'))) : 0;
        $prev = !empty($fs['show_previous_debt']) ? max(0, (int)fa_num((string)post('previous_debt_amount'))) : 0;
        // ── مالیات: درصدی یا مبلغی (پایه = اقلام − تخفیف + ارسال)
        $taxBase = max(0, $total - $disc + $ship);
        $taxMode = !empty($fs['show_tax']) && post('tax_mode') === 'percent' ? 'percent' : 'amount';
        $taxVal  = !empty($fs['show_tax']) ? max(0, (float)fa_num((string)post('tax_value'))) : 0;
        if ($taxMode === 'percent') { $taxPct = min(100.0, $taxVal); $taxAmt = (int)round($taxBase * $taxPct / 100); }
        else { $taxPct = 0.0; $taxAmt = (int)round($taxVal); }
        // بدهی قبلی به مبلغ قابل پرداخت اضافه می‌شود
        $final = max(0, $taxBase + $taxAmt + $prev);
        $pm = in_array((string)post('pay_method'), ['cash','card','credit','transfer'], true) ? (string)post('pay_method') : 'credit';
        $paid = min($adv, $final);
        $status = $type === 'pre_invoice' ? 'pending' : ($paid >= $final ? 'paid' : 'credit');
        $year = current_jalali_year();
        $prefix = ['sale' => 'INV', 'pre_invoice' => 'PRE', 'purchase' => 'BUY'][$type];
        $seq = (int)Database::val('SELECT IFNULL(MAX(seq),0)+1 FROM fida_invoices WHERE user_id=? AND invoice_type=? AND invoice_year=?', [$u, $type, $year], 1);
        while (Database::val('SELECT id FROM fida_invoices WHERE user_id=? AND invoice_type=? AND invoice_year=? AND seq=?', [$u, $type, $year, $seq])) $seq++;
        $code = $prefix . '-' . $year . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
        [$jy, $jm, $jd] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
        $jal = sprintf('%04d/%02d/%02d', $jy, $jm, $jd);
        $due = to_gregorian((string)post('due_date'));
        $dueJal = $due ? (function($d){ [$y,$m,$dd]=gregorian_to_jalali((int)date('Y',strtotime($d)),(int)date('n',strtotime($d)),(int)date('j',strtotime($d))); return sprintf('%04d/%02d/%02d',$y,$m,$dd); })($due) : null;
        $id = Database::transaction(function () use ($u, $type, $code, $seq, $year, $jm, $personId, $status, $pm, $due, $dueJal, $prev, $adv, $total, $disc, $ship, $taxMode, $taxPct, $taxAmt, $final, $paid, $rows, $jal) {
            $id = Database::insert('fida_invoices', [
                'user_id' => $u, 'invoice_type' => $type, 'invoice_code' => $code, 'seq' => $seq, 'invoice_year' => $year, 'invoice_month' => $jm,
                'invoice_date' => today(), 'invoice_jalali' => $jal, 'person_id' => $personId, 'status' => $status, 'pay_method' => $pm,
                'due_date' => $due, 'due_jalali' => $dueJal, 'previous_debt_amount' => $prev, 'advance_amount' => $adv,
                'total_amount' => $total, 'discount_amount' => $disc, 'ship_amount' => $ship,
                'tax_mode' => $taxMode, 'tax_percent' => $taxPct, 'tax_amount' => $taxAmt,
                'final_amount' => $final, 'paid_amount' => $paid,
                'notes' => mb_substr((string)post('notes'), 0, 255) ?: null, 'created_at' => now(),
            ]);
            foreach ($rows as $r) { $r['invoice_id'] = $id; $r['user_id'] = $u; Database::insert('fida_invoice_items', $r); }
            if ($paid > 0) Database::insert('fida_payments', ['user_id' => $u, 'invoice_id' => $id, 'person_id' => $personId, 'amount' => $paid, 'pay_method' => in_array($pm, ['cash','card','transfer'], true) ? $pm : 'cash', 'reference_code' => 'AUTO-' . $code, 'paid_at' => today(), 'paid_jalali' => $jal, 'note' => 'پرداخت هنگام صدور', 'created_at' => now()]);
            Database::insert('fida_invoice_status_history', ['user_id' => $u, 'invoice_id' => $id, 'old_status' => null, 'new_status' => $status, 'changed_at' => now(), 'note' => 'صدور فاکتور']);
            return $id;
        });
        Flash::push('success', 'فاکتور ' . $code . ' ثبت شد.');
        redirect('fida/invoices/' . $id);
    }

    public function invoiceShow(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $inv = Database::one('SELECT * FROM v_fida_invoices_full WHERE id=? AND user_id=?', [(int)$p['id'], $u]);
        if (!$inv) abort(404, 'فاکتور یافت نشد.');
        $items = Database::all('SELECT * FROM fida_invoice_items WHERE invoice_id=? ORDER BY position', [$inv['id']]);
        $pays = Database::all('SELECT * FROM fida_payments WHERE invoice_id=? ORDER BY id DESC', [$inv['id']]);
        $hist = Database::all('SELECT * FROM fida_invoice_status_history WHERE invoice_id=? ORDER BY id DESC', [$inv['id']]);
        $cheques = Database::all('SELECT * FROM fida_cheques WHERE user_id=? AND invoice_id=? ORDER BY id DESC', [$u, $inv['id']]);
        return view('pages/fida/invoice_show', ['title' => 'فاکتور ' . $inv['invoice_code'], 'inv' => $inv, 'items' => $items, 'pays' => $pays, 'hist' => $hist, 'cheques' => $cheques]);
    }

    /* ── اشخاص: فرم/ذخیره ── */
    public function personForm(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $id = (int)($p['id'] ?? 0);
        $row = $id ? Database::one('SELECT * FROM fida_persons WHERE id=? AND user_id=?', [$id, $u]) : [];
        if ($id && !$row) abort(404, 'شخص یافت نشد.');
        return view('pages/fida/person_form', ['title' => $id ? 'ویرایش شخص' : 'شخص جدید', 'row' => $row ?: []]);
    }
    public function personStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)post('id');
        $name = trim((string)post('full_name'));
        $phone = preg_replace('/[^0-9+]/', '', (string)post('phone'));
        if (mb_strlen($name) < 3) { Flash::push('error', 'نام شخص را کامل وارد کنید.'); redirect($id ? 'fida/persons/'.$id.'/edit' : 'fida/persons/create'); }
        // هر شماره فقط یک‌بار برای هر کاربر (جلوگیری از خطای کلید یگانه)
        if ($phone !== '') {
            $dup = (int)Database::val('SELECT id FROM fida_persons WHERE user_id=? AND phone=? AND id<>?', [$u, $phone, $id], 0);
            if ($dup) { Flash::push('error', 'شخصی با شمارهٔ «' . $phone . '» قبلاً ثبت شده است.'); redirect($id ? 'fida/persons/'.$id.'/edit' : 'fida/persons/create'); }
        }
        $kh = in_array(post('person_kind'), ['individual','company'], true) ? post('person_kind') : 'individual';
        $ty = in_array(post('person_type'), ['customer','supplier','partner'], true) ? post('person_type') : 'customer';
        $st = post('status') === 'inactive' ? 'inactive' : 'active';
        $g = to_gregorian((string)post('registered_at')) ?: today();
        [$jy,$jm,$jd] = gregorian_to_jalali((int)date('Y',strtotime($g)),(int)date('n',strtotime($g)),(int)date('j',strtotime($g)));
        $data = ['full_name'=>$name, 'phone'=>$phone, 'person_type'=>$ty, 'person_kind'=>$kh, 'city'=>mb_substr((string)post('city'),0,100) ?: null,
                 'role'=>mb_substr((string)post('role'),0,100) ?: null, 'address'=>mb_substr((string)post('address'),0,255) ?: null,
                 'note'=>mb_substr((string)post('note'),0,255) ?: null, 'status'=>$st, 'registered_at'=>$g, 'registered_jalali'=>sprintf('%04d/%02d/%02d',$jy,$jm,$jd)];
        if ($id && Database::val('SELECT id FROM fida_persons WHERE id=? AND user_id=?', [$id, $u])) {
            Database::update('fida_persons', $data, 'id=:pk AND user_id=:uid', ['pk'=>$id, 'uid'=>$u]); Flash::push('success','شخص ویرایش شد.');
        } else {
            $id = Database::insert('fida_persons', [
                'user_id' => $u, 'full_name' => $name, 'phone' => $phone, 'person_type' => $ty, 'person_kind' => $kh,
                'city' => mb_substr((string)post('city'), 0, 100) ?: null,
                'role' => mb_substr((string)post('role'), 0, 100) ?: null,
                'address' => mb_substr((string)post('address'), 0, 255) ?: null,
                'note' => mb_substr((string)post('note'), 0, 255) ?: null,
                'status' => $st, 'registered_at' => $g, 'registered_jalali' => sprintf('%04d/%02d/%02d', $jy, $jm, $jd),
                'created_at' => now(),
            ]);
            Flash::push('success', 'شخص ثبت شد.');
        }
        redirect('fida/persons');
    }

    /* ── کالا/خدمت: فرم/ذخیره ── */
    public function itemForm(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $id = (int)($p['id'] ?? 0);
        $row = $id ? Database::one('SELECT * FROM fida_items WHERE id=? AND user_id=?', [$id, $u]) : [];
        if ($id && !$row) abort(404, 'کالا یافت نشد.');
        return view('pages/fida/item_form', ['title' => $id ? 'ویرایش کالا/خدمت' : 'کالا/خدمت جدید', 'row' => $row ?: []]);
    }
    public function itemStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)post('id');
        $title = trim((string)post('title'));
        if (mb_strlen($title) < 2) { Flash::push('error','عنوان را وارد کنید.'); redirect($id ? 'fida/items/'.$id.'/edit' : 'fida/items/create'); }
        $data = ['kind'=> post('kind')==='service'?'service':'supply', 'title'=>mb_substr($title,0,150),
                 'unit'=>mb_substr((string)(post('unit') ?: 'عدد'),0,30), 'unit_price'=>(int)fa_num((string)post('unit_price')),
                 'is_active'=> post('is_active')==='0'?0:1];
        if ($id && Database::val('SELECT id FROM fida_items WHERE id=? AND user_id=?', [$id, $u])) {
            Database::update('fida_items', $data, 'id=:pk AND user_id=:uid', ['pk'=>$id, 'uid'=>$u]); Flash::push('success','ذخیره شد.');
        } else {
            $id = Database::insert('fida_items', [
                'user_id' => $u,
                'kind' => post('kind') === 'service' ? 'service' : 'supply',
                'title' => mb_substr($title, 0, 150),
                'unit' => mb_substr((string)(post('unit') ?: 'عدد'), 0, 30),
                'unit_price' => (int)fa_num((string)post('unit_price')),
                'is_active' => post('is_active') === '0' ? 0 : 1,
                'created_at' => now(),
            ]);
            Flash::push('success', 'کالا/خدمت ثبت شد.');
        }
        redirect('fida/items');
    }

    /* ── ثبت پرداخت روی فاکتور ── */
    public function paymentStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $iid = (int)post('invoice_id');
        $inv = Database::one('SELECT * FROM fida_invoices WHERE id=? AND user_id=?', [$iid, $u]);
        if (!$inv) { Flash::push('error', 'فاکتور یافت نشد.'); redirect('fida/invoices'); }
        $amt = (int)fa_num((string)post('amount'));
        if ($amt <= 0) { Flash::push('error', 'مبلغ پرداخت نامعتبر است.'); redirect('fida/invoices/' . $iid); }
        // کنترل بیش‌پرداخت: ماندهٔ فاکتور نباید منفی شود
        $balance = (int)$inv['final_amount'] - (int)$inv['paid_amount'];
        if ($balance <= 0) { Flash::push('info', 'این فاکتور ماندهٔ قابل پرداخت ندارد.'); redirect('fida/invoices/' . $iid); }
        if ($amt > $balance) { Flash::push('error', 'مبلغ پرداخت از ماندهٔ فاکتور (' . num($balance) . ' تومان) بیشتر است.'); redirect('fida/invoices/' . $iid); }
        $pm = in_array((string)post('pay_method'), ['cash','card','transfer','check'], true) ? (string)post('pay_method') : 'cash';
        $g = to_gregorian((string)post('paid_at')) ?: today();
        [$jy,$jm,$jd] = gregorian_to_jalali((int)date('Y',strtotime($g)),(int)date('n',strtotime($g)),(int)date('j',strtotime($g)));
        $jal = sprintf('%04d/%02d/%02d',$jy,$jm,$jd);
        Database::transaction(function () use ($u, $inv, $iid, $amt, $pm, $g, $jal) {
            Database::insert('fida_payments', ['user_id'=>$u, 'invoice_id'=>$iid, 'person_id'=>(int)$inv['person_id'], 'amount'=>$amt, 'pay_method'=>$pm,
                'reference_code'=>'PAY-'.$iid.'-'.bin2hex(random_bytes(3)), 'paid_at'=>$g, 'paid_jalali'=>$jal,
                'note'=>mb_substr((string)post('note'),0,200) ?: null, 'created_at'=>now()]);
            $paid = (int)$inv['paid_amount'] + $amt; $final = (int)$inv['final_amount'];
            $status = $paid >= $final ? 'paid' : ($inv['status'] === 'pending' ? 'pending' : 'credit');
            Database::update('fida_invoices', ['paid_amount'=>$paid, 'status'=>$status], 'id=:pk AND user_id=:uid', ['pk'=>$iid, 'uid'=>$u]);
            if ($status !== $inv['status']) Database::insert('fida_invoice_status_history', ['user_id'=>$u, 'invoice_id'=>$iid, 'old_status'=>$inv['status'], 'new_status'=>$status, 'changed_at'=>now(), 'note'=>'ثبت پرداخت']);
        });
        /* اگر پرداخت با چک انجام شده و شمارهٔ چک داده شده، چک هم ثبت می‌شود */
        if ($pm === 'check') {
            $cno = trim((string)post('cheque_no'));
            $cdue = to_gregorian((string)post('cheque_due'));
            if (mb_strlen($cno) >= 2) {
                $dir = ((string)($inv['invoice_type'] ?? '')) === 'purchase' ? 'issued' : 'received';
                Database::insert('fida_cheques', [
                    'user_id' => $u, 'direction' => $dir, 'cheque_no' => mb_substr($cno, 0, 30),
                    'bank_name' => mb_substr((string)post('cheque_bank'), 0, 80) ?: null,
                    'amount' => $amt, 'person_id' => (int)$inv['person_id'],
                    'issue_date' => $g, 'issue_jalali' => $jal,
                    'due_date' => $cdue ?: $g, 'due_jalali' => $this->jal($cdue ?: $g),
                    'status' => 'in_hand', 'invoice_id' => $iid,
                    'note' => 'ثبت‌شده از پرداخت فاکتور ' . $inv['invoice_code'], 'created_at' => now(),
                ]);
                Flash::push('info', 'چک ' . $cno . ' نیز در بخش چک‌ها ثبت شد.');
            }
        }
        Flash::push('success', 'پرداخت ثبت شد.');
        redirect('fida/invoices/' . $iid);
    }

    /* ── تغییر وضعیت فاکتور ── */
    public function invoiceStatus(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $iid = (int)post('invoice_id');
        $inv = Database::one('SELECT * FROM fida_invoices WHERE id=? AND user_id=?', [$iid, $u]);
        if (!$inv) { Flash::push('error', 'فاکتور یافت نشد.'); redirect('fida/invoices'); }
        $st = in_array((string)post('status'), ['paid','credit','pending','converted','closed'], true) ? (string)post('status') : $inv['status'];
        if ($st !== $inv['status']) {
            Database::update('fida_invoices', ['status'=>$st], 'id=:pk AND user_id=:uid', ['pk'=>$iid, 'uid'=>$u]);
            Database::insert('fida_invoice_status_history', ['user_id'=>$u, 'invoice_id'=>$iid, 'old_status'=>$inv['status'], 'new_status'=>$st, 'changed_at'=>now(), 'note'=>'تغییر دستی وضعیت']);
            Flash::push('success', 'وضعیت به‌روزرسانی شد.');
        }
        redirect('fida/invoices/' . $iid);
    }

    /* ── تنظیمات اپ (پروفایل اختصاصی کاربر) ── */
    public function settings(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        if (is_post()) {
            csrf_verify();
            $in = function ($k, array $allowed, $def) { $v = (string)post($k); return in_array($v, $allowed, true) ? $v : $def; };
            $d = [
                'owner_name' => mb_substr((string)(post('owner_name') ?: 'مدیر'), 0, 120),
                'shop_name' => mb_substr((string)(post('shop_name') ?: 'فروشگاه من'), 0, 150),
                'shop_address' => mb_substr((string)post('shop_address'), 0, 255) ?: null,
                'shop_phone' => mb_substr((string)post('shop_phone'), 0, 40) ?: null,
                'header_title' => mb_substr((string)post('header_title'), 0, 120) ?: null,
                'header_description' => mb_substr((string)post('header_description'), 0, 200) ?: null,
                'accent_color' => $in('accent_color', ['purple','blue','green','red'], 'purple'),
                'currency' => $in('currency', ['toman','rial'], 'toman'),
                'discount_mode' => $in('discount_mode', ['percent','amount'], 'percent'),
                'show_ship' => post('show_ship') ? 1 : 0, 'show_discount' => post('show_discount') ? 1 : 0,
                'show_advance' => post('show_advance') ? 1 : 0, 'show_previous_debt' => post('show_previous_debt') ? 1 : 0,
                'show_types' => post('show_types') ? 1 : 0,
                'show_bank_info' => post('show_bank_info') ? 1 : 0,
                'show_tax' => post('show_tax') ? 1 : 0,
                'tax_percent' => min(100.0, max(0.0, (float)fa_num((string)post('tax_percent')))),
                'updated_at' => now(),
            ];
            Fida::ensureProfile($u);
            $cur = Database::one('SELECT * FROM fida_settings WHERE user_id=?', [$u]) ?: [];

            // ── تصاویر: لوگو · مهر · امضا (حذف درخواستی، سپس آپلود تازه)
            $imgs = ['logo' => ['logo_path', 'لوگو'], 'stamp' => ['stamp_path', 'مهر'], 'signature' => ['signature_path', 'امضا']];
            foreach ($imgs as $f => [$col, $fa]) {
                if (post('delete_' . $f)) {
                    Fida::removeUpload($cur[$col] ?? null);
                    $d[$col] = null;
                    Flash::push('info', $fa . ' حذف شد و از چاپ/PDF هم برداشته می‌شود.');
                }
            }
            foreach ($imgs as $f => [$col, $fa]) {
                $up = Fida::saveUpload($f . '_file', $u, $f);
                if (!empty($up['error'])) Flash::push('error', $fa . ': ' . $up['error']);
                elseif (!empty($up['ok'])) {
                    Fida::removeUpload($cur[$col] ?? null);   // فایل قبلی پاک شود
                    $d[$col] = $up['path'];
                    Flash::push('success', $fa . ' بارگذاری شد.');
                }
            }

            Database::update('fida_settings', $d, 'user_id=:uid', ['uid' => $u]);
            Flash::push('success', 'تنظیمات اپ ذخیره شد.');
            redirect('fida/settings');
        }
        return view('pages/fida/settings', ['title' => 'تنظیمات اپ فاکتورزنی', 's' => Fida::settings(),
            'banks' => Fida::bankAccounts(), 'defaultBankId' => (int)(Fida::defaultBank()['id'] ?? 0)]);
    }

    /* ── حساب‌های بانکی (چاپ و PDF) ── */
    public function bankAccountStore(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            Fida::saveBankAccount([
                'id'             => (int)post('id'),
                'bank_name'      => (string)post('bank_name'),
                'account_holder' => (string)post('account_holder'),
                'card_no'        => (string)post('card_no'),
                'iban'           => (string)post('iban'),
                'account_no'     => (string)post('account_no'),
                'sort_order'     => (int)fa_num((string)post('sort_order', '0')),
            ]);
            Flash::push('success', 'حساب بانکی ذخیره شد.');
        } catch (Throwable $e) {
            Flash::push('error', $e->getMessage());
        }
        redirect('fida/settings');
        return '';
    }

    public function bankAccountDefault(array $p): string
    {
        $this->guard(); csrf_verify();
        if (Fida::setDefaultBank((int)($p['id'] ?? 0))) Flash::push('success', 'حساب پیش‌فرض برای چاپ و PDF تعیین شد.');
        else Flash::push('error', 'حساب بانکی یافت نشد.');
        redirect('fida/settings');
        return '';
    }

    public function bankAccountDelete(array $p): string
    {
        $this->guard(); csrf_verify();
        if (Fida::deleteBankAccount((int)($p['id'] ?? 0))) Flash::push('success', 'حساب بانکی حذف شد.');
        else Flash::push('error', 'حساب بانکی یافت نشد.');
        redirect('fida/settings');
        return '';
    }

    /* ── قالب‌های فاکتور ── */
    public function templates(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $rows = Database::all('SELECT t.*, (SELECT COUNT(*) FROM fida_template_items i WHERE i.template_id=t.id) AS items_count FROM fida_invoice_templates t WHERE t.user_id=? ORDER BY t.id DESC', [$u]);
        return view('pages/fida/templates', ['title' => 'قالب‌های فاکتور', 'rows' => $rows]);
    }
    public function templateStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $name = trim((string)post('name'));
        if (mb_strlen($name) < 2) { Flash::push('error', 'نام قالب را وارد کنید.'); redirect('fida/templates'); }
        $tid = Database::transaction(function () use ($u, $name) {
            $id = Database::insert('fida_invoice_templates', ['user_id'=>$u, 'name'=>mb_substr($name,0,120), 'description'=>mb_substr((string)post('description'),0,200) ?: null, 'icon'=>mb_substr((string)post('icon'),0,40) ?: null, 'usage_count'=>0, 'created_at'=>now()]);
            $pids = (array)($_POST['t_item_id'] ?? []); $qtys = (array)($_POST['t_quantity'] ?? []); $prices = (array)($_POST['t_unit_price'] ?? []); $pos = 1;
            foreach ($pids as $i => $pid) {
                if ($pid === '') continue;
                $it = Database::one('SELECT title, unit FROM fida_items WHERE id=? AND user_id=?', [(int)$pid, $u]); if (!$it) continue;
                $q = fa_num($qtys[$i] ?? 0); $pr = fa_num($prices[$i] ?? 0);
                if ($q <= 0) continue;
                Database::insert('fida_template_items', ['user_id'=>$u, 'template_id'=>$id, 'item_title'=>$it['title'], 'unit'=>$it['unit'], 'quantity'=>$q, 'unit_price'=>(int)$pr, 'total_price'=>(int)round($q*$pr), 'position'=>$pos++]);
            }
            return $id;
        });
        Flash::push('success', 'قالب فاکتور ثبت شد.');
        redirect('fida/templates');
    }

    /* ── تقویم شخصی ── */
    public function calendar(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        [$jy, $jm, $jd] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
        $jy = (int)($_GET['y'] ?? $jy); $jm = (int)($_GET['m'] ?? $jm);
        if ($jm < 1) { $jm = 12; $jy--; } if ($jm > 12) { $jm = 1; $jy++; }
        $sel = trim((string)($_GET['d'] ?? ''));
        $selGreg = $sel !== '' ? (to_gregorian($sel) ?: today()) : today();
        return view('pages/fida/calendar', [
            'title' => 'تقویم من', 'jy' => $jy, 'jm' => $jm, 'sel' => $selGreg,
            'grid' => Fida::calendarGrid($jy, $jm, $u),
            'dayEvents' => Fida::eventsOn($u, $selGreg),
            'upcoming' => Fida::upcomingEvents($u, 8, 60),
            'monthCount' => count(Fida::eventsBetween($u, (string)to_gregorian($jy . '/' . $jm . '/1'),
                date('Y-m-d', strtotime((string)to_gregorian($jy . '/' . $jm . '/' . Fida::jalaliMonthDays($jy, $jm)))))),
            'todayEvents' => Fida::eventsOn($u, today()),
        ]);
    }

    public function eventStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)post('id');
        $back = 'fida/calendar?y=' . (int)post('back_y') . '&m=' . (int)post('back_m') . '&d=' . urlencode((string)post('event_date'));
        try {
            $rawDate = trim((string)post('event_date'));
            $g = $rawDate !== '' ? (string)to_gregorian($rawDate) : '';
            if ($g === '') throw new RuntimeException('تاریخ رویداد را انتخاب کنید.');
            Fida::saveEvent($u, [
                'title' => (string)post('title'), 'event_date' => $g, 'event_time' => (string)post('event_time'),
                'kind' => (string)post('kind', 'reminder'), 'priority' => (string)post('priority', 'normal'),
                'note' => (string)post('note'), 'notify_days' => (int)post('notify_days', 0), 'is_done' => post('is_done') ? 1 : 0,
            ], $id ?: null);
            Flash::push('success', $id ? 'رویداد ویرایش شد.' : 'رویداد به تقویم اضافه شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect($back);
        return '';
    }

    public function eventDelete(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $e = Fida::event($u, (int)($p['id'] ?? 0));
        Fida::deleteEvent($u, (int)($p['id'] ?? 0));
        Flash::push('success', 'رویداد حذف شد.');
        redirect('fida/calendar?y=' . (int)post('back_y') . '&m=' . (int)post('back_m') . ($e ? '&d=' . urlencode(jdate((string)$e['event_date'])) : ''));
        return '';
    }

    public function eventToggle(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        Fida::toggleEvent($u, (int)($p['id'] ?? 0));
        redirect('fida/calendar?y=' . (int)post('back_y') . '&m=' . (int)post('back_m') . '&d=' . urlencode((string)post('back_d')));
        return '';
    }

    /* ── اشتراک طلایی ── */
    public function gold(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $disc = $this->currentDiscount();
        $plans = Database::all('SELECT * FROM fida_gold_plans WHERE is_active=1 ORDER BY duration_months');
        foreach ($plans as &$pl) $pl += $this->priceWithDiscount((int)$pl['price'], $disc);
        unset($pl);
        $purchases = [];
        try { $purchases = Database::all('SELECT * FROM fida_gold_purchases WHERE user_id=? ORDER BY id DESC LIMIT 5', [$u]); } catch (Throwable $e) {}
        // آدرس مطلق بازگشت از اپلیکیشن کافه‌بازار (باید با http/https شروع شود)
        $__scheme = ((!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')) ? 'https' : 'http';
        $__host = (string)($_SERVER['HTTP_HOST'] ?? '');
        $__absGold = $__host !== '' ? $__scheme . '://' . $__host . url('fida/gold') : url('fida/gold');
        return view('pages/fida/gold', ['title' => 'اشتراک طلایی فیدا',
            'plans' => $plans, 'discount' => $disc,
            'codes' => Database::all('SELECT code,title,discount_mode,discount_value FROM fida_discount_codes WHERE is_active=1 ORDER BY id LIMIT 3'),
            'subs' => Database::all('SELECT * FROM fida_subscriptions WHERE user_id=? ORDER BY id DESC LIMIT 10', [$u]),
            'purchases' => $purchases, 'return_url' => $__absGold,
            'bazaar' => [
                'enabled' => Bazaar::enabled(), 'ready' => Bazaar::ready(), 'sandbox' => Bazaar::sandbox(),
                'package' => Bazaar::package(),
            ]]);
    }

    /** کد تخفیف فعالِ نشست کاربر (اگر معتبر باشد) */
    private function currentDiscount(): ?array
    {
        $code = strtoupper(trim((string)($_SESSION['fida_discount_code'] ?? '')));
        if ($code === '') return null;
        $row = Database::one('SELECT * FROM fida_discount_codes WHERE code=? AND is_active=1', [$code]);
        if (!$row) { unset($_SESSION['fida_discount_code']); return null; }
        if (!empty($row['expires_at']) && (string)$row['expires_at'] < today()) { unset($_SESSION['fida_discount_code']); return null; }
        if ((int)$row['max_uses'] > 0 && (int)$row['used_count'] >= (int)$row['max_uses']) { unset($_SESSION['fida_discount_code']); return null; }
        return $row;
    }

    /** محاسبهٔ قیمت نهایی با کد تخفیف */
    private function priceWithDiscount(int $price, ?array $disc): array
    {
        if (!$disc) return ['discount_amount' => 0, 'final_price' => $price, 'discount_label' => ''];
        $mode = (string)$disc['discount_mode'];
        $val = (int)$disc['discount_value'];
        $amount = $mode === 'percent' ? (int)round($price * $val / 100) : min($price, $val);
        $amount = max(0, min($price, $amount));
        return ['discount_amount' => $amount, 'final_price' => max(0, $price - $amount),
            'discount_label' => $mode === 'percent' ? num($val) . '٪ تخفیف' : num($val) . ' تومان تخفیف'];
    }

    /** اعمال کد تخفیف */
    public function discountApply(array $p): string
    {
        $this->guard(); csrf_verify();
        $code = strtoupper(trim((string)post('discount_code')));
        if ($code === '') { Flash::push('error', 'کد تخفیف را وارد کنید.'); redirect('fida/gold'); }
        $row = Database::one('SELECT * FROM fida_discount_codes WHERE code=? AND is_active=1', [$code]);
        if (!$row) Flash::push('error', 'کد تخفیف «' . $code . '» معتبر نیست.');
        elseif (!empty($row['expires_at']) && (string)$row['expires_at'] < today()) Flash::push('error', 'این کد تخفیف منقضی شده است.');
        elseif ((int)$row['max_uses'] > 0 && (int)$row['used_count'] >= (int)$row['max_uses']) Flash::push('error', 'ظرفیت این کد تخفیف تکمیل شده است.');
        else {
            $_SESSION['fida_discount_code'] = $code;
            $label = (string)$row['discount_mode'] === 'percent' ? num((int)$row['discount_value']) . '٪' : num((int)$row['discount_value']) . ' تومان';
            Flash::push('success', 'کد تخفیف «' . $code . '» اعمال شد (' . $label . ' تخفیف) و در خرید اشتراک محاسبه می‌شود.');
        }
        redirect('fida/gold');
    }

    /** برداشتن کد تخفیف */
    public function discountRemove(array $p): string
    {
        $this->guard(); csrf_verify();
        unset($_SESSION['fida_discount_code']);
        Flash::push('success', 'کد تخفیف برداشته شد.');
        redirect('fida/gold');
    }

    public function goldSubscribe(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $plan = Database::one('SELECT * FROM fida_gold_plans WHERE id=? AND is_active=1', [(int)post('plan_id')]);
        if (!$plan) { Flash::push('error', 'پلن یافت نشد.'); redirect('fida/gold'); }
        // اگر درگاه کافه‌بازار فعال است، اشتراک فقط پس از پرداخت تأییدشده فعال می‌شود
        if (Bazaar::enabled()) {
            Flash::push('info', 'برای فعال‌سازی اشتراک، پرداخت را از دکمهٔ «پرداخت با کافه‌بازار» انجام دهید.');
            redirect('fida/gold');
        }
        $disc = $this->currentDiscount();
        $pay = $this->priceWithDiscount((int)$plan['price'], $disc);
        $days = max(30, (int)($plan['duration_months'] ?? 3) * 30);
        Database::insert('fida_subscriptions', ['user_id'=>$u, 'plan_id'=>(int)$plan['id'], 'source'=>'purchase', 'status'=>'active',
            'activated_at'=>today(), 'expires_at'=>date('Y-m-d', strtotime('+' . $days . ' days')),
            'discount_code'=>$disc['code'] ?? null, 'discount_amount'=>(int)$pay['discount_amount'], 'paid_amount'=>(int)$pay['final_price']]);
        if ($disc) Database::run('UPDATE fida_discount_codes SET used_count=used_count+1 WHERE id=?', [(int)$disc['id']]);
        unset($_SESSION['fida_discount_code']);
        Flash::push('success', 'اشتراک «' . $plan['title'] . '» فعال شد.' . ((int)$pay['discount_amount'] > 0
            ? ' (تخفیف ' . num((int)$pay['discount_amount']) . ' تومان — پرداختی ' . num((int)$pay['final_price']) . ' تومان)' : ''));
        redirect('fida/gold');
    }
    /**
     * تأیید پرداخت کافه‌بازار و فعال‌سازی اشتراک فیدا
     * توکن خرید از بازگشت دیپ‌لینک بازار می‌آید و با «API پیشخان بازار» بررسی می‌شود.
     */
    public function bazaarConfirm(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $planId = (int)post('plan_id');
        $token  = trim((string)post('purchase_token'));
        $plan   = $planId > 0 ? Database::one('SELECT * FROM fida_gold_plans WHERE id=? AND is_active=1', [$planId]) : null;

        if (!$plan) { Flash::push('error', 'پلن انتخابی یافت نشد.'); redirect('fida/gold'); }
        if ($token === '') { Flash::push('error', 'توکن پرداخت از کافه‌بازار دریافت نشد.'); redirect('fida/gold'); }
        if (!Bazaar::enabled()) { Flash::push('error', 'درگاه کافه‌بازار در این نرم‌افزار فعال نیست.'); redirect('fida/gold'); }

        $sku = Bazaar::skuFor($plan);
        if ($sku === '') { Flash::push('error', 'برای این پلن، شناسهٔ محصول (SKU) در تنظیمات تعریف نشده است.'); redirect('fida/gold'); }

        // ── ضدتکرار: هر توکن خرید فقط یک‌بار
        $seen = Database::one('SELECT * FROM fida_gold_purchases WHERE purchase_token=?', [$token]);
        if ($seen && (string)$seen['status'] === 'verified') {
            Flash::push('info', 'این خرید قبلاً ثبت شده و اشتراک شما فعال است.');
            redirect('fida/gold');
        }
        if (!$seen) {
            try {
                $rowId = Database::insert('fida_gold_purchases', [
                    'user_id' => $u, 'plan_id' => $planId, 'gateway' => 'bazaar', 'sku' => $sku,
                    'purchase_token' => $token, 'amount' => (int)$plan['price'], 'status' => 'pending', 'created_at' => now(),
                ]);
            } catch (Throwable $e) {
                $seen = Database::one('SELECT * FROM fida_gold_purchases WHERE purchase_token=?', [$token]);
                $rowId = (int)($seen['id'] ?? 0);
            }
        } else {
            $rowId = (int)$seen['id'];
        }

        // ── بررسی واقعی با کافه‌بازار
        $res = Bazaar::verify($sku, $token);
        $payload = json_encode(['sku' => $sku, 'token' => $token, 'verify' => $res], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (mb_strlen((string)$payload) > 60000) $payload = mb_substr((string)$payload, 0, 60000);

        if (empty($res['ok'])) {
            if ($rowId > 0) {
                Database::run('UPDATE fida_gold_purchases SET status=?, response_json=?, verified_at=? WHERE id=?',
                    ['failed', $payload, now(), $rowId]);
            }
            Flash::push('error', 'پرداخت تأیید نشد: ' . ($res['message'] ?: 'خطای نامشخص از کافه‌بازار'));
            redirect('fida/gold');
        }

        // ── فعال‌سازی اشتراک (تمدید از انتهای اشتراک فعلی اگر فعال باشد)
        $disc = $this->currentDiscount();
        $pay  = $this->priceWithDiscount((int)$plan['price'], $disc);
        $days = max(30, (int)($plan['duration_months'] ?? 3) * 30);
        $cur  = Database::one('SELECT MAX(expires_at) AS e FROM fida_subscriptions WHERE user_id=? AND status="active" AND expires_at>=?', [$u, today()]);
        $from = ($cur && !empty($cur['e']) && (string)$cur['e'] > today()) ? (string)$cur['e'] : today();
        $expires = date('Y-m-d', strtotime($from . ' +' . $days . ' days'));

        $subId = Database::insert('fida_subscriptions', [
            'user_id' => $u, 'plan_id' => (int)$plan['id'], 'source' => 'purchase', 'status' => 'active',
            'activated_at' => today(), 'expires_at' => $expires,
            'discount_code' => $disc['code'] ?? null,
            'discount_amount' => (int)$pay['discount_amount'],
            'paid_amount' => (int)($pay['final_price'] ?? $plan['price']),
        ]);
        if ($rowId > 0) {
            Database::run('UPDATE fida_gold_purchases SET status=?, subscription_id=?, amount=?, day_count=?, response_json=?, verified_at=? WHERE id=?',
                ['verified', $subId, (int)($pay['final_price'] ?? $plan['price']), $days, $payload, now(), $rowId]);
        }
        if ($disc) Database::run('UPDATE fida_discount_codes SET used_count=used_count+1 WHERE id=?', [(int)$disc['id']]);
        unset($_SESSION['fida_discount_code']);

        // مصرف خرید تا خرید بعدی با همین حساب ممکن باشد (خریدهای اشتراکی مصرف نمی‌شوند)
        try { $c = Bazaar::consume($token); } catch (Throwable $e) { $c = ['ok' => false]; }

        Flash::push('success', '✅ پرداخت با کافه‌بازار تأیید و اشتراک «' . $plan['title'] . '» فعال شد — معتبر تا ' . jdate($expires) . '.');
        redirect('fida/gold');
    }

    public function inviteStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $code = '';
        for ($i = 0; $i < 6; $i++) {
            $c = strtoupper(bin2hex(random_bytes(4)));
            if (!Database::val('SELECT id FROM fida_invite_codes WHERE code=?', [$c])) { $code = $c; break; }
        }
        if ($code === '') { Flash::push('error', 'ساخت کد دعوت ممکن نشد؛ دوباره تلاش کنید.'); redirect('fida/gold'); }
        Database::insert('fida_invite_codes', ['user_id'=>$u, 'code'=>$code, 'owner_label'=>mb_substr((string)(Auth::user()['full_name'] ?? ''),0,120), 'friend_discount_percent'=>10, 'reward'=>0, 'used_count'=>0, 'is_active'=>1, 'created_at'=>now()]);
        Flash::push('success', 'کد دعوت ساخته شد: ' . $code);
        redirect('fida/gold');
    }

    /* ── چاپ فاکتور ── */
    public function invoicePrint(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $id = (int)$p['id'];
        $inv = Database::one('SELECT * FROM v_fida_invoices_full WHERE id=? AND user_id=?', [$id, $u]);
        if (!$inv) abort(404, 'فاکتور یافت نشد.');
        $items = Database::all('SELECT * FROM fida_invoice_items WHERE invoice_id=? ORDER BY position', [$id]);
        $s = Fida::settings();
        return view('pages/fida/invoice_print', ['title' => 'چاپ ' . $inv['invoice_code'], 'inv' => $inv, 'items' => $items, 's' => $s]);
    }

    /* ── تبدیل پیش‌فاکتور به فاکتور فروش ── */
    public function invoiceConvert(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)$p['id'];
        $inv = Database::one('SELECT * FROM fida_invoices WHERE id=? AND user_id=?', [$id, $u]);
        if (!$inv) { Flash::push('error', 'فاکتور یافت نشد.'); redirect('fida/invoices'); }
        if ($inv['invoice_type'] !== 'pre_invoice') { Flash::push('error', 'فقط پیش‌فاکتور قابل تبدیل است.'); redirect('fida/invoices/' . $id); }
        if ($inv['status'] === 'converted' && (int)$inv['converted_to_id'] > 0) { Flash::push('info', 'این پیش‌فاکتور قبلاً تبدیل شده است.'); redirect('fida/invoices/' . (int)$inv['converted_to_id']); }
        $items = Database::all('SELECT * FROM fida_invoice_items WHERE invoice_id=? ORDER BY position', [$id]);
        if (!$items) { Flash::push('error', 'این پیش‌فاکتور قلمی ندارد.'); redirect('fida/invoices/' . $id); }
        $year = current_jalali_year();
        $newId = Database::transaction(function () use ($u, $inv, $items, $year, $id) {
            $seq = (int)Database::val('SELECT IFNULL(MAX(seq),0)+1 FROM fida_invoices WHERE user_id=? AND invoice_type="sale" AND invoice_year=?', [$u, $year], 1);
            while (Database::val('SELECT id FROM fida_invoices WHERE user_id=? AND invoice_type="sale" AND invoice_year=? AND seq=?', [$u, $year, $seq])) $seq++;
            $code = 'INV-' . $year . '-' . str_pad((string)$seq, 4, '0', STR_PAD_LEFT);
            [$jy,$jm,$jd] = gregorian_to_jalali((int)date('Y'),(int)date('n'),(int)date('j'));
            $jal = sprintf('%04d/%02d/%02d',$jy,$jm,$jd);
            $newId = Database::insert('fida_invoices', [
                'user_id'=>$u, 'invoice_type'=>'sale', 'invoice_code'=>$code, 'seq'=>$seq, 'invoice_year'=>$year, 'invoice_month'=>$jm,
                'invoice_date'=>today(), 'invoice_jalali'=>$jal, 'person_id'=>(int)$inv['person_id'], 'status'=>'credit', 'pay_method'=>'credit',
                'due_date'=>$inv['due_date'] ?? null, 'due_jalali'=>$inv['due_jalali'] ?? null, 'previous_debt_amount'=>(int)$inv['previous_debt_amount'],
                'advance_amount'=>0, 'total_amount'=>(int)$inv['total_amount'], 'discount_amount'=>(int)$inv['discount_amount'],
                'ship_amount'=>(int)$inv['ship_amount'],
                'tax_mode'=>$inv['tax_mode'] ?? null, 'tax_percent'=>(float)($inv['tax_percent'] ?? 0), 'tax_amount'=>(int)($inv['tax_amount'] ?? 0),
                'final_amount'=>(int)$inv['final_amount'], 'paid_amount'=>0,
                'notes'=>('از پیش‌فاکتور ' . $inv['invoice_code']), 'created_at'=>now(),
            ]);
            foreach ($items as $it) Database::insert('fida_invoice_items', ['user_id'=>$u, 'invoice_id'=>$newId, 'item_id'=>$it['item_id'], 'item_title'=>$it['item_title'], 'unit'=>$it['unit'], 'quantity'=>$it['quantity'], 'unit_price'=>$it['unit_price'], 'total_price'=>$it['total_price'], 'position'=>$it['position']]);
            Database::insert('fida_invoice_status_history', ['user_id'=>$u, 'invoice_id'=>$newId, 'old_status'=>null, 'new_status'=>'credit', 'changed_at'=>now(), 'note'=>'تبدیل از پیش‌فاکتور ' . $inv['invoice_code']]);
            Database::update('fida_invoices', ['status'=>'converted', 'converted_to_id'=>$newId], 'id=:pk AND user_id=:uid', ['pk'=>$id, 'uid'=>$u]);
            Database::insert('fida_invoice_status_history', ['user_id'=>$u, 'invoice_id'=>$id, 'old_status'=>$inv['status'], 'new_status'=>'converted', 'changed_at'=>now(), 'note'=>'تبدیل به فاکتور ' . $code]);
            return $newId;
        });
        Flash::push('success', 'پیش‌فاکتور به فاکتور فروش تبدیل شد.');
        redirect('fida/invoices/' . $newId);
    }

    /* ── پروفایل شخص ── */
    public function personShow(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $id = (int)$p['id'];
        $person = Database::one('SELECT * FROM fida_persons WHERE id=? AND user_id=?', [$id, $u]);
        if (!$person) abort(404, 'شخص یافت نشد.');
        $inv = Database::all('SELECT * FROM v_fida_invoices_full WHERE person_id=? AND user_id=? ORDER BY id DESC LIMIT 100', [$id, $u]);
        $pays = Database::all('SELECT p.*, i.invoice_code FROM fida_payments p LEFT JOIN fida_invoices i ON i.id=p.invoice_id WHERE p.person_id=? AND p.user_id=? ORDER BY p.id DESC LIMIT 100', [$id, $u]);
        $sum = Database::one('SELECT * FROM v_fida_person_summary WHERE id=? AND user_id=?', [$id, $u]) ?: [];
        return view('pages/fida/person_show', ['title' => 'پرونده ' . $person['full_name'], 'person' => $person, 'inv' => $inv, 'pays' => $pays, 'sum' => $sum]);
    }

    /* ── تاریخ شمسی از تاریخ میلادی ── */
    private function jal(string $greg): string
    {
        $t = strtotime($greg) ?: time();
        [$y, $m, $d] = gregorian_to_jalali((int)date('Y', $t), (int)date('n', $t), (int)date('j', $t));
        return sprintf('%04d/%02d/%02d', $y, $m, $d);
    }

    /* ══════════════════ چک‌ها (دریافتی / پرداختی) ══════════════════ */

    public function cheques(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $f = (string)($_GET['f'] ?? 'all');
        $w = ['c.user_id = ?']; $par = [$u];
        switch ($f) {
            case 'received': $w[] = "c.direction = 'received'"; break;
            case 'issued':   $w[] = "c.direction = 'issued'"; break;
            case 'due':      $w[] = "c.status IN ('in_hand','deposited') AND c.due_date <= DATE_ADD(CURDATE(), INTERVAL " . FidaNotice::WINDOW_DAYS . " DAY)"; break;
            case 'cleared':  $w[] = "c.status = 'cleared'"; break;
            case 'returned': $w[] = "c.status = 'returned'"; break;
        }
        $rows = Database::all(
            "SELECT * FROM v_fida_cheques_full c WHERE " . implode(' AND ', $w)
            . " ORDER BY (c.status IN ('in_hand','deposited')) DESC, c.due_date ASC, c.id DESC LIMIT 300", $par);
        $sum = Database::one(
            "SELECT
               IFNULL(SUM(CASE WHEN direction='received' AND status IN ('in_hand','deposited') THEN amount END),0) AS recv,
               IFNULL(SUM(CASE WHEN direction='issued'   AND status IN ('in_hand','deposited') THEN amount END),0) AS issued,
               IFNULL(SUM(CASE WHEN status IN ('in_hand','deposited') AND due_date <= DATE_ADD(CURDATE(), INTERVAL " . FidaNotice::WINDOW_DAYS . " DAY) THEN amount END),0) AS due_soon,
               IFNULL(SUM(CASE WHEN status IN ('in_hand','deposited') AND due_date <= DATE_ADD(CURDATE(), INTERVAL " . FidaNotice::WINDOW_DAYS . " DAY) THEN 1 END),0) AS due_count,
               IFNULL(SUM(CASE WHEN status='returned' THEN 1 END),0) AS returned
             FROM fida_cheques WHERE user_id=?", [$u]) ?: [];
        $focus = (int)($_GET['focus'] ?? 0);
        return view('pages/fida/cheques', ['title' => 'چک‌ها', 'rows' => $rows, 'f' => $f, 'sum' => $sum, 'focus' => $focus]);
    }

    public function chequeForm(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $id = (int)($p['id'] ?? 0);
        $row = $id ? Database::one('SELECT * FROM fida_cheques WHERE id=? AND user_id=?', [$id, $u]) : [];
        if ($id && !$row) abort(404, 'چک یافت نشد.');
        return view('pages/fida/cheque_form', [
            'title'   => $id ? 'ویرایش چک' : 'ثبت چک',
            'row'     => $row ?: [],
            'persons' => Database::all('SELECT id, full_name FROM fida_persons WHERE user_id=? AND status="active" ORDER BY full_name LIMIT 500', [$u]),
            'prePerson' => (int)($_GET['person_id'] ?? 0),
            'preInvoice' => (int)($_GET['invoice_id'] ?? 0),
        ]);
    }

    public function chequeStore(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id   = (int)post('id');
        $back = $id ? 'fida/cheques/' . $id . '/edit' : 'fida/cheques/create';
        $dir  = post('direction') === 'issued' ? 'issued' : 'received';
        $no   = trim((string)post('cheque_no'));
        $amt  = (int)fa_num((string)post('amount'));
        $due  = to_gregorian((string)post('due_date'));
        $issue = to_gregorian((string)post('issue_date'));
        $sts  = in_array((string)post('status'), ['in_hand','deposited','cleared','returned','cancelled'], true) ? (string)post('status') : 'in_hand';
        $personId = (int)post('person_id') ?: null;
        $invoiceId = (int)post('invoice_id') ?: null;

        if (mb_strlen($no) < 2)      { Flash::push('error', 'شمارهٔ چک را وارد کنید.'); redirect($back); }
        if ($amt <= 0)               { Flash::push('error', 'مبلغ چک را درست وارد کنید.'); redirect($back); }
        if (!$due)                   { Flash::push('error', 'تاریخ سررسید را وارد کنید (مثال: ۱۴۰۵/۰۷/۱۵).'); redirect($back); }
        if ($personId && !Database::val('SELECT id FROM fida_persons WHERE id=? AND user_id=?', [$personId, $u])) $personId = null;
        if ($invoiceId && !Database::val('SELECT id FROM fida_invoices WHERE id=? AND user_id=?', [$invoiceId, $u])) $invoiceId = null;

        $data = [
            'direction' => $dir,
            'cheque_no' => mb_substr($no, 0, 30),
            'bank_name' => mb_substr((string)post('bank_name'), 0, 80) ?: null,
            'branch_name' => mb_substr((string)post('branch_name'), 0, 80) ?: null,
            'account_no' => mb_substr((string)post('account_no'), 0, 40) ?: null,
            'sayad_id' => mb_substr((string)post('sayad_id'), 0, 30) ?: null,
            'amount' => $amt,
            'person_id' => $personId,
            'person_name' => $personId ? null : (mb_substr(trim((string)post('person_name')), 0, 120) ?: null),
            'issue_date' => $issue, 'issue_jalali' => $issue ? $this->jal($issue) : null,
            'due_date' => $due, 'due_jalali' => $this->jal($due),
            'status' => $sts,
            'invoice_id' => $invoiceId,
            'note' => mb_substr((string)post('note'), 0, 255) ?: null,
        ];
        if ($id && Database::val('SELECT id FROM fida_cheques WHERE id=? AND user_id=?', [$id, $u])) {
            Database::update('fida_cheques', $data, 'id=:pk AND user_id=:uid', ['pk' => $id, 'uid' => $u]);
            Flash::push('success', 'چک ویرایش شد.');
        } else {
            Database::insert('fida_cheques', [
                'user_id' => $u, 'direction' => $dir, 'cheque_no' => mb_substr($no, 0, 30),
                'bank_name' => mb_substr((string)post('bank_name'), 0, 80) ?: null,
                'branch_name' => mb_substr((string)post('branch_name'), 0, 80) ?: null,
                'account_no' => mb_substr((string)post('account_no'), 0, 40) ?: null,
                'sayad_id' => mb_substr((string)post('sayad_id'), 0, 30) ?: null,
                'amount' => $amt, 'person_id' => $personId,
                'person_name' => $personId ? null : (mb_substr(trim((string)post('person_name')), 0, 120) ?: null),
                'issue_date' => $issue, 'issue_jalali' => $issue ? $this->jal($issue) : null,
                'due_date' => $due, 'due_jalali' => $this->jal($due), 'status' => $sts,
                'invoice_id' => $invoiceId, 'note' => mb_substr((string)post('note'), 0, 255) ?: null,
                'created_at' => now(),
            ]);
            Flash::push('success', ($dir === 'issued' ? 'چک پرداختی' : 'چک دریافتی') . ' ثبت شد.');
        }
        redirect('fida/cheques' . ($dir === 'received' ? '?f=received' : '?f=issued'));
    }

    public function chequeStatus(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)($p['id'] ?? 0);
        $ch = Database::one('SELECT * FROM fida_cheques WHERE id=? AND user_id=?', [$id, $u]);
        if (!$ch) { Flash::push('error', 'چک یافت نشد.'); redirect('fida/cheques'); }
        $st = in_array((string)post('status'), ['in_hand','deposited','cleared','returned','cancelled'], true) ? (string)post('status') : null;
        if (!$st) { Flash::push('error', 'وضعیت نامعتبر است.'); redirect('fida/cheques'); }
        Database::update('fida_cheques', ['status' => $st], 'id=:pk AND user_id=:uid', ['pk' => $id, 'uid' => $u]);
        $fa = ['in_hand'=>'در جریان','deposited'=>'سپرده‌شده','cleared'=>'وصول‌شده','returned'=>'برگشتی','cancelled'=>'ابطال‌شده'];
        Flash::push('success', 'وضعیت چک به «' . ($fa[$st] ?? $st) . '» تغییر کرد.');
        // وقتی چک وصول می‌شود، اعلان مربوطه خوانده‌شده می‌شود
        FidaNotice::markRead($u, 'chq:' . $id);
        redirect('fida/cheques');
    }

    public function chequeDelete(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $id = (int)($p['id'] ?? 0);
        Database::run('DELETE FROM fida_cheques WHERE id=? AND user_id=?', [$id, $u]);
        Flash::push('success', 'چک حذف شد.');
        redirect('fida/cheques');
    }

    /* ══════════════════ اعلان‌های داخلی ══════════════════ */

    public function notifications(array $p): string
    {
        $this->guard(); $u = Fida::uid();
        $items = FidaNotice::feed($u);
        $unread = 0; foreach ($items as $it) if (!$it['read']) $unread++;
        return view('pages/fida/notifications', ['title' => 'اعلان‌ها', 'items' => $items, 'unread' => $unread]);
    }

    public function notificationsFeed(array $p): string
    {
        $this->guard();
        header('Content-Type: application/json; charset=utf-8');
        $u = Fida::uid();
        $items = FidaNotice::feed($u);
        $out = [];
        foreach ($items as $it) {
            $out[] = [
                'key' => $it['key'], 'kind' => $it['kind'], 'severity' => $it['severity'],
                'when' => $it['when'], 'title' => $it['title'], 'desc' => $it['desc'],
                'url' => $it['url'], 'read' => $it['read'], 'icon' => FidaNotice::icon($it['icon'], 17),
            ];
        }
        $badge = FidaNotice::badge($u);
        echo json_encode(['ok' => true, 'count' => $badge['count'], 'unread' => $badge['unread'],
                          'urgent' => $badge['urgent'], 'items' => $out], JSON_UNESCAPED_UNICODE);
        return '';
    }

    public function notificationRead(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $key = (string)post('key');
        $mode = (string)post('mode');
        if ($key !== '') { $mode === 'unread' ? FidaNotice::markUnread($u, $key) : FidaNotice::markRead($u, $key); }
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $badge = FidaNotice::badge($u);
            echo json_encode(['ok' => true, 'unread' => $badge['unread']], JSON_UNESCAPED_UNICODE);
            return '';
        }
        redirect('fida/notifications');
        return '';
    }

    /** حذف یک اعلان (فقط برای همین کاربر) */
    public function notificationDismiss(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $key = mb_substr((string)post('key'), 0, 80);
        $okDelete = $key !== '' && FidaNotice::dismiss($u, $key);
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $badge = FidaNotice::badge($u);
            echo json_encode(['ok' => $okDelete, 'unread' => $badge['unread'], 'count' => $badge['count']], JSON_UNESCAPED_UNICODE);
            return '';
        }
        if ($okDelete) Flash::push('success', 'اعلان حذف شد.');
        redirect('fida/notifications');
        return '';
    }

    /** حذف همهٔ اعلان‌های فعلی همین کاربر */
    public function notificationsDismissAll(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $n = FidaNotice::dismissAll($u);
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $badge = FidaNotice::badge($u);
            echo json_encode(['ok' => true, 'removed' => $n, 'unread' => $badge['unread'], 'count' => $badge['count']], JSON_UNESCAPED_UNICODE);
            return '';
        }
        Flash::push('success', $n > 0 ? (num($n) . ' اعلان حذف شد.') : 'اعلانی برای حذف نبود.');
        redirect('fida/notifications');
        return '';
    }

    public function notificationsReadAll(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $n = FidaNotice::markAllRead($u);
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $badge = FidaNotice::badge($u);
            echo json_encode(['ok' => true, 'marked' => $n, 'unread' => $badge['unread'], 'count' => $badge['count']], JSON_UNESCAPED_UNICODE);
            return '';
        }
        Flash::push('success', $n > 0 ? ($n . ' اعلان خوانده‌شده شد.') : 'اعلان خوانده‌نشده‌ای نبود.');
        redirect('fida/notifications');
        return '';
    }

    /* ── ورود / ثبت‌نام فیدا — فقط با کد پیامکی (کاربران مشترک با فینتو) ── */
    public function login(array $p): string
    {
        if (Auth::id()) redirect('fida');
        $mode = (post('mode') === 'register' || (($_GET['mode'] ?? '') === 'register')) ? 'register' : 'login';
        $error = null; $oldMobile = ''; $oldName = '';
        if (is_post()) {
            csrf_verify();
            $oldMobile = (string)post('mobile');
            $oldName   = trim((string)post('full_name'));
            $mobile = AuthController::normalizeMobile($oldMobile);
            $user = $mobile ? Database::one('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL', [$mobile]) : null;
            if (!$mobile) {
                $error = 'شماره موبایل معتبر نیست (مثال: 09121234567).';
            } elseif ($mode === 'register') {
                if ($user) $error = 'این شماره قبلاً ثبت‌نام شده است؛ از تب «ورود» استفاده کنید.';
                elseif (mb_strlen($oldName) < 3) $error = 'نام و نام خانوادگی را کامل وارد کنید.';
                else {
                    $uid = Database::insert('users', [
                        'full_name' => mb_substr($oldName, 0, 120),
                        'mobile' => $mobile,
                        'password_hash' => password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT, ['cost' => 10]),
                        'status' => 'active', 'is_active' => 1, 'preferred_language' => 'fa', 'theme' => 'purple',
                        'created_at' => now(),
                    ]);
                    $user = Database::one('SELECT * FROM users WHERE id=?', [$uid]);
                    Fida::ensureProfile($uid, $oldName);   // پروفایل اختصاصی تازه برای این کاربر
                }
            } elseif (!$user) {
                $error = 'حسابی با این شماره پیدا نشد؛ ابتدا از تب «ثبت‌نام» حساب بسازید.';
            } elseif (!$user['is_active'] || $user['status'] !== 'active') {
                $error = 'حساب کاربری فعال نیست. با پشتیبانی تماس بگیرید.';
            }
            if (!$error) {
                try {
                    $purpose = $mode === 'register' ? 'register' : 'login';
                    Otp::create((int)$user['id'], $mobile, $purpose);
                    $_SESSION['fida_otp_mobile']  = $mobile;
                    $_SESSION['fida_otp_purpose'] = $purpose;
                    redirect('fida/verify');
                } catch (Throwable $e) { $error = $e->getMessage(); }
            }
        }
        return view('pages/fida/login', [
            'title' => ($mode === 'register' ? 'ثبت‌نام در اپ فاکتورزنی' : 'ورود به اپ فاکتورزنی'),
            'mode' => $mode, 'error' => $error, 'oldMobile' => $oldMobile, 'oldName' => $oldName,
        ]);
    }

    /* ── صفحهٔ کد تایید ── */
    public function verify(array $p): string
    {
        if (Auth::id()) redirect('fida');
        $mobile = $_SESSION['fida_otp_mobile'] ?? null;
        if (!$mobile) redirect('fida/login');
        $purpose = (string)($_SESSION['fida_otp_purpose'] ?? 'login');
        $demo = (bool)config('app')['demo_mode'];
        $error = null; $info = null;
        if ($demo) {
            $demoCode = $_SESSION['_demo_otp'][$mobile] ?? '';
            if (!$demoCode) {
                $log = @file_get_contents(storage_path('sms.log')) ?: '';
                if (preg_match_all('/(?:^|\n)[^|]*\| '.preg_quote($mobile, '/').' \| [^0-9]*(\d{6})/', $log, $mm)) $demoCode = (string)end($mm[1]);
            }
            $info = $demoCode
                ? 'حالت نمایشی: کد تایید این شماره «'.$demoCode.'» است. در محیط عملیاتی این کد با پیامک (کاوه‌نگار) ارسال می‌شود.'
                : 'حالت نمایشی: کد تایید در فایل storage/sms.log ثبت شده است.';
        }
        if (is_post()) {
            csrf_verify();
            $code = strtr((string)post('code'), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
            $code = (string)preg_replace('/\D/', '', $code);
            if ($demo && $code === self::DEMO_OTP) {
                $ok = true; $res = null;                      // کد تستی همیشه در حالت نمایشی معتبر است
            } else {
                [$ok, $res] = Otp::verify($mobile, $code, $purpose);
            }
            if ($ok) {
                $u = Database::one('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL', [$mobile]);
                if (!$u) {
                    $error = 'کاربر یافت نشد.';
                } else {
                    unset($_SESSION['fida_otp_mobile'], $_SESSION['fida_otp_purpose']);
                    Database::run('UPDATE users SET last_login_at=NOW() WHERE id=?', [(int)$u['id']]);
                    Auth::loginUser($u);
                    Fida::ensureProfile((int)$u['id'], (string)($u['full_name'] ?? ''));   // پروفایل اختصاصی این کاربر
                    $name = trim((string)($u['full_name'] ?? ''));
                    Flash::push('success', 'خوش آمدی' . ($name !== '' ? ' ' . $name : '') . ' 👋');
                    redirect('fida');
                }
            } else $error = $res;
        }
        return view('pages/fida/verify', [
            'title' => 'کد تایید', 'mobile' => $mobile, 'purpose' => $purpose, 'error' => $error, 'info' => $info,
            'testCode' => $demo ? self::DEMO_OTP : null,
        ]);
    }

    public function authResend(array $p): string
    {
        csrf_verify();
        $mobile = (string)($_SESSION['fida_otp_mobile'] ?? '');
        if ($mobile === '') redirect('fida/login');
        $purpose = (string)($_SESSION['fida_otp_purpose'] ?? 'login');
        $u = Database::one('SELECT * FROM users WHERE mobile=? AND deleted_at IS NULL', [$mobile]);
        try {
            Otp::create($u ? (int)$u['id'] : null, $mobile, $purpose);
            Flash::push('success', 'کد تایید جدید ارسال شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('fida/verify');
        return '';
    }

    public function logout(array $p): string
    {
        unset($_SESSION['fida_otp_mobile'], $_SESSION['fida_otp_purpose']);
        Auth::logout();
        redirect('fida/login');
        return '';
    }

    /** اطمینان از ورود کاربر + وجود پروفایل اختصاصی او */
    private function guard(): void
    {
        if (!Auth::id()) redirect('fida/login');
        Fida::ensureProfile((int)Auth::id());
    }

    /* ── فعال‌سازی اشتراک با کد دعوت ── */
    public function inviteRedeem(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        $code = strtoupper(trim((string)post('code')));
        if ($code === '') { Flash::push('error', 'کد دعوت را وارد کنید.'); redirect('fida/gold'); }
        $inv = Database::one('SELECT * FROM fida_invite_codes WHERE code=? AND is_active=1', [$code]);
        if (!$inv) { Flash::push('error', 'کد دعوت نامعتبر یا غیرفعال است.'); redirect('fida/gold'); }
        if ((int)($inv['used_count'] ?? 0) >= 25) { Flash::push('error', 'ظرفیت این کد دعوت تکمیل شده است.'); redirect('fida/gold'); }
        $pct = (int)($inv['friend_discount_percent'] ?? 0);
        $plan = Database::one('SELECT * FROM fida_gold_plans WHERE is_active=1 ORDER BY price LIMIT 1');
        $planId = $plan ? (int)$plan['id'] : null;
        $months = $plan ? max(1, (int)$plan['duration_months']) : 1;
        Database::transaction(function () use ($u, $inv, $planId, $months) {
            Database::insert('fida_subscriptions', ['user_id'=>$u, 'plan_id'=>$planId, 'source'=>'invite', 'status'=>'active',
                'activated_at'=>today(), 'expires_at'=>date('Y-m-d', strtotime('+' . ($months * 30) . ' days'))]);
            Database::run('UPDATE fida_invite_codes SET used_count = used_count + 1 WHERE id=?', [(int)$inv['id']]);
        });
        Flash::push('success', 'اشتراک با کد دعوت فعال شد' . ($pct > 0 ? ' — ' . $pct . '٪ تخفیف دوستانه اعمال شد.' : '.'));
        redirect('fida/gold');
    }

    /* ── افزودن سریع واحد شمارش (JSON) ── */
    public function unitQuick(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        header('Content-Type: application/json; charset=utf-8');
        $t = Fida::addUnit($u, (string)post('title'));
        if ($t === null) { echo json_encode(['ok' => false, 'error' => 'نام واحد را وارد کنید.'], JSON_UNESCAPED_UNICODE); return ''; }
        echo json_encode(['ok' => true, 'title' => $t, 'units' => Fida::units($u)], JSON_UNESCAPED_UNICODE);
        return '';
    }

    /* ── افزودن سریع کالا/خدمت از فرم فاکتور (JSON) ── */
    public function itemQuick(array $p): string
    {
        $this->guard(); csrf_verify(); $u = Fida::uid();
        header('Content-Type: application/json; charset=utf-8');
        $title = trim((string)post('title'));
        if (mb_strlen($title) < 2) { echo json_encode(['ok' => false, 'error' => 'عنوان کالا کوتاه است.'], JSON_UNESCAPED_UNICODE); return ''; }
        $unit = mb_substr((string)(post('unit') ?: 'عدد'), 0, 30);
        $price = (int)fa_num((string)post('unit_price'));
        $kind = post('kind') === 'service' ? 'service' : 'supply';
        $ex = Database::one('SELECT id,title,unit,unit_price,kind FROM fida_items WHERE user_id=? AND title=? LIMIT 1', [$u, $title]);
        if ($ex) { echo json_encode(['ok' => true, 'item' => $ex, 'existed' => true], JSON_UNESCAPED_UNICODE); return ''; }
        $id = Database::insert('fida_items', ['user_id'=>$u, 'kind' => $kind, 'title' => mb_substr($title, 0, 150), 'unit' => $unit, 'unit_price' => $price, 'is_active' => 1, 'created_at' => now()]);
        echo json_encode(['ok' => true, 'item' => ['id' => $id, 'title' => $title, 'unit' => $unit, 'unit_price' => $price, 'kind' => $kind]], JSON_UNESCAPED_UNICODE);
        return '';
    }
}
