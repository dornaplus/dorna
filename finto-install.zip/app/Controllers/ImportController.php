<?php
/**
 * «به‌روزرسانی اطلاعات» — واردسازی واقعی CSV برای اشخاص و کالا/خدمات.
 * هر بارگذاری یک ردیف در جدول import_jobs ثبت می‌کند و گزارش خطاها را در storage/imports نگه می‌دارد.
 */
final class ImportController
{
    /** موجودیت‌های قابل واردسازی → عنوان، ستون‌های مجاز، ستون‌های الزامی */
    public const ENTITIES = [
        'persons' => [
            'title' => 'اشخاص (مشتری/تأمین‌کننده/پرسنل)',
            'columns' => ['code', 'person_kind', 'first_name', 'last_name', 'company_name', 'national_id',
                          'economic_code', 'mobile', 'phone', 'email', 'postal_code', 'address', 'notes'],
            'required' => ['person_kind'],
            'sample' => ['C-1001', 'haqiqi', 'علی', 'محمدی', '', '0079123456', '', '09121234567', '', 'ali@example.com', '', 'تهران، خیابان آزادی', ''],
        ],
        'products' => [
            'title' => 'کالا و خدمات',
            'columns' => ['code', 'title', 'item_type', 'unit', 'sale_price', 'buy_price', 'is_taxable', 'is_active'],
            'required' => ['code', 'title'],
            'sample' => ['P-1001', 'ماوس بی‌سیم', 'goods', 'عدد', '5000000', '4000000', '1', '1'],
        ],
    ];

    private const HEADER_MAP = [
        'کد' => 'code', 'نام' => 'first_name', 'نام خانوادگی' => 'last_name', 'شرکت' => 'company_name',
        'نوع شخص' => 'person_kind', 'نوع' => 'item_type', 'کد ملی' => 'national_id', 'شناسه ملی' => 'national_id',
        'کد اقتصادی' => 'economic_code', 'موبایل' => 'mobile', 'همراه' => 'mobile', 'تلفن' => 'phone',
        'ایمیل' => 'email', 'کدپستی' => 'postal_code', 'کد پستی' => 'postal_code', 'نشانی' => 'address', 'آدرس' => 'address',
        'عنوان' => 'title', 'نام کالا' => 'title', 'نام خدمت' => 'title', 'واحد' => 'unit',
        'قیمت فروش' => 'sale_price', 'قیمت خرید' => 'buy_price', 'قیمت' => 'sale_price',
        'مالیات‌پذیر' => 'is_taxable', 'وضعیت' => 'is_active', 'یادداشت' => 'notes',
    ];

    private function guard(): void
    {
        Auth::requireApp();
        if (!Auth::can('settings.edit') && !Auth::can('settings.view')) abort(403, 'مجوز دسترسی به به‌روزرسانی اطلاعات را ندارید.');
    }

    /** فرم بارگذاری */
    public function createForm(array $p): string
    {
        $this->guard();
        $entity = (string)($_GET['entity'] ?? 'persons');
        if (!isset(self::ENTITIES[$entity])) $entity = 'persons';
        return view('pages/import/form', ['title' => 'به‌روزرسانی اطلاعات', 'entity' => $entity, 'entities' => self::ENTITIES,
            'jobs' => Database::all('SELECT * FROM import_jobs WHERE business_id=? ORDER BY id DESC LIMIT 20', [Auth::businessId()])]);
    }

    /** دانلود قالب CSV */
    public function template(array $p): void
    {
        $this->guard();
        $entity = (string)($_GET['entity'] ?? 'persons');
        $def = self::ENTITIES[$entity] ?? self::ENTITIES['persons'];
        $titles = ['persons' => ['کد', 'نوع شخص', 'نام', 'نام خانوادگی', 'شرکت', 'کد ملی', 'کد اقتصادی', 'موبایل', 'تلفن', 'ایمیل', 'کد پستی', 'نشانی', 'یادداشت'],
                   'products' => ['کد', 'عنوان', 'نوع', 'واحد', 'قیمت فروش', 'قیمت خرید', 'مالیات‌پذیر', 'وضعیت']][$entity];
        csv_download('template-' . $entity, $titles, [$def['sample']]);
    }

    /** پردازش فایل بارگذاری‌شده */
    public function store(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز انجام به‌روزرسانی اطلاعات را ندارید.');
        csrf_verify();
        $biz = Auth::businessId();
        $entity = (string)post('entity_type', 'persons');
        if (!isset(self::ENTITIES[$entity])) { Flash::push('error', 'نوع داده نامعتبر است.'); redirect('app/import-jobs/create'); }
        $mode = (string)post('mode', 'upsert');
        $dry = (string)post('dry_run', '0') === '1';
        $def = self::ENTITIES[$entity];

        if (empty($_FILES['file']['tmp_name']) || (int)($_FILES['file']['error'] ?? 1) !== UPLOAD_ERR_OK) {
            Flash::push('error', 'فایل CSV را انتخاب کنید.');
            redirect('app/import-jobs/create?entity=' . $entity);
        }
        $rows = $this->readCsv((string)$_FILES['file']['tmp_name']);
        if (!$rows) { Flash::push('error', 'فایل خالی است یا قالب آن خوانده نشد.'); redirect('app/import-jobs/create?entity=' . $entity); }
        $head = array_shift($rows);

        // نگاشت سرستون‌ها
        $map = [];
        foreach ($head as $i => $h) {
            $h = trim(en_digits((string)$h));
            $col = in_array($h, $def['columns'], true) ? $h : (self::HEADER_MAP[$h] ?? null);
            if ($col && in_array($col, $def['columns'], true)) $map[$i] = $col;
        }
        if (!$map) { Flash::push('error', 'سرستون‌های فایل شناسایی نشد. از «دانلود قالب» استفاده کنید.'); redirect('app/import-jobs/create?entity=' . $entity); }

        $total = 0; $okCount = 0; $updCount = 0; $errors = []; $seen = [];
        $jobId = null;
        if (!$dry) {
            $jobId = Database::insert('import_jobs', ['business_id' => $biz, 'entity_type' => $entity, 'attachment_id' => null,
                'total_rows' => 0, 'success_rows' => 0, 'error_rows' => 0, 'mode' => $mode, 'status' => 'processing',
                'started_at' => now(), 'created_at' => now(), 'created_by' => Auth::id()]);
        }
        Database::transaction(function () use ($rows, $map, $def, $entity, $mode, $dry, $biz, &$total, &$okCount, &$updCount, &$errors, &$seen) {
            foreach ($rows as $idx => $row) {
                $line = $idx + 2;                      // شمارهٔ خط در فایل
                if (!$row || (count(array_filter($row, fn($v) => trim((string)$v) !== '')) === 0)) continue;
                $total++;
                $data = [];
                foreach ($map as $i => $col) $data[$col] = trim(en_digits((string)($row[$i] ?? '')));
                try {
                    if ($entity === 'persons') [$did, $wasUpdate] = $this->savePerson($biz, $data, $mode, $seen, $dry);
                    else [$did, $wasUpdate] = $this->saveProduct($biz, $data, $mode, $seen, $dry);
                    $okCount++; if ($wasUpdate) $updCount++;
                } catch (Throwable $e) {
                    $errors[] = ['line' => $line, 'message' => $e->getMessage(), 'row' => array_values($data)];
                    if (!$dry) $seen = $seen;      // ادامهٔ پردازش
                }
            }
        });
        $failCount = count($errors);

        if (!$dry) {
            Database::run('UPDATE import_jobs SET total_rows=?, success_rows=?, error_rows=?, status=?, finished_at=? WHERE id=?',
                [$total, $okCount, $failCount, $failCount ? ($okCount ? 'done' : 'failed') : 'done', now(), $jobId]);
            $this->writeReport((int)$jobId, $biz, ['entity' => $entity, 'mode' => $mode, 'total' => $total, 'ok' => $okCount,
                'updated' => $updCount, 'failed' => $failCount, 'errors' => $errors, 'file' => (string)($_FILES['file']['name'] ?? ''), 'at' => now()]);
            Audit::log('import', 'import_jobs', (int)$jobId, 'به‌روزرسانی اطلاعات ' . $def['title'], ['ok' => $okCount, 'failed' => $failCount]);
            Flash::push($failCount ? 'info' : 'success', num($okCount) . ' ردیف ثبت/به‌روزرسانی شد' . ($failCount ? ' و ' . num($failCount) . ' ردیف خطا داشت.' : '.'));
            redirect('app/import-jobs/' . $jobId . '/result');
        }
        // پیش‌بررسی بدون ثبت
        Flash::push($failCount ? 'info' : 'success', 'پیش‌بررسی: ' . num($okCount) . ' ردیف سالم' . ($failCount ? ' و ' . num($failCount) . ' ردیف خطا' : '') . '. (چیزی ثبت نشد)');
        $_SESSION['import_dry'] = ['entity' => $entity, 'total' => $total, 'ok' => $okCount, 'updated' => $updCount, 'failed' => $failCount, 'errors' => array_slice($errors, 0, 200)];
        redirect('app/import-jobs/preview');
        return '';
    }

    /** گزارش یک بارگذاری */
    public function result(array $p): string
    {
        $this->guard();
        $job = Database::one('SELECT * FROM import_jobs WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$job) abort(404, 'کار بارگذاری یافت نشد.');
        return view('pages/import/result', ['title' => 'گزارش به‌روزرسانی اطلاعات', 'job' => $job, 'report' => $this->readReport((int)$job['id']),
            'entities' => self::ENTITIES]);
    }

    /** نتیجهٔ پیش‌بررسی */
    public function preview(array $p): string
    {
        $this->guard();
        $rep = $_SESSION['import_dry'] ?? null;
        if (!$rep) { Flash::push('info', 'ابتدا یک فایل را پیش‌بررسی کنید.'); redirect('app/import-jobs/create'); }
        unset($_SESSION['import_dry']);
        return view('pages/import/preview', ['title' => 'پیش‌بررسی به‌روزرسانی', 'rep' => $rep, 'entities' => self::ENTITIES]);
    }

    /* ───────────── درونی ───────────── */

    private function reportPath(int $jobId): string
    {
        $dir = storage_path('imports');
        if (!is_dir($dir)) @mkdir($dir, 0775, true);
        return $dir . '/job-' . $jobId . '.json';
    }
    private function writeReport(int $jobId, int $biz, array $data): void
    {
        @file_put_contents($this->reportPath($jobId), json_encode($data, JSON_UNESCAPED_UNICODE));
    }
    private function readReport(int $jobId): ?array
    {
        $p = $this->reportPath($jobId);
        if (!is_file($p)) return null;
        $d = json_decode((string)file_get_contents($p), true);
        return is_array($d) ? $d : null;
    }

    /** خواندن CSV با پشتیبانی BOM و جداکنندهٔ , یا ; */
    private function readCsv(string $path): array
    {
        $raw = (string)file_get_contents($path);
        if ($raw === '') return [];
        $raw = preg_replace('/^\xEF\xBB\xBF/', '', $raw);
        $delim = substr_count($raw, ';') > substr_count($raw, ',') ? ';' : ',';
        $tmp = fopen('php://temp', 'r+');
        fwrite($tmp, $raw); rewind($tmp);
        $out = [];
        while (($r = fgetcsv($tmp, 0, $delim)) !== false) $out[] = $r;
        fclose($tmp);
        return $out;
    }

    /** ذخیرهٔ یک شخص → [id, wasUpdate] */
    private function savePerson(int $biz, array $d, string $mode, array &$seen, bool $dry): array
    {
        $kind = strtolower(trim((string)($d['person_kind'] ?? '')));
        $kindMap = ['حقیقی' => 'haqiqi', 'حقوقی' => 'hoqoqi', 'haqiqi' => 'haqiqi', 'hoqoqi' => 'hoqoqi', 'individual' => 'haqiqi', 'company' => 'hoqoqi'];
        $kind = $kindMap[$kind] ?? '';
        if ($kind === '') $kind = trim((string)($d['company_name'] ?? '')) !== '' ? 'hoqoqi' : 'haqiqi';
        if ($kind === 'hoqoqi' && trim((string)($d['company_name'] ?? '')) === '' && trim((string)($d['last_name'] ?? '')) === '')
            throw new RuntimeException('برای شخص حقوقی، نام شرکت لازم است.');
        $code = trim((string)($d['code'] ?? ''));
        if ($code === '') $code = (new PeopleController())->nextCode($biz, $kind);
        if (isset($seen['p:' . $code])) throw new RuntimeException('کد «' . $code . '» در همین فایل تکرار شده است.');
        $seen['p:' . $code] = 1;

        $vals = ['business_id' => $biz, 'code' => $code, 'person_kind' => $kind,
            'first_name' => ($d['first_name'] ?? '') ?: null, 'last_name' => ($d['last_name'] ?? '') ?: null,
            'company_name' => ($d['company_name'] ?? '') ?: null, 'national_id' => ($d['national_id'] ?? '') ?: null,
            'economic_code' => ($d['economic_code'] ?? '') ?: null, 'email' => ($d['email'] ?? '') ?: null,
            'postal_code' => ($d['postal_code'] ?? '') ?: null, 'address' => ($d['address'] ?? '') ?: null,
            'notes' => ($d['notes'] ?? '') ?: null, 'phone' => ($d['phone'] ?? '') ?: null,
            'status' => 'active', 'is_active' => 1];
        $existing = Database::one('SELECT id FROM persons WHERE business_id=? AND code=? AND deleted_at IS NULL', [$biz, $code]);
        if ($existing && $mode === 'insert') throw new RuntimeException('کد «' . $code . '» قبلاً ثبت شده است.');
        if (!$existing && $mode === 'update') throw new RuntimeException('کد «' . $code . '» برای ویرایش پیدا نشد.');
        if ($dry) return [$existing['id'] ?? 0, (bool)$existing];

        if ($existing) {
            $set = []; $pr = [];
            foreach ($vals as $k => $v) { if ($k === 'business_id' || $k === 'code') continue; $set[] = "`$k`=?"; $pr[] = $v; }
            $set[] = 'updated_at=?'; $pr[] = now();
            $pr[] = $existing['id'];
            Database::run('UPDATE persons SET ' . implode(',', $set) . ' WHERE id=?', $pr);
            $pid = (int)$existing['id'];
        } else {
            $cols = array_keys($vals); $pr = array_values($vals);
            $cols[] = 'created_at'; $pr[] = now(); $cols[] = 'created_by'; $pr[] = Auth::id();
            Database::run('INSERT INTO persons (`' . implode('`,`', $cols) . '`) VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', $pr);
            $pid = (int)Database::pdo()->lastInsertId();
        }
        // موبایل در جدول تماس‌ها
        $mob = trim((string)($d['mobile'] ?? ''));
        if ($mob !== '') {
            Database::run('DELETE FROM person_contacts WHERE person_id=? AND contact_type IN ("mobile","phone")', [$pid]);
            Database::run('INSERT INTO person_contacts (person_id, contact_type, value, is_primary) VALUES (?,?,?,1)',
                [$pid, strlen(preg_replace('/\D/', '', $mob)) > 8 ? 'mobile' : 'phone', $mob]);
        }
        return [$pid, (bool)$existing];
    }

    /** ذخیرهٔ یک کالا/خدمت → [id, wasUpdate] */
    private function saveProduct(int $biz, array $d, string $mode, array &$seen, bool $dry): array
    {
        $code = trim((string)($d['code'] ?? ''));
        if ($code === '') throw new RuntimeException('کد کالا الزامی است.');
        $title = trim((string)($d['title'] ?? ''));
        if ($title === '') throw new RuntimeException('عنوان کالا الزامی است.');
        if (isset($seen['k:' . $code])) throw new RuntimeException('کد «' . $code . '» در همین فایل تکرار شده است.');
        $seen['k:' . $code] = 1;
        $itemType = strtolower(trim((string)($d['item_type'] ?? '')));
        $itemType = ['کالا' => 'goods', 'خدمت' => 'service', 'خدمات' => 'service', 'goods' => 'goods', 'service' => 'service'][$itemType]
            ?? (str_contains($title, 'خدم') || str_contains($title, 'مشاوره') ? 'service' : 'goods');
        $unitId = $this->unitId($biz, (string)($d['unit'] ?? ''));

        $existing = Database::one('SELECT id FROM products WHERE business_id=? AND code=? AND deleted_at IS NULL', [$biz, $code]);
        if ($existing && $mode === 'insert') throw new RuntimeException('کد «' . $code . '» قبلاً ثبت شده است.');
        if (!$existing && $mode === 'update') throw new RuntimeException('کد «' . $code . '» برای ویرایش پیدا نشد.');
        if ($dry) return [$existing['id'] ?? 0, (bool)$existing];

        $taxable = trim((string)($d['is_taxable'] ?? '1'));
        $vals = ['business_id' => $biz, 'code' => $code, 'title' => $title, 'item_type' => $itemType, 'main_unit_id' => $unitId,
            'is_taxable' => in_array($taxable, ['0', 'خیر', 'no', 'false'], true) ? 0 : 1,
            'status' => in_array(trim((string)($d['is_active'] ?? '1')), ['0', 'غیرفعال', 'inactive'], true) ? 'inactive' : 'active',
            'is_active' => 1];
        if ($existing) {
            $set = []; $pr = [];
            foreach ($vals as $k => $v) { if ($k === 'business_id') continue; $set[] = "`$k`=?"; $pr[] = $v; }
            $set[] = 'updated_at=?'; $pr[] = now(); $pr[] = $existing['id'];
            Database::run('UPDATE products SET ' . implode(',', $set) . ' WHERE id=?', $pr);
            $pid = (int)$existing['id'];
        } else {
            $cols = array_keys($vals); $pr = array_values($vals);
            $cols[] = 'created_at'; $pr[] = now(); $cols[] = 'created_by'; $pr[] = Auth::id();
            Database::run('INSERT INTO products (`' . implode('`,`', $cols) . '`) VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')', $pr);
            $pid = (int)Database::pdo()->lastInsertId();
        }
        // قیمت‌ها روی «نوع قیمت» پیش‌فرض فروش/خرید
        foreach ([['sale_price', 'sale'], ['buy_price', 'purchase']] as [$col, $slug]) {
            $v = trim((string)($d[$col] ?? ''));
            if ($v === '' || !is_numeric($v)) continue;
            $ptId = (int)Database::val('SELECT id FROM price_types WHERE business_id=? AND slug=? LIMIT 1', [$biz, $slug], 0);
            if (!$ptId) continue;
            $row = Database::one('SELECT id FROM product_prices WHERE product_id=? AND price_type_id=?', [$pid, $ptId]);
            if ($row) Database::run('UPDATE product_prices SET price=?, from_date=? WHERE id=?', [(float)$v, today(), (int)$row['id']]);
            else Database::run('INSERT INTO product_prices (business_id, product_id, price_type_id, currency_id, price, from_date, created_at, created_by) VALUES (?,?,?,?,?,?,?,?)',
                [$biz, $pid, $ptId, base_currency_id($biz), (float)$v, today(), now(), Auth::id()]);
        }
        return [$pid, (bool)$existing];
    }

    /** شناسهٔ واحد شمارش از عنوان (یا ساخت «عدد») */
    private function unitId(int $biz, string $title): int
    {
        $title = trim($title);
        if ($title !== '') {
            $id = (int)Database::val('SELECT id FROM units WHERE business_id=? AND title=? LIMIT 1', [$biz, $title], 0);
            if ($id) return $id;
            return (int)Database::insert('units', ['business_id' => $biz, 'title' => mb_substr($title, 0, 60), 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
        }
        $id = (int)Database::val('SELECT id FROM units WHERE business_id=? AND is_active=1 ORDER BY id LIMIT 1', [$biz], 0);
        if ($id) return $id;
        return (int)Database::insert('units', ['business_id' => $biz, 'title' => 'عدد', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
    }
}
