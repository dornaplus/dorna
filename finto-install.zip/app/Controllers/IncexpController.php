<?php
/** درآمد و هزینه: فرم چندردیفی با سند حسابداری خودکار */
final class IncexpController
{
    public function createExpense(array $p): string { return $this->form('expense', []); }
    public function createIncome(array $p): string { return $this->form('income', []); }
    public function formCreate(array $m, array $p): string { return $this->form($m['key'] === 'incomes' ? 'income' : 'expense', []); }
    public function formEdit(array $m, array $p): string
    {
        $kind = $m['key'] === 'incomes' ? 'income' : 'expense';
        $tbl = $kind === 'expense' ? 'expense_documents' : 'income_documents';
        $row = Database::one("SELECT * FROM `$tbl` WHERE id=? AND business_id=?", [(int)$p['id'], Auth::businessId()]);
        if (!$row) abort(404, 'سند یافت نشد.');
        if ($row['status'] === 'posted') { Flash::push('error', 'سند قطعی‌شده قابل ویرایش نیست؛ برای اصلاح، سند برگشتی ثبت کنید.'); redirect('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/'.$row['id']); }
        return $this->form($kind, $row);
    }
    private function form(string $kind, array $row): string
    {
        Auth::requireApp();
        $biz = Auth::businessId();
        $tbl = $kind === 'expense' ? 'expense_documents' : 'income_documents';
        $lineTbl = $kind === 'expense' ? 'expense_document_lines' : 'income_document_lines';
        $lines = $row ? Database::all("SELECT * FROM `$lineTbl` WHERE ".($kind === 'expense' ? 'expense_document_id' : 'income_document_id')."=? ORDER BY row_no", [$row['id']]) : [];
        $accKey = $kind === 'expense' ? 'expense_default' : 'other_income';
        $defaultAccount = (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$biz, $accKey], 0);
        return view('pages/incexp/form', ['title' => ($row ? 'ویرایش ' : 'ثبت ').($kind === 'expense' ? 'هزینه' : 'درآمد'), 'kind' => $kind, 'row' => $row, 'lines' => $lines,
            'categories' => Database::all('SELECT id,title,default_account_id FROM profit_loss_categories WHERE business_id=? AND kind=? AND is_active=1', [$biz, $kind]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 AND status="active" ORDER BY code', [$biz]),
            'persons' => Database::all('SELECT id, code, first_name, last_name, company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
            'cashAccounts' => Database::all('SELECT id,title,account_kind FROM cash_accounts WHERE business_id=? AND status="active"', [$biz]),
            'taxes' => Database::all('SELECT id,title,rate_percent FROM taxes WHERE business_id=? AND is_active=1', [$biz]),
            'projects' => Database::all('SELECT id,name FROM projects WHERE business_id=? AND status="active"', [$biz]),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1', [$biz]),
            'defaultAccount' => $defaultAccount,
            'action' => $row ? url('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/'.$row['id']) : url('app/'.($kind === 'expense' ? 'expenses' : 'incomes'))]);
    }
    public function storeExpense(array $p): string { return $this->save('expense'); }
    public function storeIncome(array $p): string { return $this->save('income'); }
    public function customSave(array $m, array $p, ?string $id): string { return $this->save($m['key'] === 'incomes' ? 'income' : 'expense'); }

    private function save(string $kind): string
    {
        Auth::requireApp(); csrf_verify();
        $biz = Auth::businessId();
        $title = (string)post('title');
        if (mb_strlen($title) < 2) { Flash::keep($_POST); Flash::push('error', 'عنوان سند را وارد کنید.'); redirect('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/create'); }
        $lines = [];
        foreach ((array)($_POST['line_amount'] ?? []) as $i => $amt) {
            $amt = fa_num($amt);
            if ($amt <= 0) continue;
            $taxId = !empty($_POST['line_tax_id'][$i]) ? (int)$_POST['line_tax_id'][$i] : null;
            $taxAmount = 0.0;
            if ($taxId) { $t = Database::one('SELECT rate_percent FROM taxes WHERE id=?', [$taxId]); if ($t) $taxAmount = round($amt * (float)$t['rate_percent'] / 100, 2); }
            $lines[] = ['title' => $_POST['line_title'][$i] ?? $title, 'account_id' => !empty($_POST['line_account_id'][$i]) ? (int)$_POST['line_account_id'][$i] : null,
                'cost_center_id' => !empty($_POST['line_cost_center_id'][$i]) ? (int)$_POST['line_cost_center_id'][$i] : null,
                'tax_id' => $taxId, 'amount' => $amt, 'tax_amount' => $taxAmount];
        }
        if (!$lines) { Flash::keep($_POST); Flash::push('error', 'حداقل یک ردیف با مبلغ بزرگ‌تر از صفر لازم است.'); redirect('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/create'); }
        try {
            $id = Trade::createExpenseOrIncome($kind, [
                'title' => $title, 'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'person_id' => post('person_id') ? (int)post('person_id') : null,
                'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'category_id' => post('category_id') ? (int)post('category_id') : null,
                'account_id' => post('account_id') ? (int)post('account_id') : null,
                'project_id' => post('project_id') ? (int)post('project_id') : null,
                'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null,
                'settlement_type' => post('cash_account_id') ? 'cash' : 'credit',
                'refundable' => (string)post('refundable', 'no'), 'description' => (string)post('description') ?: null,
            ], $lines);
            Audit::log($kind === 'expense' ? 'create_expense' : 'create_income', $kind === 'expense' ? 'expenses' : 'incomes', (int)$id,
                'ثبت سند '.($kind === 'expense' ? 'هزینه' : 'درآمد').' '.$title);
            Flash::push('success', 'سند '.($kind === 'expense' ? 'هزینه' : 'درآمد').' ثبت و سند حسابداری آن صادر شد.');
            Flash::clearOld();
            redirect('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/'.$id);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', 'خطا در ثبت سند: '.$e->getMessage()); redirect('app/'.($kind === 'expense' ? 'expenses' : 'incomes').'/create'); }
        return '';
    }
}
