<?php
/** جست‌وجوی درون‌برنامه‌ای برای انتخابگرها و جست‌وجوی سریع نوار بالا */
final class LookupController
{
    public function options(array $p): string
    {
        Auth::requireApp();
        header('Content-Type: application/json; charset=utf-8');
        $table = (string)$p['table'];
        if (!in_array($table, Schema::tables(), true)) { echo json_encode(['ok' => false, 'error' => 'table'], JSON_UNESCAPED_UNICODE); return ''; }
        $q = (string)($_GET['q'] ?? '');
        $scope = [];
        // محدودسازی چندمستأجری برای جدول‌های دارای business_id
        if (isset(Schema::columns($table)['business_id'])) $scope['business_id'] = Auth::businessId();
        echo json_encode(['ok' => true, 'items' => Schema::options($table, $q, 50, $scope)], JSON_UNESCAPED_UNICODE);
        return '';
    }

    public function quickSearch(array $p): string
    {
        Auth::requireApp();
        header('Content-Type: application/json; charset=utf-8');
        $q = trim((string)($_GET['q'] ?? ''));
        $biz = Auth::businessId();
        $out = [];
        if (mb_strlen($q) >= 2) {
            $like = '%'.$q.'%';
            $map = [
                'فاکتور' => ['invoices', 'invoice_no', 'app/invoices/%d'],
                'شخص' => ['persons', 'code', 'app/persons/%d'],
                'کالا' => ['products', 'title', 'app/products/%d'],
                'سند' => ['journal_entries', 'entry_no', 'app/journal/%d'],
                'دریافت' => ['receipts', 'doc_no', 'app/receipts/%d'],
                'پرداخت' => ['payments', 'doc_no', 'app/payments/%d'],
                'چک' => ['cheques', 'cheque_no', 'app/cheques/%d'],
            ];
            foreach ($map as $label => [$table, $col, $route]) {
                // هر گروه مستقل و محافظت‌شده است تا خطای یک جدول، کل جست‌وجو را از کار نیندازد
                try {
                    $hasDel = isset(Schema::columns($table)['deleted_at']);
                    $rows = Database::all("SELECT id, `$col` AS text FROM `$table` WHERE business_id=? " . ($hasDel ? 'AND deleted_at IS NULL ' : '') . "AND CAST(`$col` AS CHAR) LIKE ? LIMIT 5", [$biz, $like]);
                    foreach ($rows as $r) if ((string)$r['text'] !== '') $out[] = ['group' => $label, 'text' => (string)$r['text'], 'url' => url(sprintf($route, $r['id']))];
                } catch (Throwable $e) { /* این گروه رد می‌شود */ }
            }
            // اشخاص با نام/نام شرکت (محافظت‌شده)
            try {
                $hasDel = isset(Schema::columns('persons')['deleted_at']);
                $rows = Database::all('SELECT id, CONCAT(IFNULL(first_name,"")," ",IFNULL(last_name,""), IFNULL(company_name,"")) AS text FROM persons WHERE business_id=? ' . ($hasDel ? 'AND deleted_at IS NULL ' : '') . 'AND (first_name LIKE ? OR last_name LIKE ? OR company_name LIKE ?) LIMIT 5', [$biz, $like, $like, $like]);
                foreach ($rows as $r) if (trim((string)$r['text']) !== '') $out[] = ['group' => 'شخص', 'text' => trim((string)$r['text']), 'url' => url('app/persons/'.$r['id'])];
            } catch (Throwable $e) { /* اشخاص رد می‌شود */ }
        }
        echo json_encode(['ok' => true, 'items' => $out], JSON_UNESCAPED_UNICODE);
        return '';
    }
}
