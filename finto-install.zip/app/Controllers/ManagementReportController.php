<?php
/** گزارش مدیریتی خودکار ماهانه (AI) */
final class ManagementReportController
{
    private function guard(): void { Auth::requireApp(); if (!Auth::can('reports.view') && !Auth::isAdmin()) abort(403, 'مجوز مشاهده ندارید.'); }

    public function index(array $p): string
    {
        $this->guard();
        $period = ManagementReport::currentPeriod();
        $hasCurrent = ManagementReport::exists($period);
        return view('pages/reports/management', [
            'title' => 'گزارش مدیریتی', 'reports' => ManagementReport::list(),
            'currentPeriod' => $period, 'hasCurrent' => $hasCurrent,
        ]);
    }

    public function generate(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            $id = ManagementReport::generate();
            Audit::log('generate', 'management_reports', $id, 'تولید گزارش مدیریتی ماهانه');
            Flash::push('success', 'گزارش مدیریتی تولید شد.');
            redirect('app/management-reports/' . $id);
        } catch (Throwable $e) {
            Flash::push('error', 'خطا در تولید گزارش: ' . $e->getMessage());
            redirect('app/management-reports');
        }
        return '';
    }

    public function show(array $p): string
    {
        $this->guard();
        $r = ManagementReport::get((int)$p['id']);
        if (!$r) abort(404, 'گزارش یافت نشد.');
        return view('pages/reports/management_show', ['title' => $r['title'], 'r' => $r]);
    }
}
