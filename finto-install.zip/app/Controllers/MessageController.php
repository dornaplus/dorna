<?php
/**
 * پیام‌رسان داخلی کاربران — گفت‌وگوی دو‌نفره، ارسال فایل و اعلان پیام‌ها در هدر.
 */
final class MessageController
{
    private function guard(): void { Auth::requireApp(); }

    private function json(array $d): string
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($d, JSON_UNESCAPED_UNICODE);
        return '';
    }

    /* ───────────── صفحهٔ پیام‌ها ───────────── */
    public function index(array $p): string
    {
        $this->guard();
        $me = (int)Auth::id();
        $q = trim((string)($_GET['q'] ?? ''));
        $threadId = (int)($_GET['t'] ?? 0);
        $thread = $threadId ? Messages::thread($threadId) : null;
        if ($threadId && !Messages::canAccess($thread)) { Flash::push('error', 'دسترسی به این گفت‌وگو ندارید.'); redirect('app/messages'); }

        // شروع گفت‌وگو با یک همکار
        $to = (int)($_GET['u'] ?? 0);
        if (!$thread && $to) {
            $t = Messages::threadWith($to);
            if ($t) redirect('app/messages?t=' . (int)$t['id']);
        }

        $rows = $thread ? Messages::messages((int)$thread['id']) : [];
        $att = Messages::attachmentsOf(array_column($rows, 'id'));
        if ($thread) Messages::markRead($me, (int)$thread['id']);

        $openEvents = [];
        if ($thread) {
            $openEvents = Planner::events(date('Y-m-d', strtotime(today() . ' -30 days')), date('Y-m-d', strtotime(today() . ' +180 days')),
                ['status' => ['open', 'in_progress']]);
        }
        return view('pages/messages/index', [
            'title' => 'پیام‌ها', 'threads' => Messages::threads($me, $q), 'thread' => $thread,
            'messages' => $rows, 'attachments' => $att, 'q' => $q,
            'colleagues' => Messages::colleagues($me), 'unread' => Messages::unreadTotal($me),
            'searchResults' => $q !== '' ? Messages::search($me, $q) : [],
            'members' => $thread ? Messages::members((int)$thread['id']) : [],
            'openEvents' => $openEvents,
        ]);
    }

    /* ───────────── ارسال پیام ───────────── */
    public function send(array $p): string
    {
        $this->guard(); csrf_verify();
        $threadId = (int)post('thread_id');
        $ajax = (string)post('ajax') === '1';
        try {
            if (!$threadId) {
                $t = Messages::threadWith((int)post('to_user_id'));
                if (!$t) throw new RuntimeException('کاربر مقصد را انتخاب کنید.');
                $threadId = (int)$t['id'];
            }
            $files = [];
            if (!empty($_FILES['files']) && is_array($_FILES['files']['name'])) {
                $n = count($_FILES['files']['name']);
                for ($i = 0; $i < min($n, Messages::MAX_FILES); $i++) {
                    $files[] = ['name' => $_FILES['files']['name'][$i], 'type' => $_FILES['files']['type'][$i] ?? '',
                        'tmp_name' => $_FILES['files']['tmp_name'][$i], 'error' => $_FILES['files']['error'][$i], 'size' => $_FILES['files']['size'][$i]];
                }
            } elseif (!empty($_FILES['file'])) {
                $files[] = $_FILES['file'];
            }
            $res = Messages::send($threadId, (string)post('body'), $files);
            if ($ajax) {
                $rows = Messages::since($threadId, max(0, (int)post('after', 0)));
                return $this->json(['ok' => true, 'id' => $res['id'], 'files' => $res['files'], 'thread' => $threadId,
                    'html' => $this->renderMessages($rows)]);
            }
            Flash::push('success', $res['files'] > 0 ? 'پیام و فایل ارسال شد.' : 'پیام ارسال شد.');
        } catch (Throwable $e) {
            if ($ajax) return $this->json(['ok' => false, 'error' => $e->getMessage()]);
            Flash::push('error', $e->getMessage());
        }
        redirect('app/messages?t=' . $threadId);
        return '';
    }

    /** رندر HTML پیام‌ها (برای ارسال/به‌روزرسانی زنده) */
    private function renderMessages(array $rows): string
    {
        if (!$rows) return '';
        return view('partials/pm_messages', ['rows' => $rows, 'att' => Messages::attachmentsOf(array_column($rows, 'id')),
            'openEvents' => Planner::events(date('Y-m-d', strtotime(today() . ' -30 days')), date('Y-m-d', strtotime(today() . ' +180 days')), ['status' => ['open', 'in_progress']])]);
    }

    /* ───────────── گروه جدید ───────────── */
    public function groupCreate(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            $id = Messages::createGroup((string)post('title'), (array)($_POST['members'] ?? []));
            Flash::push('success', 'گروه ساخته شد.');
            redirect('app/messages?t=' . $id);
        } catch (Throwable $e) {
            Flash::push('error', $e->getMessage());
            redirect('app/messages');
        }
        return '';
    }

    /* ───────────── افزودن پیام/فایل به رویداد پلنر ───────────── */
    public function toEvent(array $p): string
    {
        $this->guard(); csrf_verify();
        $threadId = (int)post('thread_id');
        $ajax = (string)post('ajax') === '1';
        try {
            $res = Messages::toEvent((int)post('message_id'), (int)post('event_id'));
            $msg = ($res['files'] > 0 ? num($res['files']) . ' فایل' : '') . ($res['files'] > 0 && $res['text'] ? ' و ' : '') . ($res['text'] ? 'متن پیام' : '') . ' به پروندهٔ رویداد افزوده شد.';
            if ($ajax) return $this->json(['ok' => true, 'files' => $res['files'], 'text' => $res['text'], 'message' => $msg]);
            Flash::push('success', $msg);
        } catch (Throwable $e) {
            if ($ajax) return $this->json(['ok' => false, 'error' => $e->getMessage()]);
            Flash::push('error', $e->getMessage());
        }
        redirect($threadId ? 'app/messages?t=' . $threadId : 'app/messages');
        return '';
    }

    /* ───────────── خوراک هدر ───────────── */
    public function feed(array $p): string
    {
        $this->guard();
        return $this->json(['ok' => true] + Messages::feed());
    }

    /** به‌روزرسانی زندهٔ گفت‌وگو */
    public function poll(array $p): string
    {
        $this->guard();
        $threadId = (int)($_GET['t'] ?? 0);
        $after = (int)($_GET['after'] ?? 0);
        $t = Messages::thread($threadId);
        if (!Messages::canAccess($t)) return $this->json(['ok' => false, 'error' => 'دسترسی ندارید.']);
        $rows = Messages::since($threadId, $after);
        if ($rows) Messages::markRead((int)Auth::id(), $threadId);
        return $this->json(['ok' => true, 'html' => $this->renderMessages($rows), 'last' => $rows ? (int)end($rows)['id'] : $after,
            'unread' => Messages::unreadTotal()]);
    }

    /* ───────────── خوانده‌شدن ───────────── */
    public function read(array $p): string
    {
        $this->guard(); csrf_verify();
        $threadId = (int)post('thread_id');
        $t = Messages::thread($threadId);
        if (Messages::canAccess($t)) Messages::markRead((int)Auth::id(), $threadId);
        return $this->json(['ok' => true, 'unread' => Messages::unreadTotal()]);
    }

    /* ───────────── دریافت فایل ───────────── */
    public function file(array $p): string
    {
        $this->guard();
        $a = Messages::attachment((int)$p['id']);
        if (!$a) { http_response_code(404); exit('فایل یافت نشد.'); }
        $m = Database::one('SELECT * FROM pm_messages WHERE id=?', [(int)$a['message_id']]);
        $t = $m ? Messages::thread((int)$m['thread_id']) : null;
        if (!Messages::canAccess($t)) { http_response_code(403); exit('دسترسی به این فایل ندارید.'); }
        $path = Messages::attachmentPath($a);
        if (!is_file($path)) { http_response_code(404); exit('فایل روی سرور موجود نیست.'); }
        $inline = str_starts_with((string)$a['mime_type'], 'image/') || (string)$a['mime_type'] === 'application/pdf';
        if (headers_sent()) exit('خطا در ارسال فایل.');
        header('Content-Type: ' . (string)$a['mime_type']);
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . rawurlencode((string)$a['file_name']) . '"');
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    public function deleteFile(array $p): string
    {
        $this->guard(); csrf_verify();
        $t = (int)post('thread_id');
        try { Messages::deleteAttachment((int)$p['id']); Flash::push('success', 'فایل حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect($t ? 'app/messages?t=' . $t : 'app/messages');
        return '';
    }
}
