<?php
/**
 * اعلان‌های درون‌برنامه‌ای — سررسید فاکتورها و چک‌ها (۳/۲/۱ روز قبل و معوق) + هشدار موجودی.
 * وضعیت «خوانده‌شده» و «حذف‌شده» برای هر کاربر جداگانه در جدول notification_states ذخیره می‌شود؛
 * پس حذف‌کردن یک اعلان توسط یک کاربر، آن را برای کاربران دیگر پنهان نمی‌کند.
 */
final class NotificationController
{
    /** وضعیت اعلان‌های همین کاربر: کلید ⇒ ['read'=>bool,'dismissed'=>bool] */
    private static function states(int $biz, int $uid): array
    {
        $out = [];
        foreach (Database::all('SELECT notif_key, read_at, dismissed_at FROM notification_states WHERE business_id=? AND user_id=?', [$biz, $uid]) as $r) {
            $out[(string)$r['notif_key']] = ['read' => $r['read_at'] !== null, 'dismissed' => $r['dismissed_at'] !== null];
        }
        return $out;
    }

    private static function mark(int $biz, int $uid, string $key, string $mode): void
    {
        if ($biz <= 0 || $uid <= 0 || $key === '') return;
        $key = mb_substr($key, 0, 80);
        $row = Database::one('SELECT id FROM notification_states WHERE business_id=? AND user_id=? AND notif_key=?', [$biz, $uid, $key]);
        $set = match ($mode) {
            'read'      => 'read_at=NOW(), dismissed_at=NULL',
            'unread'    => 'read_at=NULL',
            'dismiss'   => 'read_at=NOW(), dismissed_at=NOW()',
            'restore'   => 'dismissed_at=NULL',
            default     => 'read_at=NOW()',
        };
        if ($row) Database::run("UPDATE notification_states SET $set WHERE id=?", [(int)$row['id']]);
        else Database::run("INSERT INTO notification_states (business_id, user_id, notif_key, read_at, dismissed_at) VALUES (?,?,?,"
            . ($mode === 'dismiss' ? 'NOW(), NOW()' : ($mode === 'unread' ? 'NULL, NULL' : 'NOW(), NULL')) . ')', [$biz, $uid, $key]);
    }

    public function feed(array $p): string
    {
        Auth::requireApp();
        header('Content-Type: application/json; charset=utf-8');
        $biz = Auth::businessId();
        $uid = (int)Auth::id();
        $items = self::collect((int)$biz);

        /* ── اعمال وضعیت همین کاربر ── */
        $st = self::states((int)$biz, $uid);
        $items = array_values(array_filter($items, fn($i) => empty($st[$i['id']]['dismissed'])));
        foreach ($items as &$it) $it['read'] = !empty($st[$it['id']]['read']);
        unset($it);

        $urgent = array_values(array_filter($items, fn($i) => !$i['read'] && $i['days'] !== null && (int)$i['days'] <= 1));
        echo json_encode(['ok' => true, 'count' => count($items), 'urgent' => count($urgent), 'items' => $items], JSON_UNESCAPED_UNICODE);
        return '';
    }

    private static function pcType(string $t): string
    {
        return ['charge' => 'شارژ تنخواه', 'expense' => 'هزینه از تنخواه', 'refund' => 'برگشت هزینه', 'settle' => 'تسویه تنخواه'][$t] ?? 'سند تنخواه';
    }

    /** خواندن وضعیت (برای همگام‌سازی نشانک زنگ) */
    public function status(array $p): string
    {
        Auth::requireApp();
        header('Content-Type: application/json; charset=utf-8');
        $biz = (int)Auth::businessId(); $uid = (int)Auth::id();
        $items = self::collect($biz);
        $st = self::states($biz, $uid);
        $unread = 0; $total = 0;
        foreach ($items as $i) {
            if (!empty($st[$i['id']]['dismissed'])) continue;
            $total++;
            if (empty($st[$i['id']]['read'])) $unread++;
        }
        echo json_encode(['ok' => true, 'count' => $total, 'unread' => $unread], JSON_UNESCAPED_UNICODE);
        return '';
    }

    /** خوانده‌شده / خوانده‌نشده / حذف / بازگردانی یک اعلان */
    public function state(array $p): string
    {
        Auth::requireApp();
        csrf_verify();
        $biz = (int)Auth::businessId(); $uid = (int)Auth::id();
        $key  = (string)post('key');
        $mode = (string)post('mode', 'read');
        if ($key === '' || !in_array($mode, ['read', 'unread', 'dismiss', 'restore'], true)) {
            http_response_code(422);
            echo json_encode(['ok' => false, 'error' => 'درخواست نامعتبر'], JSON_UNESCAPED_UNICODE);
            return '';
        }
        self::mark($biz, $uid, $key, $mode);
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $items = self::collect($biz); $st = self::states($biz, $uid);
            $unread = 0; $total = 0;
            foreach ($items as $i) { if (!empty($st[$i['id']]['dismissed'])) continue; $total++; if (empty($st[$i['id']]['read'])) $unread++; }
            echo json_encode(['ok' => true, 'unread' => $unread, 'count' => $total], JSON_UNESCAPED_UNICODE);
            return '';
        }
        redirect('app');
        return '';
    }

    /** همه را خوانده‌شده / حذف کن (فقط برای همین کاربر) */
    public function all(array $p): string
    {
        Auth::requireApp();
        csrf_verify();
        $biz = (int)Auth::businessId(); $uid = (int)Auth::id();
        $mode = (string)post('mode', 'read');           // read | dismiss
        if (!in_array($mode, ['read', 'dismiss'], true)) $mode = 'read';
        $st = self::states($biz, $uid);
        $n = 0;
        foreach (self::collect($biz) as $it) {
            if (!empty($st[$it['id']]['dismissed'])) continue;
            if ($mode === 'read' && !empty($st[$it['id']]['read'])) continue;
            self::mark($biz, $uid, (string)$it['id'], $mode);
            $n++;
        }
        if ((string)post('ajax') === '1') {
            header('Content-Type: application/json; charset=utf-8');
            $items = self::collect($biz); $st2 = self::states($biz, $uid);
            $unread = 0; $total = 0;
            foreach ($items as $i) { if (!empty($st2[$i['id']]['dismissed'])) continue; $total++; if (empty($st2[$i['id']]['read'])) $unread++; }
            echo json_encode(['ok' => true, 'mode' => $mode, 'changed' => $n, 'unread' => $unread, 'count' => $total], JSON_UNESCAPED_UNICODE);
            return '';
        }
        Flash::push('success', $mode === 'dismiss'
            ? ($n > 0 ? num($n) . ' اعلان حذف شد.' : 'اعلانی برای حذف نبود.')
            : ($n > 0 ? num($n) . ' اعلان خوانده‌شده علامت خورد.' : 'اعلان خوانده‌نشده‌ای نبود.'));
        redirect('app');
        return '';
    }

    /** ساخت فهرست اعلان‌های کسب‌وکار (بدون وضعیت کاربر) */
    private static function collect(int $biz): array
    {
        $items = [];
        // دسترسی کاربر جاری برای پنهان‌کردن اعلان‌هایی که فهرستشان برای او مسدود است
        $canInv = Auth::id() && Auth::can('invoices.view');
        $canChq = Auth::id() && Auth::can('cheques.view');
        $canPer = Auth::id() && Auth::can('persons.view');
        $canRep = Auth::id() && Auth::can('reports.view');

        /* ── فاکتورهای فروش/خرید نزدیک سررسید یا معوق ── */
        foreach (Database::all(
            "SELECT i.id, i.invoice_no, i.invoice_type, i.remaining_amount,
                    IFNULL(i.due_date, i.invoice_date) AS due,
                    DATEDIFF(IFNULL(i.due_date, i.invoice_date), CURDATE()) AS d,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who
               FROM invoices i LEFT JOIN persons p ON p.id = i.person_id
              WHERE i.business_id = ? AND i.status NOT IN ('draft','cancelled') AND i.remaining_amount > 0
                AND IFNULL(i.due_date, i.invoice_date) <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
              ORDER BY d ASC LIMIT 25", [$biz]) as $r) {
            $d = (int)$r['d'];
            $items[] = [
                'id'       => 'inv' . $r['id'],
                'kind'     => 'invoice',
                'severity' => $d < 0 ? 'danger' : ($d <= 1 ? 'danger' : 'warn'),
                'days'     => $d,
                'when'     => self::whenLabel($d),
                'title'    => ($r['invoice_type'] === 'buy' ? 'فاکتور خرید ' : 'فاکتور فروش ') . $r['invoice_no'],
                'desc'     => trim((string)$r['who']) . ' — مانده ' . money($r['remaining_amount']) . ' — سررسید ' . jdate($r['due']),
                'url'      => url('app/invoices/' . $r['id']),
                'icon'     => icon('receipt', 17),
            ];
        }

        /* ── چک‌های نزدیک سررسید یا معوق ── */
        foreach (Database::all(
            "SELECT c.id, c.cheque_no, c.direction, c.amount, c.due_date, c.bank_name, DATEDIFF(c.due_date, CURDATE()) AS d,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who
               FROM cheques c LEFT JOIN persons p ON p.id = c.person_id
              WHERE c.business_id = ? AND c.status IN ('in_hand','deposited')
                AND c.due_date <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
              ORDER BY d ASC LIMIT 25", [$biz]) as $r) {
            $d = (int)$r['d'];
            $dir = $r['direction'] === 'issued' ? 'چک پرداختی' : 'چک دریافتی';
            $items[] = [
                'id'       => 'chq' . $r['id'],
                'kind'     => 'cheque',
                'severity' => $d < 0 ? 'danger' : ($d <= 1 ? 'danger' : 'warn'),
                'days'     => $d,
                'when'     => self::whenLabel($d),
                'title'    => $dir . ' ' . $r['cheque_no'],
                'desc'     => ($r['bank_name'] ? $r['bank_name'] . ' — ' : '') . 'مبلغ ' . money($r['amount']) . ' — سررسید ' . jdate($r['due_date'])
                              . (trim((string)$r['who']) !== '' ? ' — ' . trim((string)$r['who']) : ''),
                'url'      => url('app/cheques/' . $r['id']),
                'icon'     => icon('cheque', 17),
            ];
        }

        /* ── حذف اعلان‌هایی که فهرستشان برای این کاربر مجاز نیست ── */
        $items = array_values(array_filter($items, function ($i) use ($canInv, $canChq, $canPer, $canRep) {
            $k = (string)($i['kind'] ?? '');
            if ($k === 'invoice') return $canInv;
            if ($k === 'cheque') return $canChq;
            if ($k === 'followup') return $canPer;
            if ($k === 'payment_receipt') return $canInv;
            if ($k === 'management_report' || $k === 'anomaly') return $canRep;
            return true;
        }));

        /* ── تنخواه گردان: درخواست‌های در انتظار تأیید + هشدار موجودی تنخواه ── */
        if (Auth::id() && Auth::can('petty_cash.view')) {
            $canApprove = Auth::can('petty_cash.approve');
            if ($canApprove) {
                foreach (Database::all("SELECT e.id, e.doc_no, e.title, e.amount, e.entry_type, f.title AS fund_title, u.full_name AS who
                                          FROM petty_cash_entries e JOIN petty_cash_funds f ON f.id=e.fund_id
                                          LEFT JOIN users u ON u.id=e.requested_by
                                         WHERE e.business_id=? AND e.is_active=1 AND e.status='pending'
                                         ORDER BY e.id DESC LIMIT 15", [$biz]) as $r) {
                    $items[] = [
                        'id' => 'pcr' . $r['id'], 'kind' => 'pettycash', 'severity' => 'warn', 'days' => null, 'when' => 'در انتظار تأیید',
                        'title' => 'درخواست ' . self::pcType((string)$r['entry_type']) . ' ' . $r['fund_title'],
                        'desc'  => $r['title'] . ' — مبلغ ' . money($r['amount']) . ($r['who'] ? ' — ثبت: ' . $r['who'] : ''),
                        'url'   => url('app/petty-cash/' . (int)$r['id']), 'icon' => icon('wallet', 17),
                    ];
                }
            }
            // هشدار کمبود موجودی تنخواه (برای تنخواه‌دار و مدیران)
            foreach (PettyCash::visibleFunds(true) as $f) {
                if (empty($f['low'])) continue;
                $items[] = [
                    'id' => 'pcf' . (int)$f['id'], 'kind' => 'pettycash', 'severity' => 'danger', 'days' => null, 'when' => 'کمبود موجودی',
                    'title' => 'موجودی تنخواه کم است: ' . $f['title'],
                    'desc'  => 'ماندهٔ فعلی ' . money($f['balance']) . ' — حد هشدار ' . money($f['low_balance_amount']),
                    'url'   => url('app/petty-cash/funds'), 'icon' => icon('wallet', 17),
                ];
            }
            // نتیجهٔ درخواست‌های خودِ کاربر (تأیید/رد در ۷ روز گذشته)
            $uid = (int)Auth::id();
            foreach (Database::all("SELECT e.id, e.doc_no, e.title, e.amount, e.status, e.reject_reason, f.title AS fund_title
                                      FROM petty_cash_entries e JOIN petty_cash_funds f ON f.id=e.fund_id
                                     WHERE e.business_id=? AND e.is_active=1 AND e.requested_by=?
                                       AND e.status IN ('approved','rejected') AND e.approved_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                                     ORDER BY e.approved_at DESC LIMIT 10", [$biz, $uid]) as $r) {
                $okc = (string)$r['status'] === 'approved';
                $items[] = [
                    'id' => 'pcs' . (int)$r['id'], 'kind' => 'pettycash', 'severity' => $okc ? 'info' : 'danger', 'days' => null,
                    'when' => $okc ? 'تأیید شد' : 'رد شد',
                    'title' => ($okc ? 'درخواست تنخواه شما تأیید شد' : 'درخواست تنخواه شما رد شد') . ' — ' . $r['fund_title'],
                    'desc'  => $r['title'] . ' — ' . money($r['amount']) . (!$okc && $r['reject_reason'] ? ' — دلیل: ' . $r['reject_reason'] : ''),
                    'url'   => url('app/petty-cash/' . (int)$r['id']), 'icon' => icon('wallet', 17),
                ];
            }
        }

        /* ── کمبود موجودی انبار ── */
        $low = (int)Database::val('SELECT COUNT(*) FROM v_low_stock WHERE business_id=?', [$biz], 0);
        if ($low > 0) {
            $items[] = [
                'id'   => 'stock-low',
                'kind' => 'stock', 'severity' => 'info', 'days' => null, 'when' => '',
                'title' => $low . ' کالا زیر نقطهٔ سفارش',
                'desc'  => 'برای جلوگیری از کمبود، سفارش خرید ثبت کنید.',
                'url'   => url('app/reports/low_stock'),
                'icon'  => icon('box', 17),
            ];
        }

        /* ── برنامه‌ریز: وظایف نزدیک سررسید / معوق (برای مسئول و سازنده؛ مدیر همه را می‌بیند) ── */
        $uid = (int)Auth::id();
        $all = Planner::canManageAll();
        $pst = Planner::settings((int)$biz);
        $dueIds = [];
        foreach (Planner::dueSoon((int)$biz, $uid, max(1, (int)$pst['reminder_days']), $all) as $r) {
            $d = (int)$r['d'];
            $dueIds[(int)$r['id']] = true;
            $due = (string)($r['end_date'] ?: $r['start_date']);
            $items[] = [
                'id'       => 'pln' . $r['id'],
                'kind'     => 'planner',
                'severity' => $d < 0 ? 'danger' : ($d <= 1 ? 'danger' : 'warn'),
                'days'     => $d,
                'when'     => self::whenLabel($d),
                'title'    => ($d < 0 ? 'وظیفهٔ عقب‌افتاده: ' : 'وظیفه: ') . $r['title'],
                'desc'     => (!empty($r['who']) ? 'مسئول: ' . $r['who'] . ' — ' : '') . 'سررسید ' . jdate($due)
                              . ($r['status'] === 'in_progress' ? ' — در جریان' : ''),
                'url'      => url('app/planner?open=' . (int)$r['id']),
                'icon'     => icon('calendar', 17),
                'pin'      => 1,
            ];
        }
        // وظایف تازه‌ای که به همین کاربر سپرده شده‌اند
        foreach (Planner::assignedRecently((int)$biz, $uid, 7) as $r) {
            if (!empty($dueIds[(int)$r['id']])) continue;   // اگر همین حالا سررسیدش نزدیک است، تکرار نشود
            $items[] = [
                'id'       => 'pla' . (int)$r['id'],
                'kind'     => 'planner',
                'severity' => ((string)$r['priority'] === 'urgent' || (string)$r['priority'] === 'high') ? 'warn' : 'info',
                'days'     => null, 'when' => 'جدید',
                'title'    => 'وظیفهٔ جدید برای شما: ' . $r['title'],
                'desc'     => (!empty($r['who']) ? 'از طرف ' . $r['who'] . ' — ' : '')
                              . 'از ' . jdate((string)$r['start_date']) . (!empty($r['end_date']) ? ' تا ' . jdate((string)$r['end_date']) : ''),
                'url'      => url('app/planner?open=' . (int)$r['id']),
                'icon'     => icon('calendar', 17),
                'pin'      => 1,
            ];
        }
        if (!empty($pst['notify_manager'])) {
            foreach (Planner::recentlyClosed((int)$biz, $uid, $all) as $r) {
                $ok = ((string)$r['status'] === 'done');
                $items[] = [
                    'id'       => 'plr' . (int)$r['id'] . (int)strtotime((string)$r['completed_at']),
                    'kind'     => 'planner',
                    'severity' => $ok ? 'info' : 'danger',
                    'days'     => null, 'when' => '',
                    'title'    => ($ok ? 'وظیفه انجام شد: ' : 'وظیفه انجام نشد: ') . $r['title'],
                    'desc'     => (!empty($r['who']) ? 'توسط ' . $r['who'] : '') . (!empty($r['completion_note']) ? ' — ' . $r['completion_note'] : ''),
                    'url'      => url('app/planner?open=' . (int)$r['id']),
                    'icon'     => icon('check', 17),
                    'pin'      => 1,
                ];
            }
        }

        /* ── CRM: پیگیری‌های باز مشتریان نزدیک سررسید یا معوق (پروندهٔ ۳۶۰) ── */
        foreach (Database::all(
            "SELECT a.id, a.subject, a.due_at, a.happened_at, a.person_id,
                    DATEDIFF(IFNULL(a.due_at, a.happened_at), CURDATE()) AS d,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who
               FROM person_activities a LEFT JOIN persons p ON p.id = a.person_id
              WHERE a.business_id = ? AND a.deleted_at IS NULL AND a.activity_type='followup' AND a.is_done=0
                AND a.due_at IS NOT NULL AND a.due_at <= DATE_ADD(CURDATE(), INTERVAL 3 DAY)
              ORDER BY d ASC LIMIT 25", [$biz]) as $r) {
            $d = (int)$r['d'];
            $items[] = [
                'id'       => 'fu' . (int)$r['id'],
                'kind'     => 'followup',
                'severity' => $d < 0 ? 'danger' : 'warn',
                'days'     => $d,
                'when'     => self::whenLabel($d),
                'title'    => ($d < 0 ? 'پیگیری عقب‌افتاده: ' : 'پیگیری مشتری: ') . $r['subject'],
                'desc'     => trim((string)$r['who']) . ' — سررسید پیگیری ' . jdate($r['due_at']),
                'url'      => url('app/persons/' . (int)$r['person_id']),
                'icon'     => icon('clock', 17),
            ];
        }

        /* ── پورتال مشتری: رسیدهای پرداخت در انتظار تأیید ── */
        foreach (Database::all(
            "SELECT r.id, r.invoice_id, r.amount, r.created_at, i.invoice_no,
                    TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS who
               FROM customer_payment_receipts r
               JOIN invoices i ON i.id = r.invoice_id
               JOIN persons p ON p.id = r.person_id
              WHERE r.business_id = ? AND r.status = 'pending'
              ORDER BY r.id DESC LIMIT 10", [$biz]) as $r) {
            $items[] = [
                'id'       => 'cpr' . (int)$r['id'],
                'kind'     => 'payment_receipt',
                'severity' => 'warn',
                'days'     => null, 'when' => 'در انتظار تأیید',
                'title'    => 'رسید پرداخت مشتری — ' . $r['invoice_no'],
                'desc'     => trim((string)$r['who']) . ' — فاکتور ' . $r['invoice_no'],
                'url'      => url('app/invoices/' . (int)$r['invoice_id']),
                'icon'     => icon('wallet', 17),
            ];
        }

        /* ── گزارش مدیریتی ماه آماده ── */
        $curPeriod = ManagementReport::currentPeriod();
        $mr = ManagementReport::latest($biz);
        if ($mr && $mr['period'] === $curPeriod) {
            $items[] = [
                'id'       => 'mgmt-' . $curPeriod,
                'kind'     => 'management_report',
                'severity' => 'info',
                'days'     => null, 'when' => 'جدید',
                'title'    => 'گزارش مدیریتی ماه آماده است',
                'desc'     => $mr['title'] . ' — برای مشاهده کلیک کنید',
                'url'      => url('app/management-reports/' . (int)$mr['id']),
                'icon'     => icon('spark', 17),
            ];
        }

        /* ── ناهنجاری‌های اسناد ── */
        $anomalyCount = Anomaly::total($biz);
        if ($anomalyCount > 0) {
            $items[] = [
                'id'       => 'anomalies',
                'kind'     => 'anomaly',
                'severity' => 'warn',
                'days'     => null, 'when' => '',
                'title'    => num($anomalyCount) . ' ناهنجاری در اسناد',
                'desc'     => 'اسناد غیرعادی (مبالغ بزرگ، تکرار مشکوک، مشتری بدحساب) را بررسی کنید',
                'url'      => url('app/anomalies'),
                'icon'     => icon('shield', 17),
            ];
        }

        // مرتب‌سازی: وظایف برنامه‌ریز (سنجاق‌شده) اول، سپس فوری‌ترها (روز کمتر)
        usort($items, function ($a, $b) {
            $pa = !empty($a['pin']) ? 0 : 1;
            $pb = !empty($b['pin']) ? 0 : 1;
            if ($pa !== $pb) return $pa <=> $pb;
            $da = $a['days'] === null ? 999 : (int)$a['days'];
            $db = $b['days'] === null ? 999 : (int)$b['days'];
            return $da <=> $db;
        });
        return $items;
    }

    /** برچسب فارسی زمان سررسید */
    private static function whenLabel(int $d): string
    {
        if ($d < 0)  return abs($d) . ' روز گذشته';
        if ($d === 0) return 'امروز';
        if ($d === 1) return 'فردا';
        return $d . ' روز مانده';
    }
}
