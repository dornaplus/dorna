<?php
/** راه‌اندازی گام‌به‌گام: اطلاعات شخصی → اطلاعات کسب‌وکار → ورود به نرم‌افزار */
final class OnboardingController
{
    public function profile(array $p): string
    {
        $u = Auth::pendingUser();
        if (!$u) { if (Auth::id()) redirect(Auth::businessId() ? 'app' : 'onboarding/business'); redirect('login'); }
        $error = null;
        if (is_post()) {
            csrf_verify();
            $first = (string)post('first_name'); $last = (string)post('last_name');
            $national = (string)post('national_id'); $email = (string)post('email');
            if (mb_strlen($first) < 2 || mb_strlen($last) < 2) $error = 'نام و نام خانوادگی را کامل وارد کنید.';
            elseif (!AuthController::validNationalId($national)) $error = 'کد ملی واردشده معتبر نیست (۱۰ رقم با رقم کنترل صحیح).';
            elseif ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'قالب ایمیل صحیح نیست.';
            elseif ($email && Database::val('SELECT id FROM users WHERE email=? AND id<>?', [$email, $u['id']])) $error = 'این ایمیل قبلاً برای کاربر دیگری ثبت شده است.';
            else {
                Database::run('UPDATE users SET full_name=?, email=?, updated_at=NOW() WHERE id=?', [$first.' '.$last, $email ?: null, $u['id']]);
                $_SESSION['pending_profile'] = ['first_name' => $first, 'last_name' => $last, 'national_id' => $national];
                Flash::push('success', 'اطلاعات شخصی ثبت شد. حالا اطلاعات کسب‌وکار را کامل کنید.');
                redirect('onboarding/business');
            }
        }
        return view('pages/auth/profile', ['title' => 'اطلاعات شخصی', 'user' => $u, 'error' => $error]);
    }

    public function business(array $p): string
    {
        // کاربر ممکن است در میانه راه‌اندازی یا کاربر واردشده بدون کسب‌وکار باشد
        $uid = Auth::id();
        if (!$uid) { $u = Auth::pendingUser(); if (!$u) redirect('login'); $uid = (int)$u['id']; }
        $error = null;
        $provinces = Database::all('SELECT id, name AS title FROM provinces WHERE country_id=(SELECT id FROM countries WHERE iso2="IR" LIMIT 1) OR country_id IS NULL ORDER BY name LIMIT 40');
        if (!$provinces) $provinces = Database::all('SELECT id, name AS title FROM provinces ORDER BY id LIMIT 40');
        $currencies = Database::all('SELECT id, title, symbol, is_base FROM currencies WHERE is_active=1 ORDER BY is_base DESC, id LIMIT 12');
        $defaultCurrency = (int)Database::val('SELECT id FROM currencies WHERE code="IRT" LIMIT 1', [], (int)($currencies[0]['id'] ?? 0));

        if (is_post()) {
            csrf_verify();
            $name = (string)post('name');
            $legalType = (string)post('legal_type', 'hoqoqi');
            $fyStart = to_gregorian((string)post('fy_start')) ?: null;
            $fyEnd = to_gregorian((string)post('fy_end')) ?: null;
            if (mb_strlen($name) < 3) $error = 'نام کسب‌وکار را کامل وارد کنید.';
            elseif (!$fyStart || !$fyEnd) $error = 'تاریخ شروع و پایان سال مالی را وارد کنید.';
            elseif ($fyStart >= $fyEnd) $error = 'پایان سال مالی باید بعد از شروع آن باشد.';
            else {
                $data = [
                    'name' => $name, 'activity_type' => (string)post('activity_type', 'bazargardani'), 'legal_type' => $legalType,
                    'economic_code' => (string)post('economic_code', ''), 'national_id' => (string)post('national_id', ''), 'reg_no' => (string)post('reg_no', ''),
                    'phone' => (string)post('phone', ''), 'mobile' => (string)post('mobile', ''), 'email' => (string)post('email', ''),
                    'province_id' => post('province_id') ? (int)post('province_id') : null, 'city_id' => post('city_id') ? (int)post('city_id') : null,
                    'postal_code' => (string)post('postal_code', ''), 'address' => (string)post('address', ''),
                    'currency_id' => post('currency_id') ? (int)post('currency_id') : $defaultCurrency,
                    'fy_title' => (string)post('fy_title') ?: ('سال مالی '.jdate($fyStart)), 'fy_start' => $fyStart, 'fy_end' => $fyEnd,
                ];
                try {
                    $bizId = Provisioner::provision($uid, $data);
                    // اشتراک آزمایشی ۱۴ روزه: کاربر تازه می‌تواند همهٔ بخش‌ها را امتحان کند (پس از آن باید پکیج بخرد)
                    try { Billing::grantTrial($bizId, 14); } catch (Throwable $e) { /* رد شود */ }
                    // ورود کامل کاربر به نرم‌افزار با کسب‌وکار تازه‌ساخته‌شده
                    $userRow = Database::one('SELECT * FROM users WHERE id=?', [$uid]);
                    if ($userRow) Auth::loginUser($userRow);
                    Auth::clearPending();
                    if ($userRow) Auth::switchBusiness($bizId);
                    Flash::push('success', 'کسب‌وکار «'.$name.'» ایجاد شد. کدینگ حساب‌ها، قواعد سند و تنظیمات پیش‌فرض آماده است.');
                    redirect('onboarding/done');
                } catch (Throwable $e) { $error = $e->getMessage(); }
            }
        }
        [$defStart, $defEnd] = jalali_year_range(current_jalali_year());
        return view('pages/auth/business', ['title' => 'اطلاعات کسب‌وکار', 'error' => $error,
            'provinces' => $provinces, 'currencies' => $currencies, 'defaultCurrency' => $defaultCurrency,
            'defStart' => $defStart, 'defEnd' => $defEnd, 'profile' => $_SESSION['pending_profile'] ?? []]);
    }

    public function done(array $p): string
    {
        Auth::requireApp();
        return view('pages/auth/done', ['title' => 'آماده شروع کار', 'business' => Auth::business()]);
    }
}
