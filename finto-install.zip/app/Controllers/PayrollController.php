<?php
/**
 * حقوق و دستمزد — داشبورد، کارگاه‌ها، مساعده، وام و گزارش جامع
 */
final class PayrollController
{
    private function guard(string $perm = 'payroll.view'): void
    {
        Auth::requireApp();
        if (!Auth::can($perm)) abort(403, 'مجوز لازم برای این بخش از حقوق و دستمزد را ندارید.');
    }

    /* ─────────────── داشبورد ─────────────── */
    public function index(array $p): string
    {
        $this->guard();
        $from = to_gregorian((string)($_GET['from'] ?? '')) ?: date('Y-m-01');
        $to = to_gregorian((string)($_GET['to'] ?? '')) ?: today();
        $workshopId = (int)($_GET['workshop_id'] ?? 0);
        $biz = (int)Auth::businessId();
        return view('pages/payroll/index', [
            'title' => 'حقوق و دستمزد',
            'stats' => Payroll::dashboard($from, $to, $workshopId),
            'workshops' => Payroll::workshops(true),
            'byWorkshop' => Payroll::byWorkshop($from, $to),
            'advances' => Payroll::advances(['status' => 'open'], 6),
            'expiringContracts' => Payroll::expiringContracts(60, 5),
            'contractStats' => Payroll::contractStats(),
            'loans' => Payroll::loans(['status' => 'active'], 6),
            'docs' => Database::all('SELECT d.*, ws.title AS workshop_title FROM payroll_documents d
                                      LEFT JOIN payroll_workshops ws ON ws.id=d.workshop_id
                                     WHERE d.business_id=? AND d.deleted_at IS NULL AND d.doc_date BETWEEN ? AND ?
                                     ORDER BY d.doc_date DESC, d.id DESC LIMIT 6', [$biz, $from, $to]),
            'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '', 'workshopId' => $workshopId,
            'gregFrom' => $from, 'gregTo' => $to,
        ]);
    }

    /* ─────────────── کارگاه‌ها ─────────────── */
    public function workshops(array $p): string
    {
        $this->guard();
        return view('pages/payroll/workshops', ['title' => 'کارگاه‌ها', 'rows' => Payroll::workshops()]);
    }

    public function workshopForm(array $p): string
    {
        $this->guard('payroll.edit');
        $biz = (int)Auth::businessId();
        $row = !empty($p['id']) ? Payroll::workshop((int)$p['id']) : null;
        if (!empty($p['id']) && !$row) abort(404, 'کارگاه یافت نشد.');
        return view('pages/payroll/workshop_form', [
            'title' => $row ? 'ویرایش کارگاه ' . $row['title'] : 'تعریف کارگاه جدید',
            'row' => $row, 'nextCode' => Payroll::nextWorkshopCode($biz),
            'costCenters' => Database::all('SELECT id,name FROM cost_centers WHERE business_id=? AND is_active=1 ORDER BY name', [$biz]),
            'users' => Database::all('SELECT u.id,u.full_name FROM user_business_roles ubr JOIN users u ON u.id=ubr.user_id WHERE ubr.business_id=? AND ubr.is_active=1 ORDER BY u.full_name', [$biz]),
            'persons' => Database::all('SELECT id,code,first_name,last_name,company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
            'employees' => Database::all('SELECT id,code,full_name,job_title,department FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz]),
        ]);
    }

    public function workshopStore(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        $id = (int)post('id');
        try {
            $newId = Payroll::saveWorkshop([
                'title' => (string)post('title'), 'code' => (string)post('code'),
                'workshop_type' => (string)post('workshop_type', 'project'), 'status' => (string)post('status', 'active'),
                'manager_person_id' => post('manager_person_id') ? (int)post('manager_person_id') : null,
                'manager_user_id' => post('manager_user_id') ? (int)post('manager_user_id') : null,
                'address' => (string)post('address'), 'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null,
                'budget_amount' => fa_num((string)post('budget_amount', '0')),
                'start_date' => to_gregorian((string)post('start_date')), 'end_date' => to_gregorian((string)post('end_date')),
                'note' => (string)post('note'),
            ], $id ?: null);
            Flash::push('success', 'کارگاه ذخیره شد.');
            redirect('app/payroll/workshops/' . $newId);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', $e->getMessage());
            redirect($id ? 'app/payroll/workshops/' . $id . '/edit' : 'app/payroll/workshops/create');
        }
        return '';
    }

    public function workshopShow(array $p): string
    {
        $this->guard();
        $w = Payroll::workshop((int)($p['id'] ?? 0));
        if (!$w) abort(404, 'کارگاه یافت نشد.');
        $biz = (int)Auth::businessId();
        return view('pages/payroll/workshop_show', [
            'title' => 'کارگاه ' . $w['title'], 'w' => $w,
            'employees' => Database::all('SELECT id,code,full_name,job_title,department FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'docs' => Database::all('SELECT * FROM payroll_documents WHERE business_id=? AND workshop_id=? AND deleted_at IS NULL ORDER BY doc_date DESC LIMIT 30', [$biz, (int)$w['id']]),
        ]);
    }

    public function workshopDelete(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        try { Payroll::deleteWorkshop((int)($p['id'] ?? 0)); Flash::push('success', 'کارگاه حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/workshops');
        return '';
    }

    public function workshopAddEmployee(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        $wid = (int)($p['id'] ?? 0);
        try {
            $emp = (int)post('employee_id');
            if (!$emp) throw new RuntimeException('پرسنل را انتخاب کنید.');
            Payroll::addWorkshopEmployee($wid, $emp, (string)post('role_title'), fa_num((string)post('daily_wage', '0')),
                to_gregorian((string)post('from_date')), to_gregorian((string)post('to_date')));
            Flash::push('success', 'پرسنل به کارگاه اضافه شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/workshops/' . $wid);
        return '';
    }

    public function workshopRemoveEmployee(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        Payroll::removeWorkshopEmployee((int)($p['id'] ?? 0));
        Flash::push('success', 'پرسنل از کارگاه حذف شد.');
        redirect('app/payroll/workshops/' . (int)post('workshop_id'));
        return '';
    }

    /* ─────────────── مساعده ─────────────── */
    public function advances(array $p): string
    {
        $this->guard();
        $f = [
            'q' => trim((string)($_GET['q'] ?? '')), 'status' => (string)($_GET['status'] ?? ''),
            'employee_id' => (int)($_GET['employee_id'] ?? 0),
        ];
        $biz = (int)Auth::businessId();
        $rows = Payroll::advances($f, 200);
        $sum = ['amount' => 0.0, 'settled' => 0.0, 'remaining' => 0.0];
        foreach ($rows as $r) { $sum['amount'] += (float)$r['amount']; $sum['settled'] += (float)$r['settled_amount']; $sum['remaining'] += (float)$r['remaining']; }
        return view('pages/payroll/advances', ['title' => 'مساعده‌ها', 'rows' => $rows, 'f' => $f, 'sum' => $sum,
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz])]);
    }

    public function advanceForm(array $p): string
    {
        $this->guard('payroll.create');
        $biz = (int)Auth::businessId();
        return view('pages/payroll/advance_form', [
            'title' => 'ثبت مساعدهٔ حقوق',
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'cashAccounts' => Database::all('SELECT id,title,account_kind,current_balance FROM cash_accounts WHERE business_id=? AND status="active" ORDER BY id', [$biz]),
            'workshops' => Payroll::workshops(true),
            'outstanding' => Payroll::outstandingMap(),
        ]);
    }

    public function advanceStore(array $p): string
    {
        $this->guard('payroll.create');
        csrf_verify();
        try {
            $id = Payroll::saveAdvance([
                'employee_id' => (int)post('employee_id'), 'amount' => fa_num((string)post('amount')),
                'installments' => (int)post('installments', 1),
                'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'workshop_id' => post('workshop_id') ? (int)post('workshop_id') : null,
                'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'request_note' => (string)post('request_note'),
            ]);
            Flash::push('success', 'مساعده ثبت شد و سند حسابداری آن صادر گردید (از سند حقوق کسر می‌شود).');
            redirect('app/payroll/advances?highlight=' . $id);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', $e->getMessage());
            redirect('app/payroll/advances/create');
        }
        return '';
    }

    public function advanceCancel(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        try { Payroll::cancelAdvance((int)($p['id'] ?? 0)); Flash::push('success', 'مساعده لغو شد و سند آن برگشت خورد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/advances');
        return '';
    }

    /* ─────────────── وام ─────────────── */
    public function loans(array $p): string
    {
        $this->guard();
        $f = ['q' => trim((string)($_GET['q'] ?? '')), 'status' => (string)($_GET['status'] ?? ''), 'employee_id' => (int)($_GET['employee_id'] ?? 0)];
        $biz = (int)Auth::businessId();
        $rows = Payroll::loans($f, 200);
        $sum = ['amount' => 0.0, 'paid' => 0.0, 'remaining' => 0.0];
        foreach ($rows as $r) { $sum['amount'] += (float)$r['amount']; $sum['paid'] += (float)$r['paid_amount']; $sum['remaining'] += (float)$r['remaining']; }
        return view('pages/payroll/loans', ['title' => 'وام‌ها', 'rows' => $rows, 'f' => $f, 'sum' => $sum,
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz])]);
    }

    public function loanForm(array $p): string
    {
        $this->guard('payroll.create');
        $biz = (int)Auth::businessId();
        return view('pages/payroll/loan_form', [
            'title' => 'ثبت وام کارکنان',
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'cashAccounts' => Database::all('SELECT id,title,account_kind,current_balance FROM cash_accounts WHERE business_id=? AND status="active" ORDER BY id', [$biz]),
            'persons' => Database::all('SELECT id,code,first_name,last_name,company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
            'outstanding' => Payroll::outstandingMap(),
        ]);
    }

    public function loanStore(array $p): string
    {
        $this->guard('payroll.create');
        csrf_verify();
        try {
            $id = Payroll::saveLoan([
                'employee_id' => (int)post('employee_id'), 'amount' => fa_num((string)post('amount')),
                'installments' => (int)post('installments', 1),
                'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'guarantor_person_id' => post('guarantor_person_id') ? (int)post('guarantor_person_id') : null,
                'loan_date' => to_gregorian((string)post('loan_date')) ?: today(),
                'purpose' => (string)post('purpose'),
            ]);
            Flash::push('success', 'وام ثبت شد و سند حسابداری آن صادر گردید (اقساط از سند حقوق کسر می‌شود).');
            redirect('app/payroll/loans?highlight=' . $id);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', $e->getMessage());
            redirect('app/payroll/loans/create');
        }
        return '';
    }

    public function loanCancel(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        try { Payroll::cancelLoan((int)($p['id'] ?? 0)); Flash::push('success', 'وام لغو شد و سند آن برگشت خورد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/loans');
        return '';
    }

    /* ─────────────── گزارش جامع ─────────────── */
    public function report(array $p): string
    {
        $this->guard();
        $from = to_gregorian((string)($_GET['from'] ?? '')) ?: date('Y-m-01');
        $to = to_gregorian((string)($_GET['to'] ?? '')) ?: today();
        $workshopId = (int)($_GET['workshop_id'] ?? 0);
        $employeeId = (int)($_GET['employee_id'] ?? 0);
        $rows = Payroll::reportRows($from, $to, $workshopId, $employeeId);
        $biz = (int)Auth::businessId();
        if (($_GET['export'] ?? '') === 'csv') {
            $headers = ['تاریخ', 'شماره سند', 'دوره', 'کارگاه', 'پرسنل', 'کد', 'روز کارکرد', 'حقوق ناخالص', 'کسورات', 'مساعده', 'قسط وام', 'خالص'];
            $out = [];
            foreach ($rows as $r) $out[] = [jdate($r['doc_date']), $r['doc_no'], $r['period_title'], $r['workshop_title'] ?? '—',
                $r['full_name'], $r['employee_code'], num((float)$r['worked_days'], 1), num((float)$r['gross_amount'], 0),
                num((float)$r['deductions_amount'], 0), num((float)$r['advance_amount'], 0), num((float)$r['loan_amount'], 0), num((float)$r['net_amount'], 0)];
            csv_download('payroll-report-' . date('Ymd'), $headers, $out);
            return '';
        }
        $tot = ['gross' => 0.0, 'ded' => 0.0, 'adv' => 0.0, 'loan' => 0.0, 'net' => 0.0];
        foreach ($rows as $r) { $tot['gross'] += (float)$r['gross_amount']; $tot['ded'] += (float)$r['deductions_amount']; $tot['adv'] += (float)$r['advance_amount']; $tot['loan'] += (float)$r['loan_amount']; $tot['net'] += (float)$r['net_amount']; }
        return view('pages/payroll/report', [
            'title' => 'گزارش جامع حقوق', 'rows' => $rows, 'tot' => $tot, 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '',
            'gregFrom' => $from, 'gregTo' => $to, 'workshopId' => $workshopId, 'employeeId' => $employeeId,
            'workshops' => Payroll::workshops(),
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'byWorkshop' => Payroll::byWorkshop($from, $to),
            'stats' => Payroll::dashboard($from, $to, $workshopId),
        ]);
    }


    /* ═══════════════ قراردادهای کار (تنظیمات حقوق و دستمزد) ═══════════════ */

    public function contracts(array $p): string
    {
        $this->guard();
        $f = ['q' => trim((string)($_GET['q'] ?? '')), 'status' => (string)($_GET['status'] ?? ''),
            'contract_type' => (string)($_GET['contract_type'] ?? ''), 'employee_id' => (int)($_GET['employee_id'] ?? 0)];
        $biz = (int)Auth::businessId();
        $rows = Payroll::contracts($f, 300);
        return view('pages/payroll/contracts', [
            'title' => 'قراردادهای کار', 'rows' => $rows, 'f' => $f,
            'stats' => Payroll::contractStats(), 'expiring' => Payroll::expiringContracts(60),
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND deleted_at IS NULL ORDER BY full_name', [$biz]),
        ]);
    }

    private function contractFormData(array $row): array
    {
        $biz = (int)Auth::businessId();
        return [
            'title' => !empty($row) ? 'ویرایش قرارداد ' . $row['contract_no'] : 'ثبت قرارداد جدید',
            'row' => $row,
            'nextNo' => !empty($row) ? (string)$row['contract_no'] : Payroll::nextContractNo($biz),
            'employees' => Database::all('SELECT id,code,full_name,job_title,department,workshop_id,hire_date FROM employees WHERE business_id=? AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'workshops' => Payroll::workshops(true),
            'templates' => Payroll::contractTemplates($biz),
        ];
    }

    public function contractForm(array $p): string
    {
        $this->guard('payroll.create');
        $row = [];
        if (!empty($p['id'])) {
            $row = Payroll::contract((int)$p['id']);
            if (!$row) abort(404, 'قرارداد یافت نشد.');
        } elseif (!empty($_GET['employee_id'])) {
            $row['employee_id'] = (int)$_GET['employee_id'];   // از پروندهٔ پرسنل
        }
        return view('pages/payroll/contract_form', $this->contractFormData($row));
    }

    public function contractStore(array $p): string
    {
        $this->guard('payroll.create');
        csrf_verify();
        $id = (int)($p['id'] ?? 0);
        $money = static fn(string $k): float => round(fa_num((string)post($k, '0')), 2);
        try {
            $cid = Payroll::saveContract([
                'employee_id' => (int)post('employee_id'),
                'contract_no' => (string)post('contract_no'),
                'template_id' => post('template_id') ? (int)post('template_id') : null,
                'contract_type' => (string)post('contract_type', 'fixed_term'),
                'status' => (string)post('status', 'draft'),
                'title' => (string)post('title'), 'job_title' => (string)post('job_title'),
                'workshop_id' => post('workshop_id') ? (int)post('workshop_id') : null,
                'start_date' => to_gregorian((string)post('start_date')),
                'end_date' => to_gregorian((string)post('end_date')),
                'signed_date' => to_gregorian((string)post('signed_date')),
                'trial_months' => (int)post('trial_months', 0),
                'work_hours_monthly' => fa_num((string)post('work_hours_monthly', '176')),
                'work_days_monthly' => fa_num((string)post('work_days_monthly', '26')),
                'base_salary' => $money('base_salary'), 'housing_allowance' => $money('housing_allowance'),
                'food_allowance' => $money('food_allowance'), 'child_allowance' => $money('child_allowance'),
                'other_allowances' => $money('other_allowances'),
                'insurance_rate_employee' => round((float)fa_num((string)post('insurance_rate_employee', '7')), 2),
                'insurance_rate_employer' => round((float)fa_num((string)post('insurance_rate_employer', '23')), 2),
                'paid_leave_days' => (int)post('paid_leave_days', 26),
                'apply_to_salary' => post('apply_to_salary') ? 1 : 0,
                'terms' => (string)post('terms'), 'note' => (string)post('note'),
            ], $id ?: null);
            if (post('apply_to_salary')) Payroll::applyContractToSalary($cid);
            Flash::push('success', 'قرارداد ذخیره شد.' . (post('apply_to_salary') ? ' عوامل آن در تنظیمات حقوق پرسنل اعمال شد.' : ''));
            redirect('app/payroll/contracts/' . $cid);
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', $e->getMessage());
            redirect($id ? 'app/payroll/contracts/' . $id . '/edit' : 'app/payroll/contracts/create');
        }
        return '';
    }

    public function contractShow(array $p): string
    {
        $this->guard();
        $c = Payroll::contract((int)($p['id'] ?? 0));
        if (!$c) abort(404, 'قرارداد یافت نشد.');
        $rendered = Payroll::renderContract((int)$c['id'], !empty($c['template_id']) ? (int)$c['template_id'] : null);
        return view('pages/payroll/contract_print', [
            'title' => 'قرارداد کار ' . $c['contract_no'], 'c' => $c, 'print' => false, 'rendered' => $rendered,
            'biz' => Database::one('SELECT * FROM businesses WHERE id=?', [(int)Auth::businessId()]),
        ]);
    }

    public function contractPrint(array $p): string
    {
        $this->guard();
        $c = Payroll::contract((int)($p['id'] ?? 0));
        if (!$c) abort(404, 'قرارداد یافت نشد.');
        $rendered = Payroll::renderContract((int)$c['id'], !empty($c['template_id']) ? (int)$c['template_id'] : null);
        return view('pages/payroll/contract_print', [
            'title' => 'چاپ قرارداد ' . $c['contract_no'], 'c' => $c, 'print' => true, 'rendered' => $rendered,
            'biz' => Database::one('SELECT * FROM businesses WHERE id=?', [(int)Auth::businessId()]),
        ]);
    }

    public function contractApply(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        try { Payroll::applyContractToSalary((int)($p['id'] ?? 0)); Flash::push('success', 'عوامل قرارداد در تنظیمات حقوق پرسنل اعمال شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/contracts/' . (int)($p['id'] ?? 0));
        return '';
    }

    public function contractDelete(array $p): string
    {
        $this->guard('payroll.edit');
        csrf_verify();
        try { Payroll::deleteContract((int)($p['id'] ?? 0)); Flash::push('success', 'قرارداد حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/payroll/contracts');
        return '';
    }

    /* ═══════════════ پروندهٔ پرسنل (فرم اختصاصی) ═══════════════ */

    public function formCreate(array $m, array $p): string { return $this->employeeForm($m, []); }

    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM employees WHERE id=? AND business_id=? AND deleted_at IS NULL', [(int)($p['id'] ?? 0), (int)Auth::businessId()]);
        if (!$row) abort(404, 'پرسنل یافت نشد.');
        return $this->employeeForm($m, $row);
    }

    private function employeeForm(array $m, array $row): string
    {
        Auth::requireApp();
        if (!Payroll::canEdit()) abort(403, 'مجوز ثبت/ویرایش پرسنل را ندارید.');
        $biz = (int)Auth::businessId();
        $salary = !empty($row['id']) ? Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [(int)$row['id']]) : null;
        return view('pages/payroll/employee_form', [
            'm' => $m, 'row' => $row, 'salary' => $salary ?: [],
            'title' => !empty($row) ? 'ویرایش پروندهٔ ' . (string)$row['full_name'] : 'تعریف پرسنل جدید',
            'cols' => Schema::columns('employees'),
            'workshops' => Payroll::workshops(true),
            'provinces' => Schema::options('provinces', '', 100),
            'cities' => Schema::options('cities', '', 500),
            'managers' => Database::all('SELECT id, code, full_name FROM employees WHERE business_id=? AND status="active" AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'persons' => Database::all("SELECT p.id, p.code, p.first_name, p.last_name, p.company_name, p.national_id, p.mobile, p.father_name,
                                               (SELECT COUNT(*) FROM employees e WHERE e.business_id=p.business_id AND e.person_id=p.id AND e.deleted_at IS NULL) AS has_file
                                          FROM persons p WHERE p.business_id=? AND p.deleted_at IS NULL AND p.person_kind='haqiqi' ORDER BY p.id DESC LIMIT 300", [$biz]),
            'cashAccounts' => Database::all('SELECT id, title FROM cash_accounts WHERE business_id=? ORDER BY id', [$biz]),
            'paymentMethods' => Database::all('SELECT id, title_fa AS title FROM payment_methods WHERE business_id=? AND is_active=1 ORDER BY id', [$biz]),
            'nextCode' => self::nextEmployeeCode($biz),
        ]);
    }

    /** کد پرسنلی بعدی */
    private static function nextEmployeeCode(int $biz): string
    {
        $max = 0;
        foreach (Database::all('SELECT code FROM employees WHERE business_id=?', [$biz]) as $r)
            if (preg_match('/(\d+)\s*$/', (string)$r['code'], $mm)) $max = max($max, (int)$mm[1]);
        return 'EMP-' . str_pad((string)($max + 1), 4, '0', STR_PAD_LEFT);
    }

    public function customSave(array $m, array $p, ?string $id): string
    {
        Auth::requireApp();
        if (!Payroll::canEdit()) abort(403, 'مجوز ثبت/ویرایش پرسنل را ندارید.');
        csrf_verify();
        $biz = (int)Auth::businessId();
        $txt = static function (string $k): ?string { $v = trim((string)post($k)); return $v === '' ? null : mb_substr($v, 0, 250); };
        $money = static fn(string $k): float => round(fa_num((string)post($k, '0')), 2);
        $int = static function (string $k): ?int { $v = trim((string)post($k)); return $v === '' ? null : (int)fa_num($v); };
        $date = static fn(string $k): ?string => to_gregorian((string)post($k)) ?: null;
        $enum = static function (string $k, array $allowed): ?string { $v = (string)post($k); return in_array($v, $allowed, true) ? $v : null; };
        $digits = static fn(string $k): ?string => ($v = preg_replace('/\D+/', '', en_digits((string)post($k)))) ? $v : null;

        $fullName = mb_substr(trim((string)post('full_name')), 0, 150);
        $errors = [];
        if (mb_strlen($fullName) < 3) $errors[] = 'نام و نام خانوادگی پرسنل الزامی است.';
        $national = $digits('national_id');
        if ($national && !AuthController::validNationalId($national)) $errors[] = 'کد ملی واردشده معتبر نیست.';
        $mobileRaw = trim((string)post('mobile'));
        $mobile = $mobileRaw !== '' ? AuthController::normalizeMobile($mobileRaw) : null;
        if ($mobileRaw !== '' && !$mobile) $errors[] = 'شماره موبایل معتبر نیست.';
        $email = $txt('email');
        if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'ایمیل معتبر نیست.';
        $code = mb_substr(trim((string)post('code')), 0, 30) ?: self::nextEmployeeCode($biz);
        $dupCode = Database::val('SELECT COUNT(*) FROM employees WHERE business_id=? AND code=?' . ($id ? ' AND id<>?' : ''), $id ? [$biz, $code, (int)$id] : [$biz, $code]);
        if ($dupCode) $errors[] = 'کد پرسنلی «' . $code . '» تکراری است.';
        if ($national) {
            $dupN = Database::val('SELECT COUNT(*) FROM employees WHERE business_id=? AND national_id=?' . ($id ? ' AND id<>?' : ''), $id ? [$biz, $national, (int)$id] : [$biz, $national]);
            if ($dupN) $errors[] = 'پرسنلی با همین کد ملی قبلاً ثبت شده است.';
        }
        if ($errors) {
            Flash::keep($_POST); Flash::push('error', implode(' ', $errors));
            redirect($id ? 'app/employees/' . $id . '/edit' : 'app/employees/create');
        }

        // ارتباط با «اشخاص»: هر شخص حقیقی تنها یک پروندهٔ پرسنلی دارد و مشخصات پایه از او خوانده می‌شود
        $personId = $int('person_id');
        $person = null;
        if ($personId) {
            $person = Database::one('SELECT * FROM persons WHERE id=? AND business_id=? AND deleted_at IS NULL', [$personId, $biz]);
            if (!$person) $errors[] = 'شخص انتخاب‌شده معتبر نیست.';
            elseif (($person['person_kind'] ?? 'haqiqi') !== 'haqiqi') $errors[] = 'فقط اشخاص حقیقی می‌توانند پروندهٔ پرسنلی داشته باشند.';
            else {
                $dup = Database::val('SELECT COUNT(*) FROM employees WHERE business_id=? AND person_id=? AND deleted_at IS NULL' . ($id ? ' AND id<>?' : ''),
                    $id ? [$biz, $personId, (int)$id] : [$biz, $personId]);
                if ($dup) $errors[] = 'برای شخص «' . trim(($person['first_name'] ?? '') . ' ' . ($person['last_name'] ?? '')) . '» قبلاً پروندهٔ پرسنلی ثبت شده است.';
            }
        }
        $workshopId = $int('workshop_id');
        $current = $id ? Database::one('SELECT * FROM employees WHERE id=? AND business_id=?', [(int)$id, $biz]) : null;
        if ($person) {
            // تکمیل خودکار مشخصات هویتی از پروندهٔ شخص (تنها اگر خالی باشد)
            $national = $national ?: ($person['national_id'] ? (string)preg_replace('/\D+/', '', en_digits((string)$person['national_id'])) : null);
            $mobile = $mobile ?: ($person['mobile'] ? AuthController::normalizeMobile((string)$person['mobile']) : null);
        }
        $data = [
            'code' => $code, 'full_name' => $fullName, 'person_id' => $int('person_id'),
            'father_name' => $txt('father_name') ?: ($person['father_name'] ?? null), 'national_id' => $national,
            'id_card_no' => $digits('id_card_no'), 'id_card_issue_place' => $txt('id_card_issue_place'),
            'birth_date' => $date('birth_date'), 'birth_place' => $txt('birth_place'),
            'gender' => $enum('gender', ['male', 'female']), 'marital_status' => $enum('marital_status', ['single', 'married']),
            'children_count' => (int)fa_num((string)post('children_count', '0')),
            'military_status' => $enum('military_status', ['done', 'exempt', 'in_progress', 'not_required']),
            'education_level' => $txt('education_level'), 'field_of_study' => $txt('field_of_study'),
            'mobile' => $mobile, 'phone' => $digits('phone'), 'email' => $email,
            'address' => $txt('address'), 'postal_code' => $digits('postal_code'),
            'province_id' => $int('province_id'), 'city_id' => $int('city_id'),
            'emergency_name' => $txt('emergency_name'), 'emergency_phone' => $digits('emergency_phone'),
            'workshop_id' => $workshopId, 'manager_employee_id' => $int('manager_employee_id'),
            'job_title' => $txt('job_title'), 'department' => $txt('department'),
            'employment_type' => $enum('employment_type', ['full_time', 'part_time', 'contract', 'temporary', 'permanent', 'intern']) ?? 'full_time',
            'hire_date' => $date('hire_date'), 'contract_end_date' => $date('contract_end_date'),
            'termination_date' => $date('termination_date'), 'shift_title' => $txt('shift_title'),
            'status' => $enum('status', ['active', 'suspended', 'terminated', 'retired', 'inactive']) ?? 'active',
            'insurance_no' => $digits('insurance_no'), 'insurance_start_date' => $date('insurance_start_date'),
            'tax_file_no' => $txt('tax_file_no'), 'bank_name' => $txt('bank_name'),
            'account_no' => $digits('account_no'),
            'iban' => self::normalizeIban((string)post('iban')), 'card_no' => $digits('card_no'),
            'note' => $txt('note'), 'is_active' => post('is_active') ? 1 : 0,
        ];
        $salaryData = [
            'base_salary' => $money('base_salary'), 'housing_allowance' => $money('housing_allowance'),
            'food_allowance' => $money('food_allowance'), 'child_allowance' => $money('child_allowance'),
            'other_allowances' => $money('other_allowances'),
            'insurance_rate_employee' => round((float)fa_num((string)post('insurance_rate_employee', '7')), 2),
            'insurance_rate_employer' => round((float)fa_num((string)post('insurance_rate_employer', '23')), 2),
            'tax_exemption_amount' => $money('tax_exemption_amount'),
            'cash_account_id' => $int('cash_account_id'), 'payment_method_id' => $int('payment_method_id'),
            'effective_from' => $date('salary_effective_from') ?: today(),
        ];
        if ($errors) {   // خطاهای مربوط به اتصال «شخص» (تکراری/حقوقی) هم باید متوقف کنند
            Flash::keep($_POST); Flash::push('error', implode(' ', $errors));
            redirect($id ? 'app/employees/' . $id . '/edit' : 'app/employees/create');
        }
        // در ویرایش، فیلدهایی که فرم نفرستاده دست‌نخورده می‌مانند (به‌جز چک‌باکس‌ها)
        if ($current) {
            foreach ($data as $k => $v) {
                if (in_array($k, ['is_active'], true)) continue;
                if (!array_key_exists($k, $_POST)) $data[$k] = $current[$k] ?? null;
            }
            foreach (['base_salary' => 'base_salary', 'housing_allowance' => 'housing_allowance', 'food_allowance' => 'food_allowance',
                      'child_allowance' => 'child_allowance', 'other_allowances' => 'other_allowances',
                      'insurance_rate_employee' => 'insurance_rate_employee', 'insurance_rate_employer' => 'insurance_rate_employer',
                      'tax_exemption_amount' => 'tax_exemption_amount', 'cash_account_id' => 'cash_account_id',
                      'payment_method_id' => 'payment_method_id'] as $pk => $ck) {
                if (!array_key_exists($pk, $_POST)) {
                    $cur = Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [(int)$id]) ?: [];
                    $salaryData[$ck] = $cur[$ck] ?? $salaryData[$ck];
                }
            }
        }
        try {
            Database::transaction(function () use ($id, $biz, $data, $salaryData, $workshopId) {
                if ($id) {
                    $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                    Database::update('employees', $data, 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
                    $empId = (int)$id;
                } else {
                    $data['business_id'] = $biz; $data['created_at'] = now(); $data['created_by'] = Auth::id();
                    $empId = (int)Database::insert('employees', $data);
                }
                $exists = Database::val('SELECT COUNT(*) FROM employee_salary_settings WHERE employee_id=?', [$empId]);
                if ($exists) Database::update('employee_salary_settings', $salaryData, 'employee_id=:employee_id', ['employee_id' => $empId]);
                else { $salaryData['employee_id'] = $empId; $salaryData['created_at'] = now(); $salaryData['created_by'] = Auth::id(); Database::insert('employee_salary_settings', $salaryData); }
                // همگام‌سازی کارگاه: پروندهٔ پرسنل و عضویت کارگاه همیشه یکی هستند
                Payroll::syncEmployeeWorkshop($empId, $workshopId, (string)post('workshop_role'));
            });
            Audit::log($id ? 'update' : 'create', 'employees', (int)($id ?? 0), ($id ? 'ویرایش' : 'ایجاد') . ' پروندهٔ پرسنل ' . $data['full_name']);
            Flash::push('success', 'پروندهٔ پرسنل با موفقیت ذخیره شد.' . ($workshopId ? ' به کارگاه انتخابی هم افزوده شد.' : ''));
            redirect('app/employees/' . ($id ?: (int)Database::val('SELECT id FROM employees WHERE business_id=? AND code=? ORDER BY id DESC LIMIT 1', [$biz, $data['code']], 0)));
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', 'ذخیرهٔ پروندهٔ پرسنل انجام نشد: ' . $e->getMessage());
            redirect($id ? 'app/employees/' . $id . '/edit' : 'app/employees/create');
        }
        return '';
    }

    /** پس از حذف (نرم) پرسنل: پاک‌سازی عضویت کارگاه تا داده ناسازگار نماند */
    public function afterDelete(array $m, array $p, int $id): void
    {
        if (($m['table'] ?? '') !== 'employees') return;
        Database::run('DELETE FROM payroll_workshop_employees WHERE business_id=? AND employee_id=?', [(int)Auth::businessId(), $id]);
    }

    /** یکسان‌سازی شبا: IR + ۲۴ رقم */
    private static function normalizeIban(string $v): ?string
    {
        $v = strtoupper(str_replace([' ', '-'], '', en_digits(trim($v))));
        if ($v === '') return null;
        if (str_starts_with($v, 'IR')) $v = substr($v, 2);
        $v = preg_replace('/\D+/', '', $v);
        return strlen($v) >= 24 ? 'IR' . substr($v, 0, 24) : 'IR' . $v;
    }
}
