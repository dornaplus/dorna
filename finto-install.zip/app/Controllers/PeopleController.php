<?php
/** اشخاص: فرم اختصاصی با گروه‌های شخص، اطلاعات مالی و کد خودکار */
final class PeopleController
{
    public static function onlyFor(): array
    {
        return ['code','person_kind','first_name','last_name','company_name','national_id','national_legal_id','economic_code','father_name',
            'mobile','phone','email','website','country_id','province_id','city_id','postal_code','address',
            'receivable_account_id_placeholder','marketer_id','introducer_person_id','price_list_note','notes','status','is_active'];
    }

    public function formCreate(array $m, array $p): string
    {
        return $this->form($m, []);
    }
    public function formEdit(array $m, array $p): string
    {
        $id = (int)$p['id'];
        $row = Database::one('SELECT * FROM persons WHERE id=? AND business_id=?', [$id, Auth::businessId()]);
        if (!$row) abort(404, 'شخص یافت نشد.');
        return $this->form($m, $row);
    }
    private function form(array $m, array $row): string
    {
        $only = array_values(array_filter($this->onlyFor(), fn($c) => isset(Schema::columns('persons')[$c])));
        $groups = Fields::groups('persons', ['only' => $only]);
        $types = Database::all('SELECT * FROM person_types WHERE business_id=? AND is_active=1 ORDER BY id', [Auth::businessId()]);
        $selected = [];
        if (!empty($row['id'])) $selected = array_column(Database::all('SELECT person_type_id FROM person_type_links WHERE person_id=?', [$row['id']]), 'person_type_id');
        $financial = !empty($row['id']) ? Database::one('SELECT * FROM person_financial_settings WHERE person_id=?', [$row['id']]) : null;
        return view('pages/people/form', ['m' => $m, 'groups' => $groups, 'row' => $row, 'types' => $types, 'selectedTypes' => $selected,
            'financial' => $financial ?: [],
            'action' => $row ? url('app/persons/'.$row['id']) : url('app/persons'), 'title' => $row ? 'ویرایش شخص' : 'تعریف شخص']);
    }

    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $biz = Auth::businessId();
        $kind = (string)post('person_kind', 'haqiqi');
        $first = (string)post('first_name'); $last = (string)post('last_name'); $company = (string)post('company_name');
        $mobile = (string)post('mobile');
        $errors = [];
        if ($kind === 'haqiqi' && (mb_strlen($first) < 2 || mb_strlen($last) < 2)) $errors[] = 'برای شخص حقیقی، نام و نام خانوادگی الزامی است.';
        if ($kind === 'hoqoqi' && mb_strlen($company) < 2) $errors[] = 'برای شخص حقوقی، نام شرکت الزامی است.';
        if ($mobile && !AuthController::normalizeMobile($mobile)) $errors[] = 'شماره موبایل معتبر نیست.';
        $national = (string)post('national_id');
        if ($national && $kind === 'haqiqi' && !AuthController::validNationalId($national)) $errors[] = 'کد ملی واردشده معتبر نیست.';
        if ($errors) { Flash::keep($_POST); Flash::push('error', implode(' ', $errors)); redirect($id ? 'app/persons/'.$id.'/edit' : 'app/persons/create'); }

        $data = [
            'business_id' => $biz, 'person_kind' => $kind, 'first_name' => $first ?: null, 'last_name' => $last ?: null,
            'company_name' => $company ?: null, 'national_id' => $national ?: null, 'national_legal_id' => (string)post('national_legal_id') ?: null,
            'economic_code' => (string)post('economic_code') ?: null, 'father_name' => (string)post('father_name') ?: null,
            'mobile' => $mobile ? AuthController::normalizeMobile($mobile) : null, 'phone' => (string)post('phone') ?: null,
            'email' => (string)post('email') ?: null, 'website' => (string)post('website') ?: null,
            'country_id' => post('country_id') ? (int)post('country_id') : null,
            'province_id' => post('province_id') ? (int)post('province_id') : null,
            'city_id' => post('city_id') ? (int)post('city_id') : null,
            'postal_code' => (string)post('postal_code') ?: null, 'address' => (string)post('address') ?: null,
            'marketer_id' => post('marketer_id') ? (int)post('marketer_id') : null,
            'introducer_person_id' => post('introducer_person_id') ? (int)post('introducer_person_id') : null,
            'price_list_note' => (string)post('price_list_note') ?: null, 'notes' => (string)post('notes') ?: null,
            'status' => (string)post('status', 'active'), 'is_active' => post('is_active') ? 1 : 0,
        ];
        $data['code'] = (string)post('code') ?: $this->nextCode($biz, $kind);
        try {
            Database::transaction(function () use ($id, $data, $biz, $p) {
                if ($id) {
                    $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                    Database::update('persons', $data, 'id=:pk', ['pk' => $id]);
                    $pid = (int)$id;
                } else {
                    $data['created_at'] = now(); $data['created_by'] = Auth::id();
                    $pid = Database::insert('persons', $data);
                }
                // گروه‌های شخص
                Database::run('DELETE FROM person_type_links WHERE person_id=?', [$pid]);
                foreach ((array)($_POST['person_types'] ?? []) as $tid) Database::run('INSERT IGNORE INTO person_type_links (person_id, person_type_id) VALUES (?,?)', [$pid, (int)$tid]);
                // تنظیمات مالی
                $fin = ['receivable_account_id' => post('receivable_account_id') ? (int)post('receivable_account_id') : null,
                    'credit_limit_amount' => (float)str_replace(',', '', (string)post('credit_limit_amount', '0')),
                    'payment_term_id' => post('payment_term_id') ? (int)post('payment_term_id') : null,
                    'default_price_type_id' => post('default_price_type_id') ? (int)post('default_price_type_id') : null,
                    'default_discount_percent' => (float)post('default_discount_percent', 0),
                    'opening_balance_type' => (string)post('opening_balance_type', 'none'),
                    'sms_thanks_enabled' => post('sms_thanks_enabled') ? 1 : 0];
                $exists = Database::val('SELECT COUNT(*) FROM person_financial_settings WHERE person_id=?', [$pid]);
                if ($exists) { Database::update('person_financial_settings', $fin, 'person_id=:pid', ['pid' => $pid]); }
                else { $fin['person_id'] = $pid; Database::insert('person_financial_settings', $fin); }
            });
            Audit::log($id ? 'update' : 'create', 'persons', (int)($id ?? 0), ($id ? 'ویرایش' : 'ایجاد').' شخص '.$data['code']);
            Flash::push('success', 'اطلاعات شخص با موفقیت ذخیره شد.');
            Flash::clearOld();
            redirect('app/persons/'.($id ?: Database::val('SELECT id FROM persons WHERE business_id=? AND code=? ORDER BY id DESC LIMIT 1', [$biz, $data['code']])));
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', 'خطا در ذخیره شخص: '.$e->getMessage());
            redirect($id ? 'app/persons/'.$id.'/edit' : 'app/persons/create');
        }
        return '';
    }

    /** شرایط پرداخت یک شخص (برای محاسبهٔ خودکار سررسید فاکتور) */
    public function paymentTerm(array $p): string
    {
        Auth::requireApp();
        header('Content-Type: application/json; charset=utf-8');
        $id = (int)($p['id'] ?? 0);
        $ok = (int)Database::val('SELECT COUNT(*) FROM persons WHERE id=? AND business_id=?', [$id, Auth::businessId()], 0);
        if (!$ok) { echo json_encode(['ok' => false], JSON_UNESCAPED_UNICODE); return ''; }
        $days = finance_payment_term_days($id);
        echo json_encode(['ok' => true, 'days' => $days, 'due_date' => finance_due_date(today(), $id), 'title' => (string)Database::val(
            'SELECT pt.title FROM person_financial_settings pfs JOIN payment_terms pt ON pt.id=pfs.payment_term_id WHERE pfs.person_id=?', [$id], '')],
            JSON_UNESCAPED_UNICODE);
        return '';
    }

    public function nextCode(int $biz, string $kind = 'haqiqi'): string
    {
        $prefix = $kind === 'hoqoqi' ? 'CO' : 'C';
        $n = (int)Database::val('SELECT COUNT(*) FROM persons WHERE business_id=?', [$biz], 0) + 1;
        do { $code = $prefix.'-'.str_pad((string)$n, 4, '0', STR_PAD_LEFT); $n++; }
        while (Database::val('SELECT COUNT(*) FROM persons WHERE business_id=? AND code=?', [$biz, $code]));
        return $code;
    }
}
