<?php
/** نمای ۳۶۰ مشتری + فعالیت‌ها و اسناد مرتبط */
final class PersonProfileController
{
    private function guard(): void { Auth::requireApp(); if (!Auth::can('persons.view')) abort(403, 'مجوز مشاهدهٔ اشخاص را ندارید.'); }

    private function guardWrite(): void { Auth::requireApp(); if (!Auth::can('persons.edit')) abort(403, 'مجوز ویرایش اشخاص را ندارید.'); }

    private function person(int $id): array
    {
        $biz = Auth::businessId();
        $p = Database::one('SELECT * FROM persons WHERE id=? AND business_id=? AND deleted_at IS NULL', [$id, $biz]);
        if (!$p) abort(404, 'شخص یافت نشد.');
        return $p;
    }

    private static function displayName(array $p): string
    {
        $name = trim((string)($p['first_name'] ?? '') . ' ' . (string)($p['last_name'] ?? ''));
        if ($name !== '') return $name;
        return (string)($p['company_name'] ?? 'بدون نام');
    }

    public function show(array $p): string
    {
        $this->guard();
        $person = $this->person((int)$p['id']);
        $biz = (int)Auth::businessId();
        $pid = (int)$person['id'];
        $fy = (int)Auth::fiscalYearId();

        // ── مانده از دفتر (شامل ماندهٔ افتتاحیه و اسناد) ──
        $bal = Database::one(
            'SELECT total_debit, total_credit, balance_amount FROM v_person_balances
              WHERE business_id=? AND person_id=? AND fiscal_year_id=?', [$biz, $pid, $fy]);
        $balance = (float)($bal['balance_amount'] ?? 0);

        // ── آمار فاکتورها ──
        $invStats = Database::one(
            "SELECT COUNT(*) AS cnt,
                    IFNULL(SUM(CASE WHEN invoice_type='sale' THEN total_amount END),0) AS sales_total,
                    IFNULL(SUM(CASE WHEN invoice_type='buy' THEN total_amount END),0) AS buy_total,
                    IFNULL(SUM(remaining_amount),0) AS remaining
               FROM invoices WHERE business_id=? AND person_id=? AND deleted_at IS NULL AND status <> 'cancelled'",
            [$biz, $pid]);

        $invoices = Database::all(
            "SELECT id, invoice_no, invoice_type, invoice_date, total_amount, paid_amount, remaining_amount, status, settlement_status
               FROM invoices WHERE business_id=? AND person_id=? AND deleted_at IS NULL
              ORDER BY invoice_date DESC, id DESC LIMIT 12", [$biz, $pid]);

        // ── تیکت‌ها ──
        $tickets = Database::all(
            "SELECT id, ticket_no, subject, status, priority, created_at FROM tickets
              WHERE business_id=? AND person_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 10", [$biz, $pid]);

        // ── فعالیت‌ها و پیگیری‌ها ──
        $activities = PersonActivity::timeline($pid);
        $followups = PersonActivity::openFollowups($pid);

        // ── اسناد (پیوست‌های شخص + پیوست فاکتورهایش) ──
        $docs = Database::all(
            "SELECT a.*, u.full_name AS uploader_name
               FROM attachments a LEFT JOIN users u ON u.id = a.uploaded_by
              WHERE a.business_id = ?
                AND ( (a.entity_type='person' AND a.entity_id=?)
                      OR (a.entity_type='invoice' AND a.entity_id IN (SELECT id FROM invoices WHERE business_id=? AND person_id=?)) )
              ORDER BY a.id DESC LIMIT 30", [$biz, $pid, $biz, $pid]);

        // انواع شخص
        $types = Database::all(
            "SELECT pt.title_fa, pt.slug FROM person_type_links l JOIN person_types pt ON pt.id=l.person_type_id
              WHERE l.person_id=? AND pt.is_active=1", [$pid]);
        $fin = Database::one('SELECT * FROM person_financial_settings WHERE person_id=?', [$pid]);

        return view('pages/persons/profile', [
            'title' => 'پروندهٔ مشتری', 'person' => $person, 'pname' => self::displayName($person),
            'types' => $types, 'fin' => $fin ?: [],
            'balance' => $balance, 'invStats' => $invStats ?: ['cnt' => 0, 'sales_total' => 0, 'buy_total' => 0, 'remaining' => 0],
            'invoices' => $invoices, 'tickets' => $tickets,
            'activities' => $activities, 'followups' => $followups, 'docs' => $docs,
            'actTypes' => PersonActivity::TYPES,
        ]);
    }

    /* ───────────── فعالیت‌ها ───────────── */

    public function activityStore(array $p): string
    {
        $this->guardWrite(); csrf_verify();
        $pid = (int)$p['id'];
        $this->person($pid);
        try {
            $type = (string)post('activity_type', 'note');
            $due = (string)post('due_at', '');
            $due = $due !== '' ? to_gregorian($due) : null;
            $happened = (string)post('happened_at', '');
            $happened = $happened !== '' ? to_gregorian($happened) : null;
            PersonActivity::store($pid, $type, (string)post('subject'), (string)post('body'), $due, $happened);
            Flash::push('success', 'فعالیت ثبت شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/persons/' . $pid);
        return '';
    }

    public function activityDone(array $p): string
    {
        $this->guardWrite(); csrf_verify();
        try { PersonActivity::toggleDone((int)$p['aid']); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/persons/' . (int)$p['id']);
        return '';
    }

    public function activityDelete(array $p): string
    {
        $this->guardWrite(); csrf_verify();
        try { PersonActivity::delete((int)$p['aid']); Flash::push('success', 'فعالیت حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/persons/' . (int)$p['id']);
        return '';
    }

    /* ───────────── اسناد (پیوست شخص) ───────────── */

    public function docStore(array $p): string
    {
        $this->guardWrite(); csrf_verify();
        $person = $this->person((int)$p['id']);
        $biz = (int)Auth::businessId();
        $pid = (int)$person['id'];
        try {
            $f = $_FILES['file'] ?? [];
            if ((int)($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) throw new RuntimeException('فایلی انتخاب نشده است.');
            if ((int)$f['error'] !== UPLOAD_ERR_OK) throw new RuntimeException('آپلود ناموفق بود.');
            if ((int)($f['size'] ?? 0) > 20 * 1024 * 1024) throw new RuntimeException('حجم فایل باید کمتر از ۲۰ مگابایت باشد.');
            if (!is_uploaded_file((string)($f['tmp_name'] ?? ''))) throw new RuntimeException('فایل نامعتبر است.');
            $orig = mb_substr((string)($f['name'] ?? 'file'), 0, 255);
            $dir = storage_path('person-docs/' . $pid);
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) throw new RuntimeException('ساخت پوشه ممکن نشد.');
            $safe = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
            if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $safe)) throw new RuntimeException('ذخیره فایل ممکن نشد.');
            @chmod($dir . '/' . $safe, 0644);
            Database::insert('attachments', [
                'business_id' => $biz, 'entity_type' => 'person', 'entity_id' => $pid,
                'file_name' => $orig, 'storage_key' => 'person-docs/' . $pid . '/' . $safe,
                'mime_type' => (string)($f['type'] ?? 'application/octet-stream'), 'size_bytes' => (int)$f['size'],
                'uploaded_by' => Auth::id(), 'is_public' => 0, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            Flash::push('success', 'سند پیوست شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/persons/' . $pid);
        return '';
    }

    public function docDownload(array $p): string
    {
        $this->guard();
        $biz = (int)Auth::businessId();
        $a = Database::one('SELECT * FROM attachments WHERE id=? AND business_id=? AND entity_type="person"', [(int)$p['aid'], $biz]);
        if (!$a) { http_response_code(404); exit('سند یافت نشد.'); }
        $path = storage_path(ltrim((string)$a['storage_key'], '/'));
        if (!is_file($path)) { http_response_code(404); exit('فایل روی سرور موجود نیست.'); }
        $inline = str_starts_with((string)$a['mime_type'], 'image/') || (string)$a['mime_type'] === 'application/pdf';
        header('Content-Type: ' . (string)$a['mime_type']);
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . rawurlencode((string)$a['file_name']) . '"');
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    public function docDelete(array $p): string
    {
        $this->guardWrite(); csrf_verify();
        $biz = (int)Auth::businessId();
        $a = Database::one('SELECT * FROM attachments WHERE id=? AND business_id=? AND entity_type="person"', [(int)$p['aid'], $biz]);
        if ($a) {
            $path = storage_path(ltrim((string)$a['storage_key'], '/'));
            if (is_file($path)) @unlink($path);
            Database::run('DELETE FROM attachments WHERE id=?', [(int)$a['id']]);
            Flash::push('success', 'سند حذف شد.');
        }
        redirect('app/persons/' . (int)$p['id']);
        return '';
    }
}
