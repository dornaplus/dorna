<?php
/**
 * تنخواه گردان — داشبورد، تنخواه‌ها، اسناد، گردش تأیید، گزارش و چاپ
 */
final class PettyCashController
{
    private function guard(string $perm = 'petty_cash.view'): void
    {
        Auth::requireApp();
        if (!Auth::can($perm)) abort(403, 'مجوز لازم برای این بخش از تنخواه گردان را ندارید.');
    }

    /* ─────────────── داشبورد ─────────────── */
    public function index(array $p): string
    {
        $this->guard();
        $from = to_gregorian((string)($_GET['from'] ?? '')) ?: date('Y-m-01');
        $to = to_gregorian((string)($_GET['to'] ?? '')) ?: today();
        $fundId = (int)($_GET['fund_id'] ?? 0);
        $stats = PettyCash::stats($from, $to, $fundId);
        return view('pages/petty_cash/index', [
            'title' => 'تنخواه گردان', 'stats' => $stats,
            'funds' => PettyCash::visibleFunds(),
            'byCategory' => PettyCash::byCategory($from, $to, $fundId),
            'recent' => PettyCash::entries(['from' => $from, 'to' => $to, 'fund_id' => $fundId], 8),
            'pending' => PettyCash::entries(['status' => 'pending'], 6),
            'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '', 'fundId' => $fundId,
            'gregFrom' => $from, 'gregTo' => $to,
        ]);
    }

    /* ─────────────── تنخواه‌ها ─────────────── */
    public function funds(array $p): string
    {
        $this->guard();
        if (!Auth::can('petty_cash.edit') && !Auth::can('petty_cash.approve')) {
            // تنخواه‌دار فقط تنخواه خودش را می‌بیند
            return view('pages/petty_cash/funds', ['title' => 'تنخواه‌های من', 'rows' => PettyCash::visibleFunds(), 'canManage' => false]);
        }
        return view('pages/petty_cash/funds', ['title' => 'تنخواه‌داران', 'rows' => PettyCash::funds(), 'canManage' => true]);
    }

    public function fundForm(array $p): string
    {
        $this->guard('petty_cash.edit');
        $biz = (int)Auth::businessId();
        $row = !empty($p['id']) ? PettyCash::fund((int)$p['id']) : null;
        if (!empty($p['id']) && !$row) abort(404, 'تنخواه یافت نشد.');
        $defaultGl = (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key="petty_cash"', [$biz], 0);
        if (!$defaultGl) $defaultGl = (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key="cash"', [$biz], 0);
        return view('pages/petty_cash/fund_form', [
            'title' => $row ? 'ویرایش تنخواه ' . $row['title'] : 'تعریف تنخواه جدید',
            'row' => $row, 'defaultGl' => $defaultGl, 'nextCode' => PettyCash::nextFundCode($biz),
            'accounts' => Database::all('SELECT id, code, title, full_path FROM chart_of_accounts
                                          WHERE business_id=? AND is_group=0 AND status="active" AND account_type IN ("asset","expense") ORDER BY code', [$biz]),
            'users' => Database::all('SELECT u.id, u.full_name FROM user_business_roles ubr JOIN users u ON u.id=ubr.user_id
                                       WHERE ubr.business_id=? AND ubr.is_active=1 ORDER BY u.full_name', [$biz]),
            'persons' => Database::all('SELECT id, code, first_name, last_name, company_name FROM persons
                                         WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
        ]);
    }

    public function fundStore(array $p): string
    {
        $this->guard('petty_cash.edit');
        csrf_verify();
        $id = (int)post('id');
        try {
            $newId = PettyCash::saveFund([
                'title' => (string)post('title'), 'code' => (string)post('code'),
                'keeper_user_id' => post('keeper_user_id') ? (int)post('keeper_user_id') : null,
                'person_id' => post('person_id') ? (int)post('person_id') : null,
                'gl_account_id' => (int)post('gl_account_id'),
                'ceiling_amount' => fa_num((string)post('ceiling_amount', '0')),
                'low_balance_amount' => fa_num((string)post('low_balance_amount', '0')),
                'status' => (string)post('status', 'active'), 'note' => (string)post('note'),
            ], $id ?: null);
            Flash::push('success', 'تنخواه ذخیره شد.');
            redirect('app/petty-cash/funds');
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', $e->getMessage());
            redirect($id ? 'app/petty-cash/funds/' . $id . '/edit' : 'app/petty-cash/funds/create');
        }
        return '';
    }

    public function fundDelete(array $p): string
    {
        $this->guard('petty_cash.edit');
        csrf_verify();
        try {
            PettyCash::deleteFund((int)($p['id'] ?? 0));
            Flash::push('success', 'تنخواه حذف شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/petty-cash/funds');
        return '';
    }

    /* ─────────────── اسناد ─────────────── */
    public function entries(array $p): string
    {
        $this->guard();
        $f = [
            'fund_id' => (int)($_GET['fund_id'] ?? 0), 'type' => (string)($_GET['type'] ?? ''),
            'status' => (string)($_GET['status'] ?? ''), 'category_id' => (int)($_GET['category_id'] ?? 0),
            'q' => trim((string)($_GET['q'] ?? '')),
            'from' => to_gregorian((string)($_GET['from'] ?? '')), 'to' => to_gregorian((string)($_GET['to'] ?? '')),
        ];
        $page = max(1, (int)($_GET['page'] ?? 1)); $per = 25;
        $total = PettyCash::entriesCount($f);
        return view('pages/petty_cash/entries', [
            'title' => 'اسناد تنخواه', 'rows' => PettyCash::entries($f, $per, ($page - 1) * $per),
            'total' => $total, 'page' => $page, 'per' => $per, 'f' => $f, 'funds' => PettyCash::visibleFunds(true),
            'categories' => Database::all('SELECT id, title FROM profit_loss_categories WHERE business_id=? AND is_active=1 AND kind="expense" ORDER BY title', [(int)Auth::businessId()]),
        ]);
    }

    public function show(array $p): string
    {
        $this->guard();
        $e = PettyCash::entry((int)($p['id'] ?? 0));
        if (!$e) abort(404, 'سند تنخواه یافت نشد.');
        $f = PettyCash::fund((int)$e['fund_id']);
        if ($f && !PettyCash::canSee($f)) abort(403, 'به این سند دسترسی ندارید.');
        $je = $e['journal_entry_id'] ? Database::one('SELECT * FROM journal_entries WHERE id=?', [(int)$e['journal_entry_id']]) : null;
        $jeLines = $je ? Database::all('SELECT l.*, a.code AS account_code, a.title AS account_title FROM journal_entry_lines l
                                          JOIN chart_of_accounts a ON a.id=l.account_id WHERE l.journal_entry_id=? ORDER BY l.row_no', [(int)$je['id']]) : [];
        return view('pages/petty_cash/entry_show', ['title' => 'سند تنخواه ' . $e['doc_no'], 'e' => $e, 'je' => $je, 'jeLines' => $jeLines]);
    }

    public function create(array $p): string
    {
        $this->guard('petty_cash.create');
        $type = in_array((string)($_GET['type'] ?? ''), array_keys(PettyCash::TYPES), true) ? (string)$_GET['type'] : 'expense';
        $biz = (int)Auth::businessId();
        $fundId = (int)($_GET['fund_id'] ?? 0);
        return view('pages/petty_cash/entry_form', [
            'title' => 'ثبت ' . PettyCash::typeTitle($type), 'type' => $type,
            'funds' => PettyCash::visibleFunds(true), 'fundId' => $fundId,
            'fund' => $fundId ? PettyCash::fund($fundId) : null,
            'categories' => Database::all('SELECT id, title, default_account_id FROM profit_loss_categories WHERE business_id=? AND is_active=1 ORDER BY kind, title', [$biz]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_group=0 AND status="active" ORDER BY code', [$biz]),
            'cashAccounts' => Database::all('SELECT id, title, account_kind, current_balance FROM cash_accounts WHERE business_id=? AND status="active" ORDER BY id', [$biz]),
            'costCenters' => Database::all('SELECT id, name FROM cost_centers WHERE business_id=? AND is_active=1 ORDER BY name', [$biz]),
            'persons' => Database::all('SELECT id, code, first_name, last_name, company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
            'defaultExpense' => PettyCash::defaultExpenseAccount(),
            'canApprove' => PettyCash::canApprove(),
            'nextNo' => Sequence::peek((int)$biz, Auth::fiscalYearId(), 'voucher'),
        ]);
    }

    public function store(array $p): string
    {
        $this->guard('petty_cash.create');
        csrf_verify();
        $type = (string)post('entry_type', 'expense');
        $back = 'app/petty-cash/create?type=' . $type . (post('fund_id') ? '&fund_id=' . (int)post('fund_id') : '');
        try {
            $id = PettyCash::createEntry([
                'fund_id' => (int)post('fund_id'), 'entry_type' => $type,
                'amount' => fa_num((string)post('amount')), 'title' => (string)post('title'),
                'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'category_id' => post('category_id') ? (int)post('category_id') : null,
                'cost_center_id' => post('cost_center_id') ? (int)post('cost_center_id') : null,
                'person_id' => post('person_id') ? (int)post('person_id') : null,
                'expense_account_id' => post('expense_account_id') ? (int)post('expense_account_id') : null,
                'cash_account_id' => post('cash_account_id') ? (int)post('cash_account_id') : null,
                'reference_no' => (string)post('reference_no'), 'description' => (string)post('description'),
                'auto_approve' => post('auto_approve') ? 1 : 0,
            ]);
            if (!empty($_FILES['files'])) PettyCash::saveUploads($id, 'files');
            Flash::push('success', PettyCash::canApprove() && post('auto_approve')
                ? 'سند ثبت و تأیید شد (سند حسابداری صادر گردید).'
                : 'سند ثبت شد و در انتظار تأیید است.');
            Flash::clearOld();
            redirect('app/petty-cash/' . $id);
        } catch (Throwable $e) {
            Flash::keep($_POST);
            Flash::push('error', $e->getMessage());
            redirect($back);
        }
        return '';
    }

    public function approve(array $p): string
    {
        $this->guard('petty_cash.approve');
        csrf_verify();
        try { PettyCash::approve((int)($p['id'] ?? 0)); Flash::push('success', 'سند تأیید و سند حسابداری آن صادر شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/petty-cash/' . (int)($p['id'] ?? 0));
        return '';
    }

    public function reject(array $p): string
    {
        $this->guard('petty_cash.approve');
        csrf_verify();
        try { PettyCash::reject((int)($p['id'] ?? 0), (string)post('reason')); Flash::push('success', 'سند رد شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/petty-cash/' . (int)($p['id'] ?? 0));
        return '';
    }

    public function deleteEntry(array $p): string
    {
        $this->guard('petty_cash.edit');
        csrf_verify();
        try { PettyCash::deleteEntry((int)($p['id'] ?? 0)); Flash::push('success', 'سند تنخواه حذف شد و سند حسابداری آن برگشت خورد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/petty-cash/entries');
        return '';
    }

    /* ─────────────── پیوست ─────────────── */
    public function attachment(array $p): string
    {
        $this->guard();
        $a = PettyCash::attachment((int)($p['id'] ?? 0));
        if (!$a) abort(404, 'فایل یافت نشد.');
        $e = PettyCash::entry((int)$a['entry_id']);
        $f = $e ? PettyCash::fund((int)$e['fund_id']) : null;
        if (!$e || !$f || !PettyCash::canSee($f)) abort(403, 'به این فایل دسترسی ندارید.');
        $path = PettyCash::attachmentPath($a);
        if (!is_file($path)) abort(404, 'فایل روی سرور موجود نیست.');
        header('Content-Type: ' . ($a['mime_type'] ?: 'application/octet-stream'));
        header('Content-Length: ' . filesize($path));
        header('Content-Disposition: ' . (($_GET['dl'] ?? '') === '1' ? 'attachment' : 'inline') . '; filename="' . rawurlencode((string)$a['file_name']) . '"');
        readfile($path);
        return '';
    }

    /* ─────────────── گزارش و چاپ ─────────────── */
    public function reports(array $p): string
    {
        $this->guard();
        $from = to_gregorian((string)($_GET['from'] ?? '')) ?: date('Y-m-01');
        $to = to_gregorian((string)($_GET['to'] ?? '')) ?: today();
        $fundId = (int)($_GET['fund_id'] ?? 0);
        $fund = $fundId ? PettyCash::fund($fundId) : null;
        $ledger = $fundId ? PettyCash::ledger($fundId, $from, $to) : ['opening' => 0, 'rows' => []];
        $running = $ledger['opening'];
        foreach ($ledger['rows'] as &$r) {
            $running += ((string)$r['entry_type'] === 'expense' || (string)$r['entry_type'] === 'settle') ? -(float)$r['amount'] : (float)$r['amount'];
            $r['running'] = round($running, 2);
        }
        unset($r);
        if (($_GET['export'] ?? '') === 'csv') {
            $headers = ['تاریخ', 'شماره', 'نوع', 'بابت', 'مبلغ', 'مانده'];
            $out = [];
            foreach ($ledger['rows'] as $r) $out[] = [jdate($r['doc_date']), $r['doc_no'], PettyCash::typeTitle((string)$r['entry_type']), $r['title'], num((float)$r['amount'], 0), num($r['running'], 0)];
            csv_download('petty-cash-' . ($fund['code'] ?? 'all'), $headers, $out);
            return '';
        }
        return view('pages/petty_cash/reports', [
            'title' => 'گزارشات تنخواه', 'from' => $_GET['from'] ?? '', 'to' => $_GET['to'] ?? '',
            'gregFrom' => $from, 'gregTo' => $to, 'fundId' => $fundId, 'fund' => $fund,
            'funds' => PettyCash::visibleFunds(), 'stats' => PettyCash::stats($from, $to, $fundId),
            'byCategory' => PettyCash::byCategory($from, $to, $fundId),
            'ledgerOpening' => $ledger['opening'], 'ledgerRows' => $ledger['rows'],
        ]);
    }

    public function printEntry(array $p): string
    {
        $this->guard('petty_cash.print');
        $e = PettyCash::entry((int)($p['id'] ?? 0));
        if (!$e) abort(404, 'سند تنخواه یافت نشد.');
        if ($e['status'] !== 'approved') { Flash::push('error', 'فقط سند تأییدشده قابل چاپ است.'); redirect('app/petty-cash/' . $e['id']); }
        return view('pages/petty_cash/print_entry', [
            'title' => 'چاپ سند تنخواه ' . $e['doc_no'], 'e' => $e, 'business' => Auth::business(),
            'tpl' => Printing::template('voucher'),
            'amountWords' => InvoiceController::amountInWords((float)$e['amount']),
        ]);
    }
}
