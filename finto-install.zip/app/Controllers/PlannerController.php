<?php
/**
 * برنامه‌ریز (پلنر) — تقویم تمام‌صفحه، وظایف، تخصیص به کاربران، وضعیت انجام و تنظیمات.
 */
final class PlannerController
{
    private function guard(): void { Auth::requireApp(); }

    private function json(array $d): string
    {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($d, JSON_UNESCAPED_UNICODE);
        return '';
    }

    /* ───────────── تقویم ───────────── */
    public function index(array $p): string
    {
        $this->guard();
        $biz = (int)Auth::businessId();
        Planner::seedTypes($biz, (int)Auth::id());
        $st = Planner::settings();

        $view = (string)($_GET['view'] ?? $st['default_view']);
        if (!in_array($view, ['month', 'agenda'], true)) $view = 'month';
        [$cy, $cm] = current_jalali_ym();
        $jy = (int)($_GET['y'] ?? $cy);
        $jm = (int)($_GET['m'] ?? $cm);
        if ($jm < 1 || $jm > 12) $jm = $cm;
        if ($jy < 1300 || $jy > 1500) $jy = $cy;

        // بازهٔ محاسبه
        if ($view === 'agenda') {
            $from = to_gregorian((string)($_GET['from'] ?? '')) ?: today();
            $to   = to_gregorian((string)($_GET['to'] ?? '')) ?: date('Y-m-d', strtotime(today() . ' +30 days'));
            if ($to < $from) $to = date('Y-m-d', strtotime($from . ' +30 days'));
        } else {
            [$gy1, $gm1, $gd1] = jalali_to_gregorian($jy, $jm, 1);
            $len = Planner::jalaliMonthLen($jy, $jm);
            [$gy2, $gm2, $gd2] = jalali_to_gregorian($jy, $jm, $len);
            // کل شبکهٔ ۶ هفته‌ای (خارج از ماه هم رویداد نشان دهیم)
            $from = date('Y-m-d', mktime(0, 0, 0, $gm1, $gd1, $gy1) - 7 * 86400);
            $to   = date('Y-m-d', mktime(0, 0, 0, $gm2, $gd2, $gy2) + 7 * 86400);
        }

        $filters = [
            'assignee' => (int)($_GET['assignee'] ?? 0), 'type_id' => (int)($_GET['type_id'] ?? 0),
            'status' => array_values(array_filter((array)($_GET['status'] ?? []), fn($s) => isset(Planner::STATUSES[$s]))),
            'priority' => (string)($_GET['priority'] ?? ''), 'q' => (string)($_GET['q'] ?? ''),
        ];
        // بازهٔ آمار: ماه جاری در نمای ماه، و بازهٔ انتخابی در نمای فهرست
        if ($view === 'agenda') { $statFrom = $from; $statTo = $to; }
        else {
            [$sy, $sm, $sd] = jalali_to_gregorian($jy, $jm, 1);
            [$ey, $em, $ed] = jalali_to_gregorian($jy, $jm, Planner::jalaliMonthLen($jy, $jm));
            $statFrom = sprintf('%04d-%02d-%02d', $sy, $sm, $sd);
            $statTo = sprintf('%04d-%02d-%02d', $ey, $em, $ed);
        }
        $events = Planner::events($from, $to, $filters);
        $byDay = Planner::byDay($events, $from, $to);

        $openId = (int)($_GET['open'] ?? 0);
        if (!$openId && !empty($_SESSION['planner_open'])) { $openId = (int)$_SESSION['planner_open']; unset($_SESSION['planner_open']); }
        $openEvent = $openId ? Planner::event($openId) : null;
        if ($openEvent) {
            $openEvent['can_edit'] = Planner::canEdit($openEvent);
            $openEvent['can_status'] = Planner::canUpdateStatus($openEvent);
        }
        $dayIso = to_gregorian((string)($_GET['day'] ?? '')) ?: null;
        $dayEvents = $dayIso ? Planner::events($dayIso, $dayIso, []) : [];
        $newDate = to_gregorian((string)($_GET['new'] ?? '')) ?: null;

        return view('pages/planner/calendar', [
            'title' => 'برنامه‌ریز و تقویم', 'view' => $view, 'jy' => $jy, 'jm' => $jm,
            'from' => $from, 'to' => $to, 'events' => $events, 'byDay' => $byDay,
            'cells' => $view === 'month' ? Planner::monthGrid($jy, $jm) : [],
            'types' => Planner::types(), 'users' => Planner::users(), 'settings' => $st,
            'stats' => Planner::stats($statFrom, $statTo),
            'filters' => $filters, 'openEvent' => $openEvent,
            'openComments' => $openEvent ? Planner::comments((int)$openEvent['id']) : [],
            'canManageAll' => Planner::canManageAll(),
            'dayIso' => $dayIso, 'dayEvents' => $dayEvents, 'newDate' => $newDate,
            'projects' => Planner::projects(), 'attachments' => $openEvent ? Planner::attachments((int)$openEvent['id']) : [],
            'aiEnabled' => Ai::enabled(),
        ]);
    }

    /** رویدادهای یک روز (JSON برای پنل روز) */
    public function day(array $p): string
    {
        $this->guard();
        $iso = to_gregorian((string)($_GET['date'] ?? '')) ?: today();
        $events = Planner::events($iso, $iso, []);
        $out = [];
        foreach ($events as $e) $out[] = $this->present($e);
        return $this->json(['ok' => true, 'date' => $iso, 'jalali' => jdate($iso), 'events' => $out]);
    }

    /** یک رویداد + گفت‌وگو (JSON) */
    public function show(array $p): string
    {
        $this->guard();
        $e = Planner::event((int)$p['id']);
        if (!$e) return $this->json(['ok' => false, 'error' => 'رویداد یافت نشد.']);
        $cs = [];
        foreach (Planner::comments((int)$e['id']) as $c) $cs[] = ['user' => (string)($c['user_name'] ?? '—'), 'body' => (string)$c['body'], 'at' => jdate((string)$c['created_at'], '/', true)];
        return $this->json(['ok' => true, 'event' => $this->present($e) + [
            'description' => (string)($e['description'] ?? ''), 'completion_note' => (string)($e['completion_note'] ?? ''),
            'can_edit' => Planner::canEdit($e), 'can_status' => Planner::canUpdateStatus($e),
            'comments' => $cs,
        ]]);
    }

    private function present(array $e): array
    {
        [$hex, $soft] = Planner::colorHex((string)($e['type_color'] ?? 'purple'));
        $st = (string)$e['status'];
        $due = (string)($e['end_date'] ?: $e['start_date']);
        $d = (int)round((strtotime($due) - strtotime(today())) / 86400);
        return [
            'id' => (int)$e['id'], 'title' => (string)$e['title'],
            'type' => (string)($e['type_title'] ?? ''), 'icon' => (string)($e['type_icon'] ?? 'check'),
            'color' => $hex, 'soft' => $soft,
            'start' => (string)$e['start_date'], 'end' => (string)($e['end_date'] ?? ''),
            'start_jalali' => jdate((string)$e['start_date']), 'end_jalali' => $e['end_date'] ? jdate((string)$e['end_date']) : '',
            'all_day' => (int)$e['all_day'], 'start_time' => (string)($e['start_time'] ?? ''), 'end_time' => (string)($e['end_time'] ?? ''),
            'priority' => (string)$e['priority'], 'priority_label' => Planner::PRIORITIES[(string)$e['priority']] ?? '',
            'status' => $st, 'status_label' => Planner::STATUSES[$st] ?? $st, 'progress' => (int)$e['progress'],
            'assignee' => (string)($e['assignee_name'] ?? ''), 'assignee_id' => (int)($e['assignee_user_id'] ?? 0),
            'creator' => (string)($e['creator_name'] ?? ''), 'location' => (string)($e['location'] ?? ''),
            'days_left' => $d, 'due_jalali' => jdate($due),
            'repeat' => (string)$e['repeat_rule'], 'remind_days' => (int)$e['remind_days'],
        ];
    }

    /* ───────────── پیوست‌ها ───────────── */
    public function attach(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            $res = Planner::saveUpload((int)$p['id'], 'file');
            if ($res['error']) throw new RuntimeException((string)$res['error']);
            if ($res['empty']) Flash::push('info', 'فایلی انتخاب نشده بود.');
            else Flash::push('success', 'فایل برای مدیر ارسال شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/planner?open=' . (int)$p['id']);
        return '';
    }

    /** نمایش/دانلود فایل پیوست (فقط برای افراد مرتبط با رویداد) */
    public function attachment(array $p): string
    {
        $this->guard();
        $a = Planner::attachment((int)$p['id']);
        if (!$a) { http_response_code(404); exit('فایل یافت نشد.'); }
        $e = Planner::event((int)$a['event_id']);
        if (!$e) { http_response_code(403); exit('دسترسی ندارید.'); }
        $path = Planner::attachmentPath($a);
        if (!is_file($path)) { http_response_code(404); exit('فایل روی سرور موجود نیست.'); }
        $inline = str_starts_with((string)$a['mime_type'], 'image/') || (string)$a['mime_type'] === 'application/pdf';
        if (headers_sent()) exit('خطا در ارسال فایل.');
        header('Content-Type: ' . (string)$a['mime_type']);
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . rawurlencode((string)$a['file_name']) . '"');
        header('Content-Length: ' . filesize($path));
        header('Cache-Control: private, no-store');
        readfile($path);
        exit;
    }

    public function attachDelete(array $p): string
    {
        $this->guard(); csrf_verify();
        $evId = (int)post('event_id');
        try { Planner::deleteAttachment((int)$p['id']); Flash::push('success', 'فایل حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect($evId ? 'app/planner?open=' . $evId : 'app/planner');
        return '';
    }

    /* ───────────── برد مدیریت پروژه ───────────── */
    public function board(array $p): string
    {
        $this->guard();
        Planner::seedTypes((int)Auth::businessId(), (int)Auth::id());
        $filters = [
            'project_id' => (int)($_GET['project_id'] ?? 0), 'assignee' => (int)($_GET['assignee'] ?? 0),
            'type_id' => (int)($_GET['type_id'] ?? 0), 'priority' => (string)($_GET['priority'] ?? ''), 'q' => (string)($_GET['q'] ?? ''),
        ];
        $cols = Planner::board($filters);
        return view('pages/planner/board', [
            'title' => 'برد پروژه‌ها', 'cols' => $cols, 'filters' => $filters,
            'projects' => Planner::projects(false), 'users' => Planner::users(), 'types' => Planner::types(),
            'summary' => Planner::projectSummary(), 'settings' => Planner::settings(),
            'canManageAll' => Planner::canManageAll(),
        ]);
    }

    /* ───────────── هوش مصنوعی برنامه‌ریز (AvalAI) ───────────── */
    /** بافت وظایف کاربر برای ارسال به مدل */
    private function aiContext(): string
    {
        $from = date('Y-m-d', strtotime(today() . ' -30 days'));
        $to = date('Y-m-d', strtotime(today() . ' +120 days'));
        $rows = Planner::events($from, $to, []);
        $out = [];
        foreach (array_slice($rows, 0, 60) as $e) {
            $due = (string)($e['end_date'] ?: $e['start_date']);
            $d = (int)round((strtotime($due) - strtotime(today())) / 86400);
            $out[] = sprintf('- %s | وضعیت: %s | اولویت: %s | مسئول: %s | سررسید: %s (%s) | پیشرفت: %d%%',
                (string)$e['title'], Planner::STATUSES[(string)$e['status']] ?? '', Planner::PRIORITIES[(string)$e['priority']] ?? '',
                (string)($e['assignee_name'] ?? '—'), jdate($due, '/'), $d < 0 ? abs($d) . ' روز گذشته' : ($d === 0 ? 'امروز' : $d . ' روز مانده'), (int)$e['progress']);
        }
        return ($out ? implode("\n", $out) : '(فهرست وظایف خالی است)');
    }

    public function aiPlan(array $p): string
    {
        $this->guard(); csrf_verify();
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'هوش مصنوعی فعال نیست. کلید AvalAI را در «تنظیمات ← هوش مصنوعی» وارد کنید.']);
        $q = trim((string)post('q'));
        $today = jdate(today());
        $sys = 'تو دستیار برنامه‌ریزی کسب‌وکار ایرانی هستی. خروجی را فارسی، کوتاه، حرفه‌ای و فقط در قالب این سه بخش بده:\n'
             . '۱) وضعیت کلی (۲ جمله)\n۲) اولویت‌های امروز (حداکثر ۵ مورد، هر کدام در یک خط با «- »)\n۳) هشدار و پیشنهاد (حداکثر ۳ مورد با «- »)\n'
             . 'از تاریخ شمسی استفاده کن و هیچ مقدمه یا توضیح اضافه ننویس.';
        $user = 'امروز: ' . $today . "\n\nوظایف برنامه‌ریز:\n" . $this->aiContext() . ($q !== '' ? "\n\nدرخواست مدیر: " . $q : '');
        $r = Ai::chat([['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $user]], ['max_tokens' => 900, 'temperature' => 0.3, 'type' => 'planner_plan']);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => (string)($r['error'] ?? 'خطای نامشخص')]);
        return $this->json(['ok' => true, 'text' => trim((string)$r['text']), 'usage' => $r['usage'] ?? []]);
    }

    /** تبدیل متن آزاد به فیلدهای رویداد (ساخت سریع وظیفه) */
    public function aiParse(array $p): string
    {
        $this->guard(); csrf_verify();
        $text = trim((string)post('text'));
        if (mb_strlen($text) < 4) return $this->json(['ok' => false, 'error' => 'متن کوتاه است؛ توضیح بیشتری بنویسید.']);
        if (!Ai::enabled()) return $this->json(['ok' => false, 'error' => 'هوش مصنوعی فعال نیست (کلید AvalAI در تنظیمات).']);
        $types = array_map(fn($t) => (string)$t['title'], Planner::types());
        $users = array_map(fn($u) => (string)$u['full_name'], Planner::users());
        $sys = 'متن فارسی کاربر را به یک رویداد برنامه‌ریز تبدیل کن و فقط JSON برگردان با این کلیدها: '
             . 'title (متن کوتاه), days_offset (عدد صحیح؛ ۰=امروز، ۱=فردا، منفی=قبل), duration_days (عدد صحیح >=۱), '
             . 'priority (یکی از low|normal|high|urgent), type (از فهرست موجود یا خالی), assignee (نام دقیق از فهرست یا خالی), '
             . 'location (یا خالی), description (یا خالی), remind_days (عدد صحیح).';
        $user = 'امروز: ' . jdate(today()) . "\nانواع موجود: " . implode('، ', $types) . "\nکاربران: " . implode('، ', $users) . "\n\nمتن: " . $text;
        $r = Ai::json([['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $user]], ['max_tokens' => 500, 'temperature' => 0.2, 'type' => 'planner_parse']);
        if (empty($r['ok'])) return $this->json(['ok' => false, 'error' => (string)($r['error'] ?? 'خطای نامشخص')]);
        $d = (array)$r['data'];
        $offset = (int)($d['days_offset'] ?? 0);
        $dur = max(1, (int)($d['duration_days'] ?? 1));
        $start = date('Y-m-d', strtotime(today() . ' ' . ($offset >= 0 ? '+' : '-') . abs($offset) . ' days'));
        $end = $dur > 1 ? date('Y-m-d', strtotime($start . ' +' . ($dur - 1) . ' days')) : null;
        $typeId = 0;
        foreach (Planner::types() as $t) if (trim((string)$t['title']) === trim((string)($d['type'] ?? ''))) $typeId = (int)$t['id'];
        $assigneeId = 0;
        foreach (Planner::users() as $u) if (trim((string)$u['full_name']) === trim((string)($d['assignee'] ?? ''))) $assigneeId = (int)$u['id'];
        return $this->json(['ok' => true, 'event' => [
            'title' => mb_substr((string)($d['title'] ?? $text), 0, 190),
            'start_jalali' => jdate($start), 'start_iso' => $start,
            'end_jalali' => $end ? jdate($end) : '', 'end_iso' => (string)$end,
            'priority' => array_key_exists((string)($d['priority'] ?? ''), Planner::PRIORITIES) ? (string)$d['priority'] : 'normal',
            'type_id' => $typeId, 'assignee_id' => $assigneeId,
            'location' => (string)($d['location'] ?? ''), 'description' => (string)($d['description'] ?? ''),
            'remind_days' => max(0, min(60, (int)($d['remind_days'] ?? 1))),
        ]]);
    }

    /* ───────────── ذخیره/ویرایش ───────────── */
    public function store(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            $id = Planner::save([
                'title' => (string)post('title'), 'description' => (string)post('description'),
                'location' => (string)post('location'), 'type_id' => (int)post('type_id', 0),
                'start_date' => to_gregorian((string)post('start_date')) ?: today(),
                'end_date' => to_gregorian((string)post('end_date')),
                'all_day' => post('all_day') ? 1 : 0,
                'start_time' => (string)post('start_time'), 'end_time' => (string)post('end_time'),
                'priority' => (string)post('priority', 'normal'), 'assignee_user_id' => (int)post('assignee_user_id', 0),
                'repeat_rule' => (string)post('repeat_rule', 'none'), 'remind_days' => (int)post('remind_days', 1),
                'project_id' => (int)post('project_id', 0),
            ]);
            Flash::push('success', 'رویداد ثبت شد.');
            $_SESSION['planner_open'] = $id;
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); }
        redirect('app/planner');
        return '';
    }

    public function update(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            Planner::save([
                'title' => (string)post('title'), 'description' => (string)post('description'),
                'location' => (string)post('location'), 'type_id' => (int)post('type_id', 0),
                'start_date' => to_gregorian((string)post('start_date')) ?: today(),
                'end_date' => to_gregorian((string)post('end_date')),
                'all_day' => post('all_day') ? 1 : 0,
                'start_time' => (string)post('start_time'), 'end_time' => (string)post('end_time'),
                'priority' => (string)post('priority', 'normal'), 'assignee_user_id' => (int)post('assignee_user_id', 0),
                'repeat_rule' => (string)post('repeat_rule', 'none'), 'remind_days' => (int)post('remind_days', 1),
                'project_id' => (int)post('project_id', 0),
            ], (int)$p['id']);
            Flash::push('success', 'رویداد ویرایش شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/planner?open=' . (int)$p['id']);
        return '';
    }

    public function status(array $p): string
    {
        $this->guard(); csrf_verify();
        $ajax = (string)post('ajax') === '1';
        try {
            Planner::setStatus((int)$p['id'], (string)post('status'), (string)post('note'), (int)post('progress', -1));
            if ($ajax) return $this->json(['ok' => true, 'event' => $this->present(Planner::event((int)$p['id']) ?? [])]);
            Flash::push('success', 'وضعیت رویداد به‌روزرسانی شد.');
        } catch (Throwable $e) {
            if ($ajax) return $this->json(['ok' => false, 'error' => $e->getMessage()]);
            Flash::push('error', $e->getMessage());
        }
        if ((string)post('back') === 'board') { redirect('app/planner/board'); }
        redirect('app/planner?open=' . (int)$p['id']);
        return '';
    }

    public function comment(array $p): string
    {
        $this->guard(); csrf_verify();
        $ajax = (string)post('ajax') === '1';
        try {
            Planner::comment((int)$p['id'], (string)post('body'));
            if ($ajax) {
                $cs = [];
                foreach (Planner::comments((int)$p['id']) as $c) $cs[] = ['user' => (string)($c['user_name'] ?? '—'), 'body' => (string)$c['body'], 'at' => jdate((string)$c['created_at'], '/', true)];
                return $this->json(['ok' => true, 'comments' => $cs]);
            }
        } catch (Throwable $e) {
            if ($ajax) return $this->json(['ok' => false, 'error' => $e->getMessage()]);
            Flash::push('error', $e->getMessage());
        }
        redirect('app/planner?open=' . (int)$p['id']);
        return '';
    }

    public function delete(array $p): string
    {
        $this->guard(); csrf_verify();
        try { Planner::deleteEvent((int)$p['id']); Flash::push('success', 'رویداد حذف شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/planner');
        return '';
    }

    /* ───────────── تنظیمات پلنر ───────────── */
    public function settings(array $p): string
    {
        $this->guard();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        return view('pages/planner/settings', [
            'title' => 'تنظیمات برنامه‌ریز', 'types' => Planner::types(false), 'settings' => Planner::settings(),
            'colors' => Planner::COLORS, 'weekdays' => Planner::WEEKDAYS, 'users' => Planner::users(),
        ]);
    }

    public function settingsSave(array $p): string
    {
        $this->guard(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = (int)Auth::businessId();
        Settings::set($biz, 'planner.reminder_days', max(0, min(60, (int)fa_num(post('reminder_days', '1')))));
        Settings::set($biz, 'planner.default_view', in_array((string)post('default_view'), ['month', 'agenda'], true) ? (string)post('default_view') : 'month');
        Settings::set($biz, 'planner.max_visible', max(1, min(6, (int)fa_num(post('max_visible', '3')))));
        Settings::set($biz, 'planner.allow_user_create', post('allow_user_create') ? true : false);
        Settings::set($biz, 'planner.notify_manager', post('notify_manager') ? true : false);
        $days = array_map('intval', (array)($_POST['work_days'] ?? []));
        Settings::set($biz, 'planner.work_days', array_values(array_intersect($days, [0, 1, 2, 3, 4, 5, 6])));
        Planner::flush();
        Audit::log('update', 'settings', 0, 'ویرایش تنظیمات برنامه‌ریز');
        Flash::push('success', 'تنظیمات برنامه‌ریز ذخیره شد.');
        redirect('app/planner/settings');
        return '';
    }

    public function typeStore(array $p): string
    {
        $this->guard(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = (int)Auth::businessId();
        $id = (int)post('id', 0);
        $title = mb_substr(trim((string)post('title')), 0, 80);
        $color = array_key_exists((string)post('color'), Planner::COLORS) ? (string)post('color') : 'purple';
        $icon = mb_substr(preg_replace('/[^a-z0-9-]/', '', (string)post('icon', 'check')) ?: 'check', 0, 40);
        try {
            if ($title === '') throw new RuntimeException('عنوان نوع رویداد را وارد کنید.');
            if ($id) {
                Database::run('UPDATE planner_types SET title=?, color=?, icon=?, is_active=?, sort_order=?, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?',
                    [$title, $color, $icon, post('is_active') ? 1 : 0, (int)fa_num(post('sort_order', '0')), Auth::id(), $id, $biz]);
                Flash::push('success', 'نوع رویداد ویرایش شد.');
            } else {
                Database::insert('planner_types', ['business_id' => $biz, 'title' => $title, 'color' => $color, 'icon' => $icon,
                    'is_active' => 1, 'sort_order' => (int)fa_num(post('sort_order', '0')), 'created_at' => now(), 'created_by' => Auth::id()]);
                Flash::push('success', 'نوع رویداد اضافه شد.');
            }
            Audit::log($id ? 'update' : 'create', 'planner_types', $id, 'نوع رویداد برنامه‌ریز');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/planner/settings');
        return '';
    }

    public function typeDelete(array $p): string
    {
        $this->guard(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $id = (int)$p['id']; $biz = (int)Auth::businessId();
        $used = (int)Database::val('SELECT COUNT(*) FROM planner_events WHERE business_id=? AND type_id=? AND deleted_at IS NULL', [$biz, $id], 0);
        if ($used > 0) {
            Database::run('UPDATE planner_types SET is_active=0, deleted_at=NOW() WHERE id=? AND business_id=?', [$id, $biz]);
            Flash::push('info', 'این نوع در ' . num($used) . ' رویداد استفاده شده؛ غیرفعال شد (تاریخچه حفظ شد).');
        } else {
            Database::run('DELETE FROM planner_types WHERE id=? AND business_id=?', [$id, $biz]);
            Flash::push('success', 'نوع رویداد حذف شد.');
        }
        Audit::log('delete', 'planner_types', $id, 'حذف نوع رویداد');
        redirect('app/planner/settings');
        return '';
    }
}
