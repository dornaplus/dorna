<?php
/** پورتال مشتری — ورود با کد تایید، فاکتورها، صورت‌حساب و آپلود رسید */
final class PortalController
{
    /** شخص واردشده به پورتال (در غیر این صورت به ورود) */
    private function person(): array
    {
        $p = Portal::person();
        if (!$p) { redirect('portal'); }
        return $p;
    }

    public function login(array $p): string
    {
        if (Portal::person()) redirect('portal/dashboard');
        $error = null; $info = null; $mobile = '';
        if (is_post()) {
            csrf_verify();
            $mobile = AuthController::normalizeMobile((string)post('mobile'));
            if (!$mobile) $error = 'شماره موبایل معتبر نیست.';
            else {
                $per = Portal::findPerson($mobile);
                if (!$per) $error = 'مشتری‌ای با این شماره موبایل یافت نشد.';
                else {
                    try {
                        $code = Otp::create(null, $mobile, 'login');
                        $_SESSION['portal_mobile'] = $mobile;
                        $info = config('app')['demo_mode']
                            ? 'حالت نمایشی: کد تایید «' . $code . '» است.'
                            : 'کد تایید به شمارهٔ شما پیامک شد.';
                        redirect('portal/verify');
                    } catch (Throwable $e) { $error = $e->getMessage(); }
                }
            }
        }
        return view('pages/portal/login', ['title' => 'ورود مشتری', 'error' => $error, 'mobile' => $mobile]);
    }

    public function verify(array $p): string
    {
        $mobile = $_SESSION['portal_mobile'] ?? null;
        if (!$mobile) redirect('portal');
        $error = null; $info = null;
        if (config('app')['demo_mode']) {
            $demoCode = $_SESSION['_demo_otp'][$mobile] ?? '';
            if ($demoCode) $info = 'حالت نمایشی: کد تایید «' . $demoCode . '» است.';
        }
        if (is_post()) {
            csrf_verify();
            $code = preg_replace('/\D/', '', (string)post('code'));
            [$ok, $res] = Otp::verify($mobile, $code, 'login');
            if ($ok) {
                $per = Portal::findPerson($mobile);
                if (!$per) { $error = 'مشتری یافت نشد.'; }
                else {
                    unset($_SESSION['portal_mobile']);
                    $_SESSION['portal_person_id'] = (int)$per['id'];
                    redirect('portal/dashboard');
                }
            } else $error = $res;
        }
        return view('pages/portal/verify', ['title' => 'کد تایید', 'mobile' => $mobile, 'error' => $error, 'info' => $info]);
    }

    public function logout(array $p): string
    {
        unset($_SESSION['portal_person_id'], $_SESSION['portal_mobile']);
        redirect('portal');
        return '';
    }

    public function dashboard(array $p): string
    {
        $per = $this->person();
        $biz = (int)$per['business_id'];
        $invoices = Portal::invoices((int)$per['id'], $biz);
        $summary = Portal::summary((int)$per['id'], $biz);
        return view('pages/portal/dashboard', [
            'title' => 'حساب من', 'person' => $per, 'invoices' => $invoices, 'summary' => $summary,
            'accounts' => Portal::paymentAccounts($biz),
        ]);
    }

    public function uploadReceipt(array $p): string
    {
        $per = $this->person();
        csrf_verify();
        $biz = (int)$per['business_id'];
        try {
            Portal::saveReceipt($biz, (int)$per['id'], (int)post('invoice_id'), $_FILES['file'] ?? [], (string)post('note'));
            Flash::push('success', 'رسید پرداخت ارسال شد. پس از تأیید کارشناسان، فاکتور تسویه می‌شود.');
        } catch (Throwable $e) {
            Flash::push('error', $e->getMessage());
        }
        redirect('portal/dashboard');
        return '';
    }

    public function statement(array $p): string
    {
        $per = $this->person();
        $biz = (int)$per['business_id'];
        $invoices = Portal::invoices((int)$per['id'], $biz);
        $summary = Portal::summary((int)$per['id'], $biz);
        return view('pages/portal/statement', [
            'title' => 'صورت‌حساب', 'person' => $per, 'invoices' => $invoices, 'summary' => $summary,
            'business' => Database::one('SELECT * FROM businesses WHERE id=?', [$biz]),
        ]);
    }
}
