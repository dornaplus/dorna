<?php
/** مرکز گزارش‌های مالی — نمایش، فیلتر، خروجی CSV و چاپ گزارش‌های مبتنی بر نماها */
final class ReportController
{
    private function guard(): void { Auth::requireApp(); if (!Auth::can('reports.view')) abort(403, 'مجوز مشاهدهٔ گزارش‌ها را ندارید.'); }

    public function index(array $p): string
    {
        $this->guard();
        $groups = [];
        foreach (Meta::reports() as $key => $r) $groups[$r['group']][$key] = $r;
        return view('pages/reports/index', ['title' => 'مرکز گزارش‌ها', 'groups' => $groups]);
    }

    private function meta(string $key): array
    {
        $rep = Meta::reports()[$key] ?? null;
        if (!$rep) abort(404, 'گزارش یافت نشد.');
        $rep['key'] = $key;
        return $rep;
    }

    /** ساخت کوئری گزارش: [view, cols, where, params, filters, filterLabels, dateCol] */
    private function build(array $rep): array
    {
        $view = (string)$rep['view'];
        $cols = Schema::columns($view);
        $biz = Auth::businessId();
        $where = ['business_id = ?'];
        $params = [$biz];
        $filters = [];
        $filterLabels = [];

        // ستون تاریخ (برای فیلتر «date»)
        $dateCol = null;
        foreach (['entry_date', 'invoice_date', 'doc_date', 'rate_date', 'date'] as $cand) {
            if (isset($cols[$cand])) { $dateCol = $cand; break; }
        }
        if ($dateCol === null) foreach ($cols as $name => $m) { if (str_ends_with($name, '_date')) { $dateCol = $name; break; } }

        foreach ((array)($rep['filters'] ?? []) as $f) {
            if ($f === 'date') {
                $from = to_gregorian((string)($_GET['from'] ?? ''));
                $to = to_gregorian((string)($_GET['to'] ?? ''));
                if ($dateCol) {
                    if ($from) { $where[] = "`$dateCol` >= ?"; $params[] = $from; $filters['from'] = $_GET['from'] ?? ''; $filterLabels['from'] = 'از تاریخ'; }
                    if ($to) { $where[] = "`$dateCol` <= ?"; $params[] = $to . ' 23:59:59'; $filters['to'] = $_GET['to'] ?? ''; $filterLabels['to'] = 'تا تاریخ'; }
                }
                continue;
            }
            $v = $_GET[$f] ?? '';
            if ($v === '' || $v === null) continue;
            if (isset($cols[$f])) {
                $where[] = "`$f` = ?";
                $params[] = $v;
                $filters[$f] = $v;
                $filterLabels[$f] = Schema::label($view, $f);
            }
        }
        return [$view, $cols, $where, $params, $filters, $filterLabels, $dateCol];
    }

    private function fetch(array $rep, array $where, array $params, int $page, int $per, array &$cols): array
    {
        $view = (string)$rep['view'];
        $allCols = Schema::columns($view);
        $cols = array_keys(array_filter($allCols, fn($c) => !in_array($c, ['business_id', 'fiscal_year_id'], true)));
        $whereSql = implode(' AND ', $where);
        $total = (int)Database::val("SELECT COUNT(*) FROM `$view` WHERE $whereSql", $params, 0);
        $off = ($page - 1) * $per;
        $rows = Database::all("SELECT * FROM `$view` WHERE $whereSql LIMIT $per OFFSET $off", $params);
        $totals = [];
        if ($rows) {
            foreach ($cols as $c) {
                $m = $allCols[$c] ?? ['type' => 'varchar'];
                if (in_array($m['type'], ['decimal', 'double', 'float'], true)) {
                    $totals[$c] = (float)Database::val("SELECT IFNULL(SUM(`$c`),0) FROM `$view` WHERE $whereSql", $params, 0);
                }
            }
        }
        return [$rows, $totals, $total];
    }

    public function show(array $p): string
    {
        $this->guard();
        $rep = $this->meta((string)$p['key']);
        [$view, $allCols, $where, $params, $filters, $filterLabels] = $this->build($rep);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $per = max(10, min(500, (int)($_GET['per_page'] ?? 50)));
        $cols = [];
        try {
            [$rows, $totals, $total] = $this->fetch($rep, $where, $params, $page, $per, $cols);
            $runError = null;
        } catch (Throwable $e) {
            $rows = []; $totals = []; $total = 0; $cols = []; $runError = $e->getMessage();
        }
        return view('pages/reports/show', ['title' => $rep['title'], 'rep' => $rep, 'cols' => $cols, 'rows' => $rows,
            'totals' => $totals, 'filters' => $filters, 'filterLabels' => $filterLabels, 'page' => $page, 'per' => $per, 'total' => $total, 'runError' => $runError]);
    }

    public function export(array $p): string
    {
        $this->guard();
        $rep = $this->meta((string)$p['key']);
        [$view, $allCols, $where, $params] = $this->build($rep);
        $cols = array_keys(array_filter($allCols, fn($c) => !in_array($c, ['business_id', 'fiscal_year_id'], true)));
        $rows = Database::all("SELECT * FROM `$view` WHERE " . implode(' AND ', $where), $params);
        $headers = array_map(fn($c) => Schema::label($view, $c), $cols);
        $data = [];
        foreach ($rows as $r) {
            $line = [];
            foreach ($cols as $c) {
                $m = $allCols[$c] ?? ['type' => 'varchar'];
                $line[] = strip_tags(report_cell($m, $r[$c] ?? null));
            }
            $data[] = $line;
        }
        csv_download($rep['title'], $headers, $data);
        return '';
    }

    public function printView(array $p): string
    {
        $this->guard();
        $rep = $this->meta((string)$p['key']);
        [$view, $allCols, $where, $params, $filters, $filterLabels] = $this->build($rep);
        $cols = array_keys(array_filter($allCols, fn($c) => !in_array($c, ['business_id', 'fiscal_year_id'], true)));
        try {
            $rows = Database::all("SELECT * FROM `$view` WHERE " . implode(' AND ', $where) . ' LIMIT 2000', $params);
            $runError = null;
        } catch (Throwable $e) { $rows = []; $runError = $e->getMessage(); }
        $totals = [];
        if ($rows) foreach ($cols as $c) {
            $m = $allCols[$c] ?? ['type' => 'varchar'];
            if (in_array($m['type'], ['decimal', 'double', 'float'], true)) {
                $totals[$c] = (float)Database::val("SELECT IFNULL(SUM(`$c`),0) FROM `$view` WHERE " . implode(' AND ', $where), $params, 0);
            }
        }
        return view('pages/reports/print', ['title' => $rep['title'], 'rep' => $rep, 'cols' => $cols, 'rows' => $rows,
            'totals' => $totals, 'filters' => $filters, 'filterLabels' => $filterLabels,
            'business' => Auth::business() ?: [], 'tpl' => Printing::template('statement'), 'runError' => $runError]);
    }
}
