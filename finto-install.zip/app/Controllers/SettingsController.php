<?php
/** تنظیمات: کسب‌وکار، مالی، حقوق، پیامک، سطح دسترسی و نقش‌ها */
final class SettingsController
{
    public function business(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        if (is_post() && !Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::business();
        $error = null;
        if (is_post()) {
            csrf_verify();
            try {
                $cols = Schema::columns('businesses');
                $data = [];
                foreach ($cols as $c => $m) {
                    if (in_array($c, ['id','slug','created_at','created_by','updated_at','updated_by','deleted_at','row_version','status','logo_attachment_id','timezone'], true)) continue;
                    if (!array_key_exists($c, $_POST)) continue;
                    $data[$c] = $m['enum'] ? $_POST[$c] : Fields::coerce('businesses', $c, $_POST[$c]);
                }
                $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                Database::update('businesses', $data, 'id=:pk', ['pk' => $biz['id']]);
                // لوگوی کسب‌وکار (برای سربرگ همهٔ چاپ‌ها)
                if ((string)($_POST['remove_logo'] ?? '') === '1') Printing::clearLogo((int)$biz['id']);
                $logoUp = Printing::saveLogo('logo', (int)$biz['id'], Auth::id());
                if ($logoUp['error']) throw new RuntimeException((string)$logoUp['error']);
                Audit::log('update', 'businesses', (int)$biz['id'], 'ویرایش اطلاعات کسب‌وکار');
                Flash::push('success', 'اطلاعات کسب‌وکار ذخیره شد.');
                redirect('app/settings/business');
            } catch (Throwable $e) { $error = $e->getMessage(); }
        }
        $groups = Fields::groups('businesses', ['hide' => ['slug','status','timezone','logo_attachment_id']]);
        return view('pages/settings/business', ['title' => 'ویرایش کسب‌وکار', 'biz' => $biz, 'groups' => $groups, 'error' => $error,
            'logoImg' => Printing::logo($biz),
            'provinces' => Database::all('SELECT id, name AS title FROM provinces ORDER BY id LIMIT 40'),
            'cities' => Database::all('SELECT id, name AS title FROM cities ORDER BY id LIMIT 200'),
            'currencies' => Database::all('SELECT id,title,symbol,is_base FROM currencies WHERE is_active=1 ORDER BY is_base DESC LIMIT 12')]);
    }

    /* ───────────── تنظیمات هوش مصنوعی ───────────── */
    public function ai(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        if (is_post() && !Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::businessId();
        $error = null;
        if (is_post()) {
            csrf_verify();
            try {
                Settings::set($biz, 'ai.enabled', (bool)post('enabled'));
                Settings::set($biz, 'ai.thinking', (bool)post('thinking'));
                Settings::set($biz, 'ai.model', (string)(post('model') ?: 'deepseek-v4.1-flash'));
                Settings::set($biz, 'ai.base_url', (string)(post('base_url') ?: 'https://api.avalai.ir/v1'));
                $key = trim((string)post('api_key'));
                if ($key !== '') Settings::set($biz, 'ai.api_key', $key);
                Audit::log('update', 'settings', $biz, 'ویرایش تنظیمات هوش مصنوعی');
                Flash::push('success', 'تنظیمات هوش مصنوعی ذخیره شد.');
                redirect('app/settings/ai');
            } catch (Throwable $e) { $error = $e->getMessage(); }
        }
        $cfg = Ai::config();
        $masked = $cfg['api_key'] !== '' ? (mb_substr($cfg['api_key'], 0, 6) . '••••' . mb_substr($cfg['api_key'], -4)) : '';
        return view('pages/settings/ai', ['title' => 'تنظیمات هوش مصنوعی', 'cfg' => $cfg, 'maskedKey' => $masked,
            'connected' => Ai::enabled(), 'error' => $error]);
    }

    /* ───────────── آزمون اتصال کاوه‌نگار ───────────── */
    public function smsTest(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز آزمون پیامک را ندارید.');
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(Sms::test(), JSON_UNESCAPED_UNICODE);
        return '';
    }

    /** ارسال پیامک آزمایشی به شمارهٔ دلخواه (برای بررسی اتصال پنل کاوه‌نگار) */
    public function smsSendTest(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ارسال پیامک آزمایشی را ندارید.');
        header('Content-Type: application/json; charset=utf-8');
        $m = (string)post('mobile');
        $body = (string)post('message');
        $r = Sms::sendTest($m, $body);
        $r['server_ip'] = Sms::outboundIp();
        echo json_encode($r, JSON_UNESCAPED_UNICODE);
        return '';
    }

    public function financial(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        if (is_post() && !Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) {
                    Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                }
                // نگاشت حساب‌ها (تب نگاشت‌ها)
                foreach ((array)($_POST['mapping'] ?? []) as $mappingId => $accId) {
                    if (!$accId) continue;
                    Database::run('UPDATE account_mappings SET account_id=? WHERE id=? AND business_id=?', [(int)$accId, (int)$mappingId, $biz]);
                }
                $this->syncFinancialSettings($biz);           // ارز پایه + کدینگ پیش‌فرض → اعمال واقعی
                if ((string)post('prune_logs') === '1') {     // سیاست نگهداری: پاک‌سازی رخدادهای قدیمی
                    $years = (int)Settings::get('financial.retention.accounting_years', 10, $biz);
                    $cut = date('Y-m-d H:i:s', strtotime('-' . max(1, $years) . ' years'));
                    $logs = (int)Database::val('SELECT COUNT(*) FROM audit_logs WHERE business_id=? AND created_at < ?', [$biz, $cut], 0);
                    Database::run('DELETE FROM audit_logs WHERE business_id=? AND created_at < ?', [$biz, $cut]);
                    Database::run('DELETE FROM print_logs WHERE business_id=? AND printed_at < ?', [$biz, $cut]);
                    Flash::push('success', 'پاک‌سازی انجام شد؛ ' . num($logs) . ' رخداد قدیمی‌تر از ' . num($years) . ' سال حذف شد.');
                } else {
                    Flash::push('success', 'تنظیمات مالی ذخیره شد.');
                }
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/financial');
        }
        // همگام‌سازی اولیهٔ کدینگ پیش‌فرض از نگاشت‌های موجود
        foreach (['ar' => 'ar_account', 'ap' => 'ap_account', 'sales' => 'sales_account', 'cogs' => 'cogs_account', 'cash' => 'cash_account'] as $mk => $sfx) {
            $code = (string)Database::val('SELECT a.code FROM account_mappings m JOIN chart_of_accounts a ON a.id=m.account_id WHERE m.business_id=? AND m.mapping_key=?', [$biz, $mk], '');
            if ($code !== '' && (string)Settings::get('financial.mapping.' . $sfx, '', $biz) !== $code) Settings::set($biz, 'financial.mapping.' . $sfx, $code);
        }
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category IN ("financial","technical") ORDER BY category, id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        return view('pages/settings/financial', ['title' => 'تنظیمات مالی', 'groups' => $groups,
            'mappings' => Database::all('SELECT m.*, a.code, a.title AS account_title FROM account_mappings m LEFT JOIN chart_of_accounts a ON a.id=m.account_id WHERE m.business_id=? ORDER BY m.id', [$biz]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [$biz]),
            'taxes' => Database::all('SELECT * FROM taxes WHERE business_id=? ORDER BY id', [$biz]),
            'fiscalYears' => Database::all('SELECT * FROM fiscal_years WHERE business_id=? ORDER BY id DESC', [$biz])]);
    }

    public function hr(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('payroll.view') && !Auth::can('settings.view')) abort(403, 'مجوز دسترسی ندارید.');
        if (is_post() && !Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                // قالب‌های متن قرارداد (تب «متن قرارداد»)
                $tplAction = trim((string)post('tpl_action'));
                if ($tplAction !== '' && Auth::can('payroll.edit')) {
                    $tid = (int)post('tpl_id');
                    $payload = ['title' => (string)post('tpl_title'), 'body' => (string)post('tpl_body'), 'note' => (string)post('tpl_note'),
                        'is_default' => $tplAction === 'default' ? 1 : 0];
                    if ($tplAction === 'save') { $tid = Payroll::saveContractTemplate($payload, $tid ?: null); Flash::push('success', 'متن قرارداد ذخیره شد.'); }
                    elseif ($tplAction === 'new') { $tid = Payroll::saveContractTemplate($payload, null); Flash::push('success', 'متن قرارداد جدید ذخیره شد.'); }
                    elseif ($tplAction === 'default') { Payroll::setDefaultContractTemplate($tid); Flash::push('success', 'این متن به‌عنوان پیش‌فرض تعیین شد.'); }
                    elseif ($tplAction === 'delete') { Payroll::deleteContractTemplate($tid); Flash::push('success', 'متن قرارداد حذف شد.'); $tid = 0; }
                    redirect('app/settings/hr?tab=contracts' . ($tid ? '&template=' . $tid : ''));
                }
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                if (post('new_component_title')) {
                    Database::insert('payroll_components', ['business_id' => $biz, 'title' => (string)post('new_component_title'),
                        'component_kind' => (string)post('new_component_kind', 'earning'), 'calc_type' => (string)post('new_component_calc', 'fixed'),
                        'rate_percent' => (float)post('new_component_rate', 0), 'default_amount' => (float)str_replace(',', '', (string)post('new_component_amount', '0')),
                        'account_id' => post('new_component_account') ? (int)post('new_component_account') : null, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
                }
                foreach ((array)($_POST['component'] ?? []) as $id => $vals) {
                    if (!isset($vals['rate_percent']) && !isset($vals['default_amount'])) continue;
                    Database::run('UPDATE payroll_components SET rate_percent=?, default_amount=? WHERE id=? AND business_id=?',
                        [(float)($vals['rate_percent'] ?? 0), (float)str_replace(',', '', (string)($vals['default_amount'] ?? 0)), (int)$id, $biz]);
                }
                Flash::push('success', 'تنظیمات حقوق و دستمزد ذخیره شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/hr');
        }
        // پارامترهای «عیدی» و «حق سنوات» — در همین صفحه قابل ویرایش (یک‌بار ساخته می‌شوند)
        $extras = [
            ['hr.minimum_wage', 0, 'decimal', 'حداقل مزد ماهانه (ریال)', 'عیدی و حق سنوات'],
            ['hr.eidi_base', 'base', 'string', 'مبنای عیدی (base = حقوق پایه، gross = حقوق و مزایا)', 'عیدی و حق سنوات'],
            ['hr.eidi_multiplier', 2, 'decimal', 'ضریب عیدی (برابر حقوق ماهانه)', 'عیدی و حق سنوات'],
            ['hr.eidi_cap_multiplier', 3, 'decimal', 'سقف عیدی (برابر حداقل مزد)', 'عیدی و حق سنوات'],
            ['hr.sanavat_base', 'base', 'string', 'مبنای حق سنوات', 'عیدی و حق سنوات'],
            ['hr.sanavat_days_per_year', 30, 'decimal', 'روز حق سنوات به‌ازای هر سال سابقه', 'عیدی و حق سنوات'],
        ];
        foreach ($extras as [$k, $v, $t, $title, $group]) {
            if (!Database::val('SELECT COUNT(*) FROM settings WHERE business_id=? AND setting_key=?', [$biz, $k])) {
                Database::insert('settings', ['business_id' => $biz, 'category' => 'hr', 'setting_key' => $k,
                    'value_json' => json_encode($v), 'value_type' => $t, 'title_fa' => $title, 'group_fa' => $group, 'created_at' => now()]);
            }
        }
        Settings::flush();
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category="hr" ORDER BY id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        $calcEmp = (int)($_GET['calc_employee'] ?? 0);
        $templates = Payroll::contractTemplates($biz);
        $tplId = (string)($_GET['template'] ?? '');
        $editingTpl = ($tplId === 'new') ? null : Payroll::contractTemplate((int)$tplId ?: (int)($templates[0]['id'] ?? 0));
        if (!$editingTpl && $templates) $editingTpl = $templates[0];
        $previewEmp = (int)($_GET['preview_employee'] ?? 0);
        $preview = null;
        if ($previewEmp) {
            $tmpContracts = null;
            $activeCt = Payroll::activeContract($previewEmp);
            if ($activeCt) $preview = Payroll::renderContract((int)$activeCt['id'], (int)($editingTpl['id'] ?? 0) ?: null);
            else {
                // قراردادی ثبت نشده: پیش‌نمایش با مقادیر پرسنل و عوامل حقوق او
                $ctx = Payroll::contractContext(0);
                $preview = ['template' => $editingTpl, 'body' => 'برای این پرسنل قراردادی ثبت نشده است؛ ابتدا قرارداد او را ثبت کنید.'];
            }
        }
        return view('pages/settings/hr', ['title' => 'تنظیمات حقوق و دستمزد', 'groups' => $groups,
            'contracts' => Payroll::contractStats(), 'recentContracts' => Payroll::contracts([], 8), 'expiring' => Payroll::expiringContracts(60, 8),
            'employees' => Database::all('SELECT id,code,full_name FROM employees WHERE business_id=? AND deleted_at IS NULL ORDER BY full_name', [$biz]),
            'calcEmp' => $calcEmp, 'calc' => $calcEmp ? Payroll::eidiAndSanavat($calcEmp) : [],
            'templates' => $templates, 'editing' => $editingTpl, 'preview' => $preview, 'previewEmp' => $previewEmp,
            'components' => Database::all('SELECT c.*, a.title AS account_title FROM payroll_components c LEFT JOIN chart_of_accounts a ON a.id=c.account_id WHERE c.business_id=? ORDER BY c.id', [$biz]),
            'accounts' => Database::all('SELECT id, code, title FROM chart_of_accounts WHERE business_id=? AND is_postable=1 ORDER BY code', [$biz]),
            'leaveTypes' => Database::all('SELECT * FROM leave_types WHERE business_id=? ORDER BY id', [$biz]),
            'devices' => Database::all('SELECT * FROM attendance_devices WHERE business_id=? ORDER BY id', [$biz])]);
    }

    public function sms(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات پیامک را ندارید.');
        if (is_post() && !Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::businessId();
        if (is_post()) {
            csrf_verify();
            try {
                foreach ((array)($_POST['setting'] ?? []) as $key => $value) Settings::set($biz, (string)$key, $this->castValue($value, (string)($_POST['type'][$key] ?? 'string')));
                Flash::push('success', 'تنظیمات پیامک ذخیره شد.');
            } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
            redirect('app/settings/sms');
        }
        $balance = (float)Database::val('SELECT balance_after FROM message_credits WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz], 0);
        $settings = Database::all('SELECT * FROM settings WHERE business_id=? AND category="sms" ORDER BY id', [$biz]);
        $groups = [];
        foreach ($settings as $s) $groups[$s['group_fa'] ?: 'عمومی'][] = $s;
        return view('pages/settings/sms', ['title' => 'تنظیمات پیامک', 'groups' => $groups, 'balance' => $balance,
            'templates' => Database::all('SELECT * FROM message_templates WHERE business_id=? ORDER BY id', [$biz]),
            'rules' => Database::all('SELECT * FROM notification_rules WHERE business_id=? ORDER BY id', [$biz]),
            'recent' => Database::all('SELECT * FROM messages WHERE business_id=? ORDER BY id DESC LIMIT 20', [$biz])]);
    }

    private function castValue($value, string $type)
    {
        return match ($type) {
            'number' => (float)str_replace(',', '', (string)$value),
            'bool' => (bool)(int)$value,
            'json' => (json_decode((string)$value, true) ?? (string)$value),
            default => (string)$value,
        };
    }

    /* ───────────── درگاه و پرداخت (پورتال مشتری) ───────────── */

    public function payment(array $p): string
    {
        Auth::requireApp();
        if (!Auth::can('settings.view')) abort(403, 'مجوز دسترسی به تنظیمات را ندارید.');
        $biz = Auth::businessId();
        return view('pages/settings/payment', [
            'title' => 'درگاه و پرداخت',
            'accounts' => Database::all('SELECT * FROM payment_accounts WHERE business_id=? ORDER BY sort_order, id', [$biz]),
            'portalUrl' => url('portal'),
        ]);
    }

    public function paymentStore(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        $biz = Auth::businessId();
        try {
            $id = (int)post('id', 0);
            $data = [
                'bank_name' => mb_substr(trim((string)post('bank_name')), 0, 120),
                'account_holder' => mb_substr(trim((string)post('account_holder')), 0, 150),
                'card_no' => trim((string)post('card_no')) !== '' ? mb_substr(trim((string)post('card_no')), 0, 20) : null,
                'iban' => trim((string)post('iban')) !== '' ? mb_substr(trim((string)post('iban')), 0, 26) : null,
                'sort_order' => (int)post('sort_order', 0),
                'is_active' => post('is_active') ? 1 : 0,
            ];
            if ($data['bank_name'] === '' || $data['account_holder'] === '') throw new RuntimeException('نام بانک و نام صاحب حساب الزامی است.');
            if ($id) {
                $data['updated_at'] = now();
                Database::update('payment_accounts', $data, 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
                Flash::push('success', 'حساب پرداخت به‌روزرسانی شد.');
            } else {
                $data['business_id'] = $biz; $data['created_at'] = now(); $data['created_by'] = Auth::id();
                Database::insert('payment_accounts', $data);
                Flash::push('success', 'حساب پرداخت اضافه شد.');
            }
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/settings/payment');
        return '';
    }

    public function paymentDelete(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::can('settings.edit')) abort(403, 'مجوز ویرایش تنظیمات را ندارید.');
        Database::run('DELETE FROM payment_accounts WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        Flash::push('success', 'حساب پرداخت حذف شد.');
        redirect('app/settings/payment');
        return '';
    }

    /**
     * اعمال واقعی تنظیمات مالی:
     *  ۱) «واحد پول پایه» → ستون businesses.base_currency_id (تمام نمایش مبالغ و چاپ‌ها)
     *  ۲) «کدینگ پیش‌فرض حساب‌ها» → جدول account_mappings (سند خودکار)
     */
    private function syncFinancialSettings(int $biz): void
    {
        // ۱) واحد پول پایه
        $cur = strtoupper(trim((string)Settings::get('financial.base_currency', '', $biz)));
        if ($cur !== '') {
            $cid = (int)Database::val('SELECT id FROM currencies WHERE code=? AND is_active=1 LIMIT 1', [$cur], 0);
            if ($cid && $cid !== (int)Database::val('SELECT base_currency_id FROM businesses WHERE id=?', [$biz], 0)) {
                Database::update('businesses', ['base_currency_id' => $cid, 'updated_at' => now(), 'updated_by' => Auth::id()], 'id=:pk', ['pk' => $biz]);
            }
        }
        // ۲) نگاشت حساب‌ها از کدینگ پیش‌فرض
        $map = ['ar_account' => 'ar', 'ap_account' => 'ap', 'sales_account' => 'sales', 'cogs_account' => 'cogs', 'cash_account' => 'cash'];
        foreach ($map as $suffix => $mappingKey) {
            $code = trim((string)Settings::get('financial.mapping.' . $suffix, '', $biz));
            if ($code === '') continue;
            $accId = (int)Database::val('SELECT id FROM chart_of_accounts WHERE business_id=? AND code=? AND deleted_at IS NULL LIMIT 1', [$biz, $code], 0);
            if (!$accId) continue;
            $row = Database::one('SELECT id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$biz, $mappingKey]);
            if ($row) Database::run('UPDATE account_mappings SET account_id=? WHERE id=?', [$accId, (int)$row['id']]);
            else Database::insert('account_mappings', ['business_id' => $biz, 'mapping_key' => $mappingKey,
                'title_fa' => ['ar' => 'حساب‌های دریافتنی تجاری', 'ap' => 'حساب‌های پرداختنی تجاری', 'sales' => 'فروش',
                               'cogs' => 'بهای تمام‌شده کالای فروش‌رفته', 'cash' => 'صندوق'][$mappingKey] ?? $mappingKey,
                'account_id' => $accId, 'created_at' => now(), 'created_by' => Auth::id()]);
        }
    }

    /* ───────────── نقش‌ها و مجوزها ───────────── */
    public function formCreate(array $m, array $p): string
    {
        return view('pages/settings/role_form', ['title' => 'تعریف نقش', 'm' => $m, 'row' => [], 'perms' => $this->permissionsByModule(),
            'selected' => [], 'action' => url('app/roles')]);
    }
    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM roles WHERE id=? AND business_id=?', [(int)$p['id'], Auth::businessId()]);
        if (!$row) abort(404, 'نقش یافت نشد.');
        $sel = array_column(Database::all('SELECT p.slug FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id WHERE rp.role_id=?', [$row['id']]), 'slug');
        return view('pages/settings/role_form', ['title' => 'ویرایش نقش '.$row['name'], 'm' => $m, 'row' => $row,
            'perms' => $this->permissionsByModule(), 'selected' => $sel, 'action' => url('app/roles/'.$row['id'])]);
    }
    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $biz = Auth::businessId();
        try {
            $data = ['business_id' => $biz, 'name' => (string)post('name'), 'slug' => (string)post('slug') ?: ('role-'.random_int(100, 999)),
                'description' => (string)post('description') ?: null, 'is_system' => 0, 'is_active' => 1];
            if ($id) { $data['updated_at'] = now(); $data['updated_by'] = Auth::id(); Database::update('roles', $data, 'id=:pk', ['pk' => $id]); $roleId = (int)$id; }
            else { $data['created_at'] = now(); $data['created_by'] = Auth::id(); $roleId = Database::insert('roles', $data); }
            $this->syncPermissions($roleId, (array)($_POST['perms'] ?? []));
            Flash::push('success', 'نقش و سطح دسترسی ذخیره شد.');
            redirect('app/roles/'.$roleId);
        } catch (Throwable $e) { Flash::push('error', 'خطا: '.$e->getMessage()); redirect($id ? 'app/roles/'.$id.'/edit' : 'app/roles/create'); }
        return '';
    }
    public function savePermissions(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز تغییر سطح دسترسی را ندارید.');
        $this->syncPermissions((int)$p['id'], (array)($_POST['perms'] ?? []));
        Flash::push('success', 'سطح دسترسی نقش به‌روزرسانی شد.');
        redirect('app/roles/'.$p['id']);
        return '';
    }
    private function syncPermissions(int $roleId, array $slugs): void
    {
        $role = Database::one('SELECT * FROM roles WHERE id=? AND business_id=?', [$roleId, Auth::businessId()]);
        if (!$role) throw new RuntimeException('نقش یافت نشد.');
        Database::run('DELETE FROM role_permissions WHERE role_id=?', [$roleId]);
        foreach ($slugs as $slug) {
            $pid = Database::val('SELECT id FROM permissions WHERE slug=?', [$slug]);
            if ($pid) Database::run('INSERT IGNORE INTO role_permissions (role_id, permission_id, scope) VALUES (?,?,"own_business")', [$roleId, $pid]);
        }
        Audit::log('update', 'roles', $roleId, 'به‌روزرسانی سطح دسترسی نقش '.$role['name'], ['count' => count($slugs)]);
    }
    public function permissionsByModule(): array
    {
        $out = [];
        foreach (Database::all('SELECT * FROM permissions WHERE is_active=1 ORDER BY module, action') as $perm) $out[$perm['module']][] = $perm;
        return $out;
    }

    /* ───────────── کاربران: رمز و نقش ───────────── */
    public function resetPassword(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز ندارید.');
        $pw = (string)post('password');
        if (mb_strlen($pw) < 8) { Flash::push('error', 'رمز عبور باید حداقل ۸ کاراکتر باشد.'); redirect('app/users/'.$p['id']); }
        Database::run('UPDATE users SET password_hash=?, password_changed_at=NOW(), failed_attempts=0, locked_until=NULL WHERE id=?',
            [password_hash($pw, PASSWORD_BCRYPT, ['cost' => 10]), (int)$p['id']]);
        Audit::log('reset_password', 'users', (int)$p['id'], 'تغییر رمز کاربر توسط مدیر');
        Flash::push('success', 'رمز عبور کاربر تغییر کرد.');
        redirect('app/users/'.$p['id']);
        return '';
    }
    public function saveUserRole(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        if (!Auth::isAdmin() && !Auth::can('users.edit')) abort(403, 'مجوز ندارید.');
        $biz = Auth::businessId(); $uid = (int)$p['id'];
        try {
            $row = Database::one('SELECT * FROM user_business_roles WHERE user_id=? AND business_id=?', [$uid, $biz]);
            $data = ['role_id' => (int)post('role_id'), 'is_active' => post('is_active') ? 1 : 0,
                'max_discount_percent' => (float)post('max_discount_percent', 0), 'can_see_cost' => post('can_see_cost') ? 1 : 0,
                'default_warehouse_id' => post('default_warehouse_id') ? (int)post('default_warehouse_id') : null,
                'default_cash_account_id' => post('default_cash_account_id') ? (int)post('default_cash_account_id') : null];
            if ($row) Database::update('user_business_roles', $data, 'id=:pk', ['pk' => $row['id']]);
            else { $data['business_id'] = $biz; $data['user_id'] = $uid; $data['created_at'] = now(); $data['created_by'] = Auth::id(); Database::insert('user_business_roles', $data); }
            Flash::push('success', 'نقش کاربر در این کسب‌وکار ذخیره شد.');
        } catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/users/'.$uid);
        return '';
    }
}
