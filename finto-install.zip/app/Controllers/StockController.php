<?php
/** انبار: حواله ورود/خروج، انتقال بین انبارها، ضایعات و انبارگردانی */
final class StockController
{
    public const DOC_TITLES = ['receive' => 'رسید ورود کالا', 'issue' => 'حواله خروج کالا', 'transfer' => 'انتقال بین انبارها',
        'waste' => 'سند ضایعات', 'count_adjust' => 'اصلاح انبارگردانی', 'opening' => 'موجودی افتتاحیه',
        'buy_return' => 'برگشت به تأمین‌کننده', 'sale_return' => 'برگشت از مشتری'];
    private const MANUAL_TYPES = ['receive', 'issue', 'waste', 'opening', 'buy_return', 'sale_return'];

    public function formCreate(array $m, array $p): string { return $this->documentForm([]); }
    public function formEdit(array $m, array $p): string
    {
        $doc = $this->findDoc((int)$p['id']);
        if ($doc['doc_type'] === 'transfer_in' || $doc['doc_type'] === 'transfer_out') redirect('app/stock-transfers');
        return $this->documentForm($doc);
    }
    public function createDocument(array $p): string { return $this->documentForm([]); }

    private function documentForm(array $doc): string
    {
        Auth::requireApp();
        if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت سند انبار را ندارید.');
        $biz = Auth::businessId();
        $type = $doc['doc_type'] ?? (string)($_GET['doc_type'] ?? 'receive');
        if (!in_array($type, self::MANUAL_TYPES, true)) $type = 'receive';
        $lines = [];
        if ($doc) {
            foreach (Database::all('SELECT l.*, p.title AS product_title, p.code AS product_code FROM inventory_document_lines l
                                     JOIN products p ON p.id=l.product_id WHERE l.document_id=? ORDER BY l.row_no', [$doc['id']]) as $l) $lines[] = $l;
        }
        return view('pages/stock/document_form', ['title' => 'ثبت '.self::DOC_TITLES[$type], 'type' => $type, 'doc' => $doc, 'lines' => $lines,
            'docTypes' => self::MANUAL_TYPES, 'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=? AND status="active"', [$biz]),
            'persons' => Database::all('SELECT id, code, first_name, last_name, company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [$biz]),
            'products' => Database::all('SELECT pr.id, pr.code, pr.title, pr.item_type, pr.main_unit_id, IFNULL(sb.qty,0) AS stock_qty FROM products pr
                                          LEFT JOIN (SELECT product_id, SUM(quantity) qty FROM stock_balances WHERE business_id=? GROUP BY product_id) sb ON sb.product_id=pr.id
                                         WHERE pr.business_id=? AND pr.status="active" AND pr.item_type="goods" ORDER BY pr.title LIMIT 500', [$biz, $biz]),
            'wasteReasons' => Database::all('SELECT id,title FROM waste_reasons WHERE business_id=? AND is_active=1', [$biz]),
            'nextNo' => Sequence::peek($biz, Auth::fiscalYearId(), $type === 'waste' ? 'waste' : ($type === 'count_adjust' ? 'count' : 'transfer'))]);
    }

    public function storeDocument(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت سند انبار را ندارید.'); csrf_verify();
        try {
            $biz = Auth::businessId();
            $type = (string)post('doc_type', 'receive');
            $lines = $this->collectLines();
            if (!$lines) throw new RuntimeException('سند انبار باید حداقل یک آرتیکل داشته باشد.');
            $id = Inventory::createDocument([
                'business_id' => $biz, 'doc_type' => $type, 'doc_date' => to_gregorian((string)post('doc_date')) ?: today(),
                'warehouse_id' => (int)post('warehouse_id'), 'person_id' => post('person_id') ? (int)post('person_id') : null,
                'description' => (string)post('description') ?: null, 'source_type' => 'manual',
            ], $lines, true);
            Flash::push('success', 'سند انبار ثبت و موجودی/کاردکس به‌روزرسانی شد.');
            redirect('app/inventory-documents/'.$id);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/inventory-documents/create'); }
        return '';
    }

    public function postDocument(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.edit')) abort(403, 'مجوز قطعی‌سازی سند انبار را ندارید.'); csrf_verify();
        try { Inventory::postDocument((int)$p['id']); Flash::push('success', 'سند انبار قطعی و ثبت شد.'); }
        catch (Throwable $e) { Flash::push('error', $e->getMessage()); }
        redirect('app/inventory-documents/'.$p['id']);
    }

    /* ───────────── انتقال بین انبارها ───────────── */
    public function createTransfer(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت انتقال انبار را ندارید.');
        $biz = Auth::businessId();
        return view('pages/stock/transfer_form', ['title' => 'ثبت انتقال بین انبارها',
            'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=? AND status="active"', [$biz]),
            'products' => Database::all('SELECT pr.id, pr.code, pr.title, pr.main_unit_id, IFNULL(sb.qty,0) AS stock_qty FROM products pr
                                           LEFT JOIN (SELECT product_id, SUM(quantity) qty FROM stock_balances WHERE business_id=? GROUP BY product_id) sb ON sb.product_id=pr.id
                                          WHERE pr.business_id=? AND pr.status="active" AND pr.item_type="goods" ORDER BY pr.title LIMIT 500', [$biz, $biz])]);
    }
    public function storeTransfer(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت انتقال انبار را ندارید.'); csrf_verify();
        $biz = Auth::businessId();
        $from = (int)post('warehouse_id'); $to = (int)post('dest_warehouse_id');
        try {
            if (!$from || !$to || $from === $to) throw new RuntimeException('انبار مبدأ و مقصد را درست انتخاب کنید.');
            $lines = $this->collectLines();
            if (!$lines) throw new RuntimeException('حداقل یک کالا برای انتقال لازم است.');
            $date = to_gregorian((string)post('doc_date')) ?: today();
            $docId = Database::transaction(function () use ($biz, $from, $to, $lines, $date) {
                // سند خروج از مبدأ
                $outId = Inventory::createDocument(['business_id' => $biz, 'doc_type' => 'transfer_out', 'doc_date' => $date,
                    'warehouse_id' => $from, 'dest_warehouse_id' => $to, 'description' => 'انتقال بین انبارها (خروج)', 'source_type' => 'manual'], $lines, true);
                // بهای تمام‌شده هر ردیف از سند خروج → ورود به مقصد با همان بها
                $inLines = [];
                foreach (Database::all('SELECT * FROM inventory_document_lines WHERE document_id=? ORDER BY row_no', [$outId]) as $l) {
                    $inLines[] = ['product_id' => $l['product_id'], 'variant_id' => $l['variant_id'], 'unit_id' => $l['unit_id'],
                        'quantity' => $l['base_quantity'], 'unit_cost' => $l['unit_cost'], 'description' => $l['description']];
                }
                $inId = Inventory::createDocument(['business_id' => $biz, 'doc_type' => 'transfer_in', 'doc_date' => $date,
                    'warehouse_id' => $to, 'dest_warehouse_id' => $from, 'description' => 'انتقال بین انبارها (ورود)', 'source_type' => 'manual'], $inLines, true);
                Database::run('UPDATE inventory_documents SET source_type="transfer", source_id=? WHERE id=?', [$inId, $outId]);
                Database::run('UPDATE inventory_documents SET source_type="transfer", source_id=? WHERE id=?', [$outId, $inId]);
                return $outId;
            });
            Flash::push('success', 'انتقال بین انبارها انجام شد (سند خروج و ورود صادر گردید).');
            redirect('app/inventory-documents/'.$docId);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', $e->getMessage()); redirect('app/stock-transfers/create'); }
        return '';
    }

    /* ───────────── انبارگردانی ───────────── */
    public function createCount(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت انبارگردانی را ندارید.');
        $biz = Auth::businessId();
        $whId = (int)($_GET['warehouse_id'] ?? 0);
        $balances = $whId ? Database::all('SELECT b.*, p.code AS product_code, p.title AS product_title, u.title AS unit_title
                                             FROM stock_balances b JOIN products p ON p.id=b.product_id LEFT JOIN units u ON u.id=p.main_unit_id
                                            WHERE b.business_id=? AND b.warehouse_id=? ORDER BY p.title', [$biz, $whId]) : [];
        return view('pages/stock/count_form', ['title' => 'انبارگردانی', 'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=? AND status="active"', [$biz]),
            'warehouseId' => $whId, 'balances' => $balances]);
    }
    public function storeCount(array $p): string
    {
        Auth::requireApp(); if (!Auth::can('inventory.create')) abort(403, 'مجوز ثبت انبارگردانی را ندارید.'); csrf_verify();
        $biz = Auth::businessId();
        $whId = (int)post('warehouse_id');
        $date = to_gregorian((string)post('count_date')) ?: today();
        try {
            $result = Database::transaction(function () use ($biz, $whId, $date) {
                $items = 0; $diffItems = 0; $diffValue = 0.0; $lines = []; $adjLines = [];
                foreach ((array)($_POST['counted'] ?? []) as $productId => $counted) {
                    if ($counted === '' || $counted === null) continue;
                    $productId = (int)$productId; $counted = (float)str_replace(',', '', (string)$counted);
                    $bal = Database::one('SELECT * FROM stock_balances WHERE business_id=? AND warehouse_id=? AND product_id=?', [$biz, $whId, $productId]);
                    $book = (float)($bal['quantity'] ?? 0);
                    $diff = round($counted - $book, 4);
                    $unitCost = (float)($bal['avg_unit_cost'] ?? 0);
                    $items++;
                    $lines[] = ['product_id' => $productId, 'book_qty' => $book, 'counted_qty' => $counted,
                        'unit_cost' => $unitCost, 'diff_value' => round($diff * $unitCost, 2), 'description' => null]; // diff_qty ستون تولیدشده است
                    if (abs($diff) > 0.0001) { $diffItems++; $diffValue += $diff * $unitCost; }
                    if ($diff > 0) $adjLines[] = ['product_id' => $productId, 'quantity' => $diff, 'unit_cost' => $unitCost, 'description' => 'اضافه‌شدگی انبارگردانی'];
                    elseif ($diff < 0) $adjLines[] = ['product_id' => $productId, 'quantity' => abs($diff), 'unit_cost' => 0, 'description' => 'کسری انبارگردانی'];
                }
                if (!$items) throw new RuntimeException('تعداد شمارش‌شده‌ای وارد نشده است.');
                $docNo = Sequence::next($biz, Auth::fiscalYearId(), 'count');
                $countId = Database::insert('stock_counts', ['business_id' => $biz, 'fiscal_year_id' => Auth::fiscalYearId(), 'doc_no' => $docNo,
                    'count_date' => $date, 'warehouse_id' => $whId, 'period_type' => (string)post('period_type', 'yearly'), 'responsible_user_id' => Auth::id(),
                    'status' => 'done', 'items_count' => $items, 'diff_items_count' => $diffItems, 'diff_value' => round($diffValue, 2),
                    'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
                foreach ($lines as $l) { $l['stock_count_id'] = $countId; unset($l['diff_qty']); Database::insert('stock_count_lines', $l); }
                // اختلاف هر قلم = شمارش‌شده منهای دفتری (ستون diff_qty تولیدشده است و درج نمی‌شود)
                foreach ($lines as $i => $l) $lines[$i]['diff'] = round((float)$l['counted_qty'] - (float)$l['book_qty'], 4);
                // سند اصلاح انبار: کسری (خروج) و اضافه‌شدگی (ورود) در دو سند جدا برای درستی جهت‌ها
                $shortages = array_values(array_filter($lines, fn($l) => $l['diff'] < 0));
                $surpluses = array_values(array_filter($lines, fn($l) => $l['diff'] > 0));
                $jeId = null;
                if ($shortages) {
                    $outLines = array_map(fn($l) => ['product_id' => $l['product_id'], 'quantity' => abs($l['diff']), 'unit_cost' => 0, 'description' => 'کسری انبارگردانی'], $shortages);
                    $docId = Inventory::createDocument(['business_id' => $biz, 'doc_type' => 'count_adjust', 'doc_date' => $date, 'warehouse_id' => $whId,
                        'source_type' => 'stock_count', 'source_id' => $countId, 'doc_no' => $docNo.'-', 'description' => 'کسری انبارگردانی '.$docNo], $outLines, true);
                    $jeId = Database::val('SELECT journal_entry_id FROM inventory_documents WHERE id=?', [$docId]);
                }
                if ($surpluses) {
                    $inLines = array_map(fn($l) => ['product_id' => $l['product_id'], 'quantity' => $l['diff'], 'unit_cost' => $l['unit_cost'], 'description' => 'اضافه‌شدگی انبارگردانی'], $surpluses);
                    $docId2 = Inventory::createDocument(['business_id' => $biz, 'doc_type' => 'count_adjust', 'doc_date' => $date, 'warehouse_id' => $whId,
                        'source_type' => 'stock_count', 'source_id' => $countId, 'doc_no' => $docNo.'+', 'description' => 'اضافه‌شدگی انبارگردانی '.$docNo], $inLines, true);
                    $jeId = $jeId ?: Database::val('SELECT journal_entry_id FROM inventory_documents WHERE id=?', [$docId2]);
                }
                Database::run('UPDATE stock_counts SET journal_entry_id=? WHERE id=?', [$jeId, $countId]);
                // نکته: هیچ redirect/exit ای داخل تراکنش اجرا نمی‌شود (در غیر این صورت commit انجام نمی‌شود)
                return ['id' => $countId, 'items' => $items, 'diff' => $diffItems, 'je' => $jeId];
            });
            Flash::push('success', 'انبارگردانی ثبت شد: '.$result['items'].' قلم شمارش، '.$result['diff'].' قلم اختلاف'
                .($result['je'] ? ' — سند حسابداری اصلاح انبار: #'.$result['je'] : '').'.');
            redirect('app/stock-counts/'.$result['id']);
        } catch (Throwable $e) { Flash::keep($_POST); Flash::push('error', 'خطا در انبارگردانی: '.$e->getMessage()); redirect('app/stock-counts/create?warehouse_id='.$whId); }
        return '';
    }

    /* ───────────── مسیریابی فرم‌های اختصاصی ماژول انبار ───────────── */
    public function customSave(array $m, array $p, ?string $id): string
    {
        if ($m['key'] === 'stock-transfers') return $this->storeTransfer($p);
        return $this->storeDocument($p);
    }

    /* ───────────── کمکی ───────────── */
    private function collectLines(): array
    {
        $lines = [];
        foreach ((array)($_POST['line_product_id'] ?? []) as $i => $pid) {
            if (!$pid) continue;
            $qty = fa_num(($_POST['line_quantity'][$i] ?? 0));
            if ($qty <= 0) continue;
            $lines[] = ['product_id' => (int)$pid, 'variant_id' => 0,
                'unit_id' => !empty($_POST['line_unit_id'][$i]) ? (int)$_POST['line_unit_id'][$i] : null,
                'quantity' => $qty, 'unit_cost' => (float)str_replace(',', '', (string)($_POST['line_unit_cost'][$i] ?? 0)),
                'waste_reason_id' => !empty($_POST['line_waste_reason'][$i]) ? (int)$_POST['line_waste_reason'][$i] : null,
                'description' => $_POST['line_desc'][$i] ?? null];
        }
        return $lines;
    }
    private function findDoc(int $id): array
    {
        $doc = Database::one('SELECT * FROM inventory_documents WHERE id=? AND business_id=?', [$id, Auth::businessId()]);
        if (!$doc) abort(404, 'سند انبار یافت نشد.');
        return $doc;
    }
}
