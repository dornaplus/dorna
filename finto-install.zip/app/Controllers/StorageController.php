<?php
/** فضای ذخیره‌سازی اسناد: نمایش سهمیه و خرید فضای اضافه */
final class StorageController
{
    public function index(array $p): string
    {
        Auth::requireApp();
        $uid = (int)Auth::id();
        $used = StorageQuota::usedBytes($uid);
        $quota = StorageQuota::quotaBytes($uid);
        $pct = $quota > 0 ? min(100, round($used * 100 / $quota, 1)) : 0;
        return view('pages/storage/index', [
            'title' => 'فضای ذخیره‌سازی',
            'used' => $used, 'quota' => $quota, 'remaining' => StorageQuota::remainingBytes($uid), 'pct' => $pct,
            'purchasedGb' => StorageQuota::purchasedGb($uid),
            'pricePerGb' => StorageQuota::PRICE_PER_GB,
            'maxGb' => StorageQuota::MAX_PURCHASE_GB,
            'history' => StorageQuota::history($uid),
            'docCount' => (int)Database::val('SELECT COUNT(*) FROM user_documents WHERE user_id=? AND deleted_at IS NULL', [$uid], 0),
        ]);
    }

    public function purchase(array $p): string
    {
        Auth::requireApp(); csrf_verify();
        $gb = (int)post('gigabytes', 1);
        try {
            if ($gb < 1 || $gb > StorageQuota::MAX_PURCHASE_GB) throw new RuntimeException('مقدار خرید باید بین ۱ تا ' . StorageQuota::MAX_PURCHASE_GB . ' گیگابایت باشد.');
            $id = StorageQuota::purchase($gb);
            Flash::push('success', num($gb) . ' گیگابایت فضای ذخیره‌سازی با موفقیت فعال شد.');
        } catch (Throwable $e) {
            Flash::push('error', $e->getMessage());
        }
        redirect('app/storage');
        return '';
    }
}
