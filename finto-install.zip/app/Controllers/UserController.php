<?php
/** حساب کاربری، سوییچ کسب‌وکار و فرم اختصاصی کاربران */
final class UserController
{
    public function account(array $p): string
    {
        Auth::requireLogin();
        $u = Auth::user();
        $error = null;
        if (is_post()) {
            csrf_verify();
            $first = (string)post('first_name'); $last = (string)post('last_name');
            $email = (string)post('email');
            if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) $error = 'قالب ایمیل صحیح نیست.';
            else {
                Database::run('UPDATE users SET full_name=?, email=?, theme=?, preferred_language=?, updated_at=NOW() WHERE id=?',
                    [trim($first.' '.$last) ?: $u['full_name'], $email ?: null, (string)post('theme', 'light'), (string)post('preferred_language', 'fa'), $u['id']]);
                Database::run('UPDATE users SET password_hash=?, password_changed_at=NOW() WHERE id=?', [$u['password_hash'], $u['id']]);
                [$f1, $l1] = array_pad(explode(' ', (string)$u['full_name'], 2), 2, '');
                Flash::push('success', 'اطلاعات حساب ذخیره شد.');
                redirect('app/my-account');
            }
        }
        [$f, $l] = array_pad(explode(' ', (string)$u['full_name'], 2), 2, '');
        return view('pages/user/account', ['title' => 'حساب کاربری من', 'user' => $u, 'first' => $f, 'last' => $l,
            'businesses' => Auth::businesses(), 'error' => $error]);
    }

    public function switchBusiness(array $p): string
    {
        Auth::requireLogin();
        csrf_verify();
        Auth::switchBusiness((int)$p['id']);
        Flash::push('success', 'کسب‌وکار فعال تغییر کرد.');
        redirect('app');
    }

    /** آپلود یا حذف تصویر پروفایل کاربر جاری */
    public function avatar(array $p): string
    {
        Auth::requireLogin();
        csrf_verify();
        $u = Auth::user();
        if (post('remove') === '1') {
            Avatar::clear((int)$u['id']);
            Flash::push('success', 'تصویر پروفایل حذف شد.');
        } else {
            $up = Avatar::save((int)$u['id'], 'avatar');
            if ($up['error']) Flash::push('error', (string)$up['error']);
            elseif (!$up['empty']) Flash::push('success', 'تصویر پروفایل به‌روزرسانی شد.');
        }
        redirect('app/my-account');
        return '';
    }

    public function formCreate(array $m, array $p): string
    {
        $groups = Fields::groups('users', ['only' => ['full_name','mobile','email','preferred_language','theme','status','is_active','two_factor_enabled']]);
        return view('pages/user/form', ['m' => $m, 'groups' => $groups, 'row' => [], 'title' => 'تعریف کاربر',
            'roles' => Database::all('SELECT * FROM roles WHERE business_id=? AND is_active=1', [Auth::businessId()]),
            'action' => url('app/users'), 'isNew' => true, 'roleId' => null, 'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=?', [Auth::businessId()]),
            'cashAccounts' => Database::all('SELECT id,title FROM cash_accounts WHERE business_id=?', [Auth::businessId()])]);
    }
    public function formEdit(array $m, array $p): string
    {
        $row = Database::one('SELECT * FROM users WHERE id=?', [(int)$p['id']]);
        if (!$row) abort(404, 'کاربر یافت نشد.');
        $groups = Fields::groups('users', ['only' => ['full_name','mobile','email','preferred_language','theme','status','is_active','two_factor_enabled']]);
        $ubr = Database::one('SELECT * FROM user_business_roles WHERE user_id=? AND business_id=?', [$row['id'], Auth::businessId()]);
        return view('pages/user/form', ['m' => $m, 'groups' => $groups, 'row' => $row, 'title' => 'ویرایش کاربر',
            'roles' => Database::all('SELECT * FROM roles WHERE business_id=? AND is_active=1', [Auth::businessId()]),
            'action' => url('app/users/'.$row['id']), 'isNew' => false, 'ubr' => $ubr ?: [],
            'roleId' => $ubr['role_id'] ?? null, 'warehouses' => Database::all('SELECT id,title FROM warehouses WHERE business_id=?', [Auth::businessId()]),
            'cashAccounts' => Database::all('SELECT id,title FROM cash_accounts WHERE business_id=?', [Auth::businessId()])]);
    }

    public function customSave(array $m, array $p, ?string $id): string
    {
        csrf_verify();
        $biz = Auth::businessId();
        $mobile = AuthController::normalizeMobile((string)post('mobile'));
        $password = (string)($_POST['password_hash'] ?? '');
        $errors = [];
        if (!$mobile) $errors[] = 'شماره موبایل معتبر الزامی است.';
        if (!$id && mb_strlen($password) < 8) $errors[] = 'رمز عبور اولیه باید حداقل ۸ کاراکتر باشد.';
        $dup = Database::val('SELECT id FROM users WHERE mobile=? AND id<>?', [$mobile, $id ?: 0]);
        if ($dup) $errors[] = 'کاربر دیگری با این شماره موبایل ثبت شده است.';
        if ($errors) { Flash::keep($_POST); Flash::push('error', implode(' ', $errors)); redirect($id ? 'app/users/'.$id.'/edit' : 'app/users/create'); }
        try {
            $savedId = null;
            Database::transaction(function () use ($id, $mobile, $password, $biz, &$savedId) {
                $data = ['full_name' => (string)post('full_name'), 'mobile' => $mobile, 'email' => (string)post('email') ?: null,
                    'preferred_language' => (string)post('preferred_language', 'fa'), 'theme' => (string)post('theme', 'light'),
                    'status' => (string)post('status', 'active'), 'is_active' => post('is_active') ? 1 : 0,
                    'two_factor_enabled' => post('two_factor_enabled') ? 1 : 0];
                if ($id) {
                    $data['updated_at'] = now(); $data['updated_by'] = Auth::id();
                    if ($password !== '') $data['password_hash'] = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
                    Database::update('users', $data, 'id=:pk', ['pk' => $id]);
                    $uid = (int)$id;
                } else {
                    $data['password_hash'] = password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]);
                    $data['created_at'] = now(); $data['created_by'] = Auth::id();
                    $uid = Database::insert('users', $data);
                }
                $savedId = $uid;
                $roleId = (int)post('role_id');
                if ($roleId) {
                    $exists = Database::one('SELECT id FROM user_business_roles WHERE user_id=? AND business_id=?', [$uid, $biz]);
                    $ubr = ['role_id' => $roleId, 'max_discount_percent' => (float)post('max_discount_percent', 0),
                        'can_see_cost' => post('can_see_cost') ? 1 : 0,
                        'default_warehouse_id' => post('default_warehouse_id') ? (int)post('default_warehouse_id') : null,
                        'default_cash_account_id' => post('default_cash_account_id') ? (int)post('default_cash_account_id') : null, 'is_active' => 1];
                    if ($exists) Database::update('user_business_roles', $ubr, 'id=:pk', ['pk' => $exists['id']]);
                    else { $ubr['business_id'] = $biz; $ubr['user_id'] = $uid; $ubr['created_at'] = now(); $ubr['created_by'] = Auth::id(); Database::insert('user_business_roles', $ubr); }
                    if (!$id) { /* نقش پیش‌فرض تعیین شد */ }
                    $_SESSION['business_id'] = $biz;
                }
                Audit::log($id ? 'update' : 'create', 'users', $uid, ($id ? 'ویرایش' : 'ایجاد').' کاربر '.$mobile);
            });
            // آواتار (پس از ذخیرهٔ کاربر؛ در صورت آپلود یا درخواست حذف)
            if ($savedId) {
                if (post('remove_avatar') === '1') Avatar::clear((int)$savedId);
                else {
                    $up = Avatar::save((int)$savedId, 'avatar');
                    if ($up['error']) { Flash::push('error', (string)$up['error']); redirect($id ? 'app/users/'.$id.'/edit' : 'app/users/create'); }
                }
            }
            Flash::push('success', 'کاربر ذخیره شد.');
            Flash::clearOld();
            redirect('app/users');
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', 'خطا در ذخیره کاربر: '.$e->getMessage());
            redirect($id ? 'app/users/'.$id.'/edit' : 'app/users/create');
        }
        return '';
    }
}
