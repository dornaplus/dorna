<?php
/** مدیریت اسناد شخصی کاربران — فهرست، آپلود، دانلود (با رمز)، حذف */
final class UserDocumentController
{
    private function guard(): void { Auth::requireApp(); }

    private function filters(): array
    {
        return [
            'q'      => (string)($_GET['q'] ?? ''),
            'ext'    => (string)($_GET['ext'] ?? ''),
            'size'   => (string)($_GET['size'] ?? ''),
            'locked' => (string)($_GET['locked'] ?? ''),
            'sort'   => (string)($_GET['sort'] ?? 'created_desc'),
            'from'   => (string)($_GET['from'] ?? ''),
            'to'     => (string)($_GET['to'] ?? ''),
            'user_id' => (int)($_GET['user_id'] ?? 0),
        ];
    }

    public function index(array $p): string
    {
        $this->guard();
        $f = $this->filters();
        $rows = UserDocument::list($f);
        $uid = (int)Auth::id();
        return view('pages/documents/index', [
            'title' => 'اسناد من', 'rows' => $rows, 'f' => $f,
            'stats' => UserDocument::stats(),
            'exts' => UserDocument::distinctExts(),
            'users' => Auth::isAdmin() ? UserDocument::usersWithDocs() : [],
            'isAdmin' => Auth::isAdmin(),
            'maxSize' => UserDocument::MAX_SIZE,
            'storageUsed' => StorageQuota::usedBytes($uid),
            'storageQuota' => StorageQuota::quotaBytes($uid),
            'storagePct' => StorageQuota::quotaBytes($uid) > 0 ? min(100, round(StorageQuota::usedBytes($uid) * 100 / StorageQuota::quotaBytes($uid), 1)) : 0,
        ]);
    }

    public function store(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            $id = UserDocument::store(
                (string)post('title'),
                (string)post('description'),
                $_FILES['file'] ?? [],
                (string)post('password') !== '' ? (string)post('password') : null
            );
            Flash::push('success', 'سند با موفقیت ذخیره شد.');
        } catch (Throwable $e) {
            Flash::keep($_POST); Flash::push('error', $e->getMessage());
        }
        redirect('app/documents');
        return '';
    }

    public function download(array $p): string
    {
        $this->guard();
        $d = UserDocument::one((int)$p['id']);
        if (!$d) { http_response_code(404); exit('سند یافت نشد.'); }

        // درخواست بازگشایی با رمز (POST)
        if (is_post()) {
            csrf_verify();
            if (!UserDocument::verifyPassword($d, (string)post('password'))) {
                return view('pages/documents/unlock', ['title' => 'بازگشایی سند', 'doc' => $d, 'error' => 'رمز واردشده صحیح نیست.']);
            }
            UserDocument::stream($d);
            return '';
        }

        // سند قفل‌شده و کاربر غیرمدیر → فرم رمز
        if (UserDocument::locked($d) && !Auth::isAdmin()) {
            return view('pages/documents/unlock', ['title' => 'بازگشایی سند', 'doc' => $d, 'error' => null]);
        }

        UserDocument::stream($d);
        return '';
    }

    public function delete(array $p): string
    {
        $this->guard(); csrf_verify();
        try {
            UserDocument::delete((int)$p['id']);
            Flash::push('success', 'سند حذف شد.');
        } catch (Throwable $e) {
            Flash::push('error', $e->getMessage());
        }
        redirect('app/documents');
        return '';
    }
}
