<?php
/** قالب پیش‌فرض کسب‌وکار — تولیدشده در 2026-09-30 22:57 از کسب‌وکار #1
 *  در راه‌اندازی کسب‌وکار جدید، این ساختار کپی می‌شود (کدینگ، نگاشت‌ها، قواعد سند، مالیات‌ها، تنظیمات، شماره‌گذاری، نقش‌ها).
 */
return array (
  'chart_of_accounts' => 
  array (
    0 => 
    array (
      'code' => '1',
      'parent_code' => NULL,
      'title' => 'دارایی‌ها',
      'level_no' => 1,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'دارایی‌ها',
    ),
    1 => 
    array (
      'code' => '11',
      'parent_code' => '1',
      'title' => 'دارایی جاری',
      'level_no' => 2,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'دارایی‌ها / دارایی جاری',
    ),
    2 => 
    array (
      'code' => '1101',
      'parent_code' => '11',
      'title' => 'صندوق',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'cash',
      'full_path' => 'دارایی‌ها / دارایی جاری / صندوق',
    ),
    3 => 
    array (
      'code' => '1102',
      'parent_code' => '11',
      'title' => 'بانک ملت',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'bank',
      'full_path' => 'دارایی‌ها / دارایی جاری / بانک ملت',
    ),
    4 => 
    array (
      'code' => '1103',
      'parent_code' => '11',
      'title' => 'بانک صادرات',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'bank',
      'full_path' => 'دارایی‌ها / دارایی جاری / بانک صادرات',
    ),
    5 => 
    array (
      'code' => '1104',
      'parent_code' => '11',
      'title' => 'کارتخوان فروشگاهی',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'pos',
      'full_path' => 'دارایی‌ها / دارایی جاری / کارتخوان فروشگاهی',
    ),
    6 => 
    array (
      'code' => '1105',
      'parent_code' => '11',
      'title' => 'تنخواه گردان',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'petty_cash',
      'full_path' => 'دارایی‌ها / دارایی جاری / تنخواه گردان',
    ),
    7 => 
    array (
      'code' => '1106',
      'parent_code' => '11',
      'title' => 'حساب‌های دریافتنی تجاری',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 1,
      'system_role' => 'ar',
      'full_path' => 'دارایی‌ها / دارایی جاری / حساب‌های دریافتنی تجاری',
    ),
    8 => 
    array (
      'code' => '1107',
      'parent_code' => '11',
      'title' => 'اسناد دریافتنی (چک)',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'cheque_receivable',
      'full_path' => 'دارایی‌ها / دارایی جاری / اسناد دریافتنی (چک)',
    ),
    9 => 
    array (
      'code' => '1108',
      'parent_code' => '11',
      'title' => 'پیش‌پرداخت به تأمین‌کنندگان',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'prepaid',
      'full_path' => 'دارایی‌ها / دارایی جاری / پیش‌پرداخت به تأمین‌کنندگان',
    ),
    10 => 
    array (
      'code' => '1109',
      'parent_code' => '11',
      'title' => 'مالیات بر ارزش افزوده دریافتنی',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'vat_receivable',
      'full_path' => 'دارایی‌ها / دارایی جاری / مالیات بر ارزش افزوده دریافتنی',
    ),
    11 => 
    array (
      'code' => '1110',
      'parent_code' => '11',
      'title' => 'موجودی کالا',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'inventory',
      'full_path' => 'دارایی‌ها / دارایی جاری / موجودی کالا',
    ),
    12 => 
    array (
      'code' => '12',
      'parent_code' => '1',
      'title' => 'دارایی‌های غیرجاری',
      'level_no' => 2,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'دارایی‌ها / دارایی‌های غیرجاری',
    ),
    13 => 
    array (
      'code' => '1201',
      'parent_code' => '12',
      'title' => 'اموال، ماشین‌آلات و تجهیزات',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'fixed_assets',
      'full_path' => 'دارایی‌ها / دارایی‌های غیرجاری / اموال، ماشین‌آلات و تجهیزات',
    ),
    14 => 
    array (
      'code' => '1202',
      'parent_code' => '12',
      'title' => 'استهلاک انباشته',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'accumulated_depreciation',
      'full_path' => 'دارایی‌ها / دارایی‌های غیرجاری / استهلاک انباشته',
    ),
    15 => 
    array (
      'code' => '2',
      'parent_code' => NULL,
      'title' => 'بدهی‌ها',
      'level_no' => 1,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'بدهی‌ها',
    ),
    16 => 
    array (
      'code' => '21',
      'parent_code' => '2',
      'title' => 'بدهی جاری',
      'level_no' => 2,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'بدهی‌ها / بدهی جاری',
    ),
    17 => 
    array (
      'code' => '2101',
      'parent_code' => '21',
      'title' => 'حساب‌های پرداختنی تجاری',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 1,
      'system_role' => 'ap',
      'full_path' => 'بدهی‌ها / بدهی جاری / حساب‌های پرداختنی تجاری',
    ),
    18 => 
    array (
      'code' => '2102',
      'parent_code' => '21',
      'title' => 'اسناد پرداختنی (چک)',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'cheque_payable',
      'full_path' => 'بدهی‌ها / بدهی جاری / اسناد پرداختنی (چک)',
    ),
    19 => 
    array (
      'code' => '2103',
      'parent_code' => '21',
      'title' => 'مالیات بر ارزش افزوده پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'vat_payable',
      'full_path' => 'بدهی‌ها / بدهی جاری / مالیات بر ارزش افزوده پرداختنی',
    ),
    20 => 
    array (
      'code' => '2104',
      'parent_code' => '21',
      'title' => 'مالیات بر حقوق پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'payroll_tax',
      'full_path' => 'بدهی‌ها / بدهی جاری / مالیات بر حقوق پرداختنی',
    ),
    21 => 
    array (
      'code' => '2105',
      'parent_code' => '21',
      'title' => 'بیمه پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'insurance_payable',
      'full_path' => 'بدهی‌ها / بدهی جاری / بیمه پرداختنی',
    ),
    22 => 
    array (
      'code' => '2106',
      'parent_code' => '21',
      'title' => 'حقوق و دستمزد پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'payroll_payable',
      'full_path' => 'بدهی‌ها / بدهی جاری / حقوق و دستمزد پرداختنی',
    ),
    23 => 
    array (
      'code' => '2107',
      'parent_code' => '21',
      'title' => 'پیش‌دریافت از مشتریان',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'customer_advance',
      'full_path' => 'بدهی‌ها / بدهی جاری / پیش‌دریافت از مشتریان',
    ),
    24 => 
    array (
      'code' => '2108',
      'parent_code' => '21',
      'title' => 'عیدی و سنوات پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'bonus_payable',
      'full_path' => 'بدهی‌ها / بدهی جاری / عیدی و سنوات پرداختنی',
    ),
    25 => 
    array (
      'code' => '3',
      'parent_code' => NULL,
      'title' => 'سرمایه',
      'level_no' => 1,
      'account_type' => 'equity',
      'nature' => 'credit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'سرمایه',
    ),
    26 => 
    array (
      'code' => '3101',
      'parent_code' => '3',
      'title' => 'سرمایه',
      'level_no' => 2,
      'account_type' => 'equity',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'capital',
      'full_path' => 'سرمایه / سرمایه',
    ),
    27 => 
    array (
      'code' => '3102',
      'parent_code' => '3',
      'title' => 'برداشت مالک',
      'level_no' => 2,
      'account_type' => 'equity',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'drawings',
      'full_path' => 'سرمایه / برداشت مالک',
    ),
    28 => 
    array (
      'code' => '3103',
      'parent_code' => '3',
      'title' => 'سود و زیان انباشته',
      'level_no' => 2,
      'account_type' => 'equity',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'retained_earnings',
      'full_path' => 'سرمایه / سود و زیان انباشته',
    ),
    29 => 
    array (
      'code' => '3104',
      'parent_code' => '3',
      'title' => 'سود و زیان دوره جاری',
      'level_no' => 2,
      'account_type' => 'equity',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'current_profit',
      'full_path' => 'سرمایه / سود و زیان دوره جاری',
    ),
    30 => 
    array (
      'code' => '4',
      'parent_code' => NULL,
      'title' => 'درآمدها',
      'level_no' => 1,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'درآمدها',
    ),
    31 => 
    array (
      'code' => '4101',
      'parent_code' => '4',
      'title' => 'فروش کالا',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'sales',
      'full_path' => 'درآمدها / فروش کالا',
    ),
    32 => 
    array (
      'code' => '4102',
      'parent_code' => '4',
      'title' => 'درآمد خدمات',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'service_revenue',
      'full_path' => 'درآمدها / درآمد خدمات',
    ),
    33 => 
    array (
      'code' => '4103',
      'parent_code' => '4',
      'title' => 'برگشت از فروش و تخفیفات',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'sales_return',
      'full_path' => 'درآمدها / برگشت از فروش و تخفیفات',
    ),
    34 => 
    array (
      'code' => '4104',
      'parent_code' => '4',
      'title' => 'درآمد حمل و ارسال',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'shipping_revenue',
      'full_path' => 'درآمدها / درآمد حمل و ارسال',
    ),
    35 => 
    array (
      'code' => '4105',
      'parent_code' => '4',
      'title' => 'درآمد مازاد انبارگردانی',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'inventory_gain',
      'full_path' => 'درآمدها / درآمد مازاد انبارگردانی',
    ),
    36 => 
    array (
      'code' => '4106',
      'parent_code' => '4',
      'title' => 'درآمد متفرقه',
      'level_no' => 2,
      'account_type' => 'revenue',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'other_income',
      'full_path' => 'درآمدها / درآمد متفرقه',
    ),
    37 => 
    array (
      'code' => '5',
      'parent_code' => NULL,
      'title' => 'بهای تمام‌شده',
      'level_no' => 1,
      'account_type' => 'cogs',
      'nature' => 'debit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'بهای تمام‌شده',
    ),
    38 => 
    array (
      'code' => '5101',
      'parent_code' => '5',
      'title' => 'بهای تمام‌شده کالای فروش‌رفته',
      'level_no' => 2,
      'account_type' => 'cogs',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'cogs',
      'full_path' => 'بهای تمام‌شده / بهای تمام‌شده کالای فروش‌رفته',
    ),
    39 => 
    array (
      'code' => '5102',
      'parent_code' => '11',
      'title' => 'حساب واسط خرید',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'both',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'purchase_interim',
      'full_path' => 'دارایی‌ها / دارایی جاری / حساب واسط خرید',
    ),
    40 => 
    array (
      'code' => '6',
      'parent_code' => NULL,
      'title' => 'هزینه‌ها',
      'level_no' => 1,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 1,
      'is_postable' => 0,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها',
    ),
    41 => 
    array (
      'code' => '6101',
      'parent_code' => '6',
      'title' => 'حقوق و دستمزد',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'payroll_expense',
      'full_path' => 'هزینه‌ها / حقوق و دستمزد',
    ),
    42 => 
    array (
      'code' => '6102',
      'parent_code' => '6',
      'title' => 'اجاره',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'rent_expense',
      'full_path' => 'هزینه‌ها / اجاره',
    ),
    43 => 
    array (
      'code' => '6103',
      'parent_code' => '6',
      'title' => 'آب، برق و گاز',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / آب، برق و گاز',
    ),
    44 => 
    array (
      'code' => '6104',
      'parent_code' => '6',
      'title' => 'مخابرات و اینترنت',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / مخابرات و اینترنت',
    ),
    45 => 
    array (
      'code' => '6105',
      'parent_code' => '6',
      'title' => 'ملزومات مصرفی',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / ملزومات مصرفی',
    ),
    46 => 
    array (
      'code' => '6106',
      'parent_code' => '6',
      'title' => 'حمل و نقل',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / حمل و نقل',
    ),
    47 => 
    array (
      'code' => '6107',
      'parent_code' => '6',
      'title' => 'تبلیغات و بازاریابی',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / تبلیغات و بازاریابی',
    ),
    48 => 
    array (
      'code' => '6108',
      'parent_code' => '6',
      'title' => 'تعمیر و نگهداری',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / تعمیر و نگهداری',
    ),
    49 => 
    array (
      'code' => '6109',
      'parent_code' => '6',
      'title' => 'سوخت و خودرو',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / سوخت و خودرو',
    ),
    50 => 
    array (
      'code' => '6110',
      'parent_code' => '6',
      'title' => 'ضایعات انبار',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'waste_expense',
      'full_path' => 'هزینه‌ها / ضایعات انبار',
    ),
    51 => 
    array (
      'code' => '6111',
      'parent_code' => '6',
      'title' => 'کارمزد و هزینه‌های بانکی',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'bank_fee',
      'full_path' => 'هزینه‌ها / کارمزد و هزینه‌های بانکی',
    ),
    52 => 
    array (
      'code' => '6112',
      'parent_code' => '6',
      'title' => 'استهلاک',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / استهلاک',
    ),
    53 => 
    array (
      'code' => '6113',
      'parent_code' => '6',
      'title' => 'بیمه',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / بیمه',
    ),
    54 => 
    array (
      'code' => '6114',
      'parent_code' => '6',
      'title' => 'مالیات و عوارض',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / مالیات و عوارض',
    ),
    55 => 
    array (
      'code' => '6115',
      'parent_code' => '6',
      'title' => 'پورسانت فروش',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'commission_expense',
      'full_path' => 'هزینه‌ها / پورسانت فروش',
    ),
    56 => 
    array (
      'code' => '6116',
      'parent_code' => '6',
      'title' => 'پذیرایی و تنخواه',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'هزینه‌ها / پذیرایی و تنخواه',
    ),
    57 => 
    array (
      'code' => '6117',
      'parent_code' => '6',
      'title' => 'هزینه‌های اداری و متفرقه',
      'level_no' => 2,
      'account_type' => 'expense',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => 'expense_default',
      'full_path' => 'هزینه‌ها / هزینه‌های اداری و متفرقه',
    ),
    58 => 
    array (
      'code' => '1111',
      'parent_code' => '11',
      'title' => 'مساعدهٔ کارکنان',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'دارایی‌ها / دارایی جاری / مساعدهٔ کارکنان',
    ),
    59 => 
    array (
      'code' => '1112',
      'parent_code' => '11',
      'title' => 'وام کارکنان',
      'level_no' => 3,
      'account_type' => 'asset',
      'nature' => 'debit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'دارایی‌ها / دارایی جاری / وام کارکنان',
    ),
    60 => 
    array (
      'code' => '2109',
      'parent_code' => '21',
      'title' => 'سایر کسورات حقوق پرداختنی',
      'level_no' => 3,
      'account_type' => 'liability',
      'nature' => 'credit',
      'is_group' => 0,
      'is_postable' => 1,
      'person_required' => 0,
      'system_role' => NULL,
      'full_path' => 'بدهی‌ها / بدهی جاری / سایر کسورات حقوق پرداختنی',
    ),
  ),
  'account_mappings' => 
  array (
    0 => 
    array (
      'mapping_key' => 'cash',
      'title_fa' => 'صندوق',
      'account_code' => '1101',
    ),
    1 => 
    array (
      'mapping_key' => 'bank',
      'title_fa' => 'بانک ملت',
      'account_code' => '1102',
    ),
    2 => 
    array (
      'mapping_key' => 'bank2',
      'title_fa' => 'بانک صادرات',
      'account_code' => '1103',
    ),
    3 => 
    array (
      'mapping_key' => 'pos',
      'title_fa' => 'کارتخوان فروشگاهی',
      'account_code' => '1104',
    ),
    4 => 
    array (
      'mapping_key' => 'petty_cash',
      'title_fa' => 'تنخواه گردان',
      'account_code' => '1105',
    ),
    5 => 
    array (
      'mapping_key' => 'ar',
      'title_fa' => 'حساب‌های دریافتنی تجاری',
      'account_code' => '1106',
    ),
    6 => 
    array (
      'mapping_key' => 'cheque_receivable',
      'title_fa' => 'اسناد دریافتنی (چک)',
      'account_code' => '1107',
    ),
    7 => 
    array (
      'mapping_key' => 'prepaid',
      'title_fa' => 'پیش‌پرداخت به تأمین‌کنندگان',
      'account_code' => '1108',
    ),
    8 => 
    array (
      'mapping_key' => 'vat_receivable',
      'title_fa' => 'مالیات بر ارزش افزوده دریافتنی',
      'account_code' => '1109',
    ),
    9 => 
    array (
      'mapping_key' => 'inventory',
      'title_fa' => 'موجودی کالا',
      'account_code' => '1110',
    ),
    10 => 
    array (
      'mapping_key' => 'fixed_assets',
      'title_fa' => 'اموال، ماشین‌آلات و تجهیزات',
      'account_code' => '1201',
    ),
    11 => 
    array (
      'mapping_key' => 'accumulated_depreciation',
      'title_fa' => 'استهلاک انباشته',
      'account_code' => '1202',
    ),
    12 => 
    array (
      'mapping_key' => 'ap',
      'title_fa' => 'حساب‌های پرداختنی تجاری',
      'account_code' => '2101',
    ),
    13 => 
    array (
      'mapping_key' => 'cheque_payable',
      'title_fa' => 'اسناد پرداختنی (چک)',
      'account_code' => '2102',
    ),
    14 => 
    array (
      'mapping_key' => 'vat_payable',
      'title_fa' => 'مالیات بر ارزش افزوده پرداختنی',
      'account_code' => '2103',
    ),
    15 => 
    array (
      'mapping_key' => 'payroll_tax',
      'title_fa' => 'مالیات بر حقوق پرداختنی',
      'account_code' => '2104',
    ),
    16 => 
    array (
      'mapping_key' => 'insurance_payable',
      'title_fa' => 'بیمه پرداختنی',
      'account_code' => '2105',
    ),
    17 => 
    array (
      'mapping_key' => 'payroll_payable',
      'title_fa' => 'حقوق و دستمزد پرداختنی',
      'account_code' => '2106',
    ),
    18 => 
    array (
      'mapping_key' => 'customer_advance',
      'title_fa' => 'پیش‌دریافت از مشتریان',
      'account_code' => '2107',
    ),
    19 => 
    array (
      'mapping_key' => 'bonus_payable',
      'title_fa' => 'عیدی و سنوات پرداختنی',
      'account_code' => '2108',
    ),
    20 => 
    array (
      'mapping_key' => 'capital',
      'title_fa' => 'سرمایه',
      'account_code' => '3101',
    ),
    21 => 
    array (
      'mapping_key' => 'drawings',
      'title_fa' => 'برداشت مالک',
      'account_code' => '3102',
    ),
    22 => 
    array (
      'mapping_key' => 'retained_earnings',
      'title_fa' => 'سود و زیان انباشته',
      'account_code' => '3103',
    ),
    23 => 
    array (
      'mapping_key' => 'current_profit',
      'title_fa' => 'سود و زیان دوره جاری',
      'account_code' => '3104',
    ),
    24 => 
    array (
      'mapping_key' => 'sales',
      'title_fa' => 'فروش کالا',
      'account_code' => '4101',
    ),
    25 => 
    array (
      'mapping_key' => 'service_revenue',
      'title_fa' => 'درآمد خدمات',
      'account_code' => '4102',
    ),
    26 => 
    array (
      'mapping_key' => 'sales_return',
      'title_fa' => 'برگشت از فروش و تخفیفات',
      'account_code' => '4103',
    ),
    27 => 
    array (
      'mapping_key' => 'shipping_revenue',
      'title_fa' => 'درآمد حمل و ارسال',
      'account_code' => '4104',
    ),
    28 => 
    array (
      'mapping_key' => 'inventory_gain',
      'title_fa' => 'درآمد مازاد انبارگردانی',
      'account_code' => '4105',
    ),
    29 => 
    array (
      'mapping_key' => 'other_income',
      'title_fa' => 'درآمد متفرقه',
      'account_code' => '4106',
    ),
    30 => 
    array (
      'mapping_key' => 'cogs',
      'title_fa' => 'بهای تمام‌شده کالای فروش‌رفته',
      'account_code' => '5101',
    ),
    31 => 
    array (
      'mapping_key' => 'purchase_interim',
      'title_fa' => 'حساب واسط خرید',
      'account_code' => '5102',
    ),
    32 => 
    array (
      'mapping_key' => 'payroll_expense',
      'title_fa' => 'حقوق و دستمزد',
      'account_code' => '6101',
    ),
    33 => 
    array (
      'mapping_key' => 'rent_expense',
      'title_fa' => 'اجاره',
      'account_code' => '6102',
    ),
    34 => 
    array (
      'mapping_key' => 'waste_expense',
      'title_fa' => 'ضایعات انبار',
      'account_code' => '6110',
    ),
    35 => 
    array (
      'mapping_key' => 'bank_fee',
      'title_fa' => 'کارمزد و هزینه‌های بانکی',
      'account_code' => '6111',
    ),
    36 => 
    array (
      'mapping_key' => 'commission_expense',
      'title_fa' => 'پورسانت فروش',
      'account_code' => '6115',
    ),
    37 => 
    array (
      'mapping_key' => 'expense_default',
      'title_fa' => 'هزینه‌های اداری و متفرقه',
      'account_code' => '6117',
    ),
    38 => 
    array (
      'mapping_key' => 'staff_advances',
      'title_fa' => 'مساعدهٔ کارکنان',
      'account_code' => '1111',
    ),
    39 => 
    array (
      'mapping_key' => 'staff_loans',
      'title_fa' => 'وام کارکنان',
      'account_code' => '1112',
    ),
    40 => 
    array (
      'mapping_key' => 'payroll_deductions',
      'title_fa' => 'سایر کسورات حقوق پرداختنی',
      'account_code' => '2109',
    ),
  ),
  'taxes' => 
  array (
    0 => 
    array (
      'title' => 'مالیات بر ارزش افزوده ۱۰٪',
      'tax_kind' => 'vat',
      'rate_percent' => 10.0,
      'is_inclusive' => 0,
      'account_code' => '2103',
      'moadian_tax_code' => 'VAT10',
    ),
    1 => 
    array (
      'title' => 'مالیات بر ارزش افزوده ۹٪',
      'tax_kind' => 'vat',
      'rate_percent' => 9.0,
      'is_inclusive' => 0,
      'account_code' => '2103',
      'moadian_tax_code' => 'VAT09',
    ),
    2 => 
    array (
      'title' => 'معاف از مالیات',
      'tax_kind' => 'vat',
      'rate_percent' => 0.0,
      'is_inclusive' => 0,
      'account_code' => NULL,
      'moadian_tax_code' => 'EXEMPT',
    ),
  ),
  'units' => 
  array (
    0 => 
    array (
      'title' => 'عدد',
      'symbol' => 'pcs',
    ),
    1 => 
    array (
      'title' => 'کیلوگرم',
      'symbol' => 'kg',
    ),
    2 => 
    array (
      'title' => 'گرم',
      'symbol' => 'g',
    ),
    3 => 
    array (
      'title' => 'متر',
      'symbol' => 'm',
    ),
    4 => 
    array (
      'title' => 'متر مربع',
      'symbol' => 'm²',
    ),
    5 => 
    array (
      'title' => 'لیتر',
      'symbol' => 'l',
    ),
    6 => 
    array (
      'title' => 'بسته',
      'symbol' => 'pack',
    ),
    7 => 
    array (
      'title' => 'کارتن',
      'symbol' => 'carton',
    ),
    8 => 
    array (
      'title' => 'جعبه',
      'symbol' => 'box',
    ),
    9 => 
    array (
      'title' => 'ساعت',
      'symbol' => 'hour',
    ),
    10 => 
    array (
      'title' => 'روز',
      'symbol' => 'day',
    ),
    11 => 
    array (
      'title' => 'دستگاه',
      'symbol' => 'device',
    ),
    12 => 
    array (
      'title' => 'خدمت',
      'symbol' => 'service',
    ),
    13 => 
    array (
      'title' => 'تن',
      'symbol' => 'ton',
    ),
    14 => 
    array (
      'title' => 'میلی‌لیتر',
      'symbol' => 'ml',
    ),
  ),
  'person_types' => 
  array (
    0 => 
    array (
      'slug' => 'customer',
      'title_fa' => 'مشتری',
      'is_system' => 1,
    ),
    1 => 
    array (
      'slug' => 'supplier',
      'title_fa' => 'تأمین‌کننده',
      'is_system' => 1,
    ),
    2 => 
    array (
      'slug' => 'colleague',
      'title_fa' => 'همکار',
      'is_system' => 1,
    ),
    3 => 
    array (
      'slug' => 'marketer',
      'title_fa' => 'بازاریاب',
      'is_system' => 1,
    ),
    4 => 
    array (
      'slug' => 'shareholder',
      'title_fa' => 'سهامدار',
      'is_system' => 1,
    ),
    5 => 
    array (
      'slug' => 'employee',
      'title_fa' => 'پرسنل',
      'is_system' => 1,
    ),
    6 => 
    array (
      'slug' => 'other',
      'title_fa' => 'سایر',
      'is_system' => 1,
    ),
  ),
  'price_types' => 
  array (
    0 => 
    array (
      'slug' => 'purchase',
      'title_fa' => 'قیمت خرید',
    ),
    1 => 
    array (
      'slug' => 'sale',
      'title_fa' => 'قیمت فروش',
    ),
    2 => 
    array (
      'slug' => 'wholesale',
      'title_fa' => 'قیمت عمده',
    ),
    3 => 
    array (
      'slug' => 'customer',
      'title_fa' => 'قیمت مصوب مشتری',
    ),
  ),
  'payment_methods' => 
  array (
    0 => 
    array (
      'slug' => 'cash',
      'title_fa' => 'نقد',
    ),
    1 => 
    array (
      'slug' => 'pos',
      'title_fa' => 'کارتخوان',
    ),
    2 => 
    array (
      'slug' => 'card_transfer',
      'title_fa' => 'کارت به کارت',
    ),
    3 => 
    array (
      'slug' => 'iban_transfer',
      'title_fa' => 'حواله پایا / شبا',
    ),
    4 => 
    array (
      'slug' => 'cheque',
      'title_fa' => 'چک',
    ),
    5 => 
    array (
      'slug' => 'petty',
      'title_fa' => 'تنخواه',
    ),
  ),
  'payment_terms' => 
  array (
    0 => 
    array (
      'title' => 'نقدی',
      'days' => 0,
      'is_cash' => 1,
    ),
    1 => 
    array (
      'title' => '۷ روزه',
      'days' => 7,
      'is_cash' => 0,
    ),
    2 => 
    array (
      'title' => '۱۵ روزه',
      'days' => 15,
      'is_cash' => 0,
    ),
    3 => 
    array (
      'title' => '۳۰ روزه',
      'days' => 30,
      'is_cash' => 0,
    ),
    4 => 
    array (
      'title' => '۴۵ روزه',
      'days' => 45,
      'is_cash' => 0,
    ),
    5 => 
    array (
      'title' => '۶۰ روزه',
      'days' => 60,
      'is_cash' => 0,
    ),
    6 => 
    array (
      'title' => '۹۰ روزه',
      'days' => 90,
      'is_cash' => 0,
    ),
  ),
  'pl_categories' => 
  array (
    0 => 
    array (
      'kind' => 'income',
      'title' => 'فروش کالا',
      'account_code' => '4101',
    ),
    1 => 
    array (
      'kind' => 'income',
      'title' => 'درآمد خدمات',
      'account_code' => '4102',
    ),
    2 => 
    array (
      'kind' => 'income',
      'title' => 'درآمد حمل و نقل',
      'account_code' => '4104',
    ),
    3 => 
    array (
      'kind' => 'income',
      'title' => 'درآمد متفرقه',
      'account_code' => '4106',
    ),
    4 => 
    array (
      'kind' => 'expense',
      'title' => 'حقوق و دستمزد',
      'account_code' => '6101',
    ),
    5 => 
    array (
      'kind' => 'expense',
      'title' => 'اجاره',
      'account_code' => '6102',
    ),
    6 => 
    array (
      'kind' => 'expense',
      'title' => 'آب، برق و گاز',
      'account_code' => '6103',
    ),
    7 => 
    array (
      'kind' => 'expense',
      'title' => 'مخابرات و اینترنت',
      'account_code' => '6104',
    ),
    8 => 
    array (
      'kind' => 'expense',
      'title' => 'ملزومات مصرفی',
      'account_code' => '6105',
    ),
    9 => 
    array (
      'kind' => 'expense',
      'title' => 'حمل و نقل',
      'account_code' => '6106',
    ),
    10 => 
    array (
      'kind' => 'expense',
      'title' => 'تبلیغات و بازاریابی',
      'account_code' => '6107',
    ),
    11 => 
    array (
      'kind' => 'expense',
      'title' => 'تعمیر و نگهداری',
      'account_code' => '6108',
    ),
    12 => 
    array (
      'kind' => 'expense',
      'title' => 'سوخت و خودرو',
      'account_code' => '6109',
    ),
    13 => 
    array (
      'kind' => 'expense',
      'title' => 'ضایعات',
      'account_code' => '6110',
    ),
    14 => 
    array (
      'kind' => 'expense',
      'title' => 'کارمزد و هزینه بانکی',
      'account_code' => '6111',
    ),
    15 => 
    array (
      'kind' => 'expense',
      'title' => 'استهلاک',
      'account_code' => '6112',
    ),
    16 => 
    array (
      'kind' => 'expense',
      'title' => 'بیمه',
      'account_code' => '6113',
    ),
    17 => 
    array (
      'kind' => 'expense',
      'title' => 'مالیات و عوارض',
      'account_code' => '6114',
    ),
    18 => 
    array (
      'kind' => 'expense',
      'title' => 'پذیرایی و تنخواه',
      'account_code' => '6116',
    ),
    19 => 
    array (
      'kind' => 'expense',
      'title' => 'اداری و متفرقه',
      'account_code' => '6117',
    ),
  ),
  'waste_reasons' => 
  array (
    0 => 
    array (
      'title' => 'شکست و خرابی',
      'expense_account_code' => '6110',
    ),
    1 => 
    array (
      'title' => 'تاریخ گذشته',
      'expense_account_code' => '6110',
    ),
    2 => 
    array (
      'title' => 'سرقت / مفقودی',
      'expense_account_code' => '6110',
    ),
    3 => 
    array (
      'title' => 'سایر',
      'expense_account_code' => '6110',
    ),
  ),
  'settings' => 
  array (
    0 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_sale',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند فاکتور فروش',
      'group_fa' => 'تنظیمات مالی',
    ),
    1 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_buy',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند فاکتور خرید',
      'group_fa' => 'تنظیمات مالی',
    ),
    2 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_receipt_payment',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند دریافت و پرداخت',
      'group_fa' => 'تنظیمات مالی',
    ),
    3 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_transfer',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند انتقال وجه',
      'group_fa' => 'تنظیمات مالی',
    ),
    4 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_inventory',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند حواله انبار',
      'group_fa' => 'تنظیمات مالی',
    ),
    5 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_payroll',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار سند حقوق و دستمزد',
      'group_fa' => 'تنظیمات مالی',
    ),
    6 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.auto_journal_bank_fee',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'ثبت خودکار هزینه کارمزد بانکی',
      'group_fa' => 'تنظیمات مالی',
    ),
    7 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.vat_rate_percent',
      'value_json' => '10',
      'value_type' => 'decimal',
      'title_fa' => 'نرخ مالیات بر ارزش افزوده',
      'group_fa' => 'تنظیمات مالی',
    ),
    8 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.payroll_tax_mode',
      'value_json' => '"step"',
      'value_type' => 'string',
      'title_fa' => 'روش محاسبه مالیات حقوق (پله‌ای/ثابت)',
      'group_fa' => 'تنظیمات مالی',
    ),
    9 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.fx_translation_method',
      'value_json' => '"daily"',
      'value_type' => 'string',
      'title_fa' => 'روش تسعیر ارز (روز/میانگین/ثابت)',
      'group_fa' => 'تنظیمات مالی',
    ),
    10 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.default_fx_rate',
      'value_json' => '1',
      'value_type' => 'decimal',
      'title_fa' => 'نرخ ارز پیش‌فرض (دلار)',
      'group_fa' => 'تنظیمات مالی',
    ),
    11 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.rounding_mode',
      'value_json' => '"nearest"',
      'value_type' => 'string',
      'title_fa' => 'نحوه رُند کردن مبالغ',
      'group_fa' => 'تنظیمات مالی',
    ),
    12 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.base_currency',
      'value_json' => '"IRT"',
      'value_type' => 'string',
      'title_fa' => 'واحد پول پایه (تومان/ریال)',
      'group_fa' => 'تنظیمات مالی',
    ),
    13 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.mapping.ar_account',
      'value_json' => '"1106"',
      'value_type' => 'string',
      'title_fa' => 'کدینگ پیش‌فرض حساب دریافتنی',
      'group_fa' => 'تنظیمات مالی',
    ),
    14 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.mapping.ap_account',
      'value_json' => '"2101"',
      'value_type' => 'string',
      'title_fa' => 'کدینگ پیش‌فرض حساب پرداختنی',
      'group_fa' => 'تنظیمات مالی',
    ),
    15 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.mapping.sales_account',
      'value_json' => '"4101"',
      'value_type' => 'string',
      'title_fa' => 'کدینگ پیش‌فرض حساب فروش',
      'group_fa' => 'تنظیمات مالی',
    ),
    16 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.mapping.cogs_account',
      'value_json' => '"5101"',
      'value_type' => 'string',
      'title_fa' => 'کدینگ پیش‌فرض بهای تمام‌شده',
      'group_fa' => 'تنظیمات مالی',
    ),
    17 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.mapping.cash_account',
      'value_json' => '"1102"',
      'value_type' => 'string',
      'title_fa' => 'کدینگ پیش‌فرض نقد و بانک',
      'group_fa' => 'تنظیمات مالی',
    ),
    18 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.retention.accounting_years',
      'value_json' => '10',
      'value_type' => 'int',
      'title_fa' => 'نگهداری اسناد حسابداری (سال)',
      'group_fa' => 'سیاست نگهداری',
    ),
    19 => 
    array (
      'category' => 'financial',
      'setting_key' => 'financial.retention.tax_years',
      'value_json' => '10',
      'value_type' => 'int',
      'title_fa' => 'نگهداری گزارش‌های مالیاتی (سال)',
      'group_fa' => 'سیاست نگهداری',
    ),
    20 => 
    array (
      'category' => 'access',
      'setting_key' => 'access.two_factor_required',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'الزام ورود دو مرحله‌ای',
      'group_fa' => 'امنیت',
    ),
    21 => 
    array (
      'category' => 'access',
      'setting_key' => 'access.session_timeout_minutes',
      'value_json' => '60',
      'value_type' => 'int',
      'title_fa' => 'انقضای نشست (دقیقه)',
      'group_fa' => 'امنیت',
    ),
    22 => 
    array (
      'category' => 'access',
      'setting_key' => 'access.default_user_discount_percent',
      'value_json' => '5',
      'value_type' => 'decimal',
      'title_fa' => 'سقف تخفیف پیش‌فرض کاربران',
      'group_fa' => 'امنیت',
    ),
    23 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.paper_size',
      'value_json' => '"A4"',
      'value_type' => 'string',
      'title_fa' => 'اندازه کاغذ قالب پیش‌فرض',
      'group_fa' => 'تنظیمات چاپ',
    ),
    24 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.default_template_id',
      'value_json' => '1',
      'value_type' => 'int',
      'title_fa' => 'قالب چاپ پیش‌فرض',
      'group_fa' => 'تنظیمات چاپ',
    ),
    25 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.font_size',
      'value_json' => '12',
      'value_type' => 'int',
      'title_fa' => 'اندازه فونت چاپ',
      'group_fa' => 'تنظیمات چاپ',
    ),
    26 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.amount_in_words',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'درج مبالغ به حروف',
      'group_fa' => 'تنظیمات چاپ',
    ),
    27 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.show_signature',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'نمایش مهر و امضا',
      'group_fa' => 'تنظیمات چاپ',
    ),
    28 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.show_bank_info',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'نمایش شبا و کارت بانکی',
      'group_fa' => 'تنظیمات چاپ',
    ),
    29 => 
    array (
      'category' => 'printing',
      'setting_key' => 'printing.show_barcode',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'درج بارکد سند',
      'group_fa' => 'تنظیمات چاپ',
    ),
    30 => 
    array (
      'category' => 'hr',
      'setting_key' => 'hr.insurance_rate_employee',
      'value_json' => '7',
      'value_type' => 'decimal',
      'title_fa' => 'بیمه سهم کارمند (٪)',
      'group_fa' => 'تنظیمات اسناد حقوق',
    ),
    31 => 
    array (
      'category' => 'hr',
      'setting_key' => 'hr.insurance_rate_employer',
      'value_json' => '23',
      'value_type' => 'decimal',
      'title_fa' => 'بیمه سهم کارفرما (٪)',
      'group_fa' => 'تنظیمات اسناد حقوق',
    ),
    32 => 
    array (
      'category' => 'hr',
      'setting_key' => 'hr.tax_exemption_amount',
      'value_json' => '120000000',
      'value_type' => 'decimal',
      'title_fa' => 'سقف معافیت مالیات حقوق',
      'group_fa' => 'تنظیمات اسناد حقوق',
    ),
    33 => 
    array (
      'category' => 'hr',
      'setting_key' => 'hr.attendance_device_enabled',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'اتصال به دستگاه حضور و غیاب',
      'group_fa' => 'تنظیمات اسناد حقوق',
    ),
    34 => 
    array (
      'category' => 'hr',
      'setting_key' => 'hr.payslip_pdf_enabled',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'صدور فیش حقوقی PDF',
      'group_fa' => 'تنظیمات اسناد حقوق',
    ),
    35 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.credit_low_threshold',
      'value_json' => '200',
      'value_type' => 'int',
      'title_fa' => 'آستانه هشدار اعتبار پیامک',
      'group_fa' => 'پیامک',
    ),
    36 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.thanks_after_invoice',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'پیامک تشکر پس از ثبت فاکتور',
      'group_fa' => 'پیامک',
    ),
    37 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.due_reminder_days',
      'value_json' => '[7, 3, 1]',
      'value_type' => 'json',
      'title_fa' => 'روزهای یادآوری سررسید فاکتور',
      'group_fa' => 'پیامک',
    ),
    38 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.cheque_reminder_days',
      'value_json' => '[7, 3, 1]',
      'value_type' => 'json',
      'title_fa' => 'روزهای یادآوری سررسید چک',
      'group_fa' => 'پیامک',
    ),
    39 => 
    array (
      'category' => 'technical',
      'setting_key' => 'notify.inapp_enabled',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'اعلان داخلی پنل',
      'group_fa' => 'اعلان‌ها',
    ),
    40 => 
    array (
      'category' => 'technical',
      'setting_key' => 'notify.low_stock_enabled',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'هشدار کمبود موجودی',
      'group_fa' => 'اعلان‌ها',
    ),
    41 => 
    array (
      'category' => 'technical',
      'setting_key' => 'notify.subscription_expiry_days',
      'value_json' => '7',
      'value_type' => 'int',
      'title_fa' => 'هشدار تمدید اشتراک (روز)',
      'group_fa' => 'اعلان‌ها',
    ),
    42 => 
    array (
      'category' => 'technical',
      'setting_key' => 'inventory.negative_stock_policy',
      'value_json' => '"block"',
      'value_type' => 'string',
      'title_fa' => 'سیاست موجودی منفی (منع/اجازه/هشدار)',
      'group_fa' => 'انبار',
    ),
    43 => 
    array (
      'category' => 'technical',
      'setting_key' => 'inventory.cost_method_default',
      'value_json' => '"fifo"',
      'value_type' => 'string',
      'title_fa' => 'روش پیش‌فرض قیمت‌گذاری',
      'group_fa' => 'انبار',
    ),
    44 => 
    array (
      'category' => 'technical',
      'setting_key' => 'inventory.auto_issue_on_sale',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'صدور خودکار حواله خروج با فاکتور',
      'group_fa' => 'انبار',
    ),
    45 => 
    array (
      'category' => 'technical',
      'setting_key' => 'inventory.count_period',
      'value_json' => '"monthly"',
      'value_type' => 'string',
      'title_fa' => 'دوره انبارگردانی (ماهانه/فصلی/سالانه)',
      'group_fa' => 'انبار',
    ),
    46 => 
    array (
      'category' => 'technical',
      'setting_key' => 'trade.default_payment_term_days',
      'value_json' => '30',
      'value_type' => 'int',
      'title_fa' => 'مهلت پرداخت پیش‌فرض (روز)',
      'group_fa' => 'خرید و فروش',
    ),
    47 => 
    array (
      'category' => 'technical',
      'setting_key' => 'trade.price_include_tax',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'قیمت‌ها شامل مالیات',
      'group_fa' => 'خرید و فروش',
    ),
    48 => 
    array (
      'category' => 'technical',
      'setting_key' => 'trade.auto_reserve_stock',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'رزرو خودکار موجودی در پیش‌فاکتور',
      'group_fa' => 'خرید و فروش',
    ),
    49 => 
    array (
      'category' => 'moadian',
      'setting_key' => 'moadian.enabled',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'فعال بودن سامانه مودیان',
      'group_fa' => 'مودیان',
    ),
    50 => 
    array (
      'category' => 'moadian',
      'setting_key' => 'moadian.environment',
      'value_json' => '"sandbox"',
      'value_type' => 'string',
      'title_fa' => 'محیط (آزمون/عملیات)',
      'group_fa' => 'مودیان',
    ),
    51 => 
    array (
      'category' => 'moadian',
      'setting_key' => 'moadian.auto_submit',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'ارسال خودکار صورتحساب',
      'group_fa' => 'مودیان',
    ),
    52 => 
    array (
      'category' => 'backup',
      'setting_key' => 'backup.auto_daily',
      'value_json' => 'true',
      'value_type' => 'bool',
      'title_fa' => 'پشتیبان‌گیری خودکار روزانه',
      'group_fa' => 'پشتیبان',
    ),
    53 => 
    array (
      'category' => 'backup',
      'setting_key' => 'backup.hour',
      'value_json' => '23',
      'value_type' => 'int',
      'title_fa' => 'ساعت اجرای پشتیبان',
      'group_fa' => 'پشتیبان',
    ),
    54 => 
    array (
      'category' => 'backup',
      'setting_key' => 'backup.keep_versions',
      'value_json' => '30',
      'value_type' => 'int',
      'title_fa' => 'تعداد نسخه‌های نگهداری',
      'group_fa' => 'پشتیبان',
    ),
    55 => 
    array (
      'category' => 'backup',
      'setting_key' => 'backup.email_to_admin',
      'value_json' => 'false',
      'value_type' => 'bool',
      'title_fa' => 'ارسال پشتیبان به ایمیل مدیر',
      'group_fa' => 'پشتیبان',
    ),
    56 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.kavenegar_driver',
      'value_json' => '"kavenegar"',
      'value_type' => 'string',
      'title_fa' => 'درایور ارسال پیامک (kavenegar = ارسال واقعی · log = فقط ثبت)',
      'group_fa' => 'اتصال سامانهٔ پیامک (کاوه‌نگار)',
    ),
    57 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.kavenegar_api_key',
      'value_json' => '"39396B65697855656D4E354B3752666F463070615668677A4A633253445934515843753547502B724D646F3D"',
      'value_type' => 'string',
      'title_fa' => 'کلید API کاوه‌نگار',
      'group_fa' => 'اتصال سامانهٔ پیامک (کاوه‌نگار)',
    ),
    58 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.kavenegar_template',
      'value_json' => '"sendmelodi"',
      'value_type' => 'string',
      'title_fa' => 'نام الگوی کد تایید (Lookup)',
      'group_fa' => 'اتصال سامانهٔ پیامک (کاوه‌نگار)',
    ),
    59 => 
    array (
      'category' => 'sms',
      'setting_key' => 'sms.kavenegar_sender',
      'value_json' => '""',
      'value_type' => 'string',
      'title_fa' => 'شمارهٔ خط ارسال (خالی = خط پیش‌فرض حساب)',
      'group_fa' => 'اتصال سامانهٔ پیامک (کاوه‌نگار)',
    ),
  ),
  'number_sequences' => 
  array (
    0 => 
    array (
      'doc_type' => 'sale',
      'template' => 'INV-{FY}-{SEQ}',
      'next_value' => 3,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    1 => 
    array (
      'doc_type' => 'buy',
      'template' => 'PINV-{FY}-{SEQ}',
      'next_value' => 2,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    2 => 
    array (
      'doc_type' => 'sale_return',
      'template' => 'SR-{FY}-{SEQ}',
      'next_value' => 1,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    3 => 
    array (
      'doc_type' => 'buy_return',
      'template' => 'BR-{FY}-{SEQ}',
      'next_value' => 1,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    4 => 
    array (
      'doc_type' => 'quote',
      'template' => 'QT-{FY}-{SEQ}',
      'next_value' => 1,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    5 => 
    array (
      'doc_type' => 'receipt',
      'template' => 'RC-{FY}-{SEQ}',
      'next_value' => 3,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    6 => 
    array (
      'doc_type' => 'payment',
      'template' => 'PY-{FY}-{SEQ}',
      'next_value' => 2,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    7 => 
    array (
      'doc_type' => 'cheque',
      'template' => 'CH-{FY}-{SEQ}',
      'next_value' => 3,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    8 => 
    array (
      'doc_type' => 'journal',
      'template' => 'JV-{FY}-{SEQ}',
      'next_value' => 13,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    9 => 
    array (
      'doc_type' => 'hr',
      'template' => 'HR-{FY}-{SEQ}',
      'next_value' => 2,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    10 => 
    array (
      'doc_type' => 'transfer',
      'template' => 'TR-{FY}-{SEQ}',
      'next_value' => 2,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    11 => 
    array (
      'doc_type' => 'waste',
      'template' => 'WS-{FY}-{SEQ}',
      'next_value' => 2,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    12 => 
    array (
      'doc_type' => 'count',
      'template' => 'CT-{FY}-{SEQ}',
      'next_value' => 1,
      'step' => 1,
      'reset_yearly' => 1,
    ),
    13 => 
    array (
      'doc_type' => 'voucher',
      'template' => 'VC-{FY}-{SEQ}',
      'next_value' => 1,
      'step' => 1,
      'reset_yearly' => 1,
    ),
  ),
  'print_templates' => 
  array (
    0 => 
    array (
      'title' => 'فاکتور رسمی A4',
      'template_type' => 'invoice',
      'paper_size' => 'A4',
      'show_logo' => 1,
      'logo_position' => 'right',
      'font_size' => 12,
      'show_signature' => 1,
      'amount_in_words' => 1,
      'show_economic_code' => 1,
      'show_bank_info' => 1,
      'show_barcode' => 0,
      'is_default' => 1,
      'status' => 'active',
    ),
    1 => 
    array (
      'title' => 'فاکتور ساده A5',
      'template_type' => 'invoice',
      'paper_size' => 'A5',
      'show_logo' => 1,
      'logo_position' => 'right',
      'font_size' => 11,
      'show_signature' => 0,
      'amount_in_words' => 0,
      'show_economic_code' => 0,
      'show_bank_info' => 0,
      'show_barcode' => 0,
      'is_default' => 0,
      'status' => 'active',
    ),
    2 => 
    array (
      'title' => 'حواله انبار A5',
      'template_type' => 'voucher',
      'paper_size' => 'A5',
      'show_logo' => 0,
      'logo_position' => 'right',
      'font_size' => 11,
      'show_signature' => 1,
      'amount_in_words' => 0,
      'show_economic_code' => 0,
      'show_bank_info' => 0,
      'show_barcode' => 1,
      'is_default' => 0,
      'status' => 'active',
    ),
  ),
  'auto_entry_rules' => 
  array (
    0 => 
    array (
      'event_key' => 'invoice.sale.cash',
      'title_fa' => 'ثبت سند فاکتور فروش نقدی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'invoice_total',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'sales',
          'account_code' => NULL,
          'amount_source' => 'invoice_net',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'dynamic_tax',
          'mapping_key' => 'vat_payable',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 3,
        ),
        3 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'shipping_revenue',
          'account_code' => NULL,
          'amount_source' => 'charges',
          'row_order' => 4,
        ),
      ),
    ),
    1 => 
    array (
      'event_key' => 'invoice.sale.credit',
      'title_fa' => 'ثبت سند فاکتور فروش اعتباری',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'ar',
          'account_code' => NULL,
          'amount_source' => 'invoice_total',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'sales',
          'account_code' => NULL,
          'amount_source' => 'invoice_net',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'dynamic_tax',
          'mapping_key' => 'vat_payable',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 3,
        ),
        3 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'shipping_revenue',
          'account_code' => NULL,
          'amount_source' => 'charges',
          'row_order' => 4,
        ),
      ),
    ),
    2 => 
    array (
      'event_key' => 'invoice.sale.cogs',
      'title_fa' => 'ثبت بهای تمام‌شده فاکتور فروش',
      'priority' => 20,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'cogs',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    3 => 
    array (
      'event_key' => 'invoice.sale_return',
      'title_fa' => 'ثبت سند برگشت از فروش',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'sales_return',
          'account_code' => NULL,
          'amount_source' => 'invoice_net',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'debit',
          'account_source' => 'dynamic_tax',
          'mapping_key' => 'vat_payable',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'ar',
          'account_code' => NULL,
          'amount_source' => 'invoice_total',
          'row_order' => 3,
        ),
      ),
    ),
    4 => 
    array (
      'event_key' => 'invoice.sale_return.cogs',
      'title_fa' => 'برگشت بهای تمام‌شده به انبار',
      'priority' => 20,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cogs',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    5 => 
    array (
      'event_key' => 'invoice.buy.credit',
      'title_fa' => 'ثبت سند فاکتور خرید اعتباری',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'invoice_net',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'debit',
          'account_source' => 'dynamic_tax',
          'mapping_key' => 'vat_receivable',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'ap',
          'account_code' => NULL,
          'amount_source' => 'invoice_total',
          'row_order' => 3,
        ),
      ),
    ),
    6 => 
    array (
      'event_key' => 'invoice.buy.cash',
      'title_fa' => 'ثبت سند فاکتور خرید نقدی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'invoice_net',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'debit',
          'account_source' => 'dynamic_tax',
          'mapping_key' => 'vat_receivable',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'invoice_total',
          'row_order' => 3,
        ),
      ),
    ),
    7 => 
    array (
      'event_key' => 'receipt.cash',
      'title_fa' => 'ثبت سند دریافت نقدی/بانکی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    8 => 
    array (
      'event_key' => 'receipt.cheque',
      'title_fa' => 'ثبت سند دریافت چک',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_receivable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    9 => 
    array (
      'event_key' => 'payment.cash',
      'title_fa' => 'ثبت سند پرداخت نقدی/بانکی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    10 => 
    array (
      'event_key' => 'payment.cheque',
      'title_fa' => 'ثبت سند پرداخت با چک',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_payable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    11 => 
    array (
      'event_key' => 'transfer',
      'title_fa' => 'ثبت سند انتقال وجه',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'debit',
          'account_source' => 'fixed',
          'mapping_key' => NULL,
          'account_code' => '6111',
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 3,
        ),
      ),
    ),
    12 => 
    array (
      'event_key' => 'inventory.issue',
      'title_fa' => 'ثبت سند حواله خروج انبار',
      'priority' => 30,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'cogs',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    13 => 
    array (
      'event_key' => 'inventory.receive',
      'title_fa' => 'ثبت سند حواله ورود انبار',
      'priority' => 30,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'purchase_interim',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    14 => 
    array (
      'event_key' => 'inventory.waste',
      'title_fa' => 'ثبت سند ضایعات انبار',
      'priority' => 30,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'waste_expense',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    15 => 
    array (
      'event_key' => 'inventory.count.shortage',
      'title_fa' => 'ثبت کسری انبارگردانی',
      'priority' => 30,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'waste_expense',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    16 => 
    array (
      'event_key' => 'inventory.count.surplus',
      'title_fa' => 'ثبت مازاد انبارگردانی',
      'priority' => 30,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'inventory_gain',
          'account_code' => NULL,
          'amount_source' => 'cogs',
          'row_order' => 2,
        ),
      ),
    ),
    17 => 
    array (
      'event_key' => 'expense.cash',
      'title_fa' => 'ثبت سند هزینه',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'expense_default',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    18 => 
    array (
      'event_key' => 'expense.credit',
      'title_fa' => 'ثبت سند هزینه پرداخت‌نشده',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'expense_default',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'ap',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    19 => 
    array (
      'event_key' => 'income.cash',
      'title_fa' => 'ثبت سند درآمد',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'service_revenue',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    20 => 
    array (
      'event_key' => 'income.credit',
      'title_fa' => 'ثبت سند درآمد وصول‌نشده',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'ar',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'service_revenue',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    21 => 
    array (
      'event_key' => 'payroll',
      'title_fa' => 'ثبت سند حقوق و دستمزد',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'payroll_expense',
          'account_code' => NULL,
          'amount_source' => 'expense_total',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'insurance_payable',
          'account_code' => NULL,
          'amount_source' => 'insurance_payable',
          'row_order' => 2,
        ),
        2 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'payroll_tax',
          'account_code' => NULL,
          'amount_source' => 'tax',
          'row_order' => 3,
        ),
        3 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'payroll_payable',
          'account_code' => NULL,
          'amount_source' => 'net',
          'row_order' => 4,
        ),
        4 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'staff_advances',
          'account_code' => NULL,
          'amount_source' => 'advance_total',
          'row_order' => 5,
        ),
        5 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'staff_loans',
          'account_code' => NULL,
          'amount_source' => 'loan_total',
          'row_order' => 6,
        ),
        6 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'payroll_deductions',
          'account_code' => NULL,
          'amount_source' => 'deduction_total',
          'row_order' => 7,
        ),
      ),
    ),
    22 => 
    array (
      'event_key' => 'payroll.payment',
      'title_fa' => 'ثبت پرداخت خالص حقوق',
      'priority' => 20,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'payroll_payable',
          'account_code' => NULL,
          'amount_source' => 'paid',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'paid',
          'row_order' => 2,
        ),
      ),
    ),
    23 => 
    array (
      'event_key' => 'commission',
      'title_fa' => 'ثبت سند پورسانت فروش',
      'priority' => 40,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'commission_expense',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'ap',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    24 => 
    array (
      'event_key' => 'cheque.received',
      'title_fa' => 'ثبت چک دریافتی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_receivable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    25 => 
    array (
      'event_key' => 'cheque.cleared',
      'title_fa' => 'وصول چک دریافتی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'bank',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_receivable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    26 => 
    array (
      'event_key' => 'cheque.bounced',
      'title_fa' => 'برگشت چک دریافتی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_receivable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    27 => 
    array (
      'event_key' => 'cheque.issued',
      'title_fa' => 'صدور چک پرداختی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_payable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    28 => 
    array (
      'event_key' => 'cheque.paid',
      'title_fa' => 'پاس شدن چک پرداختی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_payable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'cash_account',
          'mapping_key' => 'bank',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    29 => 
    array (
      'event_key' => 'cheque.endorsed',
      'title_fa' => 'خرج چک دریافتی',
      'priority' => 10,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'person',
          'mapping_key' => NULL,
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'cheque_receivable',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    30 => 
    array (
      'event_key' => 'year.opening',
      'title_fa' => 'سند افتتاحیه سال',
      'priority' => 5,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'cash_account',
          'mapping_key' => 'cash',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'capital',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
    31 => 
    array (
      'event_key' => 'year.closing',
      'title_fa' => 'سند اختتامیه سال',
      'priority' => 5,
      'is_enabled' => 1,
      'description' => NULL,
      'lines' => 
      array (
        0 => 
        array (
          'side' => 'debit',
          'account_source' => 'mapping',
          'mapping_key' => 'sales',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 1,
        ),
        1 => 
        array (
          'side' => 'credit',
          'account_source' => 'mapping',
          'mapping_key' => 'retained_earnings',
          'account_code' => NULL,
          'amount_source' => 'amount',
          'row_order' => 2,
        ),
      ),
    ),
  ),
  'roles' => 
  array (
    0 => 
    array (
      'name' => 'مدیر کل',
      'slug' => 'admin',
      'description' => 'دسترسی کامل به همه بخش‌ها',
      'is_system' => 1,
      'permissions' => 
      array (
        0 => 'access.approve',
        1 => 'access.create',
        2 => 'access.delete',
        3 => 'access.edit',
        4 => 'access.export',
        5 => 'access.lock',
        6 => 'access.print',
        7 => 'access.submit',
        8 => 'access.view',
        9 => 'accounting.approve',
        10 => 'accounting.create',
        11 => 'accounting.delete',
        12 => 'accounting.edit',
        13 => 'accounting.export',
        14 => 'accounting.lock',
        15 => 'accounting.print',
        16 => 'accounting.submit',
        17 => 'accounting.view',
        18 => 'api.approve',
        19 => 'api.create',
        20 => 'api.delete',
        21 => 'api.edit',
        22 => 'api.export',
        23 => 'api.lock',
        24 => 'api.print',
        25 => 'api.submit',
        26 => 'api.view',
        27 => 'attendance.approve',
        28 => 'attendance.create',
        29 => 'attendance.delete',
        30 => 'attendance.edit',
        31 => 'attendance.export',
        32 => 'attendance.lock',
        33 => 'attendance.print',
        34 => 'attendance.submit',
        35 => 'attendance.view',
        36 => 'backup.approve',
        37 => 'backup.create',
        38 => 'backup.delete',
        39 => 'backup.edit',
        40 => 'backup.export',
        41 => 'backup.lock',
        42 => 'backup.print',
        43 => 'backup.submit',
        44 => 'backup.view',
        45 => 'cheques.approve',
        46 => 'cheques.create',
        47 => 'cheques.delete',
        48 => 'cheques.edit',
        49 => 'cheques.export',
        50 => 'cheques.lock',
        51 => 'cheques.print',
        52 => 'cheques.submit',
        53 => 'cheques.view',
        54 => 'cost_centers.approve',
        55 => 'cost_centers.create',
        56 => 'cost_centers.delete',
        57 => 'cost_centers.edit',
        58 => 'cost_centers.export',
        59 => 'cost_centers.lock',
        60 => 'cost_centers.print',
        61 => 'cost_centers.submit',
        62 => 'cost_centers.view',
        63 => 'dashboard.approve',
        64 => 'dashboard.create',
        65 => 'dashboard.delete',
        66 => 'dashboard.edit',
        67 => 'dashboard.export',
        68 => 'dashboard.lock',
        69 => 'dashboard.print',
        70 => 'dashboard.submit',
        71 => 'dashboard.view',
        72 => 'income_expense.approve',
        73 => 'income_expense.create',
        74 => 'income_expense.delete',
        75 => 'income_expense.edit',
        76 => 'income_expense.export',
        77 => 'income_expense.lock',
        78 => 'income_expense.print',
        79 => 'income_expense.submit',
        80 => 'income_expense.view',
        81 => 'inventory.approve',
        82 => 'inventory.create',
        83 => 'inventory.delete',
        84 => 'inventory.edit',
        85 => 'inventory.export',
        86 => 'inventory.lock',
        87 => 'inventory.print',
        88 => 'inventory.submit',
        89 => 'inventory.view',
        90 => 'invoices.approve',
        91 => 'invoices.create',
        92 => 'invoices.delete',
        93 => 'invoices.edit',
        94 => 'invoices.export',
        95 => 'invoices.lock',
        96 => 'invoices.print',
        97 => 'invoices.submit',
        98 => 'invoices.view',
        99 => 'messages.approve',
        100 => 'messages.create',
        101 => 'messages.delete',
        102 => 'messages.edit',
        103 => 'messages.export',
        104 => 'messages.lock',
        105 => 'messages.print',
        106 => 'messages.submit',
        107 => 'messages.view',
        108 => 'moadian.approve',
        109 => 'moadian.create',
        110 => 'moadian.delete',
        111 => 'moadian.edit',
        112 => 'moadian.export',
        113 => 'moadian.lock',
        114 => 'moadian.print',
        115 => 'moadian.submit',
        116 => 'moadian.view',
        117 => 'payments.approve',
        118 => 'payments.create',
        119 => 'payments.delete',
        120 => 'payments.edit',
        121 => 'payments.export',
        122 => 'payments.lock',
        123 => 'payments.print',
        124 => 'payments.submit',
        125 => 'payments.view',
        126 => 'payroll.approve',
        127 => 'payroll.create',
        128 => 'payroll.delete',
        129 => 'payroll.edit',
        130 => 'payroll.export',
        131 => 'payroll.lock',
        132 => 'payroll.print',
        133 => 'payroll.submit',
        134 => 'payroll.view',
        135 => 'persons.approve',
        136 => 'persons.create',
        137 => 'persons.delete',
        138 => 'persons.edit',
        139 => 'persons.export',
        140 => 'persons.lock',
        141 => 'persons.print',
        142 => 'persons.submit',
        143 => 'persons.view',
        144 => 'printing.approve',
        145 => 'printing.create',
        146 => 'printing.delete',
        147 => 'printing.edit',
        148 => 'printing.export',
        149 => 'printing.lock',
        150 => 'printing.print',
        151 => 'printing.submit',
        152 => 'printing.view',
        153 => 'products.approve',
        154 => 'products.create',
        155 => 'products.delete',
        156 => 'products.edit',
        157 => 'products.export',
        158 => 'products.lock',
        159 => 'products.print',
        160 => 'products.submit',
        161 => 'products.view',
        162 => 'projects.approve',
        163 => 'projects.create',
        164 => 'projects.delete',
        165 => 'projects.edit',
        166 => 'projects.export',
        167 => 'projects.lock',
        168 => 'projects.print',
        169 => 'projects.submit',
        170 => 'projects.view',
        171 => 'receipts.approve',
        172 => 'receipts.create',
        173 => 'receipts.delete',
        174 => 'receipts.edit',
        175 => 'receipts.export',
        176 => 'receipts.lock',
        177 => 'receipts.print',
        178 => 'receipts.submit',
        179 => 'receipts.view',
        180 => 'reports.approve',
        181 => 'reports.create',
        182 => 'reports.delete',
        183 => 'reports.edit',
        184 => 'reports.export',
        185 => 'reports.lock',
        186 => 'reports.print',
        187 => 'reports.submit',
        188 => 'reports.view',
        189 => 'settings.approve',
        190 => 'settings.create',
        191 => 'settings.delete',
        192 => 'settings.edit',
        193 => 'settings.export',
        194 => 'settings.lock',
        195 => 'settings.print',
        196 => 'settings.submit',
        197 => 'settings.view',
        198 => 'subscription.approve',
        199 => 'subscription.create',
        200 => 'subscription.delete',
        201 => 'subscription.edit',
        202 => 'subscription.export',
        203 => 'subscription.lock',
        204 => 'subscription.print',
        205 => 'subscription.submit',
        206 => 'subscription.view',
        207 => 'tickets.approve',
        208 => 'tickets.create',
        209 => 'tickets.delete',
        210 => 'tickets.edit',
        211 => 'tickets.export',
        212 => 'tickets.lock',
        213 => 'tickets.print',
        214 => 'tickets.submit',
        215 => 'tickets.view',
        216 => 'transfers.approve',
        217 => 'transfers.create',
        218 => 'transfers.delete',
        219 => 'transfers.edit',
        220 => 'transfers.export',
        221 => 'transfers.lock',
        222 => 'transfers.print',
        223 => 'transfers.submit',
        224 => 'transfers.view',
        225 => 'users.approve',
        226 => 'users.create',
        227 => 'users.delete',
        228 => 'users.edit',
        229 => 'users.export',
        230 => 'users.lock',
        231 => 'users.print',
        232 => 'users.submit',
        233 => 'users.view',
        234 => 'petty_cash.view',
        235 => 'petty_cash.create',
        236 => 'petty_cash.edit',
        237 => 'petty_cash.approve',
        238 => 'petty_cash.print',
      ),
    ),
    1 => 
    array (
      'name' => 'حسابدار',
      'slug' => 'accountant',
      'description' => 'حسابداری، خزانه، گزارشات و حقوق',
      'is_system' => 1,
      'permissions' => 
      array (
        0 => 'dashboard.view',
        1 => 'persons.view',
        2 => 'persons.create',
        3 => 'persons.edit',
        4 => 'persons.print',
        5 => 'persons.export',
        6 => 'products.view',
        7 => 'products.create',
        8 => 'products.edit',
        9 => 'products.print',
        10 => 'products.export',
        11 => 'inventory.view',
        12 => 'inventory.create',
        13 => 'inventory.edit',
        14 => 'inventory.print',
        15 => 'inventory.export',
        16 => 'invoices.view',
        17 => 'invoices.create',
        18 => 'invoices.edit',
        19 => 'invoices.delete',
        20 => 'invoices.print',
        21 => 'invoices.export',
        22 => 'invoices.approve',
        23 => 'invoices.lock',
        24 => 'invoices.submit',
        25 => 'receipts.view',
        26 => 'receipts.create',
        27 => 'receipts.edit',
        28 => 'receipts.delete',
        29 => 'receipts.print',
        30 => 'receipts.export',
        31 => 'receipts.approve',
        32 => 'receipts.lock',
        33 => 'receipts.submit',
        34 => 'payments.view',
        35 => 'payments.create',
        36 => 'payments.edit',
        37 => 'payments.delete',
        38 => 'payments.print',
        39 => 'payments.export',
        40 => 'payments.approve',
        41 => 'payments.lock',
        42 => 'payments.submit',
        43 => 'transfers.view',
        44 => 'transfers.create',
        45 => 'transfers.edit',
        46 => 'transfers.delete',
        47 => 'transfers.print',
        48 => 'transfers.export',
        49 => 'transfers.approve',
        50 => 'transfers.lock',
        51 => 'transfers.submit',
        52 => 'cheques.view',
        53 => 'cheques.create',
        54 => 'cheques.edit',
        55 => 'cheques.delete',
        56 => 'cheques.print',
        57 => 'cheques.export',
        58 => 'cheques.approve',
        59 => 'cheques.lock',
        60 => 'cheques.submit',
        61 => 'income_expense.view',
        62 => 'income_expense.create',
        63 => 'income_expense.edit',
        64 => 'income_expense.delete',
        65 => 'income_expense.print',
        66 => 'income_expense.export',
        67 => 'income_expense.approve',
        68 => 'income_expense.lock',
        69 => 'income_expense.submit',
        70 => 'accounting.view',
        71 => 'accounting.create',
        72 => 'accounting.edit',
        73 => 'accounting.delete',
        74 => 'accounting.print',
        75 => 'accounting.export',
        76 => 'accounting.approve',
        77 => 'accounting.lock',
        78 => 'accounting.submit',
        79 => 'reports.view',
        80 => 'reports.create',
        81 => 'reports.edit',
        82 => 'reports.delete',
        83 => 'reports.print',
        84 => 'reports.export',
        85 => 'reports.approve',
        86 => 'reports.lock',
        87 => 'reports.submit',
        88 => 'payroll.view',
        89 => 'payroll.create',
        90 => 'payroll.edit',
        91 => 'payroll.print',
        92 => 'payroll.export',
        93 => 'settings.view',
        94 => 'printing.view',
        95 => 'printing.print',
        96 => 'petty_cash.view',
        97 => 'petty_cash.create',
        98 => 'petty_cash.edit',
        99 => 'petty_cash.approve',
        100 => 'petty_cash.print',
      ),
    ),
    2 => 
    array (
      'name' => 'انباردار',
      'slug' => 'warehouse',
      'description' => 'انبارداری، حواله‌ها و انبارگردانی',
      'is_system' => 1,
      'permissions' => 
      array (
        0 => 'dashboard.view',
        1 => 'products.view',
        2 => 'products.create',
        3 => 'products.edit',
        4 => 'products.export',
        5 => 'inventory.view',
        6 => 'inventory.create',
        7 => 'inventory.edit',
        8 => 'inventory.print',
        9 => 'inventory.export',
        10 => 'invoices.view',
        11 => 'reports.view',
        12 => 'reports.export',
        13 => 'printing.view',
        14 => 'printing.print',
        15 => 'petty_cash.view',
        16 => 'petty_cash.create',
      ),
    ),
    3 => 
    array (
      'name' => 'فروشنده',
      'slug' => 'sales',
      'description' => 'فاکتور فروش، مشتریان و پیش‌فاکتور',
      'is_system' => 1,
      'permissions' => 
      array (
        0 => 'dashboard.view',
        1 => 'persons.view',
        2 => 'persons.create',
        3 => 'persons.edit',
        4 => 'products.view',
        5 => 'inventory.view',
        6 => 'invoices.view',
        7 => 'invoices.create',
        8 => 'invoices.edit',
        9 => 'invoices.print',
        10 => 'receipts.view',
        11 => 'receipts.create',
        12 => 'reports.view',
        13 => 'petty_cash.view',
        14 => 'petty_cash.create',
      ),
    ),
  ),
  'meta' => 
  array (
    'source_business_id' => 1,
    'exported_at' => '2026-09-28T23:48:19+00:00',
    'accounts' => 61,
    'rules' => 32,
    'settings' => 56,
    'permissions_total' => 234,
    'patched_at' => '2026-09-30T22:57:36+00:00',
  ),
);
