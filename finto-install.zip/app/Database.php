<?php
/** لایه دسترسی به داده — PDO با پشتیبانی MySQL و MariaDB */
final class Database
{
    private static ?PDO $pdo = null;
    private static int $txSeq = 1;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) return self::$pdo;
        $c = config('db');
        if (($env = getenv('FINTO_DB_NAME')) !== false && $env !== '') $c['name'] = $env; // برای آزمون روی دیتابیس آزمایشی
        $dsn = $c['socket']
            ? "mysql:unix_socket={$c['socket']};dbname={$c['name']};charset={$c['charset']}"
            : "mysql:host={$c['host']};port={$c['port']};dbname={$c['name']};charset={$c['charset']}";
        try {
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                // sql_mode تنظیم می‌شود تا رفتار MySQL 8 (که ONLY_FULL_GROUP_BY را پیش‌فرض فعال دارد)
                // با MariaDB و سرورهای cPanel یکسان باشد.
                (defined('Pdo\\Mysql::ATTR_INIT_COMMAND') ? \Pdo\Mysql::ATTR_INIT_COMMAND : PDO::MYSQL_ATTR_INIT_COMMAND) => "SET time_zone='+03:30', NAMES utf8mb4, SESSION sql_mode='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'",
            ]);
        } catch (PDOException $e) {
            // اگر نرم‌افزار هنوز نصب نشده باشد (فایل config.local.php ساخته نشده)، کاربر را به نصب‌کننده راهنمایی کن
            if (!is_file(__DIR__.'/../config.local.php') && is_file(__DIR__.'/../install.php')) {
                self::notInstalledPage();
            }
            if (config('app')['debug']) throw new RuntimeException('اتصال به دیتابیس ممکن نشد: '.$e->getMessage());
            throw new RuntimeException('اتصال به دیتابیس ممکن نشد.');
        }
        return self::$pdo;
    }

    /** صفحه راهنمای «نصب نشده» — پیش از اجرای نصب‌کننده */
    private static function notInstalledPage(): void
    {
        $base = rtrim(dirname((string)($_SERVER['SCRIPT_NAME'] ?? '/index.php')), '/\\');
        $link = ($base === '' || $base === '/' ? '' : $base).'/install.php';
        if (!headers_sent()) http_response_code(503);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!DOCTYPE html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<title>راه‌اندازی نرم‌افزار حسابداری فینتو</title><style>'
            . 'body{margin:0;background:linear-gradient(160deg,#f7f5fc,#efeaf9);font-family:Vazirmatn,Tahoma,system-ui,sans-serif;color:#241b3a;'
            . 'display:grid;place-items:center;min-height:100vh;padding:20px}'
            . '.c{background:#fff;border:1px solid #e6e1f2;border-radius:20px;padding:30px;max-width:520px;text-align:center;box-shadow:0 14px 40px rgba(36,27,58,.1)}'
            . 'i{display:grid;place-items:center;width:64px;height:64px;margin:0 auto 14px;border-radius:20px;font-size:28px;font-style:normal;color:#fff;'
            . 'background:linear-gradient(135deg,#6d28d9,#8b5cf6)}'
            . 'h1{font-size:20px;margin:0 0 8px}p{color:#6b6480;font-size:14px;line-height:2;margin:6px 0}'
            . 'a{display:inline-block;margin-top:16px;background:linear-gradient(135deg,#6d28d9,#8b5cf6);color:#fff;text-decoration:none;'
            . 'border-radius:13px;padding:12px 26px;font-weight:700;box-shadow:0 8px 20px rgba(109,40,217,.25)}'
            . 'code{background:#f4f1fb;border-radius:8px;padding:2px 7px;direction:ltr;display:inline-block;font-size:12.5px}'
            . '</style></head><body><div class="c"><i>ف</i>'
            . '<h1>نرم‌افزار هنوز نصب نشده است</h1>'
            . '<p>برای راه‌اندازی، نصب‌کننده وبی را اجرا کنید: مشخصات دیتابیس را وارد کنید تا جدول‌ها، داده‌ها و فایل تنظیمات ساخته شوند.</p>'
            . '<a href="'.htmlspecialchars($link, ENT_QUOTES).'">اجرای نصب‌کننده</a>'
            . '<p style="margin-top:18px;font-size:12.5px">اگر نصب انجام شده است، مقدارهای فایل <code>config.local.php</code> را بررسی کنید.</p>'
            . '</div></body></html>';
        exit;
    }

    /** اجرای پرس‌وجو با پارامتر */
    public static function run(string $sql, array $params = []): PDOStatement
    {
        $st = self::pdo()->prepare($sql);
        foreach ($params as $k => $v) {
            $key = is_int($k) ? $k + 1 : ':'.$k;
            if (is_bool($v)) $v = $v ? 1 : 0;
            $type = is_int($v) ? PDO::PARAM_INT : PDO::PARAM_STR;
            $st->bindValue($key, $v, $type);
        }
        $st->execute();
        return $st;
    }

    public static function all(string $sql, array $p = []): array { return self::run($sql, $p)->fetchAll(); }
    public static function one(string $sql, array $p = []): ?array { $r = self::run($sql, $p)->fetch(); return $r === false ? null : $r; }
    public static function val(string $sql, array $p = [], $default = null) { $v = self::run($sql, $p)->fetchColumn(); return $v === false ? $default : $v; }
    public static function insert(string $table, array $row): int
    {
        $cols = array_keys($row);
        $sql = 'INSERT INTO `'.$table.'` ('.implode(',', array_map(fn($c) => "`$c`", $cols)).') VALUES ('
             . implode(',', array_map(fn($c) => ':'.$c, $cols)).')';
        self::run($sql, $row);
        return (int) self::pdo()->lastInsertId();
    }
    public static function update(string $table, array $row, string $where, array $wp = []): int
    {
        $set = implode(',', array_map(fn($c) => "`$c`=:$c", array_keys($row)));
        return self::run("UPDATE `$table` SET $set WHERE $where", $row + $wp)->rowCount();
    }
    /** اجرای یک بلوک در تراکنش؛ در صورت تودرتو بودن از SAVEPOINT استفاده می‌شود */
    public static function transaction(callable $fn)
    {
        $pdo = self::pdo();
        if ($pdo->inTransaction()) {
            $sp = 'finto_sp_'.(self::$txSeq++);
            $pdo->exec('SAVEPOINT '.$sp);
            try {
                $r = $fn();
                $pdo->exec('RELEASE SAVEPOINT '.$sp);
                return $r;
            } catch (Throwable $e) {
                try { $pdo->exec('ROLLBACK TO SAVEPOINT '.$sp); } catch (Throwable $ignored) { }
                throw $e;
            }
        }
        $pdo->beginTransaction();
        try {
            $r = $fn();
            $pdo->commit();
            return $r;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}
