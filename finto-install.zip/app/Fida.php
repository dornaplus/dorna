<?php
/**
 * اپ فاکتورزنی فیدا — کمک‌تابع‌های مشترک
 *  • migrate()       : ارتقای ساختار برای چندکاربره‌شدن (ستون user_id) — ایدمپوتنت
 *  • ensureProfile() : ساخت/بازگرداندن پروفایل اختصاصی یک کاربر
 *  • uid()/settings(): کاربر جاری و تنظیمات او
 */
final class Fida
{
    /** ستون‌هایی که در نسخه‌های بعدی اضافه شده‌اند (مهاجرت ایدمپوتنت) */
    private const EXTRA_COLUMNS = [
        'fida_invoices' => [
            'tax_mode'    => "ENUM('percent','amount') NULL COMMENT 'نوع مالیات' AFTER `ship_amount`",
            'tax_percent' => "DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'درصد مالیات' AFTER `tax_mode`",
            'tax_amount'  => "BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ مالیات' AFTER `tax_percent`",
        ],
        'fida_settings' => [
            'show_tax'    => "TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش ردیف مالیات' AFTER `show_ship`",
            'tax_percent' => "DECIMAL(5,2) NOT NULL DEFAULT 9 COMMENT 'درصد مالیات پیش‌فرض' AFTER `show_tax`",
            'show_bank_info' => "TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش اطلاعات حساب بانکی در چاپ و PDF' AFTER `show_types`",
        ],
        'fida_subscriptions' => [
            'discount_code'   => "VARCHAR(40) NULL COMMENT 'کد تخفیف استفاده‌شده' AFTER `source`",
            'discount_amount' => "BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ تخفیف (تومان)' AFTER `discount_code`",
            'paid_amount'     => "BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ پرداختی پس از تخفیف' AFTER `discount_amount`",
        ],
        'fida_notice_reads' => [
            'dismissed_at' => "DATETIME NULL COMMENT 'زمان حذف/بستن اعلان توسط همین کاربر' AFTER `read_at`",
        ],
    ];

    /** جدول‌های دارای user_id و کلید یگانه‌ی ترکیبی متناظر (نام کلید => ستون‌ها) */
    private const USER_TABLES = [
        'fida_persons'                 => ['uq_persons_phone' => 'user_id, phone'],
        'fida_items'                   => [],
        'fida_invoices'                => ['uq_invoices_code' => 'user_id, invoice_type, invoice_year, seq'],
        'fida_invoice_items'           => [],
        'fida_payments'                => ['uq_payments_ref' => 'user_id, reference_code'],
        'fida_invoice_status_history'  => [],
        'fida_invoice_templates'       => [],
        'fida_template_items'          => [],
        'fida_settings'                => ['uq_settings_user' => 'user_id'],
        'fida_subscriptions'           => [],
        'fida_invite_codes'            => [],
        'fida_monthly_metrics'         => ['uq_metrics_ym' => 'user_id, year, month'],
        'fida_units'                   => ['uq_units_user_title' => 'user_id, title'],
        'fida_bank_accounts'           => [],
    ];

    /** پالت رنگ سازمانی: [رنگ اصلی، زمینهٔ ملایم، رنگ متن، رنگ حاشیه] */
    public const ACCENTS = [
        'purple' => ['#6D28D9', '#F1ECFE', '#3B1D78', '#D9CFF7'],
        'blue'   => ['#1D4ED8', '#E8EFFE', '#1E3A8A', '#C2D4FC'],
        'green'  => ['#047857', '#E6F6EF', '#064E3B', '#B9E4D2'],
        'red'    => ['#BE123C', '#FDECEF', '#881337', '#F6C9D3'],
    ];

    /** یک رنگ از پالت (۰ اصلی · ۱ ملایم · ۲ متن · ۳ حاشیه) */
    public static function accent(?string $key, int $i = 0): string
    {
        $k = (string)$key;
        if (!isset(self::ACCENTS[$k])) $k = 'purple';
        return self::ACCENTS[$k][$i] ?? self::ACCENTS['purple'][$i];
    }

    /* ─────────────── آپلود تصویر (لوگو / مهر / امضا) ─────────────── */

    /** مسیر پوشهٔ public پروژه */
    public static function publicDir(): string { return dirname(__DIR__) . '/public'; }

    /** پوشهٔ آپلودهای فیدا (نسبت به public) */
    public const UPLOAD_BASE = 'uploads/fida';

    /**
     * ذخیرهٔ تصویر آپلودی.
     * @return array{ok:bool,path:?string,error:?string,empty:bool}
     */
    public static function saveUpload(string $field, int $uid, string $kind): array
    {
        $out = ['ok' => false, 'path' => null, 'error' => null, 'empty' => true];
        if ($uid <= 0) { $out['error'] = 'کاربر نامعتبر.'; return $out; }
        if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return $out;
        $f = $_FILES[$field];
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) return $out;                 // فایلی انتخاب نشده
        $out['empty'] = false;
        if ($err !== UPLOAD_ERR_OK) { $out['error'] = 'آپلود تصویر ناموفق بود (کد ' . $err . ').'; return $out; }
        if ((int)$f['size'] > 3 * 1024 * 1024) { $out['error'] = 'حجم تصویر باید کمتر از ۳ مگابایت باشد.'; return $out; }
        if (!is_uploaded_file((string)$f['tmp_name'])) { $out['error'] = 'فایل نامعتبر است.'; return $out; }

        $info = @getimagesize((string)$f['tmp_name']);
        $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $type = is_array($info) ? (int)$info[2] : 0;
        if (!isset($allowed[$type])) { $out['error'] = 'فقط تصویر JPG، PNG، WEBP یا GIF مجاز است.'; return $out; }

        $rel = self::UPLOAD_BASE . '/' . $uid;
        $dir = self::publicDir() . '/' . $rel;
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) { $out['error'] = 'ساخت پوشهٔ آپلود ممکن نشد.'; return $out; }

        $name = $kind . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$type];
        if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $name)) { $out['error'] = 'ذخیرهٔ تصویر ممکن نشد.'; return $out; }
        @chmod($dir . '/' . $name, 0644);
        $out['ok'] = true;
        $out['path'] = $rel . '/' . $name;      // مسیر نسبی به public
        return $out;
    }

    /** حذف فایل آپلودشده (فقط داخل پوشهٔ آپلود فیدا) */
    public static function removeUpload(?string $relPath): void
    {
        $p = trim((string)$relPath);
        if ($p === '' || !str_starts_with($p, self::UPLOAD_BASE . '/')) return;
        if (str_contains($p, '..')) return;
        $abs = self::publicDir() . '/' . $p;
        if (is_file($abs)) @unlink($abs);
    }

    /** آدرس وب یک تصویر آپلودی (یا خالی) */
    public static function imageUrl(?string $relPath): string
    {
        $p = trim((string)$relPath);
        if ($p === '' || !str_starts_with($p, self::UPLOAD_BASE . '/') || str_contains($p, '..')) return '';
        return url($p);
    }

    /** واحدهای پیش‌فرض شمارش */
    public const DEFAULT_UNITS = ['عدد','بسته','دستگاه','کیلوگرم','گرم','متر','متر مربع','لیتر','ساعت','روز','نفر','کارتن','جعبه','سری','قلم','خدمات'];


    /* ───────────────────────── کاربر جاری ───────────────────────── */

    public static function uid(): int
    {
        return (int)(Auth::id() ?? 0);
    }

    /** تنظیمات کاربر جاری (در صورت نبود، ساخته می‌شود) */
    public static function settings(): array
    {
        return self::ensureProfile(self::uid());
    }

    /** پروفایل اختصاصی کاربر را می‌سازد (اگر نبود) و برمی‌گرداند */
    public static function ensureProfile(int $uid, ?string $name = null): array
    {
        $row = $uid > 0 ? Database::one('SELECT * FROM fida_settings WHERE user_id=?', [$uid]) : null;
        if ($row) return $row;
        if ($uid <= 0) return [];

        if ($name === null) {
            $u = Database::one('SELECT full_name FROM users WHERE id=?', [$uid]);
            $name = (string)($u['full_name'] ?? '');
        }
        $name = trim((string)$name);
        if ($name === '') $name = 'کاربر فیدا';

        Database::insert('fida_settings', [
            'user_id'        => $uid,
            'owner_name'     => mb_substr($name, 0, 80),
            'shop_name'      => 'فروشگاه من',
            'accent_color'   => 'purple',
            'currency'       => 'toman',
            'discount_mode'  => 'percent',
            'printer_status' => 'none',
        ]);
        self::seedUnits($uid);
        return Database::one('SELECT * FROM fida_settings WHERE user_id=?', [$uid]) ?: [];
    }

    /* ───────────────────────── تقویم شخصی ───────────────────────── */

    /** انواع رویداد و برچسب فارسی */
    public const EVENT_KINDS = ['reminder' => 'یادآوری', 'meeting' => 'جلسه', 'call' => 'تماس',
        'payment' => 'پرداخت/دریافت', 'delivery' => 'تحویل کالا', 'task' => 'کار روزانه', 'other' => 'سایر'];
    public const EVENT_KINDS_ICON = ['reminder' => '⏰', 'meeting' => '🤝', 'call' => '📞',
        'payment' => '💳', 'delivery' => '📦', 'task' => '✅', 'other' => '📌'];

    public const JALALI_MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
        'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    public const WEEKDAYS = ['شنبه', 'یک‌شنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'];

    /** طول ماه شمسی */
    public static function jalaliMonthDays(int $jy, int $jm): int
    {
        if ($jm <= 6) return 31;
        if ($jm <= 11) return 30;
        [$ny, $nm] = $jm === 12 ? [$jy + 1, 1] : [$jy, $jm + 1];
        $start = strtotime((string)to_gregorian($jy . '/' . $jm . '/1'));
        $next = strtotime((string)to_gregorian($ny . '/' . $nm . '/1'));
        return (int)round(($next - $start) / 86400);
    }

    /** شمارهٔ روز هفته (۰=شنبه … ۶=جمعه) */
    public static function weekdayIndex(string $gregorian): int
    {
        $w = (int)date('w', strtotime($gregorian));   // 0=Sunday
        return ($w + 1) % 7;                          // Saturday=0
    }

    /**
     * شبکهٔ ماه شمسی برای تقویم: [{date, jy, jm, jd, inMonth, isToday, isHoliday, events[]}]
     */
    public static function calendarGrid(int $jy, int $jm, int $uid): array
    {
        $days = self::jalaliMonthDays($jy, $jm);
        $first = (string)to_gregorian($jy . '/' . $jm . '/1');
        $lead = self::weekdayIndex($first);           // روزهای خالی ابتدای ماه
        $start = date('Y-m-d', strtotime($first . ' -' . $lead . ' days'));
        $events = self::eventsBetween($uid, $start, date('Y-m-d', strtotime($start . ' +41 days')));
        $byDate = [];
        foreach ($events as $e) $byDate[(string)$e['event_date']][] = $e;

        $grid = [];
        for ($i = 0; $i < 42; $i++) {
            $date = date('Y-m-d', strtotime($start . ' +' . $i . ' days'));
            [$yy, $mm, $dd] = gregorian_to_jalali((int)date('Y', strtotime($date)), (int)date('n', strtotime($date)), (int)date('j', strtotime($date)));
            $grid[] = ['date' => $date, 'jy' => (int)$yy, 'jm' => (int)$mm, 'jd' => (int)$dd,
                'in_month' => ((int)$mm === $jm && (int)$yy === $jy), 'is_today' => $date === today(),
                'is_holiday' => self::weekdayIndex($date) === 6,
                'events' => $byDate[$date] ?? []];
        }
        return $grid;
    }

    /** رویدادهای کاربر در یک بازه */
    public static function eventsBetween(int $uid, string $from, string $to): array
    {
        if ($uid <= 0) return [];
        return self::decorateEvents(Database::all('SELECT * FROM fida_events WHERE user_id=? AND event_date BETWEEN ? AND ?
                                ORDER BY event_date, event_time IS NULL, event_time, id', [$uid, $from, $to]));
    }

    /** افزودن تاریخ شمسی (لاتین برای فرم/لینک + فارسی برای نمایش) به هر رویداد */
    public static function decorateEvents(array $rows): array
    {
        foreach ($rows as &$r) {
            if (empty($r['event_date'])) continue;
            [$jy, $jm, $jd] = gregorian_to_jalali((int)date('Y', strtotime((string)$r['event_date'])),
                (int)date('n', strtotime((string)$r['event_date'])), (int)date('j', strtotime((string)$r['event_date'])));
            $r['jalali_date'] = $jy . '/' . $jm . '/' . $jd;
            $r['jalali_label'] = jdate((string)$r['event_date']);
            $r['days_left'] = (int)floor((strtotime((string)$r['event_date']) - strtotime(today())) / 86400);
        }
        unset($r);
        return $rows;
    }

    /** رویدادهای یک روز */
    public static function eventsOn(int $uid, string $date): array
    {
        return self::eventsBetween($uid, $date, $date);
    }

    /** رویدادهای پیش‌رو (برای فهرست کنار تقویم) */
    public static function upcomingEvents(int $uid, int $limit = 8, int $days = 60): array
    {
        if ($uid <= 0) return [];
        return self::decorateEvents(Database::all("SELECT * FROM fida_events WHERE user_id=? AND event_date >= CURDATE() AND event_date <= DATE_ADD(CURDATE(), INTERVAL ? DAY)
                               ORDER BY event_date, event_time IS NULL, event_time, id LIMIT " . max(1, min(50, $limit)), [$uid, $days]));
    }

    /** ذخیره/ویرایش رویداد (فقط برای صاحب آن) */
    public static function saveEvent(int $uid, array $d, ?int $id = null): int
    {
        $title = mb_substr(trim((string)($d['title'] ?? '')), 0, 150);
        if (mb_strlen($title) < 2) throw new RuntimeException('عنوان رویداد را وارد کنید.');
        $date = (string)($d['event_date'] ?? '');
        if ($date === '' || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) throw new RuntimeException('تاریخ رویداد را انتخاب کنید.');
        $kind = array_key_exists((string)($d['kind'] ?? ''), self::EVENT_KINDS) ? (string)$d['kind'] : 'reminder';
        $prio = (string)($d['priority'] ?? 'normal') === 'high' ? 'high' : 'normal';
        $time = en_digits(trim((string)($d['event_time'] ?? '')));   // ارقام فارسی → لاتین
        $time = preg_match('/^(\d{1,2}):(\d{2})/', $time, $tm) ? sprintf('%02d:%02d', (int)$tm[1], (int)$tm[2]) : null;
        $row = ['title' => $title, 'event_date' => $date, 'event_time' => $time, 'kind' => $kind, 'priority' => $prio,
            'note' => ($n = mb_substr(trim((string)($d['note'] ?? '')), 0, 500)) !== '' ? $n : null,
            'notify_days' => max(0, min(30, (int)($d['notify_days'] ?? 0))),
            'is_done' => !empty($d['is_done']) ? 1 : 0];
        if ($id && Database::val('SELECT id FROM fida_events WHERE id=? AND user_id=?', [$id, $uid])) {
            $row['updated_at'] = now();
            Database::update('fida_events', $row, 'id=:pk AND user_id=:uid', ['pk' => $id, 'uid' => $uid]);
            return $id;
        }
        $row['user_id'] = $uid; $row['created_at'] = now();
        return (int)Database::insert('fida_events', $row);
    }

    public static function event(int $uid, int $id): ?array
    {
        return $uid > 0 ? Database::one('SELECT * FROM fida_events WHERE id=? AND user_id=?', [$id, $uid]) : null;
    }

    public static function deleteEvent(int $uid, int $id): bool
    {
        if (!self::event($uid, $id)) return false;
        Database::run('DELETE FROM fida_events WHERE id=? AND user_id=?', [$id, $uid]);
        return true;
    }

    public static function toggleEvent(int $uid, int $id): bool
    {
        $e = self::event($uid, $id);
        if (!$e) return false;
        Database::run('UPDATE fida_events SET is_done=?, updated_at=NOW() WHERE id=? AND user_id=?',
            [!empty($e['is_done']) ? 0 : 1, $id, $uid]);
        return true;
    }

    /** برچسب تاریخ شمسی رویداد */
    public static function eventDateLabel(string $date): string
    {
        return jdate($date);
    }

    /* ───────────────────────── سهم رایگان و وضعیت اشتراک ───────────────────────── */

    /** تعداد فاکتور رایگان هر کاربر پیش از نیاز به اشتراک */
    public const FREE_INVOICE_LIMIT = 5;

    /** اشتراک فعال کاربر (اگر داشته باشد) */
    public static function activeSubscription(int $uid): ?array
    {
        if ($uid <= 0) return null;
        return Database::one("SELECT s.*, p.title AS plan_title, p.duration_months FROM fida_subscriptions s
                               LEFT JOIN fida_gold_plans p ON p.id = s.plan_id
                              WHERE s.user_id = ? AND s.status = 'active' AND s.expires_at >= CURDATE()
                              ORDER BY s.expires_at DESC, s.id DESC LIMIT 1", [$uid]);
    }

    /** تعداد فاکتورهای ثبت‌شدهٔ کاربر (همهٔ انواع) */
    public static function usedInvoices(int $uid): int
    {
        return (int)Database::val('SELECT COUNT(*) FROM fida_invoices WHERE user_id=?', [$uid], 0);
    }

    /**
     * وضعیت دسترسی کاربر به ثبت فاکتور:
     *   • کاربران طلایی: نامحدود
     *   • رایگان: ۵ فاکتور (FREE_INVOICE_LIMIT) — پس از آن باید اشتراک بخرند
     */
    public static function accessState(int $uid): array
    {
        $sub = self::activeSubscription($uid);
        $used = self::usedInvoices($uid);
        $limit = self::FREE_INVOICE_LIMIT;
        $remaining = max(0, $limit - $used);
        $everSubscribed = $uid > 0 && (int)Database::val('SELECT COUNT(*) FROM fida_subscriptions WHERE user_id=?', [$uid], 0) > 0;
        $isGold = $sub !== null;
        $blocked = !$isGold && $remaining <= 0;                    // سهم رایگان تمام شده و اشتراکی نیست
        $reason = '';                                             // دلیل نمایش پیام
        if (!$isGold) {
            if ($everSubscribed && $used > 0) $reason = 'expired';  // اشتراکش تمام شده است
            elseif ($remaining <= 0) $reason = 'quota';             // سهم رایگان تمام شده
        }
        return ['is_gold' => $isGold, 'subscription' => $sub, 'used' => $used, 'limit' => $limit,
            'remaining' => $remaining, 'ever_subscribed' => $everSubscribed, 'blocked' => $blocked,
            'reason' => $reason, 'show_popup' => (!$isGold && ($reason === 'expired' || $remaining <= 0))];
    }

    /** پیام‌های پیشنهاد اشتراک (برای پاپ‌آپ) */
    public static function upgradeMessages(array $st): array
    {
        if (($st['reason'] ?? '') === 'expired') {
            $title = 'اشتراک طلایی شما به پایان رسید';
            $sub = 'دورهٔ اشتراکت تموم شد — برای ادامهٔ کار و ثبت فاکتور جدید، اشتراکت رو تازه کن.';
        } elseif (($st['reason'] ?? '') === 'quota') {
            $title = 'سهم رایگان شما (' . num((int)$st['limit']) . ' فاکتور) به پایان رسید';
            $sub = 'تا اینجا رایگان استفاده کردی؛ برای ثبت فاکتورهای بعدی اشتراک طلایی رو فعال کن.';
        } else {
            $title = 'نسخهٔ رایگان فیدا';
            $sub = 'با ' . num((int)$st['limit']) . ' فاکتور رایگان شروع کن؛ هر وقت خواستی ارتقا بده.';
        }
        return ['title' => $title, 'sub' => $sub];
    }

    /** واحد پول کاربر (تومان/ریال) — از تنظیمات */
    public static function unit(?array $s = null): string
    {
        $s = $s ?: self::settings();
        return (($s['currency'] ?? 'toman') === 'rial') ? 'ریال' : 'تومان';
    }

    /** حالت تخفیف (درصدی/مبلغی) */
    public static function discountMode(?array $s = null): string
    {
        $s = $s ?: self::settings();
        return (($s['discount_mode'] ?? 'percent') === 'amount') ? 'amount' : 'percent';
    }

    /* ─────────────── حساب‌های بانکی (چند حساب، یکی پیش‌فرض) ─────────────── */

    /** حذف فاصله/خط تیره و یکسان‌سازی ارقام (ذخیره همیشه با ارقام لاتین) */
    private static function digits(?string $v, int $max): ?string
    {
        $v = strtr((string)$v, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                                '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $v = preg_replace('/[^0-9A-Za-z]/', '', $v);
        return $v === '' ? null : mb_substr($v, 0, $max);
    }

    /** همهٔ حساب‌های بانکی کاربر (پیش‌فرض اول) */
    public static function bankAccounts(?int $uid = null): array
    {
        $uid = $uid ?? self::uid();
        if ($uid <= 0) return [];
        return Database::all('SELECT * FROM fida_bank_accounts WHERE user_id=? AND is_active=1
                               ORDER BY is_default DESC, sort_order, id', [$uid]);
    }

    /** حساب پیش‌فرض کاربر (اگر هیچ حسابی پیش‌فرض نبود، اولین حساب) */
    public static function defaultBank(?int $uid = null): ?array
    {
        $list = self::bankAccounts($uid);
        if (!$list) return null;
        foreach ($list as $b) if ((int)$b['is_default'] === 1) return $b;
        return $list[0];
    }

    public static function bankAccount(int $id, ?int $uid = null): ?array
    {
        $uid = $uid ?? self::uid();
        return $id > 0 && $uid > 0
            ? Database::one('SELECT * FROM fida_bank_accounts WHERE id=? AND user_id=?', [$id, $uid])
            : null;
    }

    /** افزودن/ویرایش حساب بانکی (اولین حساب خودکار پیش‌فرض می‌شود) */
    public static function saveBankAccount(array $d, ?int $uid = null): int
    {
        $uid = $uid ?? self::uid();
        $bank = mb_substr(trim((string)($d['bank_name'] ?? '')), 0, 80);
        $holder = mb_substr(trim((string)($d['account_holder'] ?? '')), 0, 120);
        if ($bank === '' || $holder === '') throw new RuntimeException('نام بانک و نام صاحب حساب الزامی است.');
        $row = [
            'bank_name'      => $bank,
            'account_holder' => $holder,
            'card_no'        => self::digits($d['card_no'] ?? null, 32),
            'iban'           => self::digits($d['iban'] ?? null, 40),
            'account_no'     => self::digits($d['account_no'] ?? null, 40),
            'sort_order'     => (int)($d['sort_order'] ?? 0),
            'is_active'      => 1,
        ];
        $id = (int)($d['id'] ?? 0);
        if ($id > 0) {
            if (!self::bankAccount($id, $uid)) throw new RuntimeException('حساب بانکی یافت نشد.');
            Database::update('fida_bank_accounts', $row, 'id=:id AND user_id=:uid', ['id' => $id, 'uid' => $uid]);
        } else {
            $row['user_id'] = $uid;
            $row['is_default'] = 0;
            $id = (int)Database::insert('fida_bank_accounts', $row);
        }
        // اگر کاربر هیچ حساب پیش‌فرضی ندارد، همین حساب پیش‌فرض شود
        $hasDefault = (int)Database::val('SELECT COUNT(*) FROM fida_bank_accounts WHERE user_id=? AND is_default=1', [$uid], 0);
        if (!$hasDefault) self::setDefaultBank($id, $uid);
        return $id;
    }

    /** تعیین حساب پیش‌فرض */
    public static function setDefaultBank(int $id, ?int $uid = null): bool
    {
        $uid = $uid ?? self::uid();
        if (!self::bankAccount($id, $uid)) return false;
        Database::run('UPDATE fida_bank_accounts SET is_default=0 WHERE user_id=?', [$uid]);
        Database::run('UPDATE fida_bank_accounts SET is_default=1 WHERE id=? AND user_id=?', [$id, $uid]);
        return true;
    }

    /** حذف حساب بانکی (اگر پیش‌فرض بود، حساب بعدی پیش‌فرض می‌شود) */
    public static function deleteBankAccount(int $id, ?int $uid = null): bool
    {
        $uid = $uid ?? self::uid();
        $b = self::bankAccount($id, $uid);
        if (!$b) return false;
        Database::run('DELETE FROM fida_bank_accounts WHERE id=? AND user_id=?', [$id, $uid]);
        if ((int)$b['is_default'] === 1) {
            $next = (int)Database::val('SELECT id FROM fida_bank_accounts WHERE user_id=? AND is_active=1 ORDER BY sort_order, id LIMIT 1', [$uid], 0);
            if ($next) self::setDefaultBank($next, $uid);
        }
        return true;
    }

    /** نمایش چهار رقم آخر کارت/شبا برای نمایش فهرست */
    public static function maskTail(?string $v, int $keep = 4): string
    {
        $v = (string)$v;
        if ($v === '') return '';
        if (mb_strlen($v) <= $keep) return $v;
        return str_repeat('•', max(0, mb_strlen($v) - $keep)) . mb_substr($v, -$keep);
    }

    /** گروه‌بندی چهارتایی برای نمایش شماره کارت/شبا */
    public static function groupDigits(?string $v): string
    {
        $v = (string)$v;
        return $v === '' ? '' : trim(chunk_split($v, 4, ' '));
    }

    /** واحدهای کاربر (با seed اولیه در صورت خالی بودن) */
    public static function units(int $uid): array
    {
        if ($uid <= 0) return self::DEFAULT_UNITS;
        if ((int)Database::val('SELECT COUNT(*) FROM fida_units WHERE user_id=?', [$uid], 0) === 0) self::seedUnits($uid);
        $out = [];
        foreach (Database::all('SELECT title FROM fida_units WHERE user_id=? ORDER BY id', [$uid]) as $r) $out[] = (string)$r['title'];
        return $out ?: self::DEFAULT_UNITS;
    }

    /** افزودن واحد (ایدیپوتنت) و برگرداندن عنوان نهایی */
    public static function addUnit(int $uid, string $title): ?string
    {
        if ($uid <= 0) return null;
        $t = trim(preg_replace('/\s+/u', ' ', $title));
        if ($t === '') return null;
        $t = mb_substr($t, 0, 30);
        try { Database::run('INSERT IGNORE INTO fida_units (user_id, title) VALUES (?, ?)', [$uid, $t]); }
        catch (Throwable $e) { return null; }
        return $t;
    }

    /** درج واحدهای پیش‌فرض برای کاربر (فقط اگر هیچ واحدی نداشته باشد) */
    public static function seedUnits(int $uid): void
    {
        if ($uid <= 0) return;
        try {
            if ((int)Database::val('SELECT COUNT(*) FROM fida_units WHERE user_id=?', [$uid], 0) > 0) return;
            foreach (self::DEFAULT_UNITS as $t) {
                Database::run('INSERT IGNORE INTO fida_units (user_id, title) VALUES (?, ?)', [$uid, $t]);
            }
        } catch (Throwable $e) { /* جدول هنوز ساخته نشده */ }
    }

    /* ───────────────────────── مهاجرت ساختار ───────────────────────── */

    /**
     * ساختار فیدا را برای چندکاربره‌بودن آماده می‌کند:
     *  ۱) افزودن ستون user_id به جدول‌های کاربری (اگر نبود)
     *  ۲) تبدیل کلیدهای یگانه به ترکیبی با user_id
     *  ۳) نسبت‌دادن دادهٔ قدیمی/نمونه به کاربر مالک نمونه
     *  ۴) بازسازی ویوها (db/fida.sql)
     * برای نصب تازه بی‌اثر است.
     */
    public static function migrate(PDO $pdo, ?string $ownerSql = null): array
    {
        $notes = [];
        $db = $pdo->query('SELECT DATABASE()')->fetchColumn();

        $tableExists = function (string $t) use ($pdo, $db): bool {
            $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=? AND TABLE_NAME=?');
            $q->execute([$db, $t]);
            return (int)$q->fetchColumn() > 0;
        };
        $colsOf = function (string $t) use ($pdo, $db): array {
            $q = $pdo->prepare('SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=? AND TABLE_NAME=?');
            $q->execute([$db, $t]);
            return array_map('strval', $q->fetchAll(PDO::FETCH_COLUMN));
        };
        $indexCols = function (string $t, string $ix) use ($pdo, $db): array {
            $q = $pdo->prepare('SELECT COLUMN_NAME FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=? AND TABLE_NAME=? AND INDEX_NAME=? ORDER BY SEQ_IN_INDEX');
            $q->execute([$db, $t, $ix]);
            return array_map('strval', $q->fetchAll(PDO::FETCH_COLUMN));
        };

        // ── ۱) ستون user_id
        foreach (array_keys(self::USER_TABLES) as $t) {
            if (!$tableExists($t)) continue;
            $cols = $colsOf($t);
            if (!in_array('user_id', $cols, true)) {
                try {
                    $pdo->exec("ALTER TABLE `$t` ADD COLUMN `user_id` INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'کاربر مالک (پروفایل اختصاصی)' FIRST");
                    $pdo->exec("ALTER TABLE `$t` ADD INDEX `idx_" . preg_replace('/^fida_/', '', $t) . "_user` (`user_id`)");
                    $notes[] = "ستون user_id به $t";
                } catch (Throwable $e) { /* رد شود */ }
            }
        }

        // ── ۱.۵) ستون‌های افزوده‌شده در نسخه‌های بعدی (مالیات و …)
        foreach (self::EXTRA_COLUMNS as $t => $cols) {
            if (!$tableExists($t)) continue;
            $have = $colsOf($t);
            foreach ($cols as $col => $ddl) {
                if (in_array($col, $have, true)) continue;
                try { $pdo->exec("ALTER TABLE `$t` ADD COLUMN `$col` $ddl"); $notes[] = "ستون $col به $t"; } catch (Throwable $e) { /* رد شود */ }
            }
        }

        // ── ۲) نسبت‌دادن دادهٔ قدیمی به مالک نمونه
        $owner = 0;
        try {
            $owner = (int)$pdo->query("SELECT id FROM users WHERE mobile='09120000001' AND deleted_at IS NULL LIMIT 1")->fetchColumn();
            if (!$owner) $owner = (int)$pdo->query('SELECT MIN(id) FROM users WHERE deleted_at IS NULL')->fetchColumn();
        } catch (Throwable $e) { $owner = 0; }
        if ($owner > 0) {
            foreach (array_keys(self::USER_TABLES) as $t) {
                if (!$tableExists($t) || !in_array('user_id', $colsOf($t), true)) continue;
                try {
                    $n = $pdo->exec("UPDATE `$t` SET `user_id` = " . (int)$owner . " WHERE `user_id` = 0");
                    if ($n > 0) $notes[] = "انتقال $n ردیف $t به پروفایل کاربر #$owner";
                } catch (Throwable $e) { /* رد شود */ }
            }
        }

        // ── ۳) کلیدهای یگانه‌ی ترکیبی
        foreach (self::USER_TABLES as $t => $keys) {
            foreach ($keys as $ixName => $want) {
                if (!$tableExists($t)) continue;
                $wantCols = preg_split('/\s*,\s*/', trim($want));
                $have = $indexCols($t, $ixName);
                $ok = $have && $have === $wantCols;
                if ($ok) continue;
                try {
                    if ($have) { $pdo->exec("ALTER TABLE `$t` DROP INDEX `$ixName`"); }
                    $pdo->exec("ALTER TABLE `$t` ADD UNIQUE KEY `$ixName` (" . implode(', ', array_map(fn($c) => "`$c`", $wantCols)) . ")");
                    $notes[] = "کلید یگانه $ixName در $t";
                } catch (Throwable $e) { /* رد شود */ }
            }
        }

        // ── ۳.۴) جدول خریدهای درگاه کافه‌بازار (ضدتکرار + اثر حسابرسی)
        if (!$tableExists('fida_gold_purchases')) {
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS `fida_gold_purchases` (
                  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر خریدار',
                  plan_id INT UNSIGNED NOT NULL COMMENT 'پلن اشتراک',
                  gateway VARCHAR(20) NOT NULL DEFAULT 'bazaar' COMMENT 'درگاه پرداخت',
                  sku VARCHAR(80) NOT NULL COMMENT 'شناسهٔ محصول در بازار',
                  purchase_token VARCHAR(190) NOT NULL COMMENT 'توکن خرید بازار',
                  amount BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ پرداختی (تومان)',
                  day_count SMALLINT UNSIGNED NOT NULL DEFAULT 90 COMMENT 'طول اشتراک (روز)',
                  status ENUM('pending','verified','failed','refunded') NOT NULL DEFAULT 'pending',
                  subscription_id BIGINT UNSIGNED NULL COMMENT 'اشتراک فعال‌شده',
                  response_json TEXT NULL COMMENT 'پاسخ خام بازار',
                  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  verified_at DATETIME NULL,
                  PRIMARY KEY (id),
                  UNIQUE KEY uq_gold_token (purchase_token),
                  KEY idx_gold_user (user_id),
                  KEY idx_gold_status (status)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خریدهای اشتراک فیدا از کافه‌بازار'");
                $notes[] = 'جدول fida_gold_purchases';
            } catch (Throwable $e) { /* رد شود */ }
        }

        // ── ۳.۵) جدول پشتیبان‌گیری فیدا (هر کاربر مستقل)
        if (!$tableExists('fida_backups')) {
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS `fida_backups` (
                  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک پشتیبان',
                  job_type ENUM('manual','auto') NOT NULL DEFAULT 'manual' COMMENT 'دستی/خودکار',
                  scope VARCHAR(20) NOT NULL DEFAULT 'full' COMMENT 'دامنهٔ پشتیبان',
                  file_name VARCHAR(190) NULL COMMENT 'نام فایل JSON',
                  size_mb DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'حجم (مگابایت)',
                  row_count INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد ردیف‌ها',
                  status ENUM('running','success','failed') NOT NULL DEFAULT 'running' COMMENT 'وضعیت',
                  error_message VARCHAR(255) NULL COMMENT 'پیام خطا',
                  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                  created_by BIGINT UNSIGNED NULL,
                  PRIMARY KEY (id), INDEX idx_fida_backups_user (user_id, id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پشتیبان‌های فیدا (هر کاربر مستقل)'");
                $notes[] = 'جدول fida_backups ساخته شد';
            } catch (Throwable $e) { /* رد شود */ }
        }

        // ── ۴) هم‌گام‌سازی با فایل اسکیما: ساخت جدول‌های جدید و بازسازی ویوها
        //    (db/fida.sql تنها منبع حقیقت است؛ هر جدول/ویوی تازه خودکار اضافه می‌شود)
        $sqlFile = dirname(__DIR__) . '/db/fida.sql';
        if (is_file($sqlFile)) {
            $sql = (string)file_get_contents($sqlFile);
            if (preg_match_all('/CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS.*?;/is', $sql, $m)) {
                foreach ($m[0] as $tbl) {
                    try { $pdo->exec($tbl); } catch (Throwable $e) { /* رد شود */ }
                }
            }
            if (preg_match_all('/CREATE\s+OR\s+REPLACE\s+VIEW.*?;/is', $sql, $m)) {
                foreach ($m[0] as $view) {
                    try { $pdo->exec($view); $notes[] = 'بازسازی ویو'; } catch (Throwable $e) { /* رد شود */ }
                }
            }
        }

        // ── هم‌گام‌سازی پلن‌های اشتراک (۳ماهه ۲۹۰٬۰۰۰ · ۶ماهه ۴۹۰٬۰۰۰ · یک‌ساله ۶۹۰٬۰۰۰) و کدهای تخفیف
        try {
            $have = $tableExists('fida_gold_plans');
            if ($have) {
                $pdo->exec("UPDATE `fida_gold_plans` SET `is_active`=0 WHERE `plan_code`='silver' OR `duration_months`=1");
                $pdo->exec("UPDATE `fida_gold_plans` SET `title`='۳ ماهه',`duration_months`=3,`price`=290000,`old_price`=490000,`badge`='best_seller',`is_active`=1 WHERE `plan_code`='gold'");
                $pdo->exec("UPDATE `fida_gold_plans` SET `title`='۶ ماهه',`duration_months`=6,`price`=490000,`old_price`=690000,`badge`='recommended',`is_active`=1 WHERE `plan_code`='diamond'");
                if (!(int)$pdo->query("SELECT COUNT(*) FROM `fida_gold_plans` WHERE `plan_code`='annual'")->fetchColumn()) {
                    $pdo->exec("INSERT INTO `fida_gold_plans` (`plan_code`,`title`,`duration_months`,`price`,`old_price`,`badge`,`is_active`) VALUES ('annual','یک‌ساله',12,690000,1200000,'value',1)");
                    $notes[] = 'پلن یک‌ساله اضافه شد';
                } else {
                    $pdo->exec("UPDATE `fida_gold_plans` SET `title`='یک‌ساله',`duration_months`=12,`price`=690000,`old_price`=1200000,`badge`='value',`is_active`=1 WHERE `plan_code`='annual'");
                }
            }
            if ($tableExists('fida_discount_codes')) {
                if (!(int)$pdo->query("SELECT COUNT(*) FROM `fida_discount_codes` WHERE `code`='FIDA20'")->fetchColumn()) {
                    $pdo->exec("INSERT INTO `fida_discount_codes` (`code`,`title`,`discount_mode`,`discount_value`,`max_uses`,`is_active`) VALUES ('FIDA20','کد تخفیف آزمایشی ۲۰٪','percent',20,0,1)");
                    $notes[] = 'کد تخفیف آزمایشی FIDA20 ساخته شد';
                }
                if (!(int)$pdo->query("SELECT COUNT(*) FROM `fida_discount_codes` WHERE `code`='FIDA100'")->fetchColumn()) {
                    $pdo->exec("INSERT INTO `fida_discount_codes` (`code`,`title`,`discount_mode`,`discount_value`,`max_uses`,`is_active`) VALUES ('FIDA100','۱۰۰٬۰۰۰ تومان تخفیف نقدی','amount',100000,100,1)");
                }
            }
        } catch (Throwable $e) { /* رد شود */ }

        // جدول‌های تازهٔ این نسخه (اگر از فایل اسکیما ساخته نشدند)
        foreach ([['fida_bank_accounts', "CREATE TABLE IF NOT EXISTS `fida_bank_accounts` (
              id INT UNSIGNED NOT NULL AUTO_INCREMENT, user_id INT UNSIGNED NOT NULL,
              bank_name VARCHAR(80) NOT NULL, account_holder VARCHAR(120) NOT NULL,
              card_no VARCHAR(32) NULL, iban VARCHAR(40) NULL, account_no VARCHAR(40) NULL,
              is_default TINYINT(1) NOT NULL DEFAULT 0, is_active TINYINT(1) NOT NULL DEFAULT 1,
              sort_order SMALLINT NOT NULL DEFAULT 0, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
              PRIMARY KEY (id), KEY ix_fida_bank_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"]] as [$tn, $ddl]) {
            if (!$tableExists($tn)) {
                try { $pdo->exec($ddl); $notes[] = "جدول $tn ساخته شد"; } catch (Throwable $e) { /* رد شود */ }
            }
        }

        return array_values(array_unique($notes));
    }
}
