<?php
/**
 * پشتیبان‌گیری و بازگردانی فیدا — «هر کاربر، پروفایل مستقل».
 *  • خروجی JSON (قابل بازگردانی) + CSV (همهٔ بخش‌ها در یک فایل)
 *  • فقط داده‌های همان کاربر پشتیبان می‌شود و بازگردانی هم فقط روی همان کاربر انجام می‌گیرد
 *  • فایل‌ها در storage/fida-backups/{user_id}/ نگهداری می‌شوند (بیرون از پوشهٔ وب)
 */
final class FidaBackup
{
    /** جدول‌هایی که در پشتیبان نمی‌آیند: پلن‌های سراسری و خودِ پشتیبان‌ها */
    private const EXCLUDE = ['fida_gold_plans', 'fida_backups'];

    public const FORMAT_VERSION = 1;

    /* ───────────── مسیرها ───────────── */

    public static function dir(int $uid): string { return storage_path('fida-backups/' . max(0, $uid)); }

    public static function filePath(array $job): string
    {
        return self::dir((int)$job['user_id']) . '/' . basename((string)$job['file_name']);
    }

    /* ───────────── فهرست جدول‌ها ───────────── */

    /** جدول‌های فیدا که مالک (user_id) دارند */
    public static function tables(): array
    {
        static $cache = null;
        if ($cache !== null) return $cache;
        $rows = Database::all(
            "SELECT c.TABLE_NAME AS t FROM information_schema.COLUMNS c
               JOIN information_schema.TABLES tb ON tb.TABLE_SCHEMA = c.TABLE_SCHEMA AND tb.TABLE_NAME = c.TABLE_NAME
              WHERE c.TABLE_SCHEMA = DATABASE() AND c.COLUMN_NAME = 'user_id'
                AND tb.TABLE_TYPE = 'BASE TABLE' AND c.TABLE_NAME LIKE 'fida\\_%'
              ORDER BY c.TABLE_NAME");
        $out = [];
        foreach ($rows as $r) {
            $name = (string)$r['t'];
            if (in_array($name, self::EXCLUDE, true)) continue;
            $out[] = $name;
        }
        return $cache = $out;
    }

    private static function tableHas(string $t): bool
    {
        static $cache = [];
        if (array_key_exists($t, $cache)) return $cache[$t];
        return $cache[$t] = ((int)Database::val(
            "SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND TABLE_TYPE='BASE TABLE'",
            [$t], 0) > 0);
    }

    /** ردیف‌های یک جدول برای این کاربر */
    private static function rowsOf(string $table, int $uid): array
    {
        if (!self::tableHas($table)) return [];
        return Database::all("SELECT * FROM `{$table}` WHERE user_id = ?", [$uid]);
    }

    /* ───────────── ساخت پشتیبان ───────────── */

    /** ساخت پشتیبان و ثبت رکورد؛ خروجی: ردیف fida_backups */
    public static function create(int $uid, string $type = 'manual'): array
    {
        if ($uid <= 0) throw new RuntimeException('کاربر نامعتبر است.');
        $jobId = Database::insert('fida_backups', [
            'user_id' => $uid, 'job_type' => in_array($type, ['manual', 'auto'], true) ? $type : 'manual',
            'scope' => 'full', 'status' => 'running', 'created_at' => now(), 'created_by' => $uid,
        ]);
        $dir = self::dir($uid);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) {
            Database::update('fida_backups', ['status' => 'failed', 'error_message' => 'ساخت پوشهٔ پشتیبان ممکن نشد.'], 'id=:pk', ['pk' => $jobId]);
            throw new RuntimeException('ساخت پوشهٔ پشتیبان ممکن نشد.');
        }

        // پسوند تصادفی: دو پشتیبان در یک ثانیه نباید روی هم بنویسند
        $base = 'fida-backup-' . $uid . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3));
        $jsonF = $dir . '/' . $base . '.json';
        $csvF  = $dir . '/' . $base . '.csv';
        $shop  = (string)Database::val('SELECT shop_name FROM fida_settings WHERE user_id=?', [$uid], '');

        $payload = [
            'format'     => 'fida-backup',
            'version'    => self::FORMAT_VERSION,
            'user_id'    => $uid,
            'shop'       => $shop,
            'created_at' => date('c'),
            'tables'     => [],
            'counts'     => [],
        ];
        $csv = fopen($csvF, 'w');
        fwrite($csv, "\xEF\xBB\xBF");   // BOM برای اکسل فارسی
        fputcsv($csv, ['#fida-backup', (string)self::FORMAT_VERSION, (string)$uid, date('c')]);

        $total = 0;
        foreach (self::tables() as $t) {
            try { $rows = self::rowsOf($t, $uid); } catch (Throwable $e) { continue; }
            if (!$rows) continue;
            $payload['tables'][$t] = $rows;
            $payload['counts'][$t] = count($rows);
            $total += count($rows);
            $cols = array_keys($rows[0]);
            fputcsv($csv, array_merge(['#table', $t], array_map(fn($c) => $c . '|' . self::colType($rows, $c), $cols)));
            foreach ($rows as $r) {
                $line = [];
                foreach ($cols as $c) { $v = $r[$c] ?? null; $line[] = $v === null ? '\\N' : (string)$v; }
                fputcsv($csv, $line);
            }
        }
        // فایل تنظیمات همیشه در پشتیبان هست تا پروفایل کامل بازیابی شود
        if (!isset($payload['tables']['fida_settings'])) {
            $row = Database::one('SELECT * FROM fida_settings WHERE user_id=?', [$uid]);
            if ($row) { $payload['tables']['fida_settings'] = [$row]; $payload['counts']['fida_settings'] = 1; $total++; }
        }
        fclose($csv);

        $okJson = @file_put_contents($jsonF, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR)) !== false;
        $sizeMb = round(((is_file($jsonF) ? filesize($jsonF) : 0) + (is_file($csvF) ? filesize($csvF) : 0)) / 1048576, 2);
        Database::update('fida_backups', [
            'file_name' => basename($jsonF), 'size_mb' => $sizeMb, 'row_count' => $total,
            'status' => $okJson ? 'success' : 'failed',
            'error_message' => $okJson ? null : 'نوشتن فایل پشتیبان ناموفق بود.',
        ], 'id=:pk', ['pk' => $jobId]);
        if (!$okJson) throw new RuntimeException('نوشتن فایل پشتیبان ناموفق بود.');

        return Database::one('SELECT * FROM fida_backups WHERE id=?', [$jobId]);
    }

    /** تشخیص نوع ستون از داده‌ها (برای سرسطر CSV) */
    private static function colType(array $rows, string $col): string
    {
        foreach ($rows as $r) {
            $v = $r[$col] ?? null;
            if ($v === null) continue;
            if (is_int($v)) return 'int';
            if (is_float($v)) return 'num';
            $s = (string)$v;
            if (preg_match('/^-?\d+$/', $s)) return 'int';
            if (preg_match('/^-?\d*\.\d+$/', $s)) return 'num';
            if (strlen($s) > 1 && ($s[0] === '{' || $s[0] === '[')) return 'json';
            return 'str';
        }
        return 'str';
    }

    /* ───────────── فهرست/حذف ───────────── */

    public static function jobs(int $uid, int $limit = 100): array
    {
        return Database::all('SELECT * FROM fida_backups WHERE user_id=? ORDER BY id DESC LIMIT ' . (int)$limit, [$uid]);
    }

    /** ایزوله‌سازی: فقط پشتیبان‌های همین کاربر */
    public static function job(int $uid, int $id): ?array
    {
        return Database::one('SELECT * FROM fida_backups WHERE id=? AND user_id=?', [$id, $uid]);
    }

    public static function remove(int $uid, int $id): bool
    {
        $job = self::job($uid, $id);
        if (!$job) return false;
        $stem = pathinfo((string)$job['file_name'], PATHINFO_FILENAME);
        foreach (['.json', '.csv'] as $ext) {
            $f = self::dir($uid) . '/' . $stem . $ext;
            if (is_file($f)) @unlink($f);
        }
        Database::run('DELETE FROM fida_backups WHERE id=? AND user_id=?', [$id, $uid]);
        return true;
    }

    /* ───────────── بازگردانی ───────────── */

    /** خواندن فایل پشتیبان (JSON یا CSV) → ساختار tables */
    public static function read(string $file, string $ext): array
    {
        if ($ext === 'json') {
            $j = json_decode((string)@file_get_contents($file), true);
            if (!is_array($j) || ($j['format'] ?? '') !== 'fida-backup') throw new RuntimeException('فایل پشتیبان معتبر نیست.');
            return $j;
        }
        if ($ext === 'csv') return self::readCsv($file);
        throw new RuntimeException('فقط فایل پشتیبان (JSON یا CSV همین سامانه) قابل بازگردانی است.');
    }

    /** خواندن CSV چندبخشی با سرسطر نوع‌دار */
    private static function readCsv(string $file): array
    {
        $fh = fopen($file, 'r');
        if (!$fh) throw new RuntimeException('فایل قابل خواندن نیست.');
        $bom = fread($fh, 3);
        if ($bom !== "\xEF\xBB\xBF") rewind($fh);
        $payload = ['format' => 'fida-backup', 'version' => self::FORMAT_VERSION, 'user_id' => 0, 'created_at' => '', 'tables' => [], 'counts' => []];
        $table = null; $cols = []; $types = [];
        while (($row = fgetcsv($fh)) !== false) {
            if (!$row) continue;
            $first = (string)($row[0] ?? '');
            if ($first === "#fida-backup") {
                $payload['version'] = (int)($row[1] ?? 1);
                $payload['user_id'] = (int)($row[2] ?? 0);
                $payload['created_at'] = (string)($row[3] ?? '');
                continue;
            }
            if ($first === '#table') {
                $table = (string)($row[1] ?? '');
                $cols = []; $types = [];
                for ($i = 2; $i < count($row); $i++) {
                    $p = explode('|', (string)$row[$i]);
                    $cols[] = $p[0];
                    $types[] = $p[1] ?? 'str';
                }
                if ($table !== '') $payload['tables'][$table] = [];
                continue;
            }
            if ($table === null || !$cols) continue;
            $data = [];
            foreach ($cols as $i => $c) {
                $v = $row[$i] ?? null;
                if ($v === '\\N' || $v === null) { $data[$c] = null; continue; }
                $t = $types[$i] ?? 'str';
                $data[$c] = $t === 'int' ? (int)$v : ($t === 'num' ? (float)$v : $v);
            }
            $payload['tables'][$table][] = $data;
        }
        fclose($fh);
        foreach ($payload['tables'] as $t => $rows) $payload['counts'][$t] = count($rows);
        return $payload;
    }

    /**
     * بازگردانی روی پروفایل کاربر جاری.
     * فقط ردیف‌های همین کاربر پاک/بازنویسی می‌شوند؛ دادهٔ کاربران دیگر دست‌نخورده می‌ماند.
     */
    public static function restore(int $uid, array $payload): array
    {
        if ($uid <= 0) throw new RuntimeException('کاربر نامعتبر است.');
        $srcUid = (int)($payload['user_id'] ?? 0);
        if ($srcUid !== $uid) {
            throw new RuntimeException('این فایل پشتیبان مربوط به کاربر دیگری است (#' . $srcUid . ') و برای حفظ ایزوله‌بودن داده‌ها بازگردانی نمی‌شود.');
        }
        $tables = $payload['tables'] ?? [];
        if (!is_array($tables) || !$tables) throw new RuntimeException('فایل پشتیبان خالی است.');

        $known = array_flip(self::tables());
        $ins = 0;
        Database::transaction(function () use ($uid, $tables, $known, &$ins) {
            $pdo = Database::pdo();
            $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
            try {
                // ۱) پاک‌کردن داده‌های همین کاربر (برعکس ترتیب وابستگی‌ها)
                foreach (array_reverse(array_keys($tables)) as $t) {
                    if (!isset($known[$t]) || !self::tableHas($t)) continue;
                    $pdo->prepare("DELETE FROM `{$t}` WHERE user_id = ?")->execute([$uid]);
                }
                // جدول‌هایی که در فایل نیستند ولی دادهٔ همین کاربر دارند هم پاک می‌شوند (بازگردانی کامل)
                foreach (self::tables() as $t) {
                    if (isset($tables[$t]) || !self::tableHas($t)) continue;
                    $pdo->prepare("DELETE FROM `{$t}` WHERE user_id = ?")->execute([$uid]);
                }
                // ۲) درج ردیف‌های پشتیبان (user_id به کاربر جاری اجبار می‌شود)
                foreach (array_keys($tables) as $t) {
                    if (!isset($known[$t]) || !self::tableHas($t)) continue;
                    $rows = $tables[$t];
                    if (!is_array($rows)) continue;
                    foreach ($rows as $row) {
                        if (!is_array($row) || !$row) continue;
                        $row['user_id'] = $uid;                        // ایزوله‌سازی
                        self::insertRow($pdo, $t, $row);
                        $ins++;
                    }
                }
            } finally {
                $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
            }
        });
        return ['rows' => $ins, 'tables' => count($tables)];
    }

    private static function insertRow(PDO $pdo, string $table, array $row): void
    {
        $cols = array_keys($row);
        $colSql = implode(',', array_map(fn($c) => "`" . str_replace('`', '', $c) . "`", $cols));
        $ph = implode(',', array_fill(0, count($cols), '?'));
        $st = $pdo->prepare("INSERT INTO `{$table}` ({$colSql}) VALUES ({$ph})");
        $vals = [];
        foreach ($cols as $c) { $v = $row[$c]; $vals[] = is_bool($v) ? (int)$v : $v; }
        $st->execute($vals);
    }

    /* ───────────── آمار بخش‌ها (برای نمایش) ───────────── */

    public static function counts(int $uid): array
    {
        $out = [];
        foreach (self::tables() as $t) {
            try { $out[$t] = (int)Database::val("SELECT COUNT(*) FROM `{$t}` WHERE user_id=?", [$uid], 0); }
            catch (Throwable $e) { $out[$t] = 0; }
        }
        return $out;
    }

    /** برچسب فارسی جدول‌ها */
    public static function labels(): array
    {
        return [
            'fida_persons' => 'اشخاص', 'fida_items' => 'کالا و خدمات', 'fida_invoices' => 'فاکتورها',
            'fida_invoice_items' => 'ردیف فاکتورها', 'fida_payments' => 'پرداخت‌ها',
            'fida_invoice_status_history' => 'تاریخچهٔ وضعیت', 'fida_cheques' => 'چک‌ها',
            'fida_invoice_templates' => 'قالب‌های فاکتور', 'fida_template_items' => 'اقلام قالب',
            'fida_settings' => 'تنظیمات فروشگاه', 'fida_units' => 'واحدهای شمارش',
            'fida_monthly_metrics' => 'آمار ماهانه', 'fida_subscriptions' => 'اشتراک‌ها',
            'fida_invite_codes' => 'کدهای دعوت', 'fida_notice_reads' => 'اعلان‌های خوانده‌شده',
        ];
    }
}
