<?php
/**
 * سیستم اعلان داخلی فیدا — سررسید فاکتورهای اعتباری و چک‌ها.
 * اعلان‌ها «محاسبه‌شده» هستند (همیشه به‌روز)؛ وضعیت خوانده‌شدن در جدول fida_notice_reads ذخیره می‌شود.
 */
final class FidaNotice
{
    /** پنجرهٔ هشدار: چند روز قبل از سررسید اعلان ساخته شود */
    public const WINDOW_DAYS = 3;

    /** فهرست اعلان‌های کاربر */
    public static function feed(int $uid): array
    {
        if ($uid <= 0) return [];
        $win = self::WINDOW_DAYS;
        $items = [];

        /* ── فاکتورهای اعتباری نزدیک سررسید یا معوق ── */
        foreach (Database::all(
            "SELECT id, invoice_code, invoice_type, person_name, balance_amount, due_date, due_jalali,
                    DATEDIFF(due_date, CURDATE()) AS d
               FROM v_fida_invoices_full
              WHERE user_id = ? AND status = 'credit' AND balance_amount > 0 AND due_date IS NOT NULL
                AND due_date <= DATE_ADD(CURDATE(), INTERVAL {$win} DAY)
              ORDER BY d ASC LIMIT 60", [$uid]) as $r) {
            $d = (int)$r['d'];
            $items[] = [
                'key'      => 'inv:' . (int)$r['id'],
                'kind'     => 'invoice',
                'severity' => $d < 0 ? 'danger' : ($d <= 1 ? 'danger' : 'warn'),
                'days'     => $d,
                'when'     => self::label($d),
                'title'    => 'سررسید فاکتور ' . fa_digits($r['invoice_code']),
                'desc'     => $r['person_name'] . ' — مانده ' . num($r['balance_amount']) . ' تومان — سررسید ' . fa_digits($r['due_jalali']),
                'url'      => url('fida/invoices/' . (int)$r['id']),
                'amount'   => (int)$r['balance_amount'],
                'icon'     => 'receipt',
            ];
        }

        /* ── چک‌های در جریان نزدیک سررسید یا معوق ── */
        foreach (Database::all(
            "SELECT id, direction, cheque_no, bank_name, amount, due_date, due_jalali, party_name, status,
                    DATEDIFF(due_date, CURDATE()) AS d
               FROM v_fida_cheques_full
              WHERE user_id = ? AND status IN ('in_hand','deposited')
                AND due_date <= DATE_ADD(CURDATE(), INTERVAL {$win} DAY)
              ORDER BY d ASC LIMIT 60", [$uid]) as $r) {
            $d = (int)$r['d'];
            $dirFa = $r['direction'] === 'issued' ? 'چک پرداختی' : 'چک دریافتی';
            $items[] = [
                'key'      => 'chq:' . (int)$r['id'],
                'kind'     => 'cheque',
                'severity' => $d < 0 ? 'danger' : ($d <= 1 ? 'danger' : 'warn'),
                'days'     => $d,
                'when'     => self::label($d),
                'title'    => 'سررسید ' . $dirFa . ' ' . $r['cheque_no'],
                'desc'     => ($r['bank_name'] ? $r['bank_name'] . ' — ' : '')
                              . $r['party_name'] . ' — مبلغ ' . num($r['amount']) . ' تومان'
                              . ($r['status'] === 'deposited' ? ' — سپرده‌شده' : ''),
                'url'      => url('fida/cheques?focus=' . (int)$r['id']),
                'amount'   => (int)$r['amount'],
                'icon'     => 'cheque',
            ];
        }

        /* ── چک‌های برگشتی (نیازمند پیگیری) ── */
        foreach (Database::all(
            "SELECT id, direction, cheque_no, bank_name, amount, due_jalali, party_name
               FROM v_fida_cheques_full
              WHERE user_id = ? AND status = 'returned'
              ORDER BY due_date DESC LIMIT 20", [$uid]) as $r) {
            $dirFa = $r['direction'] === 'issued' ? 'چک پرداختی' : 'چک دریافتی';
            $items[] = [
                'key'      => 'chqret:' . (int)$r['id'],
                'kind'     => 'cheque_returned',
                'severity' => 'danger',
                'days'     => null,
                'when'     => 'برگشتی',
                'title'    => $dirFa . ' برگشتی ' . $r['cheque_no'],
                'desc'     => $r['party_name'] . ' — مبلغ ' . num($r['amount']) . ' تومان — سررسید ' . fa_digits($r['due_jalali']),
                'url'      => url('fida/cheques?focus=' . (int)$r['id']),
                'amount'   => (int)$r['amount'],
                'icon'     => 'alert',
            ];
        }

        /* ── فاکتورهای پیش‌نویس/در انتظار تأیید قدیمی (یادآوری) ── */
        foreach (Database::all(
            "SELECT id, invoice_code, person_name, final_amount, invoice_jalali, DATEDIFF(CURDATE(), invoice_date) AS age
               FROM v_fida_invoices_full
              WHERE user_id = ? AND invoice_type = 'pre_invoice' AND status = 'pending'
                AND invoice_date <= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
              ORDER BY invoice_date ASC LIMIT 15", [$uid]) as $r) {
            $items[] = [
                'key'      => 'pre:' . (int)$r['id'],
                'kind'     => 'pre_invoice',
                'severity' => 'info',
                'days'     => null,
                'when'     => fa_digits((string)$r['age']) . ' روز',
                'title'    => 'پیش‌فاکتور بی‌پاسخ ' . fa_digits($r['invoice_code']),
                'desc'     => $r['person_name'] . ' — مبلغ ' . num($r['final_amount']) . ' تومان — ' . fa_digits((string)$r['age']) . ' روز بدون اقدام',
                'url'      => url('fida/invoices/' . (int)$r['id']),
                'amount'   => (int)$r['final_amount'],
                'icon'     => 'receipt',
            ];
        }

        /* ── رویدادهای تقویم شخصی: امروز، معوق و یادآوری‌های چند روز قبل ── */
        foreach (Database::all(
            "SELECT id, title, kind, event_date, event_time, priority, note, is_done, notify_days,
                    DATEDIFF(event_date, CURDATE()) AS d
               FROM fida_events
              WHERE user_id = ? AND is_done = 0
                AND event_date <= DATE_ADD(CURDATE(), INTERVAL notify_days DAY)
              ORDER BY event_date, event_time IS NULL, event_time, id LIMIT 60", [$uid]) as $r) {
            $d = (int)$r['d'];
            if ($d > 7) continue;
            [$ey, $em, $ed] = gregorian_to_jalali((int)date('Y', strtotime((string)$r['event_date'])),
                (int)date('n', strtotime((string)$r['event_date'])), (int)date('j', strtotime((string)$r['event_date'])));
            $kindFa = class_exists('Fida') ? (Fida::EVENT_KINDS[$r['kind']] ?? 'رویداد') : 'رویداد';
            $items[] = [
                'key'      => 'evt:' . (int)$r['id'],
                'kind'     => 'event',
                'severity' => $d < 0 ? 'danger' : ($d === 0 ? 'warn' : 'info'),
                'days'     => $d,
                'when'     => $d === 0 ? 'امروز' : ($d === 1 ? 'فردا' : self::label($d)),
                'title'    => ($d < 0 ? 'رویداد معوق: ' : ($d === 0 ? '🔔 رویداد امروز: ' : 'رویداد پیش‌رو: ')) . $r['title'],
                'desc'     => $kindFa . (!empty($r['event_time']) ? ' — ساعت ' . fa_digits(substr((string)$r['event_time'], 0, 5)) : '')
                              . ' — ' . jdate((string)$r['event_date'])
                              . ($r['priority'] === 'high' ? ' — ⚡ مهم' : '')
                              . (!empty($r['note']) ? ' — ' . mb_substr((string)$r['note'], 0, 60) : ''),
                'url'      => url('fida/calendar?y=' . $ey . '&m=' . $em . '&d=' . $ey . '/' . $em . '/' . $ed),
                'amount'   => 0,
                'icon'     => 'event',
            ];
        }

        /* ── حذف اعلان‌هایی که همین کاربر بسته است (وضعیت هر کاربر جداست) ── */
        $dismissed = self::dismissedKeys($uid);
        if ($dismissed) $items = array_values(array_filter($items, static fn($it) => !isset($dismissed[$it['key']])));

        /* ── وضعیت خوانده‌شدن ── */
        $read = self::readKeys($uid);
        foreach ($items as &$it) { $it['read'] = isset($read[$it['key']]); }
        unset($it);

        /* ── مرتب‌سازی: فوری‌ترها اول ── */
        usort($items, static function ($a, $b) {
            $ra = $a['read'] ? 1 : 0; $rb = $b['read'] ? 1 : 0;
            if ($ra !== $rb) return $ra <=> $rb;
            $da = $a['days'] === null ? 999 : (int)$a['days'];
            $db = $b['days'] === null ? 999 : (int)$b['days'];
            return $da <=> $db;
        });
        return $items;
    }

    /** تعداد اعلان‌های خوانده‌نشده */
    public static function unreadCount(int $uid): int
    {
        if ($uid <= 0) return 0;
        $n = 0;
        foreach (self::feed($uid) as $it) if (!$it['read']) $n++;
        return $n;
    }

    /** خلاصهٔ کوچک برای نشانک دار زنگ (بدون محاسبهٔ کامل) */
    public static function badge(int $uid): array
    {
        $items = self::feed($uid);
        $unread = 0; $urgent = 0;
        foreach ($items as $it) {
            if (!$it['read']) $unread++;
            if ($it['days'] !== null && (int)$it['days'] <= 1 && !$it['read']) $urgent++;
        }
        return ['count' => count($items), 'unread' => $unread, 'urgent' => $urgent];
    }

    public static function markRead(int $uid, string $key): void
    {
        if ($uid <= 0 || $key === '') return;
        Database::run('INSERT IGNORE INTO fida_notice_reads (user_id, notice_key) VALUES (?, ?)', [$uid, mb_substr($key, 0, 80)]);
    }

    public static function markUnread(int $uid, string $key): void
    {
        if ($uid <= 0 || $key === '') return;
        Database::run('DELETE FROM fida_notice_reads WHERE user_id=? AND notice_key=?', [$uid, mb_substr($key, 0, 80)]);
    }

    /** علامت‌گذاری همهٔ اعلان‌های فعلی به‌عنوان خوانده‌شده */
    public static function markAllRead(int $uid): int
    {
        if ($uid <= 0) return 0;
        $n = 0;
        foreach (self::feed($uid) as $it) {
            if (!$it['read']) { self::markRead($uid, $it['key']); $n++; }
        }
        return $n;
    }

    private static function readKeys(int $uid): array
    {
        $out = [];
        foreach (Database::all('SELECT notice_key FROM fida_notice_reads WHERE user_id=? AND dismissed_at IS NULL', [$uid]) as $r) {
            $out[(string)$r['notice_key']] = true;
        }
        return $out;
    }

    /** کلید اعلان‌هایی که همین کاربر حذف کرده است */
    private static function dismissedKeys(int $uid): array
    {
        if ($uid <= 0) return [];
        $out = [];
        foreach (Database::all('SELECT notice_key FROM fida_notice_reads WHERE user_id=? AND dismissed_at IS NOT NULL', [$uid]) as $r) {
            $out[(string)$r['notice_key']] = true;
        }
        return $out;
    }

    /** حذف (بستن) یک اعلان برای همین کاربر */
    public static function dismiss(int $uid, string $key): bool
    {
        if ($uid <= 0 || $key === '') return false;
        $key = mb_substr($key, 0, 80);
        $row = Database::one('SELECT id FROM fida_notice_reads WHERE user_id=? AND notice_key=?', [$uid, $key]);
        if ($row) Database::run('UPDATE fida_notice_reads SET dismissed_at=NOW() WHERE id=?', [(int)$row['id']]);
        else Database::run('INSERT INTO fida_notice_reads (user_id, notice_key, read_at, dismissed_at) VALUES (?,?,NOW(),NOW())', [$uid, $key]);
        return true;
    }

    /** حذف همهٔ اعلان‌های فعلی همین کاربر */
    public static function dismissAll(int $uid): int
    {
        if ($uid <= 0) return 0;
        $n = 0;
        foreach (self::feed($uid) as $it) { if (self::dismiss($uid, (string)$it['key'])) $n++; }
        return $n;
    }

    /** برچسب فارسی زمان سررسید */
    public static function label(int $d): string
    {
        if ($d < 0)  return abs($d) . ' روز گذشته';
        if ($d === 0) return 'امروز';
        if ($d === 1) return 'فردا';
        return $d . ' روز مانده';
    }

    /** آیکون SVG هر نوع اعلان */
    public static function icon(string $kind, int $size = 18): string
    {
        $paths = [
            'receipt' => '<path d="M6 2.5h9l4 4V21a.5.5 0 0 1-.5.5h-12A.5.5 0 0 1 6 21V2.5z"/><path d="M9 12h7M9 16h7M9 8h3"/>',
            'cheque'  => '<rect x="2.5" y="5.5" width="19" height="13" rx="2.5"/><path d="M2.5 10h19M6.5 15h4"/>',
            'alert'   => '<path d="M12 3.5 21 20H3L12 3.5z"/><path d="M12 9.5v4M12 16.5h.01"/>',
            'event'   => '<rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/><path d="M8 14h3M8 17.5h7"/>',
        ];
        $p = $paths[$kind] ?? $paths['receipt'];
        return '<svg viewBox="0 0 24 24" width="' . $size . '" height="' . $size . '" fill="none" stroke="currentColor" '
             . 'stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' . $p . '</svg>';
    }
}
