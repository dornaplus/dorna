<?php
/** توابع کمکی سراسری (نمایش اعداد، تاریخ شمسی، امنیت فرم، رندر قالب) */

function config(?string $key = null, $default = null)
{
    static $cfg = null;
    if ($cfg === null) {
        $cfg = require __DIR__.'/../config.php';
        $local = __DIR__.'/../config.local.php';
        if (is_file($local)) {
            $over = require $local;
            $cfg = array_replace_recursive($cfg, is_array($over) ? $over : []);
        }
    }
    if ($key === null) return $cfg;
    $parts = explode('.', $key); $cur = $cfg;
    foreach ($parts as $p) { if (!is_array($cur) || !array_key_exists($p, $cur)) return $default; $cur = $cur[$p]; }
    return $cur;
}

function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function num($v, int $dec = 0): string
{
    // نمایش همهٔ اعداد به‌صورت فارسی (ارقام و جداکنندهٔ هزار/اعشار فارسی)
    return strtr(number_format((float)$v, $dec, '.', ','),
        ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹', ','=>'٬', '.'=>'٫']);
}
/** تبدیل ارقام لاتین به فارسی (برای متن‌های غیرعددی) */
function fa_digits(?string $s): string
{
    return strtr((string)$s, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
}
/** آیا این مجوز در سامانه تعریف شده است؟ (با کش) */
function perm_defined(string $slug): bool
{
    static $set = null;
    if ($set === null) {
        $set = [];
        if (class_exists('Database')) {
            foreach (Database::all('SELECT slug FROM permissions WHERE is_active=1') as $row) $set[$row['slug']] = true;
        }
    }
    return isset($set[$slug]);
}

/** مجوز لازم برای یک مسیر منو (خالی = بدون محدودیت) */
function route_perm(string $route): string
{
    $parts = array_values(array_filter(explode('/', explode('?', ltrim($route, '/'))[0]), fn($x) => $x !== ''));
    if (($parts[0] ?? '') !== 'app' || empty($parts[1])) return '';
    $key = (string)$parts[1];
    // پیام‌رسان داخلی (`app/messages`) با ماژول «پیامک» (جدول messages) هم‌نام است؛
    // پیام‌رسان داخلی برای همهٔ کاربران باز است و نباید به مجوز «پیامک» گره بخورد.
    if ($key === 'messages') return '';
    $last = (string)end($parts);
    $action = in_array($last, ['create', 'edit'], true) ? $last : 'view';
    // مسیرهایی که ماژول متادیتا ندارند (کنترلر اختصاصی)
    $custom = [
        'invoices' => 'invoices', 'journal' => 'accounting', 'reports' => 'reports',
        'plans' => 'subscription', 'subscription' => 'subscription', 'subscription-payments' => 'subscription',
        'backups' => 'backup', 'users' => 'users', 'roles' => 'users', 'audit-logs' => 'settings',
        'petty-cash' => 'petty_cash', 'payroll' => 'payroll',
        'settings' => 'settings', 'assistant' => '', 'dashboard' => 'dashboard',
    ];
    $m = class_exists('Meta') ? Meta::module($key) : null;
    $base = (string)($m['perm'] ?? '');
    if ($base === '') $base = (string)($custom[$key] ?? '');
    if ($base === '') return '';
    if (str_contains($base, '.')) return perm_defined($base) ? $base : '';
    $cand = $base . '.' . $action;
    if (perm_defined($cand)) return $cand;
    $view = $base . '.view';
    return perm_defined($view) ? $view : '';
}

/** آیا کاربر جاری اجازهٔ دیدن این مسیر را دارد؟ */
function route_allowed(?string $route): bool
{
    $route = (string)$route;
    if ($route === '') return true;
    $perm = route_perm($route);
    return $perm === '' || Auth::can($perm);
}

/** آیا این مسیر جزو بخش‌های ویژهٔ «مدیر سیستم» است؟ (داشبورد، تنظیمات، پشتیبانی، خرید پکیج) */
function admin_only_path(string $path): bool
{
    $p = '/' . trim(explode('?', $path)[0], '/');
    if ($p === '/app') return true;                       // داشبورد
    $parts = array_values(array_filter(explode('/', $p), fn($x) => $x !== ''));
    if (($parts[0] ?? '') !== 'app' || empty($parts[1])) return false;
    return class_exists('Meta') && Meta::isAdminOnlyModule((string)$parts[1]);
}

/** نخستین صفحهٔ مجاز کاربر — برای فرود کاربران غیرمدیر و بازگردانی از بخش‌های ویژهٔ مدیر */
function nav_home(): string
{
    $isAdmin = Auth::isAdmin();
    $fallback = '';
    foreach (Meta::NAV as $g) {
        if (!empty($g['admin_only']) && !$isAdmin) continue;
        if (!empty($g['perm']) && !Auth::can((string)$g['perm'])) continue;
        $items = [];
        foreach (($g['items'] ?? []) as $it) {
            if (!empty($it['admin_only']) && !$isAdmin) continue;
            if (!empty($it['perm']) && !Auth::can((string)$it['perm'])) continue;
            if (!route_allowed((string)($it['route'] ?? ''))) continue;
            $items[] = (string)$it['route'];
        }
        if (!empty($g['route']) && route_allowed((string)$g['route'])) return (string)$g['route'];
        if (!$items) continue;
        if ($fallback === '') $fallback = $items[0];
        // گروه‌های ماژول اصلی (دارای مجوز) بر گروه‌های کمکی مقدم‌اند
        if (!empty($g['perm'])) return $items[0];
    }
    return $fallback !== '' ? $fallback : 'app/my-account';
}

/** تبدیل ارقام فارسی/عربی به لاتین */
function en_digits(?string $s): string
{
    return strtr((string)$s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                              '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
}
function money($v, ?string $cur = null): string { return num((float)$v, 0).' '.($cur ?: 'ریال'); }
function base_path(): string { $c = config('app'); if (!empty($c['url'])) return rtrim($c['url'], '/'); return rtrim((dirname($_SERVER['SCRIPT_NAME'] ?? '/') === '/' ? '' : dirname($_SERVER['SCRIPT_NAME'])), '/'); }
function url(string $path = ''): string { return base_path().'/'.ltrim($path, '/'); }
function asset(string $p): string { return url('assets/'.ltrim($p, '/')); }
function redirect(string $path): void { header('Location: '.url($path)); exit; }
function variant_ref(int $v): ?int { return $v > 0 ? $v : null; }

function uuid4(): string
{
    $d = random_bytes(16);
    $d[6] = chr((ord($d[6]) & 0x0f) | 0x40);
    $d[8] = chr((ord($d[8]) & 0x3f) | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($d), 4));
}

function base_currency_id(?int $businessId = null): int
{
    static $cache = [];
    $biz = $businessId ?: (Auth::businessId() ?: 0);
    if ($biz && !isset($cache[$biz])) {
        $cache[$biz] = (int)Database::val('SELECT base_currency_id FROM businesses WHERE id=?', [$biz], 0);
    }
    if (!empty($cache[$biz])) return (int)$cache[$biz];
    return (int)Database::val('SELECT id FROM currencies WHERE is_base=1 ORDER BY id LIMIT 1', [], 1);
}

function cashAccountKind(string $k): string
{
    return ['bank' => 'بانک', 'cash_box' => 'صندوق', 'petty_cash' => 'تنخواه', 'pos' => 'کارتخوان'][$k] ?? $k;
}

function currency_title(): string
{
    static $t = null;
    if ($t !== null) return $t;
    $t = (string)Database::val('SELECT title FROM currencies WHERE id=?', [base_currency_id()], 'ریال');
    return $t;
}

/* ───────────── توابع تنظیمات مالی (این تنظیمات واقعاً روی محاسبات اثر می‌گذارند) ───────────── */

/** نرخ مالیات بر ارزش افزودهٔ کسب‌وکار از تنظیمات مالی */
function finance_vat_rate(?int $businessId = null): float
{
    return (float)Settings::get('financial.vat_rate_percent', 0, $businessId);
}

/** شناسهٔ ردیف مالیات متناظر با نرخ پیش‌فرض ارزش افزوده (یا null) */
function finance_vat_tax_id(?int $businessId = null): ?int
{
    static $cache = [];
    $bid = (int)($businessId ?: Auth::businessId());
    if (array_key_exists($bid, $cache)) return $cache[$bid];
    $rate = finance_vat_rate($bid ?: null);
    if ($rate <= 0) return $cache[$bid] = null;
    $id = Database::val('SELECT id FROM taxes WHERE business_id=? AND is_active=1 AND deleted_at IS NULL AND ABS(rate_percent-?)<0.001 ORDER BY id LIMIT 1', [$bid, $rate], 0);
    return $cache[$bid] = ($id ? (int)$id : null);
}

/** رُند کردن مبلغ بر اساس تنظیمات مالی (nearest/up/down/exact) */
function finance_round(float $v, ?int $businessId = null): float
{
    $mode = strtolower(trim((string)Settings::get('financial.rounding_mode', 'exact', $businessId)));
    return match ($mode) {
        'nearest', 'round', 'integer' => round($v),
        'up', 'ceil' => ceil($v),
        'down', 'floor' => floor($v),
        default => round($v, 2),          // exact / none / هر مقدار ناشناخته
    };
}

/** تعداد روز شرایط پرداخت شخص (یا مقدار پیش‌فرض کسب‌وکار) */
function finance_payment_term_days(?int $personId = null): ?int
{
    if ($personId) {
        $t = Database::one('SELECT pt.days FROM person_financial_settings pfs JOIN payment_terms pt ON pt.id=pfs.payment_term_id
                            WHERE pfs.person_id=? AND pt.is_active=1 AND pt.deleted_at IS NULL', [$personId]);
        if ($t) return (int)$t['days'];
    }
    $d = Settings::get('trade.default_payment_term_days', null);
    if ($d !== null && $d !== '' && (int)$d > 0) return (int)$d;
    return null;
}

/** تاریخ سررسید پیشنهادی (میلادی) بر اساس شرایط پرداخت */
function finance_due_date(string $invoiceDate, ?int $personId = null): ?string
{
    $days = finance_payment_term_days($personId);
    if ($days === null) return null;
    $ts = strtotime($invoiceDate ?: today());
    return date('Y-m-d', $ts + $days * 86400);
}

function docTypeTitle(string $t): string
{
    return [
        'sale' => 'فاکتور فروش', 'buy' => 'فاکتور خرید', 'sale_return' => 'برگشت از فروش', 'buy_return' => 'برگشت از خرید',
        'quote' => 'پیش‌فاکتور', 'receipt' => 'دریافت', 'payment' => 'پرداخت', 'cheque' => 'چک', 'journal' => 'سند حسابداری',
        'hr' => 'حقوق و دستمزد', 'voucher' => 'سند هزینه/درآمد', 'transfer' => 'انتقال', 'waste' => 'ضایعات', 'count' => 'انبارگردانی',
    ][$t] ?? $t;
}


/** تبدیل عدد به حروف فارسی (برای چاپ اسناد و فاکتورها) */
function amount_in_words(float $number, string $currency = 'ریال'): string
{
    $number = (float)round($number, 0);
    if (abs($number) < 0.5) return 'صفر '.$currency;
    $int = (int)floor(abs($number));
    $ones = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه'];
    $teens = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده'];
    $tens = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود'];
    $hundreds = ['', 'یکصد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد'];
    $scales = ['', ' هزار', ' میلیون', ' میلیارد', ' بیلیون'];

    $three = function (int $n) use ($ones, $teens, $tens, $hundreds): string {
        $out = [];
        $h = intdiv($n, 100); $r = $n % 100;
        if ($h) $out[] = $hundreds[$h];
        if ($r >= 10 && $r < 20) $out[] = $teens[$r - 10];
        else { $t = intdiv($r, 10); $o = $r % 10; if ($t) $out[] = $tens[$t]; if ($o) $out[] = $ones[$o]; }
        return implode(' و ', array_filter($out));
    };

    $parts = []; $i = 0;
    while ($int > 0) {
        $chunk = $int % 1000;
        if ($chunk) $parts[] = trim($three($chunk).($scales[$i] ?? ''));
        $int = intdiv($int, 1000); $i++;
    }
    $words = $parts ? implode(' و ', array_reverse($parts)) : 'صفر';
    return ($number < 0 ? 'منفی ' : '').$words.' '.$currency;
}

function now(): string { return date('Y-m-d H:i:s'); }
function today(): string { return date('Y-m-d'); }
function is_post(): bool { return strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST'; }
function input(string $key, $default = null) { $v = $_POST[$key] ?? $_GET[$key] ?? null; if (is_string($v)) $v = trim($v); return ($v === '' || $v === null) ? $default : $v; }
function post(string $key, $default = null) { $v = $_POST[$key] ?? null; if (is_string($v)) $v = trim($v); return ($v === '' || $v === null) ? $default : $v; }
function qs(array $extra = []): string { $q = array_merge($_GET, $extra); unset($q['_url']); return $q ? '?'.http_build_query($q) : ''; }
function json_input(): array { $raw = file_get_contents('php://input'); $j = json_decode($raw ?: '[]', true); return is_array($j) ? $j : []; }

/* ---------- پیام‌های کاربر ---------- */
function flash(string $type, string $msg): void { $_SESSION['_flash'][] = ['type' => $type, 'msg' => $msg]; }
function old(string $k, $d = '') { return e($_SESSION['_old'][$k] ?? $d); }
function errors(): array { return $_SESSION['_errors'] ?? []; }
function set_errors(array $e): void { $_SESSION['_errors'] = $e; }

/**
 * ارقام فارسی/عربی ورودی‌های «عددِ محض» را به لاتین تبدیل می‌کند تا در دیتابیس انگلیسی ثبت شود.
 * مقادیری که متن ترکیبی دارند (مثل یادداشت‌ها) دست‌نخورده می‌مانند.
 */
function normalize_request_digits(array $in): array
{
    $skip = ['password', 'password_hash', 'password_confirmation', 'current_password', 'new_password', '_token', '_method'];
    $out = [];
    foreach ($in as $k => $v) {
        if (is_string($k) && in_array($k, $skip, true)) { $out[$k] = $v; continue; }
        if (is_array($v)) { $out[$k] = normalize_request_digits($v); continue; }
        if (!is_string($v) || $v === '' || !preg_match('/[۰-۹٠-٩٬٫]/u', $v)) { $out[$k] = $v; continue; }
        $t = trim($v);
        // فقط اگر کل مقدار «عدد» باشد (با جداکنندهٔ هزار/اعشار، علامت، فاصله)
        if (!preg_match('/^[-+\d۰-۹٠-٩٬٫,،.\s]+$/u', $t)) { $out[$k] = $v; continue; }
        $out[$k] = strtr(en_digits($t), ['٬'=>'', '،'=>'', ','=>'', '٫'=>'.', '‌'=>'', ' '=>'']);
    }
    return $out;
}

/* ---------- CSRF ---------- */
function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(16));
    return $_SESSION['_csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="_token" value="'.e(csrf_token()).'">'; }
function csrf_verify(): void
{
    if (!is_post()) return;
    $t = $_POST['_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    if (!hash_equals($_SESSION['_csrf'] ?? '', (string)$t)) { http_response_code(419); exit('نشست شما منقضی شده است؛ صفحه را تازه کنید.'); }
}

/* ---------- تاریخ شمسی ---------- */
function gregorian_to_jalali(int $gy, int $gm, int $gd): array
{
    $g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + intdiv($gy2 + 3, 4) - intdiv($gy2 + 99, 100) + intdiv($gy2 + 399, 400) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * intdiv($days, 12053)); $days %= 12053;
    $jy += 4 * intdiv($days, 1461); $days %= 1461;
    if ($days > 365) { $jy += intdiv($days - 1, 365); $days = ($days - 1) % 365; }
    if ($days < 186) { $jm = 1 + intdiv($days, 31); $jd = 1 + ($days % 31); }
    else { $jm = 7 + intdiv($days - 186, 30); $jd = 1 + (($days - 186) % 30); }
    return [$jy, $jm, $jd];
}
function jalali_to_gregorian(int $jy, int $jm, int $jd): array
{
    $jy += 1595; $days = -355668 + (365 * $jy) + (intdiv($jy, 33) * 8) + intdiv(($jy % 33) + 3, 4) + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
    $gy = 400 * intdiv($days, 146097); $days %= 146097;
    if ($days > 36524) { $gy += 100 * intdiv(--$days, 36524); $days %= 36524; if ($days >= 365) $days++; }
    $gy += 4 * intdiv($days, 1461); $days %= 1461;
    if ($days > 365) { $gy += intdiv($days - 1, 365); $days = ($days - 1) % 365; }
    $gd = $days + 1;
    $months = [31,(((($gy % 4 == 0) && ($gy % 100 != 0)) || ($gy % 400 == 0)) ? 29 : 28),31,30,31,30,31,31,30,31,30,31];
    $gm = 0; while ($gm < 12 && $gd > $months[$gm]) { $gd -= $months[$gm]; $gm++; }
    return [$gy, $gm + 1, $gd];
}
/** تاریخ شمسی خوانا: 1404/05/08 */
function jdate(?string $date, string $sep = '/', bool $withTime = false): string
{
    if (!$date || $date === '0000-00-00' || str_starts_with((string)$date, '0000')) return '—';
    $ts = strtotime($date); if (!$ts) return '—';
    [$jy, $jm, $jd] = gregorian_to_jalali((int)date('Y', $ts), (int)date('n', $ts), (int)date('j', $ts));
    $out = sprintf('%04d%s%02d%s%02d', $jy, $sep, $jm, $sep, $jd);
    if ($withTime) $out .= ' - '.date('H:i', $ts);
    return fa_digits($out);
}
/** نام ماه شمسی */
function jmonth_name(int $m): string { return ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'][$m - 1] ?? ''; }
/** نام فارسی روز هفته (شمسی/میلادی یکی است) */
function weekday_fa(?string $date = null): string
{
    $ts = $date ? strtotime($date) : time(); if (!$ts) return '';
    return ['شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه'][(int)date('w', $ts)] ?? '';
}
/** تبدیل ورودی کاربر (شمسی یا میلادی) به DATE میلادی */
function to_gregorian(?string $in): ?string
{
    if (!$in) return null;
    $in = trim($in);
    $fa = ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9'];
    $in = strtr($in, $fa);
    if (preg_match('#^(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?$#', $in, $m)) {
        $y = (int)$m[1];
        if ($y < 1700) { [$gy, $gm, $gd] = jalali_to_gregorian($y, (int)$m[2], (int)$m[3]); $d = sprintf('%04d-%02d-%02d', $gy, $gm, $gd); }
        else { $d = sprintf('%04d-%02d-%02d', $y, (int)$m[2], (int)$m[3]); }
        if (isset($m[4])) $d .= sprintf(' %02d:%02d:00', (int)$m[4], (int)$m[5]);
        return $d;
    }
    return date('Y-m-d H:i:s', strtotime($in));
}
function current_jalali_year(): int { [$y] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j')); return $y; }
function current_jalali_month(): int { [, $m] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j')); return $m; }
/** [سال، ماه] شمسی امروز */
function current_jalali_ym(): array { [$y, $m] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j')); return [$y, $m]; }
/** بازه سال مالی شمسی جاری */
function jalali_year_range(int $jy): array { [$sy,$sm,$sd] = jalali_to_gregorian($jy,1,1); [$ey,$em,$ed] = jalali_to_gregorian($jy,12,($jy % 33 % 4 === 1 ? 30 : 29)); return [sprintf('%04d-%02d-%02d',$sy,$sm,$sd), sprintf('%04d-%02d-%02d',$ey,$em,$ed)]; }

/* ---------- رندر ---------- */
function view(string $__view, array $data = []): string
{
    // نکته: نام پارامتر نباید با کلیدهای داده هم‌نام باشد، وگرنه extract(EXTR_SKIP) آن کلید را دور می‌ریزد.
    extract($data, EXTR_SKIP);
    ob_start();
    require __DIR__.'/Views/'.$__view.'.php';
    return ob_get_clean();
}
function render(string $__view, array $data = []): void { echo view($__view, $data); }
function abort(int $code, string $msg = ''): void
{
    http_response_code($code);
    $titles = [403 => 'دسترسی غیرمجاز', 404 => 'صفحه یافت نشد', 419 => 'نشست منقضی شد', 500 => 'خطای داخلی سرور'];
    echo view('errors/page', ['code' => $code, 'title' => $titles[$code] ?? 'خطا', 'message' => $msg]);
    exit;
}
function csrf_hidden(): string { return csrf_field(); }

/** خروجی CSV با BOM برای اکسل فارسی */
function csv_download(string $filename, array $headers, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="'.preg_replace('/[^\w\.\-آ-ی]+/u', '_', $filename).'.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, $headers);
    foreach ($rows as $r) fputcsv($out, array_map(fn($v) => is_scalar($v) || $v === null ? (string)$v : json_encode($v, JSON_UNESCAPED_UNICODE), $r));
    fclose($out);
    exit;
}

/** آیکون‌های خطی (SVG درون‌خطی، بدون وابستگی بیرونی) */
function icon(string $name, int $size = 17): string { return icons($name, $size); }
function icons(string $name, int $size = 17): string
{
    $paths = [
        'gauge' => '<path d="M12 13a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"/><path d="M12 12l4-4"/><circle cx="12" cy="12" r="9"/>',
        'users' => '<path d="M16 19v-1a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v1"/><circle cx="9.5" cy="7" r="3.5"/><path d="M17 11a3 3 0 1 0 0-6"/><path d="M21 19v-1a3.5 3.5 0 0 0-2.5-3.3"/>',
        'box' => '<path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="M3 8l9 5 9-5"/><path d="M12 13v8"/>',
        'cart' => '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.4a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21 7H5"/>',
        'wallet' => '<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 10h18"/><path d="M16 14h2"/>',
        'bank' => '<path d="M3 10 12 4l9 6"/><path d="M5 10v9h14v-9"/><path d="M9 19v-5h6v5"/>',
        'warehouse' => '<path d="M3 20V9l9-5 9 5v11"/><path d="M9 20v-6h6v6"/>',
        'coins' => '<ellipse cx="9" cy="7" rx="6" ry="3"/><path d="M3 7v5c0 1.7 2.7 3 6 3"/><ellipse cx="15" cy="14" rx="6" ry="3"/><path d="M9 14v5c0 1.7 2.7 3 6 3s6-1.3 6-3v-5"/>',
        'book' => '<path d="M4 4h7a3 3 0 0 1 3 3v13a2.5 2.5 0 0 0-2.5-2.5H4V4Z"/><path d="M20 4h-3a3 3 0 0 0-3 3v13a2.5 2.5 0 0 1 2.5-2.5H20V4Z"/>',
        'chart' => '<path d="M4 20V10"/><path d="M10 20V4"/><path d="M16 20v-7"/><path d="M22 20H2"/>',
        'cog' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-2.9 1.2 2 2 0 1 1-4 0 1.7 1.7 0 0 0-2.9-1.2l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1A1.7 1.7 0 0 0 3 15a2 2 0 1 1 0-4 1.7 1.7 0 0 0 1.5-2.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1A1.7 1.7 0 0 0 10 4a2 2 0 1 1 4 0 1.7 1.7 0 0 0 2.9 1.5l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1A1.7 1.7 0 0 0 21 11a2 2 0 1 1 0 4Z"/>',
        'lifebuoy' => '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M5.6 5.6 9.5 9.5M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9"/>',
        'star' => '<path d="M12 3.5l2.6 5.6 6 .7-4.4 4.1 1.2 6-5.4-3-5.4 3 1.2-6L3.4 9.8l6-.7L12 3.5Z"/>',
        'dot' => '<circle cx="12" cy="12" r="4"/>',
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'print' => '<path d="M6 9V4h12v5"/><rect x="4" y="9" width="16" height="8" rx="2"/><path d="M8 17h8v4H8z"/>',
        'eye' => '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="2.6"/>',
        'trash' => '<path d="M4 7h16"/><path d="M9 7V5h6v2"/><path d="M6 7l1 13h10l1-13"/>',
        'edit' => '<path d="M4 20h4l10-10-4-4L4 16v4Z"/><path d="M14 6l4 4"/>',
        'search' => '<circle cx="11" cy="11" r="6"/><path d="M20 20l-4.5-4.5"/>',
        'filter' => '<path d="M3 5h18l-7 8v6l-4-2v-4L3 5Z"/>',
        'download' => '<path d="M12 4v10"/><path d="M8 11l4 4 4-4"/><path d="M5 19h14"/>',
        'upload' => '<path d="M12 20V9"/><path d="M8 12l4-4 4 4"/><path d="M5 5h14"/>',
        'receipt' => '<path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/>',
        'cheque' => '<rect x="3" y="6" width="18" height="12" rx="2"/><path d="M6 15c2-3 4-3 6 0"/><path d="M15 10h3"/>',
        'truck' => '<path d="M3 16V6h11v10"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
        'home' => '<path d="M4 11 12 4l8 7"/><path d="M6 11v9h12v-9"/>',
        'bell' => '<path d="M6 16V11a6 6 0 1 1 12 0v5l2 2H4l2-2Z"/><path d="M10 20a2 2 0 0 0 4 0"/>',
        'logout' => '<path d="M15 12H4"/><path d="M8 8l-4 4 4 4"/><path d="M14 4h5v16h-5"/>',
        'user' => '<circle cx="12" cy="8" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
        'calendar' => '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3.5v3M16 3.5v3"/>',
        'money' => '<rect x="3" y="7" width="18" height="10" rx="2"/><circle cx="12" cy="12" r="2.6"/>',
        'file' => '<path d="M7 3h7l4 4v14H7z"/><path d="M14 3v4h4"/>',
        'back' => '<path d="M10 5 5 10l5 5"/><path d="M5 10h9a5 5 0 0 1 0 10H9"/>',
        'check' => '<path d="M5 13l4 4L19 7"/>',
        'x' => '<path d="M6 6l12 12M18 6 6 18"/>',
        'refresh' => '<path d="M20 11a8 8 0 1 0-2.5 6.5"/><path d="M20 5v6h-6"/>',
        'up' => '<path d="M12 19V6"/><path d="M6 12l6-6 6 6"/>',
        'down' => '<path d="M12 5v13"/><path d="M6 12l6 6 6-6"/>',
        'tag' => '<path d="M4 12 12 4h8v8l-8 8-8-8Z"/><circle cx="16" cy="8" r="1.3"/>',
        'list' => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
        'clock' => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
        'shield' => '<path d="M12 3 5 6v6c0 4.4 3 7.7 7 9 4-1.3 7-4.6 7-9V6l-7-3Z"/>',
        'phone' => '<path d="M6 3h3l2 5-2.5 1.5a12 12 0 0 0 6 6L16 13l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 4 5a2 2 0 0 1 2-2Z"/>',
        'mail' => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5 12 13l8.5-6.5"/>',
        'info' => '<circle cx="12" cy="12" r="8.5"/><path d="M12 11v5M12 8.2v.2"/>',
        'spark' => '<path d="M12 3l1.7 4.8L18.5 9.5l-4.8 1.7L12 16l-1.7-4.8L5.5 9.5l4.8-1.7L12 3Z"/><path d="M18.5 15.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2Z"/>',
        'wand' => '<path d="M15 4V2M15 10V8M12 7h-2M20 7h-2M17.5 4.5l1.4-1.4M17.5 9.5l1.4 1.4"/><path d="M3 21l9-9"/>',
        'folder' => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V7Z"/>',
        'lock' => '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.2"/>',
        'key' => '<circle cx="8" cy="15" r="4"/><path d="M11 12 19 4"/><path d="M16 7l2 2"/>',
        'image' => '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="9" r="1.6"/><path d="M4 17l5-5 4 4 3-3 4 4"/>',
    ];
    $p = $paths[$name] ?? $paths['dot'];
    return '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-3px">'.$p.'</svg>';
}

/** ریشه‌یابی درخواست (برای لینک‌های فعال) */
function current_path(): string { return parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/'; }
/** مسیر یک آدرس برنامه — حتی وقتی app.url مطلق است (برای تشخیص منوی فعال) */
function url_path(string $path = ''): string { return parse_url(url($path), PHP_URL_PATH) ?: '/'; }
function is_active(string $prefix): bool { return str_starts_with(current_path(), url_path($prefix)); }
function path_is(string $path): bool { return current_path() === rtrim(url_path($path), '/'); }

/** فرمت سلول گزارش (برای مشترک بین show و print) */
function report_cell(array $m, $v)
{
    if ($v === null || $v === '') return '';
    $t = $m['type'] ?? 'varchar';
    $name = $m['name'] ?? '';
    if (in_array($t, ['decimal', 'double', 'float'], true)) return money($v);
    if (in_array($t, ['int', 'bigint', 'smallint', 'tinyint'], true)) return num($v, 0);
    if (str_ends_with($name, '_at') || str_ends_with($name, '_date')) return jdate((string)$v);
    return e($v);
}


/** دکمه‌های حرفه‌ای «چاپ» و «ذخیره PDF» — برای همهٔ صفحه‌های دارای خروجی چاپ */
function print_buttons(string $printUrl, string $size = ''): string
{
    $cls = 'btn gray' . ($size !== '' ? ' ' . $size : '');
    $is = $size === 'sm' ? 15 : 17;
    $pdfUrl = $printUrl . (str_contains($printUrl, '?') ? '&' : '?') . 'pdf=1';
    return '<a class="' . $cls . '" href="' . e($printUrl) . '" target="_blank" rel="noopener">' . icon('print', $is) . ' چاپ</a> '
         . '<a class="' . $cls . '" href="' . e($pdfUrl) . '" target="_blank" rel="noopener" title="ذخیره به‌صورت PDF">' . icon('file', $is) . ' PDF</a>';
}

/** تبدیل ارقام فارسی/عربی به لاتین + حذف جداکننده‌ها — برای پارس اعداد ورودی کاربر */
function fa_num($v): float
{
    $s = (string)$v;
    $s = en_digits($s);
    $s = strtr($s, [','=>'', '،'=>'', '٬'=>'', ' '=>'', '‌'=>'', 'ریال'=>'', 'تومان'=>'', '٫'=>'.', '−'=>'-', '–'=>'-', '—'=>'-']);
    return (float)$s;
}
