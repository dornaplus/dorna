<?php
/**
 * گزارش مدیریتی خودکار ماهانه — گردآوری داده‌های مالی و تولید گزارش دو صفحه‌ای با هوش مصنوعی.
 */
final class ManagementReport
{
    /** دورهٔ شمسی جاری (مثلاً 1405-07) */
    public static function currentPeriod(): string
    {
        [$y, $m] = current_jalali_ym();
        return $y . '-' . str_pad((string)$m, 2, '0', STR_PAD_LEFT);
    }

    public static function exists(string $period, ?int $biz = null): bool
    {
        $biz = $biz ?? (int)Auth::businessId();
        return (int)Database::val('SELECT COUNT(*) FROM management_reports WHERE business_id=? AND period=?', [$biz, $period], 0) > 0;
    }

    public static function latest(?int $biz = null): ?array
    {
        $biz = $biz ?? (int)Auth::businessId();
        return Database::one('SELECT * FROM management_reports WHERE business_id=? ORDER BY id DESC LIMIT 1', [$biz]);
    }

    public static function get(int $id, ?int $biz = null): ?array
    {
        $biz = $biz ?? (int)Auth::businessId();
        return Database::one('SELECT * FROM management_reports WHERE id=? AND business_id=?', [$id, $biz]);
    }

    public static function list(?int $biz = null): array
    {
        $biz = $biz ?? (int)Auth::businessId();
        return Database::all('SELECT * FROM management_reports WHERE business_id=? ORDER BY id DESC LIMIT 30', [$biz]);
    }

    /** گردآوری دادهٔ مالی برای گزارش */
    public static function data(?int $biz = null): array
    {
        $biz = $biz ?? (int)Auth::businessId();
        $fy = Auth::fiscalYear();
        $fyStart = $fy['start_date'] ?? date('Y-m-d', strtotime(today() . ' -1 year'));
        $fyEnd = $fy['end_date'] ?? today();

        // سود و زیان سال مالی
        $pl = ['revenue' => 0, 'expense' => 0, 'cogs' => 0];
        foreach (Database::all("SELECT a.account_type, ROUND(SUM(l.debit_amount - l.credit_amount),2) AS amt
                                 FROM journal_entry_lines l
                                 JOIN journal_entries e ON e.id = l.journal_entry_id
                                 JOIN chart_of_accounts a ON a.id = l.account_id
                                WHERE e.business_id=? AND e.status='posted' AND e.deleted_at IS NULL
                                  AND e.entry_date BETWEEN ? AND ? AND a.account_type IN ('revenue','expense','cogs')
                                GROUP BY a.account_type", [$biz, $fyStart, $fyEnd]) as $r) {
            $pl[$r['account_type']] = (float)$r['amt'];
        }
        $profit = $pl['revenue'] - $pl['expense'] - $pl['cogs'];

        // نقدینگی
        $cash = (float)Database::val('SELECT IFNULL(SUM(current_balance),0) FROM cash_accounts WHERE business_id=? AND status="active"', [$biz], 0);
        // طلب و بدهی
        $receivable = (float)Database::val("SELECT IFNULL(SUM(remaining_amount),0) FROM invoices WHERE business_id=? AND deleted_at IS NULL AND status='posted' AND invoice_type='sale'", [$biz], 0);
        $payable = (float)Database::val("SELECT IFNULL(SUM(remaining_amount),0) FROM invoices WHERE business_id=? AND deleted_at IS NULL AND status='posted' AND invoice_type='buy'", [$biz], 0);

        // مشتریان برتر (بر اساس فروش)
        $topCustomers = Database::all("SELECT TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS name,
                                              ROUND(SUM(i.total_amount),2) AS amount
                                         FROM invoices i JOIN persons p ON p.id = i.person_id
                                        WHERE i.business_id=? AND i.deleted_at IS NULL AND i.status='posted' AND i.invoice_type='sale'
                                        GROUP BY p.id ORDER BY amount DESC LIMIT 5", [$biz]);

        // هشدارها
        $overdue = (int)Database::val("SELECT COUNT(*) FROM invoices WHERE business_id=? AND settlement_status='overdue' AND status='posted' AND remaining_amount>0 AND deleted_at IS NULL", [$biz], 0);
        $dueCheques = (int)Database::val("SELECT COUNT(*) FROM cheques WHERE business_id=? AND status IN ('in_hand','deposited') AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)", [$biz], 0);
        $lowStock = (int)Database::val('SELECT COUNT(*) FROM v_low_stock WHERE business_id=?', [$biz], 0);

        return [
            'fy_title' => $fy['title'] ?? '',
            'revenue' => $pl['revenue'], 'expense' => $pl['expense'], 'cogs' => $pl['cogs'], 'profit' => $profit,
            'cash' => $cash, 'receivable' => $receivable, 'payable' => $payable,
            'top_customers' => $topCustomers,
            'overdue_invoices' => $overdue, 'due_cheques' => $dueCheques, 'low_stock' => $lowStock,
        ];
    }

    /** تولید گزارش با هوش مصنوعی و ذخیره */
    public static function generate(?int $biz = null): int
    {
        $biz = $biz ?? (int)Auth::businessId();
        $period = self::currentPeriod();
        $d = self::data($biz);
        $content = self::aiContent($d);
        $title = 'گزارش مدیریتی ' . jmonth_name((int)explode('-', $period)[1]) . ' ' . explode('-', $period)[0];
        $id = (int)Database::insert('management_reports', [
            'business_id' => $biz, 'period' => $period, 'title' => $title,
            'content' => $content, 'stats_json' => json_encode($d, JSON_UNESCAPED_UNICODE),
            'status' => 'ready', 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        return $id;
    }

    /** ساخت متن گزارش با AI */
    private static function aiContent(array $d): string
    {
        $top = array_map(fn($t) => '- ' . $t['name'] . ': ' . num($t['amount']), $d['top_customers']);
        $user = "داده‌های مالی کسب‌وکار:\n"
            . 'سال مالی: ' . $d['fy_title'] . "\n"
            . 'درآمد: ' . num($d['revenue']) . " تومان\n"
            . 'هزینه: ' . num($d['expense']) . " تومان\n"
            . 'بهای تمام‌شده: ' . num($d['cogs']) . " تومان\n"
            . 'سود (زیان): ' . num($d['profit']) . " تومان\n"
            . 'موجودی نقد و بانک: ' . num($d['cash']) . " تومان\n"
            . 'طلب از مشتریان: ' . num($d['receivable']) . " تومان\n"
            . 'بدهی به تأمین‌کنندگان: ' . num($d['payable']) . " تومان\n"
            . 'مشتریان برتر: ' . ($top ? implode(' / ', $top) : 'ندارد') . "\n"
            . 'فاکتورهای معوق: ' . $d['overdue_invoices'] . "\n"
            . 'چک‌های نزدیک سررسید: ' . $d['due_cheques'] . "\n"
            . 'کالاهای زیر نقطه سفارش: ' . $d['low_stock'] . "\n";

        $sys = 'تو تحلیلگر مالی یک نرم‌افزار حسابداری ایرانی هستی. یک گزارش مدیریتی فارسی، حرفه‌ای و کوتاه بنویس '
            . 'در قالب این ۵ بخش (هر بخش با عنوان و چند خط):\n'
            . '۱) خلاصهٔ سود و زیان\n۲) وضعیت نقدینگی\n۳) مشتریان\n۴) هشدارها و ریسک‌ها\n۵) سه اقدام پیشنهادی\n'
            . 'اعداد را همان‌طور که داده شده با «تومان» بنویس. لحن: رسمی، روشن، بدون مقدمه.';

        $r = Ai::chat([['role' => 'system', 'content' => $sys], ['role' => 'user', 'content' => $user]], ['max_tokens' => 1400, 'temperature' => 0.3, 'type' => 'management_report']);
        if (empty($r['ok'])) {
            return self::fallbackContent($d);
        }
        $text = trim((string)$r['text']);
        $html = '<div class="mr-report">';
        $inList = false;
        foreach (preg_split('/\r?\n/', $text) as $line) {
            $line = trim($line);
            if ($line === '') continue;
            // پاک‌سازی نشانه‌های مارک‌داون
            $isHeader = (bool)preg_match('/^\*\*[^*]+\*\*$/', $line);
            $plain = preg_replace('/^\*\*|\*\*$/', '', $line);
            $plain = trim($plain);
            if ($plain === '') continue;
            if ($isHeader || preg_match('/^[۰-۹0-9]{1,2}\s*[).،]\s*/u', $plain)) {
                if ($inList) { $html .= '</ul>'; $inList = false; }
                $html .= '<h4>' . e(preg_replace('/^[۰-۹0-9]{1,2}\s*[).،]\s*/u', '', $plain)) . '</h4>';
            } elseif (preg_match('/^[-•]/u', $plain)) {
                if (!$inList) { $html .= '<ul>'; $inList = true; }
                $html .= '<li>' . e(preg_replace('/^[-•]\s*/u', '', $plain)) . '</li>';
            } else {
                if ($inList) { $html .= '</ul>'; $inList = false; }
                $plain = preg_replace('/\*\*(.+?)\*\*/u', '<b>$1</b>', $plain);
                $html .= '<p>' . e($plain) . '</p>';
            }
        }
        if ($inList) $html .= '</ul>';
        $html .= '</div>';
        return $html;
    }

    /** متن جایگزین در صورت خطای AI */
    private static function fallbackContent(array $d): string
    {
        $profit = (float)$d['profit'];
        return '<div class="mr-report">'
            . '<h4>۱) خلاصهٔ سود و زیان</h4>'
            . '<p>درآمد ' . num($d['revenue']) . ' تومان، هزینه ' . num($d['expense']) . ' تومان و بهای تمام‌شده ' . num($d['cogs']) . ' تومان بوده است. سود (زیان) دوره ' . num($profit) . ' تومان است.</p>'
            . '<h4>۲) وضعیت نقدینگی</h4>'
            . '<p>موجودی نقد و بانک ' . num($d['cash']) . ' تومان است. طلب از مشتریان ' . num($d['receivable']) . ' و بدهی به تأمین‌کنندگان ' . num($d['payable']) . ' تومان است.</p>'
            . '<h4>۳) مشتریان</h4><p>' . (($d['top_customers']) ? implode('، ', array_map(fn($t) => $t['name'] . ' (' . num($t['amount']) . ')', $d['top_customers'])) : '—') . '</p>'
            . '<h4>۴) هشدارها</h4><p>فاکتور معوق: ' . $d['overdue_invoices'] . ' — چک نزدیک سررسید: ' . $d['due_cheques'] . ' — کالای زیر نقطه سفارش: ' . $d['low_stock'] . '</p>'
            . '<h4>۵) سه اقدام پیشنهادی</h4><ul><li>پیگیری فاکتورهای معوق و چک‌های نزدیک سررسید</li><li>بررسی موجودی کالاهای زیر نقطه سفارش</li><li>مدیریت جریان نقدی بر اساس ماندهٔ بدهی/طلب</li></ul>'
            . '</div>';
    }
}
