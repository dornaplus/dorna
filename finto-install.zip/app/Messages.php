<?php
/**
 * پیام‌رسان داخلی کاربران + ارسال فایل.
 *  • گفت‌وگوی دو‌نفره (هر جفت کاربر یک گفت‌وگو)، پیام‌ها و فایل‌ها روی سرور ذخیره می‌شوند.
 *  • وضعیت خوانده‌شدن برای هر کاربر جداست و شمارندهٔ نخوانده در هدر نمایش داده می‌شود.
 *  • فایل‌ها بیرون از پوشهٔ وب و فقط برای دو طرف گفت‌وگو قابل دریافت‌اند.
 */
final class Messages
{
    /** پسوندهای مجاز فایل */
    public const DOC_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt', 'zip', 'rar', 'ppt', 'pptx'];
    public const MAX_FILES = 5;
    public const MAX_SIZE = 8388608;   // ۸ مگابایت

    /* ───────────── مسیرها ───────────── */

    public static function dir(int $biz, int $threadId): string
    {
        return storage_path('messages/' . max(0, $biz) . '/' . max(0, $threadId));
    }

    public static function attachmentPath(array $a): string
    {
        return storage_path('messages/' . ltrim((string)$a['storage_key'], '/'));
    }

    /* ───────────── گفت‌وگوها ───────────── */

    private static function canon(int $x, int $y): array { return $x <= $y ? [$x, $y] : [$y, $x]; }

    /** گفت‌وگوی بین کاربر جاری و کاربر دیگر (در صورت نبود ساخته می‌شود) */
    /** اعضای یک گفت‌وگو */
    public static function members(int $threadId): array
    {
        return Database::all('SELECT m.user_id, u.full_name, u.avatar_path FROM pm_thread_members m
                               LEFT JOIN users u ON u.id = m.user_id
                              WHERE m.thread_id = ? ORDER BY u.full_name', [$threadId]);
    }

    public static function isMember(int $threadId, ?int $uid = null): bool
    {
        $uid = $uid ?? (int)Auth::id();
        return (int)Database::val('SELECT COUNT(*) FROM pm_thread_members WHERE thread_id=? AND user_id=?', [$threadId, $uid], 0) > 0;
    }

    private static function addMembers(int $threadId, array $userIds): void
    {
        $biz = (int)Auth::businessId();
        foreach (array_unique(array_map('intval', $userIds)) as $uid) {
            if ($uid <= 0) continue;
            Database::run('INSERT IGNORE INTO pm_thread_members (business_id, thread_id, user_id) VALUES (?,?,?)', [$biz, $threadId, $uid]);
        }
    }

    /** گفت‌وگوی دو‌نفره (در صورت نبود ساخته می‌شود) */
    public static function threadWith(int $otherId, bool $create = true): ?array
    {
        $biz = (int)Auth::businessId();
        $me = (int)Auth::id();
        if ($otherId <= 0 || $otherId === $me) return null;
        $ok = (int)Database::val('SELECT COUNT(*) FROM user_business_roles WHERE business_id=? AND user_id=? AND is_active=1', [$biz, $otherId], 0);
        if (!$ok) return null;
        [$a, $b] = self::canon($me, $otherId);
        $key = $a . '-' . $b;
        $t = Database::one('SELECT * FROM pm_threads WHERE business_id=? AND pair_key=?', [$biz, $key]);
        if (!$t && !$create) return null;
        if (!$t) {
            $id = (int)Database::insert('pm_threads', ['business_id' => $biz, 'user_a' => $a, 'user_b' => $b, 'kind' => 'direct',
                'pair_key' => $key, 'created_at' => now()]);
            $t = Database::one('SELECT * FROM pm_threads WHERE id=?', [$id]);
        }
        if (!self::isMember((int)$t['id'], $me) || !self::isMember((int)$t['id'], $otherId)) self::addMembers((int)$t['id'], [$me, $otherId]);
        return $t;
    }

    /** ساخت گفت‌وگوی گروهی */
    public static function createGroup(string $title, array $memberIds): int
    {
        $biz = (int)Auth::businessId();
        $me = (int)Auth::id();
        $ids = array_values(array_unique(array_filter(array_map('intval', $memberIds), fn($x) => $x > 0 && $x !== $me)));
        if (!$ids) throw new RuntimeException('حداقل یک عضو دیگر را انتخاب کنید.');
        // فقط همکاران همین کسب‌وکار
        $in = implode(',', array_fill(0, count($ids), '?'));
        $valid = array_map('intval', array_column(Database::all(
            "SELECT DISTINCT user_id FROM user_business_roles WHERE business_id=? AND is_active=1 AND user_id IN ($in)", array_merge([$biz], $ids)), 'user_id'));
        if (!$valid) throw new RuntimeException('اعضای انتخاب‌شده در این کسب‌وکار مجاز نیستند.');
        $title = mb_substr(trim($title), 0, 150) ?: 'گروه بدون عنوان';
        $id = (int)Database::insert('pm_threads', ['business_id' => $biz, 'user_a' => $me, 'user_b' => $me, 'kind' => 'group',
            'title' => $title, 'owner_id' => $me, 'pair_key' => null, 'created_at' => now()]);
        self::addMembers($id, array_merge([$me], $valid));
        Audit::log('create', 'pm_threads', $id, 'ساخت گروه «' . $title . '» با ' . (count($valid) + 1) . ' عضو');
        return $id;
    }

    public static function addMemberTo(int $threadId, int $userId): void
    {
        $t = self::thread($threadId);
        if (!$t) throw new RuntimeException('گفت‌وگو یافت نشد.');
        if (!self::isMember($threadId)) throw new RuntimeException('دسترسی ندارید.');
        if ((string)$t['kind'] !== 'group') throw new RuntimeException('افزودن عضو فقط در گروه ممکن است.');
        self::addMembers($threadId, [(int)$userId]);
    }

    /** عنوان نمایشی گفت‌وگو */
    public static function displayName(array $t, ?int $uid = null): string
    {
        if ((string)($t['kind'] ?? 'direct') === 'group') return (string)($t['title'] ?? 'گروه');
        $other = self::otherId($t, $uid);
        return (string)Database::val('SELECT full_name FROM users WHERE id=?', [$other], '—');
    }

    public static function thread(int $id): ?array
    {
        return Database::one('SELECT * FROM pm_threads WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
    }

    public static function canAccess(?array $t, ?int $uid = null): bool
    {
        if (!$t) return false;
        $uid = $uid ?? (int)Auth::id();
        if ((int)$t['user_a'] === $uid || (int)$t['user_b'] === $uid) return true;   // گفت‌وگوی دونفره
        return self::isMember((int)$t['id'], $uid);                                   // گروه/سازگاری
    }

    /** طرف مقابل گفت‌وگو */
    public static function otherId(array $t, ?int $uid = null): int
    {
        $uid = $uid ?? (int)Auth::id();
        return (int)$t['user_a'] === $uid ? (int)$t['user_b'] : (int)$t['user_a'];
    }

    /** فهرست گفت‌وگوهای کاربر با آخرین پیام و تعداد نخوانده */
    public static function threads(?int $uid = null, string $q = '', ?int $businessId = null): array
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $uid = $uid ?? (int)Auth::id();
        $sql = "SELECT t.*,
                       CASE WHEN t.kind = 'direct' THEN (CASE WHEN t.user_a = ? THEN t.user_b ELSE t.user_a END) ELSE 0 END AS other_id,
                       CASE WHEN t.kind = 'group' THEN COALESCE(t.title, 'گروه') ELSE u.full_name END AS other_name,
                       u.avatar_path AS other_avatar,
                       (SELECT COUNT(*) FROM pm_thread_members mm WHERE mm.thread_id = t.id) AS member_count,
                       m.body AS last_body, m.has_file AS last_has_file, m.sender_id AS last_sender, m.created_at AS last_at,
                       (SELECT COUNT(*) FROM pm_messages x
                          LEFT JOIN pm_reads r ON r.thread_id = x.thread_id AND r.user_id = ?
                         WHERE x.thread_id = t.id AND x.sender_id <> ? AND x.id > IFNULL(r.last_read_id, 0)) AS unread
                  FROM pm_threads t
                  JOIN pm_thread_members me ON me.thread_id = t.id AND me.user_id = ?
                  LEFT JOIN pm_thread_members om ON om.thread_id = t.id AND t.kind = 'direct' AND om.user_id <> ?
                  LEFT JOIN users u ON u.id = om.user_id
                  LEFT JOIN pm_messages m ON m.id = t.last_message_id
                 WHERE t.business_id = ?";
        $pr = [$uid, $uid, $uid, $uid, $uid, $biz];   // other_id، read، sender، عضویت من، عضو دیگر، کسب‌وکار
        if (trim($q) !== '') {
            $sql .= " AND (u.full_name LIKE ? OR m.body LIKE ? OR t.subject LIKE ?)";
            $like = '%' . trim($q) . '%'; array_push($pr, $like, $like, $like);
        }
        $sql .= ' ORDER BY IFNULL(t.last_message_at, t.created_at) DESC LIMIT 100';
        return Database::all($sql, $pr);
    }

    /** پیام‌های یک گفت‌وگو */
    public static function messages(int $threadId, int $beforeId = 0, int $limit = 120): array
    {
        $t = self::thread($threadId);
        if (!self::canAccess($t)) return [];
        $sql = 'SELECT m.*, u.full_name AS sender_name, u.avatar_path AS sender_avatar FROM pm_messages m LEFT JOIN users u ON u.id = m.sender_id
                 WHERE m.thread_id = ?';
        $pr = [$threadId];
        if ($beforeId > 0) { $sql .= ' AND m.id < ?'; $pr[] = $beforeId; }
        $sql .= ' ORDER BY m.id DESC LIMIT ' . max(1, min(300, $limit));
        $rows = Database::all($sql, $pr);
        return array_reverse($rows);
    }

    /** پیام‌های جدیدتر از یک شناسه (برای به‌روزرسانی زنده) */
    public static function since(int $threadId, int $afterId = 0): array
    {
        $t = self::thread($threadId);
        if (!self::canAccess($t)) return [];
        return Database::all('SELECT m.*, u.full_name AS sender_name, u.avatar_path AS sender_avatar FROM pm_messages m LEFT JOIN users u ON u.id = m.sender_id
                               WHERE m.thread_id = ? AND m.id > ? ORDER BY m.id ASC LIMIT 100', [$threadId, max(0, $afterId)]);
    }

    /**
     * ارسال پیام (متن و/یا فایل).
     * @param array $files آرایهٔ $_FILES چندگانه یا یک فایل
     * @return array{id:int,files:int}
     */
    public static function send(int $threadId, string $body, array $files = []): array
    {
        $biz = (int)Auth::businessId();
        $t = self::thread($threadId);
        if (!self::canAccess($t)) throw new RuntimeException('دسترسی به این گفت‌وگو ندارید.');
        $body = trim($body);
        $hasFiles = false;
        foreach ($files as $f) if ((int)($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) { $hasFiles = true; break; }
        if ($body === '' && !$hasFiles) throw new RuntimeException('متن پیام یا فایل لازم است.');

        $msgId = (int)Database::insert('pm_messages', ['business_id' => $biz, 'thread_id' => $threadId,
            'sender_id' => (int)Auth::id(), 'body' => $body !== '' ? mb_substr($body, 0, 4000) : null,
            'has_file' => $hasFiles ? 1 : 0, 'created_at' => now()]);
        $saved = self::saveFiles($threadId, $msgId, $files, $biz);
        Database::run('UPDATE pm_threads SET last_message_id=?, last_message_at=NOW() WHERE id=?', [$msgId, $threadId]);
        // فرستنده پیام خودش را خوانده‌شده حساب می‌کند
        self::markRead((int)Auth::id(), $threadId, $msgId);
        Audit::log('create', 'pm_messages', $msgId, 'ارسال پیام در گفت‌وگو #' . $threadId . ($saved ? ' + ' . $saved . ' فایل' : ''));
        return ['id' => $msgId, 'files' => $saved];
    }

    /** ذخیرهٔ فایل‌های پیام */
    private static function saveFiles(int $threadId, int $msgId, array $files, int $biz): int
    {
        $n = 0;
        $dir = self::dir($biz, $threadId);
        foreach (array_slice($files, 0, self::MAX_FILES) as $f) {
            if (!is_array($f) || (int)($f['error'] ?? 4) !== UPLOAD_ERR_OK) continue;
            if ((int)$f['size'] > self::MAX_SIZE) throw new RuntimeException('حجم فایل «' . (string)$f['name'] . '» بیش از ۸ مگابایت است.');
            if (!is_uploaded_file((string)$f['tmp_name'])) continue;
            $orig = (string)$f['name'];
            $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
            if (!in_array($ext, self::DOC_EXT, true)) throw new RuntimeException('فرمت فایل «' . $orig . '» مجاز نیست.');
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) throw new RuntimeException('ساخت پوشهٔ ذخیره ممکن نشد.');
            $safe = 'm' . $msgId . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
            if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $safe)) continue;
            @chmod($dir . '/' . $safe, 0644);
            Database::insert('pm_attachments', ['business_id' => $biz, 'message_id' => $msgId, 'user_id' => (int)Auth::id(),
                'file_name' => mb_substr($orig, 0, 190), 'storage_key' => $biz . '/' . $threadId . '/' . $safe,
                'mime_type' => self::mimeOf($ext), 'size_bytes' => (int)$f['size'], 'created_at' => now()]);
            $n++;
        }
        return $n;
    }

    public static function mimeOf(string $ext): string
    {
        return ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif',
            'pdf' => 'application/pdf', 'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv' => 'text/csv', 'txt' => 'text/plain', 'zip' => 'application/zip', 'rar' => 'application/vnd.rar',
            'ppt' => 'application/vnd.ms-powerpoint', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation'][$ext] ?? 'application/octet-stream';
    }

    public static function attachments(int $messageId): array
    {
        return Database::all('SELECT * FROM pm_attachments WHERE message_id=? ORDER BY id', [$messageId]);
    }

    /** پیوست‌های چند پیام به‌صورت گروهی */
    public static function attachmentsOf(array $messageIds): array
    {
        if (!$messageIds) return [];
        $in = implode(',', array_fill(0, count($messageIds), '?'));
        $out = [];
        foreach (Database::all("SELECT * FROM pm_attachments WHERE message_id IN ($in) ORDER BY id", $messageIds) as $a) {
            $out[(int)$a['message_id']][] = $a;
        }
        return $out;
    }

    public static function attachment(int $id): ?array
    {
        return Database::one('SELECT * FROM pm_attachments WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
    }

    public static function deleteAttachment(int $id): void
    {
        $a = self::attachment($id);
        if (!$a) throw new RuntimeException('فایل یافت نشد.');
        $m = Database::one('SELECT * FROM pm_messages WHERE id=?', [(int)$a['message_id']]);
        $t = $m ? self::thread((int)$m['thread_id']) : null;
        if (!self::canAccess($t)) throw new RuntimeException('دسترسی ندارید.');
        if ((int)$a['user_id'] !== (int)Auth::id() && !Auth::isAdmin()) throw new RuntimeException('فقط فرستنده یا مدیر می‌تواند فایل را حذف کند.');
        $p = self::attachmentPath($a);
        if (is_file($p)) @unlink($p);
        Database::run('DELETE FROM pm_attachments WHERE id=?', [$id]);
    }

    /* ───────────── افزودن پیام به پروندهٔ رویداد ───────────── */

    /**
     * پیام (متن و فایل‌ها) را به پروندهٔ یک رویداد برنامه‌ریز می‌چسباند.
     * فایل‌ها کپی می‌شوند تا حذف بعدی پیام، مدرک رویداد را از بین نبرد.
     */
    public static function toEvent(int $messageId, int $eventId): array
    {
        $biz = (int)Auth::businessId();
        $m = Database::one('SELECT * FROM pm_messages WHERE id=? AND business_id=?', [$messageId, $biz]);
        if (!$m) throw new RuntimeException('پیام یافت نشد.');
        $t = self::thread((int)$m['thread_id']);
        if (!self::canAccess($t)) throw new RuntimeException('دسترسی به این پیام ندارید.');
        $e = Planner::event($eventId);
        if (!$e) throw new RuntimeException('رویداد یافت نشد یا به آن دسترسی ندارید.');
        if (!Planner::canUpdateStatus($e) && !Planner::canEdit($e)) throw new RuntimeException('اجازهٔ افزودن مدرک به این رویداد را ندارید.');

        $sender = (string)Database::val('SELECT full_name FROM users WHERE id=?', [(int)($m['sender_id'] ?? 0)], '—');
        $dir = Planner::attachDir($biz, $eventId);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) throw new RuntimeException('ساخت پوشهٔ مقصد ممکن نشد.');
        $copied = 0;
        foreach (self::attachments($messageId) as $a) {
            $src = self::attachmentPath($a);
            if (!is_file($src)) continue;
            $ext = strtolower(pathinfo((string)$a['file_name'], PATHINFO_EXTENSION));
            $safe = 'pm' . (int)$a['id'] . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . ($ext ? '.' . $ext : '');
            if (!@copy($src, $dir . '/' . $safe)) continue;
            @chmod($dir . '/' . $safe, 0644);
            Database::insert('planner_attachments', ['business_id' => $biz, 'event_id' => $eventId, 'user_id' => (int)Auth::id(),
                'file_name' => (string)$a['file_name'], 'storage_key' => $biz . '/' . $eventId . '/' . $safe,
                'mime_type' => (string)$a['mime_type'], 'size_bytes' => (int)$a['size_bytes'],
                'note' => 'از گفت‌وگوی داخلی — فرستنده: ' . $sender, 'created_at' => now()]);
            $copied++;
        }
        $text = trim((string)($m['body'] ?? ''));
        if ($text !== '') Planner::comment($eventId, 'پیام از گفت‌وگوی داخلی (' . $sender . '): ' . $text);
        Audit::log('create', 'planner_attachments', $eventId, 'افزودن ' . $copied . ' فایل از پیام‌رسان به رویداد #' . $eventId);
        return ['files' => $copied, 'text' => $text !== ''];
    }

    /* ───────────── خوانده‌شدن ───────────── */

    public static function markRead(int $uid, int $threadId, int $lastId = 0): void
    {
        if ($uid <= 0 || $threadId <= 0) return;
        if ($lastId <= 0) $lastId = (int)Database::val('SELECT IFNULL(MAX(id),0) FROM pm_messages WHERE thread_id=?', [$threadId], 0);
        $row = Database::one('SELECT id, last_read_id FROM pm_reads WHERE user_id=? AND thread_id=?', [$uid, $threadId]);
        if ($row) Database::run('UPDATE pm_reads SET last_read_id=GREATEST(last_read_id, ?), updated_at=NOW() WHERE id=?', [$lastId, (int)$row['id']]);
        else Database::insert('pm_reads', ['business_id' => (int)Auth::businessId(), 'user_id' => $uid, 'thread_id' => $threadId,
            'last_read_id' => $lastId, 'updated_at' => now()]);
    }

    public static function unreadTotal(?int $uid = null, ?int $businessId = null): int
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $uid = $uid ?? (int)Auth::id();
        $n = (int)Database::val("SELECT COUNT(*) FROM pm_messages m
                                   JOIN pm_threads t ON t.id = m.thread_id
                                   JOIN pm_thread_members me ON me.thread_id = t.id AND me.user_id = ?
                                   LEFT JOIN pm_reads r ON r.thread_id = m.thread_id AND r.user_id = ?
                                  WHERE t.business_id = ? AND m.sender_id <> ? AND m.id > IFNULL(r.last_read_id, 0)",
            [$uid, $uid, $biz, $uid], 0);
        return $n;
    }

    /** تعداد نخوانده به تفکیک گفت‌وگو */
    public static function unreadByThread(?int $uid = null, ?int $businessId = null): array
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $uid = $uid ?? (int)Auth::id();
        $rows = Database::all("SELECT m.thread_id, COUNT(*) AS n FROM pm_messages m
                                 JOIN pm_threads t ON t.id = m.thread_id
                                 JOIN pm_thread_members me ON me.thread_id = t.id AND me.user_id = ?
                                 LEFT JOIN pm_reads r ON r.thread_id = m.thread_id AND r.user_id = ?
                                WHERE t.business_id = ? AND m.sender_id <> ? AND m.id > IFNULL(r.last_read_id, 0)
                                GROUP BY m.thread_id", [$uid, $uid, $biz, $uid]);
        $out = [];
        foreach ($rows as $r) $out[(int)$r['thread_id']] = (int)$r['n'];
        return $out;
    }

    /* ───────────── خوراک هدر (اعلان پیام‌ها) ───────────── */

    public static function feed(?int $uid = null, int $limit = 8, ?int $businessId = null): array
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $uid = $uid ?? (int)Auth::id();
        $rows = Database::all("SELECT m.id, m.thread_id, m.body, m.has_file, m.created_at, u.full_name AS sender_name, u.avatar_path AS sender_avatar
                                 FROM pm_messages m
                                 JOIN pm_threads t ON t.id = m.thread_id
                                 JOIN pm_thread_members me ON me.thread_id = t.id AND me.user_id = ?
                                 LEFT JOIN users u ON u.id = m.sender_id
                                WHERE t.business_id = ? AND m.sender_id <> ?
                                ORDER BY m.id DESC LIMIT " . max(1, min(30, $limit)), [$uid, $biz, $uid]);
        $unread = self::unreadByThread($uid, $biz);
        $items = [];
        foreach ($rows as $r) {
            $items[] = [
                'id' => (int)$r['id'], 'thread' => (int)$r['thread_id'],
                'from' => (string)($r['sender_name'] ?? '—'),
                'avatar' => Avatar::url((string)($r['sender_avatar'] ?? '')),
                'body' => mb_substr((string)($r['body'] ?? ''), 0, 90),
                'has_file' => (int)$r['has_file'] === 1,
                'unread' => isset($unread[(int)$r['thread_id']]),
                'when' => self::ago((string)$r['created_at']),
                'url' => url('app/messages?t=' . (int)$r['thread_id']),
            ];
        }
        return ['unread' => self::unreadTotal($uid, $biz), 'items' => $items, 'threads' => count($unread)];
    }

    public static function ago(string $at): string
    {
        $ts = strtotime($at); if (!$ts) return '';
        $d = time() - $ts;
        if ($d < 60) return 'همین حالا';
        if ($d < 3600) return floor($d / 60) . ' دقیقه پیش';
        if ($d < 86400) return floor($d / 3600) . ' ساعت پیش';
        if ($d < 604800) return floor($d / 86400) . ' روز پیش';
        return jdate($at, '/');
    }

    /* ───────────── همکاران و جست‌وجو ───────────── */

    public static function colleagues(int $excludeUserId = 0, string $q = '', ?int $businessId = null): array
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $sql = 'SELECT DISTINCT u.id, u.full_name, u.mobile, u.avatar_path FROM users u
                  JOIN user_business_roles ubr ON ubr.user_id = u.id AND ubr.business_id = ? AND ubr.is_active = 1
                 WHERE u.deleted_at IS NULL AND u.is_active = 1 AND u.id <> ?';
        $pr = [$biz, $excludeUserId ?: (int)Auth::id()];
        if (trim($q) !== '') { $sql .= ' AND u.full_name LIKE ?'; $pr[] = '%' . trim($q) . '%'; }
        $sql .= ' ORDER BY u.full_name LIMIT 200';
        return Database::all($sql, $pr);
    }

    /** جست‌وجو در پیام‌های خودم */
    public static function search(int $uid, string $q, int $limit = 50, ?int $businessId = null): array
    {
        $q = trim($q);
        if (mb_strlen($q) < 2) return [];
        $biz = $businessId ?: (int)Auth::businessId();
        return Database::all("SELECT m.*, u.full_name AS sender_name, u.avatar_path AS sender_avatar, t.id AS thread_id, t.kind, t.title,
                                     (CASE WHEN t.kind='direct' THEN (CASE WHEN t.user_a = ? THEN t.user_b ELSE t.user_a END) ELSE 0 END) AS other_id
                                FROM pm_messages m
                                JOIN pm_threads t ON t.id = m.thread_id
                                JOIN pm_thread_members me ON me.thread_id = t.id AND me.user_id = ?
                                LEFT JOIN users u ON u.id = m.sender_id
                               WHERE t.business_id = ? AND m.body LIKE ?
                               ORDER BY m.id DESC LIMIT " . max(1, min(100, $limit)),
            [$uid, $uid, $biz, '%' . $q . '%']);
    }

    public static function fileKind(string $name): array
    {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        return match (true) {
            in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) => ['image', 'تصویر'],
            $ext === 'pdf' => ['file', 'PDF'],
            in_array($ext, ['doc', 'docx'], true) => ['file', 'Word'],
            in_array($ext, ['xls', 'xlsx', 'csv'], true) => ['chart', 'Excel'],
            in_array($ext, ['zip', 'rar'], true) => ['download', 'آرشیو'],
            default => ['file', strtoupper($ext ?: 'فایل')],
        };
    }
}
