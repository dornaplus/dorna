<?php
/**
 * متادیتای نرم‌افزار: منو، ماژول‌ها (جدول↔صفحه)، برچسب‌ها و فهرست گزارش‌ها
 * همه ماژول‌ها روی همان ۱۲۹ جدول دیتابیس سوار می‌شوند و فرم/فهرست از متادیتا ساخته می‌شود.
 */
final class Meta
{
    /** ساختار منوی اصلی (مطابق پنل فینتو: ۱۳ بخش) */
    public const NAV = [
        ['key' => 'dashboard', 'title' => 'داشبورد', 'icon' => 'gauge', 'route' => 'app', 'perm' => 'dashboard.view', 'admin_only' => true, 'items' => []],
        ['key' => 'assistant', 'title' => 'دستیار هوشمند', 'icon' => 'spark', 'items' => [
            ['title' => 'گفت‌وگو با دستیار', 'route' => 'app/assistant'],
        ]],
        ['key' => 'messages', 'title' => 'پیام‌ها', 'icon' => 'mail', 'items' => [
            ['title' => 'پیام‌های داخلی', 'route' => 'app/messages'],
        ]],
        ['key' => 'documents', 'title' => 'اسناد من', 'icon' => 'folder', 'items' => [
            ['title' => 'مدیریت اسناد', 'route' => 'app/documents'],
            ['title' => 'فضای ذخیره‌سازی', 'route' => 'app/storage'],
        ]],
        ['key' => 'planner', 'title' => 'برنامه‌ریز', 'icon' => 'calendar', 'items' => [
            ['title' => 'تقویم و وظایف', 'route' => 'app/planner'],
            ['title' => 'برد پروژه‌ها', 'route' => 'app/planner/board'],
            ['title' => 'تنظیمات برنامه‌ریز', 'route' => 'app/planner/settings', 'perm' => 'settings.view'],
        ]],
        ['key' => 'parties', 'title' => 'اشخاص', 'icon' => 'users', 'perm' => 'persons.view', 'items' => [
            ['title' => 'لیست اشخاص', 'route' => 'app/persons'],
            ['title' => 'تعریف شخص', 'route' => 'app/persons/create'],
            ['title' => 'گروه‌های شخص', 'route' => 'app/person-types'],
            ['title' => 'سهامداران', 'route' => 'app/shareholders'],
            ['title' => 'بازاریاب‌ها', 'route' => 'app/marketers'],
            ['title' => 'پرسنل', 'route' => 'app/employees'],
        ]],
        ['key' => 'catalog', 'title' => 'کالاها و خدمات', 'icon' => 'box', 'perm' => 'products.view', 'items' => [
            ['title' => 'لیست کالاها و خدمات', 'route' => 'app/products'],
            ['title' => 'تعریف کالا و خدمت', 'route' => 'app/products/create'],
            ['title' => 'دسته‌بندی کالا', 'route' => 'app/product-categories'],
            ['title' => 'واحدهای شمارش', 'route' => 'app/units'],
            ['title' => 'انواع قیمت', 'route' => 'app/price-types'],
            ['title' => 'مالیات‌ها', 'route' => 'app/taxes'],
        ]],
        ['key' => 'trade', 'title' => 'خرید و فروش', 'icon' => 'cart', 'perm' => 'invoices.view', 'items' => [
            ['title' => 'ثبت فاکتور فروش', 'route' => 'app/invoices/create?type=sale'],
            ['title' => 'لیست فاکتورهای فروش', 'route' => 'app/invoices?type=sale'],
            ['title' => 'ثبت فاکتور خرید', 'route' => 'app/invoices/create?type=buy'],
            ['title' => 'لیست فاکتورهای خرید', 'route' => 'app/invoices?type=buy'],
            ['title' => 'برگشت از فروش', 'route' => 'app/invoices?type=sale_return'],
            ['title' => 'برگشت از خرید', 'route' => 'app/invoices?type=buy_return'],
            ['title' => 'پیش‌فاکتورها', 'route' => 'app/invoices?type=quote'],
        ]],
        ['key' => 'treasury', 'title' => 'دریافت و پرداخت', 'icon' => 'wallet', 'perm' => 'receipts.view', 'items' => [
            ['title' => 'ثبت دریافت', 'route' => 'app/receipts/create'],
            ['title' => 'لیست دریافت‌ها', 'route' => 'app/receipts'],
            ['title' => 'ثبت پرداخت', 'route' => 'app/payments/create'],
            ['title' => 'لیست پرداخت‌ها', 'route' => 'app/payments'],
        ]],
        ['key' => 'banking', 'title' => 'بانکداری', 'icon' => 'bank', 'perm' => 'cheques.view', 'items' => [
            ['title' => 'موجودی نقد و بانک', 'route' => 'app/cash-accounts'],
            ['title' => 'انتقال بین حساب‌ها', 'route' => 'app/transfers'],
            ['title' => 'چک‌های دریافتی', 'route' => 'app/cheques?direction=received'],
            ['title' => 'چک‌های پرداختی', 'route' => 'app/cheques?direction=issued'],
            ['title' => 'مغایرت بانکی', 'route' => 'app/bank-statements'],
        ]],
        ['key' => 'pettycash', 'title' => 'تنخواه گردان', 'icon' => 'wallet', 'perm' => 'petty_cash.view', 'items' => [
            ['title' => 'داشبورد تنخواه', 'route' => 'app/petty-cash'],
            ['title' => 'تنخواه‌داران', 'route' => 'app/petty-cash/funds'],
            ['title' => 'شارژ تنخواه', 'route' => 'app/petty-cash/create?type=charge', 'perm' => 'petty_cash.create'],
            ['title' => 'ثبت هزینه از تنخواه', 'route' => 'app/petty-cash/create?type=expense', 'perm' => 'petty_cash.create'],
            ['title' => 'برگشت هزینه', 'route' => 'app/petty-cash/create?type=refund', 'perm' => 'petty_cash.create'],
            ['title' => 'تسویه تنخواه', 'route' => 'app/petty-cash/create?type=settle', 'perm' => 'petty_cash.create'],
            ['title' => 'اسناد تنخواه', 'route' => 'app/petty-cash/entries'],
            ['title' => 'گزارشات تنخواه', 'route' => 'app/petty-cash/reports'],
            ['title' => 'کارت تنخواه', 'route' => 'app/petty-cash/reports'],
            ['title' => 'مراکز هزینه', 'route' => 'app/cost-centers'],
        ]],
        ['key' => 'payroll', 'title' => 'حقوق و دستمزد', 'icon' => 'users', 'perm' => 'payroll.view', 'items' => [
            ['title' => 'داشبورد حقوق و دستمزد', 'route' => 'app/payroll'],
            ['title' => 'کارگاه‌ها', 'route' => 'app/payroll/workshops'],
            ['title' => 'پرسنل', 'route' => 'app/employees'],
            ['title' => 'ثبت سند حقوق', 'route' => 'app/payroll-documents/create', 'perm' => 'payroll.create'],
            ['title' => 'لیست حقوق‌ها', 'route' => 'app/payroll-documents'],
            ['title' => 'حقوق مشابه ماه قبل', 'route' => 'app/payroll-documents/create?clone=1', 'perm' => 'payroll.create'],
            ['title' => 'قراردادها', 'route' => 'app/payroll/contracts'],
            ['title' => 'ثبت قرارداد جدید', 'route' => 'app/payroll/contracts/create', 'perm' => 'payroll.create'],
            ['title' => 'مساعده‌ها', 'route' => 'app/payroll/advances'],
            ['title' => 'وام‌ها', 'route' => 'app/payroll/loans'],
            ['title' => 'گزارش جامع حقوق', 'route' => 'app/payroll/report'],
            ['title' => 'تنظیمات حقوق', 'route' => 'app/settings/hr', 'admin_only' => true],
        ]],
        ['key' => 'inventory', 'title' => 'انبارداری', 'icon' => 'warehouse', 'perm' => 'inventory.view', 'items' => [
            ['title' => 'انبارها', 'route' => 'app/warehouses'],
            ['title' => 'ثبت حواله انبار', 'route' => 'app/inventory-documents/create'],
            ['title' => 'لیست اسناد انبار', 'route' => 'app/inventory-documents'],
            ['title' => 'انتقال بین انبارها', 'route' => 'app/stock-transfers'],
            ['title' => 'موجودی کالا', 'route' => 'app/stock-available'],
            ['title' => 'انبارگردانی', 'route' => 'app/stock-counts'],
            ['title' => 'ضایعات', 'route' => 'app/inventory-documents?doc_type=waste'],
            ['title' => 'دلایل ضایعات', 'route' => 'app/waste-reasons'],
        ]],
        ['key' => 'incexp', 'title' => 'درآمد و هزینه', 'icon' => 'coins', 'perm' => 'income_expense.view', 'items' => [
            ['title' => 'ثبت هزینه', 'route' => 'app/expenses/create'],
            ['title' => 'لیست هزینه‌ها', 'route' => 'app/expenses'],
            ['title' => 'ثبت درآمد', 'route' => 'app/incomes/create'],
            ['title' => 'لیست درآمدها', 'route' => 'app/incomes'],
            ['title' => 'دسته‌بندی درآمد و هزینه', 'route' => 'app/pl-categories'],
            ['title' => 'اسناد تکرارشونده', 'route' => 'app/recurring-rules'],
        ]],
        ['key' => 'accounting', 'title' => 'حسابداری', 'icon' => 'book', 'perm' => 'accounting.view', 'items' => [
            ['title' => 'ثبت سند حسابداری', 'route' => 'app/journal/create'],
            ['title' => 'لیست اسناد', 'route' => 'app/journal'],
            ['title' => 'تراز افتتاحیه', 'route' => 'app/opening-balances'],
            ['title' => 'لیست حساب‌ها', 'route' => 'app/chart-of-accounts'],
            ['title' => 'نگاشت حساب‌ها', 'route' => 'app/account-mappings'],
            ['title' => 'قواعد سند خودکار', 'route' => 'app/auto-rules'],
            ['title' => 'اسناد حقوق', 'route' => 'app/payroll-documents'],
            ['title' => 'سال‌های مالی', 'route' => 'app/fiscal-years'],
            ['title' => 'مراکز هزینه', 'route' => 'app/cost-centers'],
        ]],
        ['key' => 'reports', 'title' => 'گزارشات', 'icon' => 'chart', 'perm' => 'reports.view', 'items' => [
            ['title' => 'مرکز گزارش‌ها', 'route' => 'app/reports'],
            ['title' => 'گزارش مدیریتی هوشمند', 'route' => 'app/management-reports'],
            ['title' => 'ناهنجاری‌های اسناد', 'route' => 'app/anomalies'],
            ['title' => 'صورت سود و زیان', 'route' => 'app/reports/income_statement'],
            ['title' => 'ترازنامه', 'route' => 'app/reports/balance_sheet'],
            ['title' => 'دفتر روزنامه', 'route' => 'app/reports/journal_book'],
            ['title' => 'دفتر حساب‌ها', 'route' => 'app/reports/ledger_account'],
            ['title' => 'تراز آزمایشی', 'route' => 'app/reports/trial_balance'],
            ['title' => 'موجودی کالا', 'route' => 'app/reports/inventory_value'],
            ['title' => 'بدهکاران و بستانکاران', 'route' => 'app/reports/receivable_aging'],
            ['title' => 'کارت حساب کالا', 'route' => 'app/reports/stock_card'],
            ['title' => 'سود فاکتورها', 'route' => 'app/reports/profit_per_invoice'],
            ['title' => 'خرید و فروش به تفکیک کالا', 'route' => 'app/reports/sales_by_item'],
            ['title' => 'گزارش مالیات (VAT)', 'route' => 'app/reports/vat_report'],
            ['title' => 'گزارش معاملات فصلی', 'route' => 'app/reports/quarterly_transactions'],
        ]],
        ['key' => 'settings', 'title' => 'تنظیمات', 'icon' => 'cog', 'perm' => 'settings.view', 'admin_only' => true, 'items' => [
            ['title' => 'ویرایش کسب‌وکار', 'route' => 'app/settings/business'],
            ['title' => 'تنظیمات مالی', 'route' => 'app/settings/financial'],
            ['title' => 'تنظیمات چاپ', 'route' => 'app/print-templates'],
            ['title' => 'تنظیمات حقوق و دستمزد', 'route' => 'app/settings/hr'],
            ['title' => 'سطح دسترسی', 'route' => 'app/roles'],
            ['title' => 'کاربران', 'route' => 'app/users'],
            ['title' => 'پروژه‌ها', 'route' => 'app/projects'],
            ['title' => 'روش‌های پرداخت', 'route' => 'app/payment-methods'],
            ['title' => 'شرایط پرداخت', 'route' => 'app/payment-terms'],
            ['title' => 'شماره‌گذاری اسناد', 'route' => 'app/number-sequences'],
            ['title' => 'به‌روزرسانی اطلاعات', 'route' => 'app/import-jobs'],
            ['title' => 'پشتیبان‌گیری', 'route' => 'app/backups'],
            ['title' => 'تنظیمات مودیان', 'route' => 'app/moadian-settings'],
            ['title' => 'درگاه و پرداخت', 'route' => 'app/settings/payment'],
            ['title' => 'نرخ ارز', 'route' => 'app/settings/currency'],
            ['title' => 'گزارش رخدادها', 'route' => 'app/audit-logs'],
        ]],
        ['key' => 'support', 'title' => 'پشتیبانی', 'icon' => 'lifebuoy', 'perm' => 'tickets.view', 'admin_only' => true, 'items' => [
            ['title' => 'تیکت‌های پشتیبانی', 'route' => 'app/tickets'],
            ['title' => 'تیکت جدید', 'route' => 'app/tickets/create'],
        ]],
        ['key' => 'billing', 'title' => 'خرید پکیج', 'icon' => 'star', 'perm' => '', 'admin_only' => true, 'items' => [
            ['title' => 'پکیج‌های اشتراک', 'route' => 'app/plans'],
            ['title' => 'اشتراک من', 'route' => 'app/subscription'],
            ['title' => 'پرداخت‌های اشتراک', 'route' => 'app/subscription-payments'],
        ]],
    ];

    /** ماژول‌ها: هر کلید = یک صفحه فهرست/فرم روی یک جدول */
    public const MODULES = [
        // ── اشخاص ──
        'persons' => ['title' => 'اشخاص', 'singular' => 'شخص', 'table' => 'persons', 'perm' => 'persons', 'icon' => 'users',
            'list' => ['code', 'person_kind', 'first_name', 'last_name', 'company_name', 'mobile', 'national_id', 'city_id', 'status'],
            'search' => ['code','first_name','last_name','company_name','mobile','national_id','economic_code','phone'],
            'filters' => ['person_kind','status','province_id','city_id','marketer_id'],
            'order' => 'id DESC', 'custom' => 'party',
            'children' => [
                ['table' => 'person_contacts', 'fk' => 'person_id', 'title' => 'راه‌های ارتباطی', 'list' => ['contact_type','value','is_primary','label']],
                ['table' => 'person_bank_accounts', 'fk' => 'person_id', 'title' => 'حساب‌های بانکی', 'list' => ['bank_name','account_no','iban','card_no','is_default']],
                ['table' => 'person_product_prices', 'fk' => 'person_id', 'title' => 'قیمت‌های اختصاصی', 'list' => ['product_id','unit_price','discount_percent','from_date','to_date']],
                ['table' => 'person_opening_balances', 'fk' => 'person_id', 'title' => 'مانده افتتاحیه', 'list' => ['fiscal_year_id','debit_amount','credit_amount']],
            ]],
        'person-types' => ['title' => 'گروه‌های شخص', 'singular' => 'گروه شخص', 'table' => 'person_types', 'perm' => 'persons',
            'list' => ['title_fa','slug','is_system','is_active'], 'search' => ['title_fa','slug'], 'order' => 'id'],
        'shareholders' => ['title' => 'سهامداران', 'singular' => 'سهامدار', 'table' => 'shareholders', 'perm' => 'persons',
            'list' => ['person_id','share_percent','share_type','capital_amount','effective_from','effective_to','is_active'], 'search' => [], 'order' => 'id DESC'],
        'marketers' => ['title' => 'بازاریاب‌ها', 'singular' => 'بازاریاب', 'table' => 'marketers', 'perm' => 'persons',
            'list' => ['code','full_name','commission_percent','commission_base','settlement_cycle','region','status'], 'search' => ['code','full_name','region'], 'order' => 'id DESC'],
        'employees' => ['title' => 'پرسنل', 'singular' => 'پرسنل', 'table' => 'employees', 'perm' => 'payroll', 'custom' => 'employee',
            'list' => ['code','full_name','national_id','job_title','department','workshop_id','hire_date','employment_type','status'],
            'search' => ['code','full_name','national_id','job_title','mobile'], 'filters' => ['department','employment_type','status','workshop_id'], 'order' => 'id DESC',
            'children' => [['table' => 'employee_salary_settings', 'fk' => 'employee_id', 'title' => 'تنظیمات حقوق', 'list' => ['base_salary','housing_allowance','food_allowance','child_allowance','other_allowances','insurance_rate_employee','insurance_rate_employee','effective_from']]]],

        // ── کالاها ──
        'products' => ['title' => 'کالاها و خدمات', 'singular' => 'کالا / خدمت', 'table' => 'products', 'perm' => 'products', 'icon' => 'box',
            'list' => ['code','item_type','title','category_id','main_unit_id','cost_method','is_taxable','reorder_point','status'],
            'search' => ['code','title','description'], 'filters' => ['item_type','category_id','status','is_taxable'], 'order' => 'id DESC', 'custom' => 'catalog',
            'children' => [
                ['table' => 'product_units', 'fk' => 'product_id', 'title' => 'واحدها و بارکد', 'list' => ['unit_id','factor','barcode','sale_price']],
                ['table' => 'product_prices', 'fk' => 'product_id', 'title' => 'قیمت‌ها', 'list' => ['price_type_id','price','currency_id','from_date','to_date']],
                ['table' => 'product_variants', 'fk' => 'product_id', 'title' => 'تنوع کالا', 'list' => ['sku','barcode','extra_price','attributes_json']],
                ['table' => 'product_taxes', 'fk' => 'product_id', 'title' => 'مالیات‌ها', 'list' => ['tax_id','is_default']],
                ['table' => 'product_warehouse_settings', 'fk' => 'product_id', 'title' => 'تنظیمات انبار', 'list' => ['warehouse_id','reorder_point','max_stock','default_bin_location']],
            ]],
        'product-categories' => ['title' => 'دسته‌بندی کالا', 'singular' => 'دسته', 'table' => 'product_categories', 'perm' => 'products',
            'list' => ['title','path','parent_id','sort_order','is_active'], 'search' => ['title','path'], 'order' => 'sort_order, id'],
        'units' => ['title' => 'واحدهای شمارش', 'singular' => 'واحد', 'table' => 'units', 'perm' => 'products',
            'list' => ['title','symbol','is_system','is_active'], 'search' => ['title','symbol'], 'order' => 'id'],
        'price-types' => ['title' => 'انواع قیمت', 'singular' => 'نوع قیمت', 'table' => 'price_types', 'perm' => 'products',
            'list' => ['title_fa','slug','is_system','is_active'], 'search' => ['title_fa','slug'], 'order' => 'id'],
        'taxes' => ['title' => 'مالیات‌ها', 'singular' => 'مالیات', 'table' => 'taxes', 'perm' => 'settings',
            'list' => ['title','tax_kind','rate_percent','is_inclusive','account_id','moadian_tax_code','is_active'], 'search' => ['title','moadian_tax_code'], 'order' => 'id'],

        // ── بانکداری و خزانه ──
        'cash-accounts' => ['title' => 'موجودی نقد و بانک', 'singular' => 'حساب نقد/بانک', 'table' => 'cash_accounts', 'perm' => 'cheques',
            'list' => ['code','title','account_kind','bank_name','account_no','iban','opening_balance','current_balance','show_in_dashboard','status'],
            'search' => ['code','title','bank_name','account_no','iban'], 'filters' => ['account_kind','status'], 'order' => 'id'],
        'transfers' => ['title' => 'انتقال‌های وجه', 'singular' => 'انتقال', 'table' => 'transfers', 'perm' => 'transfers',
            'list' => ['doc_no','doc_date','from_cash_account_id','to_cash_account_id','amount','fee_amount','journal_entry_id','status'],
            'search' => ['doc_no','bank_reference','description'], 'filters' => ['from_cash_account_id','to_cash_account_id'], 'order' => 'id DESC', 'no_create' => true],
        'cheques' => ['title' => 'چک‌ها', 'singular' => 'چک', 'table' => 'cheques', 'perm' => 'cheques',
            'list' => ['cheque_no','direction','person_id','bank_name','amount','issue_date','due_date','cash_account_id','status'],
            'search' => ['cheque_no','bank_name','sayad_id'], 'filters' => ['direction','status','bank_name','person_id'], 'order' => 'due_date, id DESC', 'custom' => 'cheque'],
        'bank-statements' => ['title' => 'صورت‌حساب بانکی', 'singular' => 'صورت‌حساب', 'table' => 'bank_statements', 'perm' => 'cheques',
            'list' => ['cash_account_id','from_date','to_date','opening_balance','closing_balance','source','reconciled'], 'search' => [], 'order' => 'id DESC'],

        // ── دریافت و پرداخت ──
        'receipts' => ['title' => 'دریافت‌ها', 'singular' => 'دریافت', 'table' => 'receipts', 'perm' => 'receipts',
            'list' => ['doc_no','doc_date','person_id','cash_account_id','payment_method_id','cheque_id','amount','status'],
            'search' => ['doc_no','bank_reference','description'], 'filters' => ['person_id','cash_account_id','status'], 'order' => 'id DESC', 'custom' => 'treasury'],
        'payments' => ['title' => 'پرداخت‌ها', 'singular' => 'پرداخت', 'table' => 'payments', 'perm' => 'payments',
            'list' => ['doc_no','doc_date','person_id','cash_account_id','payment_method_id','cheque_id','amount','status'],
            'search' => ['doc_no','bank_reference','description'], 'filters' => ['person_id','cash_account_id','status'], 'order' => 'id DESC', 'custom' => 'treasury'],

        // ── درآمد و هزینه ──
        'expenses' => ['title' => 'هزینه‌ها', 'singular' => 'سند هزینه', 'table' => 'expense_documents', 'perm' => 'income_expense',
            'list' => ['doc_no','doc_date','title','expense_category_id','person_id','cash_account_id','amount','status'],
            'search' => ['doc_no','title','description'], 'filters' => ['cash_account_id','expense_category_id','status'], 'order' => 'id DESC', 'custom' => 'incexp'],
        'incomes' => ['title' => 'درآمدها', 'singular' => 'سند درآمد', 'table' => 'income_documents', 'perm' => 'income_expense',
            'list' => ['doc_no','doc_date','title','income_category_id','person_id','cash_account_id','amount','settlement_type','status'],
            'search' => ['doc_no','title','description'], 'filters' => ['cash_account_id','income_category_id','status'], 'order' => 'id DESC', 'custom' => 'incexp'],
        'pl-categories' => ['title' => 'دسته‌بندی درآمد و هزینه', 'singular' => 'دسته', 'table' => 'profit_loss_categories', 'perm' => 'income_expense',
            'list' => ['title','kind','parent_id','default_account_id','is_active'], 'search' => ['title'], 'filters' => ['kind'], 'order' => 'kind, id'],
        'recurring-rules' => ['title' => 'اسناد تکرارشونده', 'singular' => 'قاعده تکرار', 'table' => 'recurring_rules', 'perm' => 'income_expense',
            'list' => ['title','doc_kind','frequency','day_of_period','amount','next_run_date','last_run_date','status'], 'search' => ['title'], 'order' => 'id DESC'],

        // ── انبارداری ──
        'warehouses' => ['title' => 'انبارها', 'singular' => 'انبار', 'table' => 'warehouses', 'perm' => 'inventory',
            'list' => ['code','title','warehouse_type','keeper_user_id','city_id','phone','count_in_reports','status'],
            'search' => ['code','title','address','phone'], 'filters' => ['warehouse_type','status'], 'order' => 'id'],
        'inventory-documents' => ['title' => 'اسناد انبار', 'singular' => 'سند انبار', 'table' => 'inventory_documents', 'perm' => 'inventory',
            'list' => ['doc_no','doc_type','doc_date','warehouse_id','dest_warehouse_id','person_id','total_cost','journal_entry_id','status'],
            'search' => ['doc_no','description'], 'filters' => ['doc_type','warehouse_id','status'], 'order' => 'id DESC', 'custom' => 'stock',
            'children' => [['table' => 'inventory_document_lines', 'fk' => 'document_id', 'title' => 'آرتیکل‌ها', 'list' => ['row_no','product_id','quantity','unit_id','unit_cost','total_cost','waste_reason_id']]]],
        'stock-counts' => ['title' => 'انبارگردانی', 'singular' => 'سند انبارگردانی', 'table' => 'stock_counts', 'perm' => 'inventory',
            'list' => ['doc_no','count_date','warehouse_id','period_type','responsible_user_id','items_count','diff_items_count','diff_value','journal_entry_id','status'],
            'search' => ['doc_no'], 'filters' => ['warehouse_id','status'], 'order' => 'id DESC',
            'children' => [['table' => 'stock_count_lines', 'fk' => 'stock_count_id', 'title' => 'آرتیکل‌ها', 'list' => ['product_id','book_qty','counted_qty','diff_qty','unit_cost','diff_value']]]],
        'stock-available' => ['title' => 'موجودی کالا', 'singular' => 'موجودی', 'table' => 'v_stock_available', 'perm' => 'inventory',
            'list' => ['warehouse_title','product_code','product_title','unit_title','quantity','reserved_quantity','available_quantity','avg_unit_cost','stock_value'],
            'search' => ['product_title','product_code'], 'filters' => ['warehouse_id','category_id'], 'order' => 'product_code', 'readonly' => true],
        'waste-reasons' => ['title' => 'دلایل ضایعات', 'singular' => 'دلیل ضایعات', 'table' => 'waste_reasons', 'perm' => 'inventory',
            'list' => ['title','expense_account_id','is_active'], 'search' => ['title'], 'order' => 'id'],
        'stock-transfers' => ['title' => 'انتقال بین انبارها', 'singular' => 'انتقال انبار', 'table' => 'inventory_documents', 'perm' => 'inventory',
            'list' => ['doc_no','doc_date','warehouse_id','dest_warehouse_id','total_cost','status'],
            'filters' => ['warehouse_id','dest_warehouse_id'], 'order' => 'id DESC', 'custom' => 'stock_transfer', 'readonly' => false],

        // ── حسابداری ──
        'journal' => ['title' => 'اسناد حسابداری', 'singular' => 'سند حسابداری', 'table' => 'journal_entries', 'perm' => 'accounting',
            'list' => ['entry_no','entry_date','entry_type','reference_type','reference_no','total_debit','source','status','is_locked'],
            'search' => ['entry_no','description','reference_no'], 'filters' => ['entry_type','source','status','fiscal_year_id'], 'order' => 'id DESC', 'custom' => 'journal',
            'children' => [['table' => 'journal_entry_lines', 'fk' => 'journal_entry_id', 'title' => 'آرتیکل‌ها', 'list' => ['row_no','account_id','description','debit_amount','credit_amount','person_id','cheque_id']]]],
        'chart-of-accounts' => ['title' => 'لیست حساب‌ها', 'singular' => 'حساب', 'table' => 'chart_of_accounts', 'perm' => 'accounting',
            'list' => ['code','title','full_path','account_type','nature','is_group','person_required','system_role','status'],
            'search' => ['code','title','full_path'], 'filters' => ['account_type','nature','is_group','status'], 'order' => 'code'],
        'account-mappings' => ['title' => 'نگاشت حساب‌ها', 'singular' => 'نگاشت', 'table' => 'account_mappings', 'perm' => 'accounting',
            'list' => ['mapping_key','title_fa','account_id'], 'search' => ['mapping_key','title_fa'], 'order' => 'id'],
        'auto-rules' => ['title' => 'قواعد سند خودکار', 'singular' => 'قاعده', 'table' => 'auto_entry_rules', 'perm' => 'accounting',
            'list' => ['event_key','title_fa','is_enabled','priority','description'], 'search' => ['event_key','title_fa'], 'order' => 'id',
            'children' => [['table' => 'auto_entry_rule_lines', 'fk' => 'rule_id', 'title' => 'آرتیکل‌های قاعده', 'list' => ['row_order','side','account_source','mapping_key','account_id','amount_source']]]],
        'opening-balances' => ['title' => 'تراز افتتاحیه', 'singular' => 'مانده افتتاحیه', 'table' => 'opening_balances', 'perm' => 'accounting',
            'list' => ['fiscal_year_id','account_id','person_id','warehouse_id','debit_amount','credit_amount','is_locked'], 'search' => [], 'order' => 'id DESC', 'custom' => 'opening'],
        'leave-types' => ['title' => 'انواع مرخصی', 'singular' => 'نوع مرخصی', 'table' => 'leave_types', 'perm' => 'payroll.view',
            'list' => ['title','is_paid','annual_quota_days','is_active'], 'search' => ['title'], 'filters' => ['is_paid','is_active'], 'order' => 'title'],
        'attendance-devices' => ['title' => 'دستگاه‌های حضور و غیاب', 'singular' => 'دستگاه', 'table' => 'attendance_devices', 'perm' => 'attendance.view',
            'list' => ['title','device_type','ip_address','location','last_sync_at','status','is_active'], 'search' => ['title','ip_address','location'],
            'filters' => ['device_type','status','is_active'], 'order' => 'title'],
        'payroll-documents' => ['title' => 'اسناد حقوق', 'singular' => 'سند حقوق', 'table' => 'payroll_documents', 'perm' => 'payroll',
            'list' => ['doc_no','doc_date','period_title','employee_count','gross_amount','insurance_employee','insurance_employer','tax_amount','net_amount','status'],
            'search' => ['doc_no','period_title'], 'filters' => ['status','fiscal_year_id'], 'order' => 'id DESC', 'custom' => 'payroll',
            'children' => [['table' => 'payroll_document_lines', 'fk' => 'payroll_document_id', 'title' => 'پرسنل', 'list' => ['employee_id','worked_days','gross_amount','deductions_amount','net_amount']]]],
        'fiscal-years' => ['title' => 'سال‌های مالی', 'singular' => 'سال مالی', 'table' => 'fiscal_years', 'perm' => 'accounting',
            'list' => ['title','start_date','end_date','status','is_current','closed_at'], 'search' => ['title'], 'order' => 'id DESC', 'custom' => 'fiscal',
            'children' => [['table' => 'fiscal_periods', 'fk' => 'fiscal_year_id', 'title' => 'دوره‌ها', 'list' => ['title','start_date','end_date','status','locked_at']]]],
        'cost-centers' => ['title' => 'مراکز هزینه', 'singular' => 'مرکز هزینه', 'table' => 'cost_centers', 'perm' => 'cost_centers',
            'list' => ['code','name','center_type','parent_id','linked_account_id','is_active'], 'search' => ['code','name'], 'order' => 'id'],
        'projects' => ['title' => 'پروژه‌ها', 'singular' => 'پروژه', 'table' => 'projects', 'perm' => 'projects',
            'list' => ['code','name','manager_person_id','start_date','end_date','budget_amount','status'], 'search' => ['code','name'], 'filters' => ['status'], 'order' => 'id DESC'],

        // ── تنظیمات ──
        'users' => ['title' => 'کاربران', 'singular' => 'کاربر', 'table' => 'users', 'perm' => 'users',
            'list' => ['full_name','mobile','email','status','last_login_at','is_active'], 'search' => ['full_name','mobile','email'], 'filters' => ['status'], 'order' => 'id DESC', 'custom' => 'user'],
        'roles' => ['title' => 'نقش‌ها و سطح دسترسی', 'singular' => 'نقش', 'table' => 'roles', 'perm' => 'users',
            'list' => ['name','slug','is_system','description','is_active'], 'search' => ['name','slug'], 'order' => 'id', 'custom' => 'role'],
        'payment-methods' => ['title' => 'روش‌های پرداخت', 'singular' => 'روش پرداخت', 'table' => 'payment_methods', 'perm' => 'settings',
            'list' => ['title_fa','slug','is_system','is_active'], 'search' => ['title_fa','slug'], 'order' => 'id'],
        'payment-terms' => ['title' => 'شرایط پرداخت', 'singular' => 'شرط پرداخت', 'table' => 'payment_terms', 'perm' => 'settings',
            'list' => ['title','days','is_cash','is_active'], 'search' => ['title'], 'order' => 'id'],
        'number-sequences' => ['title' => 'شماره‌گذاری اسناد', 'singular' => 'شماره‌گذاری', 'table' => 'number_sequences', 'perm' => 'settings',
            'list' => ['doc_type','template','next_value','step','reset_yearly'], 'search' => ['doc_type','template'], 'order' => 'id'],
        'print-templates' => ['title' => 'قالب‌های چاپ', 'singular' => 'قالب چاپ', 'table' => 'print_templates', 'perm' => 'printing',
            'list' => ['title','template_type','paper_size','show_logo','show_signature','amount_in_words','is_default','status'],
            'search' => ['title'], 'filters' => ['template_type','status'], 'order' => 'id'],
        'messages' => ['title' => 'پیامک‌های ارسالی', 'singular' => 'پیامک', 'table' => 'messages', 'perm' => 'messages',
            'list' => ['recipient','body','entity_type','status','provider','cost_amount','sent_at'], 'search' => ['recipient','body'], 'filters' => ['status','entity_type'], 'order' => 'id DESC', 'readonly' => true],
        'message-templates' => ['title' => 'قالب‌های پیامک', 'singular' => 'قالب پیامک', 'table' => 'message_templates', 'perm' => 'messages',
            'list' => ['title_fa','event_key','channel','body_template','is_active'], 'search' => ['title_fa','event_key','body_template'], 'order' => 'id'],
        'message-credits' => ['title' => 'اعتبار پیامک', 'singular' => 'تراکنش اعتبار', 'table' => 'message_credits', 'perm' => 'messages',
            'list' => ['tx_type','units','balance_after','unit_price','amount','description'], 'search' => ['description'], 'order' => 'id DESC'],
        'import-jobs' => ['title' => 'به‌روزرسانی اطلاعات', 'singular' => 'کار بارگذاری', 'table' => 'import_jobs', 'perm' => 'settings',
            'list' => ['entity_type','mode','total_rows','success_rows','error_rows','status','started_at','finished_at'], 'search' => ['entity_type'], 'order' => 'id DESC'],
        'backup-jobs' => ['title' => 'پشتیبان‌گیری', 'singular' => 'پشتیبان', 'table' => 'backup_jobs', 'perm' => 'backup',
            'list' => ['job_type','scope','size_mb','status','retention_days','sent_to_email','created_at'], 'search' => [], 'order' => 'id DESC'],
        'moadian-settings' => ['title' => 'تنظیمات سامانه مودیان', 'singular' => 'تنظیمات مودیان', 'table' => 'moadian_settings', 'perm' => 'moadian',
            'list' => ['economic_code','taxpayer_id','certificate_serial','environment','api_base_url','auto_submit','key_created_at'], 'search' => ['economic_code','taxpayer_id'], 'order' => 'id'],
        'audit-logs' => ['title' => 'گزارش رخدادها', 'singular' => 'رخداد', 'table' => 'v_audit_trail', 'perm' => 'settings',
            'list' => ['created_at','user_name','action','entity_type','entity_id','ip_text'], 'search' => ['action','entity_type'], 'filters' => ['action','entity_type'], 'order' => 'log_id DESC', 'readonly' => true],

        // ── پشتیبانی ──
        'tickets' => ['title' => 'تیکت‌های پشتیبانی', 'singular' => 'تیکت', 'table' => 'tickets', 'perm' => 'tickets',
            'list' => ['ticket_no','subject','department_id','request_type','priority','status','last_reply_at','satisfaction_rate'],
            'search' => ['ticket_no','subject','contact_phone'], 'filters' => ['status','priority','request_type','department_id'], 'order' => 'id DESC',
            'children' => [['table' => 'ticket_messages', 'fk' => 'ticket_id', 'title' => 'گفت‌وگو', 'list' => ['user_id','message','is_internal','created_at']]]],
        'subscription-payments' => ['title' => 'پرداخت‌های اشتراک', 'singular' => 'پرداخت اشتراک', 'table' => 'subscription_payments', 'perm' => 'subscription',
            'list' => ['paid_at','amount','payable_amount','payment_gateway','gateway_ref','status'], 'search' => ['gateway_ref'], 'order' => 'id DESC', 'readonly' => true],
        'plans' => ['title' => 'پکیج‌های اشتراک', 'singular' => 'پکیج', 'table' => 'plans', 'perm' => '',
            'list' => ['title','price_amount','included_documents','max_users','sms_credits','is_popular','status'], 'search' => ['title','slug'], 'order' => 'sort_order', 'readonly' => true],
    ];

    public static function module(string $key): ?array
    {
        $m = self::MODULES[$key] ?? null;
        if (!$m) return null;
        $m['key'] = $key;
        $m['table'] = $m['table'] ?? str_replace('-', '_', $key);
        $m['singular'] = $m['singular'] ?? $m['title'];
        $m['search'] = $m['search'] ?? [];
        $m['filters'] = $m['filters'] ?? [];
        $m['order'] = $m['order'] ?? 'id DESC';
        $m['children'] = $m['children'] ?? [];
        $m['perm'] = $m['perm'] ?? '';
        $m['icon'] = $m['icon'] ?? 'dot';
        $m['readonly'] = $m['readonly'] ?? false;
        $m['custom'] = $m['custom'] ?? null;
        $m['list'] = $m['list'] ?? Schema::defaultListColumns($m['table']);
        // پالایش ستون‌های اعلام‌شده بر اساس ستون‌های واقعی جدول/نما (جلوگیری از خطای کوئری)
        $cols = Schema::columns($m['table']);
        $m['list'] = array_values(array_filter($m['list'], fn($c) => isset($cols[$c])));
        $m['search'] = array_values(array_filter($m['search'], fn($c) => isset($cols[$c])));
        $m['filters'] = array_values(array_filter($m['filters'], fn($c) => isset($cols[$c])));
        if (!$m['list']) $m['list'] = Schema::defaultListColumns($m['table']);
        foreach ($m['children'] as $i => $ch) {
            $cc = Schema::columns($ch['table']);
            $m['children'][$i]['list'] = array_values(array_filter($ch['list'] ?? [], fn($c) => isset($cc[$c])));
            if (!$m['children'][$i]['list']) $m['children'][$i]['list'] = Schema::defaultListColumns($ch['table'], 6);
            $m['children'][$i]['title'] = $ch['title'] ?? $ch['table'];
        }
        return $m;
    }

    /** عنوان فارسی مقادیر enum */
    public static function enumLabel(string $value): string
    {
        static $map = [
            // ── ماژول‌های مجوز (برای صفحهٔ نقش‌ها) ──
            'access' => 'دسترسی و نشست', 'accounting' => 'حسابداری', 'api' => 'وب‌سرویس (API)',
            'attendance' => 'حضور و غیاب', 'backup' => 'پشتیبان‌گیری', 'cheques' => 'چک‌ها',
            'cost_centers' => 'مراکز هزینه', 'dashboard' => 'داشبورد', 'income_expense' => 'درآمد و هزینه',
            'inventory' => 'انبارداری', 'invoices' => 'فاکتورها', 'messages' => 'پیامک و پیام‌ها',
            'moadian' => 'سامانهٔ مودیان', 'payments' => 'پرداخت‌ها', 'payroll' => 'حقوق و دستمزد',
            'persons' => 'اشخاص', 'petty_cash' => 'تنخواه گردان', 'printing' => 'چاپ',
            'products' => 'کالاها و خدمات', 'projects' => 'پروژه‌ها', 'receipts' => 'دریافت‌ها',
            'reports' => 'گزارشات', 'settings' => 'تنظیمات', 'subscription' => 'اشتراک',
            'tickets' => 'پشتیبانی (تیکت)', 'transfers' => 'انتقال وجه', 'users' => 'کاربران و نقش‌ها',
            // ── اکشن‌های مجوز ──
            'view' => 'مشاهده', 'create' => 'ثبت', 'edit' => 'ویرایش', 'delete' => 'حذف',
            'print' => 'چاپ', 'export' => 'خروجی گرفتن', 'approve' => 'تأیید', 'lock' => 'قفل', 'submit' => 'ارسال',
            'sale' => 'فروش', 'buy' => 'خرید', 'sale_return' => 'برگشت از فروش', 'buy_return' => 'برگشت از خرید', 'quote' => 'پیش‌فاکتور',
            'cash' => 'نقدی', 'credit' => 'اعتباری', 'cheque' => 'چک', 'mixed' => 'ترکیبی', 'on_account' => 'علی‌الحساب', 'invoice' => 'به تفکیک فاکتور', 'expense' => 'هزینه',
            'draft' => 'پیش‌نویس', 'registered' => 'ثبت شده', 'approved' => 'تأیید شده', 'posted' => 'قطعی', 'cancelled' => 'لغو شده', 'returned' => 'برگشتی',
            'unpaid' => 'پرداخت‌نشده', 'partial' => 'پرداخت جزئی', 'paid' => 'تسویه شده', 'overdue' => 'سررسید گذشته',
            'open' => 'باز', 'locked' => 'قفل', 'closed' => 'بسته', 'closing' => 'در حال بستن',
            'active' => 'فعال', 'inactive' => 'غیرفعال', 'suspended' => 'معلق', 'expired' => 'منقضی', 'trial' => 'آزمایشی', 'revoked' => 'لغو شده',
            'received' => 'دریافتی', 'issued' => 'پرداختی',
            'in_hand' => 'در جریان', 'deposited' => 'واگذار به بانک', 'cleared' => 'وصول شده', 'bounced' => 'برگشتی', 'spent' => 'خرج شده', 'endorsed' => 'واگذار شده',
            'goods' => 'کالا', 'service' => 'خدمت',
            'receive' => 'رسید ورود', 'issue' => 'حواله خروج', 'transfer_in' => 'ورود انتقالی', 'transfer_out' => 'خروج انتقالی',
            'waste' => 'ضایعات', 'count_adjust' => 'اصلاح انبارگردانی', 'opening' => 'افتتاحیه',
            'in' => 'ورود', 'out' => 'خروج',
            'normal' => 'عادی', 'adjustment' => 'اصلاحی', 'payroll' => 'حقوق و دستمزد', 'transfer' => 'انتقال',
            'manual' => 'دستی', 'auto' => 'خودکار', 'import' => 'واردشده',
            'haqiqi' => 'حقیقی', 'hoqoqi' => 'حقوقی',
            // ── پروندهٔ پرسنلی ──
            'male' => 'مرد', 'female' => 'زن', 'single' => 'مجرد', 'married' => 'متأهل',
            'done' => 'پایان‌یافته', 'exempt' => 'معاف', 'in_progress' => 'در جریان', 'not_required' => 'مشمول نیست',
            'full_time' => 'تمام‌وقت', 'part_time' => 'پاره‌وقت', 'contract' => 'قراردادی', 'temporary' => 'موقت',
            'permanent' => 'رسمی', 'intern' => 'کارآموز', 'terminated' => 'پایان همکاری', 'retired' => 'بازنشسته',
            'diploma' => 'دیپلم', 'associate' => 'کاردانی', 'bachelor' => 'کارشناسی', 'master' => 'کارشناسی ارشد', 'phd' => 'دکتری', 'below_diploma' => 'زیر دیپلم',
            'morning' => 'صبح', 'evening' => 'عصر', 'night' => 'شب', 'rotating' => 'چرخشی',
            // ── انواع رخداد گردش حساب ──
            'receipt' => 'دریافت', 'payment' => 'پرداخت', 'transfer_in' => 'انتقال ورودی', 'transfer_out' => 'انتقال خروجی',
            'payroll' => 'سند حقوق', 'advance' => 'مساعدهٔ حقوق', 'loan' => 'وام کارکنان', 'petty_cash' => 'تنخواه گردان',
            'cheque_in' => 'وصول چک', 'cheque_out' => 'پرداخت چک', 'invoice_in' => 'دریافت فاکتور', 'invoice_out' => 'پرداخت فاکتور',
            'expense' => 'هزینه', 'income' => 'درآمد', 'journal' => 'سند دستی', 'reversal' => 'برگشت سند',
            'debit' => 'بدهکار', 'credit' => 'بستانکار',
            'pending' => 'در انتظار', 'answered' => 'پاسخ داده شده', 'question' => 'پرسش', 'bug' => 'ایراد', 'suggestion' => 'پیشنهاد', 'complaint' => 'شکایت', 'billing' => 'مالی',
            'low' => 'کم', 'high' => 'زیاد', 'urgent' => 'فوری',
            'monthly' => 'ماهانه', 'quarterly' => 'فصلی', 'per_invoice' => 'هر فاکتور',
            'net_invoice' => 'خالص فاکتور', 'gross_invoice' => 'کل فاکتور', 'invoice_profit' => 'سود فاکتور',
            'weighted_average' => 'میانگین موزون', 'fifo' => 'اولین صادره از اولین وارده (FIFO)', 'lifo' => 'LIFO',
            'incoming' => 'ورودی', 'outgoing' => 'خروجی', 'sent' => 'ارسال شده', 'failed' => 'ناموفق', 'queued' => 'در صف',
            'pending_review' => 'در انتظار بررسی', 'none' => 'ندارد', 'no' => 'خیر', 'yes' => 'بله', 'customer' => 'مشتری', 'insurance' => 'بیمه',
            'full' => 'کامل', 'partial_amount' => 'جزئی', 'member' => 'عضو', 'owner' => 'مالک', 'admin' => 'مدیر', 'cash_in' => 'واریز', 'cash_out' => 'برداشت',
            'opening_balance' => 'مانده افتتاحیه', 'invoice_payment' => 'پرداخت فاکتور', 'manual_adjust' => 'اصلاح دستی', 'subscription' => 'اشتراک',
            'text' => 'متن', 'boolean' => 'بله/خیر', 'number' => 'عدد', 'json' => 'چندمقداری', 'string' => 'متن', 'bool' => 'بله/خیر',
            'receive_stock' => 'رسید انبار', 'internal_use' => 'مصرف داخلی', 'damaged' => 'آسیب‌دیده', 'expired_item' => 'تاریخ‌گذشته',
        ];
        return $map[$value] ?? $value;
    }

    /** فهرست گزارش‌ها (روی نماهای دیتابیس) */
    /** کلیدهای ماژولی که فقط «مدیر سیستم» باید ببیند (از گروه‌های admin_only منو) */
    public static function adminOnlyModules(): array
    {
        static $cache = null;
        if ($cache !== null) return $cache;
        $keys = [];
        foreach (self::NAV as $g) {
            if (empty($g['admin_only'])) continue;
            $add = static function ($route) use (&$keys) {
                $p = explode('/', ltrim(explode('?', (string)$route)[0], '/'));
                if (!empty($p[0]) && $p[0] === 'app' && !empty($p[1])) $keys[] = (string)$p[1];
            };
            if (!empty($g['key'])) $keys[] = (string)$g['key'];
            $add($g['route'] ?? '');
            foreach (($g['items'] ?? []) as $it) $add($it['route'] ?? '');
        }
        return $cache = array_values(array_unique($keys));
    }

    /** آیا این کلید ماژول ویژهٔ مدیر است؟ */
    public static function isAdminOnlyModule(string $key): bool
    {
        return in_array($key, self::adminOnlyModules(), true);
    }

    public static function reports(): array
    {
        return [
            'dashboard_kpi' => ['title' => 'شاخص‌های مدیریتی', 'view' => 'v_dashboard_kpi', 'group' => 'مدیریتی', 'filters' => []],
            'trial_balance' => ['title' => 'تراز آزمایشی', 'view' => 'v_trial_balance', 'group' => 'حسابداری', 'filters' => ['fiscal_year_id']],
            'journal_book' => ['title' => 'دفتر روزنامه', 'view' => 'v_journal_book', 'group' => 'حسابداری', 'filters' => ['date']],
            'ledger_account' => ['title' => 'دفتر حساب‌ها', 'view' => 'v_ledger_account', 'group' => 'حسابداری', 'filters' => ['account_id','date']],
            'income_statement' => ['title' => 'صورت سود و زیان', 'view' => 'v_income_statement', 'group' => 'مالی', 'filters' => ['date']],
            'balance_sheet' => ['title' => 'ترازنامه', 'view' => 'v_balance_sheet', 'group' => 'مالی', 'filters' => ['date']],
            'equity_changes' => ['title' => 'صورت تغییرات سرمایه', 'view' => 'v_equity_changes', 'group' => 'مالی', 'filters' => []],
            'receivable_aging' => ['title' => 'ریز سنی مطالبات', 'view' => 'v_receivable_aging', 'group' => 'اشخاص', 'filters' => ['person_id']],
            'payable_aging' => ['title' => 'ریز سنی بدهی‌ها', 'view' => 'v_payable_aging', 'group' => 'اشخاص', 'filters' => ['person_id']],
            'person_balances' => ['title' => 'مانده اشخاص', 'view' => 'v_person_balances', 'group' => 'اشخاص', 'filters' => []],
            'sales_by_item' => ['title' => 'فروش به تفکیک کالا', 'view' => 'v_sales_by_item', 'group' => 'خرید و فروش', 'filters' => ['product_id','date']],
            'sales_by_person' => ['title' => 'فروش به تفکیک مشتری', 'view' => 'v_sales_by_person', 'group' => 'خرید و فروش', 'filters' => ['person_id','date']],
            'sales_by_marketer' => ['title' => 'فروش به تفکیک بازاریاب', 'view' => 'v_sales_by_marketer', 'group' => 'خرید و فروش', 'filters' => ['date']],
            'profit_per_invoice' => ['title' => 'سود هر فاکتور', 'view' => 'v_profit_per_invoice', 'group' => 'خرید و فروش', 'filters' => ['date','person_id']],
            'invoice_list' => ['title' => 'فهرست فاکتورها', 'view' => 'v_invoice_list', 'group' => 'خرید و فروش', 'filters' => ['invoice_type','person_id','date']],
            'stock_card' => ['title' => 'کارت حساب کالا', 'view' => 'v_stock_card', 'group' => 'انبار', 'filters' => ['product_id','warehouse_id','date']],
            'stock_available' => ['title' => 'موجودی کالا', 'view' => 'v_stock_available', 'group' => 'انبار', 'filters' => ['warehouse_id','product_id']],
            'inventory_value' => ['title' => 'ارزش موجودی انبار', 'view' => 'v_inventory_value', 'group' => 'انبار', 'filters' => ['warehouse_id']],
            'low_stock' => ['title' => 'کالاهای زیر نقطه سفارش', 'view' => 'v_low_stock', 'group' => 'انبار', 'filters' => ['warehouse_id']],
            'cheques_due' => ['title' => 'چک‌های سررسید نزدیک', 'view' => 'v_cheques_due', 'group' => 'خزانه', 'filters' => []],
            'cash_flow_account' => ['title' => 'گردش حساب بانک/صندوق/تنخواه', 'view' => 'v_cash_flow_account', 'group' => 'خزانه', 'filters' => ['cash_account_id','date']],
            'vat_report' => ['title' => 'گزارش مالیات بر ارزش افزوده', 'view' => 'v_vat_report', 'group' => 'مالیات', 'filters' => ['date']],
            'quarterly_transactions' => ['title' => 'معاملات فصلی', 'view' => 'v_quarterly_transactions', 'group' => 'مالیات', 'filters' => ['date']],
            'audit_trail' => ['title' => 'گزارش رخدادها', 'view' => 'v_audit_trail', 'group' => 'مدیریتی', 'filters' => ['action']],
            'user_activity' => ['title' => 'فعالیت کاربران', 'view' => 'v_user_activity', 'group' => 'مدیریتی', 'filters' => []],
        ];
    }
}
