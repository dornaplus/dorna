<?php
/**
 * مهاجرت‌های سبک و یک‌بارهٔ پایگاه‌داده.
 * هر مهاجرت فقط یک‌بار اجرا و در storage/migrations.json ثبت می‌شود؛
 * تا زمانی که VERSION بالا نرود یا فایل ثبت نباشد، هزینه‌ای به درخواست‌ها تحمیل نمی‌شود.
 */
final class Migrator
{
    public const VERSION = 35;

    public static function run(): void
    {
        try {
            $file = storage_path('migrations.json');
            $state = is_file($file) ? (json_decode((string)@file_get_contents($file), true) ?: []) : [];
            if ((int)($state['version'] ?? 0) >= self::VERSION) return;
            $done = false;
            foreach (self::steps() as [$key, $sql]) {
                if (!empty($state[$key])) continue;
                try {
                    Database::run($sql);
                } catch (Throwable $e) {
                    // فقط خطاهای «قبلاً اعمال‌شده» نادیده گرفته می‌شوند
                    $m = strtolower($e->getMessage());
                    $ok = str_contains($m, 'duplicate') || str_contains($m, "can't drop")
                        || str_contains($m, 'check that column/key exists') || str_contains($m, 'already exists')
                        || str_contains($m, "doesn't exist");
                    if (!$ok) throw $e;
                }
                $state[$key] = date('c');
                $done = true;
            }
            $state['version'] = self::VERSION;
            if ($done || !isset($state['version'])) @file_put_contents($file, json_encode($state, JSON_UNESCAPED_UNICODE));
        } catch (Throwable $e) {
            @file_put_contents(storage_path('error.log'), date('c') . ' | migrate: ' . $e->getMessage() . "\n", FILE_APPEND);
        }
    }

    /** [کلید، دستور SQL] — ترتیب مهم است */
    private static function steps(): array
    {
        return [

            // ── گفت‌وگوی گروهی: ستون‌های نوع/عنوان/کلید جفت + جدول اعضا ──
            ['pm_threads_kind', "ALTER TABLE `pm_threads` ADD COLUMN `kind` ENUM('direct','group') NOT NULL DEFAULT 'direct' COMMENT 'نوع گفت‌وگو' AFTER `user_b`"],
            ['pm_threads_title', "ALTER TABLE `pm_threads` ADD COLUMN `title` VARCHAR(150) NULL COMMENT 'عنوان گروه' AFTER `kind`"],
            ['pm_threads_owner', "ALTER TABLE `pm_threads` ADD COLUMN `owner_id` BIGINT UNSIGNED NULL COMMENT 'سازندهٔ گروه' AFTER `title`"],
            ['pm_threads_pairkey', "ALTER TABLE `pm_threads` ADD COLUMN `pair_key` VARCHAR(40) NULL COMMENT 'کلید یکتای گفت‌وگوی دونفره' AFTER `owner_id`"],
            ['pm_threads_pairkey_backfill', "UPDATE `pm_threads` SET `pair_key` = CONCAT(LEAST(user_a, user_b), '-', GREATEST(user_a, user_b)) WHERE `pair_key` IS NULL"],
            ['pm_threads_drop_pair', "ALTER TABLE `pm_threads` DROP INDEX `uq_pm_pair`"],
            ['pm_threads_pairkey_unique', "ALTER TABLE `pm_threads` ADD UNIQUE KEY `uq_pm_pair_key` (`business_id`, `pair_key`)"],
            ['pm_members_table', "CREATE TABLE IF NOT EXISTS `pm_thread_members` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `thread_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NOT NULL,
                `joined_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), UNIQUE KEY `uq_pm_member` (`thread_id`, `user_id`),
                KEY `ix_pm_member_user` (`user_id`, `thread_id`),
                CONSTRAINT `fk_pm_member_thread` FOREIGN KEY (`thread_id`) REFERENCES `pm_threads` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pm_member_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اعضای گفت‌وگوهای داخلی'"],
            ['pm_members_backfill', "INSERT IGNORE INTO `pm_thread_members` (`business_id`, `thread_id`, `user_id`) SELECT `business_id`, `id`, `user_a` FROM `pm_threads` UNION ALL SELECT `business_id`, `id`, `user_b` FROM `pm_threads`"],
            // ── پیام‌رسان داخلی کاربران + فایل ──
            ['pm_threads_table', "CREATE TABLE IF NOT EXISTS `pm_threads` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_a` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر کم‌شناسه',
                `user_b` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر بیش‌شناسه',
                `subject` VARCHAR(190) NULL,
                `last_message_id` BIGINT UNSIGNED NULL,
                `last_message_at` DATETIME NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_pm_pair` (`business_id`, `user_a`, `user_b`),
                KEY `ix_pm_threads_a` (`business_id`, `user_a`, `last_message_at`),
                KEY `ix_pm_threads_b` (`business_id`, `user_b`, `last_message_at`),
                CONSTRAINT `fk_pm_threads_ua` FOREIGN KEY (`user_a`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pm_threads_ub` FOREIGN KEY (`user_b`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='گفت‌وگوهای داخلی کاربران'"],
            ['pm_messages_table', "CREATE TABLE IF NOT EXISTS `pm_messages` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `thread_id` BIGINT UNSIGNED NOT NULL,
                `sender_id` BIGINT UNSIGNED NULL,
                `body` TEXT NULL,
                `has_file` TINYINT(1) NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_pm_msg_thread` (`thread_id`, `id`),
                CONSTRAINT `fk_pm_msg_thread` FOREIGN KEY (`thread_id`) REFERENCES `pm_threads` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pm_msg_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پیام‌های داخلی'"],
            ['pm_attachments_table', "CREATE TABLE IF NOT EXISTS `pm_attachments` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `message_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NULL,
                `file_name` VARCHAR(190) NOT NULL,
                `storage_key` VARCHAR(400) NOT NULL,
                `mime_type` VARCHAR(120) NOT NULL,
                `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_pm_att_msg` (`message_id`),
                CONSTRAINT `fk_pm_att_msg` FOREIGN KEY (`message_id`) REFERENCES `pm_messages` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فایل‌های پیام‌های داخلی'"],
            ['pm_reads_table', "CREATE TABLE IF NOT EXISTS `pm_reads` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` BIGINT UNSIGNED NOT NULL,
                `thread_id` BIGINT UNSIGNED NOT NULL,
                `last_read_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `updated_at` DATETIME NULL,
                PRIMARY KEY (`id`), UNIQUE KEY `uq_pm_read` (`user_id`, `thread_id`),
                CONSTRAINT `fk_pm_reads_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pm_reads_thread` FOREIGN KEY (`thread_id`) REFERENCES `pm_threads` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='وضعیت خوانده‌شدن گفت‌وگوها'"],
            // ── برنامه‌ریز (پلنر): انواع رویداد، رویدادها، گفت‌وگو ──
            ['planner_types_table', "CREATE TABLE IF NOT EXISTS `planner_types` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `title` VARCHAR(80) NOT NULL COMMENT 'عنوان نوع رویداد',
                `color` VARCHAR(20) NOT NULL DEFAULT 'purple' COMMENT 'رنگ برچسب',
                `icon` VARCHAR(40) NOT NULL DEFAULT 'check' COMMENT 'آیکون',
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `sort_order` SMALLINT NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                `updated_at` DATETIME NULL, `updated_by` BIGINT UNSIGNED NULL,
                `deleted_at` DATETIME NULL, `row_version` INT UNSIGNED NOT NULL DEFAULT 1,
                PRIMARY KEY (`id`), KEY `ix_planner_types_biz` (`business_id`, `is_active`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='انواع رویداد برنامه‌ریز'"],
            ['planner_events_table', "CREATE TABLE IF NOT EXISTS `planner_events` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `type_id` BIGINT UNSIGNED NULL,
                `title` VARCHAR(190) NOT NULL,
                `description` TEXT NULL,
                `location` VARCHAR(190) NULL,
                `start_date` DATE NOT NULL,
                `end_date` DATE NULL,
                `start_time` TIME NULL,
                `end_time` TIME NULL,
                `all_day` TINYINT(1) NOT NULL DEFAULT 1,
                `priority` ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
                `status` ENUM('open','in_progress','done','failed','cancelled') NOT NULL DEFAULT 'open',
                `progress` TINYINT UNSIGNED NOT NULL DEFAULT 0,
                `assignee_user_id` BIGINT UNSIGNED NULL COMMENT 'کاربر مسئول',
                `repeat_rule` ENUM('none','daily','weekly','monthly','yearly') NOT NULL DEFAULT 'none',
                `remind_days` SMALLINT NOT NULL DEFAULT 1,
                `reminded_at` DATETIME NULL,
                `completed_at` DATETIME NULL,
                `completed_by` BIGINT UNSIGNED NULL,
                `completion_note` VARCHAR(500) NULL COMMENT 'توضیح انجام‌شدن/نشدن',
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                `updated_at` DATETIME NULL, `updated_by` BIGINT UNSIGNED NULL,
                `deleted_at` DATETIME NULL, `row_version` INT UNSIGNED NOT NULL DEFAULT 1,
                PRIMARY KEY (`id`),
                KEY `ix_planner_ev_biz_date` (`business_id`, `start_date`),
                KEY `ix_planner_ev_assignee` (`business_id`, `assignee_user_id`, `status`),
                KEY `ix_planner_ev_creator` (`business_id`, `created_by`),
                CONSTRAINT `fk_planner_ev_type` FOREIGN KEY (`type_id`) REFERENCES `planner_types` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_planner_ev_assignee` FOREIGN KEY (`assignee_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_planner_ev_creator` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='رویدادها و وظایف برنامه‌ریز'"],
            // پیوست‌های هر رویداد (تصویر/PDF/Word/Excel) — خارج از پوشهٔ وب
            ['planner_attachments_table', "CREATE TABLE IF NOT EXISTS `planner_attachments` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `event_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NULL COMMENT 'فرستنده',
                `file_name` VARCHAR(190) NOT NULL,
                `storage_key` VARCHAR(400) NOT NULL,
                `mime_type` VARCHAR(120) NOT NULL,
                `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `note` VARCHAR(255) NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_planner_attach_event` (`event_id`),
                CONSTRAINT `fk_planner_attach_event` FOREIGN KEY (`event_id`) REFERENCES `planner_events` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_planner_attach_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فایل‌های ارسالی هر رویداد'"],
            // پیوند هر رویداد/وظیفه به یک پروژه
            ['planner_events_project_id', "ALTER TABLE `planner_events` ADD COLUMN `project_id` BIGINT UNSIGNED NULL COMMENT 'پروژه' AFTER `type_id`"],
            ['planner_events_project_index', "ALTER TABLE `planner_events` ADD INDEX `ix_planner_ev_project` (`business_id`, `project_id`)"],
            ['planner_comments_table', "CREATE TABLE IF NOT EXISTS `planner_comments` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `event_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NULL,
                `body` VARCHAR(600) NOT NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_planner_comments_event` (`event_id`),
                CONSTRAINT `fk_planner_comments_event` FOREIGN KEY (`event_id`) REFERENCES `planner_events` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_planner_comments_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='گفت‌وگوی هر رویداد'"],
            // وضعیت اعلان‌ها: هر کاربر وضعیت خوانده/حذف خودش را دارد
            ['notification_states_table', "CREATE TABLE IF NOT EXISTS `notification_states` (
                `business_id` BIGINT UNSIGNED NOT NULL,
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'کاربر بیننده',
                `notif_key` VARCHAR(80) NOT NULL COMMENT 'کلید یکتای اعلان',
                `read_at` DATETIME NULL,
                `dismissed_at` DATETIME NULL,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                UNIQUE KEY `uq_notif_state` (`business_id`, `user_id`, `notif_key`),
                KEY `ix_notif_state_user` (`business_id`, `user_id`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='وضعیت اعلان‌های هر کاربر'"],
            // گزارش رخدادها: ستون action از ENUM بسته به متن آزاد (تا همهٔ رخدادها ثبت شوند)
            ['audit_action_text', 'ALTER TABLE audit_logs MODIFY action VARCHAR(60) NOT NULL'],
            // نمایه‌های کارایی برای پاک‌سازی بر اساس «سیاست نگهداری»
            ['print_logs_business_index', 'ALTER TABLE print_logs ADD INDEX k_print_logs_biz_date (business_id, printed_at)'],
            ['audit_logs_biz_date_index', 'ALTER TABLE audit_logs ADD INDEX k_audit_logs_biz_date (business_id, created_at)'],
            // با حذف کاربر، رخدادهای او حفظ شوند (کاربر تهی می‌شود) نه اینکه حذف کاربر شکست بخورد
            ['audit_logs_user_fk_drop', 'ALTER TABLE audit_logs DROP FOREIGN KEY fk_audit_logs_user_id'],
            ['audit_logs_user_fk_setnull', 'ALTER TABLE audit_logs ADD CONSTRAINT fk_audit_logs_user_id FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL ON UPDATE RESTRICT'],
            ['audit_logs_createdby_fk_drop', 'ALTER TABLE audit_logs DROP FOREIGN KEY fk_audit_logs_created_by'],
            ['audit_logs_createdby_fk_setnull', 'ALTER TABLE audit_logs ADD CONSTRAINT fk_audit_logs_created_by FOREIGN KEY (created_by) REFERENCES users (id) ON DELETE SET NULL ON UPDATE RESTRICT'],
            // ── چک: وصول/پاس شدن باید به «حساب نقد/بانکِ خودِ چک» سند بزند، نه به نگاشت ثابت «bank» ──
            ['cheque_rules_cash_account',
                "UPDATE `auto_entry_rule_lines` l JOIN `auto_entry_rules` r ON r.id = l.rule_id
                    SET l.`account_source` = 'cash_account'
                  WHERE r.`event_key` IN ('cheque.cleared','cheque.paid') AND l.`account_source` = 'mapping' AND l.`mapping_key` = 'bank'"],
            // ── گزارش گردش حساب نقد/بانک: افزودن هزینه/درآمد نقدی، پرداخت حقوق و ماندهٔ افتتاحیه ──
            ['v_cash_flow_account_v2', "CREATE OR REPLACE VIEW `v_cash_flow_account` AS
SELECT m.business_id, m.fiscal_year_id, m.cash_account_id, ca.title AS cash_account_title, ca.account_kind,
       m.doc_date, m.doc_type, m.doc_no, m.ref_id,
       m.amount_in, m.amount_out,
       SUM(m.amount_in - m.amount_out)
         OVER (PARTITION BY m.cash_account_id ORDER BY m.doc_date, m.ref_id) AS running_balance
FROM (
  SELECT r.business_id, r.fiscal_year_id, r.cash_account_id, r.doc_date, 'receipt' AS doc_type,
         r.doc_no, r.id AS ref_id, r.amount AS amount_in, 0 AS amount_out
    FROM receipts r WHERE r.status <> 'cancelled' AND r.cheque_id IS NULL
  UNION ALL
  SELECT p.business_id, p.fiscal_year_id, p.cash_account_id, p.doc_date, 'payment',
         p.doc_no, p.id, 0, p.amount
    FROM payments p WHERE p.status <> 'cancelled' AND p.cheque_id IS NULL
  UNION ALL
  SELECT t.business_id, t.fiscal_year_id, t.from_cash_account_id, t.doc_date, 'transfer_out',
         t.doc_no, t.id, 0, t.amount + IFNULL(t.fee_amount,0)
    FROM transfers t WHERE t.status <> 'cancelled'
  UNION ALL
  SELECT t.business_id, t.fiscal_year_id, t.to_cash_account_id, t.doc_date, 'transfer_in',
         t.doc_no, t.id, t.amount, 0
    FROM transfers t WHERE t.status <> 'cancelled'
  UNION ALL
  SELECT i.business_id, i.fiscal_year_id, i.cash_account_id, i.invoice_date,
         CONCAT('invoice_', i.invoice_type), i.invoice_no, i.id,
         CASE WHEN i.invoice_type = 'sale'        THEN i.total_amount
              WHEN i.invoice_type = 'buy_return'  THEN i.total_amount ELSE 0 END,
         CASE WHEN i.invoice_type = 'buy'         THEN i.total_amount
              WHEN i.invoice_type = 'sale_return' THEN i.total_amount ELSE 0 END
    FROM invoices i
   WHERE i.status NOT IN ('draft','cancelled') AND i.settlement_type = 'cash' AND i.cash_account_id IS NOT NULL
  UNION ALL
  SELECT c.business_id, NULL, c.cash_account_id, DATE(c.cleared_at), 'cheque_in',
         c.cheque_no, c.id, c.amount, 0
    FROM cheques c WHERE c.direction = 'received' AND c.status = 'cleared' AND c.cleared_at IS NOT NULL
  UNION ALL
  SELECT c.business_id, NULL, c.cash_account_id, DATE(c.cleared_at), 'cheque_out',
         c.cheque_no, c.id, 0, c.amount
    FROM cheques c WHERE c.direction = 'issued' AND c.status = 'cleared' AND c.cleared_at IS NOT NULL
  UNION ALL
  SELECT d.business_id, d.fiscal_year_id, d.cash_account_id, d.doc_date, 'expense',
         d.doc_no, d.id, 0, d.amount
    FROM expense_documents d WHERE d.cash_account_id IS NOT NULL AND d.status = 'posted'
  UNION ALL
  SELECT d.business_id, d.fiscal_year_id, d.cash_account_id, d.doc_date, 'income',
         d.doc_no, d.id, d.amount, 0
    FROM income_documents d WHERE d.cash_account_id IS NOT NULL AND d.status = 'posted'
  UNION ALL
  SELECT pd.business_id, pd.fiscal_year_id, pd.cash_account_id, pd.doc_date, 'payroll',
         pd.doc_no, pd.id, 0, pd.net_amount
    FROM payroll_documents pd WHERE pd.cash_account_id IS NOT NULL AND pd.status = 'paid'
  UNION ALL
  SELECT ob.business_id, ob.fiscal_year_id, ca.id, fy.start_date, 'opening',
         'مانده افتتاحیه', 0,
         CASE WHEN ob.debit_amount >= ob.credit_amount THEN ob.debit_amount - ob.credit_amount ELSE 0 END,
         CASE WHEN ob.credit_amount > ob.debit_amount THEN ob.credit_amount - ob.debit_amount ELSE 0 END
    FROM opening_balances ob
    JOIN cash_accounts ca ON ca.gl_account_id = ob.account_id
    JOIN fiscal_years fy ON fy.id = ob.fiscal_year_id
) m
JOIN cash_accounts ca ON ca.id = m.cash_account_id"],
            ['v_person_balances_v2',
                "CREATE OR REPLACE VIEW `v_person_balances` AS select `x`.`business_id` AS `business_id`,`x`.`fiscal_year_id` AS `fiscal_year_id`,`x`.`person_id` AS `person_id`,`p`.`code` AS `person_code`,coalesce(nullif(trim(concat(ifnull(`p`.`first_name`,''),' ',ifnull(`p`.`last_name`,''))),''),`p`.`company_name`) AS `person_name`,`p`.`person_kind` AS `person_kind`,sum(`x`.`debit_amount`) AS `total_debit`,sum(`x`.`credit_amount`) AS `total_credit`,sum((`x`.`debit_amount` - `x`.`credit_amount`)) AS `balance_amount` from ((select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`jel`.`person_id` AS `person_id`,`jel`.`debit_amount` AS `debit_amount`,`jel`.`credit_amount` AS `credit_amount` from ((`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed')) and (`je`.`entry_type` <> 'opening')))) join `chart_of_accounts` `a` on(((`a`.`id` = `jel`.`account_id`) and (`a`.`person_required` = 1)))) where (`jel`.`person_id` is not null) union all select `ob`.`business_id` AS `business_id`,`ob`.`fiscal_year_id` AS `fiscal_year_id`,`ob`.`person_id` AS `person_id`,`ob`.`debit_amount` AS `debit_amount`,`ob`.`credit_amount` AS `credit_amount` from `person_opening_balances` `ob`) `x` left join `persons` `p` on((`p`.`id` = `x`.`person_id`))) group by `x`.`business_id`,`x`.`fiscal_year_id`,`x`.`person_id`,`p`.`code`,`p`.`first_name`,`p`.`last_name`,`p`.`company_name`,`p`.`person_kind`"],
            ['v_trial_balance_v2',
                "CREATE OR REPLACE VIEW `v_trial_balance` AS select `x`.`business_id` AS `business_id`,`x`.`fiscal_year_id` AS `fiscal_year_id`,`x`.`account_id` AS `account_id`,`a`.`code` AS `account_code`,`a`.`title` AS `account_title`,`a`.`account_type` AS `account_type`,`a`.`nature` AS `nature`,`a`.`level_no` AS `level_no`,sum(`x`.`opening_debit`) AS `opening_debit`,sum(`x`.`opening_credit`) AS `opening_credit`,sum(`x`.`turn_debit`) AS `turn_debit`,sum(`x`.`turn_credit`) AS `turn_credit`,sum((`x`.`opening_debit` + `x`.`turn_debit`)) AS `closing_debit_total`,sum((`x`.`opening_credit` + `x`.`turn_credit`)) AS `closing_credit_total`,sum((((`x`.`opening_debit` - `x`.`opening_credit`) + `x`.`turn_debit`) - `x`.`turn_credit`)) AS `balance_amount` from ((select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`jel`.`account_id` AS `account_id`,0 AS `opening_debit`,0 AS `opening_credit`,`jel`.`debit_amount` AS `turn_debit`,`jel`.`credit_amount` AS `turn_credit` from (`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed')) and (`je`.`entry_type` <> 'opening')))) union all select `ob`.`business_id` AS `business_id`,`ob`.`fiscal_year_id` AS `fiscal_year_id`,`ob`.`account_id` AS `account_id`,`ob`.`debit_amount` AS `debit_amount`,`ob`.`credit_amount` AS `credit_amount`,0 AS `0`,0 AS `0` from `opening_balances` `ob`) `x` join `chart_of_accounts` `a` on((`a`.`id` = `x`.`account_id`))) group by `x`.`business_id`,`x`.`fiscal_year_id`,`x`.`account_id`,`a`.`code`,`a`.`title`,`a`.`account_type`,`a`.`nature`,`a`.`level_no`"],
            ['v_ledger_account_v2',
                "CREATE OR REPLACE VIEW `v_ledger_account` AS select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`jel`.`account_id` AS `account_id`,`a`.`code` AS `account_code`,`a`.`title` AS `account_title`,`a`.`account_type` AS `account_type`,`je`.`id` AS `journal_entry_id`,`je`.`entry_no` AS `entry_no`,`je`.`entry_date` AS `entry_date`,`je`.`entry_type` AS `entry_type`,`jel`.`row_no` AS `row_no`,`jel`.`description` AS `description`,`jel`.`person_id` AS `person_id`,`jel`.`cost_center_id` AS `cost_center_id`,`jel`.`project_id` AS `project_id`,`jel`.`debit_amount` AS `debit_amount`,`jel`.`credit_amount` AS `credit_amount`,sum((`jel`.`debit_amount` - `jel`.`credit_amount`)) OVER (PARTITION BY `je`.`business_id`,`je`.`fiscal_year_id`,`jel`.`account_id` ORDER BY `je`.`entry_date`,`je`.`entry_no`,`jel`.`row_no` )  AS `running_balance` from ((`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed'))))) join `chart_of_accounts` `a` on((`a`.`id` = `jel`.`account_id`)))"],
            ['v_income_statement_v2',
                "CREATE OR REPLACE VIEW `v_income_statement` AS select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`je`.`entry_date` AS `entry_date`,`a`.`id` AS `account_id`,`a`.`code` AS `account_code`,`a`.`title` AS `account_title`,`a`.`account_type` AS `account_type`,`jel`.`cost_center_id` AS `cost_center_id`,`cc`.`name` AS `cost_center_name`,`jel`.`project_id` AS `project_id`,sum(`jel`.`debit_amount`) AS `debit_total`,sum(`jel`.`credit_amount`) AS `credit_total`,sum((case when (`a`.`nature` = 'credit') then (`jel`.`credit_amount` - `jel`.`debit_amount`) else (`jel`.`debit_amount` - `jel`.`credit_amount`) end)) AS `net_amount` from (((`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed'))))) join `chart_of_accounts` `a` on(((`a`.`id` = `jel`.`account_id`) and (`a`.`account_type` in ('revenue','cogs','expense'))))) left join `cost_centers` `cc` on((`cc`.`id` = `jel`.`cost_center_id`))) group by `je`.`business_id`,`je`.`fiscal_year_id`,`je`.`entry_date`,`a`.`id`,`a`.`code`,`a`.`title`,`a`.`account_type`,`jel`.`cost_center_id`,`cc`.`name`,`jel`.`project_id`"],
            ['v_balance_sheet_v2',
                "CREATE OR REPLACE VIEW `v_balance_sheet` AS select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`je`.`entry_date` AS `entry_date`,`a`.`id` AS `account_id`,`a`.`code` AS `account_code`,`a`.`title` AS `account_title`,`a`.`account_type` AS `account_type`,`a`.`level_no` AS `level_no`,sum(`jel`.`debit_amount`) AS `debit_total`,sum(`jel`.`credit_amount`) AS `credit_total`,sum((`jel`.`debit_amount` - `jel`.`credit_amount`)) AS `balance_amount` from ((`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed'))))) join `chart_of_accounts` `a` on(((`a`.`id` = `jel`.`account_id`) and (`a`.`account_type` in ('asset','liability','equity'))))) group by `je`.`business_id`,`je`.`fiscal_year_id`,`je`.`entry_date`,`a`.`id`,`a`.`code`,`a`.`title`,`a`.`account_type`,`a`.`level_no`"],
            ['v_equity_changes_v2',
                "CREATE OR REPLACE VIEW `v_equity_changes` AS select `je`.`business_id` AS `business_id`,`je`.`fiscal_year_id` AS `fiscal_year_id`,`a`.`id` AS `account_id`,`a`.`code` AS `account_code`,`a`.`title` AS `account_title`,min(`je`.`entry_date`) AS `first_entry_date`,max(`je`.`entry_date`) AS `last_entry_date`,sum(`jel`.`debit_amount`) AS `debit_total`,sum(`jel`.`credit_amount`) AS `credit_total`,sum((`jel`.`credit_amount` - `jel`.`debit_amount`)) AS `net_change`,max(`sh`.`shareholder_count`) AS `shareholder_count`,max(`sh`.`declared_capital`) AS `declared_capital` from (((`journal_entry_lines` `jel` join `journal_entries` `je` on(((`je`.`id` = `jel`.`journal_entry_id`) and (`je`.`status` IN ('posted','reversed'))))) join `chart_of_accounts` `a` on(((`a`.`id` = `jel`.`account_id`) and (`a`.`account_type` = 'equity')))) left join (select `shareholders`.`business_id` AS `business_id`,count(0) AS `shareholder_count`,sum(`shareholders`.`capital_amount`) AS `declared_capital` from `shareholders` where (`shareholders`.`effective_to` is null) group by `shareholders`.`business_id`) `sh` on((`sh`.`business_id` = `je`.`business_id`))) group by `je`.`business_id`,`je`.`fiscal_year_id`,`a`.`id`,`a`.`code`,`a`.`title`"],
            // ── بستن سال مالی باید سود/زیان را به «سود و زیان انباشته» ببرد، نه «سرمایه» ──
            ['fiscal_kept_earnings_fix',
                "UPDATE `fiscal_years` fy JOIN `account_mappings` m ON m.business_id = fy.business_id AND m.mapping_key = 'retained_earnings'
                    SET fy.`kept_earnings_account_id` = m.`account_id`
                  WHERE m.`account_id` IS NOT NULL AND fy.`status` <> 'closed'
                    AND (fy.`kept_earnings_account_id` IS NULL OR fy.`kept_earnings_account_id` <> m.`account_id`)"],
            // ── ترمیم یک‌بارهٔ ماندهٔ کارت حساب‌های نقد/بانک از دفتر (رفع مانده‌های کهنهٔ گذشته) ──
            ['cash_balance_resync',
                "UPDATE `cash_accounts` ca
                    SET ca.`current_balance` = (
                        SELECT IFNULL(SUM(l.`debit_amount` - l.`credit_amount`), 0)
                          FROM `journal_entry_lines` l JOIN `journal_entries` e ON e.id = l.`journal_entry_id`
                         WHERE e.`business_id` = ca.`business_id` AND e.`deleted_at` IS NULL
                           AND e.`status` IN ('posted','reversed') AND l.`account_id` = ca.`gl_account_id`)
                  WHERE ca.`gl_account_id` IS NOT NULL"],
            // ── قواعد سند حقوق: مبالغ باید از کلیدهای درست خوانده شوند (ناخالص/بیمه/مالیات/خالص) ──
            ['payroll_rule_amount_sources',
                "UPDATE `auto_entry_rule_lines` l JOIN `auto_entry_rules` r ON r.id = l.`rule_id`
                    SET l.`amount_source` = CASE
                          WHEN l.`side` = 'debit'  AND l.`mapping_key` = 'payroll_expense'   THEN 'expense_total'
                          WHEN l.`side` = 'credit' AND l.`mapping_key` = 'insurance_payable' THEN 'insurance_payable'
                          WHEN l.`side` = 'credit' AND l.`mapping_key` = 'payroll_tax'       THEN 'tax'
                          WHEN l.`side` = 'credit' AND l.`mapping_key` = 'payroll_payable'   THEN 'net'
                          ELSE l.`amount_source` END
                  WHERE r.`event_key` = 'payroll' AND l.`amount_source` = 'amount'"],
            // ── فیدا: حساب‌های بانکی پروفایل (چند حساب، یکی پیش‌فرض) برای چاپ و PDF ──
            ['fida_bank_accounts_table', "CREATE TABLE IF NOT EXISTS `fida_bank_accounts` (
                `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                `user_id` INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
                `bank_name` VARCHAR(80) NOT NULL COMMENT 'نام بانک',
                `account_holder` VARCHAR(120) NOT NULL COMMENT 'نام صاحب حساب',
                `card_no` VARCHAR(32) NULL COMMENT 'شماره کارت',
                `iban` VARCHAR(40) NULL COMMENT 'شماره شبا',
                `account_no` VARCHAR(40) NULL COMMENT 'شماره حساب',
                `is_default` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'حساب پیش‌فرض',
                `is_active` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
                `sort_order` SMALLINT NOT NULL DEFAULT 0 COMMENT 'ترتیب نمایش',
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_fida_bank_user` (`user_id`), KEY `ix_fida_bank_default` (`user_id`, `is_default`)
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='حساب‌های بانکی پروفایل (چاپ و PDF)'"],
            ['fida_settings_show_bank_info', "ALTER TABLE `fida_settings` ADD COLUMN `show_bank_info` TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش اطلاعات حساب بانکی در چاپ و PDF' AFTER `show_types`"],
            // ── ماژول تنخواه گردان (۱۴۰۵/۰۷): جداول، مجوزها و تخصیص نقش‌ها ──
            ['petty_cash_funds_table', "CREATE TABLE IF NOT EXISTS `petty_cash_funds` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `code` VARCHAR(30) NOT NULL,
                `title` VARCHAR(150) NOT NULL,
                `keeper_user_id` BIGINT UNSIGNED NULL,
                `person_id` BIGINT UNSIGNED NULL,
                `gl_account_id` BIGINT UNSIGNED NOT NULL,
                `ceiling_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `low_balance_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `status` ENUM('active','suspended','closed') NOT NULL DEFAULT 'active',
                `note` VARCHAR(255) NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                `updated_at` TIMESTAMP NULL DEFAULT NULL,
                `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), UNIQUE KEY `uq_pcf_code` (`business_id`,`code`), KEY `ix_pcf_keeper` (`business_id`,`keeper_user_id`),
                CONSTRAINT `fk_pcf_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pcf_gl` FOREIGN KEY (`gl_account_id`) REFERENCES `chart_of_accounts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
                CONSTRAINT `fk_pcf_keeper` FOREIGN KEY (`keeper_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_pcf_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنخواه‌های گردان'"],
            ['petty_cash_entries_table', "CREATE TABLE IF NOT EXISTS `petty_cash_entries` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `fiscal_year_id` BIGINT UNSIGNED NULL,
                `fund_id` BIGINT UNSIGNED NOT NULL,
                `doc_no` VARCHAR(30) NOT NULL,
                `doc_date` DATE NOT NULL,
                `entry_type` ENUM('charge','expense','refund','settle') NOT NULL,
                `amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `title` VARCHAR(200) NOT NULL,
                `category_id` BIGINT UNSIGNED NULL,
                `cost_center_id` BIGINT UNSIGNED NULL,
                `person_id` BIGINT UNSIGNED NULL,
                `expense_account_id` BIGINT UNSIGNED NULL,
                `cash_account_id` BIGINT UNSIGNED NULL,
                `reference_no` VARCHAR(80) NULL,
                `description` TEXT NULL,
                `attachment` VARCHAR(255) NULL,
                `status` ENUM('pending','approved','rejected','cancelled') NOT NULL DEFAULT 'approved',
                `requested_by` BIGINT UNSIGNED NULL,
                `approved_by` BIGINT UNSIGNED NULL,
                `approved_at` DATETIME NULL,
                `reject_reason` VARCHAR(255) NULL,
                `journal_entry_id` BIGINT UNSIGNED NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                `updated_at` TIMESTAMP NULL DEFAULT NULL,
                `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), KEY `ix_pce_fund_date` (`business_id`,`fund_id`,`doc_date`), KEY `ix_pce_status` (`business_id`,`status`), KEY `ix_pce_type` (`business_id`,`entry_type`),
                CONSTRAINT `fk_pce_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pce_fund` FOREIGN KEY (`fund_id`) REFERENCES `petty_cash_funds` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_pce_je` FOREIGN KEY (`journal_entry_id`) REFERENCES `journal_entries` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد تنخواه گردان'"],
            ['petty_cash_attachments_table', "CREATE TABLE IF NOT EXISTS `petty_cash_attachments` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `entry_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NULL,
                `file_name` VARCHAR(190) NOT NULL,
                `storage_key` VARCHAR(255) NOT NULL,
                `mime_type` VARCHAR(100) NULL,
                `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`), KEY `ix_pca_entry` (`entry_id`),
                CONSTRAINT `fk_pca_entry` FOREIGN KEY (`entry_id`) REFERENCES `petty_cash_entries` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پیوست اسناد تنخواه'"],
            ['petty_cash_permissions', "INSERT IGNORE INTO `permissions` (`id`, `module`, `action`, `slug`, `title_fa`) VALUES
                (235, 'petty_cash', 'view',    'petty_cash.view',    'مشاهده تنخواه گردان'),
                (236, 'petty_cash', 'create',  'petty_cash.create',  'ثبت سند تنخواه گردان'),
                (237, 'petty_cash', 'edit',    'petty_cash.edit',    'ویرایش سند تنخواه گردان'),
                (238, 'petty_cash', 'approve', 'petty_cash.approve', 'تأیید/رد درخواست تنخواه'),
                (239, 'petty_cash', 'print',   'petty_cash.print',   'چاپ اسناد تنخواه گردان')"],
            ['petty_cash_grants', "INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`, `scope`)
                SELECT r.id, p.id, 'own_business' FROM `roles` r JOIN `permissions` p
                 WHERE r.slug IN ('admin','accountant','warehouse','sales')
                   AND ((r.slug IN ('admin','accountant') AND p.slug IN ('petty_cash.view','petty_cash.create','petty_cash.edit','petty_cash.approve','petty_cash.print'))
                     OR (r.slug IN ('warehouse','sales') AND p.slug IN ('petty_cash.view','petty_cash.create')))"],
            // ── ماژول حقوق و دستمزد (۱۴۰۵/۰۷): کارگاه، اعضای کارگاه، مساعده، وام ──
            ['payroll_workshops_table', "CREATE TABLE IF NOT EXISTS `payroll_workshops` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `code` VARCHAR(30) NOT NULL,
                `title` VARCHAR(150) NOT NULL,
                `workshop_type` ENUM('project','site','branch','unit') NOT NULL DEFAULT 'project',
                `manager_person_id` BIGINT UNSIGNED NULL,
                `manager_user_id` BIGINT UNSIGNED NULL,
                `city_id` BIGINT UNSIGNED NULL,
                `address` VARCHAR(255) NULL,
                `start_date` DATE NULL, `end_date` DATE NULL,
                `cost_center_id` BIGINT UNSIGNED NULL,
                `budget_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `status` ENUM('active','suspended','closed') NOT NULL DEFAULT 'active',
                `note` VARCHAR(255) NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL, `updated_at` TIMESTAMP NULL DEFAULT NULL, `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), UNIQUE KEY `uq_workshop_code` (`business_id`,`code`), KEY `ix_workshop_status` (`business_id`,`status`),
                CONSTRAINT `fk_workshop_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_workshop_manager_person` FOREIGN KEY (`manager_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_workshop_manager_user` FOREIGN KEY (`manager_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_workshop_cost_center` FOREIGN KEY (`cost_center_id`) REFERENCES `cost_centers` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کارگاه‌های حقوق و دستمزد'"],
            ['payroll_workshop_employees_table', "CREATE TABLE IF NOT EXISTS `payroll_workshop_employees` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `workshop_id` BIGINT UNSIGNED NOT NULL,
                `employee_id` BIGINT UNSIGNED NOT NULL,
                `role_title` VARCHAR(100) NULL, `daily_wage` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `from_date` DATE NULL, `to_date` DATE NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `created_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), UNIQUE KEY `uq_workshop_employee` (`workshop_id`,`employee_id`),
                CONSTRAINT `fk_we_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_we_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `payroll_workshops` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_we_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پرسنل هر کارگاه'"],
            ['employee_advances_table', "CREATE TABLE IF NOT EXISTS `employee_advances` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `business_id` BIGINT UNSIGNED NOT NULL, `fiscal_year_id` BIGINT UNSIGNED NULL,
                `employee_id` BIGINT UNSIGNED NOT NULL, `doc_no` VARCHAR(30) NOT NULL, `doc_date` DATE NOT NULL,
                `amount` DECIMAL(18,2) NOT NULL DEFAULT 0, `installments` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
                `installment_amount` DECIMAL(18,2) NOT NULL DEFAULT 0, `settled_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `cash_account_id` BIGINT UNSIGNED NULL, `workshop_id` BIGINT UNSIGNED NULL, `request_note` VARCHAR(255) NULL,
                `status` ENUM('open','settled','cancelled') NOT NULL DEFAULT 'open', `journal_entry_id` BIGINT UNSIGNED NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL, `updated_at` TIMESTAMP NULL DEFAULT NULL, `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), KEY `ix_adv_employee` (`business_id`,`employee_id`,`status`),
                CONSTRAINT `fk_adv_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_adv_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_adv_cash` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_adv_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `payroll_workshops` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='مساعدهٔ حقوق پرسنل'"],
            ['employee_loans_table', "CREATE TABLE IF NOT EXISTS `employee_loans` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `business_id` BIGINT UNSIGNED NOT NULL, `fiscal_year_id` BIGINT UNSIGNED NULL,
                `employee_id` BIGINT UNSIGNED NOT NULL, `loan_no` VARCHAR(30) NOT NULL, `loan_date` DATE NOT NULL,
                `amount` DECIMAL(18,2) NOT NULL DEFAULT 0, `installments` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
                `installment_amount` DECIMAL(18,2) NOT NULL DEFAULT 0, `paid_amount` DECIMAL(18,2) NOT NULL DEFAULT 0,
                `cash_account_id` BIGINT UNSIGNED NULL, `guarantor_person_id` BIGINT UNSIGNED NULL, `purpose` VARCHAR(255) NULL,
                `status` ENUM('active','settled','cancelled') NOT NULL DEFAULT 'active', `journal_entry_id` BIGINT UNSIGNED NULL,
                `is_active` TINYINT(1) NOT NULL DEFAULT 1, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL, `updated_at` TIMESTAMP NULL DEFAULT NULL, `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), KEY `ix_loan_employee` (`business_id`,`employee_id`,`status`),
                CONSTRAINT `fk_loan_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_loan_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_loan_cash` FOREIGN KEY (`cash_account_id`) REFERENCES `cash_accounts` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                CONSTRAINT `fk_loan_guarantor` FOREIGN KEY (`guarantor_person_id`) REFERENCES `persons` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='وام کارکنان'"],
            ['payroll_documents_workshop_cols', "ALTER TABLE `payroll_documents`
                ADD COLUMN `workshop_id` BIGINT UNSIGNED NULL COMMENT 'کارگاه' AFTER `cost_center_id`,
                ADD COLUMN `period_year` SMALLINT UNSIGNED NULL COMMENT 'سال دوره' AFTER `period_title`,
                ADD COLUMN `period_month` TINYINT UNSIGNED NULL COMMENT 'ماه دوره' AFTER `period_year`,
                ADD COLUMN `advance_total` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع کسر مساعده' AFTER `deductions_amount`,
                ADD COLUMN `loan_total` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع کسر وام' AFTER `advance_total`,
                ADD KEY `ix_payroll_workshop` (`business_id`,`workshop_id`)"],
            ['payroll_lines_advance_cols', "ALTER TABLE `payroll_document_lines`
                ADD COLUMN `advance_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'کسر مساعده' AFTER `deductions_amount`,
                ADD COLUMN `loan_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'کسر وام' AFTER `advance_amount`"],
            ['employees_full_profile', "ALTER TABLE `employees` ADD COLUMN `father_name` VARCHAR(80) NULL COMMENT 'نام پدر' AFTER `full_name`, ADD COLUMN `id_card_no` VARCHAR(20) NULL COMMENT 'شماره شناسنامه' AFTER `national_id`, ADD COLUMN `id_card_issue_place` VARCHAR(80) NULL COMMENT 'محل صدور شناسنامه' AFTER `id_card_no`, ADD COLUMN `birth_date` DATE NULL COMMENT 'تاریخ تولد' AFTER `id_card_issue_place`, ADD COLUMN `birth_place` VARCHAR(80) NULL COMMENT 'محل تولد' AFTER `birth_date`, ADD COLUMN `gender` ENUM('male','female') NULL COMMENT 'جنسیت' AFTER `birth_place`, ADD COLUMN `marital_status` ENUM('single','married') NULL COMMENT 'وضعیت تاهل' AFTER `gender`, ADD COLUMN `children_count` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد فرزند' AFTER `marital_status`, ADD COLUMN `military_status` ENUM('done','exempt','in_progress','not_required') NULL COMMENT 'وضعیت خدمت سربازی' AFTER `children_count`, ADD COLUMN `education_level` VARCHAR(60) NULL COMMENT 'مدرک تحصیلی' AFTER `military_status`, ADD COLUMN `field_of_study` VARCHAR(100) NULL COMMENT 'رشتهٔ تحصیلی' AFTER `education_level`, ADD COLUMN `mobile` VARCHAR(20) NULL COMMENT 'موبایل' AFTER `field_of_study`, ADD COLUMN `phone` VARCHAR(20) NULL COMMENT 'تلفن' AFTER `mobile`, ADD COLUMN `email` VARCHAR(120) NULL COMMENT 'ایمیل' AFTER `phone`, ADD COLUMN `address` VARCHAR(255) NULL COMMENT 'نشانی' AFTER `email`, ADD COLUMN `postal_code` VARCHAR(15) NULL COMMENT 'کد پستی' AFTER `address`, ADD COLUMN `province_id` SMALLINT UNSIGNED NULL COMMENT 'استان' AFTER `postal_code`, ADD COLUMN `city_id` SMALLINT UNSIGNED NULL COMMENT 'شهر' AFTER `province_id`, ADD COLUMN `emergency_name` VARCHAR(120) NULL COMMENT 'نام تماس اضطراری' AFTER `city_id`, ADD COLUMN `emergency_phone` VARCHAR(20) NULL COMMENT 'تلفن تماس اضطراری' AFTER `emergency_name`, ADD COLUMN `workshop_id` BIGINT UNSIGNED NULL COMMENT 'کارگاه محل خدمت' AFTER `emergency_phone`, ADD COLUMN `manager_employee_id` BIGINT UNSIGNED NULL COMMENT 'سرپرست' AFTER `workshop_id`, ADD COLUMN `contract_end_date` DATE NULL COMMENT 'پایان قرارداد' AFTER `termination_date`, ADD COLUMN `shift_title` VARCHAR(60) NULL COMMENT 'شیفت کاری' AFTER `contract_end_date`, ADD COLUMN `insurance_start_date` DATE NULL COMMENT 'شروع بیمه' AFTER `shift_title`, ADD COLUMN `tax_file_no` VARCHAR(30) NULL COMMENT 'شماره پرونده مالیاتی' AFTER `insurance_start_date`, ADD COLUMN `bank_name` VARCHAR(80) NULL COMMENT 'نام بانک' AFTER `tax_file_no`, ADD COLUMN `account_no` VARCHAR(40) NULL COMMENT 'شماره حساب' AFTER `bank_name`, ADD COLUMN `iban` VARCHAR(40) NULL COMMENT 'شبا' AFTER `account_no`, ADD COLUMN `card_no` VARCHAR(30) NULL COMMENT 'شماره کارت' AFTER `iban`, ADD COLUMN `photo` VARCHAR(255) NULL COMMENT 'عکس پرسنلی' AFTER `card_no`, ADD COLUMN `note` VARCHAR(255) NULL COMMENT 'ملاحظات' AFTER `photo`"],
            ['employees_workshop_index', "ALTER TABLE `employees` ADD KEY `ix_employees_workshop` (`business_id`,`workshop_id`)"],
            ['employees_national_index', "ALTER TABLE `employees` ADD KEY `ix_employees_national` (`business_id`,`national_id`)"],
            ['employees_geo_types', "ALTER TABLE `employees`
                MODIFY `province_id` SMALLINT UNSIGNED NULL COMMENT 'استان',
                MODIFY `city_id` SMALLINT UNSIGNED NULL COMMENT 'شهر'"],
            ['employees_profile_fks', "ALTER TABLE `employees`
                ADD CONSTRAINT `fk_employees_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `payroll_workshops` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                ADD CONSTRAINT `fk_employees_province` FOREIGN KEY (`province_id`) REFERENCES `provinces` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                ADD CONSTRAINT `fk_employees_city` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT,
                ADD CONSTRAINT `fk_employees_manager` FOREIGN KEY (`manager_employee_id`) REFERENCES `employees` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT"],
            ['payroll_components_account_nullable', "ALTER TABLE `payroll_components` MODIFY `account_id` BIGINT UNSIGNED NULL COMMENT 'حساب مرتبط (اختیاری)'"],
            ['auto_rule_amount_source_payroll', "ALTER TABLE `auto_entry_rule_lines` MODIFY `amount_source` ENUM('invoice_total','invoice_net','tax','charges','cogs','amount','paid','remaining','net','insurance_payable','payroll_tax','expense_total','advance_total','loan_total','deduction_total') NOT NULL COMMENT 'منبع مبلغ'"],
            ['v_balance_sheet_v3', "CREATE OR REPLACE VIEW `v_balance_sheet` AS
SELECT x.business_id, x.fiscal_year_id, x.entry_date, x.account_id, x.account_code, x.account_title, x.account_type, x.level_no,
       x.debit_total, x.credit_total, x.balance_amount
FROM (
  SELECT je.business_id, je.fiscal_year_id, je.entry_date, a.id AS account_id, a.code AS account_code,
         a.title AS account_title, a.account_type, a.level_no,
         SUM(jel.debit_amount) AS debit_total, SUM(jel.credit_amount) AS credit_total,
         SUM(jel.debit_amount - jel.credit_amount) AS balance_amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status IN ('posted','reversed')
    JOIN chart_of_accounts a ON a.id = jel.account_id AND a.account_type IN ('asset','liability','equity')
   GROUP BY je.business_id, je.fiscal_year_id, je.entry_date, a.id, a.code, a.title, a.account_type, a.level_no
  UNION ALL
  SELECT je.business_id, je.fiscal_year_id, MAX(je.entry_date) AS entry_date, NULL AS account_id, '9999' AS account_code,
         'سود (زیان) دورهٔ جاری' AS account_title, 'equity' AS account_type, 3 AS level_no,
         SUM(jel.credit_amount) AS debit_total, SUM(jel.debit_amount) AS credit_total,
         SUM(jel.debit_amount - jel.credit_amount) AS balance_amount
    FROM journal_entry_lines jel
    JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status IN ('posted','reversed')
    JOIN chart_of_accounts a ON a.id = jel.account_id AND a.account_type IN ('revenue','expense','cogs')
   GROUP BY je.business_id, je.fiscal_year_id
) x"],
            ['v_cash_flow_account_v3', "CREATE OR REPLACE VIEW `v_cash_flow_account` AS
SELECT x.business_id, x.fiscal_year_id, x.cash_account_id, ca.title AS cash_account_title, ca.account_kind,
       x.doc_date, x.doc_type, x.doc_no, x.ref_id, x.amount_in, x.amount_out,
       SUM(x.amount_in - x.amount_out) OVER (PARTITION BY x.cash_account_id ORDER BY x.doc_date, x.ref_id) AS running_balance
FROM (
  SELECT je.business_id, je.fiscal_year_id, ca.id AS cash_account_id, je.entry_date AS doc_date,
         CASE je.reference_type
           WHEN 'receipt' THEN 'receipt'
           WHEN 'payment' THEN 'payment'
           WHEN 'transfer' THEN IF(jel.debit_amount > 0, 'transfer_in', 'transfer_out')
           WHEN 'payroll_document' THEN 'payroll'
           WHEN 'employee_advance' THEN 'advance'
           WHEN 'employee_loan' THEN 'loan'
           WHEN 'expense_document' THEN 'expense'
           WHEN 'income_document' THEN 'income'
           WHEN 'petty_cash' THEN 'petty_cash'
           WHEN 'cheque' THEN IF(jel.debit_amount > 0, 'cheque_in', 'cheque_out')
           WHEN 'invoice' THEN IF(jel.debit_amount > 0, 'invoice_in', 'invoice_out')
           WHEN 'reversal' THEN 'reversal'
           ELSE IFNULL(je.reference_type, 'journal')
         END AS doc_type,
         je.reference_no AS doc_no, je.id AS ref_id,
         jel.debit_amount AS amount_in, jel.credit_amount AS amount_out
    FROM journal_entry_lines jel
    JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status IN ('posted','reversed')
    JOIN cash_accounts ca ON ca.business_id = je.business_id AND ca.gl_account_id = jel.account_id
   WHERE jel.debit_amount <> 0 OR jel.credit_amount <> 0
) x
JOIN cash_accounts ca ON ca.id = x.cash_account_id"],
            ['employee_contracts_table', "CREATE TABLE IF NOT EXISTS `employee_contracts` (`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `business_id` BIGINT UNSIGNED NOT NULL, `fiscal_year_id` BIGINT UNSIGNED NULL,`employee_id` BIGINT UNSIGNED NOT NULL, `contract_no` VARCHAR(30) NOT NULL,`contract_type` ENUM('fixed_term','permanent','project','piecework','internship') NOT NULL DEFAULT 'fixed_term',`title` VARCHAR(150) NULL, `job_title` VARCHAR(100) NULL, `workshop_id` BIGINT UNSIGNED NULL,`start_date` DATE NOT NULL, `end_date` DATE NULL, `trial_months` TINYINT UNSIGNED NOT NULL DEFAULT 0,`work_hours_monthly` DECIMAL(6,2) NOT NULL DEFAULT 176, `work_days_monthly` DECIMAL(5,2) NOT NULL DEFAULT 26,`base_salary` DECIMAL(18,2) NOT NULL DEFAULT 0, `housing_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0,`food_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0, `child_allowance` DECIMAL(18,2) NOT NULL DEFAULT 0,`other_allowances` DECIMAL(18,2) NOT NULL DEFAULT 0, `insurance_rate_employee` DECIMAL(5,2) NOT NULL DEFAULT 7,`insurance_rate_employer` DECIMAL(5,2) NOT NULL DEFAULT 23, `paid_leave_days` SMALLINT UNSIGNED NOT NULL DEFAULT 26,`signed_date` DATE NULL, `apply_to_salary` TINYINT(1) NOT NULL DEFAULT 0,`status` ENUM('draft','active','expired','terminated') NOT NULL DEFAULT 'draft', `terms` TEXT NULL, `note` VARCHAR(255) NULL,`is_active` TINYINT(1) NOT NULL DEFAULT 1, `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `created_by` BIGINT UNSIGNED NULL,`updated_at` TIMESTAMP NULL DEFAULT NULL, `updated_by` BIGINT UNSIGNED NULL, PRIMARY KEY (`id`),UNIQUE KEY `uq_contract_no` (`business_id`,`contract_no`), KEY `ix_contract_employee` (`business_id`,`employee_id`,`status`),KEY `ix_contract_end` (`business_id`,`end_date`),CONSTRAINT `fk_contract_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,CONSTRAINT `fk_contract_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,CONSTRAINT `fk_contract_workshop` FOREIGN KEY (`workshop_id`) REFERENCES `payroll_workshops` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قراردادهای کار پرسنل'"],
            ['contract_templates_table', "CREATE TABLE IF NOT EXISTS `contract_templates` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `business_id` BIGINT UNSIGNED NOT NULL,
                `title` VARCHAR(150) NOT NULL, `body` MEDIUMTEXT NOT NULL, `note` VARCHAR(255) NULL,
                `is_default` TINYINT(1) NOT NULL DEFAULT 0, `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, `created_by` BIGINT UNSIGNED NULL,
                `updated_at` TIMESTAMP NULL DEFAULT NULL, `updated_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`), KEY `ix_ctpl_business` (`business_id`,`is_default`),
                CONSTRAINT `fk_ctpl_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='قالب‌های متن قرارداد کار'"],
            ['employee_contracts_template_col', "ALTER TABLE `employee_contracts`
                ADD COLUMN `template_id` BIGINT UNSIGNED NULL COMMENT 'قالب متن قرارداد' AFTER `contract_no`,
                ADD KEY `ix_contract_template` (`template_id`)"],
            ['receipts_cash_account_nullable', "ALTER TABLE `receipts` MODIFY `cash_account_id` BIGINT UNSIGNED NULL COMMENT 'حساب دریافت (برای چک خالی است)'"],
            ['payments_cash_account_nullable', "ALTER TABLE `payments` MODIFY `cash_account_id` BIGINT UNSIGNED NULL COMMENT 'حساب پرداخت (برای چک خالی است)'"],
            ['purchase_interim_is_asset', "UPDATE `chart_of_accounts` SET `account_type`='asset', `nature`='debit', `full_path`='دارایی‌ها / دارایی جاری / حساب واسط خرید' WHERE `system_role`='purchase_interim' AND `account_type`='cogs'"],
            ['purchase_interim_reparent', "UPDATE `chart_of_accounts` a JOIN `chart_of_accounts` p ON p.business_id=a.business_id AND p.code='11' SET a.parent_id=p.id, a.level_no=3 WHERE a.system_role='purchase_interim' AND a.account_type='asset' AND a.code='5102'"],
            ['plans_duration_months', "ALTER TABLE `plans` ADD COLUMN `duration_months` SMALLINT UNSIGNED NOT NULL DEFAULT 12 COMMENT 'مدت پکیج (ماه)' AFTER `price_amount`"],
            ['plans_deactivate_old', "UPDATE `plans` SET `is_active`=0 WHERE `slug` IN ('trial','basic','pro','enterprise')"],
            ['plans_quarter', "INSERT INTO `plans` (`slug`,`title`,`description`,`price_amount`,`duration_months`,`currency_id`,`included_documents`,`extra_document_price`,`max_users`,`max_businesses`,`sms_credits`,`is_popular`,`sort_order`,`status`,`is_active`) SELECT 'quarter','۳ ماهه','مناسب شروع کار و کسب‌وکارهای کوچک',900000,3,2,0,NULL,0,1,0,0,1,'active',1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `plans` WHERE `slug`='quarter')"],
            ['plans_half', "INSERT INTO `plans` (`slug`,`title`,`description`,`price_amount`,`duration_months`,`currency_id`,`included_documents`,`extra_document_price`,`max_users`,`max_businesses`,`sms_credits`,`is_popular`,`sort_order`,`status`,`is_active`) SELECT 'half','۶ ماهه','مناسب کسب‌وکارهای در حال رشد',1800000,6,2,0,NULL,0,1,0,1,2,'active',1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `plans` WHERE `slug`='half')"],
            ['plans_yearly', "INSERT INTO `plans` (`slug`,`title`,`description`,`price_amount`,`duration_months`,`currency_id`,`included_documents`,`extra_document_price`,`max_users`,`max_businesses`,`sms_credits`,`is_popular`,`sort_order`,`status`,`is_active`) SELECT 'yearly','یک‌ساله','اقتصادی‌ترین انتخاب — معادل دو ماه هدیه',2400000,12,2,0,NULL,0,1,0,0,3,'active',1 FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM `plans` WHERE `slug`='yearly')"],
            ['plans_prices_sync', "UPDATE `plans` SET `title`='۳ ماهه',`duration_months`=3,`price_amount`=900000,`is_active`=1,`sort_order`=1 WHERE `slug`='quarter'"],
            ['plans_prices_sync2', "UPDATE `plans` SET `title`='۶ ماهه',`duration_months`=6,`price_amount`=1800000,`is_active`=1,`is_popular`=1,`sort_order`=2 WHERE `slug`='half'"],
            ['plans_prices_sync3', "UPDATE `plans` SET `title`='یک‌ساله',`duration_months`=12,`price_amount`=2400000,`is_active`=1,`sort_order`=3 WHERE `slug`='yearly'"],
            // ── تصویر پروفایل کاربر (آواتار) ──
            ['users_avatar_path', "ALTER TABLE `users` ADD COLUMN `avatar_path` VARCHAR(255) NULL COMMENT 'تصویر پروفایل' AFTER `avatar_attachment_id`"],
            // ── اسناد شخصی کاربران (مدیریت اسناد با رمزگذاری اختیاری) ──
            ['user_documents_table', "CREATE TABLE IF NOT EXISTS `user_documents` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'مالک سند',
                `title` VARCHAR(190) NOT NULL COMMENT 'عنوان سند',
                `description` TEXT NULL COMMENT 'توضیحات',
                `file_name` VARCHAR(255) NOT NULL COMMENT 'نام اصلی فایل',
                `storage_key` VARCHAR(400) NOT NULL COMMENT 'مسیر نسبی فایل رمزگذاری‌شده',
                `mime_type` VARCHAR(120) NOT NULL COMMENT 'نوع MIME',
                `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'حجم اصلی (بایت)',
                `ext` VARCHAR(20) NULL COMMENT 'پسوند فایل',
                `is_encrypted` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'رمزگذاری‌شده',
                `password_hash` VARCHAR(255) NULL COMMENT 'هش رمز بازگشایی',
                `iv_hex` VARCHAR(64) NULL COMMENT 'بردار اولیهٔ رمزنگاری (hex)',
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'تاریخ ثبت',
                `updated_at` DATETIME NULL,
                `deleted_at` DATETIME NULL,
                PRIMARY KEY (`id`),
                KEY `ix_user_docs_user` (`business_id`,`user_id`,`created_at`),
                KEY `ix_user_docs_ext` (`business_id`,`ext`),
                CONSTRAINT `fk_user_docs_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_user_docs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اسناد و فایل‌های شخصی کاربران'"],
            // ── CRM: فعالیت‌ها و تایم‌لاین تعامل با مشتریان ──
            ['person_activities_table', "CREATE TABLE IF NOT EXISTS `person_activities` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'شخص (مشتری)',
                `user_id` BIGINT UNSIGNED NULL COMMENT 'کاربر ثبت‌کننده',
                `activity_type` ENUM('call','note','followup','meeting','email','sms','visit','other') NOT NULL DEFAULT 'note' COMMENT 'نوع فعالیت',
                `subject` VARCHAR(190) NOT NULL COMMENT 'عنوان',
                `body` TEXT NULL COMMENT 'شرح',
                `happened_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'زمان رخداد',
                `due_at` DATETIME NULL COMMENT 'زمان پیگیری بعدی (برای پیگیری)',
                `is_done` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'انجام‌شده (پیگیری)',
                `done_at` DATETIME NULL COMMENT 'زمان انجام',
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `updated_at` DATETIME NULL,
                `deleted_at` DATETIME NULL,
                PRIMARY KEY (`id`),
                KEY `ix_person_act_person` (`business_id`,`person_id`,`id`),
                KEY `ix_person_act_due` (`business_id`,`due_at`,`is_done`),
                CONSTRAINT `fk_person_act_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_person_act_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_person_act_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فعالیت‌ها و پیگیری‌های مشتریان (تایم‌لاین تعامل)'"],
            ['tickets_person_id', "ALTER TABLE `tickets` ADD COLUMN `person_id` BIGINT UNSIGNED NULL COMMENT 'شخص مرتبط (مشتری)' AFTER `created_by`"],
            // ── خرید فضای ذخیره‌سازی اضافه ──
            ['storage_purchases_table', "CREATE TABLE IF NOT EXISTS `storage_purchases` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `user_id` BIGINT UNSIGNED NOT NULL COMMENT 'خریدار',
                `gigabytes` SMALLINT UNSIGNED NOT NULL COMMENT 'حجم خریداری‌شده (گیگابایت)',
                `unit_price` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'قیمت هر گیگ (تومان)',
                `amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'جمع مبلغ',
                `payable_amount` DECIMAL(18,2) NOT NULL DEFAULT 0 COMMENT 'مبلغ قابل پرداخت',
                `payment_gateway` VARCHAR(40) NULL,
                `gateway_ref` VARCHAR(80) NULL,
                `status` ENUM('paid','pending','cancelled') NOT NULL DEFAULT 'paid',
                `paid_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`),
                KEY `ix_storage_purchases_user` (`business_id`,`user_id`),
                CONSTRAINT `fk_storage_purchases_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_storage_purchases_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خرید فضای ذخیره‌سازی اضافه (جدا از پکیج اشتراک)'"],
            // ── پورتال مشتری: حساب‌های دریافت وجه + رسید پرداخت ──
            ['payment_accounts_table', "CREATE TABLE IF NOT EXISTS `payment_accounts` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `bank_name` VARCHAR(120) NOT NULL COMMENT 'نام بانک',
                `account_holder` VARCHAR(150) NOT NULL COMMENT 'نام صاحب حساب',
                `card_no` VARCHAR(20) NULL COMMENT 'شماره کارت',
                `iban` VARCHAR(26) NULL COMMENT 'شبا',
                `is_active` TINYINT(1) NOT NULL DEFAULT 1,
                `sort_order` INT NOT NULL DEFAULT 0,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                `updated_at` DATETIME NULL,
                PRIMARY KEY (`id`),
                KEY `ix_payment_accounts_biz` (`business_id`),
                CONSTRAINT `fk_payment_accounts_biz` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='حساب‌های دریافت وجه (شبا/کارت) برای نمایش در پورتال مشتری'"],
            ['customer_payment_receipts_table', "CREATE TABLE IF NOT EXISTS `customer_payment_receipts` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `invoice_id` BIGINT UNSIGNED NOT NULL COMMENT 'فاکتور',
                `person_id` BIGINT UNSIGNED NOT NULL COMMENT 'مشتری',
                `file_name` VARCHAR(255) NOT NULL,
                `storage_key` VARCHAR(400) NOT NULL,
                `mime_type` VARCHAR(120) NOT NULL,
                `size_bytes` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                `amount` DECIMAL(18,2) NULL COMMENT 'مبلغ پرداختی',
                `note` VARCHAR(500) NULL COMMENT 'توضیح مشتری',
                `status` ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
                `reviewed_by` BIGINT UNSIGNED NULL,
                `reviewed_at` DATETIME NULL,
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (`id`),
                KEY `ix_cpr_invoice` (`invoice_id`),
                KEY `ix_cpr_biz` (`business_id`),
                CONSTRAINT `fk_cpr_biz` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_cpr_invoice` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
                CONSTRAINT `fk_cpr_person` FOREIGN KEY (`person_id`) REFERENCES `persons` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='رسیدهای پرداخت آپلودشده توسط مشتریان در پورتال'"],
            // ── گزارش مدیریتی خودکار ماهانه ──
            ['management_reports_table', "CREATE TABLE IF NOT EXISTS `management_reports` (
                `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                `business_id` BIGINT UNSIGNED NOT NULL,
                `period` VARCHAR(7) NOT NULL COMMENT 'دورهٔ شمسی (مثلاً 1405-07)',
                `title` VARCHAR(190) NOT NULL COMMENT 'عنوان گزارش',
                `content` MEDIUMTEXT NOT NULL COMMENT 'متن گزارش (HTML)',
                `stats_json` JSON NULL COMMENT 'آمار خام',
                `status` ENUM('ready','generating','failed') NOT NULL DEFAULT 'ready',
                `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `created_by` BIGINT UNSIGNED NULL,
                PRIMARY KEY (`id`),
                KEY `ix_mgmt_reports_biz` (`business_id`,`period`),
                CONSTRAINT `fk_mgmt_reports_biz` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
              ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='گزارش‌های مدیریتی خودکار ماهانه (AI)'"],
        ];
    }
}
