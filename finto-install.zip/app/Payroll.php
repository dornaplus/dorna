<?php
/**
 * حقوق و دستمزد — سرویس مشترک
 *  • کارگاه‌ها و پرسنل هر کارگاه
 *  • مساعدهٔ حقوق (پرداخت علی‌الحساب) با کسر خودکار از سند حقوق
 *  • وام کارکنان با اقساط و کسر خودکار از سند حقوق
 *  • داشبورد و گزارش جامع حقوق
 * هر پرداخت مساعده/وام سند حسابداری می‌سازد (بدهکار «حقوق پرداختنی» / بستانکار بانک یا صندوق)
 * و کسر آن در سند حقوق همان حساب را تسویه می‌کند.
 */
final class Payroll
{
    public const WORKSHOP_TYPES = ['project' => 'پروژه', 'site' => 'کارگاه اجرایی', 'branch' => 'شعبه', 'unit' => 'واحد سازمانی'];
    public const WORKSHOP_STATUS = ['active' => 'فعال', 'suspended' => 'غیرفعال', 'closed' => 'پایان‌یافته'];
    public const ADVANCE_STATUS = ['open' => 'باز (در حال کسر)', 'settled' => 'تسویه‌شده', 'cancelled' => 'لغوشده'];
    public const LOAN_STATUS = ['active' => 'در حال پرداخت', 'settled' => 'تسویه‌شده', 'cancelled' => 'لغوشده'];
    public const CONTRACT_TYPES = ['fixed_term' => 'مدت معین', 'permanent' => 'رسمی (نامحدود)', 'project' => 'پیمانکاری پروژه‌ای', 'piecework' => 'کارمزدی', 'internship' => 'کارآموزی'];
    public const CONTRACT_STATUS = ['draft' => 'پیش‌نویس', 'active' => 'جاری', 'expired' => 'پایان‌یافته', 'terminated' => 'فسخ‌شده'];

    public static function canView(): bool { return Auth::can('payroll.view'); }
    public static function canEdit(): bool { return Auth::can('payroll.create') || Auth::can('payroll.edit'); }

    /* ─────────────── کارگاه‌ها ─────────────── */

    public static function workshops(bool $activeOnly = false, ?int $businessId = null): array
    {
        $biz = $businessId ?? (int)Auth::businessId();
        $w = $activeOnly ? ' AND w.status="active"' : '';
        return Database::all("SELECT w.*, cc.name AS cost_center_name,
                                     CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),IFNULL(p.company_name,'')) AS manager_person_name,
                                     u.full_name AS manager_user_name,
                                     (SELECT COUNT(*) FROM payroll_workshop_employees we JOIN employees e2 ON e2.id=we.employee_id WHERE we.workshop_id=w.id AND we.is_active=1 AND e2.deleted_at IS NULL) AS employees_count,
                                     (SELECT IFNULL(SUM(d.net_amount),0) FROM payroll_documents d WHERE d.workshop_id=w.id AND d.status IN ('posted','paid') AND d.deleted_at IS NULL) AS paid_total
                                FROM payroll_workshops w
                                LEFT JOIN cost_centers cc ON cc.id=w.cost_center_id
                                LEFT JOIN persons p ON p.id=w.manager_person_id
                                LEFT JOIN users u ON u.id=w.manager_user_id
                               WHERE w.business_id=? AND w.is_active=1$w
                               ORDER BY w.status='active' DESC, w.code", [$biz]);
    }

    public static function workshop(int $id, ?int $businessId = null): ?array
    {
        $biz = $businessId ?? (int)Auth::businessId();
        if ($id <= 0) return null;
        $w = Database::one("SELECT w.*, cc.name AS cost_center_name,
                                   CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),IFNULL(p.company_name,'')) AS manager_person_name,
                                   u.full_name AS manager_user_name
                              FROM payroll_workshops w
                              LEFT JOIN cost_centers cc ON cc.id=w.cost_center_id
                              LEFT JOIN persons p ON p.id=w.manager_person_id
                              LEFT JOIN users u ON u.id=w.manager_user_id
                             WHERE w.id=? AND w.business_id=? AND w.is_active=1", [$id, $biz]);
        if ($w) $w['employees'] = self::workshopEmployees($id);
        return $w;
    }

    public static function nextWorkshopCode(int $biz): string
    {
        $max = 0;
        foreach (Database::all('SELECT code FROM payroll_workshops WHERE business_id=?', [$biz]) as $r) {
            if (preg_match('/(\d+)\s*$/', (string)$r['code'], $m)) $max = max($max, (int)$m[1]);
        }
        return 'WS-' . str_pad((string)($max + 1), 3, '0', STR_PAD_LEFT);
    }

    public static function saveWorkshop(array $d, ?int $id = null): int
    {
        $biz = (int)Auth::businessId();
        $title = mb_substr(trim((string)($d['title'] ?? '')), 0, 150);
        if (mb_strlen($title) < 2) throw new RuntimeException('نام کارگاه را وارد کنید.');
        $status = array_key_exists((string)($d['status'] ?? ''), self::WORKSHOP_STATUS) ? (string)$d['status'] : 'active';
        $type = array_key_exists((string)($d['workshop_type'] ?? ''), self::WORKSHOP_TYPES) ? (string)$d['workshop_type'] : 'project';
        $row = [
            'title' => $title, 'workshop_type' => $type, 'status' => $status,
            'manager_person_id' => !empty($d['manager_person_id']) ? (int)$d['manager_person_id'] : null,
            'manager_user_id' => !empty($d['manager_user_id']) ? (int)$d['manager_user_id'] : null,
            'address' => mb_substr(trim((string)($d['address'] ?? '')), 0, 255) ?: null,
            'start_date' => (string)($d['start_date'] ?? '') ?: null,
            'end_date' => (string)($d['end_date'] ?? '') ?: null,
            'cost_center_id' => !empty($d['cost_center_id']) ? (int)$d['cost_center_id'] : null,
            'budget_amount' => round((float)($d['budget_amount'] ?? 0), 2),
            'note' => mb_substr(trim((string)($d['note'] ?? '')), 0, 255) ?: null,
            'is_active' => 1,
        ];
        if ($id && self::workshop($id)) {
            $row['updated_at'] = now(); $row['updated_by'] = Auth::id();
            Database::update('payroll_workshops', $row, 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
            Audit::log('update', 'payroll_workshops', $id, 'ویرایش کارگاه ' . $title);
            return $id;
        }
        $code = mb_substr(trim((string)($d['code'] ?? '')), 0, 30) ?: self::nextWorkshopCode($biz);
        if (Database::val('SELECT COUNT(*) FROM payroll_workshops WHERE business_id=? AND code=?', [$biz, $code]))
            throw new RuntimeException('کد کارگاه «' . $code . '» تکراری است.');
        $row['business_id'] = $biz; $row['code'] = $code; $row['created_at'] = now(); $row['created_by'] = Auth::id();
        $newId = (int)Database::insert('payroll_workshops', $row);
        Audit::log('create', 'payroll_workshops', $newId, 'ایجاد کارگاه ' . $title);
        return $newId;
    }

    public static function deleteWorkshop(int $id): void
    {
        $biz = (int)Auth::businessId();
        $w = self::workshop($id);
        if (!$w) throw new RuntimeException('کارگاه یافت نشد.');
        $n = (int)Database::val('SELECT COUNT(*) FROM payroll_documents WHERE workshop_id=? AND deleted_at IS NULL', [$id], 0);
        if ($n > 0) throw new RuntimeException('برای این کارگاه ' . num($n) . ' سند حقوق ثبت شده است؛ ابتدا اسناد را حذف کنید.');
        Database::run('DELETE FROM payroll_workshops WHERE id=? AND business_id=?', [$id, $biz]);
        Audit::log('delete', 'payroll_workshops', $id, 'حذف کارگاه ' . $w['title']);
    }

    public static function workshopEmployees(int $workshopId): array
    {
        return Database::all("SELECT we.*, e.full_name, e.code AS employee_code, e.job_title, e.department
                                FROM payroll_workshop_employees we JOIN employees e ON e.id=we.employee_id
                               WHERE we.workshop_id=? AND we.is_active=1 AND e.deleted_at IS NULL ORDER BY e.full_name", [$workshopId]);
    }

    public static function addWorkshopEmployee(int $workshopId, int $employeeId, string $roleTitle = '', float $dailyWage = 0, ?string $from = null, ?string $to = null): void
    {
        $biz = (int)Auth::businessId();
        if (!self::workshop($workshopId)) throw new RuntimeException('کارگاه یافت نشد.');
        if (!Database::val('SELECT id FROM employees WHERE id=? AND business_id=? AND deleted_at IS NULL', [$employeeId, $biz])) throw new RuntimeException('پرسنل یافت نشد.');
        Database::transaction(function () use ($biz, $workshopId, $employeeId, $roleTitle, $dailyWage, $from, $to) {
            // کارگاه اصلی هر پرسنل یکی است: عضویت کارگاه‌های دیگر حذف می‌شود
            Database::run('DELETE FROM payroll_workshop_employees WHERE business_id=? AND employee_id=? AND workshop_id<>?', [$biz, $employeeId, $workshopId]);
            Database::run('UPDATE employees SET workshop_id=?, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?', [$workshopId, Auth::id(), $employeeId, $biz]);
            Database::run('INSERT INTO payroll_workshop_employees (business_id, workshop_id, employee_id, role_title, daily_wage, from_date, to_date, is_active, created_at, created_by)
                           VALUES (?,?,?,?,?,?,?,1,NOW(),?)
                           ON DUPLICATE KEY UPDATE role_title=VALUES(role_title), daily_wage=VALUES(daily_wage), from_date=VALUES(from_date), to_date=VALUES(to_date), is_active=1',
                [$biz, $workshopId, $employeeId, mb_substr($roleTitle, 0, 100) ?: null, round($dailyWage, 2), $from ?: null, $to ?: null, Auth::id()]);
        });
    }

    public static function removeWorkshopEmployee(int $id): void
    {
        $biz = (int)Auth::businessId();
        $row = Database::one('SELECT * FROM payroll_workshop_employees WHERE id=? AND business_id=?', [$id, $biz]);
        if (!$row) return;
        Database::transaction(function () use ($biz, $id, $row) {
            Database::run('DELETE FROM payroll_workshop_employees WHERE id=? AND business_id=?', [$id, $biz]);
            // اگر کارگاه اصلی پرسنل همین بود، از پروندهٔ او هم برداشته می‌شود
            Database::run('UPDATE employees SET workshop_id=NULL, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=? AND workshop_id=?',
                [Auth::id(), (int)$row['employee_id'], $biz, (int)$row['workshop_id']]);
        });
    }

    /** کارگاه اصلی پرسنل را روی پروندهٔ او تنظیم/پاک می‌کند (همگام با عضویت کارگاه) */
    public static function syncEmployeeWorkshop(int $employeeId, ?int $workshopId, string $roleTitle = ''): void
    {
        $biz = (int)Auth::businessId();
        if ($workshopId) {
            $ex = Database::one('SELECT id, role_title FROM payroll_workshop_employees WHERE workshop_id=? AND employee_id=?', [$workshopId, $employeeId]);
            self::addWorkshopEmployee($workshopId, $employeeId, $roleTitle ?: (string)($ex['role_title'] ?? ''));
            return;
        }
        // پاک‌کردن کارگاه پرسنل → حذف عضویت‌های او
        Database::run('DELETE FROM payroll_workshop_employees WHERE business_id=? AND employee_id=?', [$biz, $employeeId]);
        Database::run('UPDATE employees SET workshop_id=NULL, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?', [Auth::id(), $employeeId, $biz]);
    }

    /** کارگاه اصلی هر پرسنل به‌صورت نقشه (برای فرم‌ها) */
    public static function employeeWorkshopMap(): array
    {
        $out = [];
        foreach (Database::all('SELECT id, workshop_id FROM employees WHERE business_id=? AND deleted_at IS NULL', [(int)Auth::businessId()]) as $r)
            if (!empty($r['workshop_id'])) $out[(int)$r['id']] = (int)$r['workshop_id'];
        return $out;
    }

    /* ─────────────── مساعده ─────────────── */

    public static function advances(array $f = [], int $limit = 100): array
    {
        $biz = (int)Auth::businessId();
        $w = ['a.business_id=?', 'a.is_active=1']; $p = [$biz];
        if (!empty($f['employee_id'])) { $w[] = 'a.employee_id=?'; $p[] = (int)$f['employee_id']; }
        if (!empty($f['status'])) { $w[] = 'a.status=?'; $p[] = (string)$f['status']; }
        if (!empty($f['q'])) { $w[] = '(a.doc_no LIKE ? OR e.full_name LIKE ?)'; array_push($p, '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
        return Database::all("SELECT a.*, e.full_name, e.code AS employee_code, ca.title AS cash_title, ws.title AS workshop_title,
                                     (a.amount - a.settled_amount) AS remaining,
                                     CASE WHEN a.installment_amount > 0 THEN CEIL((a.amount - a.settled_amount) / a.installment_amount) ELSE 0 END AS remaining_installments
                                FROM employee_advances a
                                JOIN employees e ON e.id=a.employee_id
                                LEFT JOIN cash_accounts ca ON ca.id=a.cash_account_id
                                LEFT JOIN payroll_workshops ws ON ws.id=a.workshop_id
                               WHERE " . implode(' AND ', $w) . " ORDER BY a.doc_date DESC, a.id DESC LIMIT " . max(1, min(500, $limit)), $p);
    }

    public static function advance(int $id): ?array
    {
        return Database::one("SELECT a.*, e.full_name, e.code AS employee_code, ca.title AS cash_title,
                                     (a.amount - a.settled_amount) AS remaining
                                FROM employee_advances a JOIN employees e ON e.id=a.employee_id
                                LEFT JOIN cash_accounts ca ON ca.id=a.cash_account_id
                               WHERE a.id=? AND a.business_id=? AND a.is_active=1", [$id, (int)Auth::businessId()]);
    }

    public static function saveAdvance(array $d): int
    {
        $biz = (int)Auth::businessId();
        $emp = (int)($d['employee_id'] ?? 0);
        if (!Database::val('SELECT id FROM employees WHERE id=? AND business_id=? AND deleted_at IS NULL', [$emp, $biz])) throw new RuntimeException('پرسنل را انتخاب کنید.');
        $amount = round((float)($d['amount'] ?? 0), 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ مساعده باید بزرگ‌تر از صفر باشد.');
        $inst = max(1, min(60, (int)($d['installments'] ?? 1)));
        $cash = (int)($d['cash_account_id'] ?? 0);
        $date = (string)($d['doc_date'] ?? today());
        [$fy] = Posting::periodFor($biz, $date);
        Posting::assertPeriodOpen($fy, null);
        return Database::transaction(function () use ($biz, $emp, $amount, $inst, $cash, $date, $fy, $d) {
            $docNo = Sequence::next($biz, (int)$fy['id'], 'voucher', ['fy' => (int)substr((string)$fy['title'], -4), 'template' => 'ADV-{FY}-{SEQ}']);
            $id = (int)Database::insert('employee_advances', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'employee_id' => $emp, 'doc_no' => $docNo, 'doc_date' => $date,
                'amount' => $amount, 'installments' => $inst, 'installment_amount' => round($amount / $inst, 2), 'settled_amount' => 0,
                'cash_account_id' => $cash ?: null, 'workshop_id' => !empty($d['workshop_id']) ? (int)$d['workshop_id'] : null,
                'request_note' => mb_substr(trim((string)($d['request_note'] ?? '')), 0, 255) ?: null,
                'status' => 'open', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            if ($cash) {
                $je = self::payOut($biz, $date, $cash, $amount, 'مساعدهٔ حقوق — ' . $docNo, $docNo, 'employee_advance', $id);
                Database::run('UPDATE employee_advances SET journal_entry_id=? WHERE id=?', [$je, $id]);
            }
            Audit::log('create', 'employee_advances', $id, 'ثبت مساعده ' . $docNo, ['amount' => $amount]);
            return $id;
        });
    }

    public static function cancelAdvance(int $id): void
    {
        $a = self::advance($id);
        if (!$a) throw new RuntimeException('مساعده یافت نشد.');
        if ((float)$a['settled_amount'] > 0) throw new RuntimeException('از این مساعده قسط کسر شده است؛ امکان لغو نیست.');
        Database::transaction(function () use ($id, $a) {
            if (!empty($a['journal_entry_id'])) {
                try { Posting::reverse((int)$a['journal_entry_id'], 'لغو مساعده ' . $a['doc_no']); } catch (Throwable $e) { /* رد شود */ }
            }
            Database::run('UPDATE employee_advances SET status="cancelled", updated_at=NOW(), updated_by=? WHERE id=?', [Auth::id(), $id]);
            Trade::refreshCashBalances((int)Auth::businessId());
        });
        Audit::log('cancel', 'employee_advances', $id, 'لغو مساعده ' . $a['doc_no']);
    }

    /* ─────────────── وام ─────────────── */

    public static function loans(array $f = [], int $limit = 100): array
    {
        $biz = (int)Auth::businessId();
        $w = ['l.business_id=?', 'l.is_active=1']; $p = [$biz];
        if (!empty($f['employee_id'])) { $w[] = 'l.employee_id=?'; $p[] = (int)$f['employee_id']; }
        if (!empty($f['status'])) { $w[] = 'l.status=?'; $p[] = (string)$f['status']; }
        if (!empty($f['q'])) { $w[] = '(l.loan_no LIKE ? OR e.full_name LIKE ?)'; array_push($p, '%' . $f['q'] . '%', '%' . $f['q'] . '%'); }
        return Database::all("SELECT l.*, e.full_name, e.code AS employee_code, ca.title AS cash_title,
                                     TRIM(CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),' ',IFNULL(p.company_name,''))) AS guarantor_name,
                                     (l.amount - l.paid_amount) AS remaining,
                                     CASE WHEN l.installment_amount > 0 THEN CEIL((l.amount - l.paid_amount) / l.installment_amount) ELSE 0 END AS remaining_installments
                                FROM employee_loans l
                                JOIN employees e ON e.id=l.employee_id
                                LEFT JOIN cash_accounts ca ON ca.id=l.cash_account_id
                                LEFT JOIN persons p ON p.id=l.guarantor_person_id
                               WHERE " . implode(' AND ', $w) . " ORDER BY l.loan_date DESC, l.id DESC LIMIT " . max(1, min(500, $limit)), $p);
    }

    public static function loan(int $id): ?array
    {
        return Database::one("SELECT l.*, e.full_name, e.code AS employee_code, ca.title AS cash_title,
                                     (l.amount - l.paid_amount) AS remaining
                                FROM employee_loans l JOIN employees e ON e.id=l.employee_id
                                LEFT JOIN cash_accounts ca ON ca.id=l.cash_account_id
                               WHERE l.id=? AND l.business_id=? AND l.is_active=1", [$id, (int)Auth::businessId()]);
    }

    public static function saveLoan(array $d): int
    {
        $biz = (int)Auth::businessId();
        $emp = (int)($d['employee_id'] ?? 0);
        if (!Database::val('SELECT id FROM employees WHERE id=? AND business_id=? AND deleted_at IS NULL', [$emp, $biz])) throw new RuntimeException('پرسنل را انتخاب کنید.');
        $amount = round((float)($d['amount'] ?? 0), 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ وام باید بزرگ‌تر از صفر باشد.');
        $inst = max(1, min(120, (int)($d['installments'] ?? 1)));
        $cash = (int)($d['cash_account_id'] ?? 0);
        $date = (string)($d['loan_date'] ?? today());
        [$fy] = Posting::periodFor($biz, $date);
        Posting::assertPeriodOpen($fy, null);
        return Database::transaction(function () use ($biz, $emp, $amount, $inst, $cash, $date, $fy, $d) {
            $no = Sequence::next($biz, (int)$fy['id'], 'voucher', ['fy' => (int)substr((string)$fy['title'], -4), 'template' => 'LOAN-{FY}-{SEQ}']);
            $id = (int)Database::insert('employee_loans', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'employee_id' => $emp, 'loan_no' => $no, 'loan_date' => $date,
                'amount' => $amount, 'installments' => $inst, 'installment_amount' => round($amount / $inst, 2), 'paid_amount' => 0,
                'cash_account_id' => $cash ?: null,
                'guarantor_person_id' => !empty($d['guarantor_person_id']) ? (int)$d['guarantor_person_id'] : null,
                'purpose' => mb_substr(trim((string)($d['purpose'] ?? '')), 0, 255) ?: null,
                'status' => 'active', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            if ($cash) {
                $je = self::payOut($biz, $date, $cash, $amount, 'وام کارکنان — ' . $no, $no, 'employee_loan', $id);
                Database::run('UPDATE employee_loans SET journal_entry_id=? WHERE id=?', [$je, $id]);
            }
            Audit::log('create', 'employee_loans', $id, 'ثبت وام ' . $no, ['amount' => $amount]);
            return $id;
        });
    }

    public static function cancelLoan(int $id): void
    {
        $l = self::loan($id);
        if (!$l) throw new RuntimeException('وام یافت نشد.');
        if ((float)$l['paid_amount'] > 0) throw new RuntimeException('از این وام قسط کسر شده است؛ امکان لغو نیست.');
        Database::transaction(function () use ($id, $l) {
            if (!empty($l['journal_entry_id'])) {
                try { Posting::reverse((int)$l['journal_entry_id'], 'لغو وام ' . $l['loan_no']); } catch (Throwable $e) { /* رد شود */ }
            }
            Database::run('UPDATE employee_loans SET status="cancelled", updated_at=NOW(), updated_by=? WHERE id=?', [Auth::id(), $id]);
            Trade::refreshCashBalances((int)Auth::businessId());
        });
        Audit::log('cancel', 'employee_loans', $id, 'لغو وام ' . $l['loan_no']);
    }

    /** سند پرداخت مساعده/وام: بدهکار «مساعده/وام کارکنان» (دارایی) / بستانکار بانک یا صندوق */
    private static function payOut(int $biz, string $date, int $cashAccountId, float $amount, string $desc, string $docNo, string $refType, int $refId): ?int
    {
        $cashGl = (int)Database::val('SELECT gl_account_id FROM cash_accounts WHERE id=? AND business_id=?', [$cashAccountId, $biz], 0);
        // حسابداری اصولی: پرداخت مساعده/وام «دارایی» (مطالبات از کارکنان) ایجاد می‌کند، نه کاهش حقوق پرداختنی
        $accounts = Posting::ensurePayrollAccounts($biz);
        $assetGl = $refType === 'employee_loan' ? (int)($accounts['staff_loans'] ?? 0) : (int)($accounts['staff_advances'] ?? 0);
        if (!$cashGl || !$assetGl) throw new RuntimeException('حساب نقد/بانک یا حساب مساعده/وام کارکنان یافت نشد.');
        $je = Posting::create($biz, ['entry_date' => $date, 'entry_type' => 'normal', 'reference_type' => $refType, 'reference_id' => $refId,
            'reference_no' => $docNo, 'source' => 'auto', 'description' => $desc], [
            ['account_id' => $assetGl, 'debit' => $amount, 'description' => $desc],
            ['account_id' => $cashGl, 'credit' => $amount, 'description' => $desc],
        ]);
        Trade::updateCashBalance($cashAccountId);
        return $je;
    }

    /* ─────────────── مانده و کسر ─────────────── */

    public static function outstanding(int $employeeId): array
    {
        $adv = (float)Database::val("SELECT IFNULL(SUM(amount - settled_amount),0) FROM employee_advances WHERE business_id=? AND employee_id=? AND status='open' AND is_active=1", [(int)Auth::businessId(), $employeeId], 0);
        $loan = (float)Database::val("SELECT IFNULL(SUM(amount - paid_amount),0) FROM employee_loans WHERE business_id=? AND employee_id=? AND status='active' AND is_active=1", [(int)Auth::businessId(), $employeeId], 0);
        return ['advance' => round($adv, 2), 'loan' => round($loan, 2)];
    }

    /** ماندهٔ همهٔ پرسنل به‌صورت یک‌جا */
    public static function outstandingMap(?array $employeeIds = null): array
    {
        $biz = (int)Auth::businessId();
        $map = [];
        foreach (Database::all("SELECT employee_id, SUM(amount - settled_amount) rem FROM employee_advances
                                 WHERE business_id=? AND status='open' AND is_active=1 GROUP BY employee_id", [$biz]) as $r)
            $map[(int)$r['employee_id']]['advance'] = round((float)$r['rem'], 2);
        foreach (Database::all("SELECT employee_id, SUM(amount - paid_amount) rem FROM employee_loans
                                 WHERE business_id=? AND status='active' AND is_active=1 GROUP BY employee_id", [$biz]) as $r)
            $map[(int)$r['employee_id']]['loan'] = round((float)$r['rem'], 2);
        if ($employeeIds !== null) {
            $out = [];
            foreach ($employeeIds as $id) $out[(int)$id] = ['advance' => $map[(int)$id]['advance'] ?? 0, 'loan' => $map[(int)$id]['loan'] ?? 0];
            return $out;
        }
        // حتی وقتی فقط یکی از دو مورد وجود دارد، هر دو کلید تضمین می‌شود
        foreach ($map as $id => $v) $map[$id] = ['advance' => $v['advance'] ?? 0, 'loan' => $v['loan'] ?? 0];
        return $map;
    }

    /** قسط پیشنهادی این ماه برای یک پرسنل */
    public static function suggestedInstallments(int $employeeId): array
    {
        $biz = (int)Auth::businessId();
        $adv = Database::one("SELECT installment_amount, (amount - settled_amount) rem FROM employee_advances
                               WHERE business_id=? AND employee_id=? AND status='open' AND is_active=1 ORDER BY doc_date, id LIMIT 1", [$biz, $employeeId]);
        $loan = Database::one("SELECT installment_amount, (amount - paid_amount) rem FROM employee_loans
                                WHERE business_id=? AND employee_id=? AND status='active' AND is_active=1 ORDER BY loan_date, id LIMIT 1", [$biz, $employeeId]);
        return [
            'advance' => $adv ? round(min((float)$adv['installment_amount'], (float)$adv['rem']), 2) : 0.0,
            'loan' => $loan ? round(min((float)$loan['installment_amount'], (float)$loan['rem']), 2) : 0.0,
        ];
    }

    /** کسر مساعده/وام هنگام ثبت سند حقوق (از قدیمی‌ترین) */
    public static function applyDeductions(int $biz, int $employeeId, float $advance, float $loan): array
    {
        $applied = ['advance' => 0.0, 'loan' => 0.0];
        if ($advance > 0) {
            foreach (Database::all("SELECT * FROM employee_advances WHERE business_id=? AND employee_id=? AND status='open' AND is_active=1 ORDER BY doc_date, id", [$biz, $employeeId]) as $a) {
                if ($advance <= 0.009) break;
                $rem = round((float)$a['amount'] - (float)$a['settled_amount'], 2);
                if ($rem <= 0.009) continue;
                $take = min($advance, $rem);
                $newSettled = round((float)$a['settled_amount'] + $take, 2);
                $status = $newSettled + 0.009 >= (float)$a['amount'] ? 'settled' : 'open';
                Database::run('UPDATE employee_advances SET settled_amount=?, status=?, updated_at=NOW() WHERE id=?', [$newSettled, $status, (int)$a['id']]);
                $applied['advance'] += $take; $advance = round($advance - $take, 2);
            }
        }
        if ($loan > 0) {
            foreach (Database::all("SELECT * FROM employee_loans WHERE business_id=? AND employee_id=? AND status='active' AND is_active=1 ORDER BY loan_date, id", [$biz, $employeeId]) as $l) {
                if ($loan <= 0.009) break;
                $rem = round((float)$l['amount'] - (float)$l['paid_amount'], 2);
                if ($rem <= 0.009) continue;
                $take = min($loan, $rem);
                $newPaid = round((float)$l['paid_amount'] + $take, 2);
                $status = $newPaid + 0.009 >= (float)$l['amount'] ? 'settled' : 'active';
                Database::run('UPDATE employee_loans SET paid_amount=?, status=?, updated_at=NOW() WHERE id=?', [$newPaid, $status, (int)$l['id']]);
                $applied['loan'] += $take; $loan = round($loan - $take, 2);
            }
        }
        return $applied;
    }

    /** متن پیش‌فرض قرارداد کار (قابل ویرایش در تنظیمات حقوق و دستمزد) */
    public const DEFAULT_CONTRACT_BODY = <<<'TXT'
این قرارداد به موجب ماده (۱۰) قانون کار جمهوری اسلامی ایران بین کارفرما / نمایندهٔ قانونی کارفرما و کارگر منعقد می‌شود.

۱) مشخصات طرفین:
کارفرما / نمایندهٔ قانونی کارفرما $[business_name]$ به مدیریت: $[boss]$ و به نشانی: $[business_address]$
کارگر $[first_name]$ $[last_name]$ فرزند $[father_name]$ متولد $[birth_place]$ دارای شمارهٔ شناسنامه $[NIC]$ و شمارهٔ ملی $[melli_code]$ و میزان تحصیلات $[degree]$ به نشانی: $[person_address]$ — منعقد می‌گردد.

۲) نوع قرارداد: $[contract_type]$

۳) نوع کار یا حرفه یا حجم کار یا وظیفه‌ای که کارگر به آن اشتغال می‌یابد: $[semat]$

۴) محل انجام کار: $[workshop_name]$ — $[workshop_address]$

۵) مدت قرارداد: از تاریخ $[agreement_start_date]$ تا تاریخ $[agreement_end_date]$ (مدت آزمایشی: $[trial_months]$ ماه)

۶) میزان ساعت کار و ساعت شروع و پایان آن با توافق طرفین تعیین می‌گردد، ساعت کار نمی‌تواند بیش از میزان مندرج در قانون کار تعیین شود لیکن کمتر از آن مجاز است. (ساعت کاری ماهانه: $[work_hours]$ ساعت — روز کاری ماهانه: $[work_days]$ روز)

۷) حق‌السعی:
حقوق روزانه: $[daily_salary]$ ریال
حقوق ماهانه: $[month_salary]$ ریال
حق غذا: $[food]$ ریال
حق بن: $[bone]$ ریال
حق مسکن: $[home]$ ریال
حق اولاد: $[child]$ ریال
حق جذب: $[attract]$ ریال
سایر مزایا: $[benefit]$ ریال
مجموع دریافتی: $[sum]$ ریال

۸) حقوق و مزایا: حقوق و مزایا به‌صورت ماهانه به حساب شماره $[account_number]$ نزد بانک $[bank]$ توسط کارفرما یا نمایندهٔ قانونی وی پرداخت می‌گردد.

۹) بیمه: به موجب ماده ۱۴۸ قانون کار کارفرمایان کارگاه‌های مشمول این قانون مکلفند بر اساس قانون تأمین اجتماعی نسبت به بیمه نمودن کارگران واحد خود اقدام نمایند.

۱۰) عیدی و پاداش سالانه: به موجب ماده واحده قانون مربوط به تعیین عیدی و پاداش سالانه کارگران شاغل در کارگاه‌های مشمول قانون کار مصوب ۱۳۷۰/۱۲/۰۶ مجلس شورای اسلامی به ازای یک سال کار معادل شصت روز مزد ثابت/مبنا (تا سقف نود روز حداقل مزد روزانه قانونی کارگران) به عنوان عیدی و پاداش سالانه به کارگر پرداخت می‌شود. برای کار کمتر از یک سال میزان عیدی و پاداش و سقف مربوط به نسبت محاسبه خواهد شد.

۱۱) حق سنوات یا مزایای پایان کار: به استناد ماده ۲۴ قانون کار در صورت خاتمه قرارداد کار، کار معین یا مدت موقت، کارفرما مکلف است به کارگری که مطابق قرارداد یک سال یا بیشتر به کار اشتغال داشته است برای هر سال سابقه، اعم از متوالی یا متناوب، بر اساس آخرین حقوق مبلغی معادل یک ماه حقوق به عنوان مزایای پایان کار (حق سنوات) به وی پرداخت نماید.

۱۲) فسخ قرارداد: به استناد ماده ۲۵ قانون کار و تبصرهٔ آن، در قرارداد کار موقت و یا برای انجام کار معین هیچ یک از طرفین به تنهایی حق فسخ آن را ندارند و رسیدگی به اختلافات ناشی از این نوع قرارداد در صلاحیت هیئت‌های تشخیص و حل اختلاف می‌باشد.

۱۳) سایر: سایر موضوعات مندرج در قانون کار و مقررات تبعی از جمله مرخصی استحقاقی ($[paid_leave_days]$ روز در سال) نسبت به این قرارداد اعمال خواهد شد.

۱۴) این قرارداد در ۴ نسخه تنظیم می‌شود که یک نسخه نزد کارفرما، یک نسخه نزد کارگر، یک نسخه به تشکل کارگری (در صورت وجود) و یک نسخه نیز توسط کارفرما به ادارهٔ تعاون، کار و رفاه اجتماعی محل تحویل می‌شود.

تاریخ تنظیم: $[today]$                                  شمارهٔ قرارداد: $[contract_no]$



امضای کارفرما / نمایندهٔ قانونی: ..............................................                    امضای کارگر: ..............................................
TXT;

    /* ─────────────── قالب‌های متن قرارداد ─────────────── */

    /** جانگهدارهای متن قرارداد (کلید → عنوان فارسی برای راهنمای ادیتور) */
    public const CONTRACT_TOKENS = [
        'business_name' => 'نام کارفرما (کسب‌وکار)', 'boss' => 'مدیرعامل / نمایندهٔ قانونی', 'business_address' => 'نشانی کارفرما',
        'business_phone' => 'تلفن کارفرما', 'business_national_id' => 'شناسهٔ ملی کارفرما', 'business_economic_code' => 'کد اقتصادی کارفرما',
        'workshop_name' => 'نام کارگاه / محل خدمت', 'workshop_address' => 'نشانی کارگاه', 'workshop_code' => 'کد کارگاه',
        'first_name' => 'نام', 'last_name' => 'نام خانوادگی', 'full_name' => 'نام و نام خانوادگی',
        'father_name' => 'نام پدر', 'birth_place' => 'محل تولد', 'birth_date' => 'تاریخ تولد', 'gender' => 'جنسیت',
        'marital_status' => 'وضعیت تأهل', 'children_count' => 'تعداد فرزند',
        'NIC' => 'شمارهٔ شناسنامه', 'melli_code' => 'کد ملی', 'degree' => 'مدرک تحصیلی',
        'semat' => 'سمت / عنوان شغل', 'department' => 'واحد سازمانی', 'employee_code' => 'کد پرسنلی',
        'mobile' => 'موبایل', 'phone' => 'تلفن', 'email' => 'ایمیل', 'person_address' => 'نشانی پرسنل', 'postal_code' => 'کد پستی',
        'insurance_no' => 'شمارهٔ بیمه', 'insurance_start_date' => 'شروع بیمه', 'hire_date' => 'تاریخ استخدام',
        'contract_no' => 'شمارهٔ قرارداد', 'contract_type' => 'نوع قرارداد',
        'agreement_start_date' => 'شروع قرارداد', 'agreement_end_date' => 'پایان قرارداد',
        'trial_months' => 'مدت آزمایشی (ماه)', 'work_hours' => 'ساعت کاری ماهانه', 'work_days' => 'روز کاری ماهانه',
        'paid_leave_days' => 'مرخصی استحقاقی (روز)',
        'month_salary' => 'حقوق ماهانه', 'daily_salary' => 'حقوق روزانه',
        'food' => 'حق غذا', 'bone' => 'حق بن', 'home' => 'حق مسکن', 'child' => 'حق اولاد', 'attract' => 'حق جذب',
        'benefit' => 'سایر مزایا', 'sum' => 'مجموع دریافتی',
        'bank' => 'نام بانک', 'account_number' => 'شمارهٔ حساب', 'iban' => 'شبا', 'card_no' => 'شمارهٔ کارت',
        'account_holder' => 'صاحب حساب', 'today' => 'تاریخ امروز',
    ];

    /** اگر کسب‌وکار هیچ قالب متنی ندارد، متن پیش‌فرض ساخته می‌شود */
    public static function ensureContractTemplates(?int $biz = null): void
    {
        $biz = $biz ?: (int)Auth::businessId();
        if (!$biz) return;
        if ((int)Database::val('SELECT COUNT(*) FROM contract_templates WHERE business_id=?', [$biz], 0) > 0) return;
        Database::insert('contract_templates', ['business_id' => $biz, 'title' => 'قرارداد کار (متن پیش‌فرض)',
            'body' => self::DEFAULT_CONTRACT_BODY, 'is_default' => 1, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id()]);
    }

    public static function contractTemplates(?int $biz = null): array
    {
        $biz = $biz ?: (int)Auth::businessId();
        self::ensureContractTemplates($biz);
        return Database::all('SELECT * FROM contract_templates WHERE business_id=? AND is_active=1 ORDER BY is_default DESC, id', [$biz]);
    }

    public static function contractTemplate(int $id, ?int $biz = null): ?array
    {
        $biz = $biz ?: (int)Auth::businessId();
        return Database::one('SELECT * FROM contract_templates WHERE id=? AND business_id=? AND is_active=1', [$id, $biz]);
    }

    public static function defaultContractTemplate(?int $biz = null): ?array
    {
        $biz = $biz ?: (int)Auth::businessId();
        self::ensureContractTemplates($biz);
        return Database::one('SELECT * FROM contract_templates WHERE business_id=? AND is_active=1 ORDER BY is_default DESC, id LIMIT 1', [$biz]);
    }

    public static function saveContractTemplate(array $d, ?int $id = null): int
    {
        $biz = (int)Auth::businessId();
        $title = mb_substr(trim((string)($d['title'] ?? '')), 0, 150);
        $body = trim((string)($d['body'] ?? ''));
        if (mb_strlen($title) < 2) throw new RuntimeException('عنوان قالب را وارد کنید.');
        if (mb_strlen($body) < 30) throw new RuntimeException('متن قرارداد خیلی کوتاه است.');
        $isDefault = !empty($d['is_default']) ? 1 : 0;
        return Database::transaction(function () use ($biz, $id, $title, $body, $isDefault, $d) {
            if ($id && self::contractTemplate($id)) {
                Database::update('contract_templates', ['title' => $title, 'body' => $body, 'note' => mb_substr(trim((string)($d['note'] ?? '')), 0, 255) ?: null,
                    'updated_at' => now(), 'updated_by' => Auth::id()], 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
                $tid = $id;
            } else {
                $tid = (int)Database::insert('contract_templates', ['business_id' => $biz, 'title' => $title, 'body' => $body,
                    'note' => mb_substr(trim((string)($d['note'] ?? '')), 0, 255) ?: null, 'is_default' => 0, 'is_active' => 1,
                    'created_at' => now(), 'created_by' => Auth::id()]);
            }
            $total = (int)Database::val('SELECT COUNT(*) FROM contract_templates WHERE business_id=? AND is_active=1', [$biz], 0);
            if ($isDefault || $total === 1) self::setDefaultContractTemplate($tid);
            Audit::log($id ? 'update' : 'create', 'contract_templates', $tid, ($id ? 'ویرایش' : 'ایجاد') . ' قالب قرارداد ' . $title);
            return $tid;
        });
    }

    public static function setDefaultContractTemplate(int $id): void
    {
        $biz = (int)Auth::businessId();
        Database::run('UPDATE contract_templates SET is_default=0 WHERE business_id=?', [$biz]);
        Database::run('UPDATE contract_templates SET is_default=1, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?', [Auth::id(), $id, $biz]);
    }

    public static function deleteContractTemplate(int $id): void
    {
        $biz = (int)Auth::businessId();
        $t = self::contractTemplate($id);
        if (!$t) throw new RuntimeException('قالب یافت نشد.');
        $count = (int)Database::val('SELECT COUNT(*) FROM contract_templates WHERE business_id=? AND is_active=1', [$biz], 0);
        if ($count <= 1) throw new RuntimeException('حداقل یک قالب متن قرارداد لازم است.');
        Database::run('UPDATE contract_templates SET is_active=0, is_default=0, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?', [Auth::id(), $id, $biz]);
        if (!empty($t['is_default'])) {
            $next = (int)Database::val('SELECT id FROM contract_templates WHERE business_id=? AND is_active=1 ORDER BY id LIMIT 1', [$biz], 0);
            if ($next) self::setDefaultContractTemplate($next);
        }
        Audit::log('delete', 'contract_templates', $id, 'حذف قالب قرارداد ' . $t['title']);
    }

    /** مقادیر جانگهدارها برای یک قرارداد مشخص */
    public static function contractContext(int $contractId): array
    {
        $c = self::contract($contractId);
        if (!$c) return [];
        $biz = (int)Auth::businessId();
        $b = Database::one('SELECT * FROM businesses WHERE id=?', [$biz]) ?: [];
        $owner = Database::one('SELECT u.full_name FROM users u WHERE u.id=?', [(int)($b['created_by'] ?? 0)]) ?: [];
        $ws = !empty($c['workshop_id']) ? Database::one('SELECT * FROM payroll_workshops WHERE id=?', [(int)$c['workshop_id']]) : [];
        $emp = Database::one('SELECT * FROM employees WHERE id=?', [(int)$c['employee_id']]) ?: [];
        $person = !empty($emp['person_id']) ? Database::one('SELECT * FROM persons WHERE id=?', [(int)$emp['person_id']]) : [];
        // حساب بانکی: ابتدا پروندهٔ پرسنل، سپس حساب پیش‌فرض شخص
        $bankRow = [];
        if (!empty($emp['account_no'])) $bankRow = ['bank_name' => $emp['bank_name'] ?? '', 'account_no' => $emp['account_no'], 'iban' => $emp['iban'] ?? '', 'card_no' => $emp['card_no'] ?? '', 'account_holder' => $c['full_name']];
        elseif ($person) $bankRow = Database::one('SELECT * FROM person_bank_accounts WHERE person_id=? ORDER BY is_default DESC, id LIMIT 1', [(int)$person['id']]) ?: [];
        $full = trim((string)$c['full_name']);
        $parts = preg_split('/\s+/u', $full, 2) ?: [];
        $sum = (float)$c['base_salary'] + (float)$c['housing_allowance'] + (float)$c['food_allowance'] + (float)$c['child_allowance'] + (float)$c['other_allowances'];
        $money = fn($v) => num((float)$v);
        return [
            'business_name' => (string)($b['name'] ?? ''),
            'boss' => (string)($owner['full_name'] ?? ($b['name'] ?? '')),
            'business_address' => (string)($b['address'] ?? ''),
            'business_phone' => (string)($b['phone'] ?? ($b['mobile'] ?? '')),
            'business_national_id' => (string)($b['national_id'] ?? ''),
            'business_economic_code' => (string)($b['economic_code'] ?? ''),
            'workshop_name' => (string)($ws['title'] ?? ($c['workshop_title'] ?? '')),
            'workshop_address' => (string)($ws['address'] ?? ''),
            'workshop_code' => (string)($ws['code'] ?? ''),
            'first_name' => (string)($parts[0] ?? ''),
            'last_name' => (string)($parts[1] ?? ''),
            'full_name' => $full,
            'father_name' => (string)($emp['father_name'] ?? ''),
            'birth_place' => (string)($emp['birth_place'] ?? ''),
            'birth_date' => !empty($emp['birth_date']) ? jdate($emp['birth_date']) : '',
            'gender' => !empty($emp['gender']) ? (string)Meta::enumLabel((string)$emp['gender']) : '',
            'marital_status' => !empty($emp['marital_status']) ? (string)Meta::enumLabel((string)$emp['marital_status']) : '',
            'children_count' => num((int)($emp['children_count'] ?? 0)),
            'NIC' => (string)($emp['id_card_no'] ?? ''),
            'melli_code' => (string)($c['national_id'] ?? ($emp['national_id'] ?? '')),
            'degree' => (string)($emp['education_level'] ?? ''),
            'semat' => (string)($c['job_title'] ?: ($emp['job_title'] ?? '')),
            'department' => (string)($emp['department'] ?? ''),
            'employee_code' => (string)($c['employee_code'] ?? ''),
            'mobile' => (string)($emp['mobile'] ?? ($c['mobile'] ?? '')),
            'phone' => (string)($emp['phone'] ?? ''),
            'email' => (string)($emp['email'] ?? ''),
            'person_address' => (string)($emp['address'] ?? ($person['address'] ?? '')),
            'postal_code' => (string)($emp['postal_code'] ?? ($person['postal_code'] ?? '')),
            'insurance_no' => (string)($emp['insurance_no'] ?? ''),
            'insurance_start_date' => !empty($emp['insurance_start_date']) ? jdate($emp['insurance_start_date']) : '',
            'hire_date' => !empty($emp['hire_date']) ? jdate($emp['hire_date']) : '',
            'contract_no' => (string)$c['contract_no'],
            'contract_type' => (string)(self::CONTRACT_TYPES[$c['contract_type']] ?? $c['contract_type']),
            'agreement_start_date' => jdate($c['start_date']),
            'agreement_end_date' => !empty($c['end_date']) ? jdate($c['end_date']) : '—',
            'trial_months' => num((int)$c['trial_months']),
            'work_hours' => num((float)$c['work_hours_monthly'], 0),
            'work_days' => num((float)$c['work_days_monthly'], 0),
            'paid_leave_days' => num((int)$c['paid_leave_days']),
            'month_salary' => $money($c['base_salary']),
            'daily_salary' => $money(round((float)$c['base_salary'] / 30, 0)),
            'food' => $money(0),          // «حق غذا» در فینتو جزء جداگانه ندارد
            'bone' => $money($c['food_allowance']),
            'home' => $money($c['housing_allowance']),
            'child' => $money($c['child_allowance']),
            'attract' => $money(0),       // «حق جذب» در فینتو جزء جداگانه ندارد
            'benefit' => $money($c['other_allowances']),
            'sum' => $money($sum),
            'bank' => (string)($bankRow['bank_name'] ?? ''),
            'account_number' => (string)($bankRow['account_no'] ?? ''),
            'iban' => (string)($bankRow['iban'] ?? ''),
            'card_no' => (string)($bankRow['card_no'] ?? ''),
            'account_holder' => (string)($bankRow['account_holder'] ?? $full),
            'today' => jdate(today()),
        ];
    }

    /** جایگزینی جانگهدارها در متن قالب */
    public static function renderContractTemplate(string $body, array $ctx): string
    {
        return (string)preg_replace_callback('/\$\[([A-Za-z0-9_]+)\]\$/', function ($m) use ($ctx) {
            $k = $m[1];
            if (array_key_exists($k, $ctx)) return (string)$ctx[$k];
            return '—';
        }, $body);
    }

    /** متن نهایی قرارداد با قالب انتخاب‌شده (یا پیش‌فرض) */
    public static function renderContract(int $contractId, ?int $templateId = null): array
    {
        $tpl = $templateId ? self::contractTemplate($templateId) : null;
        if (!$tpl) $tpl = self::defaultContractTemplate();
        $ctx = self::contractContext($contractId);
        $body = (string)($tpl['body'] ?? self::DEFAULT_CONTRACT_BODY);
        return ['template' => $tpl, 'body' => self::renderContractTemplate($body, $ctx), 'context' => $ctx];
    }

    /* ─────────────── قراردادهای کار ─────────────── */

    public static function contracts(array $f = [], int $limit = 200): array
    {
        $biz = (int)Auth::businessId();
        $w = ['c.business_id=?', 'c.is_active=1']; $p = [$biz];
        if (!empty($f['employee_id'])) { $w[] = 'c.employee_id=?'; $p[] = (int)$f['employee_id']; }
        if (!empty($f['status'])) { $w[] = 'c.status=?'; $p[] = (string)$f['status']; }
        if (!empty($f['contract_type'])) { $w[] = 'c.contract_type=?'; $p[] = (string)$f['contract_type']; }
        if (!empty($f['expiring'])) { $w[] = 'c.end_date IS NOT NULL AND c.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)'; $p[] = (int)$f['expiring']; }
        if (!empty($f['q'])) { $w[] = '(c.contract_no LIKE ? OR c.title LIKE ? OR e.full_name LIKE ?)'; array_push($p, '%'.$f['q'].'%', '%'.$f['q'].'%', '%'.$f['q'].'%'); }
        return Database::all("SELECT c.*, e.full_name, e.code AS employee_code, ws.title AS workshop_title,
                                     DATEDIFF(c.end_date, CURDATE()) AS days_to_end,
                                     (c.base_salary + c.housing_allowance + c.food_allowance + c.child_allowance + c.other_allowances) AS total_salary
                                FROM employee_contracts c
                                JOIN employees e ON e.id=c.employee_id
                                LEFT JOIN payroll_workshops ws ON ws.id=c.workshop_id
                               WHERE " . implode(' AND ', $w) . " ORDER BY c.start_date DESC, c.id DESC LIMIT " . max(1, min(500, $limit)), $p);
    }

    public static function contract(int $id): ?array
    {
        return Database::one("SELECT c.*, e.full_name, e.code AS employee_code, e.job_title AS employee_job, e.national_id, e.mobile,
                                     e.hire_date, ws.title AS workshop_title
                                FROM employee_contracts c JOIN employees e ON e.id=c.employee_id
                                LEFT JOIN payroll_workshops ws ON ws.id=c.workshop_id
                               WHERE c.id=? AND c.business_id=? AND c.is_active=1", [$id, (int)Auth::businessId()]);
    }

    public static function nextContractNo(int $biz): string
    {
        $max = 0;
        foreach (Database::all('SELECT contract_no FROM employee_contracts WHERE business_id=?', [$biz]) as $r)
            if (preg_match('/(\d+)\s*$/', (string)$r['contract_no'], $mm)) $max = max($max, (int)$mm[1]);
        return 'CT-' . str_pad((string)($max + 1), 4, '0', STR_PAD_LEFT);
    }

    /** قرارداد جاری هر پرسنل */
    public static function activeContract(int $employeeId): ?array
    {
        return Database::one("SELECT * FROM employee_contracts WHERE business_id=? AND employee_id=? AND is_active=1 AND status='active'
                               ORDER BY start_date DESC, id DESC LIMIT 1", [(int)Auth::businessId(), $employeeId]);
    }

    public static function saveContract(array $d, ?int $id = null): int
    {
        $biz = (int)Auth::businessId();
        $empId = (int)($d['employee_id'] ?? 0);
        if (!Database::val('SELECT id FROM employees WHERE id=? AND business_id=? AND deleted_at IS NULL', [$empId, $biz]))
            throw new RuntimeException('پرسنل را انتخاب کنید.');
        $start = (string)($d['start_date'] ?? '');
        if ($start === '') throw new RuntimeException('تاریخ شروع قرارداد الزامی است.');
        $end = (string)($d['end_date'] ?? '') ?: null;
        if ($end && $end < $start) throw new RuntimeException('تاریخ پایان نمی‌تواند قبل از شروع باشد.');
        $type = array_key_exists((string)($d['contract_type'] ?? ''), self::CONTRACT_TYPES) ? (string)$d['contract_type'] : 'fixed_term';
        if ($type !== 'permanent' && $type !== 'piecework' && !$end)
            throw new RuntimeException('برای قرارداد مدت‌معین/پروژه‌ای/کارآموزی، تاریخ پایان الزامی است.');
        $status = array_key_exists((string)($d['status'] ?? ''), self::CONTRACT_STATUS) ? (string)$d['status'] : 'draft';
        $row = [
            'employee_id' => $empId, 'contract_type' => $type, 'status' => $status,
            'template_id' => !empty($d['template_id']) ? (int)$d['template_id'] : null,
            'title' => mb_substr(trim((string)($d['title'] ?? '')), 0, 150) ?: null,
            'job_title' => mb_substr(trim((string)($d['job_title'] ?? '')), 0, 100) ?: null,
            'workshop_id' => !empty($d['workshop_id']) ? (int)$d['workshop_id'] : null,
            'start_date' => $start, 'end_date' => $end,
            'trial_months' => max(0, min(12, (int)($d['trial_months'] ?? 0))),
            'work_hours_monthly' => round((float)($d['work_hours_monthly'] ?? 176), 2),
            'work_days_monthly' => round((float)($d['work_days_monthly'] ?? 26), 2),
            'base_salary' => round((float)($d['base_salary'] ?? 0), 2),
            'housing_allowance' => round((float)($d['housing_allowance'] ?? 0), 2),
            'food_allowance' => round((float)($d['food_allowance'] ?? 0), 2),
            'child_allowance' => round((float)($d['child_allowance'] ?? 0), 2),
            'other_allowances' => round((float)($d['other_allowances'] ?? 0), 2),
            'insurance_rate_employee' => round((float)($d['insurance_rate_employee'] ?? 7), 2),
            'insurance_rate_employer' => round((float)($d['insurance_rate_employer'] ?? 23), 2),
            'paid_leave_days' => max(0, min(60, (int)($d['paid_leave_days'] ?? 26))),
            'signed_date' => (string)($d['signed_date'] ?? '') ?: null,
            'apply_to_salary' => !empty($d['apply_to_salary']) ? 1 : 0,
            'terms' => trim((string)($d['terms'] ?? '')) ?: null,
            'note' => mb_substr(trim((string)($d['note'] ?? '')), 0, 255) ?: null,
            'is_active' => 1,
        ];
        return Database::transaction(function () use ($biz, $id, $row, $d) {
            if ($id && self::contract($id)) {
                $row['updated_at'] = now(); $row['updated_by'] = Auth::id();
                Database::update('employee_contracts', $row, 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
                $cid = $id;
                Audit::log('update', 'employee_contracts', $cid, 'ویرایش قرارداد ' . ($row['title'] ?? '#'.$cid));
            } else {
                $no = mb_substr(trim((string)($d['contract_no'] ?? '')), 0, 30) ?: self::nextContractNo($biz);
                if (Database::val('SELECT COUNT(*) FROM employee_contracts WHERE business_id=? AND contract_no=?', [$biz, $no]))
                    throw new RuntimeException('شماره قرارداد «' . $no . '» تکراری است.');
                $row['business_id'] = $biz; $row['contract_no'] = $no; $row['fiscal_year_id'] = Auth::fiscalYearId();
                $row['created_at'] = now(); $row['created_by'] = Auth::id();
                $cid = (int)Database::insert('employee_contracts', $row);
                Audit::log('create', 'employee_contracts', $cid, 'ثبت قرارداد ' . $no);
            }
            // اگر «شروع» گذشته و قرارداد پیش‌نویس است، جاری شود
            if ($row['status'] === 'draft' && $row['start_date'] <= today()) {
                Database::run('UPDATE employee_contracts SET status="active" WHERE id=?', [$cid]);
            }
            return $cid;
        });
    }

    /** اعمال عوامل قرارداد در تنظیمات حقوق پرسنل */
    public static function applyContractToSalary(int $id): void
    {
        $c = self::contract($id);
        if (!$c) throw new RuntimeException('قرارداد یافت نشد.');
        $biz = (int)Auth::businessId();
        $data = ['base_salary' => (float)$c['base_salary'], 'housing_allowance' => (float)$c['housing_allowance'],
            'food_allowance' => (float)$c['food_allowance'], 'child_allowance' => (float)$c['child_allowance'],
            'other_allowances' => (float)$c['other_allowances'],
            'insurance_rate_employee' => (float)$c['insurance_rate_employee'], 'insurance_rate_employer' => (float)$c['insurance_rate_employer'],
            'effective_from' => $c['start_date']];
        $exists = Database::one('SELECT employee_id FROM employee_salary_settings WHERE employee_id=?', [(int)$c['employee_id']]);
        if ($exists) Database::update('employee_salary_settings', $data, 'employee_id=:employee_id', ['employee_id' => (int)$c['employee_id']]);
        else { $data['employee_id'] = (int)$c['employee_id']; $data['created_at'] = now(); $data['created_by'] = Auth::id(); Database::insert('employee_salary_settings', $data); }
        Database::run('UPDATE employee_contracts SET apply_to_salary=1, updated_at=NOW(), updated_by=? WHERE id=?', [Auth::id(), $id]);
        Audit::log('update', 'employee_salary_settings', (int)$c['employee_id'], 'اعمال قرارداد ' . $c['contract_no'] . ' در تنظیمات حقوق');
    }

    public static function deleteContract(int $id): void
    {
        $c = self::contract($id);
        if (!$c) throw new RuntimeException('قرارداد یافت نشد.');
        Database::run('UPDATE employee_contracts SET is_active=0, updated_at=NOW(), updated_by=? WHERE id=? AND business_id=?', [Auth::id(), $id, (int)Auth::businessId()]);
        Audit::log('delete', 'employee_contracts', $id, 'حذف قرارداد ' . $c['contract_no']);
    }

    /** قراردادهای نزدیک به پایان (تعداد روز) */
    public static function expiringContracts(int $days = 60, int $limit = 20): array
    {
        $biz = (int)Auth::businessId();
        return Database::all("SELECT c.*, e.full_name, DATEDIFF(c.end_date, CURDATE()) AS days_to_end
                                FROM employee_contracts c JOIN employees e ON e.id=c.employee_id
                               WHERE c.business_id=? AND c.is_active=1 AND c.status='active' AND c.end_date IS NOT NULL
                                 AND c.end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                               ORDER BY c.end_date LIMIT " . max(1, min(100, $limit)), [$biz, $days]);
    }

    /** آمار قراردادها */
    public static function contractStats(): array
    {
        $biz = (int)Auth::businessId();
        $r = Database::one("SELECT COUNT(*) AS `total`,
                                   SUM(status='active') AS `active`, SUM(status='draft') AS `draft`,
                                   SUM(status='expired' OR (end_date IS NOT NULL AND end_date < CURDATE() AND status='active')) AS `expired`,
                                   SUM(status='terminated') AS `terminated`
                              FROM employee_contracts WHERE business_id=? AND is_active=1", [$biz]) ?: [];
        return ['total' => (int)($r['total'] ?? 0), 'active' => (int)($r['active'] ?? 0), 'draft' => (int)($r['draft'] ?? 0),
            'expired' => (int)($r['expired'] ?? 0), 'terminated' => (int)($r['terminated'] ?? 0)];
    }

    /* ─────────────── عیدی و حق سنوات ─────────────── */

    /** مبنای ماهانهٔ محاسبهٔ عیدی/سنوات بر اساس تنظیمات حقوق */
    public static function bonusBase(int $employeeId): float
    {
        $biz = (int)Auth::businessId();
        $s = Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [$employeeId]) ?: [];
        $monthly = (float)($s['base_salary'] ?? 0);
        return $monthly;
    }

    /**
     * محاسبهٔ عیدی و حق سنوات بر اساس پارامترهای تنظیمات حقوق.
     * عیدی: ۲ برابر حقوق ماهانه برای یک سال (نسبی برای کمتر)، سقف ۳ برابر حداقل مزد.
     * سنوات: یک ماه حقوق برای هر سال سابقه.
     */
    public static function eidiAndSanavat(int $employeeId, ?string $asOf = null): array
    {
        $biz = (int)Auth::businessId();
        $asOf = $asOf ?: today();
        $emp = Database::one('SELECT * FROM employees WHERE id=? AND business_id=?', [$employeeId, $biz]);
        if (!$emp) return [];
        $base = self::bonusBase($employeeId);
        $eidiBase = (string)Settings::get('hr.eidi_base', 'base', $biz);         // base | gross
        $monthly = $base;
        if ($eidiBase === 'gross') {
            $s = Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [$employeeId]) ?: [];
            $monthly = (float)($s['base_salary'] ?? 0) + (float)($s['housing_allowance'] ?? 0) + (float)($s['food_allowance'] ?? 0)
                     + (float)($s['child_allowance'] ?? 0) + (float)($s['other_allowances'] ?? 0);
        }
        $multi = (float)Settings::get('hr.eidi_multiplier', 2, $biz);
        $capMulti = (float)Settings::get('hr.eidi_cap_multiplier', 3, $biz);
        $minWage = (float)Settings::get('hr.minimum_wage', 0, $biz);
        // ماه‌های کارکرد در سال جاری شمسی
        $months = 12.0;
        if (!empty($emp['hire_date'])) {
            $days = (int)floor((strtotime($asOf) - strtotime((string)$emp['hire_date'])) / 86400);
            $months = max(0, min(12, $days / 30.44));
        }
        $eidi = round($monthly * $multi * ($months / 12), 2);
        $cap = $minWage > 0 ? round($minWage * $capMulti, 2) : 0.0;
        if ($cap > 0 && $eidi > $cap) $eidi = $cap;
        // سنوات: یک ماه حقوق برای هر سال سابقه
        $years = 0.0;
        if (!empty($emp['hire_date'])) $years = max(0, (strtotime($asOf) - strtotime((string)$emp['hire_date'])) / (86400 * 365.25));
        $sanavat = round($monthly * $years, 2);
        return ['monthly' => $monthly, 'months' => round($months, 2), 'years' => round($years, 2),
            'eidi' => $eidi, 'eidi_cap' => $cap, 'sanavat' => $sanavat,
            'eidi_multiplier' => $multi, 'eidi_base' => $eidiBase, 'as_of' => $asOf];
    }

    /* ─────────────── داشبورد و گزارش ─────────────── */

    public static function dashboard(string $from, string $to, int $workshopId = 0): array
    {
        $biz = (int)Auth::businessId();
        $w = ['d.business_id=?', 'd.deleted_at IS NULL', 'd.status IN ("posted","paid")', 'd.doc_date BETWEEN ? AND ?']; $p = [$biz, $from, $to];
        if ($workshopId) { $w[] = 'd.workshop_id=?'; $p[] = $workshopId; }
        $sum = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(d.gross_amount),0) gross, IFNULL(SUM(d.insurance_employee),0) ins_emp,
                                     IFNULL(SUM(d.insurance_employer),0) ins_er, IFNULL(SUM(d.tax_amount),0) tax,
                                     IFNULL(SUM(d.deductions_amount),0) ded, IFNULL(SUM(d.net_amount),0) net,
                                     IFNULL(SUM(d.advance_total),0) adv, IFNULL(SUM(d.loan_total),0) loan
                                FROM payroll_documents d WHERE " . implode(' AND ', $w), $p);
        $emp = (int)Database::val('SELECT COUNT(*) FROM employees WHERE business_id=? AND status="active"', [$biz], 0);
        $ws = (int)Database::val('SELECT COUNT(*) FROM payroll_workshops WHERE business_id=? AND is_active=1 AND status="active"', [$biz], 0);
        $advOpen = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(amount - settled_amount),0) rem FROM employee_advances WHERE business_id=? AND status='open' AND is_active=1", [$biz]);
        $loanOpen = Database::one("SELECT COUNT(*) cnt, IFNULL(SUM(amount - paid_amount),0) rem FROM employee_loans WHERE business_id=? AND status='active' AND is_active=1", [$biz]);
        return [
            'employees' => $emp, 'workshops' => $ws,
            'docs' => (int)$sum['cnt'], 'gross' => round((float)$sum['gross'], 2), 'insurance_employee' => round((float)$sum['ins_emp'], 2),
            'insurance_employer' => round((float)$sum['ins_er'], 2), 'tax' => round((float)$sum['tax'], 2),
            'deductions' => round((float)$sum['ded'], 2), 'net' => round((float)$sum['net'], 2),
            'advance_deducted' => round((float)$sum['adv'], 2), 'loan_deducted' => round((float)$sum['loan'], 2),
            'advance_open_count' => (int)$advOpen['cnt'], 'advance_open_amount' => round((float)$advOpen['rem'], 2),
            'loan_open_count' => (int)$loanOpen['cnt'], 'loan_open_amount' => round((float)$loanOpen['rem'], 2),
        ];
    }

    public static function reportRows(string $from, string $to, int $workshopId = 0, int $employeeId = 0): array
    {
        $biz = (int)Auth::businessId();
        $w = ['d.business_id=?', 'd.deleted_at IS NULL', 'd.status IN ("posted","paid")', 'd.doc_date BETWEEN ? AND ?']; $p = [$biz, $from, $to];
        if ($workshopId) { $w[] = 'd.workshop_id=?'; $p[] = $workshopId; }
        if ($employeeId) { $w[] = 'l.employee_id=?'; $p[] = $employeeId; }
        return Database::all("SELECT d.doc_no, d.doc_date, d.period_title, d.status, ws.title AS workshop_title,
                                     e.full_name, e.code AS employee_code, e.job_title, e.department,
                                     l.worked_days, l.gross_amount, l.deductions_amount, l.advance_amount, l.loan_amount, l.net_amount
                                FROM payroll_document_lines l
                                JOIN payroll_documents d ON d.id=l.payroll_document_id
                                JOIN employees e ON e.id=l.employee_id
                                LEFT JOIN payroll_workshops ws ON ws.id=d.workshop_id
                               WHERE " . implode(' AND ', $w) . " ORDER BY d.doc_date DESC, d.id DESC, e.full_name LIMIT 1000", $p);
    }

    public static function byWorkshop(string $from, string $to): array
    {
        $biz = (int)Auth::businessId();
        return Database::all("SELECT IFNULL(ws.title,'بدون کارگاه') title, COUNT(DISTINCT d.id) docs, COUNT(l.id) emp_lines,
                                     IFNULL(SUM(l.gross_amount),0) gross, IFNULL(SUM(l.net_amount),0) net
                                FROM payroll_documents d
                                LEFT JOIN payroll_workshops ws ON ws.id=d.workshop_id
                                LEFT JOIN payroll_document_lines l ON l.payroll_document_id=d.id
                               WHERE d.business_id=? AND d.deleted_at IS NULL AND d.status IN ('posted','paid') AND d.doc_date BETWEEN ? AND ?
                               GROUP BY ws.title ORDER BY gross DESC", [$biz, $from, $to]);
    }

    /** آخرین سند حقوق + خطوطش (برای «مشابه ماه قبل») */
    public static function cloneSource(): ?array
    {
        $biz = (int)Auth::businessId();
        $doc = Database::one("SELECT * FROM payroll_documents WHERE business_id=? AND deleted_at IS NULL AND status IN ('posted','paid')
                               ORDER BY doc_date DESC, id DESC LIMIT 1", [$biz]);
        if (!$doc) return null;
        $lines = Database::all('SELECT * FROM payroll_document_lines WHERE payroll_document_id=? ORDER BY id', [(int)$doc['id']]);
        return ['doc' => $doc, 'lines' => $lines];
    }
}
