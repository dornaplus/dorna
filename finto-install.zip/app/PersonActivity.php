<?php
/**
 * فعالیت‌ها و تایم‌لاین تعامل با مشتریان (CRM).
 *  • انواع: تماس، یادداشت، پیگیری، جلسه، ایمیل، پیامک، بازدید و سایر.
 *  • «پیگیری» یک فعالیت آینده‌نگر است (زمان پیگیری + انجام‌شده/نشده) و حکم یادآوری/وظیفه را دارد.
 */
final class PersonActivity
{
    public const TYPES = [
        'call'     => ['تماس', 'phone'],
        'note'     => ['یادداشت', 'edit'],
        'followup' => ['پیگیری', 'clock'],
        'meeting'  => ['جلسه', 'users'],
        'email'    => ['ایمیل', 'mail'],
        'sms'      => ['پیامک', 'mail'],
        'visit'    => ['بازدید', 'home'],
        'other'    => ['سایر', 'dot'],
    ];

    public static function label(string $type): string
    {
        return self::TYPES[$type][0] ?? self::TYPES['other'][0];
    }

    public static function iconName(string $type): string
    {
        return self::TYPES[$type][1] ?? 'dot';
    }

    /** تایم‌لاین فعالیت‌های یک شخص (جدیدترین اول) */
    public static function timeline(int $personId, int $limit = 200): array
    {
        $biz = (int)Auth::businessId();
        return Database::all(
            "SELECT a.*, u.full_name AS user_name, u.avatar_path AS user_avatar
               FROM person_activities a LEFT JOIN users u ON u.id = a.user_id
              WHERE a.business_id = ? AND a.person_id = ? AND a.deleted_at IS NULL
              ORDER BY a.happened_at DESC, a.id DESC LIMIT " . max(1, min(500, $limit)),
            [$biz, $personId]
        );
    }

    /** پیگیری‌های باز (انجام‌نشده) با سررسید مشخص */
    public static function openFollowups(int $personId): array
    {
        $biz = (int)Auth::businessId();
        return Database::all(
            "SELECT a.*, u.full_name AS user_name
               FROM person_activities a LEFT JOIN users u ON u.id = a.user_id
              WHERE a.business_id = ? AND a.person_id = ? AND a.deleted_at IS NULL
                AND a.activity_type = 'followup' AND a.is_done = 0
              ORDER BY IFNULL(a.due_at, a.happened_at) ASC",
            [$biz, $personId]
        );
    }

    /** ثبت فعالیت (تماس/یادداشت/… یا پیگیری با سررسید) */
    public static function store(int $personId, string $type, string $subject, string $body, ?string $dueAt, ?string $happenedAt): int
    {
        $biz = (int)Auth::businessId();
        if (!isset(self::TYPES[$type])) $type = 'other';
        $subject = mb_substr(trim($subject), 0, 190);
        if ($subject === '') $subject = self::label($type);

        $id = (int)Database::insert('person_activities', [
            'business_id' => $biz, 'person_id' => $personId, 'user_id' => Auth::id(),
            'activity_type' => $type, 'subject' => $subject,
            'body' => trim($body) !== '' ? mb_substr(trim($body), 0, 3000) : null,
            'happened_at' => ($happenedAt ?: now()),
            'due_at' => $type === 'followup' ? ($dueAt ?: null) : null,
            'is_done' => 0, 'created_at' => now(),
        ]);
        Audit::log('create', 'person_activities', $id, 'فعالیت «' . self::label($type) . '» برای شخص #' . $personId . ' — ' . $subject);
        return $id;
    }

    /** علامت‌گذاری پیگیری انجام‌شده/نشده */
    public static function toggleDone(int $id): void
    {
        $biz = (int)Auth::businessId();
        $a = Database::one('SELECT * FROM person_activities WHERE id=? AND business_id=?', [$id, $biz]);
        if (!$a) throw new RuntimeException('فعالیت یافت نشد.');
        $done = (int)$a['is_done'] === 1 ? 0 : 1;
        Database::run('UPDATE person_activities SET is_done=?, done_at=?, updated_at=NOW() WHERE id=?',
            [$done, $done ? now() : null, $id]);
    }

    public static function delete(int $id): void
    {
        $biz = (int)Auth::businessId();
        $a = Database::one('SELECT * FROM person_activities WHERE id=? AND business_id=?', [$id, $biz]);
        if (!$a) throw new RuntimeException('فعالیت یافت نشد.');
        Database::run('UPDATE person_activities SET deleted_at=NOW() WHERE id=?', [$id]);
        Audit::log('delete', 'person_activities', $id, 'حذف فعالیت');
    }

    /** تعداد پیگیری‌های باز سراسری (برای نشان در منو) */
    public static function openFollowupCount(): int
    {
        $biz = (int)Auth::businessId();
        return (int)Database::val(
            "SELECT COUNT(*) FROM person_activities WHERE business_id=? AND deleted_at IS NULL AND activity_type='followup' AND is_done=0",
            [$biz], 0
        );
    }
}
