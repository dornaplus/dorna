<?php
/**
 * تنخواه گردان (صندوق پیش‌پرداخت / Imprest) — سرویس مشترک
 *  • شارژ تنخواه (تخصیص وجه از بانک/صندوق به تنخواه‌دار)
 *  • هزینه از تنخواه (با مرکز هزینه، پیوست و گردش تأیید)
 *  • برگشت هزینه (واریز وجه به تنخواه)
 *  • تسویه تنخواه (برگشت مانده به بانک/صندوق)
 * هر سند تأییدشده، سند حسابداری خودکار می‌سازد و ماندهٔ حساب‌های نقد/بانک هم‌گام می‌شود.
 */
final class PettyCash
{
    public const TYPES = [
        'charge'  => 'شارژ تنخواه',
        'expense' => 'هزینه از تنخواه',
        'refund'  => 'برگشت هزینه',
        'settle'  => 'تسویه تنخواه',
    ];
    public const STATUSES = [
        'pending'   => 'در انتظار تأیید',
        'approved'  => 'تأییدشده',
        'rejected'  => 'ردشده',
        'cancelled' => 'لغوشده',
    ];
    public const STATUS_CLASS = ['pending' => 'warn', 'approved' => 'ok', 'rejected' => 'bad', 'cancelled' => 'muted'];
    /** اثر هر نوع سند بر ماندهٔ تنخواه: + افزایش ، − کاهش */
    public const SIGN = ['charge' => 1, 'refund' => 1, 'expense' => -1, 'settle' => -1];

    /* ─────────────── دسترسی ─────────────── */
    public static function canView(): bool { return Auth::can('petty_cash.view'); }
    public static function canCreate(): bool { return Auth::can('petty_cash.create'); }
    public static function canEdit(): bool { return Auth::can('petty_cash.edit'); }
    public static function canApprove(): bool { return Auth::can('petty_cash.approve'); }
    public static function canPrint(): bool { return Auth::can('petty_cash.print'); }

    public static function typeTitle(string $t): string { return self::TYPES[$t] ?? $t; }
    public static function statusTitle(string $s): string { return self::STATUSES[$s] ?? $s; }

    /* ─────────────── تنخواه‌ها ─────────────── */

    /** همهٔ تنخواه‌های کسب‌وکار + ماندهٔ محاسبه‌شده */
    public static function funds(bool $onlyActive = false, ?int $businessId = null): array
    {
        $biz = $businessId ?? (int)Auth::businessId();
        $w = $onlyActive ? ' AND f.status="active"' : '';
        $rows = Database::all("SELECT f.*, a.code AS gl_code, a.title AS gl_title,
                                      u.full_name AS keeper_name, u.mobile AS keeper_mobile,
                                      CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),IFNULL(p.company_name,'')) AS person_name,
                                      (SELECT IFNULL(SUM(CASE WHEN e.entry_type IN ('charge','refund') THEN e.amount ELSE -e.amount END),0)
                                         FROM petty_cash_entries e WHERE e.fund_id=f.id AND e.status='approved' AND e.is_active=1) AS balance,
                                      (SELECT COUNT(*) FROM petty_cash_entries e WHERE e.fund_id=f.id AND e.status='approved' AND e.is_active=1) AS entries_count
                                 FROM petty_cash_funds f
                                 LEFT JOIN chart_of_accounts a ON a.id=f.gl_account_id
                                 LEFT JOIN users u ON u.id=f.keeper_user_id
                                 LEFT JOIN persons p ON p.id=f.person_id
                                WHERE f.business_id=? AND f.is_active=1$w
                                ORDER BY f.status='active' DESC, f.code", [$biz]);
        return array_map(function ($f) {
            $f['balance'] = round((float)$f['balance'], 2);
            $f['low'] = (float)($f['low_balance_amount'] ?? 0) > 0 && $f['balance'] <= (float)$f['low_balance_amount'];
            $f['over_ceiling'] = (float)($f['ceiling_amount'] ?? 0) > 0 && $f['balance'] > (float)$f['ceiling_amount'];
            return $f;
        }, $rows);
    }

    public static function fund(int $id, ?int $businessId = null): ?array
    {
        $biz = $businessId ?? (int)Auth::businessId();
        if ($id <= 0) return null;
        $f = Database::one("SELECT f.*, a.code AS gl_code, a.title AS gl_title, u.full_name AS keeper_name,
                                   CONCAT(IFNULL(p.first_name,''),' ',IFNULL(p.last_name,''),IFNULL(p.company_name,'')) AS person_name
                              FROM petty_cash_funds f
                              LEFT JOIN chart_of_accounts a ON a.id=f.gl_account_id
                              LEFT JOIN users u ON u.id=f.keeper_user_id
                              LEFT JOIN persons p ON p.id=f.person_id
                             WHERE f.id=? AND f.business_id=? AND f.is_active=1", [$id, $biz]);
        if ($f) { $f['balance'] = self::balance($id); }
        return $f;
    }

    /** آیا کاربر جاری می‌تواند این تنخواه را ببیند؟ (تنخواه‌دار فقط تنخواه خودش؛ مدیر همه) */
    public static function canSee(array $fund): bool
    {
        if (Auth::can('petty_cash.approve') || Auth::can('petty_cash.edit')) return true;
        $uid = (int)Auth::id();
        return (int)($fund['keeper_user_id'] ?? 0) === $uid;
    }

    /** تنخواه‌های قابل‌دیدن کاربر جاری */
    public static function visibleFunds(bool $onlyActive = false): array
    {
        $all = self::funds($onlyActive);
        if (self::canApprove() || self::canEdit()) return $all;
        $uid = (int)Auth::id();
        return array_values(array_filter($all, fn($f) => (int)($f['keeper_user_id'] ?? 0) === $uid));
    }

    /** ماندهٔ تنخواه (جمع بدهکار/بستانکار دفتر، معادل ماندهٔ حساب کل) */
    public static function balance(int $fundId): float
    {
        return round((float)Database::val(
            "SELECT IFNULL(SUM(CASE WHEN entry_type IN ('charge','refund') THEN amount ELSE -amount END),0)
               FROM petty_cash_entries WHERE fund_id=? AND status='approved' AND is_active=1", [$fundId], 0), 2);
    }

    /** ذخیرهٔ تنخواه (ایجاد/ویرایش) */
    public static function saveFund(array $d, ?int $id = null): int
    {
        $biz = (int)Auth::businessId();
        $title = mb_substr(trim((string)($d['title'] ?? '')), 0, 150);
        if (mb_strlen($title) < 2) throw new RuntimeException('عنوان تنخواه را وارد کنید.');
        $gl = (int)($d['gl_account_id'] ?? 0);
        if (!$gl || !Database::val('SELECT COUNT(*) FROM chart_of_accounts WHERE id=? AND business_id=? AND is_group=0', [$gl, $biz]))
            throw new RuntimeException('حساب کل تنخواه را انتخاب کنید.');
        $status = in_array((string)($d['status'] ?? 'active'), ['active','suspended','closed'], true) ? (string)$d['status'] : 'active';
        $row = [
            'title' => $title,
            'keeper_user_id' => !empty($d['keeper_user_id']) ? (int)$d['keeper_user_id'] : null,
            'person_id' => !empty($d['person_id']) ? (int)$d['person_id'] : null,
            'gl_account_id' => $gl,
            'ceiling_amount' => round((float)($d['ceiling_amount'] ?? 0), 2),
            'low_balance_amount' => round((float)($d['low_balance_amount'] ?? 0), 2),
            'status' => $status,
            'note' => mb_substr(trim((string)($d['note'] ?? '')), 0, 255) ?: null,
            'is_active' => 1,
        ];
        if ($id && self::fund($id)) {
            $row['updated_at'] = now(); $row['updated_by'] = Auth::id();
            Database::update('petty_cash_funds', $row, 'id=:pk AND business_id=:biz', ['pk' => $id, 'biz' => $biz]);
            Audit::log('update', 'petty_cash_funds', $id, 'ویرایش تنخواه ' . $title);
            return $id;
        }
        $code = mb_substr(trim((string)($d['code'] ?? '')), 0, 30);
        if ($code === '') $code = self::nextFundCode($biz);
        if (Database::val('SELECT COUNT(*) FROM petty_cash_funds WHERE business_id=? AND code=?', [$biz, $code]))
            throw new RuntimeException('کد تنخواه «' . $code . '» تکراری است.');
        $row['business_id'] = $biz;
        $row['code'] = $code;
        $row['created_at'] = now();
        $row['created_by'] = Auth::id();
        $newId = (int)Database::insert('petty_cash_funds', $row);
        Audit::log('create', 'petty_cash_funds', $newId, 'ایجاد تنخواه ' . $title);
        return $newId;
    }

    /** کد بعدی تنخواه (PC-001 …) */
    public static function nextFundCode(int $biz): string
    {
        $max = 0;
        foreach (Database::all('SELECT code FROM petty_cash_funds WHERE business_id=?', [$biz]) as $r) {
            if (preg_match('/(\d+)\s*$/', (string)$r['code'], $m)) $max = max($max, (int)$m[1]);
        }
        return 'PC-' . str_pad((string)($max + 1), 3, '0', STR_PAD_LEFT);
    }

    /** حذف تنخواه (فقط اگر سندی نداشته باشد) */
    public static function deleteFund(int $id): void
    {
        $biz = (int)Auth::businessId();
        $f = self::fund($id);
        if (!$f) throw new RuntimeException('تنخواه یافت نشد.');
        $n = (int)Database::val('SELECT COUNT(*) FROM petty_cash_entries WHERE fund_id=?', [$id], 0);
        if ($n > 0) throw new RuntimeException('این تنخواه ' . num($n) . ' سند دارد؛ برای حذف، ابتدا اسناد آن را حذف/لغو کنید.');
        Database::run('DELETE FROM petty_cash_funds WHERE id=? AND business_id=?', [$id, $biz]);
        Audit::log('delete', 'petty_cash_funds', $id, 'حذف تنخواه ' . $f['title']);
    }

    /* ─────────────── اسناد ─────────────── */

    /** فهرست اسناد با فیلتر */
    public static function entries(array $f = [], int $limit = 50, int $offset = 0): array
    {
        $biz = (int)Auth::businessId();
        $w = ['e.business_id = ?', 'e.is_active = 1']; $p = [$biz];
        // محدودسازی به تنخواه‌های مجاز کاربر
        if (!self::canApprove() && !self::canEdit()) {
            $w[] = 'f.keeper_user_id = ?'; $p[] = (int)Auth::id();
        }
        if (!empty($f['fund_id'])) { $w[] = 'e.fund_id = ?'; $p[] = (int)$f['fund_id']; }
        if (!empty($f['type'])) { $w[] = 'e.entry_type = ?'; $p[] = (string)$f['type']; }
        if (!empty($f['status'])) { $w[] = 'e.status = ?'; $p[] = (string)$f['status']; }
        if (!empty($f['category_id'])) { $w[] = 'e.category_id = ?'; $p[] = (int)$f['category_id']; }
        if (!empty($f['q'])) {
            $w[] = '(e.doc_no LIKE ? OR e.title LIKE ? OR e.description LIKE ? OR e.reference_no LIKE ?)';
            array_push($p, '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%');
        }
        if (!empty($f['from'])) { $w[] = 'e.doc_date >= ?'; $p[] = $f['from']; }
        if (!empty($f['to'])) { $w[] = 'e.doc_date <= ?'; $p[] = $f['to']; }
        $where = implode(' AND ', $w);
        $limit = max(1, min(500, $limit)); $offset = max(0, $offset);
        return Database::all("SELECT e.*, f.title AS fund_title, f.code AS fund_code, u.full_name AS creator_name,
                                     cu.title AS category_title, cash.title AS cash_title,
                                     (SELECT COUNT(*) FROM petty_cash_attachments x WHERE x.entry_id=e.id) AS attach_count
                                FROM petty_cash_entries e
                                JOIN petty_cash_funds f ON f.id = e.fund_id
                                LEFT JOIN users u ON u.id = e.created_by
                                LEFT JOIN profit_loss_categories cu ON cu.id = e.category_id
                                LEFT JOIN cash_accounts cash ON cash.id = e.cash_account_id
                               WHERE $where
                               ORDER BY e.doc_date DESC, e.id DESC LIMIT $offset, $limit", $p);
    }

    public static function entriesCount(array $f = []): int
    {
        $biz = (int)Auth::businessId();
        $w = ['e.business_id = ?', 'e.is_active = 1']; $p = [$biz];
        if (!self::canApprove() && !self::canEdit()) { $w[] = 'f.keeper_user_id = ?'; $p[] = (int)Auth::id(); }
        if (!empty($f['fund_id'])) { $w[] = 'e.fund_id = ?'; $p[] = (int)$f['fund_id']; }
        if (!empty($f['type'])) { $w[] = 'e.entry_type = ?'; $p[] = (string)$f['type']; }
        if (!empty($f['status'])) { $w[] = 'e.status = ?'; $p[] = (string)$f['status']; }
        if (!empty($f['category_id'])) { $w[] = 'e.category_id = ?'; $p[] = (int)$f['category_id']; }
        if (!empty($f['q'])) {
            $w[] = '(e.doc_no LIKE ? OR e.title LIKE ? OR e.description LIKE ? OR e.reference_no LIKE ?)';
            array_push($p, '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%', '%' . $f['q'] . '%');
        }
        if (!empty($f['from'])) { $w[] = 'e.doc_date >= ?'; $p[] = $f['from']; }
        if (!empty($f['to'])) { $w[] = 'e.doc_date <= ?'; $p[] = $f['to']; }
        return (int)Database::val("SELECT COUNT(*) FROM petty_cash_entries e JOIN petty_cash_funds f ON f.id=e.fund_id WHERE " . implode(' AND ', $w), $p, 0);
    }

    public static function entry(int $id): ?array
    {
        $biz = (int)Auth::businessId();
        $e = Database::one("SELECT e.*, f.title AS fund_title, f.code AS fund_code, f.gl_account_id, f.keeper_user_id,
                                   a.code AS gl_code, a.title AS gl_title,
                                   cu.title AS category_title, cc.name AS cost_center_name,
                                   cash.title AS cash_title, ea.code AS expense_account_code, ea.title AS expense_account_title,
                                   p.first_name, p.last_name, p.company_name
                              FROM petty_cash_entries e
                              JOIN petty_cash_funds f ON f.id = e.fund_id
                              LEFT JOIN chart_of_accounts a ON a.id = f.gl_account_id
                              LEFT JOIN profit_loss_categories cu ON cu.id = e.category_id
                              LEFT JOIN cost_centers cc ON cc.id = e.cost_center_id
                              LEFT JOIN cash_accounts cash ON cash.id = e.cash_account_id
                              LEFT JOIN chart_of_accounts ea ON ea.id = e.expense_account_id
                              LEFT JOIN persons p ON p.id = e.person_id
                             WHERE e.id=? AND e.business_id=? AND e.is_active=1", [$id, $biz]);
        if ($e) $e['attachments'] = self::attachments($id);
        return $e;
    }

    /** ثبت سند تنخواه (اگر کاربر مجوز تأیید نداشته باشد، در انتظار تأیید می‌ماند) */
    public static function createEntry(array $d): int
    {
        $biz = (int)Auth::businessId();
        $f = self::fund((int)($d['fund_id'] ?? 0));
        if (!$f) throw new RuntimeException('تنخواه را انتخاب کنید.');
        if (!self::canSee($f)) throw new RuntimeException('به این تنخواه دسترسی ندارید.');
        if ((string)$f['status'] !== 'active') throw new RuntimeException('این تنخواه فعال نیست؛ امکان ثبت سند وجود ندارد.');
        $type = (string)($d['entry_type'] ?? '');
        if (!isset(self::TYPES[$type])) throw new RuntimeException('نوع سند نامعتبر است.');
        $amount = round((float)($d['amount'] ?? 0), 2);
        if ($amount <= 0) throw new RuntimeException('مبلغ سند باید بزرگ‌تر از صفر باشد.');
        $title = mb_substr(trim((string)($d['title'] ?? '')), 0, 200);
        if ($title === '') throw new RuntimeException('«بابت» سند را وارد کنید.');
        $date = (string)($d['doc_date'] ?? today());
        [$fy] = Posting::periodFor($biz, $date);
        Posting::assertPeriodOpen($fy, null);

        $approved = self::canApprove() && !empty($d['auto_approve']);
        return Database::transaction(function () use ($biz, $f, $type, $amount, $title, $date, $fy, $d, $approved) {
            $docNo = Sequence::next($biz, (int)$fy['id'], 'voucher', ['fy' => (int)substr((string)$fy['title'], -4), 'template' => 'PC-{FY}-{SEQ}']);
            $id = (int)Database::insert('petty_cash_entries', [
                'business_id' => $biz, 'fiscal_year_id' => $fy['id'], 'fund_id' => (int)$f['id'],
                'doc_no' => $docNo, 'doc_date' => $date, 'entry_type' => $type, 'amount' => $amount, 'title' => $title,
                'category_id' => !empty($d['category_id']) ? (int)$d['category_id'] : null,
                'cost_center_id' => !empty($d['cost_center_id']) ? (int)$d['cost_center_id'] : null,
                'person_id' => !empty($d['person_id']) ? (int)$d['person_id'] : null,
                'expense_account_id' => !empty($d['expense_account_id']) ? (int)$d['expense_account_id'] : null,
                'cash_account_id' => !empty($d['cash_account_id']) ? (int)$d['cash_account_id'] : null,
                'reference_no' => mb_substr(trim((string)($d['reference_no'] ?? '')), 0, 80) ?: null,
                'description' => mb_substr(trim((string)($d['description'] ?? '')), 0, 2000) ?: null,
                'attachment' => !empty($d['attachment']) ? (string)$d['attachment'] : null,
                'status' => $approved ? 'approved' : 'pending',
                'requested_by' => Auth::id(),
                'approved_by' => $approved ? Auth::id() : null,
                'approved_at' => $approved ? now() : null,
                'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            if ($approved) self::post($id);
            Audit::log('create', 'petty_cash_entries', $id, 'ثبت ' . self::typeTitle($type) . ' ' . $docNo, ['amount' => $amount]);
            return $id;
        });
    }

    /** تأیید سند: سند حسابداری صادر و وضعیت به تأییدشده می‌رود */
    public static function approve(int $id): void
    {
        $e = self::entry($id);
        if (!$e) throw new RuntimeException('سند یافت نشد.');
        if ($e['status'] !== 'pending') throw new RuntimeException('این سند در وضعیت «' . self::statusTitle($e['status']) . '» است.');
        Database::transaction(function () use ($id, $e) {
            Database::run('UPDATE petty_cash_entries SET status="approved", approved_by=?, approved_at=NOW(), updated_at=NOW(), updated_by=? WHERE id=?',
                [Auth::id(), Auth::id(), $id]);
            self::post($id);
        });
        Audit::log('approve', 'petty_cash_entries', $id, 'تأیید سند تنخواه ' . $e['doc_no']);
    }

    /** رد سند (بدون سند حسابداری) */
    public static function reject(int $id, string $reason): void
    {
        $e = self::entry($id);
        if (!$e) throw new RuntimeException('سند یافت نشد.');
        if ($e['status'] !== 'pending') throw new RuntimeException('فقط سند در انتظار تأیید قابل رد است.');
        Database::run('UPDATE petty_cash_entries SET status="rejected", reject_reason=?, approved_by=?, approved_at=NOW(), updated_at=NOW(), updated_by=? WHERE id=?',
            [mb_substr($reason, 0, 255) ?: 'بدون توضیح', Auth::id(), Auth::id(), $id]);
        Audit::log('reject', 'petty_cash_entries', $id, 'رد سند تنخواه ' . $e['doc_no']);
    }

    /** حذف سند (سند حسابداری آن هم برمی‌گردد) */
    public static function deleteEntry(int $id): void
    {
        $e = self::entry($id);
        if (!$e) throw new RuntimeException('سند یافت نشد.');
        Database::transaction(function () use ($id, $e) {
            if (!empty($e['journal_entry_id'])) {
                try { Posting::reverse((int)$e['journal_entry_id'], 'حذف سند تنخواه ' . $e['doc_no']); } catch (Throwable $x) { /* رد شود */ }
            }
            foreach (self::attachments($id) as $a) self::deleteAttachment($a);
            Database::run('DELETE FROM petty_cash_attachments WHERE entry_id=?', [$id]);
            Database::run('DELETE FROM petty_cash_entries WHERE id=?', [$id]);
            // هم‌گام‌سازی مانده‌ها پس از حذف
            Trade::refreshCashBalances((int)Auth::businessId());
        });
        Audit::log('delete', 'petty_cash_entries', $id, 'حذف سند تنخواه ' . $e['doc_no']);
    }

    /** ساخت سند حسابداری یک سند تنخواه */
    public static function post(int $entryId): ?int
    {
        $e = self::entry($entryId);
        if (!$e || $e['status'] !== 'approved') return null;
        $biz = (int)$e['business_id'];
        $fundGl = (int)$e['gl_account_id'];
        $amount = (float)$e['amount'];
        $ctx = ['date' => (string)$e['doc_date'], 'reference_type' => 'petty_cash', 'reference_id' => $entryId,
            'reference_no' => (string)$e['doc_no'], 'cost_center_id' => $e['cost_center_id'] ?: null,
            'person_id' => $e['person_id'] ?: null, 'source' => 'auto', 'entry_type' => 'normal'];
        $desc = self::typeTitle((string)$e['entry_type']) . ' - ' . $e['title'];
        $lines = [];
        switch ((string)$e['entry_type']) {
            case 'charge':  // شارژ: بدهکار تنخواه / بستانکار بانک یا صندوق
                $cashGl = self::cashGl((int)($e['cash_account_id'] ?? 0));
                $lines = [
                    ['account_id' => $fundGl, 'debit' => $amount, 'description' => $desc, 'cost_center_id' => $e['cost_center_id'] ?: null],
                    ['account_id' => $cashGl, 'credit' => $amount, 'description' => $desc],
                ];
                break;
            case 'settle':  // تسویه: بدهکار بانک یا صندوق / بستانکار تنخواه
                $cashGl = self::cashGl((int)($e['cash_account_id'] ?? 0));
                $lines = [
                    ['account_id' => $cashGl, 'debit' => $amount, 'description' => $desc],
                    ['account_id' => $fundGl, 'credit' => $amount, 'description' => $desc, 'cost_center_id' => $e['cost_center_id'] ?: null],
                ];
                break;
            case 'expense': // هزینه: بدهکار حساب هزینه / بستانکار تنخواه
            case 'refund':  // برگشت هزینه: بدهکار تنخواه / بستانکار حساب هزینه
                $expGl = (int)($e['expense_account_id'] ?? 0);
                if (!$expGl) $expGl = self::defaultExpenseAccount((int)($e['category_id'] ?? 0));
                if (!$expGl) throw new RuntimeException('حساب هزینه تعیین نشده است (مرکز هزینه یا حساب هزینه را انتخاب کنید).');
                $lines = (string)$e['entry_type'] === 'expense'
                    ? [['account_id' => $expGl, 'debit' => $amount, 'description' => $desc, 'person_id' => $e['person_id'] ?: null, 'cost_center_id' => $e['cost_center_id'] ?: null],
                       ['account_id' => $fundGl, 'credit' => $amount, 'description' => $desc]]
                    : [['account_id' => $fundGl, 'debit' => $amount, 'description' => $desc],
                       ['account_id' => $expGl, 'credit' => $amount, 'description' => $desc, 'person_id' => $e['person_id'] ?: null, 'cost_center_id' => $e['cost_center_id'] ?: null]];
                break;
            default:
                return null;
        }
        $jeId = Posting::create($biz, $ctx + ['description' => $desc . ' (' . $e['doc_no'] . ')'], $lines);
        Database::run('UPDATE petty_cash_entries SET journal_entry_id=? WHERE id=?', [$jeId, $entryId]);
        // هم‌گام‌سازی ماندهٔ حساب نقد/بانک درگیر (شارژ/تسویه)
        if (!empty($e['cash_account_id'])) Trade::updateCashBalance((int)$e['cash_account_id']);
        Trade::refreshCashBalances($biz);
        return $jeId;
    }

    /** حساب کل یک حساب نقد/بانک */
    private static function cashGl(int $cashAccountId): int
    {
        $gl = (int)Database::val('SELECT gl_account_id FROM cash_accounts WHERE id=? AND business_id=?', [$cashAccountId, (int)Auth::businessId()], 0);
        if (!$gl) throw new RuntimeException('حساب نقد/بانک مبدأ یا مقصد را انتخاب کنید.');
        return $gl;
    }

    /** حساب پیش‌فرض هزینه (از مرکز هزینه یا نگاشت هزینهٔ پیش‌فرض) */
    public static function defaultExpenseAccount(int $categoryId = 0): int
    {
        if ($categoryId) {
            $a = (int)Database::val('SELECT default_account_id FROM profit_loss_categories WHERE id=?', [$categoryId], 0);
            if ($a) return $a;
        }
        return (int)Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key="expense_default"', [(int)Auth::businessId()], 0);
    }

    /* ─────────────── پیوست ─────────────── */
    public const DOC_EXT = ['jpg','jpeg','png','webp','gif','pdf','doc','docx','xls','xlsx','csv','txt'];
    public const MAX_SIZE = 8388608;      // ۸ مگابایت
    public const MAX_FILES = 5;

    public static function dir(int $biz, int $entryId): string { return storage_path('petty-cash/' . $biz . '/' . $entryId); }

    public static function attachments(int $entryId): array
    {
        return Database::all('SELECT * FROM petty_cash_attachments WHERE entry_id=? ORDER BY id', [$entryId]);
    }

    public static function attachment(int $id): ?array
    {
        return Database::one('SELECT * FROM petty_cash_attachments WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
    }

    public static function attachmentPath(array $a): string { return storage_path('petty-cash/' . $a['storage_key']); }

    /** ذخیرهٔ فایل‌های پیوست یک سند */
    public static function saveUploads(int $entryId, string $field = 'files'): array
    {
        $biz = (int)Auth::businessId();
        $e = self::entry($entryId);
        if (!$e) return ['error' => 'سند یافت نشد.'];
        if (empty($_FILES[$field])) return [];
        $names = is_array($_FILES[$field]['name']) ? $_FILES[$field]['name'] : [$_FILES[$field]['name']];
        $tmp = is_array($_FILES[$field]['tmp_name']) ? $_FILES[$field]['tmp_name'] : [$_FILES[$field]['tmp_name']];
        $err = is_array($_FILES[$field]['error']) ? $_FILES[$field]['error'] : [$_FILES[$field]['error']];
        $sizes = is_array($_FILES[$field]['size']) ? $_FILES[$field]['size'] : [$_FILES[$field]['size']];
        $dir = self::dir($biz, $entryId);
        $saved = 0;
        foreach (array_slice($names, 0, self::MAX_FILES) as $i => $orig) {
            if ((int)($err[$i] ?? 4) !== UPLOAD_ERR_OK) continue;
            if ((int)($sizes[$i] ?? 0) > self::MAX_SIZE) return ['error' => 'حجم فایل «' . $orig . '» بیش از ۸ مگابایت است.'];
            if (!is_uploaded_file((string)$tmp[$i])) continue;
            $ext = strtolower(pathinfo((string)$orig, PATHINFO_EXTENSION));
            if (!in_array($ext, self::DOC_EXT, true)) return ['error' => 'فرمت فایل «' . $orig . '» مجاز نیست.'];
            if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) return ['error' => 'ساخت پوشهٔ ذخیره ممکن نشد.'];
            $safe = 'pc' . $entryId . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $ext;
            if (!@move_uploaded_file((string)$tmp[$i], $dir . '/' . $safe)) continue;
            @chmod($dir . '/' . $safe, 0644);
            Database::insert('petty_cash_attachments', ['business_id' => $biz, 'entry_id' => $entryId, 'user_id' => Auth::id(),
                'file_name' => mb_substr((string)$orig, 0, 190), 'storage_key' => $biz . '/' . $entryId . '/' . $safe,
                'mime_type' => mime_content_type($dir . '/' . $safe) ?: null, 'size_bytes' => (int)$sizes[$i], 'created_at' => now()]);
            $saved++;
        }
        return ['saved' => $saved];
    }

    public static function deleteAttachment(array $a): void
    {
        $p = self::attachmentPath($a);
        if (is_file($p)) @unlink($p);
    }

    /* ─────────────── گزارش و آمار ─────────────── */

    /** آمار کلی در بازه */
    public static function stats(string $from, string $to, int $fundId = 0): array
    {
        $biz = (int)Auth::businessId();
        $w = ['business_id = ?', 'is_active = 1', 'doc_date BETWEEN ? AND ?']; $p = [$biz, $from, $to];
        if ($fundId) { $w[] = 'fund_id = ?'; $p[] = $fundId; }
        if (!self::canApprove() && !self::canEdit()) {
            $w[] = 'fund_id IN (SELECT id FROM petty_cash_funds WHERE keeper_user_id=?)'; $p[] = (int)Auth::id();
        }
        $rows = Database::all("SELECT entry_type, status, COUNT(*) cnt, IFNULL(SUM(amount),0) total
                                 FROM petty_cash_entries WHERE " . implode(' AND ', $w) . " GROUP BY entry_type, status", $p);
        $out = ['charge' => 0.0, 'expense' => 0.0, 'refund' => 0.0, 'settle' => 0.0,
            'pending' => 0, 'pending_amount' => 0.0, 'approved_count' => 0, 'rejected' => 0, 'rejected_amount' => 0.0];
        foreach ($rows as $r) {
            $t = (string)$r['entry_type']; $s = (string)$r['status'];
            if ($s === 'approved') $out[$t] = round($out[$t] + (float)$r['total'], 2);
            if ($s === 'approved') $out['approved_count'] += (int)$r['cnt'];
            if ($s === 'pending') { $out['pending'] += (int)$r['cnt']; $out['pending_amount'] = round($out['pending_amount'] + (float)$r['total'], 2); }
            if ($s === 'rejected') { $out['rejected'] += (int)$r['cnt']; $out['rejected_amount'] = round($out['rejected_amount'] + (float)$r['total'], 2); }
        }
        $out['balance'] = round($out['charge'] + $out['refund'] - $out['expense'] - $out['settle'], 2);
        $funds = self::visibleFunds();
        $out['funds_count'] = count($funds);
        $out['funds_balance'] = round(array_sum(array_map(fn($f) => (float)$f['balance'], $funds)), 2);
        $out['low_count'] = count(array_filter($funds, fn($f) => !empty($f['low'])));
        return $out;
    }

    /** هزینه‌های تأییدشده به تفکیک مرکز هزینه */
    public static function byCategory(string $from, string $to, int $fundId = 0): array
    {
        $biz = (int)Auth::businessId();
        $w = ['e.business_id = ?', 'e.is_active = 1', "e.status = 'approved'", "e.entry_type = 'expense'", 'e.doc_date BETWEEN ? AND ?'];
        $p = [$biz, $from, $to];
        if ($fundId) { $w[] = 'e.fund_id = ?'; $p[] = $fundId; }
        if (!self::canApprove() && !self::canEdit()) { $w[] = 'f.keeper_user_id = ?'; $p[] = (int)Auth::id(); }
        return Database::all("SELECT IFNULL(cu.title,'بدون مرکز هزینه') AS title, COUNT(*) cnt, IFNULL(SUM(e.amount),0) total
                                FROM petty_cash_entries e JOIN petty_cash_funds f ON f.id=e.fund_id
                                LEFT JOIN profit_loss_categories cu ON cu.id=e.category_id
                               WHERE " . implode(' AND ', $w) . "
                               GROUP BY cu.title ORDER BY total DESC", $p);
    }

    /** گردش یک تنخواه در بازه (کارت تنخواه) */
    public static function ledger(int $fundId, string $from, string $to): array
    {
        $biz = (int)Auth::businessId();
        $opening = round((float)Database::val("SELECT IFNULL(SUM(CASE WHEN entry_type IN ('charge','refund') THEN amount ELSE -amount END),0)
                                                 FROM petty_cash_entries WHERE business_id=? AND fund_id=? AND status='approved' AND is_active=1 AND doc_date < ?",
            [$biz, $fundId, $from], 0), 2);
        $rows = Database::all("SELECT * FROM petty_cash_entries
                                WHERE business_id=? AND fund_id=? AND is_active=1 AND status='approved' AND doc_date BETWEEN ? AND ?
                                ORDER BY doc_date, id", [$biz, $fundId, $from, $to]);
        return ['opening' => $opening, 'rows' => $rows];
    }
}
