<?php
/**
 * برنامه‌ریز (پلنر) — رویدادها، وظایف، تخصیص به کاربران، وضعیت انجام و اعلان‌ها.
 * • هر کاربر فقط رویدادهایی را می‌بیند که «مسئول» آن است یا خودش ساخته است؛ مدیر کسب‌وکار همه را می‌بیند.
 * • پشتیبانی از بازهٔ تاریخ (از…تا)، ساعت، اولویت، تکرار، یادآوری و گفت‌وگو.
 */
final class Planner
{
    /** رنگ برچسب‌ها */
    public const COLORS = [
        'purple' => ['#6D28D9', '#F1ECFE'], 'blue' => ['#1D4ED8', '#E8EFFE'],
        'teal'   => ['#0F766E', '#E3F5F2'], 'green' => ['#047857', '#E6F6EF'],
        'gold'   => ['#B45309', '#FDF3E3'], 'red' => ['#BE123C', '#FDECEF'],
        'pink'   => ['#DB2777', '#FDEBF3'], 'slate' => ['#475569', '#EEF2F7'],
    ];

    public const PRIORITIES = ['low' => 'کم', 'normal' => 'معمولی', 'high' => 'زیاد', 'urgent' => 'فوری'];

    public const STATUSES = ['open' => 'باز', 'in_progress' => 'در جریان', 'done' => 'انجام‌شده', 'failed' => 'انجام‌نشده', 'cancelled' => 'لغو‌شده'];

    public const REPEATS = ['none' => 'بدون تکرار', 'daily' => 'روزانه', 'weekly' => 'هفتگی', 'monthly' => 'ماهانه', 'yearly' => 'سالانه'];

    /** روزهای هفته به ترتیب تقویم ایرانی (شنبه اول) */
    public const WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

    private static ?array $settings = null;

    /* ───────────── تنظیمات ───────────── */

    public static function settings(?int $biz = null): array
    {
        $biz = $biz ?: (int)Auth::businessId();
        if (self::$settings !== null && $biz === (int)Auth::businessId()) return self::$settings;
        $days = Settings::get('planner.work_days', [0, 1, 2, 3, 4, 5], $biz);
        if (!is_array($days) || !$days) $days = [0, 1, 2, 3, 4, 5];
        return self::$settings = [
            'reminder_days'     => (int)Settings::get('planner.reminder_days', 1, $biz),
            'default_view'      => (string)Settings::get('planner.default_view', 'month', $biz),
            'work_days'         => array_map('intval', $days),
            'max_visible'       => max(1, min(6, (int)Settings::get('planner.max_visible', 3, $biz))),
            'allow_user_create' => (bool)Settings::get('planner.allow_user_create', true, $biz),
            'notify_manager'    => (bool)Settings::get('planner.notify_manager', true, $biz),
        ];
    }

    /** پاک‌کردن کش تنظیمات (پس از تغییر از راه تنظیمات) */
    public static function flush(): void { self::$settings = null; }

    /* ───────────── دسترسی ───────────── */

    /** مدیر کسب‌وکار ⇒ دیدن/مدیریت همهٔ رویدادها */
    public static function canManageAll(): bool { return Auth::isAdmin(); }

    /** شرط ایزوله‌بودن: کاربر عادی فقط رویدادهای خودش */
    private static function scopeSql(string &$sql, array &$pr, string $alias = 'p'): void
    {
        if (self::canManageAll()) return;
        $sql .= " AND ({$alias}.assignee_user_id = ? OR {$alias}.created_by = ?)";
        $pr[] = (int)Auth::id();
        $pr[] = (int)Auth::id();
    }

    public static function canView(array $e): bool
    {
        if (self::canManageAll()) return true;
        $me = (int)Auth::id();
        return (int)($e['assignee_user_id'] ?? 0) === $me || (int)($e['created_by'] ?? 0) === $me;
    }

    public static function canEdit(array $e): bool
    {
        if (self::canManageAll()) return true;
        return (int)($e['created_by'] ?? 0) === (int)Auth::id();
    }

    public static function canUpdateStatus(array $e): bool
    {
        if (self::canManageAll()) return true;
        $me = (int)Auth::id();
        return (int)($e['assignee_user_id'] ?? 0) === $me || (int)($e['created_by'] ?? 0) === $me;
    }

    /* ───────────── انواع رویداد ───────────── */

    public static function types(bool $activeOnly = true): array
    {
        $biz = (int)Auth::businessId();
        self::seedTypes($biz);
        $w = $activeOnly ? ' AND is_active=1' : '';
        return Database::all("SELECT * FROM planner_types WHERE business_id=? AND deleted_at IS NULL$w ORDER BY sort_order, id", [$biz]);
    }

    /** ساخت انواع پیش‌فرض در اولین استفاده */
    public static function seedTypes(int $biz, ?int $uid = null): int
    {
        $n = (int)Database::val('SELECT COUNT(*) FROM planner_types WHERE business_id=? AND deleted_at IS NULL', [$biz], 0);
        if ($n > 0) return 0;
        $defaults = [
            ['وظیفه', 'purple', 'check', 1], ['جلسه', 'blue', 'users', 2], ['یادآوری', 'gold', 'bell', 3],
            ['تحویل و ارسال', 'teal', 'truck', 4], ['بازدید و سرکشی', 'green', 'eye', 5], ['مهلت قانونی', 'red', 'shield', 6],
        ];
        foreach ($defaults as [$t, $c, $i, $s]) {
            Database::insert('planner_types', ['business_id' => $biz, 'title' => $t, 'color' => $c, 'icon' => $i,
                'is_active' => 1, 'sort_order' => $s, 'created_at' => now(), 'created_by' => $uid ?? Auth::id()]);
        }
        return count($defaults);
    }

    /* ───────────── تقویم شمسی ───────────── */

    public static function jalaliMonthLen(int $jy, int $jm): int
    {
        if ($jm <= 6) return 31;
        if ($jm <= 11) return 30;
        return (($jy % 33) % 4 === 1) ? 30 : 29;   // اسفند
    }

    public static function jalaliMonthName(int $m): string
    {
        return ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'][max(1, min(12, $m)) - 1];
    }

    /** خانه‌های ماه شمسی: [null | ['j'=>روز شمسی,'iso'=>تاریخ میلادی,'wd'=>۰=شنبه]] */
    public static function monthGrid(int $jy, int $jm): array
    {
        $len = self::jalaliMonthLen($jy, $jm);
        [$gy, $gm, $gd] = jalali_to_gregorian($jy, $jm, 1);
        $lead = ((int)date('w', mktime(0, 0, 0, $gm, $gd, $gy)) + 1) % 7;   // ۰=شنبه
        $cells = array_fill(0, $lead, null);
        for ($d = 1; $d <= $len; $d++) {
            [$y2, $m2, $d2] = jalali_to_gregorian($jy, $jm, $d);
            $ts = mktime(0, 0, 0, $m2, $d2, $y2);
            $cells[] = ['j' => $d, 'iso' => sprintf('%04d-%02d-%02d', $y2, $m2, $d2), 'wd' => ((int)date('w', $ts) + 1) % 7];
        }
        while (count($cells) % 7 !== 0 || count($cells) < 35) $cells[] = null;
        return $cells;
    }

    /* ───────────── رویدادها ───────────── */

    /**
     * رویدادهای یک بازه (تاریخ میلادی) با احترام به ایزوله‌بودن کاربر.
     * پارامترها: from, to, assignee, type_id, status (آرایه/رشته), q, priority
     */
    public static function events(string $from, string $to, array $f = []): array
    {
        $biz = (int)Auth::businessId();
        $sql = "SELECT p.*, t.title AS type_title, t.color AS type_color, t.icon AS type_icon,
                       u.full_name AS assignee_name, u.avatar_path AS assignee_avatar,
                       c.full_name AS creator_name, c.avatar_path AS creator_avatar, pr.name AS project_name
                  FROM planner_events p
                  LEFT JOIN projects pr ON pr.id = p.project_id
                  LEFT JOIN planner_types t ON t.id = p.type_id
                  LEFT JOIN users u ON u.id = p.assignee_user_id
                  LEFT JOIN users c ON c.id = p.created_by
                 WHERE p.business_id = ? AND p.deleted_at IS NULL AND p.is_active = 1
                   AND p.start_date <= ? AND IFNULL(p.end_date, p.start_date) >= ?";
        $pr = [$biz, $to, $from];
        self::scopeSql($sql, $pr, 'p');
        if (!empty($f['assignee'])) { $sql .= ' AND p.assignee_user_id = ?'; $pr[] = (int)$f['assignee']; }
        if (!empty($f['type_id'])) { $sql .= ' AND p.type_id = ?'; $pr[] = (int)$f['type_id']; }
        if (!empty($f['project_id'])) { $sql .= ' AND p.project_id = ?'; $pr[] = (int)$f['project_id']; }
        if (!empty($f['priority'])) { $sql .= ' AND p.priority = ?'; $pr[] = (string)$f['priority']; }
        $statuses = (array)($f['status'] ?? []);
        $statuses = array_values(array_filter($statuses, fn($s) => isset(self::STATUSES[$s])));
        if ($statuses) { $sql .= ' AND p.status IN (' . implode(',', array_fill(0, count($statuses), '?')) . ')'; $pr = array_merge($pr, $statuses); }
        $q = trim((string)($f['q'] ?? ''));
        if ($q !== '') { $sql .= ' AND (p.title LIKE ? OR p.description LIKE ? OR p.location LIKE ?)'; $like = '%' . $q . '%'; array_push($pr, $like, $like, $like); }
        $sql .= " ORDER BY p.start_date ASC, p.all_day DESC, p.start_time ASC,
                          FIELD(p.priority,'urgent','high','normal','low'), FIELD(p.status,'open','in_progress','done','failed','cancelled'), p.id DESC";
        return Database::all($sql, $pr);
    }

    /** رویدادها به تفکیک روز (برای تقویم): تاریخ میلادی ⇒ فهرست رویدادها */
    public static function byDay(array $events, string $from, string $to): array
    {
        $out = [];
        $cur = strtotime($from); $end = strtotime($to);
        while ($cur <= $end) { $out[date('Y-m-d', $cur)] = []; $cur += 86400; }
        foreach ($events as $e) {
            $s = max(strtotime((string)$e['start_date']), strtotime($from));
            $en = min(strtotime((string)($e['end_date'] ?: $e['start_date'])), $end);
            for ($t = $s; $t <= $en; $t += 86400) {
                $d = date('Y-m-d', $t);
                if (!isset($out[$d])) continue;
                $row = $e;
                $row['is_start'] = ($d === (string)$e['start_date']);
                $row['is_end'] = ($d === (string)($e['end_date'] ?: $e['start_date']));
                $row['span_days'] = max(1, (int)round((strtotime((string)($e['end_date'] ?: $e['start_date'])) - strtotime((string)$e['start_date'])) / 86400) + 1);
                $out[$d][] = $row;
            }
        }
        return $out;
    }

    public static function event(int $id): ?array
    {
        $biz = (int)Auth::businessId();
        $e = Database::one('SELECT p.*, t.title AS type_title, t.color AS type_color, t.icon AS type_icon,
                                   u.full_name AS assignee_name, u.avatar_path AS assignee_avatar,
                                   c.full_name AS creator_name, c.avatar_path AS creator_avatar, pr.name AS project_name
                              FROM planner_events p
                              LEFT JOIN projects pr ON pr.id = p.project_id
                              LEFT JOIN planner_types t ON t.id = p.type_id
                              LEFT JOIN users u ON u.id = p.assignee_user_id
                              LEFT JOIN users c ON c.id = p.created_by
                             WHERE p.id = ? AND p.business_id = ? AND p.deleted_at IS NULL', [$id, $biz]);
        if (!$e || !self::canView($e)) return null;
        return $e;
    }

    /** ذخیرهٔ رویداد (ایجاد/ویرایش) */
    public static function save(array $d, ?int $id = null): int
    {
        $biz = (int)Auth::businessId();
        if ($id) {
            $cur = self::event($id);
            if (!$cur) throw new RuntimeException('رویداد یافت نشد.');
            if (!self::canEdit($cur)) throw new RuntimeException('اجازهٔ ویرایش این رویداد را ندارید.');
        }
        $title = trim((string)($d['title'] ?? ''));
        if (mb_strlen($title) < 2) throw new RuntimeException('عنوان رویداد را وارد کنید.');
        $start = (string)($d['start_date'] ?? '') ?: today();
        $end = (string)($d['end_date'] ?? '') ?: null;
        if ($end && $end < $start) throw new RuntimeException('تاریخ پایان نمی‌تواند قبل از تاریخ شروع باشد.');
        $row = [
            'business_id' => $biz, 'type_id' => !empty($d['type_id']) ? (int)$d['type_id'] : null,
            'project_id' => !empty($d['project_id']) ? (int)$d['project_id'] : null,
            'title' => mb_substr($title, 0, 190), 'description' => trim((string)($d['description'] ?? '')) ?: null,
            'location' => mb_substr(trim((string)($d['location'] ?? '')), 0, 190) ?: null,
            'start_date' => $start, 'end_date' => $end,
            'all_day' => !empty($d['all_day']) ? 1 : 0,
            'start_time' => empty($d['all_day']) ? (($d['start_time'] ?? '') ?: null) : null,
            'end_time' => empty($d['all_day']) ? (($d['end_time'] ?? '') ?: null) : null,
            'priority' => array_key_exists((string)($d['priority'] ?? ''), self::PRIORITIES) ? (string)$d['priority'] : 'normal',
            'assignee_user_id' => !empty($d['assignee_user_id']) ? (int)$d['assignee_user_id'] : null,
            'repeat_rule' => array_key_exists((string)($d['repeat_rule'] ?? ''), self::REPEATS) ? (string)$d['repeat_rule'] : 'none',
            'remind_days' => max(0, min(60, (int)($d['remind_days'] ?? 1))),
            'is_active' => 1,
        ];
        // کاربر عادی فقط می‌تواند رویداد خودش را بسازد
        if (!self::canManageAll()) {
            if ($id) { $row['assignee_user_id'] = $cur['assignee_user_id'] ?? (int)Auth::id(); }
            elseif (!self::settings()['allow_user_create']) throw new RuntimeException('ثبت رویداد برای شما مجاز نیست.');
            elseif (empty($row['assignee_user_id'])) $row['assignee_user_id'] = (int)Auth::id();
        }
        if ($id) {
            $row['updated_at'] = now(); $row['updated_by'] = Auth::id();
            Database::run('UPDATE planner_events SET ' . implode(', ', array_map(fn($k) => "`$k`=?", array_keys($row))) . ' WHERE id=? AND business_id=?',
                array_merge(array_values($row), [$id, $biz]));
            Audit::log('update', 'planner_events', $id, 'ویرایش رویداد «' . $row['title'] . '»');
            return $id;
        }
        $row['status'] = 'open'; $row['progress'] = 0;
        $row['created_at'] = now(); $row['created_by'] = Auth::id();
        $newId = (int)Database::insert('planner_events', $row);
        Audit::log('create', 'planner_events', $newId, 'ثبت رویداد «' . $row['title'] . '»');
        return $newId;
    }

    /** تغییر وضعیت انجام (انجام شد / انجام نشد / در جریان) + توضیح */
    public static function setStatus(int $id, string $status, string $note = '', int $progress = -1): void
    {
        $e = self::event($id);
        if (!$e) throw new RuntimeException('رویداد یافت نشد.');
        if (!self::canUpdateStatus($e)) throw new RuntimeException('اجازهٔ تغییر وضعیت این رویداد را ندارید.');
        if (!isset(self::STATUSES[$status])) throw new RuntimeException('وضعیت نامعتبر است.');
        if (in_array($status, ['failed'], true) && mb_strlen(trim($note)) < 3) throw new RuntimeException('برای «انجام‌نشده» توضیح دلیل الزامی است.');
        $data = ['status' => $status, 'completion_note' => trim($note) ?: null, 'updated_at' => now(), 'updated_by' => Auth::id()];
        if ($progress >= 0) $data['progress'] = max(0, min(100, $progress));
        elseif ($status === 'done') $data['progress'] = 100;
        elseif ($status === 'in_progress') $data['progress'] = max(10, (int)$e['progress']);
        if (in_array($status, ['done', 'failed'], true)) { $data['completed_at'] = now(); $data['completed_by'] = Auth::id(); }
        if ($status === 'cancelled') { $data['completed_at'] = now(); $data['completed_by'] = Auth::id(); }
        if ($status === 'open' || $status === 'in_progress') { $data['completed_at'] = null; $data['completed_by'] = null; }
        Database::run('UPDATE planner_events SET ' . implode(', ', array_map(fn($k) => "`$k`=?", array_keys($data))) . ' WHERE id=? AND business_id=?',
            array_merge(array_values($data), [$id, (int)Auth::businessId()]));
        Audit::log('update', 'planner_events', $id, 'وضعیت رویداد → ' . self::STATUSES[$status]);
    }

    public static function deleteEvent(int $id): void
    {
        $e = self::event($id);
        if (!$e) throw new RuntimeException('رویداد یافت نشد.');
        if (!self::canEdit($e)) throw new RuntimeException('اجازهٔ حذف این رویداد را ندارید.');
        Database::run('UPDATE planner_events SET deleted_at=NOW(), is_active=0 WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
        Audit::log('delete', 'planner_events', $id, 'حذف رویداد');
    }

    /* ───────────── گفت‌وگو ───────────── */

    public static function comments(int $eventId): array
    {
        return Database::all('SELECT c.*, u.full_name AS user_name, u.avatar_path AS user_avatar FROM planner_comments c
                               LEFT JOIN users u ON u.id = c.user_id
                              WHERE c.event_id = ? ORDER BY c.id ASC LIMIT 200', [$eventId]);
    }

    public static function comment(int $eventId, string $body): void
    {
        $e = self::event($eventId);
        if (!$e) throw new RuntimeException('رویداد یافت نشد.');
        $body = trim($body);
        if ($body === '') throw new RuntimeException('متن پیام خالی است.');
        Database::insert('planner_comments', ['business_id' => (int)Auth::businessId(), 'event_id' => $eventId,
            'user_id' => (int)Auth::id(), 'body' => mb_substr($body, 0, 600), 'created_at' => now()]);
    }

    /* ───────────── پیوست‌های هر رویداد ───────────── */

    /** پسوندهای مجاز پیوست */
    public const DOC_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'txt', 'zip', 'rar', 'ppt', 'pptx'];

    public static function attachDir(int $biz, int $eventId): string
    {
        return storage_path('planner/' . max(0, $biz) . '/' . max(0, $eventId));
    }

    public static function attachments(int $eventId): array
    {
        return Database::all('SELECT a.*, u.full_name AS user_name, u.avatar_path AS user_avatar FROM planner_attachments a
                               LEFT JOIN users u ON u.id = a.user_id
                              WHERE a.event_id = ? ORDER BY a.id DESC', [$eventId]);
    }

    public static function attachment(int $id): ?array
    {
        return Database::one('SELECT * FROM planner_attachments WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
    }

    /**
     * ذخیرهٔ فایل ارسالی برای یک رویداد.
     * @return array{ok:bool,error:?string,empty:bool,id:?int}
     */
    public static function saveUpload(int $eventId, string $field = 'file'): array
    {
        $out = ['ok' => false, 'error' => null, 'empty' => true, 'id' => null];
        $e = self::event($eventId);
        if (!$e) { $out['error'] = 'رویداد یافت نشد.'; return $out; }
        if (!self::canUpdateStatus($e)) { $out['error'] = 'اجازهٔ ارسال فایل برای این رویداد را ندارید.'; return $out; }
        if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return $out;
        $f = $_FILES[$field];
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) return $out;
        $out['empty'] = false;
        if ($err !== UPLOAD_ERR_OK) { $out['error'] = 'آپلود فایل ناموفق بود (کد ' . $err . ').'; return $out; }
        if ((int)$f['size'] > 8 * 1024 * 1024) { $out['error'] = 'حجم فایل باید کمتر از ۸ مگابایت باشد.'; return $out; }
        if (!is_uploaded_file((string)$f['tmp_name'])) { $out['error'] = 'فایل نامعتبر است.'; return $out; }
        $orig = (string)($f['name'] ?? 'file');
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        if (!in_array($ext, self::DOC_EXT, true)) {
            $out['error'] = 'فرمت مجاز نیست. تصویر (JPG/PNG/WEBP)، PDF، Word، Excel، CSV، TXT یا ZIP.';
            return $out;
        }
        $biz = (int)Auth::businessId();
        $dir = self::attachDir($biz, $eventId);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) { $out['error'] = 'ساخت پوشهٔ ذخیره ممکن نشد.'; return $out; }
        $safe = 'ev' . $eventId . '-' . date('Ymd-His') . '-' . bin2hex(random_bytes(4)) . '.' . $ext;
        if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $safe)) { $out['error'] = 'ذخیرهٔ فایل ممکن نشد.'; return $out; }
        @chmod($dir . '/' . $safe, 0644);
        $mimes = ['jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif',
            'pdf' => 'application/pdf', 'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'csv' => 'text/csv', 'txt' => 'text/plain', 'zip' => 'application/zip', 'rar' => 'application/vnd.rar',
            'ppt' => 'application/vnd.ms-powerpoint', 'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation'];
        $id = (int)Database::insert('planner_attachments', ['business_id' => $biz, 'event_id' => $eventId,
            'user_id' => (int)Auth::id(), 'file_name' => mb_substr($orig, 0, 190),
            'storage_key' => $biz . '/' . $eventId . '/' . $safe, 'mime_type' => $mimes[$ext] ?? 'application/octet-stream',
            'size_bytes' => (int)$f['size'], 'note' => mb_substr(trim((string)post('note')), 0, 255) ?: null, 'created_at' => now()]);
        Audit::log('create', 'planner_attachments', $id, 'ارسال فایل «' . $orig . '» برای رویداد #' . $eventId);
        return ['ok' => true, 'error' => null, 'empty' => false, 'id' => $id];
    }

    public static function attachmentPath(array $a): string
    {
        return storage_path('planner/' . ltrim((string)$a['storage_key'], '/'));
    }

    public static function deleteAttachment(int $id): void
    {
        $a = self::attachment($id);
        if (!$a) throw new RuntimeException('فایل یافت نشد.');
        $e = self::event((int)$a['event_id']);
        if (!$e) throw new RuntimeException('رویداد یافت نشد.');
        if ((int)$a['user_id'] !== (int)Auth::id() && !self::canManageAll()) throw new RuntimeException('فقط فرستنده یا مدیر می‌تواند فایل را حذف کند.');
        $p = self::attachmentPath($a);
        if (is_file($p)) @unlink($p);
        Database::run('DELETE FROM planner_attachments WHERE id=? AND business_id=?', [$id, (int)Auth::businessId()]);
        Audit::log('delete', 'planner_attachments', $id, 'حذف فایل پیوست');
    }

    /** آیکون و برچسب فایل بر اساس پسوند */
    public static function fileKind(string $name): array
    {
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        return match (true) {
            in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) => ['image', 'تصویر'],
            $ext === 'pdf' => ['file', 'PDF'],
            in_array($ext, ['doc', 'docx'], true) => ['file', 'Word'],
            in_array($ext, ['xls', 'xlsx', 'csv'], true) => ['chart', 'Excel'],
            in_array($ext, ['zip', 'rar'], true) => ['download', 'آرشیو'],
            default => ['file', strtoupper($ext ?: 'فایل')],
        };
    }

    /* ───────────── مدیریت پروژه ───────────── */

    public static function projects(bool $activeOnly = true): array
    {
        $biz = (int)Auth::businessId();
        $w = $activeOnly ? ' AND status="open"' : '';
        return Database::all("SELECT id, code, name, status, start_date, end_date, budget_amount FROM projects
                               WHERE business_id=? AND deleted_at IS NULL$w ORDER BY status, name", [$biz]);
    }

    /** برد کانبان: وظایف گروه‌بندی‌شده بر اساس وضعیت */
    public static function board(array $f = []): array
    {
        $from = !empty($f['from']) ? (string)$f['from'] : date('Y-m-d', strtotime(today() . ' -60 days'));
        $to = !empty($f['to']) ? (string)$f['to'] : date('Y-m-d', strtotime(today() . ' +180 days'));
        $events = self::events($from, $to, $f);
        $cols = ['open' => [], 'in_progress' => [], 'done' => [], 'failed' => []];
        foreach ($events as $e) {
            $st = (string)$e['status'];
            if ($st === 'cancelled') continue;
            if (!isset($cols[$st])) $st = 'open';
            $cols[$st][] = $e;
        }
        return $cols;
    }

    /** خلاصهٔ پیشرفت هر پروژه (بر اساس وظایف برنامه‌ریز) */
    public static function projectSummary(?int $businessId = null, ?int $userId = null, ?bool $seeAll = null): array
    {
        $biz = $businessId ?: (int)Auth::businessId();
        $uid = $userId ?? (int)Auth::id();
        $all = $seeAll ?? self::canManageAll();
        $sql = "SELECT pr.id, pr.code, pr.name, pr.status, pr.start_date, pr.end_date, pr.budget_amount,
                       COUNT(p.id) AS tasks,
                       SUM(CASE WHEN p.status='done' THEN 1 ELSE 0 END) AS done,
                       SUM(CASE WHEN p.status='in_progress' THEN 1 ELSE 0 END) AS doing,
                       SUM(CASE WHEN p.status='failed' THEN 1 ELSE 0 END) AS failed,
                       SUM(CASE WHEN p.status IN ('open','in_progress') AND IFNULL(p.end_date,p.start_date) < CURDATE() THEN 1 ELSE 0 END) AS overdue
                  FROM projects pr LEFT JOIN planner_events p ON p.project_id = pr.id AND p.deleted_at IS NULL AND p.is_active=1
                 WHERE pr.business_id=? AND pr.deleted_at IS NULL";
        $pr = [$biz];
        if (!$all) { $sql .= ' AND (p.assignee_user_id=? OR p.created_by=? OR p.id IS NULL)'; $pr[] = $uid; $pr[] = $uid; }
        $sql .= ' GROUP BY pr.id ORDER BY pr.status, pr.name';
        $rows = Database::all($sql, $pr);
        foreach ($rows as &$r) {
            $t = max(0, (int)$r['tasks']);
            $r['progress'] = $t > 0 ? (int)round((int)$r['done'] * 100 / $t) : 0;
        }
        unset($r);
        return $rows;
    }

    /* ───────────── آمار ───────────── */

    public static function stats(string $from, string $to): array
    {
        $rows = self::events($from, $to, []);
        $out = ['total' => count($rows), 'open' => 0, 'in_progress' => 0, 'done' => 0, 'failed' => 0, 'overdue' => 0, 'today' => 0];
        $t = today();
        foreach ($rows as $r) {
            $st = (string)$r['status'];
            if (isset($out[$st])) $out[$st]++;
            $due = (string)($r['end_date'] ?: $r['start_date']);
            if (in_array($st, ['open', 'in_progress'], true) && $due < $t) $out['overdue']++;
            if ($due === $t && in_array($st, ['open', 'in_progress'], true)) $out['today']++;
        }
        return $out;
    }

    /** کاربران فعال کسب‌وکار برای تخصیص وظیفه */
    public static function users(): array
    {
        $biz = (int)Auth::businessId();
        return Database::all('SELECT DISTINCT u.id, u.full_name, u.avatar_path FROM users u
                                JOIN user_business_roles ubr ON ubr.user_id = u.id AND ubr.business_id = ? AND ubr.is_active = 1
                               WHERE u.deleted_at IS NULL AND u.is_active = 1 ORDER BY u.full_name', [$biz]);
    }

    public static function colorHex(?string $key): array
    {
        return self::COLORS[$key ?? 'purple'] ?? self::COLORS['purple'];
    }

    /** نام فارسی رنگ برچسب */
    public static function colorLabel(?string $key): string
    {
        return [
            'purple' => 'بنفش', 'blue' => 'آبی', 'teal' => 'فیروزه‌ای', 'green' => 'سبز',
            'gold' => 'طلایی', 'red' => 'قرمز', 'pink' => 'صورتی', 'slate' => 'خاکستری',
        ][$key ?? 'purple'] ?? (string)$key;
    }

    /** نام فارسی آیکون نوع رویداد */
    public static function iconLabel(?string $key): string
    {
        return [
            'check' => 'تیک', 'users' => 'کاربران', 'bell' => 'زنگ', 'truck' => 'ارسال',
            'eye' => 'چشم', 'shield' => 'سپر', 'star' => 'ستاره', 'clock' => 'ساعت',
            'tag' => 'برچسب', 'money' => 'پول', 'file' => 'فایل', 'info' => 'اطلاعات',
        ][$key ?? 'check'] ?? (string)$key;
    }

    /** وظایف نزدیک سررسید/معوق برای اعلان‌ها */
    public static function dueSoon(int $biz, int $uid, int $days, bool $all): array
    {
        $sql = "SELECT p.id, p.title, p.status, p.priority, p.start_date, p.end_date, p.assignee_user_id,
                       DATEDIFF(IFNULL(p.end_date, p.start_date), CURDATE()) AS d, u.full_name AS who
                  FROM planner_events p LEFT JOIN users u ON u.id = p.assignee_user_id
                 WHERE p.business_id=? AND p.deleted_at IS NULL AND p.is_active=1
                   AND p.status IN ('open','in_progress')
                   AND IFNULL(p.end_date, p.start_date) <= DATE_ADD(CURDATE(), INTERVAL ? DAY)";
        $pr = [$biz, max(0, $days)];
        if (!$all) { $sql .= ' AND (p.assignee_user_id=? OR p.created_by=?)'; $pr[] = $uid; $pr[] = $uid; }
        $sql .= ' ORDER BY d ASC LIMIT 25';
        return Database::all($sql, $pr);
    }

    /** وظایف تازه‌ای که به این کاربر سپرده شده‌اند (برای اعلان «وظیفهٔ جدید») */
    public static function assignedRecently(int $biz, int $uid, int $days = 7): array
    {
        return Database::all("SELECT p.id, p.title, p.start_date, p.end_date, p.status, p.priority, p.created_at, c.full_name AS who
                                FROM planner_events p LEFT JOIN users c ON c.id = p.created_by
                               WHERE p.business_id=? AND p.deleted_at IS NULL AND p.is_active=1
                                 AND p.assignee_user_id=? AND p.status IN ('open','in_progress')
                                 AND p.created_at >= DATE_SUB(NOW(), INTERVAL ? DAY)
                               ORDER BY p.id DESC LIMIT 20", [$biz, $uid, max(1, $days)]);
    }

    /** رویدادهایی که اخیراً بسته شده‌اند (برای اطلاع مدیر) */
    public static function recentlyClosed(int $biz, int $uid, bool $all): array
    {
        $sql = "SELECT p.id, p.title, p.status, p.completion_note, p.completed_at, p.completed_by, p.assignee_user_id,
                       u.full_name AS who
                  FROM planner_events p LEFT JOIN users u ON u.id = p.assignee_user_id
                 WHERE p.business_id=? AND p.deleted_at IS NULL AND p.completed_at IS NOT NULL
                   AND p.completed_at >= DATE_SUB(NOW(), INTERVAL 3 DAY)
                   AND (p.completed_by IS NULL OR p.completed_by <> ?)";
        $pr = [$biz, $uid];
        if (!$all) { $sql .= ' AND (p.assignee_user_id=? OR p.created_by=?)'; $pr[] = $uid; $pr[] = $uid; }
        $sql .= ' ORDER BY p.completed_at DESC LIMIT 15';
        return Database::all($sql, $pr);
    }
}
