<?php
/**
 * پورتال مشتری — ورود با موبایل + کد تایید، مشاهدهٔ فاکتورها، صورت‌حساب،
 * مشاهدهٔ حساب‌های دریافت وجه (شبا/کارت) و آپلود رسید پرداخت.
 */
final class Portal
{
    /** شخص را با موبایل پیدا می‌کند (موبایل اصلی یا راه‌های تماس) */
    public static function findPerson(string $mobile): ?array
    {
        $m = AuthController::normalizeMobile($mobile);
        if (!$m) return null;
        $p = Database::one('SELECT * FROM persons WHERE mobile=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 1', [$m]);
        if ($p) return $p;
        $p = Database::one('SELECT p.* FROM person_contacts c JOIN persons p ON p.id = c.person_id
                             WHERE c.contact_type IN ("mobile","phone") AND c.value=? AND p.deleted_at IS NULL
                             ORDER BY p.id DESC LIMIT 1', [$m]);
        return $p ?: null;
    }

    /** شخص فعال در نشست پورتال */
    public static function person(): ?array
    {
        $id = $_SESSION['portal_person_id'] ?? null;
        if (!$id) return null;
        return Database::one('SELECT * FROM persons WHERE id=? AND deleted_at IS NULL', [(int)$id]);
    }

    /** حساب‌های دریافت وجه فعال (برای نمایش در پورتال) */
    public static function paymentAccounts(int $businessId): array
    {
        return Database::all('SELECT * FROM payment_accounts WHERE business_id=? AND is_active=1 ORDER BY sort_order, id', [$businessId]);
    }

    /** فاکتورهای باز (تسویه‌نشده) و فاکتورهای اخیر مشتری */
    public static function invoices(int $personId, int $businessId): array
    {
        return Database::all(
            "SELECT id, invoice_no, invoice_type, invoice_date, due_date, total_amount, paid_amount, remaining_amount, status, settlement_status
               FROM invoices
              WHERE business_id=? AND person_id=? AND deleted_at IS NULL AND status='posted'
                AND invoice_type IN ('sale','sale_return')
              ORDER BY invoice_date DESC, id DESC LIMIT 100",
            [$businessId, $personId]
        );
    }

    /** آمار مالی مشتری برای صورت‌حساب */
    public static function summary(int $personId, int $businessId): array
    {
        return Database::one(
            "SELECT COUNT(*) AS cnt,
                    IFNULL(SUM(total_amount),0) AS total,
                    IFNULL(SUM(paid_amount),0) AS paid,
                    IFNULL(SUM(remaining_amount),0) AS remaining
               FROM invoices
              WHERE business_id=? AND person_id=? AND deleted_at IS NULL AND status='posted'
                AND invoice_type IN ('sale','sale_return')",
            [$businessId, $personId]
        ) ?: ['cnt' => 0, 'total' => 0, 'paid' => 0, 'remaining' => 0];
    }

    /** ذخیرهٔ رسید پرداخت آپلودشده توسط مشتری */
    public static function saveReceipt(int $businessId, int $personId, int $invoiceId, array $file, ?string $note): int
    {
        $inv = Database::one('SELECT * FROM invoices WHERE id=? AND business_id=? AND person_id=?', [$invoiceId, $businessId, $personId]);
        if (!$inv) throw new RuntimeException('فاکتور یافت نشد.');
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) throw new RuntimeException('فایل رسید انتخاب نشده است.');
        if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('آپلود ناموفق بود.');
        if ((int)($file['size'] ?? 0) > 10 * 1024 * 1024) throw new RuntimeException('حجم فایل باید کمتر از ۱۰ مگابایت باشد.');
        if (!is_uploaded_file((string)($file['tmp_name'] ?? ''))) throw new RuntimeException('فایل نامعتبر است.');

        $orig = mb_substr((string)($file['name'] ?? 'receipt'), 0, 255);
        $dir = storage_path('customer-receipts/' . $businessId . '/' . $invoiceId);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) throw new RuntimeException('ساخت پوشه ممکن نشد.');
        $safe = date('Ymd-His') . '-' . bin2hex(random_bytes(4));
        if (!@move_uploaded_file((string)$file['tmp_name'], $dir . '/' . $safe)) throw new RuntimeException('ذخیرهٔ فایل ممکن نشد.');
        @chmod($dir . '/' . $safe, 0644);

        $id = (int)Database::insert('customer_payment_receipts', [
            'business_id' => $businessId, 'invoice_id' => $invoiceId, 'person_id' => $personId,
            'file_name' => $orig, 'storage_key' => $businessId . '/' . $invoiceId . '/' . $safe,
            'mime_type' => (string)($file['type'] ?? 'application/octet-stream'), 'size_bytes' => (int)$file['size'],
            'amount' => null, 'note' => trim((string)$note) !== '' ? mb_substr(trim((string)$note), 0, 500) : null,
            'status' => 'pending', 'created_at' => now(),
        ]);
        return $id;
    }

    public static function receiptPath(array $r): string
    {
        return storage_path('customer-receipts/' . ltrim((string)$r['storage_key'], '/'));
    }

    /** رسیدهای یک فاکتور */
    public static function receipts(int $invoiceId): array
    {
        return Database::all('SELECT * FROM customer_payment_receipts WHERE invoice_id=? ORDER BY id DESC', [$invoiceId]);
    }
}
