<?php
/**
 * موتور سند حسابداری — سند خودکار بر پایه قواعد جدول auto_entry_rules و نگاشت حساب‌ها
 * همه مبالغ از «کیف مبالغ» (bag) خوانده می‌شوند: invoice_total، invoice_net، tax، charges، cogs، amount، paid
 */
final class Posting
{
    public const BAG_KEYS = ['invoice_total','invoice_net','tax','charges','cogs','amount','paid','net','insurance_payable','expense_total',
        'advance_total','loan_total','deduction_total'];

    /** قواعد پیش‌فرض (در صورت نبود قاعده در دیتابیس) */
    public static function defaults(): array
    {
        return [
            'invoice.sale.cash'    => [['debit','mapping','cash','invoice_total'],['credit','mapping','sales','invoice_net'],['credit','dynamic_tax','vat_payable','tax'],['credit','mapping','shipping_revenue','charges']],
            'invoice.sale.credit'  => [['debit','mapping','ar','invoice_total'],['credit','mapping','sales','invoice_net'],['credit','dynamic_tax','vat_payable','tax'],['credit','mapping','shipping_revenue','charges']],
            'invoice.sale.cogs'    => [['debit','mapping','cogs','cogs'],['credit','mapping','inventory','cogs']],
            'invoice.buy.cash'     => [['debit','mapping','purchase_interim','invoice_net'],['debit','dynamic_tax','vat_receivable','tax'],['credit','mapping','cash','invoice_total']],
            'invoice.buy.credit'   => [['debit','mapping','purchase_interim','invoice_net'],['debit','dynamic_tax','vat_receivable','tax'],['credit','mapping','ap','invoice_total']],
            'invoice.sale_return'  => [['debit','mapping','sales_return','invoice_net'],['debit','dynamic_tax','vat_payable','tax'],['credit','mapping','ar','invoice_total']],
            'invoice.sale_return.cogs' => [['debit','mapping','inventory','cogs'],['credit','mapping','cogs','cogs']],
            'receipt.cash'         => [['debit','mapping','cash','amount'],['credit','person','ar','amount']],
            'receipt.cheque'       => [['debit','mapping','cheque_receivable','amount'],['credit','person','ar','amount']],
            'payment.cash'         => [['debit','person','ap','amount'],['credit','mapping','cash','amount']],
            'payment.cheque'       => [['debit','person','ap','amount'],['credit','mapping','cheque_payable','amount']],
            'transfer'             => [['debit','cash_account',null,'amount'],['credit','cash_account',null,'amount']],
            'inventory.receive'    => [['debit','mapping','inventory','cogs'],['credit','mapping','purchase_interim','cogs']],
            'inventory.issue'      => [['debit','mapping','cogs','cogs'],['credit','mapping','inventory','cogs']],
            'inventory.waste'      => [['debit','mapping','waste_expense','cogs'],['credit','mapping','inventory','cogs']],
            'inventory.count.shortage' => [['debit','mapping','waste_expense','cogs'],['credit','mapping','inventory','cogs']],
            'inventory.count.surplus'  => [['debit','mapping','inventory','cogs'],['credit','mapping','inventory_gain','cogs']],
            'expense.cash'         => [['debit','mapping','expense_default','amount'],['credit','mapping','cash','amount']],
            'expense.credit'       => [['debit','mapping','expense_default','amount'],['credit','person','ap','amount']],
            'income.cash'          => [['debit','mapping','cash','amount'],['credit','mapping','other_income','amount']],
            'income.credit'        => [['debit','person','ar','amount'],['credit','mapping','other_income','amount']],
            // حقوق: هزینهٔ کل (حقوق + بیمهٔ سهم کارفرما) در برابر بیمه/مالیات/خالص پرداختنی
            // و کسر مساعده و وام (بازیافت دارایی) و سایر کسورات — سند همیشه تراز است.
            // برگشت از خرید: بدهکار حساب‌های پرداختنی / بستانکار موجودی کالا و مالیات
            'invoice.buy_return'      => [['debit','mapping','ap','invoice_total'],['credit','mapping','inventory','invoice_net'],['credit','dynamic_tax','vat_receivable','tax']],
            'invoice.buy_return.cash' => [['debit','mapping','cash','invoice_total'],['credit','mapping','inventory','invoice_net'],['credit','dynamic_tax','vat_receivable','tax']],
            'payroll'              => [['debit','mapping','payroll_expense','expense_total'],['credit','mapping','insurance_payable','insurance_payable'],
                                       ['credit','mapping','payroll_tax','tax'],['credit','mapping','payroll_payable','net'],
                                       ['credit','mapping','staff_advances','advance_total'],['credit','mapping','staff_loans','loan_total'],
                                       ['credit','mapping','payroll_deductions','deduction_total']],
            'payroll.payment'      => [['debit','mapping','payroll_payable','amount'],['credit','mapping','cash','amount']],
            'cheque.received'      => [['debit','mapping','cheque_receivable','amount'],['credit','person','ar','amount']],
            'cheque.cleared'       => [['debit','cash_account','bank','amount'],['credit','mapping','cheque_receivable','amount']],
            'cheque.bounced'       => [['debit','person','ar','amount'],['credit','mapping','cheque_receivable','amount']],
            'cheque.issued'        => [['debit','person','ap','amount'],['credit','mapping','cheque_payable','amount']],
            'cheque.paid'          => [['debit','mapping','cheque_payable','amount'],['credit','cash_account','bank','amount']],
            'cheque.endorsed'      => [['debit','person','ap','amount'],['credit','mapping','cheque_receivable','amount']],
            'commission'           => [['debit','mapping','commission_expense','amount'],['credit','person','ap','amount']],
            'year.opening'         => [['debit','mapping','cash','amount'],['credit','mapping','capital','amount']],
            'year.closing'         => [['debit','mapping','sales','amount'],['credit','mapping','retained_earnings','amount']],
        ];
    }

    /** خواندن خطوط قاعده یک رویداد از دیتابیس (با بازگشت به پیش‌فرض‌ها) */
    public static function ruleLines(int $businessId, string $eventKey): array
    {
        self::ensureReturnRules($businessId, $eventKey);
        $rows = Database::all('SELECT l.side, l.account_source, l.mapping_key, l.account_id, l.amount_source, l.row_order
                                 FROM auto_entry_rules r JOIN auto_entry_rule_lines l ON l.rule_id = r.id
                                WHERE r.business_id = ? AND r.event_key = ? AND r.is_enabled = 1 AND r.is_active = 1
                                ORDER BY l.row_order, l.id', [$businessId, $eventKey]);
        if ($rows) return array_map(fn($r) => [$r['side'], $r['account_source'], $r['mapping_key'], $r['amount_source'], $r['account_id']], $rows);
        $def = self::defaults()[$eventKey] ?? null;
        if (!$def) throw new RuntimeException("قاعده سند خودکار برای رویداد «{$eventKey}» تعریف نشده است. در تنظیمات ← قواعد سند خودکار آن را تعریف کنید.");
        return array_map(fn($d) => [$d[0], $d[1], $d[2] ?? null, $d[3], null], $def);
    }

    /**
     * تضمین وجود حساب‌های «مساعدهٔ کارکنان»، «وام کارکنان» و «سایر کسورات حقوق» و نگاشت آن‌ها.
     * برای کسب‌وکارهای قدیمی که این حساب‌ها را ندارند، به‌صورت خودکار ساخته می‌شود.
     */
    public static function ensurePayrollAccounts(int $businessId): array
    {
        static $cache = [];
        if (isset($cache[$businessId])) return $cache[$businessId];
        $need = [
            'staff_advances'     => ['code' => '1111', 'title' => 'مساعدهٔ کارکنان', 'type' => 'asset', 'nature' => 'debit', 'parent' => '11', 'root' => 'دارایی‌ها'],
            'staff_loans'        => ['code' => '1112', 'title' => 'وام کارکنان', 'type' => 'asset', 'nature' => 'debit', 'parent' => '11', 'root' => 'دارایی‌ها'],
            'payroll_deductions' => ['code' => '2109', 'title' => 'سایر کسورات حقوق پرداختنی', 'type' => 'liability', 'nature' => 'credit', 'parent' => '21', 'root' => 'بدهی‌ها'],
        ];
        $out = [];
        foreach ($need as $key => $spec) {
            $exists = Database::val('SELECT m.account_id FROM account_mappings m JOIN chart_of_accounts a ON a.id=m.account_id
                                      WHERE m.business_id=? AND m.mapping_key=? AND a.deleted_at IS NULL', [$businessId, $key], 0);
            if ($exists) { $out[$key] = (int)$exists; continue; }
            $parent = Database::one('SELECT id, full_path, level_no FROM chart_of_accounts WHERE business_id=? AND code=?', [$businessId, $spec['parent']]);
            // کد آزاد (اگر اشغال بود، اولین کد آزاد بعدی)
            $i = (int)$spec['code'];
            while (Database::val('SELECT COUNT(*) FROM chart_of_accounts WHERE business_id=? AND code=?', [$businessId, (string)$i], 0)) $i++;
            $accId = (int)Database::insert('chart_of_accounts', [
                'business_id' => $businessId, 'code' => (string)$i, 'title' => $spec['title'],
                'parent_id' => $parent['id'] ?? null, 'level_no' => ((int)($parent['level_no'] ?? 1)) + 1,
                'account_type' => $spec['type'], 'nature' => $spec['nature'], 'is_group' => 0, 'is_postable' => 1,
                'person_required' => 0, 'currency_id' => base_currency_id($businessId),
                'full_path' => ($parent['full_path'] ?? $spec['root']) . ' / ' . $spec['title'],
                'status' => 'active', 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
            ]);
            Database::insert('account_mappings', ['business_id' => $businessId, 'mapping_key' => $key, 'title_fa' => $spec['title'],
                'account_id' => $accId, 'created_at' => now(), 'created_by' => Auth::id()]);
            $out[$key] = $accId;
        }
        return $cache[$businessId] = $out;
    }

    /**
     * اگر کسب‌وکار قاعدهٔ سفارشی دارد ولی قاعدهٔ «برگشت از خرید» را ندارد،
     * نسخهٔ آینه‌ای قاعدهٔ خرید را برایش می‌سازد (سند برگشت از خرید باید معکوس خرید باشد).
     */
    public static function ensureReturnRules(int $businessId, string $eventKey): void
    {
        $pairs = ['invoice.buy_return' => 'invoice.buy.credit', 'invoice.buy_return.cash' => 'invoice.buy.cash',
                  'invoice.sale_return' => 'invoice.sale.credit'];
        if (!isset($pairs[$eventKey])) return;
        $has = (int)Database::val('SELECT COUNT(*) FROM auto_entry_rules WHERE business_id=? AND event_key=? AND is_active=1', [$businessId, $eventKey], 0);
        if ($has) return;
        $srcRule = (int)Database::val('SELECT id FROM auto_entry_rules WHERE business_id=? AND event_key=? AND is_active=1 ORDER BY id LIMIT 1', [$businessId, $pairs[$eventKey]], 0);
        if (!$srcRule) return;
        $srcLines = Database::all('SELECT * FROM auto_entry_rule_lines WHERE rule_id=? ORDER BY row_order', [$srcRule]);
        if (!$srcLines) return;
        Database::transaction(function () use ($businessId, $eventKey, $srcLines) {
            $ruleId = (int)Database::insert('auto_entry_rules', ['business_id' => $businessId, 'event_key' => $eventKey,
                'title_fa' => $eventKey === 'invoice.sale_return' ? 'ثبت سند برگشت از فروش' : 'ثبت سند برگشت به تأمین‌کننده',
                'is_enabled' => 1, 'priority' => 10, 'condition_json' => '{"note": null}', 'created_at' => now(), 'created_by' => Auth::id()]);
            $i = 1;
            foreach ($srcLines as $l) {
                Database::insert('auto_entry_rule_lines', ['rule_id' => $ruleId, 'side' => $l['side'] === 'debit' ? 'credit' : 'debit',
                    'account_source' => $l['account_source'], 'account_id' => $l['account_id'], 'mapping_key' => $l['mapping_key'],
                    'amount_source' => $l['amount_source'], 'row_order' => $i++]);
            }
        });
    }

    /** کیف مبالغ */
    public static function bag(array $extra = []): array
    {
        $bag = array_fill_keys(self::BAG_KEYS, 0.0);
        foreach ($extra as $k => $v) $bag[$k] = round((float)$v, 2);
        return $bag;
    }

    /** آیا ثبت خودکار سند برای این رویداد بر اساس «تنظیمات مالی» فعال است؟ */
    public static function autoEnabled(int $businessId, string $eventKey): bool
    {
        if (str_starts_with($eventKey, 'invoice.buy')) $key = 'financial.auto_journal_buy';
        elseif (str_starts_with($eventKey, 'invoice.sale')) $key = 'financial.auto_journal_sale';
        elseif (str_starts_with($eventKey, 'receipt') || str_starts_with($eventKey, 'payment')) $key = 'financial.auto_journal_receipt_payment';
        elseif (str_starts_with($eventKey, 'transfer')) $key = 'financial.auto_journal_transfer';
        elseif (str_starts_with($eventKey, 'inventory')) $key = 'financial.auto_journal_inventory';
        elseif (str_starts_with($eventKey, 'payroll')) $key = 'financial.auto_journal_payroll';
        elseif (str_starts_with($eventKey, 'bank')) $key = 'financial.auto_journal_bank_fee';
        else return true;
        return (bool)Settings::get($key, true, $businessId);
    }

    /** نگاشت پشتیبان از «تنظیمات مالی → کدینگ پیش‌فرض» (کد حساب) */
    public static function settingMapping(int $businessId, string $mappingKey): int
    {
        $suffix = ['ar' => 'ar_account', 'ap' => 'ap_account', 'sales' => 'sales_account',
                   'cogs' => 'cogs_account', 'cash' => 'cash_account'][$mappingKey] ?? null;
        if ($suffix === null) return 0;
        $code = trim((string)Settings::get('financial.mapping.' . $suffix, '', $businessId));
        if ($code === '') return 0;
        return (int)Database::val('SELECT id FROM chart_of_accounts WHERE business_id=? AND code=? AND deleted_at IS NULL LIMIT 1', [$businessId, $code], 0);
    }

    /** شناسایی حساب از منبع */
    public static function resolveAccount(int $businessId, string $source, ?string $mappingKey, ?int $fixedId, array $ctx): int
    {
        switch ($source) {
            case 'fixed':
                if ($fixedId) return (int)$fixedId;
                break;
            case 'mapping':
                $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $mappingKey]);
                if ($id) return (int)$id;
                // نگاشت معادل
                $alias = ['cash' => ['bank','pos','petty_cash'], 'ar' => ['customer_advance'], 'ap' => ['customer_advance'], 'vat_payable' => ['vat_receivable']];
                foreach (($alias[$mappingKey] ?? []) as $alt) {
                    $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $alt]);
                    if ($id) return (int)$id;
                }
                // نگاشت پشتیبان از تنظیمات مالی (کدینگ پیش‌فرض)
                $id = self::settingMapping($businessId, (string)$mappingKey);
                if ($id) return (int)$id;
                break;
            case 'dynamic_tax':
                if (!empty($ctx['tax_id'])) {
                    $id = Database::val('SELECT account_id FROM taxes WHERE id=?', [$ctx['tax_id']]);
                    if ($id) return (int)$id;
                }
                $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $mappingKey ?: 'vat_payable']);
                if ($id) return (int)$id;
                break;
            case 'cash_account':
                // ۱) حساب نقد/بانکِ انتخاب‌شده در سند، ۲) نگاشت هم‌نامِ قاعده، ۳) نگاشت «cash» پیش‌فرض
                if (!empty($ctx['cash_account_id'])) {
                    $id = Database::val('SELECT gl_account_id FROM cash_accounts WHERE id=?', [$ctx['cash_account_id']]);
                    if ($id) return (int)$id;
                }
                if ($mappingKey) {
                    $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $mappingKey]);
                    if ($id) return (int)$id;
                }
                $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, 'cash']);
                if ($id) return (int)$id;
                break;
            case 'person':
                if (!empty($ctx['person_id'])) {
                    $pfs = Database::one('SELECT receivable_account_id FROM person_financial_settings WHERE person_id=?', [$ctx['person_id']]);
                    $side = $ctx['person_account'] ?? ($mappingKey ?: 'ar');
                    if ($side === 'ar' && !empty($pfs['receivable_account_id'])) return (int)$pfs['receivable_account_id'];
                    if ($side === 'ap' && !empty($pfs['receivable_account_id']) && ($ctx['person_is_supplier'] ?? false)) return (int)$pfs['receivable_account_id'];
                }
                $mapKey = $ctx['person_account'] ?? ($mappingKey ?: 'ar');
                $id = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $mapKey]);
                if ($id) return (int)$id;
                break;
            case 'product':
                if (!empty($ctx['product_id'])) {
                    $id = Database::val('SELECT accounting_account_id FROM products WHERE id=?', [$ctx['product_id']]);
                    if ($id) return (int)$id;
                }
                break;
        }
        throw new RuntimeException("حساب برای منبع «{$source}".($mappingKey ? " / {$mappingKey}" : '')."» یافت نشد. نگاشت حساب‌ها را در تنظیمات مالی کامل کنید.");
    }

    /** دوره مالی مربوط به تاریخ و بررسی قفل نبودن */
    public static function periodFor(int $businessId, string $date): array
    {
        $fy = Database::one('SELECT * FROM fiscal_years WHERE business_id=? AND ? BETWEEN start_date AND end_date AND deleted_at IS NULL ORDER BY id DESC LIMIT 1', [$businessId, $date]);
        if (!$fy) {
            $fy = Database::one('SELECT * FROM fiscal_years WHERE business_id=? AND is_current=1 LIMIT 1', [$businessId]);
            if (!$fy) throw new RuntimeException('سال مالی فعال برای این کسب‌وکار یافت نشد. ابتدا در تنظیمات یک سال مالی بسازید.');
        }
        $fp = Database::one('SELECT * FROM fiscal_periods WHERE fiscal_year_id=? AND ? BETWEEN start_date AND end_date LIMIT 1', [$fy['id'], $date]);
        return [$fy, $fp];
    }

    public static function assertPeriodOpen(array $fy, ?array $fp): void
    {
        if (($fy['status'] ?? 'open') === 'closed') throw new RuntimeException('سال مالی «'.$fy['title'].'» بسته شده است و ثبت سند در آن مجاز نیست.');
        if ($fp && $fp['status'] === 'locked') throw new RuntimeException('دوره «'.$fp['title'].'» قفل است؛ ثبت سند در دوره قفل‌شده مجاز نیست.');
    }

    /**
     * ثبت یک سند (پایه همه اسناد خودکار و دستی)
     * $lines: [['account_id'=>, 'debit'=>, 'credit'=>, 'description'=>, 'person_id'=>, 'product_id'=>, 'cost_center_id'=>, 'cheque_id'=>]]
     */
    public static function create(int $businessId, array $head, array $lines, array $opts = []): int
    {
        $date = $head['entry_date'] ?? today();
        [$fy, $fp] = self::periodFor($businessId, $date);
        self::assertPeriodOpen($fy, $fp);
        if ($opts['skip_period_check'] ?? false) { }

        $lines = array_values(array_filter($lines, fn($l) => round((float)($l['debit'] ?? 0), 2) != 0 || round((float)($l['credit'] ?? 0), 2) != 0));
        if (count($lines) < 2) throw new RuntimeException('سند باید حداقل دو آرتیکل داشته باشد.');
        $td = 0; $tc = 0;
        foreach ($lines as $i => $l) {
            $d = round((float)($l['debit'] ?? 0), 2); $c = round((float)($l['credit'] ?? 0), 2);
            if ($d > 0 && $c > 0) throw new RuntimeException('در هر آرتیکل فقط یکی از بدهکار/بستانکار می‌تواند مقدار داشته باشد.');
            if ($d == 0 && $c == 0) throw new RuntimeException('مبلغ آرتیکل '.($i + 1).' صفر است.');
            $acc = (int)$l['account_id'];
            if (!Database::val('SELECT COUNT(*) FROM chart_of_accounts WHERE id=? AND business_id=?', [$acc, $businessId]))
                throw new RuntimeException('حساب آرتیکل '.($i + 1).' معتبر نیست.');
            if (Database::val('SELECT is_group FROM chart_of_accounts WHERE id=?', [$acc]))
                throw new RuntimeException('حساب گروهی قابل استفاده در سند نیست (' . Database::val('SELECT title FROM chart_of_accounts WHERE id=?', [$acc]) . ').');
            $td += $d; $tc += $c;
        }
        if (abs($td - $tc) > 0.05) throw new RuntimeException('سند تراز نیست: جمع بدهکار '.num($td).' و جمع بستانکار '.num($tc).'.');

        $entryNo = Sequence::nextNumber($businessId, (int)$fy['id'], 'journal'); // entry_no ستون عددی است
        $id = Database::insert('journal_entries', [
            'business_id' => $businessId, 'fiscal_year_id' => $fy['id'], 'fiscal_period_id' => $fp['id'] ?? null,
            'entry_no' => $entryNo, 'entry_date' => $date,
            'entry_type' => $head['entry_type'] ?? 'normal', 'reference_type' => $head['reference_type'] ?? null,
            'reference_id' => $head['reference_id'] ?? null, 'reference_no' => $head['reference_no'] ?? null,
            'description' => $head['description'] ?? null, 'project_id' => $head['project_id'] ?? null,
            'currency_id' => $head['currency_id'] ?? base_currency_id($businessId),
            'total_debit' => round($td, 2), 'total_credit' => round($tc, 2), 'line_count' => count($lines),
            'source' => $head['source'] ?? 'manual', 'status' => 'posted', 'posted_at' => now(),
            'is_locked' => 0, 'is_active' => 1, 'created_at' => now(), 'created_by' => Auth::id(),
        ]);
        $row = 1;
        foreach ($lines as $l) {
            Database::insert('journal_entry_lines', [
                'journal_entry_id' => $id, 'row_no' => $row++,
                'account_id' => (int)$l['account_id'], 'description' => $l['description'] ?? ($head['description'] ?? null),
                'debit_amount' => round((float)($l['debit'] ?? 0), 2), 'credit_amount' => round((float)($l['credit'] ?? 0), 2),
                'currency_id' => $head['currency_id'] ?? base_currency_id($businessId), 'fx_amount' => $l['fx_amount'] ?? null,
                'person_id' => $l['person_id'] ?? null, 'product_id' => $l['product_id'] ?? null,
                'project_id' => $head['project_id'] ?? null, 'cost_center_id' => $l['cost_center_id'] ?? null,
                'cheque_id' => $l['cheque_id'] ?? null,
            ]);
        }
        // هم‌گام‌سازی ماندهٔ کارت حساب‌های نقد/بانکِ درگیر در سند (کارت حساب باید همیشه با دفتر یکی باشد)
        $glIds = [];
        foreach ($lines as $l) { $g = (int)($l['account_id'] ?? 0); if ($g) $glIds[$g] = true; }
        if ($glIds) {
            $ids = array_keys($glIds);
            $in = implode(',', array_fill(0, count($ids), '?'));
            foreach (Database::all("SELECT id FROM cash_accounts WHERE business_id=? AND gl_account_id IN ($in)", array_merge([$businessId], $ids)) as $ca) {
                Trade::updateCashBalance((int)$ca['id']);
            }
        }
        Audit::log('post_entry', 'journal_entries', $id, 'ثبت سند '.$entryNo, ['total' => $td]);
        return $id;
    }

    /** ثبت سند خودکار برای یک رویداد */
    public static function post(int $businessId, string $eventKey, array $amounts, array $ctx = []): ?int
    {
        // اگر «ثبت خودکار سند» این نوع رویداد در تنظیمات مالی خاموش باشد، سندی صادر نمی‌شود.
        if (!self::autoEnabled($businessId, $eventKey)) return null;
        $lines = []; $bag = self::bag($amounts);
        foreach (self::ruleLines($businessId, $eventKey) as [$side, $source, $mapKey, $amountKey, $fixedId]) {
            $amt = round((float)($bag[$amountKey] ?? 0), 2);
            if ($amt == 0) continue;
            $acc = self::resolveAccount($businessId, $source, $mapKey, $fixedId, $ctx);
            $line = ['account_id' => $acc, 'description' => $ctx['line_note'] ?? null];
            $line[$side] = abs($amt);
            if (!empty($ctx['person_id']) && (in_array($source, ['person'], true) || in_array($mapKey, ['ar','ap'], true))) $line['person_id'] = $ctx['person_id'];
            if (!empty($ctx['cost_center_id'])) $line['cost_center_id'] = $ctx['cost_center_id'];
            if (!empty($ctx['cheque_id'])) $line['cheque_id'] = $ctx['cheque_id'];
            $lines[] = $line;
        }
        // ترازسازی خودکار با حساب اختلاف (در صورت تعریف اختلاف در مبالغ)
        $td = array_sum(array_map(fn($l) => (float)($l['debit'] ?? 0), $lines));
        $tc = array_sum(array_map(fn($l) => (float)($l['credit'] ?? 0), $lines));
        if (abs($td - $tc) > 0.05) {
            $diff = round(abs($td - $tc), 2);
            $balKey = ($td > $tc) ? 'ar' : 'ap';
            $acc = Database::val('SELECT account_id FROM account_mappings WHERE business_id=? AND mapping_key=?', [$businessId, $balKey]);
            if (!$acc) throw new RuntimeException("سند رویداد «{$eventKey}» تراز نیست (اختلاف ".num($diff).").");
            $line = ['account_id' => (int)$acc, 'description' => 'تسویه اختلاف سند خودکار'];
            $line[($td > $tc) ? 'credit' : 'debit'] = $diff;
            if (!empty($ctx['person_id'])) $line['person_id'] = $ctx['person_id'];
            $lines[] = $line;
        }
        if (!$lines) return null;
        return self::create($businessId, [
            'entry_date' => $ctx['date'] ?? today(), 'entry_type' => $ctx['entry_type'] ?? 'normal',
            'reference_type' => $ctx['reference_type'] ?? $eventKey, 'reference_id' => $ctx['reference_id'] ?? null,
            'reference_no' => $ctx['reference_no'] ?? null,
            'description' => $ctx['description'] ?? null, 'project_id' => $ctx['project_id'] ?? null,
            'currency_id' => $ctx['currency_id'] ?? base_currency_id($businessId), 'source' => 'auto',
        ], $lines);
    }

    /** برگشت سند: سند معکوس ثبت و سند اصلی قفل می‌شود */
    public static function reverse(int $entryId, ?string $reason = null): int
    {
        $e = Database::one('SELECT * FROM journal_entries WHERE id=?', [$entryId]);
        if (!$e) throw new RuntimeException('سند یافت نشد.');
        if ($e['status'] === 'reversed') throw new RuntimeException('این سند قبلاً برگشت خورده است.');
        $lines = Database::all('SELECT * FROM journal_entry_lines WHERE journal_entry_id=? ORDER BY row_no', [$entryId]);
        $rev = [];
        foreach ($lines as $l) $rev[] = ['account_id' => $l['account_id'], 'debit' => $l['credit_amount'], 'credit' => $l['debit_amount'],
            'description' => 'برگشت: '.($l['description'] ?? ''), 'person_id' => $l['person_id'], 'product_id' => $l['product_id'], 'cheque_id' => $l['cheque_id']];
        $newId = self::create((int)$e['business_id'], [
            'entry_date' => today(), 'entry_type' => 'adjustment', 'reference_type' => 'reversal', 'reference_id' => $entryId,
            'reference_no' => $e['entry_no'], 'source' => 'auto',
            'description' => 'برگشت سند '.$e['entry_no'].($reason ? ' - '.$reason : ''),
        ], $rev);
        Database::run('UPDATE journal_entries SET is_locked=1, status="reversed" WHERE id=?', [$entryId]);
        return $newId;
    }

    /** مانده حساب‌ها از دفتر */
    public static function accountBalance(int $businessId, int $accountId, ?string $from = null, ?string $to = null, ?int $personId = null): array
    {
        $w = ['l.account_id = :acc', 'e.business_id = :biz', 'e.deleted_at IS NULL', "e.status IN ('posted','reversed')"]; $p = ['acc' => $accountId, 'biz' => $businessId];
        if ($from) { $w[] = 'e.entry_date >= :from'; $p['from'] = $from; }
        if ($to) { $w[] = 'e.entry_date <= :to'; $p['to'] = $to; }
        if ($personId) { $w[] = 'l.person_id = :pid'; $p['pid'] = $personId; }
        $r = Database::one('SELECT IFNULL(SUM(l.debit_amount),0) AS dr, IFNULL(SUM(l.credit_amount),0) AS cr
                              FROM journal_entry_lines l JOIN journal_entries e ON e.id = l.journal_entry_id
                             WHERE '.implode(' AND ', $w), $p);
        return ['debit' => (float)$r['dr'], 'credit' => (float)$r['cr'], 'balance' => (float)$r['dr'] - (float)$r['cr']];
    }
}
