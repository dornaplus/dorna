<?php
/**
 * موتور چاپ — «قالب چاپ» فعال کسب‌وکار را می‌خواند و به‌صورت واقعی روی صفحه‌های چاپ اعمال می‌کند:
 * اندازهٔ کاغذ (@page)، اندازهٔ قلم، لوگو و جای آن، مهر و امضا، مبلغ به حروف،
 * کد اقتصادی، اطلاعات بانکی و بارکد (Code128).
 */
final class Printing
{
    /** اندازهٔ کاغذ → [عرض، ارتفاع] میلی‌متر (ارتفاع null = نامحدود / رول) */
    public const PAPER = [
        'A4'           => [210, 297],
        'A5'           => [148, 210],
        'A4_landscape' => [297, 210],
        'thermal_80'   => [80, null],
        'label_50x30'  => [50, 30],
    ];

    /** نوع سند → عنوان فارسی */
    public const TYPES = [
        'invoice'   => 'فاکتور',
        'voucher'   => 'سند حسابداری',
        'receipt'   => 'رسید دریافت',
        'payment'   => 'سند پرداخت',
        'statement' => 'گزارش / صورت مالی',
        'label'     => 'برچسب',
        'payroll'   => 'سند حقوق و دستمزد',
    ];

    /** قالب پیش‌فرض هر نوع سند (برای کسب‌وکارهایی که قالب ذخیره‌شده ندارند) */
    public const DEFAULTS = [
        'invoice'   => ['title' => 'فاکتور رسمی A4',  'paper_size' => 'A4',  'font_size' => 12, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 1, 'show_economic_code' => 1, 'show_bank_info' => 1, 'show_barcode' => 0],
        'voucher'   => ['title' => 'سند حسابداری A4', 'paper_size' => 'A4',  'font_size' => 11, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 1, 'show_economic_code' => 0, 'show_bank_info' => 0, 'show_barcode' => 0],
        'receipt'   => ['title' => 'رسید دریافت A5',  'paper_size' => 'A5',  'font_size' => 11, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 1, 'show_economic_code' => 0, 'show_bank_info' => 0, 'show_barcode' => 1],
        'payment'   => ['title' => 'سند پرداخت A5',   'paper_size' => 'A5',  'font_size' => 11, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 1, 'show_economic_code' => 0, 'show_bank_info' => 0, 'show_barcode' => 1],
        'statement' => ['title' => 'صورت مالی A4',    'paper_size' => 'A4',  'font_size' => 10, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 0, 'show_economic_code' => 1, 'show_bank_info' => 0, 'show_barcode' => 0],
        'label'     => ['title' => 'برچسب ۵×۳ سانتی', 'paper_size' => 'label_50x30', 'font_size' => 9, 'show_logo' => 0, 'logo_position' => 'center', 'show_signature' => 0, 'amount_in_words' => 0, 'show_economic_code' => 0, 'show_bank_info' => 0, 'show_barcode' => 1],
        'payroll'   => ['title' => 'سند حقوق A4',     'paper_size' => 'A4',  'font_size' => 11, 'show_logo' => 1, 'logo_position' => 'right',  'show_signature' => 1, 'amount_in_words' => 0, 'show_economic_code' => 0, 'show_bank_info' => 1, 'show_barcode' => 0],
    ];

    private static array $cache = [];

    /** قالب پیش‌فرض داخلی یک نوع سند */
    public static function fallback(string $type): array
    {
        $d = self::DEFAULTS[$type] ?? self::DEFAULTS['invoice'];
        return ['id' => null, 'business_id' => null, 'template_type' => $type, 'status' => 'active', 'is_default' => 1] + $d;
    }

    /** قالب فعالِ کسب‌وکار برای یک نوع سند (با کش در هر درخواست) */
    public static function template(string $type): array
    {
        $bid = (int)Auth::businessId();
        $key = $bid . ':' . $type;
        if (isset(self::$cache[$key])) return self::$cache[$key];
        if ($bid <= 0) return self::fallback($type);
        $row = Database::one('SELECT * FROM print_templates WHERE business_id=? AND template_type=? AND status="active" AND deleted_at IS NULL
                              ORDER BY is_default DESC, id LIMIT 1', [$bid, $type]);
        if (!$row) {
            $row = Database::one('SELECT * FROM print_templates WHERE business_id=? AND is_default=1 AND status="active" AND deleted_at IS NULL ORDER BY id LIMIT 1', [$bid]);
            if ($row) $row['template_type'] = $type;      // سقوط به قالب پیش‌فرض موجود
        }
        if (!$row) $row = self::fallback($type);
        return self::$cache[$key] = $row;
    }

    /** ساخت قالب‌های پیش‌فرض برای انواع سندی که کسب‌وکار ندارد (idempotent) */
    public static function ensureDefaults(int $bid, ?int $uid = null): int
    {
        if ($bid <= 0) return 0;
        $have = array_column(Database::all('SELECT template_type FROM print_templates WHERE business_id=? AND deleted_at IS NULL', [$bid]), 'template_type');
        $made = 0;
        foreach (self::DEFAULTS as $type => $d) {
            if (in_array($type, $have, true)) continue;
            Database::insert('print_templates', ['business_id' => $bid, 'title' => $d['title'], 'template_type' => $type,
                'paper_size' => $d['paper_size'], 'show_logo' => $d['show_logo'], 'logo_position' => $d['logo_position'],
                'font_size' => $d['font_size'], 'show_signature' => $d['show_signature'], 'amount_in_words' => $d['amount_in_words'],
                'show_economic_code' => $d['show_economic_code'], 'show_bank_info' => $d['show_bank_info'], 'show_barcode' => $d['show_barcode'],
                'is_default' => in_array($type, ['invoice', 'voucher'], true) ? 1 : 0, 'status' => 'active', 'is_active' => 1,
                'created_at' => now(), 'created_by' => $uid]);
            $made++;
        }
        if ($made) self::$cache = [];
        return $made;
    }

    /** مقدار size برای @page */
    public static function pageSize(array $tpl): string
    {
        [$w, $h] = self::PAPER[(string)($tpl['paper_size'] ?? 'A4')] ?? self::PAPER['A4'];
        return $h === null ? $w . 'mm auto' : $w . 'mm ' . $h . 'mm';
    }

    /** بلوک <style> که اندازهٔ کاغذ، اندازهٔ قلم و جای لوگو را اعمال می‌کند */
    public static function style(array $tpl): string
    {
        [$w, $h] = self::PAPER[(string)($tpl['paper_size'] ?? 'A4')] ?? self::PAPER['A4'];
        $fs = max(7, min(20, (int)($tpl['font_size'] ?? 12)));
        $narrow = $w <= 100;
        $f = $fs / 12;
        $pos = in_array((string)($tpl['logo_position'] ?? 'right'), ['right', 'center', 'left'], true) ? (string)$tpl['logo_position'] : 'right';
        $align = $pos === 'center' ? 'center' : ($pos === 'left' ? 'flex-end' : 'flex-start');
        $px = static fn(float $v): string => rtrim(rtrim(number_format($v, 1, '.', ''), '0'), '.') . 'px';
        $css = '@page{size:' . self::pageSize($tpl) . ';margin:' . ($narrow ? '4mm 3mm' : '10mm 8mm') . '}'
            . '.print-page{font-size:' . $fs . 'px;max-width:' . $w . 'mm}'
            . '.print-brand{display:flex;flex-direction:column;align-items:' . $align . '}'
            . '.print-logo{max-height:' . $px(18 * $f) . ';max-width:100%;object-fit:contain;margin-bottom:6px}'
            . '.print-head h1,.print-head .biz{font-size:' . $px(19 * $f) . '}'
            . '.print-head h2{font-size:' . $px(15 * $f) . '}'
            . '.print-meta{font-size:' . $px(12 * $f) . '}'
            . '.words{font-size:' . $px(12.5 * $f) . '}'
            . '.signs{font-size:' . $px(12 * $f) . '}'
            . '.print-note{font-size:' . $px(12.5 * $f) . '}'
            . '.print-foot{font-size:' . $px(10.8 * $f) . '}'
            . 'table.print-tbl{font-size:' . $px(12.3 * $f) . '}'
            . 'table.print-tbl thead th{font-size:' . $px(11.8 * $f) . '}'
            . '.print-barcode{display:block;margin:10px 0;height:' . $px(12 * $f) . '}'
            . '.print-bank{font-size:' . $px(11 * $f) . ';color:#374151;border-top:1px dashed #C4B0FE;margin-top:10px;padding-top:6px}'
            . '.print-bank b{color:#111827}'
            . '@media print{.print-page{max-width:none;font-size:' . $fs . 'px}table.print-tbl{table-layout:fixed;width:100%}}'
            . (($h !== null && $w <= 100) ? '.print-page{padding:2mm}' : '');
        return '<style id="print-tpl-style">' . $css . '</style>';
    }

    /** پوشهٔ عمومی (public) برنامه */
    public static function publicDir(): string { return dirname(__DIR__) . '/public'; }

    /** پوشهٔ آپلود لوگو (نسبت به public) */
    public const LOGO_BASE = 'uploads/biz';

    /**
     * ذخیرهٔ لوگوی کسب‌وکار در جدول attachments و اتصال آن به businesses.logo_attachment_id
     * @return array{ok:bool,error:?string,empty:bool,id:?int}
     */
    public static function saveLogo(string $field, int $bid, ?int $uid = null): array
    {
        $out = ['ok' => false, 'error' => null, 'empty' => true, 'id' => null];
        if ($bid <= 0) { $out['error'] = 'کسب‌وکار نامعتبر است.'; return $out; }
        if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) return $out;
        $f = $_FILES[$field];
        $err = (int)($f['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) return $out;
        $out['empty'] = false;
        if ($err !== UPLOAD_ERR_OK) { $out['error'] = 'آپلود تصویر ناموفق بود (کد ' . $err . ').'; return $out; }
        if ((int)$f['size'] > 3 * 1024 * 1024) { $out['error'] = 'حجم تصویر باید کمتر از ۳ مگابایت باشد.'; return $out; }
        if (!is_uploaded_file((string)$f['tmp_name'])) { $out['error'] = 'فایل نامعتبر است.'; return $out; }
        $info = @getimagesize((string)$f['tmp_name']);
        $allowed = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_GIF => 'gif', IMAGETYPE_WEBP => 'webp'];
        $type = is_array($info) ? (int)$info[2] : 0;
        if (!isset($allowed[$type])) { $out['error'] = 'فقط تصویر JPG، PNG، WEBP یا GIF مجاز است.'; return $out; }

        $rel = self::LOGO_BASE . '/' . $bid;
        $dir = self::publicDir() . '/' . $rel;
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) { $out['error'] = 'ساخت پوشهٔ آپلود ممکن نشد.'; return $out; }
        $name = 'logo-' . date('Ymd-His') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$type];
        if (!@move_uploaded_file((string)$f['tmp_name'], $dir . '/' . $name)) { $out['error'] = 'ذخیرهٔ تصویر ممکن نشد.'; return $out; }
        @chmod($dir . '/' . $name, 0644);

        self::clearLogo($bid);   // لوگوی قبلی حذف شود
        $aid = (int)Database::insert('attachments', ['business_id' => $bid, 'entity_type' => 'business', 'entity_id' => $bid,
            'file_name' => 'logo.' . $allowed[$type], 'storage_key' => $rel . '/' . $name, 'mime_type' => (string)($info['mime'] ?? 'image/png'),
            'size_bytes' => (int)$f['size'], 'uploaded_by' => $uid, 'is_public' => 1]);
        Database::update('businesses', ['logo_attachment_id' => $aid, 'updated_at' => now(), 'updated_by' => $uid], 'id=:pk', ['pk' => $bid]);
        return ['ok' => true, 'error' => null, 'empty' => false, 'id' => $aid];
    }

    /** حذف لوگوی کسب‌وکار (فایل + رکورد) */
    public static function clearLogo(int $bid): void
    {
        if ($bid <= 0) return;
        // ابتدا ارجاع در جدول businesses آزاد می‌شود (قید خارجی RESTRICT اجازهٔ حذف نمی‌دهد)
        Database::update('businesses', ['logo_attachment_id' => null], 'id=:pk', ['pk' => $bid]);
        $prev = Database::one('SELECT * FROM attachments WHERE business_id=? AND entity_type="business" AND entity_id=? ORDER BY id DESC LIMIT 1', [$bid, $bid]);
        if ($prev) {
            $key = (string)$prev['storage_key'];
            if (str_contains($key, self::LOGO_BASE . '/')) {
                $p = self::publicDir() . '/' . ltrim($key, '/');
                if (is_file($p)) @unlink($p);
            }
            Database::run('DELETE FROM attachments WHERE id=?', [(int)$prev['id']]);
        }
    }

    /** تصویر لوگوی کسب‌وکار (یا رشتهٔ خالی) */
    public static function logo(?array $biz = null): string
    {
        $biz = $biz ?? Auth::business();
        $aid = (int)($biz['logo_attachment_id'] ?? 0);
        if ($aid <= 0) return '';
        $att = Database::one('SELECT storage_key, file_name FROM attachments WHERE id=? AND business_id=?', [$aid, (int)($biz['id'] ?? 0)]);
        if (!$att || trim((string)$att['storage_key']) === '') return '';
        return '<img class="print-logo" src="' . e(url((string)$att['storage_key'])) . '" alt="' . e((string)($att['file_name'] ?? 'لوگو')) . '">';
    }

    /** حساب‌های بانکی فعال کسب‌وکار (برای بلوک «اطلاعات بانکی») */
    public static function banks(?int $bid = null): array
    {
        $bid = $bid ?? (int)Auth::businessId();
        if ($bid <= 0) return [];
        return Database::all('SELECT title, bank_name, branch_name, account_no, card_no, iban FROM cash_accounts
                              WHERE business_id=? AND account_kind="bank" AND status="active" AND deleted_at IS NULL
                              ORDER BY id LIMIT 4', [$bid]);
    }

    /** بارکد Code128-B به‌صورت SVG (قابل اسکن) */
    public static function barcode(string $text, float $unit = 1.4): string
    {
        static $pat = [
            '212222','222122','222221','121223','121322','131222','122213','122312','132212','221213',
            '221312','231212','112232','122132','122231','113222','123122','123221','223211','221132',
            '221231','213212','223112','312131','311222','321122','321221','312212','322112','322211',
            '212123','212321','232121','111323','131123','131321','112313','132113','132311','211313',
            '231113','231311','112133','112331','132131','113123','113321','133121','313121','211331',
            '231131','213113','213311','213131','311123','311321','331121','312113','312311','332111',
            '314111','221411','431111','111224','111422','121124','121421','141122','141221','112214',
            '112412','122114','122411','142112','142211','241211','221114','413111','241112','134111',
            '111242','121142','121241','114212','124112','124211','411212','421112','421211','212141',
            '214121','412121','111143','111341','131141','114113','114311','411113','411311','113141',
            '114131','311141','411131','211412','211214','211232','2331112',
        ];
        $clean = '';
        $len = strlen($text);
        for ($i = 0; $i < $len; $i++) {
            $c = ord($text[$i]);
            if ($c >= 32 && $c <= 126) $clean .= $text[$i];      // Code128-B
        }
        if ($clean === '') return '';
        $codes = [104];                                          // START B
        $n = strlen($clean);
        for ($i = 0; $i < $n; $i++) $codes[] = ord($clean[$i]) - 32;
        $sum = 104;
        for ($i = 1; $i < count($codes); $i++) $sum += $codes[$i] * $i;
        $codes[] = $sum % 103;                                   // checksum
        $codes[] = 106;                                          // STOP
        $bars = ''; $x = 0.0;
        foreach ($codes as $code) {
            $p = $pat[$code] ?? '';
            $bar = true;
            for ($i = 0; $i < strlen($p); $i++) {
                $w = (int)$p[$i] * $unit;
                if ($bar) $bars .= '<rect x="' . round($x, 2) . '" y="0" width="' . round($w, 2) . '" height="40"/>';
                $x += $w; $bar = !$bar;
            }
        }
        $w = round($x, 2);
        return '<div class="print-barcode"><svg viewBox="0 0 ' . $w . ' 40" width="' . $w . '" height="40" fill="#000" shape-rendering="crispEdges" role="img" aria-label="' . e($clean) . '">' . $bars . '</svg></div>';
    }

    /** بلوک اطلاعات بانکی برای پایان سند */
    public static function bankBlock(?int $bid = null): string
    {
        $banks = self::banks($bid);
        if (!$banks) return '';
        $out = '<div class="print-bank">اطلاعات بانکی: ';
        $bits = [];
        foreach ($banks as $b) {
            $t = [];
            if (!empty($b['bank_name'])) $t[] = e((string)$b['bank_name']);
            if (!empty($b['title'])) $t[] = e((string)$b['title']);
            if (!empty($b['account_no'])) $t[] = 'حساب ' . e(fa_digits((string)$b['account_no']));
            if (!empty($b['card_no'])) $t[] = 'کارت ' . e(fa_digits((string)$b['card_no']));
            if (!empty($b['iban'])) $t[] = 'شبا <span dir="ltr">' . e((string)$b['iban']) . '</span>';
            $bits[] = implode(' — ', $t);
        }
        return $out . implode(' | ', $bits) . '</div>';
    }
}
