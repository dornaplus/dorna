<?php
/**
 * لایه متادیتای دیتابیس: ساختار ۱۲۹ جدول را از information_schema می‌خواند و
 * برای تولید خودکار فهرست‌ها و فرم‌ها استفاده می‌کند (برچسب فارسی = COMMENT ستون).
 * نتیجه در storage/schema_cache.php ذخیره می‌شود؛ برای بازسازی، آن فایل را حذف کنید.
 */
final class Schema
{
    private static ?array $d = null;
    private const CACHE = __DIR__.'/../storage/schema_cache.php';

    /** ستون‌های نمایش متنی رکورد در جدول‌های خاص (ترکیبی) */
    private const TITLE = [
        'persons'      => ['company_name', 'first_name', 'last_name'],
        'users'        => ['full_name', 'mobile'],
        'employees'    => ['full_name', 'code'],
        'shareholders' => ['person_id'],
        'person_types' => ['title'],
        'product_categories' => ['title','path'],
        'marketers'    => ['person_id'],
        'chart_of_accounts' => ['title'],
        'journal_entries'  => ['entry_no', 'description'],
        'receipts'         => ['doc_no'], 'payments' => ['doc_no'], 'cheques' => ['cheque_no'],
        'inventory_documents' => ['doc_no', 'doc_type'], 'stock_counts' => ['doc_no'],
        'payroll_documents'   => ['doc_no', 'period_title'], 'fiscal_years' => ['title'],
        'transfers' => ['doc_no'], 'tickets' => ['ticket_no', 'subject'],
        'subscriptions' => ['id'], 'plans' => ['title'],
        'businesses'   => ['name'],
        'projects'     => ['name', 'code'],
        'cost_centers' => ['name', 'code'],
    ];

    /** برچسب فارسی ستون‌های نماهای گزارش (وقتی COMMENT ستون خالی است) */
    private const LABELS_FA = [
        'account_id' => 'حساب', 'business_id' => 'کسب‌وکار', 'fiscal_year_id' => 'سال مالی',
        'person_id' => 'شخص', 'person_name' => 'نام شخص', 'cash_account_id' => 'حساب نقد/بانک',
        'balance_amount' => 'مانده', 'running_balance' => 'مانده تجمعی',
        'debit_total' => 'جمع بدهکار', 'credit_total' => 'جمع بستانکار',
        'total_debit' => 'جمع بدهکار', 'total_credit' => 'جمع بستانکار',
        'closing_debit_total' => 'جمع بدهکار', 'closing_credit_total' => 'جمع بستانکار',
        'turn_debit' => 'گردش بدهکار', 'turn_credit' => 'گردش بستانکار',
        'opening_debit' => 'مانده ابتدای دوره (بدهکار)', 'opening_credit' => 'مانده ابتدای دوره (بستانکار)',
        'net_amount' => 'مبلغ خالص', 'net_change' => 'تغییر خالص',
        'paid_amount' => 'پرداخت‌شده', 'remaining_amount' => 'مانده', 'paid' => 'پرداخت‌شده',
        'sales_amount' => 'مبلغ فروش', 'purchase_amount' => 'مبلغ خرید',
        'sold_amount' => 'مبلغ فروش', 'sold_quantity' => 'مقدار فروش',
        'sold_cost_amount' => 'بهای تمام‌شده فروش', 'gross_profit_amount' => 'سود ناخالص',
        'bought_amount' => 'مبلغ خرید', 'bought_quantity' => 'مقدار خرید',
        'sales_base_amount' => 'مبلغ پایه فروش', 'purchase_base_amount' => 'مبلغ پایه خرید',
        'output_vat' => 'مالیات فروش (پرداختنی)', 'input_vat' => 'مالیات خرید (اعتبار)', 'payable_vat' => 'مالیات قابل پرداخت',
        'commission_amount' => 'مبلغ پورسانت', 'commission_base_amount' => 'پایه پورسانت',
        'profit_percent' => 'درصد سود', 'doc_no' => 'شماره سند', 'doc_date' => 'تاریخ سند', 'doc_type' => 'نوع سند',
        'ref_id' => 'شناسه مرجع', 'amount_in' => 'واریز', 'amount_out' => 'برداشت',
        'invoice_count' => 'تعداد فاکتور', 'sale_invoice_count' => 'تعداد فاکتور فروش', 'buy_invoice_count' => 'تعداد فاکتور خرید',
        'days_overdue' => 'روز تأخیر', 'aging_bucket' => 'بازه سنی', 'days_to_due' => 'روز تا سررسید',
        'period_month' => 'دوره (ماه)', 'gregorian_quarter' => 'فصل میلادی', 'report_date' => 'تاریخ گزارش',
        'inventory_value' => 'ارزش موجودی', 'stock_value' => 'ارزش موجودی', 'product_count' => 'تعداد کالا',
        'total_quantity' => 'مقدار کل', 'reorder_point' => 'نقطه سفارش', 'shortage_quantity' => 'کسری موجودی',
        'shareholder_count' => 'تعداد سهامدار', 'declared_capital' => 'سرمایه ثبت‌شده',
        'cash_and_bank_balance' => 'موجودی نقد و بانک', 'receivable_amount' => 'طلب', 'payable_amount' => 'بدهی',
        'month_sales_amount' => 'فروش این ماه', 'month_purchase_amount' => 'خرید این ماه',
        'month_income_amount' => 'درآمد این ماه', 'month_expense_amount' => 'هزینه این ماه',
        'due_cheques_count' => 'چک‌های نزدیک سررسید', 'overdue_invoice_count' => 'فاکتورهای معوق',
        'active_session_count' => 'نشست‌های فعال', 'last_session_expires_at' => 'انقضای آخرین نشست', 'ip_text' => 'نشانی IP',
    ];

    public static function init(): void
    {
        if (self::$d !== null) return;
        if (is_file(self::CACHE) && filemtime(self::CACHE) > max(filemtime(__DIR__.'/../config.php'), filemtime(__FILE__))) { self::$d = require self::CACHE; return; }
        self::$d = self::build();
        @file_put_contents(self::CACHE, "<?php return ".var_export(self::$d, true).";\n");
    }
    public static function flush(): void { @unlink(self::CACHE); self::$d = null; }

    private static function build(): array
    {
        $db = config('db.name');
        $out = ['columns' => [], 'pk' => [], 'fks' => [], 'unique' => [], 'labels' => [], 'views' => [], 'json' => []];

        /* برخی میزبان‌های اشتراکی روی information_schema محدودیت دارند (خطای «Unknown column TABLE_NAME»).
           ابتدا information_schema، و در صورت خطا fallback به دستورات SHOW که همه‌جا کار می‌کنند. */
        $useFallback = false;
        try {
            $rows = Database::all(
                'SELECT TABLE_NAME, COLUMN_NAME, ORDINAL_POSITION, DATA_TYPE, COLUMN_TYPE, IS_NULLABLE, COLUMN_DEFAULT,
                        EXTRA, COLUMN_COMMENT, CHARACTER_MAXIMUM_LENGTH, NUMERIC_PRECISION, NUMERIC_SCALE
                   FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = :db ORDER BY TABLE_NAME, ORDINAL_POSITION',
                ['db' => $db]);
            if (!$rows) $useFallback = true; // دیتابیس خالی یا پاسخ بی‌فایده
        } catch (Throwable $e) {
            $useFallback = true;
        }

        if ($useFallback) {
            $tables = [];
            foreach (Database::all('SHOW FULL TABLES') as $r) {
                $t = array_values($r)[0];
                $kind = array_values($r)[1] ?? 'BASE TABLE';
                if ($kind === 'VIEW') $out['views'][] = $t;
                $tables[] = $t;
            }
            foreach (array_merge($tables, $out['views']) as $t) {
                $i = 0;
                foreach (Database::all('SHOW FULL COLUMNS FROM `'.str_replace('`','',$t).'`') as $r) {
                    $i++;
                    $c = (string)($r['Field'] ?? '');
                    if ($c === '') continue;
                    $ctype = (string)($r['Type'] ?? '');
                    $dtype = strtolower(preg_replace('/\(.*\)/', '', $ctype));
                    if (str_contains($dtype, ' ')) $dtype = explode(' ', $dtype)[0];
                    $enum = [];
                    if ($dtype === 'enum') { preg_match_all("/'((?:[^']|\\.)*)'/", $ctype, $m); $enum = $m[1]; }
                    $out['columns'][$t][$c] = [
                        'pos' => $i, 'type' => $dtype, 'column_type' => $ctype,
                        'null' => strtoupper((string)($r['Null'] ?? 'NO')) === 'YES',
                        'default' => (isset($r['Default']) && $r['Default'] === 'NULL') ? null : ($r['Default'] ?? null),
                        'extra' => (string)($r['Extra'] ?? ''),
                        'enum' => $enum, 'comment' => trim((string)($r['Comment'] ?? '')),
                        'len' => 0, 'precision' => 0, 'scale' => 0,
                    ];
                    if (($out['columns'][$t][$c]['comment']) !== '' && !isset($out['labels'][$c])) $out['labels'][$c] = $out['columns'][$t][$c]['comment'];
                }
                // کلید اصلی و ایندکس‌ها
                foreach (Database::all('SHOW INDEX FROM `'.str_replace('`','',$t).'`') as $r) {
                    if (($r['Key_name'] ?? '') === 'PRIMARY') $out['pk'][$t][] = $r['Column_name'];
                    elseif (empty($r['Non_unique'])) $out['unique'][$t][] = [$r['Column_name']];
                }
            }
            // کلیدهای خارجی از طریق CREATE TABLE
            foreach ($tables as $t) {
                if (in_array($t, $out['views'], true)) continue;
                try {
                    $ddlRow = Database::one('SHOW CREATE TABLE `'.str_replace('`','',$t).'`');
                    $ddl = (string)($ddlRow['Create Table'] ?? '');
                } catch (Throwable $e) { $ddl = ''; }
                if (preg_match_all('/FOREIGN KEY\s*\(`?([a-z0-9_]+)`?\)\s*REFERENCES\s*`?([a-z0-9_]+)`?\s*\(`?([a-z0-9_]+)`?\)/i', $ddl, $mm, PREG_SET_ORDER)) {
                    foreach ($mm as $m) $out['fks'][$t][$m[1]] = ['table' => $m[2], 'column' => $m[3]];
                }
            }
            return $out;
        }

        foreach ($rows as $r) {
            $t = $r['TABLE_NAME']; $c = $r['COLUMN_NAME'];
            $enum = [];
            if ($r['DATA_TYPE'] === 'enum') {
                preg_match_all("/'((?:[^'\\\\]|\\\\.)*)'/", $r['COLUMN_TYPE'], $m);
                $enum = $m[1];
            }
            $out['columns'][$t][$c] = [
                'pos' => (int)$r['ORDINAL_POSITION'], 'type' => $r['DATA_TYPE'], 'column_type' => $r['COLUMN_TYPE'],
                'null' => $r['IS_NULLABLE'] === 'YES',
                // برخی درایورها مقدار پیش‌فرض ستون‌های nullable را رشته «NULL» برمی‌گردانند
                'default' => (is_string($r['COLUMN_DEFAULT']) && $r['COLUMN_DEFAULT'] === 'NULL') ? null : $r['COLUMN_DEFAULT'],
                'extra' => $r['EXTRA'],
                'enum' => $enum, 'comment' => trim((string)$r['COLUMN_COMMENT']),
                'len' => (int)$r['CHARACTER_MAXIMUM_LENGTH'], 'precision' => (int)$r['NUMERIC_PRECISION'], 'scale' => (int)$r['NUMERIC_SCALE'],
            ];
            if ($r['COLUMN_COMMENT'] !== '' && !isset($out['labels'][$c])) $out['labels'][$c] = trim((string)$r['COLUMN_COMMENT']);
        }
        // هر بخش ثانویه جداگانه محافظت می‌شود؛ خطای یک بخش (مثلاً ناسازگاری MySQL/MariaDB)
        // نباید بقیه متادیتا — به‌ویژه فهرست نماها — را از بین ببرد.
        try {
            foreach (Database::all('SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=:db AND REFERENCED_TABLE_NAME IS NOT NULL ORDER BY TABLE_NAME, ORDINAL_POSITION', ['db' => $db]) as $r)
                $out['fks'][$r['TABLE_NAME']][$r['COLUMN_NAME']] = ['constraint' => $r['CONSTRAINT_NAME']];
            $fkTargets = Database::all('SELECT TABLE_NAME, COLUMN_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM information_schema.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA=:db AND REFERENCED_TABLE_NAME IS NOT NULL', ['db' => $db]);
            foreach ($fkTargets as $r) $out['fks'][$r['TABLE_NAME']][$r['COLUMN_NAME']] = ['table' => $r['REFERENCED_TABLE_NAME'], 'column' => $r['REFERENCED_COLUMN_NAME']];
        } catch (Throwable $e) { /* بخش اختیاری */ }

        try {
            foreach (Database::all('SELECT TABLE_NAME, INDEX_NAME, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols, NON_UNIQUE FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=:db GROUP BY TABLE_NAME, INDEX_NAME, NON_UNIQUE', ['db' => $db]) as $r) {
                $t = $r['TABLE_NAME']; $cols = explode(',', (string)$r['cols']);
                if ($r['INDEX_NAME'] === 'PRIMARY') $out['pk'][$t] = $cols;
                elseif ((int)$r['NON_UNIQUE'] === 0) $out['unique'][$t][] = $cols;
            }
        } catch (Throwable $e) { /* بخش اختیاری */ }

        // ستون‌های JSON: در MariaDB نوع json به LONGTEXT + قید CHECK(json_valid(...)) تبدیل می‌شود.
        // توجه: در MySQL ستون TABLE_NAME در information_schema.CHECK_CONSTRAINTS وجود ندارد و
        // باید از TABLE_CONSTRAINTS گرفته شود؛ در MariaDB هر دو حالت پاسخ می‌دهد (ابتدا join، سپس ساده).
        try {
            $checks = Database::all('SELECT t.TABLE_NAME AS TABLE_NAME, c.CHECK_CLAUSE AS CHECK_CLAUSE
                    FROM information_schema.CHECK_CONSTRAINTS c
                    JOIN information_schema.TABLE_CONSTRAINTS t
                      ON t.CONSTRAINT_SCHEMA = c.CONSTRAINT_SCHEMA AND t.CONSTRAINT_NAME = c.CONSTRAINT_NAME
                   WHERE c.CONSTRAINT_SCHEMA = :db', ['db' => $db]);
        } catch (Throwable $e) {
            try { $checks = Database::all('SELECT TABLE_NAME, CHECK_CLAUSE FROM information_schema.CHECK_CONSTRAINTS WHERE CONSTRAINT_SCHEMA=:db', ['db' => $db]); }
            catch (Throwable $e2) { $checks = []; }
        }
        foreach ($checks as $r) {
            if (!empty($r['TABLE_NAME']) && preg_match_all('/json_valid\(`?([a-z0-9_]+)`?\)/i', (string)$r['CHECK_CLAUSE'], $cm)) {
                foreach ($cm[1] as $c) $out['json'][$r['TABLE_NAME']][$c] = true;
            }
        }

        try {
            foreach (Database::all('SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA=:db', ['db' => $db]) as $r) {
                $out['views'][] = $r['TABLE_NAME'];
            }
        } catch (Throwable $e) { /* بخش اختیاری */ }
        return $out;
    }

    public static function tables(): array { self::init(); return array_values(array_diff(array_keys(self::$d['columns']), self::$d['views'])); }
    public static function views(): array { self::init(); return self::$d['views']; }
    public static function columns(string $t): array { self::init(); return self::$d['columns'][$t] ?? []; }
    public static function column(string $t, string $c): ?array { self::init(); return self::$d['columns'][$t][$c] ?? null; }
    public static function pk(string $t): array {
        self::init();
        $p = self::$d['pk'][$t] ?? [];
        if ($p) return $p;
        // نماهای بدون کلید اصلی: اولین ستون موجود از نام‌های مرسوم، وگرنه اولین ستون نما
        $cols = array_keys(self::$d['columns'][$t] ?? []);
        foreach (['id', 'log_id', $t.'_id'] as $c) if (in_array($c, $cols, true)) return [$c];
        foreach (['id', 'log_id'] as $c) foreach ($cols as $col) { if (str_ends_with($col, '_id')) { return [$col]; } }
        return $cols ? [$cols[0]] : ['id'];
    }
    public static function fk(string $t, string $c): ?array { self::init(); return self::$d['fks'][$t][$c] ?? null; }
    public static function uniques(string $t): array { self::init(); return self::$d['unique'][$t] ?? []; }
    public static function isView(string $t): bool { self::init(); return in_array($t, self::$d['views'], true); }
    /** آیا ستون JSON است؟ (در MariaDB نوع json به LONGTEXT + قید json_valid تبدیل می‌شود) */
    public static function isJson(string $table, string $col): bool
    {
        self::init();
        return !empty(self::$d['json'][$table][$col]) || (self::column($table, $col)['type'] ?? '') === 'json';
    }

    public static function label(string $t, string $c): string
    {
        $col = self::column($t, $c);
        if ($col && $col['comment'] !== '') return $col['comment'];
        self::init();
        if (isset(self::$d['labels'][$c])) return self::$d['labels'][$c];
        if (isset(self::LABELS_FA[$c])) return self::LABELS_FA[$c];
        return $c;
    }
    /** ستونی برای نمایش متنی رکورد ارجاع‌شده (کشور، شخص، کالا، فاکتور …) */
    public static function titleColumns(string $t): array
    {
        self::init();
        if (isset(self::TITLE[$t])) {
            $ok = array_values(array_filter(self::TITLE[$t], fn($c) => isset(self::$d['columns'][$t][$c])));
            if ($ok) return $ok;
        }
        $cands = ['title','full_name','name','invoice_no','doc_no','title_fa','subject','code','slug','cheque_no','ticket_no','account_name'];
        $cols = self::columns($t);
        foreach ($cands as $c) if (isset($cols[$c])) return [$c];
        foreach ($cols as $name => $m) if (in_array($m['type'], ['varchar','text','char'], true) && $name !== 'id') return [$name];
        return ['id'];
    }
    public static function titleColumn(string $t): string { return self::titleColumns($t)[0]; }
    /** برچسب ترکیبی جدول (برای نمایش در گزینه‌ها) */
    public static function refText(string $t, array $row): string
    {
        $cols = self::titleColumns($t);
        $parts = [];
        foreach ($cols as $c) {
            if ($c === 'id') continue;
            if ($c === 'person_id' && isset($row['person_id'])) { $parts[] = '#'.$row['person_id']; continue; }
            $v = trim((string)($row[$c] ?? ''));
            if ($v !== '') $parts[] = $v;
        }
        $text = implode(' ', $parts);
        $code = $row['code'] ?? null;
        if ($code && !str_contains($text, (string)$code)) $text = trim($code.' — '.$text, ' —');
        if ($text === '') $text = '#'.($row['id'] ?? '');
        return $text;
    }
    /** گزینه‌های یک کلید خارجی برای انتخابگرها */
    public static function options(string $table, string $q = '', int $limit = 50, array $scope = []): array
    {
        $titles = self::titleColumns($table);
        $where = []; $p = [];
        foreach ($scope as $k => $v) { $where[] = "`$k` = :s_$k"; $p["s_$k"] = $v; }
        if ($q !== '') {
            $likes = [];
            foreach ($titles as $i => $tc) { $likes[] = "CAST(`$tc` AS CHAR) LIKE :q"; }
            $likes[] = 'CAST(`id` AS CHAR) LIKE :q';
            $where[] = '('.implode(' OR ', $likes).')'; $p['q'] = '%'.$q.'%';
        }
        $cols = self::columns($table);
        $sel = array_merge(['id'], $titles);
        if (isset($cols['code'])) $sel[] = 'code';
        if (isset($cols['is_active'])) $where[] = 'is_active = 1';
        if (isset($cols['mobile']) && !in_array('mobile', $sel, true)) $sel[] = 'mobile';
        $sql = "SELECT ".implode(',', array_unique($sel))." FROM `$table`".($where ? ' WHERE '.implode(' AND ', $where) : '')." ORDER BY `{$titles[0]}` LIMIT $limit";
        $out = [];
        foreach (Database::all($sql, $p) as $r) $out[] = ['id' => $r['id'], 'text' => self::refText($table, $r)];
        return $out;
    }
    /** ستون‌های نمایشی پیش‌فرض یک جدول */
    public static function defaultListColumns(string $t, int $max = 7): array
    {
        $skip = ['business_id','created_at','created_by','updated_at','updated_by','deleted_at','row_version','is_active','password_hash','secret_hash','code_hash','value_json','layout_json','scopes_json','condition_json','allowed_ips'];
        $cols = self::columns($t); $out = [];
        foreach ($cols as $name => $m) {
            if (in_array($name, $skip, true)) continue;
            if (in_array($m['type'], ['longtext','mediumtext','blob','json'], true)) continue;
            $out[] = $name;
            if (count($out) >= $max) break;
        }
        return $out;
    }
}
