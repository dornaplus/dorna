<?php
/** سرویس‌های کمکی: کد تایید (OTP)، پیامک، شماره‌گذاری اسناد، لاگ حسابرسی، تنظیمات */
final class Otp
{
    /** نگاشت هدف کد تایید به مقادیر مجاز ستون purpose در جدول otp_codes */
    public static function purpose(string $p): string
    {
        return match ($p) {
            'register', 'verify', 'verify_contact', 'phone_change' => 'verify_contact',
            'reset', 'reset_password', 'forgot'                   => 'reset_password',
            '2fa', 'two_factor'                                   => '2fa',
            default                                               => 'login',
        };
    }

    public static function create(?int $userId, string $mobile, string $purpose = 'register'): string
    {
        $cfg = config('security');
        $purpose = self::purpose($purpose);
        // ستون created_at در جدول otp_codes وجود ندارد؛ زمان ارسال از expires_at منهای اعتبار محاسبه می‌شود
        $last = Database::one('SELECT expires_at FROM otp_codes WHERE mobile=? AND purpose=? ORDER BY id DESC LIMIT 1', [$mobile, $purpose]);
        if ($last) {
            $sentAt = strtotime((string)$last['expires_at']) - (int)$cfg['otp_ttl_seconds'];
            if ((time() - $sentAt) < (int)$cfg['otp_resend_seconds']) {
                $wait = (int)$cfg['otp_resend_seconds'] - (time() - $sentAt);
                throw new RuntimeException('لطفاً '.ceil(max(1, $wait) / 60).' دقیقه دیگر برای ارسال مجدد کد صبر کنید.');
            }
        }
        $code = (string)random_int(100000, 999999);
        Database::run('DELETE FROM otp_codes WHERE mobile=? AND purpose=? AND used_at IS NULL', [$mobile, $purpose]);
        Database::insert('otp_codes', [
            'user_id' => $userId, 'mobile' => $mobile, 'purpose' => $purpose,
            'code_hash' => self::hash($code), 'expires_at' => date('Y-m-d H:i:s', time() + $cfg['otp_ttl_seconds']),
            'attempts' => 0,
        ]);
        $send = Sms::otp($mobile, $code, $userId);
        if (session_status() === PHP_SESSION_ACTIVE) $_SESSION['_otp_send'] = $send;
        // در حالت نمایشی، کد برای نمایش روی صفحه نگه داشته می‌شود تا آزمایش محلی ساده باشد
        if (config('app')['demo_mode'] && session_status() === PHP_SESSION_ACTIVE) $_SESSION['_demo_otp'][$mobile] = $code;
        return $code;
    }
    public static function hash(string $code): string { return hash_hmac('sha256', $code, config('security')['hash_secret']); }
    public static function verify(string $mobile, string $code, string $purpose = 'register'): array
    {
        $cfg = config('security');
        $purpose = self::purpose($purpose);
        $row = Database::one('SELECT * FROM otp_codes WHERE mobile=? AND purpose=? AND used_at IS NULL ORDER BY id DESC LIMIT 1', [$mobile, $purpose]);
        if (!$row) return [false, 'کد تاییدی برای این شماره ثبت نشده است.'];
        if (strtotime($row['expires_at']) < time()) return [false, 'کد تایید منقضی شده است. کد جدید دریافت کنید.'];
        if ((int)$row['attempts'] >= $cfg['otp_max_attempts']) return [false, 'تعداد تلاش‌های ناموفق زیاد بود. کد جدید دریافت کنید.'];
        if (!hash_equals((string)$row['code_hash'], self::hash($code))) {
            Database::run('UPDATE otp_codes SET attempts=attempts+1 WHERE id=?', [$row['id']]);
            $left = max(0, $cfg['otp_max_attempts'] - (int)$row['attempts'] - 1);
            return [false, "کد وارد‌شده صحیح نیست. {$left} تلاش باقی مانده است."];
        }
        Database::run('UPDATE otp_codes SET used_at=NOW() WHERE id=?', [$row['id']]);
        return [true, $row];
    }
}

final class Sms
{
    /** تنظیمات مؤثر پیامک (config + متغیر محیطی + تنظیمات ذخیره‌شده در پنل) */
    public static function config(): array
    {
        $app = config('app');
        $k = $app['kavenegar'] ?? [];
        if (!is_array($k)) $k = [];
        $cfg = array_merge([
            'driver'       => $app['sms_driver'] ?? 'log',
            'base'         => 'https://api.kavenegar.com/v1',
            'api_key'      => '',
            'sender'       => '',
            'otp_template' => 'sendmelodi',
        ], $k);
        try {
            if (class_exists('Settings') && class_exists('Auth') && Auth::businessId()) {
                foreach (['api_key' => 'sms.kavenegar_api_key', 'otp_template' => 'sms.kavenegar_template', 'sender' => 'sms.kavenegar_sender'] as $key => $sk) {
                    $v = Settings::get($sk, null);
                    if ($v !== null && $v !== '') $cfg[$key] = (string)$v;
                }
                // درایور از پنل قابل تغییر است (log = فقط ثبت، kavenegar = ارسال واقعی)
                $drv = Settings::get('sms.kavenegar_driver', null);
                if ($drv !== null && $drv !== '') $cfg['driver'] = (string)$drv;
            }
        } catch (Throwable $e) { /* بدون دیتابیس، از config استفاده می‌شود */ }
        $env = getenv('KAVENEGAR_API_KEY');
        if ($env !== false && $env !== '') $cfg['api_key'] = $env;
        return $cfg;
    }

    /** ارسال کد تایید (ثبت‌نام/فراموشی رمز): در کاوه‌نگار با الگوی اعتبارسنجی (Lookup) */
    public static function otp(string $mobile, string $code, ?int $userId = null): array
    {
        $c = self::config();
        if ($c['driver'] === 'kavenegar' && $c['api_key'] !== '') {
            $res = self::lookup($mobile, $code);
            $res['channel'] = 'lookup';
            self::record($mobile, "کد تایید — الگوی «{$c['otp_template']}»", 'otp', $res);
            return $res;
        }
        self::send($mobile, "کد تایید فینتو: {$code}\nاین کد تا ۵ دقیقه اعتبار دارد.", $userId, 'otp');
        return ['ok' => true, 'channel' => 'log', 'message' => 'در حالت log ثبت شد'];
    }

    /** ارسال پیامک متن آزاد */
    public static function send(string $mobile, string $body, ?int $personOrUserId = null, string $entityType = 'otp', ?string $recipientName = null): bool
    {
        $c = self::config();
        $res = ['ok' => true, 'message' => 'logged'];
        if ($c['driver'] === 'kavenegar' && $c['api_key'] !== '') {
            $q = ['receptor' => self::mobile($mobile), 'message' => $body];
            if ($c['sender'] !== '') $q['sender'] = $c['sender'];
            $res = self::call('/sms/send.json', $q);
        }
        self::record($mobile, $body, $entityType, $res);
        return (bool)($res['ok'] ?? false);
    }

    /** فراخوانی متود Lookup کاوه‌نگار: /verify/lookup.json */
    public static function lookup(string $mobile, string $token, string $token2 = '', string $token3 = ''): array
    {
        $c = self::config();
        $q = ['receptor' => self::mobile($mobile), 'token' => $token, 'template' => $c['otp_template']];
        if ($token2 !== '') $q['token2'] = $token2;
        if ($token3 !== '') $q['token3'] = $token3;
        return self::call('/verify/lookup.json', $q);
    }

    /** آزمون اتصال به کاوه‌نگار با متود getdate */
    public static function test(): array
    {
        $c = self::config();
        $out = ['ok' => false, 'error' => 'کلید API تنظیم نشده است.', 'server_ip' => self::outboundIp(),
                'driver' => $c['driver'], 'template' => $c['otp_template']];
        if ($c['api_key'] === '') return $out;
        $r = self::call('/utils/getdate.json', []);
        $r['server_ip'] = self::outboundIp();
        $r['driver'] = $c['driver'];
        $r['template'] = $c['otp_template'];
        return $r;
    }

    /** IP عمومی این سرور (برای افزودن به لیست مجاز پنل کاوه‌نگار) — با کش یک‌ساعته */
    public static function outboundIp(): string
    {
        $cache = storage_path('sms_ip.txt');
        if (is_file($cache) && (time() - (int)@filemtime($cache)) < 3600) {
            $v = trim((string)@file_get_contents($cache));
            if (preg_match('/^\d+\.\d+\.\d+\.\d+$/', $v)) return $v;
        }
        $ip = '';
        if (function_exists('curl_init')) {
            $ch = curl_init('https://api.ipify.org');
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 8, CURLOPT_CONNECTTIMEOUT => 5]);
            $ip = trim((string)curl_exec($ch));
        }
        if (!preg_match('/^\d+\.\d+\.\d+\.\d+$/', $ip)) return '';
        @file_put_contents($cache, $ip);
        return $ip;
    }

    /** ارسال پیامک آزمایشی به شمارهٔ دلخواه (برای بررسی پنل) */
    public static function sendTest(string $mobile, ?string $body = null): array
    {
        $c = self::config();
        if ($c['api_key'] === '') return ['ok' => false, 'error' => 'کلید API تنظیم نشده است.'];
        $m = self::mobile($mobile);
        if (!preg_match('/^09\d{9}$/', $m)) return ['ok' => false, 'error' => 'شمارهٔ موبایل معتبر نیست.'];
        $text = $body !== null && trim($body) !== '' ? trim($body) : 'پیام آزمایشی فینتو — اتصال کاوه‌نگار برقرار است.';
        $res = self::call('/sms/send.json', array_filter(['receptor' => $m, 'message' => $text, 'sender' => $c['sender'] ?: null]));
        $res['channel'] = 'send';
        self::record($m, $text, 'test', $res);
        return $res;
    }

    /** یکسان‌سازی شمارهٔ موبایل به قالب 09xxxxxxxxx */
    private static function mobile(string $m): string
    {
        $m = preg_replace('/\D+/', '', $m);
        if (str_starts_with($m, '98') && strlen($m) >= 12) $m = '0' . substr($m, 2);
        if (strlen($m) === 10 && str_starts_with($m, '9')) $m = '0' . $m;
        return $m;
    }

    /** درخواست HTTPS به کاوه‌نگار و تفسیر پاسخ */
    private static function call(string $path, array $q): array
    {
        $c = self::config();
        if ($c['api_key'] === '') return ['ok' => false, 'error' => 'کلید API کاوه‌نگار تنظیم نشده است.'];
        if (!function_exists('curl_init')) return ['ok' => false, 'error' => 'افزونهٔ curl در دسترس نیست.'];
        $url = rtrim((string)$c['base'], '/') . '/' . rawurlencode((string)$c['api_key']) . $path . ($q ? ('?' . http_build_query($q)) : '');
        $ch = curl_init($url);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25, CURLOPT_CONNECTTIMEOUT => 12]);
        $raw = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($raw === false) return ['ok' => false, 'error' => $err ?: 'اتصال به کاوه‌نگار برقرار نشد.'];
        $j = json_decode((string)$raw, true);
        $st = (int)($j['return']['status'] ?? $code);
        $msg = (string)($j['return']['message'] ?? '');
        $ipErr = ($st === 407) || str_contains($msg, 'IP') || str_contains($msg, 'آی‌پی') || str_contains($msg, 'لیست');
        $ent = $j['entries'] ?? null;
        return [
            'ok' => $st === 200, 'status' => $st, 'message' => $msg,
            'ip_restricted' => $ipErr && $st !== 200,
            'entry' => is_array($ent) && isset($ent[0]) ? $ent[0] : $ent,
        ];
    }

    /** ثبت در جدول messages + لاگ فایل */
    private static function record(string $mobile, string $body, string $entityType, array $res): void
    {
        $c = self::config();
        $ref = is_array($res['entry'] ?? null) ? (string)($res['entry']['messageid'] ?? '') : '';
        try {
            $bizId = Auth::businessId() ?: 1;
            Database::insert('messages', [
                'business_id' => $bizId, 'channel' => 'sms', 'recipient' => $mobile, 'body' => $body,
                'entity_type' => $entityType,
                'status' => !empty($res['ok']) ? 'sent' : 'failed',
                'provider' => $c['driver'], 'provider_ref' => $ref,
                'error_message' => empty($res['ok']) ? mb_substr((string)($res['error'] ?? $res['message'] ?? ''), 0, 280) : null,
                'sent_at' => now(), 'created_at' => now(), 'cost_amount' => 800,
            ]);
        } catch (Throwable $e) { /* ثبت پیامک نباید جریان اصلی را متوقف کند */ }
        $meta = array_intersect_key($res, array_flip(['ok', 'status', 'message', 'error', 'ip_restricted', 'channel']));
        @file_put_contents(storage_path('sms.log'), date('c') . " | {$mobile} | " . str_replace("\n", ' ', $body) . ' | ' . json_encode($meta, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND);
    }
}

final class Sequence
{
    /** نگاشت نوع سند داخلی به مقادیر مجاز ستون number_sequences.doc_type */
    public static function docType(string $docType): string
    {
        $allowed = ['sale','buy','sale_return','buy_return','quote','receipt','payment','cheque','journal','hr','voucher','transfer','waste','count'];
        if (in_array($docType, $allowed, true)) return $docType;
        return match ($docType) {
            'expense', 'income', 'expenses', 'incomes' => 'voucher',
            'payroll' => 'hr',
            'stock_count', 'stock-count' => 'count',
            'stock_transfer' => 'transfer',
            default => 'voucher',
        };
    }

    /** بزرگ‌ترین شمارهٔ سند ثبت‌شده در یک سال مالی (برای جلوگیری از تکرار شماره هنگام بازنشانی سری) */
    private static function maxDocNumber(int $businessId, ?int $fiscalYearId, string $docType): int
    {
        $map = [
            'journal' => ['journal_entries', 'entry_no'],
            'receipt' => ['receipts', 'doc_no'],
            'payment' => ['payments', 'doc_no'],
            'cheque'  => ['cheques', 'cheque_no'],
            'hr'      => ['payroll_documents', 'doc_no'],
            'transfer' => ['transfers', 'doc_no'],
            'waste'   => ['inventory_documents', 'doc_no'],
            'count'   => ['stock_counts', 'doc_no'],
            'voucher' => ['expense_documents', 'doc_no'],
        ];
        if (in_array($docType, ['sale', 'buy', 'sale_return', 'buy_return', 'quote'], true)) $map[$docType] = ['invoices', 'invoice_no'];
        $m = $map[$docType] ?? null;
        if ($m === null) return 0;
        static $memo = [];
        $mk = $businessId . '|' . ($fiscalYearId ?? 0) . '|' . $docType;
        if (isset($memo[$mk])) return $memo[$mk];
        $memo[$mk] = 0;
        [$table, $col] = $m;
        try {
            $where = 'business_id=? AND (fiscal_year_id <=> ?)';
            $pr = [$businessId, $fiscalYearId];
            if ($table === 'invoices') { $where .= ' AND invoice_type=?'; $pr[] = $docType; }
            $v = $col === 'entry_no'
                ? (int)Database::val("SELECT MAX(entry_no) FROM `$table` WHERE $where", $pr, 0)
                : (int)Database::val("SELECT MAX(CAST(REGEXP_SUBSTR(`$col`, '[0-9]+$') AS UNSIGNED)) FROM `$table` WHERE $where AND `$col` REGEXP '[0-9]+$'", $pr, 0);
            return $memo[$mk] = $v;
        } catch (Throwable $e) { return $memo[$mk] = 0; }
    }

    /** ردیف توالی این نوع سند و سال مالی؛ در صورت نبود می‌سازد (با پشتیبانی «بازنشانی سالانه») */
    public static function row(int $businessId, ?int $fiscalYearId, string $docType, bool $create = true): array
    {
        $docType = self::docType($docType);
        $row = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? AND (fiscal_year_id <=> ?) ORDER BY id LIMIT 1',
            [$businessId, $docType, $fiscalYearId]);
        if ($row) {
            // خودترمیمی: اگر شمارهٔ بعدی از بزرگ‌ترین شمارهٔ ثبت‌شدهٔ همان سال عقب‌تر باشد،
            // برای جلوگیری از شمارهٔ تکراری، سری از ادامهٔ اسناد موجود تنظیم می‌شود.
            if ((int)($row['reset_yearly'] ?? 0) === 1) {
                $max = self::maxDocNumber($businessId, $fiscalYearId, $docType);
                if ($max > 0 && (int)$row['next_value'] <= $max) {
                    $row['next_value'] = $max + 1;
                    Database::run('UPDATE number_sequences SET next_value=? WHERE id=?', [$max + 1, (int)$row['id']]);
                }
            }
            return $row;
        }
        $base = Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? ORDER BY id DESC LIMIT 1', [$businessId, $docType]);
        if (!$create) return $base ?: [];
        // «بازنشانی سالانه»: سال مالی جدید → سری از ۱ آغاز می‌شود، مگر آنکه در همان سال سندی ثبت شده باشد
        // (برای جلوگیری از تکرار شماره، از بزرگ‌ترین شمارهٔ موجود همان سال ادامه می‌دهیم)
        $reset = $base ? ((int)($base['reset_yearly'] ?? 1) === 1) : true;
        $start = ($base && !$reset) ? (int)$base['next_value'] : 1;
        if ($reset) {
            $max = self::maxDocNumber($businessId, $fiscalYearId, $docType);
            if ($max > 0) $start = $max + 1;
        }
        $tpl = $base['template'] ?? (strtoupper(substr($docType, 0, 3)) . '-{FY}-{SEQ}');
        Database::insert('number_sequences', ['business_id' => $businessId, 'fiscal_year_id' => $fiscalYearId, 'doc_type' => $docType,
            'template' => $tpl, 'next_value' => $start,
            'step' => (int)($base['step'] ?? 1) ?: 1, 'reset_yearly' => $reset ? 1 : 0, 'created_at' => now()]);
        return Database::one('SELECT * FROM number_sequences WHERE business_id=? AND doc_type=? AND (fiscal_year_id <=> ?) ORDER BY id DESC LIMIT 1',
            [$businessId, $docType, $fiscalYearId]) ?: [];
    }

    /** شماره سند بعدی بر اساس number_sequences */
    public static function next(int $businessId, ?int $fiscalYearId, string $docType, array $ctx = []): string
    {
        $docType = self::docType($docType);
        $row = self::row($businessId, $fiscalYearId, $docType);
        if (!$row) {
            $prefix = strtoupper(substr($docType, 0, 3));
            $tpl = $ctx['prefix'] ?? $prefix;
            return str_replace(['{FY}', '{SEQ}', '{YYYY}'], [current_jalali_year(), '0001', date('Y')], $tpl . '-{FY}-{SEQ}');
        }
        // قالب اختصاصی ارسالی روی ردیف ذخیره می‌شود تا در ادامه هم به کار رود
        if (!empty($ctx['template']) && $ctx['template'] !== $row['template']) {
            Database::run('UPDATE number_sequences SET template=? WHERE id=?', [(string)$ctx['template'], $row['id']]);
        }
        $seq = (int)$row['next_value'];
        Database::run('UPDATE number_sequences SET next_value = next_value + ? WHERE id=?', [(int)($row['step'] ?: 1), $row['id']]);
        $fy = $ctx['fy'] ?? current_jalali_year();
        // قالب اختصاصی (مثلاً EXP/INC برای اسناد هزینه و درآمد که سری شماره مشترک دارند)
        $tpl = $ctx['template'] ?? $row['template'];
        return str_replace(['{FY}', '{SEQ}', '{YYYY}'], [$fy, str_pad((string)$seq, 4, '0', STR_PAD_LEFT), date('Y')], $tpl);
    }

    /** شماره عددی خالص (برای ستون‌های عددی مثل journal_entries.entry_no) */
    public static function nextNumber(int $businessId, ?int $fiscalYearId, string $docType): int
    {
        $row = self::row($businessId, $fiscalYearId, self::docType($docType));
        $seq = (int)($row['next_value'] ?? 1);
        if ($row) Database::run('UPDATE number_sequences SET next_value = next_value + ? WHERE id=?', [(int)($row['step'] ?: 1), $row['id']]);
        return $seq;
    }

    public static function peekNumber(int $businessId, ?int $fiscalYearId, string $docType): int
    {
        $row = self::row($businessId, $fiscalYearId, self::docType($docType), false);
        return (int)($row['next_value'] ?? 1);
    }

    /** پیش‌نمایش شمارهٔ بعدی بدون مصرف کردن آن */
    public static function peek(int $businessId, ?int $fiscalYearId, string $docType): string
    {
        $row = self::row($businessId, $fiscalYearId, self::docType($docType), false);
        $seq = (int)($row['next_value'] ?? 1);
        $tpl = $row['template'] ?? 'DOC-{FY}-{SEQ}';
        $fyId = (int)($row['fiscal_year_id'] ?? 0);
        $jalali = $fyId ? (string)Database::val('SELECT title FROM fiscal_years WHERE id=?', [$fyId], (string)current_jalali_year()) : (string)current_jalali_year();
        return str_replace(['{FY}', '{SEQ}', '{YYYY}'], [$jalali, str_pad((string)$seq, 4, '0', STR_PAD_LEFT), date('Y')], $tpl);
    }
}

final class Audit
{
    public static function log(string $action, ?string $entityType = null, ?int $entityId = null, ?string $description = null, ?array $payload = null): void
    {
        $uid = Auth::id();
        // مقادیر مجاز ستون device_type در دیتابیس: web | mobile | api | panel
        $device = preg_match('/Mobile|Android|iPhone|iPad/i', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')) ? 'mobile' : 'web';
        $row = [
            'business_id' => Auth::businessId(), 'user_id' => $uid, 'action' => $action,
            'entity_type' => $entityType, 'entity_id' => $entityId,
            'after_json' => json_encode(array_filter(['description' => $description, 'payload' => $payload], fn($v) => $v !== null && $v !== []), JSON_UNESCAPED_UNICODE),
            'ip_address' => inet_pton($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0') ?: null,
            'user_agent' => substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 250),
            'device_type' => $device,
            'created_at' => now(),
        ];
        try {
            Database::insert('audit_logs', $row);
        } catch (Throwable $e) {
            // پشتیبان برای نصب‌های قدیمی که ستون action هنوز ENUM بسته است
            try {
                $allowed = ['insert','update','delete','login','logout','print','send','submit','cancel','lock','unlock','export'];
                if (!in_array($action, $allowed, true)) {
                    $row['action'] = 'update';
                    $row['after_json'] = json_encode(array_filter(['action' => $action, 'description' => $description, 'payload' => $payload],
                        fn($v) => $v !== null && $v !== []), JSON_UNESCAPED_UNICODE);
                    Database::insert('audit_logs', $row);
                }
            } catch (Throwable $e2) { }
        }
    }
    public static function track(string $table, int $id, array $new, array $old = []): void
    {
        $changes = [];
        foreach ($new as $k => $v) if (!array_key_exists($k, $old) || (string)$old[$k] !== (string)$v) $changes[$k] = $v;
        if ($changes) self::log($old ? 'update' : 'create', $table, $id, ($old ? 'ویرایش ' : 'ایجاد ').$table, ['changes' => $changes]);
    }
}

/**
 * اشتراک و پکیج‌ها: وضعیت فعال/منقضی کسب‌وکار + امکانات پکیج
 */
final class Billing
{
    /** امکانات نرم‌افزار (برای صفحهٔ پکیج‌ها) — عدد دار‌ها «نامحدود» نمایش داده می‌شوند */
    public const FEATURES = [
        ['icon' => '🧾', 'title' => 'فاکتور خرید و فروش', 'hint' => 'نامحدود فاکتور و ردیف'],
        ['icon' => '📚', 'title' => 'حسابداری و اسناد', 'hint' => 'نامحدود سند، دفتر روزنامه و کل'],
        ['icon' => '🏬', 'title' => 'انبارداری و موجودی', 'hint' => 'نامحدود کالا، انبار و سند انبار'],
        ['icon' => '🏦', 'title' => 'بانکداری و چک', 'hint' => 'نامحدود حساب، چک و صورت‌حساب'],
        ['icon' => '💰', 'title' => 'تنخواه گردان', 'hint' => 'نامحدود تنخواه و ریز عملیات'],
        ['icon' => '👥', 'title' => 'حقوق و دستمزد و قرارداد', 'hint' => 'نامحدود پرسنل، قرارداد و سند حقوق'],
        ['icon' => '📊', 'title' => 'گزارشات جامع و تحلیل', 'hint' => 'تراز، سود و زیان، جریان نقدی و …'],
        ['icon' => '🧑‍💼', 'title' => 'چند کاربر و سطوح دسترسی', 'hint' => 'نامحدود کاربر و نقش'],
        ['icon' => '☁️', 'title' => 'پشتیبان‌گیری و بازیابی', 'hint' => 'نامحدود پشتیبان'],
        ['icon' => '🎧', 'title' => 'پشتیبانی ویژه', 'hint' => 'پاسخگویی سریع کاربران طلایی'],
    ];

    /** اشتراک فعال کسب‌وکار (اگر داشته باشد) */
    public static function activeSubscription(?int $bizId = null): ?array
    {
        $biz = $bizId ?: (int)Auth::businessId();
        if (!$biz) return null;
        return Database::one("SELECT s.*, p.title AS plan_title, p.price_amount, p.duration_months, p.max_users, p.sms_credits
                                FROM subscriptions s JOIN plans p ON p.id = s.plan_id
                               WHERE s.business_id = ? AND s.is_active = 1 AND s.status IN ('active','trial')
                                 AND s.expires_at >= CURDATE()
                               ORDER BY s.expires_at DESC, s.id DESC LIMIT 1", [$biz]);
    }

    /** آخرین اشتراک (فعال یا منقضی) */
    public static function lastSubscription(?int $bizId = null): ?array
    {
        $biz = $bizId ?: (int)Auth::businessId();
        if (!$biz) return null;
        return Database::one("SELECT s.*, p.title AS plan_title FROM subscriptions s JOIN plans p ON p.id = s.plan_id
                               WHERE s.business_id=? ORDER BY s.id DESC LIMIT 1", [$biz]);
    }

    /** وضعیت دسترسی: فعال / منقضی / بدون اشتراک */
    public static function state(?int $bizId = null): array
    {
        $sub = self::activeSubscription($bizId);
        $unlocked = self::unlocked($bizId);          // پرچم بازگشایی (آزمون/پشتیبانی)
        $last = self::lastSubscription($bizId);
        $isActive = $sub !== null || $unlocked;
        $expired = !$isActive && $last !== null;
        return ['is_active' => $isActive, 'unlocked' => $unlocked, 'subscription' => $sub, 'last' => $last,
            'expired' => $expired, 'never' => $sub === null && $last === null,
            'expires_at' => $sub['expires_at'] ?? ($last['expires_at'] ?? null),
            'plan_title' => $sub['plan_title'] ?? ($last['plan_title'] ?? ''),
            'days_left' => $sub ? (int)floor((strtotime((string)$sub['expires_at']) - strtotime(today())) / 86400) : 0];
    }

    /**
     * فعال بودن اشتراک کسب‌وکار.
     * نکته: اگر فایل storage/billing_unlock.flag شامل شناسهٔ کسب‌وکار باشد، قفل برای آن باز است
     * (برای آزمون‌های خودکار و پشتیبانی؛ در بستهٔ نصب وجود ندارد).
     */
    public static function isActive(?int $bizId = null): bool
    {
        $biz = $bizId ?: (int)Auth::businessId();
        if (self::unlocked($biz)) return true;
        return self::activeSubscription($biz) !== null;
    }

    /** فعال‌سازی اشتراک آزمایشی برای یک کسب‌وکار (روز) */
    public static function grantTrial(int $bizId, int $days = 14): ?int
    {
        if ($bizId <= 0) return null;
        if (self::activeSubscription($bizId)) return null;          // از قبل فعال است
        $planId = (int)Database::val('SELECT id FROM plans WHERE is_active=1 ORDER BY duration_months, id LIMIT 1', [], 0);
        if (!$planId) return null;
        $subId = (int)Database::insert('subscriptions', ['business_id' => $bizId, 'plan_id' => $planId, 'starts_at' => today(),
            'expires_at' => date('Y-m-d', strtotime('+' . max(1, $days) . ' days')), 'status' => 'trial',
            'documents_used' => 0, 'documents_limit' => 0, 'auto_renew' => 0, 'is_active' => 1,
            'created_at' => now(), 'created_by' => Auth::id() ?: null]);
        return $subId;
    }

    /** کسب‌وکارهای بازگشایی‌شده (از فایل موقت) */
    public static function unlocked(?int $bizId = null): bool
    {
        $biz = (int)($bizId ?: Auth::businessId());
        $f = storage_path('billing_unlock.flag');
        if (!$biz || !is_file($f)) return false;
        $raw = trim((string)@file_get_contents($f));
        if ($raw === '' ) return false;
        if ($raw === '*') return true;                                   // همهٔ کسب‌وکارها (اجرای آزمون‌ها)
        $ids = array_filter(array_map('intval', preg_split('/[\s,]+/', $raw)));
        return in_array($biz, $ids, true);
    }
}

final class Settings
{
    private static array $cache = [];
    public static function all(?int $businessId = null): array
    {
        $bid = $businessId ?: (Auth::businessId() ?: 0);
        if (isset(self::$cache[$bid])) return self::$cache[$bid];
        $out = [];
        foreach (Database::all('SELECT setting_key, value_json FROM settings WHERE business_id=?', [$bid]) as $r) {
            $v = $r['value_json'];
            $decoded = json_decode((string)$v, true);
            $out[$r['setting_key']] = json_last_error() === JSON_ERROR_NONE ? $decoded : $v;
        }
        return self::$cache[$bid] = $out;
    }
    public static function get(string $key, $default = null, ?int $businessId = null)
    {
        $all = self::all($businessId);
        return array_key_exists($key, $all) ? $all[$key] : $default;
    }
    /** پاک‌کردن کش تنظیمات (پس از تغییر بیرونی یا بین درخواست‌ها) */
    public static function flush(): void { self::$cache = []; }
    public static function set(int $businessId, string $key, $value): void
    {
        $json = json_encode($value, JSON_UNESCAPED_UNICODE);
        // value_type فقط مقادیر مجاز enum را می‌پذیرد: bool|int|decimal|string|json|date
        $type = is_bool($value) ? 'bool'
            : (is_int($value) ? 'int'
            : (is_float($value) || (is_string($value) && is_numeric($value) && str_contains($value, '.')) ? 'decimal'
            : (is_array($value) ? 'json'
            : ((is_string($value) && preg_match('/^\d{4}-\d{2}-\d{2}/', $value)) ? 'date' : 'string'))));
        $row = Database::one('SELECT id FROM settings WHERE business_id=? AND setting_key=?', [$businessId, $key]);
        if ($row) Database::run('UPDATE settings SET value_json=?, value_type=? WHERE id=?', [$json, $type, $row['id']]);
        else {
            $prefix = explode('.', $key)[0];
            $category = in_array($prefix, ['financial','printing','hr','sms','backup','technical','access','moadian'], true) ? $prefix : 'technical';
            Database::insert('settings', ['business_id' => $businessId, 'category' => $category, 'setting_key' => $key, 'value_json' => $json,
                'value_type' => $type, 'title_fa' => $key, 'group_fa' => 'سایر', 'created_at' => now()]);
        }
        self::$cache = [];
    }
}

function storage_path(string $p = ''): string { return __DIR__.'/../storage/'.ltrim($p, '/'); }
