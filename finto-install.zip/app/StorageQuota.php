<?php
/**
 * سهمیهٔ فضای ذخیره‌سازی اسناد شخصی (user_documents).
 *  • هر کاربر (مدیر یا عادی) به‌صورت پیش‌فرض ۱ گیگابایت فضا دارد.
 *  • می‌تواند فضای اضافه (۱ تا ۱۰ گیگ) جدا از پکیج اشتراک بخرد.
 *  • سهمیه سراسری است (جمع همهٔ کسب‌وکارهای همان کاربر).
 */
final class StorageQuota
{
    public const BASE_GB = 1;                            // گیگ پایه
    public const PRICE_PER_GB = 300000;                  // تومان — قیمت هر گیگ اضافه
    public const MAX_PURCHASE_GB = 10;                   // حداکثر خرید در هر بار

    public static function baseBytes(): int { return self::BASE_GB * 1024 * 1024 * 1024; }
    public static function gbBytes(int $gb): int { return $gb * 1024 * 1024 * 1024; }

    /** حجم مصرف‌شدهٔ کاربر (جمع همهٔ اسناد غیرحذف‌شده) */
    public static function usedBytes(int $userId): int
    {
        return (int)Database::val('SELECT IFNULL(SUM(size_bytes),0) FROM user_documents WHERE user_id=? AND deleted_at IS NULL', [$userId], 0);
    }

    /** حجم خریداری‌شده (فقط پرداخت‌های موفق) */
    public static function purchasedBytes(int $userId): int
    {
        $gb = (int)Database::val('SELECT IFNULL(SUM(gigabytes),0) FROM storage_purchases WHERE user_id=? AND status="paid"', [$userId], 0);
        return self::gbBytes($gb);
    }

    /** سهمیهٔ کل کاربر */
    public static function quotaBytes(int $userId): int
    {
        return self::baseBytes() + self::purchasedBytes($userId);
    }

    /** فضای باقی‌مانده */
    public static function remainingBytes(int $userId): int
    {
        return max(0, self::quotaBytes($userId) - self::usedBytes($userId));
    }

    /** آیا امکان آپلود این حجم هست؟ */
    public static function canUpload(int $size, int $userId): bool
    {
        return self::remainingBytes($userId) >= $size;
    }

    /** گیگابایت خریداری‌شده (برای نمایش) */
    public static function purchasedGb(int $userId): int
    {
        return (int)Database::val('SELECT IFNULL(SUM(gigabytes),0) FROM storage_purchases WHERE user_id=? AND status="paid"', [$userId], 0);
    }

    /** نمایش خوانا */
    public static function human(int $bytes): string
    {
        $mb = $bytes / 1024 / 1024;
        if ($mb < 1024) return num($mb, 1) . ' مگابایت';
        return num($mb / 1024, 2) . ' گیگابایت';
    }

    /** ثبت خرید فضای اضافه */
    public static function purchase(int $gigabytes): int
    {
        $gigabytes = max(1, min(self::MAX_PURCHASE_GB, $gigabytes));
        $biz = (int)Auth::businessId();
        $uid = (int)Auth::id();
        $amount = $gigabytes * self::PRICE_PER_GB;
        $id = (int)Database::insert('storage_purchases', [
            'business_id' => $biz, 'user_id' => $uid, 'gigabytes' => $gigabytes,
            'unit_price' => self::PRICE_PER_GB, 'amount' => $amount, 'payable_amount' => $amount,
            'payment_gateway' => 'internal', 'gateway_ref' => 'STG-' . strtoupper(bin2hex(random_bytes(4))),
            'status' => 'paid', 'paid_at' => now(), 'created_at' => now(), 'created_by' => $uid,
        ]);
        Audit::log('purchase', 'storage_purchases', $id, 'خرید ' . $gigabytes . ' گیگ فضای ذخیره‌سازی (' . $amount . ' تومان)');
        return $id;
    }

    /** تاریخچهٔ خریدهای کاربر */
    public static function history(int $userId, int $limit = 20): array
    {
        return Database::all('SELECT * FROM storage_purchases WHERE user_id=? ORDER BY id DESC LIMIT ' . max(1, min(100, $limit)), [$userId]);
    }
}
