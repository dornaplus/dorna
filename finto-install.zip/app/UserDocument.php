<?php
/**
 * اسناد شخصی کاربران (مدیریت اسناد).
 *  • هر کاربر سندهای خودش را دارد؛ مدیر سیستم همهٔ سندها را می‌بیند و بدون رمز باز می‌کند.
 *  • فایل‌ها به‌صورت رمزگذاری‌شده (AES-256-CBC با کلید سرور) روی دیسک ذخیره می‌شوند.
 *  • هر سند می‌تواند رمز بازگشایی داشته باشد؛ رمز فقط برای مالک لازم است (مدیر معاف است).
 *  • جستجو، مرتب‌سازی و فیلتر بر اساس پسوند، حجم و تاریخ.
 */
final class UserDocument
{
    public const MAX_SIZE = 52428800;   // ۵۰ مگابایت
    public const BASE = 'user-documents';

    /** کلید اصلی رمزنگاری (برگرفته از secret سرور) — مدیر سیستم همیشه می‌تواند باز کند */
    public static function masterKey(): string
    {
        return hash('sha256', (string)config('security')['hash_secret'] . '|finto-user-docs', true);
    }

    public static function dir(int $userId): string
    {
        return storage_path(self::BASE . '/' . max(1, $userId));
    }

    public static function path(array $d): string
    {
        return storage_path(self::BASE . '/' . ltrim((string)$d['storage_key'], '/'));
    }

    /** آیا کاربر جاری می‌تواند این سند را ببیند؟ (مالک یا مدیر) */
    public static function canAccess(array $d): bool
    {
        return (int)($d['user_id'] ?? 0) === (int)Auth::id() || Auth::isAdmin();
    }

    /** آیا برای باز کردن، رمز لازم است؟ */
    public static function locked(array $d): bool
    {
        return (int)($d['is_encrypted'] ?? 0) === 1 && !empty($d['password_hash']);
    }

    public static function one(int $id): ?array
    {
        $d = Database::one('SELECT d.*, u.full_name AS owner_name, u.avatar_path AS owner_avatar
                              FROM user_documents d LEFT JOIN users u ON u.id = d.user_id
                             WHERE d.id = ? AND d.deleted_at IS NULL', [$id]);
        if (!$d || !self::canAccess($d)) return null;
        return $d;
    }

    /** نمایش خوانای حجم */
    public static function humanSize($bytes): string
    {
        $b = (float)$bytes;
        if ($b < 1024) return num($b, 0) . ' بایت';
        $kb = $b / 1024;
        if ($kb < 1024) return num($kb, 1) . ' کیلوبایت';
        $mb = $kb / 1024;
        if ($mb < 1024) return num($mb, 1) . ' مگابایت';
        return num($mb / 1024, 2) . ' گیگابایت';
    }

    /** آیکون و برچسب بر اساس پسوند */
    public static function kind(string $ext): array
    {
        $ext = strtolower($ext);
        return match (true) {
            in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'], true) => ['image', 'تصویر'],
            $ext === 'pdf' => ['file', 'PDF'],
            in_array($ext, ['doc', 'docx'], true) => ['file', 'Word'],
            in_array($ext, ['xls', 'xlsx', 'csv'], true) => ['chart', 'Excel'],
            in_array($ext, ['ppt', 'pptx'], true) => ['file', 'پاورپوینت'],
            in_array($ext, ['zip', 'rar', '7z', 'tar', 'gz'], true) => ['download', 'آرشیو'],
            in_array($ext, ['mp3', 'wav', 'ogg', 'mp4', 'mov', 'avi', 'mkv'], true) => ['file', 'رسانه'],
            in_array($ext, ['txt', 'md', 'log'], true) => ['file', 'متن'],
            $ext === 'json' || $ext === 'xml' => ['file', 'کد'],
            default => ['file', strtoupper($ext ?: 'فایل')],
        };
    }

    /** پسوندهای موجود (برای فیلتر) */
    public static function distinctExts(): array
    {
        $biz = (int)Auth::businessId();
        $admin = Auth::isAdmin();
        $sql = "SELECT DISTINCT d.ext FROM user_documents d WHERE d.business_id = ? AND d.deleted_at IS NULL AND d.ext IS NOT NULL";
        $pr = [$biz];
        if (!$admin) { $sql .= ' AND d.user_id = ?'; $pr[] = (int)Auth::id(); }
        $sql .= ' ORDER BY d.ext';
        return array_values(array_filter(array_map(fn($r) => strtolower((string)$r['ext']), Database::all($sql, $pr))));
    }

    /** فهرست سندها با جستجو/فیلتر/مرتب‌سازی */
    public static function list(array $f = []): array
    {
        $biz = (int)Auth::businessId();
        $admin = Auth::isAdmin();
        $uid = (int)Auth::id();

        $sql = "SELECT d.*, u.full_name AS owner_name, u.avatar_path AS owner_avatar
                  FROM user_documents d LEFT JOIN users u ON u.id = d.user_id
                 WHERE d.business_id = ? AND d.deleted_at IS NULL";
        $pr = [$biz];

        if (!$admin) { $sql .= ' AND d.user_id = ?'; $pr[] = $uid; }
        if ($admin && !empty($f['user_id'])) { $sql .= ' AND d.user_id = ?'; $pr[] = (int)$f['user_id']; }

        $q = trim((string)($f['q'] ?? ''));
        if ($q !== '') {
            $sql .= ' AND (d.title LIKE ? OR d.description LIKE ? OR d.file_name LIKE ?)';
            $like = '%' . $q . '%'; array_push($pr, $like, $like, $like);
        }

        $ext = strtolower(trim((string)($f['ext'] ?? '')));
        if ($ext !== '') { $sql .= ' AND LOWER(d.ext) = ?'; $pr[] = $ext; }

        if (!empty($f['from'])) { $sql .= ' AND d.created_at >= ?'; $pr[] = to_gregorian((string)$f['from']) . ' 00:00:00'; }
        if (!empty($f['to']))   { $sql .= ' AND d.created_at <= ?'; $pr[] = to_gregorian((string)$f['to']) . ' 23:59:59'; }

        // فیلتر حجم
        $size = (string)($f['size'] ?? '');
        if ($size === 'small') { $sql .= ' AND d.size_bytes < 1048576'; }
        elseif ($size === 'medium') { $sql .= ' AND d.size_bytes >= 1048576 AND d.size_bytes < 10485760'; }
        elseif ($size === 'large') { $sql .= ' AND d.size_bytes >= 10485760'; }

        // وضعیت رمز
        $locked = (string)($f['locked'] ?? '');
        if ($locked === 'yes') { $sql .= ' AND d.is_encrypted = 1'; }
        elseif ($locked === 'no') { $sql .= ' AND d.is_encrypted = 0'; }

        $sort = (string)($f['sort'] ?? 'created_desc');
        $order = match ($sort) {
            'created_asc' => 'd.created_at ASC',
            'size_desc' => 'd.size_bytes DESC',
            'size_asc' => 'd.size_bytes ASC',
            'title_asc' => 'd.title ASC',
            'ext_asc' => 'd.ext ASC',
            default => 'd.created_at DESC',
        };
        $sql .= ' ORDER BY ' . $order . ', d.id DESC LIMIT 500';
        return Database::all($sql, $pr);
    }

    /** آمار (برای مدیر: تعداد کل / حجم کل) */
    public static function stats(): array
    {
        $biz = (int)Auth::businessId();
        $admin = Auth::isAdmin();
        $uid = (int)Auth::id();
        $w = 'business_id = ? AND deleted_at IS NULL' . ($admin ? '' : ' AND user_id = ?');
        $pr = $admin ? [$biz] : [$biz, $uid];
        $count = (int)Database::val("SELECT COUNT(*) FROM user_documents WHERE $w", $pr, 0);
        $bytes = (int)Database::val("SELECT IFNULL(SUM(size_bytes),0) FROM user_documents WHERE $w", $pr, 0);
        $lockedCount = (int)Database::val("SELECT COUNT(*) FROM user_documents WHERE $w AND is_encrypted=1", $pr, 0);
        return ['count' => $count, 'bytes' => $bytes, 'locked' => $lockedCount];
    }

    /**
     * ذخیرهٔ سند (آپلود + رمزگذاری اختیاری).
     * @return int شناسهٔ سند
     */
    public static function store(string $title, string $description, array $file, ?string $password): int
    {
        $biz = (int)Auth::businessId();
        $uid = (int)Auth::id();
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
        if ($err === UPLOAD_ERR_NO_FILE) throw new RuntimeException('فایلی انتخاب نشده است.');
        if ($err !== UPLOAD_ERR_OK) throw new RuntimeException('آپلود ناموفق بود (کد ' . $err . ').');
        if ((int)($file['size'] ?? 0) > self::MAX_SIZE) throw new RuntimeException('حجم فایل باید کمتر از ۵۰ مگابایت باشد.');
        if (!is_uploaded_file((string)($file['tmp_name'] ?? ''))) throw new RuntimeException('فایل نامعتبر است.');
        // سهمیهٔ فضای ذخیره‌سازی کاربر (۱ گیگ پایه + خرید اضافه)
        $size = (int)($file['size'] ?? 0);
        if (!StorageQuota::canUpload($size, $uid)) {
            $rem = StorageQuota::human(StorageQuota::remainingBytes($uid));
            throw new RuntimeException('فضای ذخیره‌سازی شما پر است (فقط ' . $rem . ' باقی مانده). از «فضای ذخیره‌سازی» فضای اضافه بخرید.');
        }

        $orig = trim((string)($file['name'] ?? 'file'));
        if ($orig === '') $orig = 'file';
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $ext = preg_replace('/[^a-z0-9]/', '', $ext);
        $ext = mb_substr($ext, 0, 16);

        $title = mb_substr(trim($title), 0, 190);
        if ($title === '') $title = pathinfo($orig, PATHINFO_FILENAME) ?: 'سند بدون عنوان';

        $dir = self::dir($uid);
        if (!is_dir($dir) && !@mkdir($dir, 0775, true) && !is_dir($dir)) throw new RuntimeException('ساخت پوشهٔ ذخیره ممکن نشد.');

        $plain = (string)file_get_contents((string)$file['tmp_name']);
        $iv = random_bytes(16);
        $enc = openssl_encrypt($plain, 'aes-256-cbc', self::masterKey(), OPENSSL_RAW_DATA, $iv);
        if ($enc === false) throw new RuntimeException('رمزگذاری فایل ممکن نشد.');

        $safe = date('Ymd-His') . '-' . bin2hex(random_bytes(6));
        if (!@file_put_contents($dir . '/' . $safe, $enc)) throw new RuntimeException('ذخیرهٔ فایل ممکن نشد.');
        @chmod($dir . '/' . $safe, 0644);

        $id = (int)Database::insert('user_documents', [
            'business_id' => $biz, 'user_id' => $uid, 'title' => $title,
            'description' => trim($description) !== '' ? mb_substr(trim($description), 0, 2000) : null,
            'file_name' => mb_substr($orig, 0, 255), 'storage_key' => $uid . '/' . $safe,
            'mime_type' => (string)($file['type'] ?? 'application/octet-stream'),
            'size_bytes' => (int)($file['size'] ?? 0), 'ext' => $ext ?: null,
            'is_encrypted' => $password !== null && $password !== '' ? 1 : 0,
            'password_hash' => ($password !== null && $password !== '') ? password_hash($password, PASSWORD_BCRYPT, ['cost' => 10]) : null,
            'iv_hex' => bin2hex($iv), 'created_at' => now(),
        ]);
        Audit::log('create', 'user_documents', $id, 'ذخیرهٔ سند «' . $title . '» (' . $ext . ', ' . self::humanSize((int)$file['size']) . ')');
        return $id;
    }

    /** بررسی رمز سند */
    public static function verifyPassword(array $d, string $password): bool
    {
        return password_verify($password, (string)($d['password_hash'] ?? ''));
    }

    /** بازکردن محتوای رمزگشایی‌شده */
    public static function decrypt(array $d): string
    {
        $p = self::path($d);
        if (!is_file($p)) throw new RuntimeException('فایل روی سرور موجود نیست.');
        $enc = (string)file_get_contents($p);
        $iv = hex2bin((string)($d['iv_hex'] ?? ''));
        if ($iv === false || strlen($iv) !== 16) throw new RuntimeException('متادیتای رمزنگاری نامعتبر است.');
        $plain = openssl_decrypt($enc, 'aes-256-cbc', self::masterKey(), OPENSSL_RAW_DATA, $iv);
        if ($plain === false) throw new RuntimeException('رمزگشایی فایل ممکن نشد.');
        return $plain;
    }

    /** ارسال فایل به مرورگر */
    public static function stream(array $d): void
    {
        $plain = self::decrypt($d);
        $inline = str_starts_with((string)$d['mime_type'], 'image/') || (string)$d['mime_type'] === 'application/pdf';
        header('Content-Type: ' . (string)$d['mime_type']);
        header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment') . '; filename="' . rawurlencode((string)$d['file_name']) . '"');
        header('Content-Length: ' . strlen($plain));
        header('Cache-Control: private, no-store');
        echo $plain;
        exit;
    }

    public static function delete(int $id): void
    {
        $d = self::one($id);
        if (!$d) throw new RuntimeException('سند یافت نشد یا دسترسی ندارید.');
        $p = self::path($d);
        if (is_file($p)) @unlink($p);
        Database::run('UPDATE user_documents SET deleted_at=NOW() WHERE id=?', [$id]);
        Audit::log('delete', 'user_documents', $id, 'حذف سند «' . $d['title'] . '»');
    }

    /** کاربران دارای سند (برای فیلتر مدیر) */
    public static function usersWithDocs(): array
    {
        if (!Auth::isAdmin()) return [];
        $biz = (int)Auth::businessId();
        return Database::all("SELECT DISTINCT u.id, u.full_name, u.avatar_path, COUNT(d.id) AS cnt
                                FROM user_documents d JOIN users u ON u.id = d.user_id
                               WHERE d.business_id = ? AND d.deleted_at IS NULL
                               GROUP BY u.id, u.full_name, u.avatar_path ORDER BY u.full_name", [$biz]);
    }
}
