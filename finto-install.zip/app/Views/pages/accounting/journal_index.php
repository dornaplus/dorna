<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $rows @var array $totals @var int $page @var int $per @var string $q @var string $type @var string $source @var string $from @var string $to */
$rows = $rows ?? []; $totals = $totals ?? ['cnt' => 0, 'debit' => 0];
$entryTypes = ['normal' => 'عادی', 'opening' => 'افتتاحیه', 'closing' => 'بستن سال', 'adjustment' => 'اصلاحی', 'payroll' => 'حقوق', 'transfer' => 'انتقالی'];
$sources = ['manual' => 'دستی', 'auto' => 'خودکار', 'invoice' => 'فاکتور', 'receipt' => 'دریافت', 'payment' => 'پرداخت', 'inventory' => 'انبار', 'payroll' => 'حقوق'];
$totalPages = max(1, (int)ceil(((int)$totals['cnt']) / max(1, (int)$per)));
?>
<div class="page-head">
    <div>
        <h2>اسناد حسابداری</h2>
        <div class="muted sm"><?= num($totals['cnt'], 0) ?> سند — جمع بدهکار <?= money($totals['debit']) ?></div>
    </div>
    <div class="actions">
        <a class="btn" href="<?= url('app/journal/create') ?>"><?= icon('plus') ?> ثبت سند دستی</a>
        <a class="btn soft" href="<?= url('app/opening-balances/setup') ?>">تراز افتتاحیه</a>
        <a class="btn gray" href="<?= url('app/reports/journal_book') ?>">دفتر روزنامه</a>
    </div>
</div>

<form class="card filters" method="get" action="<?= url('app/journal') ?>">
    <div class="grid c5">
        <label class="field"><span>جست‌وجو</span><input type="text" name="q" class="inp" value="<?= e($q) ?>" placeholder="شماره سند، شرح، عطف"></label>
        <label class="field"><span>نوع سند</span>
            <select name="entry_type" class="inp">
                <option value="">همه</option>
                <?php foreach ($entryTypes as $k => $t): ?><option value="<?= $k ?>" <?= $type === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
            </select>
        </label>
        <label class="field"><span>منبع</span>
            <select name="source" class="inp">
                <option value="">همه</option>
                <?php foreach ($sources as $k => $t): ?><option value="<?= $k ?>" <?= $source === $k ? 'selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
            </select>
        </label>
        <label class="field"><span>از تاریخ</span><input type="text" name="from" class="inp jalali" dir="ltr" value="<?= e($from) ?>"></label>
        <label class="field"><span>تا تاریخ</span><input type="text" name="to" class="inp jalali" dir="ltr" value="<?= e($to) ?>"></label>
    </div>
    <div class="actions end">
        <button class="btn" type="submit">اعمال فیلتر</button>
        <a class="btn gray" href="<?= url('app/journal') ?>">حذف فیلترها</a>
    </div>
</form>

<div class="card">
    <div class="table-wrap">
        <table class="tbl">
            <thead>
                <tr>
                    <th>شماره</th><th>تاریخ</th><th>نوع</th><th>شرح</th><th>عطف</th>
                    <th class="num">بدهکار</th><th class="num">بستانکار</th><th>وضعیت</th><th>ثبت‌کننده</th><th></th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td class="num"><a href="<?= url('app/journal/'.$r['id']) ?>"><?= e(fa_digits((string)$r['entry_no'])) ?></a></td>
                    <td class="num"><?= e(jdate($r['entry_date'])) ?></td>
                    <td><?= e($entryTypes[$r['entry_type']] ?? $r['entry_type']) ?></td>
                    <td><?= e(mb_strimwidth((string)$r['description'], 0, 60, '…')) ?></td>
                    <td class="num" dir="ltr"><?= e(fa_digits((string)($r['reference_no'] ?? '—'))) ?></td>
                    <td class="num"><?= money($r['total_debit']) ?></td>
                    <td class="num"><?= money($r['total_credit']) ?></td>
                    <td><span class="pill <?= $r['status'] === 'posted' ? 'st-paid' : ($r['status'] === 'reversed' ? 'st-cancelled' : 'st-draft') ?>">
                        <?= $r['status'] === 'posted' ? 'قطعی' : ($r['status'] === 'reversed' ? 'برگشتی' : 'پیش‌نویس') ?></span></td>
                    <td><?= e($r['creator'] ?? '—') ?></td>
                    <td class="actions">
                        <a class="btn icon gray" href="<?= url('app/journal/'.$r['id'].'/print') ?>" target="_blank" rel="noopener" title="چاپ"><?= icon('print') ?></a>
                        <a class="btn icon gray" href="<?= url('app/journal/'.$r['id'].'/print?pdf=1') ?>" target="_blank" rel="noopener" title="ذخیره PDF"><?= icon('file') ?></a>
                        <a class="btn icon soft" href="<?= url('app/journal/'.$r['id']) ?>" title="مشاهده"><?= icon('eye') ?></a>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$rows): ?>
                <tr><td colspan="10" class="muted center">سندی با این فیلتر یافت نشد.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
        <div class="card-foot">
            <?php $page = (int)$page; $per = (int)$per; $total = (int)$totals['cnt']; $baseQuery = qs(); require __DIR__.'/../../partials/pagination.php'; ?>
        </div>
    <?php endif; ?>
</div>
<?= view('partials/foot') ?>