<?php /** @var array $e @var array $lines @var array $tpl @var array $business */
$lines = $lines ?? []; $business = $business ?? Auth::business();
$tpl = $tpl ?? Printing::template('voucher');
$typeTitles = ['normal' => 'عادی', 'adjustment' => 'اصلاحی', 'opening' => 'افتتاحیه', 'closing' => 'بستن سال', 'payroll' => 'حقوق و دستمزد', 'transfer' => 'انتقالی'];
?>
<?= view('partials/public_head', ['title' => 'چاپ سند حسابداری']) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
    <?= view('partials/print_bar', ['back' => url('app/journal/'.$e['id'])]) ?>
    <div class="print-head">
        <div class="print-brand">
            <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
            <h1><?= e($business['name'] ?? '') ?></h1>
            <div class="muted sm">
                <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <?= e($business['economic_code']) ?> — <?php endif; ?>
                <?= e($business['address'] ?? '') ?> <?= !empty($business['phone']) ? ' — تلفن: '.e($business['phone']) : '' ?></div>
        </div>
        <div class="end">
            <h2>سند حسابداری</h2>
            <div>شماره: <strong dir="ltr"><?= e(fa_digits((string)$e['entry_no'])) ?></strong></div>
            <div>تاریخ: <strong class="num"><?= e(jdate($e['entry_date'])) ?></strong></div>
            <div>نوع: <?= e($typeTitles[$e['entry_type']] ?? $e['entry_type']) ?></div>
        </div>
    </div>
    <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)$e['entry_no']); ?>
    <table class="tbl print-tbl">
        <thead><tr><th>#</th><th>کد</th><th>شرح حساب</th><th>تفصیلی</th><th class="num">بدهکار</th><th class="num">بستانکار</th></tr></thead>
        <tbody>
        <?php foreach ($lines as $i => $l): ?>
            <tr>
                <td class="num"><?= $i + 1 ?></td>
                <td class="num" dir="ltr"><?= e($l['account_code']) ?></td>
                <td><?= e($l['account_title']) ?></td>
                <td><?= e(mb_strimwidth((string)($l['description'] ?? ''), 0, 60, '…')) ?></td>
                <td class="num"><?= $l['debit_amount'] > 0 ? money($l['debit_amount']) : '' ?></td>
                <td class="num"><?= $l['credit_amount'] > 0 ? money($l['credit_amount']) : '' ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4" class="end">جمع</th><th class="num"><?= money($e['total_debit']) ?></th><th class="num"><?= money($e['total_credit']) ?></th></tr>
        </tfoot>
    </table>
    <?php if (!empty($e['description'])): ?>
        <p class="print-note"><strong>شرح:</strong> <?= e($e['description']) ?></p>
    <?php endif; ?>
    <?php if (!empty($tpl['amount_in_words'])): ?><p class="words"><?= e(amount_in_words((float)$e['total_debit'], currency_title())) ?></p><?php endif; ?>
    <?php if (!empty($tpl['show_bank_info'])) echo Printing::bankBlock(); ?>
    <?php if (!empty($tpl['show_signature'])): ?>
    <div class="signs">
        <div>تهیه‌کننده</div><div>تأییدکننده</div><div>مدیر مالی</div><div>مدیرعامل</div>
    </div>
    <?php endif; ?>
    <div class="print-foot">
        <span><?= e(config('app')['name']) ?></span>
        <span>تاریخ چاپ: <?= e(jdate(today())) ?> — ساعت <?= e(date('H:i')) ?></span>
    </div>
</div>
<?= view('partials/public_foot') ?>
