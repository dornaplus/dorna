<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $employees @var array $components @var array $cashAccounts @var array $costCenters @var array $doc @var string $nextNo */
$employees = $employees ?? []; $components = $components ?? []; $doc = $doc ?? [];
$insRate = (float)($insRate ?? 7); $taxRate = (float)($taxRate ?? 10);
// دادهٔ پرسنل برای پرکردن خودکار ردیف‌ها
$workshops = $workshops ?? []; $outstanding = $outstanding ?? []; $suggested = $suggested ?? [];
$wsTitles = []; foreach ($workshops as $w) $wsTitles[(int)$w['id']] = (string)$w['title'];
$clone = $clone ?? null; $cur = Auth::currency(); $activeContracts = $activeContracts ?? [];
$empData = [];
foreach ($employees as $e) {
    $base = (float)($e['base_salary'] ?? 0);
    $allow = (float)($e['housing_allowance'] ?? 0) + (float)($e['food_allowance'] ?? 0) + (float)($e['child_allowance'] ?? 0) + (float)($e['other_allowances'] ?? 0);
    $parts = [(float)($e['housing_allowance'] ?? 0), (float)($e['food_allowance'] ?? 0),
              (float)($e['child_allowance'] ?? 0), (float)($e['other_allowances'] ?? 0)];
    $id = (int)$e['id'];
    $ct = $activeContracts[$id] ?? [];
    $empData[$id] = ['ws' => $wsTitles[(int)($e['workshop_id'] ?? 0)] ?? '',
        'ct' => !empty($ct['contract_no']) ? (string)$ct['contract_no'] . (!empty($ct['end_date']) ? ' تا ' . jdate($ct['end_date']) : '') : '',
        'name' => (string)$e['full_name'], 'code' => (string)($e['code'] ?? ''),
        'base' => $base, 'allow' => $allow, 'row' => $base + $allow, 'parts' => array_values(array_filter($parts)),
        'adv_open' => (float)($outstanding[$id]['advance'] ?? 0), 'loan_open' => (float)($outstanding[$id]['loan'] ?? 0),
        'adv_sug' => (float)($suggested[$id]['advance'] ?? 0), 'loan_sug' => (float)($suggested[$id]['loan'] ?? 0)];
}
// دادهٔ «مشابه ماه قبل»
$cloneLines = [];
if (!empty($clone['lines'])) {
    foreach ($clone['lines'] as $l) {
        $comps = [];
        foreach (Database::all('SELECT component_id, amount FROM payroll_line_items WHERE payroll_line_id=?', [(int)$l['id']]) as $ci) $comps[(int)$ci['component_id']] = (float)$ci['amount'];
        $cloneLines[] = ['emp' => (int)$l['employee_id'], 'days' => (float)$l['worked_days'], 'base' => (float)$l['gross_amount'],
            'ded' => (float)$l['deductions_amount'], 'adv' => (float)($l['advance_amount'] ?? 0), 'loan' => (float)($l['loan_amount'] ?? 0), 'comps' => $comps];
    }
}
?>
<form method="post" action="<?= url('app/payroll-documents') ?>" class="stack" data-payroll="1">
<?= csrf_field() ?>
<input type="hidden" name="redirect_to" value="create">
<div class="card">
    <div class="card-head">
        <h3>ثبت سند حقوق و دستمزد</h3>
        <span class="pill st-draft">شماره بعدی: <?= e($nextNo) ?></span>
    </div>
    <div class="card-body">
        <div class="grid c4">
            <label class="field"><span>تاریخ سند</span><input type="text" name="doc_date" class="inp jalali" value="<?= e(old('doc_date', today()) ? jdate(old('doc_date', today())) : '') ?>" data-date="<?= e(today()) ?>" dir="ltr" required></label>
            <label class="field"><span>عنوان دوره</span><input type="text" name="period_title" class="inp" value="<?= e(old('period_title', 'حقوق '.jdate(today()))) ?>"></label>
            <label class="field"><span>حساب پرداخت (صندوق/بانک)</span>
                <select name="cash_account_id" class="inp select-search">
                    <option value="">— انتخاب نشده —</option>
                    <?php foreach ($cashAccounts as $a): $sel = (string)old('cash_account_id', $doc['cash_account_id'] ?? '') === (string)$a['id']; ?>
                        <option value="<?= (int)$a['id'] ?>" <?= $sel ? 'selected' : '' ?>><?= e($a['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>کارگاه</span>
                <select name="workshop_id" class="inp select-search">
                    <option value="">— بدون کارگاه —</option>
                    <?php foreach ($workshops as $w): ?>
                        <option value="<?= (int)$w['id'] ?>" <?= (string)old('workshop_id', $doc['workshop_id'] ?? ($clone['doc']['workshop_id'] ?? '')) === (string)$w['id'] ? 'selected' : '' ?>><?= e($w['code'] . ' — ' . $w['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>مرکز هزینه</span>
                <select name="cost_center_id" class="inp select-search">
                    <option value="">— بدون مرکز هزینه —</option>
                    <?php foreach ($costCenters as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)old('cost_center_id', $doc['cost_center_id'] ?? '') === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['name'] ?? $c['title'] ?? '') ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-head">
        <h3>اقلام حقوق پرسنل</h3>
        <div class="muted sm">با «افزودن ردیف پرسنل» خودتان پرسنل را از فهرست انتخاب کنید؛ حقوق پایه و مزایا خودکار پر می‌شود.</div>
        <div class="grow"></div>
        <button type="button" class="btn soft sm js-add-all-emp" title="همهٔ پرسنل فعال کسب‌وکار یک‌باره به ردیف‌ها اضافه می‌شوند">افزودن همهٔ پرسنل</button>
        <button type="button" class="btn soft sm js-add-emp">+ افزودن ردیف پرسنل</button>
    </div>
    <?php if (!$employees): ?>
        <div class="card-body">
            <div class="alert info">هنوز پرسنلی ثبت نشده است. ابتدا از مسیر «اشخاص ← پرسنل» کارمند تعریف کنید.</div>
        </div>
    <?php endif; ?>
    <div class="table-wrap">
        <table class="tbl tbl-grid" data-rows="emp">
            <thead>
                <tr>
                    <th style="width:46px">#</th>
                    <th style="min-width:210px">پرسنل</th>
                    <?php foreach ($components as $c): ?>
                        <th class="num"><?= e($c['title']) ?><small class="muted block"><?= e($c['calc_type'] === 'percent' ? 'درصدی' : ($c['calc_type'] === 'formula' ? 'فرمولی' : 'ثابت')) ?></small></th>
                    <?php endforeach; ?>
                    <th class="num">روز کارکرد</th>
                    <th class="num">حقوق پایه</th>
                    <th class="num">کسورات</th>
                    <th class="num">کسر مساعده</th>
                    <th class="num">قسط وام</th>
                    <th class="num">جمع اقلام</th>
                    <th class="num">جمع کل</th>
                    <th style="width:52px"></th>
                </tr>
            </thead>
            <tbody></tbody>
            <tfoot>
                <tr class="grand">
                    <th colspan="2" class="end">جمع کل سند</th>
                    <?php foreach ($components as $c): ?><th class="num foot-comp">۰</th><?php endforeach; ?>
                    <th class="num foot-days">—</th>
                    <th class="num foot-base">۰</th>
                    <th class="num foot-ded">۰</th>
                    <th class="num foot-adv">۰</th>
                    <th class="num foot-loan">۰</th>
                    <th class="num foot-allow">۰</th>
                    <th class="num foot-total">۰</th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="card-foot">
        <div class="total-box">
            <div><span>جمع ناخالص</span><strong class="num sum_gross"><?= money(0) ?></strong></div>
            <div><span>بیمه سهم کارمند (<?= num($insRate, 0) ?>٪)</span><strong class="num ins_out"><?= money(0) ?></strong></div>
            <div><span>مالیات (برآورد <?= num($taxRate, 0) ?>٪)</span><strong class="num tax_out"><?= money(0) ?></strong></div>
            <div><span>کسورات دستی</span><strong class="num ded_out"><?= money(0) ?></strong></div>
            <div><span>کسر مساعده</span><strong class="num adv_out"><?= money(0) ?></strong></div>
            <div><span>قسط وام</span><strong class="num loan_out"><?= money(0) ?></strong></div>
            <div class="grand"><span>خالص پرداختی</span><strong class="num net_out"><?= money(0) ?></strong></div>
        </div>
        <div class="actions">
            <button type="submit" class="btn">ثبت سند حقوق و صدور سند حسابداری</button>
            <a class="btn gray" href="<?= url('app/payroll-documents') ?>">انصراف</a>
        </div>
    </div>
</div>
</form>

<template id="tpl-emp-row">
    <tr data-row="emp">
        <td class="num row-idx"></td>
        <td>
            <select class="inp select-search" data-emp>
                <option value="">— انتخاب پرسنل —</option>
                <?php foreach ($employees as $e): ?>
                    <option value="<?= (int)$e['id'] ?>"><?= e($e['full_name'] . (!empty($e['code']) ? ' (' . $e['code'] . ')' : '')) ?></option>
                <?php endforeach; ?>
            </select>
            <small class="muted block emp-hint" dir="ltr"></small>
        </td>
        <?php foreach ($components as $c): ?>
            <td><input type="text" class="inp money comp_inp" data-comp="<?= (int)$c['id'] ?>" data-rate="<?= (float)($c['rate_percent'] ?? 0) ?>" data-def="<?= (float)($c['default_amount'] ?? 0) ?>" value="0"></td>
        <?php endforeach; ?>
        <td><input type="text" class="inp num-inp days_inp" value="30" style="max-width:78px"></td>
        <td><input type="text" class="inp money base_inp" value="0" style="min-width:120px"></td>
        <td><input type="text" class="inp money ded_inp" value="0" style="min-width:100px"></td>
        <td><input type="text" class="inp money adv_inp" value="0" style="min-width:100px"></td>
        <td><input type="text" class="inp money loan_inp" value="0" style="min-width:100px"></td>
        <td class="num row-allow">۰</td>
        <td class="num row-total">۰</td>
        <td class="acts"><button type="button" class="btn-danger sm js-del-emp" title="حذف ردیف">×</button></td>
    </tr>
</template>

<script>
(function () {
    var tbl = document.querySelector('[data-rows="emp"]');
    if (!tbl) return;
    var body = tbl.querySelector('tbody');
    var tpl = document.getElementById('tpl-emp-row');
    var EMP = <?= json_encode($empData, JSON_UNESCAPED_UNICODE) ?>;
    var INS = <?= json_encode($insRate) ?>, TAX = <?= json_encode($taxRate) ?>;
    var compCount = <?= count($components) ?>;
    // ارقام فارسی/عربی هم باید خوانده شوند
    function num(v) {
        return parseFloat(String(v == null ? 0 : v)
            .replace(/[۰-۹]/g, function (d) { return String(d.charCodeAt(0) - 1776); })
            .replace(/[٠-٩]/g, function (d) { return String(d.charCodeAt(0) - 1632); })
            .replace(/[^\d.-]/g, '')) || 0;
    }
    function fa(v) { return Math.round(v).toLocaleString('fa-IR'); }
    function rowInputs(tr) { return {
        emp: tr.querySelector('[data-emp]'),
        base: tr.querySelector('.base_inp'),
        ded: tr.querySelector('.ded_inp'),
        adv: tr.querySelector('.adv_inp'),
        loan: tr.querySelector('.loan_inp'),
        days: tr.querySelector('.days_inp'),
        comps: tr.querySelectorAll('.comp_inp'),
        allow: tr.querySelector('.row-allow'),
        total: tr.querySelector('.row-total')
    }; }
    function usedBy(except) {
        var used = {};
        body.querySelectorAll('tr[data-row="emp"]').forEach(function (tr) {
            if (tr === except) return;
            var s = tr.querySelector('[data-emp]');
            if (s && s.value) used[s.value] = true;
        });
        return used;
    }
    function markDuplicates() {
        var seen = {};
        body.querySelectorAll('tr[data-row="emp"]').forEach(function (tr) {
            var s = tr.querySelector('[data-emp]'); if (!s) return;
            var dup = s.value && seen[s.value];
            if (s.value) seen[s.value] = true;
            tr.classList.toggle('row-dup', !!dup);
            var hint = tr.querySelector('.emp-hint');
            if (hint && dup) hint.textContent = '⚠️ این پرسنل در ردیف دیگری هم انتخاب شده است';
        });
    }
    /** مقدار مزایای پروندهٔ همان ردیف (که سمت سرور از پروندهٔ پرسنل خوانده می‌شود) */
    function rowAllow(tr) {
        var s = tr.querySelector('[data-emp]');
        var d = s && EMP[s.value];
        return d ? d.allow : 0;
    }
    function recalc() {
        var gross = 0;
        var footComp = new Array(compCount).fill(0), footAllow = 0, footTotal = 0, footBase = 0, footDed = 0, footAdv = 0, footLoan = 0;
        var rows = body.querySelectorAll('tr[data-row="emp"]');
        rows.forEach(function (tr, n) {
            var r = rowInputs(tr);
            var idx = tr.querySelector('.row-idx'); if (idx) idx.textContent = (n + 1).toLocaleString('fa-IR');
            // نام‌گذاری ورودی‌ها بر اساس ردیف جاری (ردیف‌های خالی فرستاده نمی‌شوند)
            if (r.emp) r.emp.name = r.emp.value ? ('employee_id[' + n + ']') : '';
            if (r.emp && r.emp.value) {
                r.base.name = 'base_salary[' + n + ']'; r.ded.name = 'deductions[' + n + ']'; r.days.name = 'worked_days[' + n + ']';
                if (r.adv) r.adv.name = 'advance_amount[' + n + ']';
                if (r.loan) r.loan.name = 'loan_amount[' + n + ']';
            } else { r.base.name = ''; r.ded.name = ''; r.days.name = ''; if (r.adv) r.adv.name = ''; if (r.loan) r.loan.name = ''; }
            var comp = 0;
            r.comps.forEach(function (inp, ci) {
                var cid = inp.getAttribute('data-comp');
                inp.name = r.emp && r.emp.value ? ('comp_amount[' + n + '][' + cid + ']') : '';
                var v = num(inp.value); comp += v; footComp[ci] += v;
            });
            var base = num(r.base.value), ded = num(r.ded.value);
            var adv = r.adv ? num(r.adv.value) : 0, loan = r.loan ? num(r.loan.value) : 0;
            footAdv += adv; footLoan += loan;
            var allow = rowAllow(tr);
            if (r.allow) r.allow.textContent = fa(allow);
            var total = base + allow + comp;
            if (r.total) r.total.textContent = fa(total);
            gross += total; footAllow += allow; footTotal += total; footBase += base; footDed += ded;
        });
        // جمع هر ستون در پانویس
        var footCells = tbl.querySelectorAll('tfoot .foot-comp');
        footCells.forEach(function (c, i) { c.textContent = fa(footComp[i] || 0); });
        var fa1 = tbl.querySelector('tfoot .foot-allow'); if (fa1) fa1.textContent = fa(footAllow);
        var fb = tbl.querySelector('tfoot .foot-base'); if (fb) fb.textContent = fa(footBase);
        var fd = tbl.querySelector('tfoot .foot-ded'); if (fd) fd.textContent = fa(footDed);
        var fad = tbl.querySelector('tfoot .foot-adv'); if (fad) fad.textContent = fa(footAdv);
        var flo = tbl.querySelector('tfoot .foot-loan'); if (flo) flo.textContent = fa(footLoan);
        var ft = tbl.querySelector('tfoot .foot-total'); if (ft) ft.textContent = fa(footTotal);
        var ins = gross * INS / 100, tax = Math.max(0, gross - ins) * TAX / 100;
        document.querySelectorAll('.sum_gross').forEach(function (el) { el.textContent = fa(gross); });
        document.querySelectorAll('.ins_out').forEach(function (el) { el.textContent = fa(ins); });
        document.querySelectorAll('.tax_out').forEach(function (el) { el.textContent = fa(tax); });
        document.querySelectorAll('.ded_out').forEach(function (el) { el.textContent = fa(footDed); });
        document.querySelectorAll('.adv_out').forEach(function (el) { el.textContent = fa(footAdv); });
        document.querySelectorAll('.loan_out').forEach(function (el) { el.textContent = fa(footLoan); });
        document.querySelectorAll('.net_out').forEach(function (el) { el.textContent = fa(gross - ins - tax - footDed - footAdv - footLoan); });
        markDuplicates();
    }
    /** پرکردن ردیف از روی پروندهٔ پرسنل انتخاب‌شده */
    function fillRow(tr) {
        var r = rowInputs(tr); if (!r.emp) return;
        var d = EMP[r.emp.value] || null;
        var hint = tr.querySelector('.emp-hint');
        if (!d) { if (hint) hint.textContent = ''; r.base.value = 0; r.comps.forEach(function (i) { i.value = 0; }); recalc(); return; }
        if (hint) {
            hint.textContent = (d.code ? d.code + ' · ' : '') + (d.ws ? d.ws + ' · ' : '') + (d.ct ? 'قرارداد ' + d.ct + ' · ' : '') + 'حقوق پایه ' + fa(d.base) + ' + مزایا ' + fa(d.allow)
                + ((d.adv_open || d.loan_open) ? ' · مانده: مساعده ' + fa(d.adv_open) + ' / وام ' + fa(d.loan_open) : '');
        }
        r.base.value = fa(d.base);
        if (r.adv) r.adv.value = fa(d.adv_sug || 0);
        if (r.loan) r.loan.value = fa(d.loan_sug || 0);
        var parts = d.parts || [];
        r.comps.forEach(function (i) {
            var def = num(i.getAttribute('data-def')), rate = num(i.getAttribute('data-rate'));
            // مزایایی که در پروندهٔ پرسنل ثبت شده‌اند سمت سرور حساب می‌شوند و نباید دوباره‌شماری شوند
            var dup = def > 0 && parts.some(function (p) { return Math.abs(p - def) < 1; });
            if (dup) {
                i.value = fa(0);
                i.title = 'این مبلغ از پروندهٔ پرسنل خوانده می‌شود و در ستون «مزایا» لحاظ شده است';
                i.classList.add('comp-from-file');
                return;
            }
            i.classList.remove('comp-from-file');
            i.value = fa(def > 0 ? def : Math.round(d.row * rate / 100));
        });
        recalc();
    }
    function addRow(fill) {
        if (!tpl) return;
        var tr = tpl.content.firstElementChild.cloneNode(true);
        body.appendChild(tr);
        tr.addEventListener('change', function (e) { if (e.target.matches('[data-emp]')) fillRow(tr); });
        recalc();
        if (fill !== false) { var s = tr.querySelector('[data-emp]'); if (s) s.focus(); }
        return tr;
    }
    body.addEventListener('input', recalc);
    body.addEventListener('click', function (e) {
        var del = e.target.closest('.js-del-emp'); if (!del) return;
        var tr = del.closest('tr[data-row="emp"]');
        if (tr) { tr.remove(); recalc(); }
    });
    document.querySelectorAll('.js-add-emp').forEach(function (b) {
        b.addEventListener('click', function () { addRow(true); });
    });
    // افزودن یک‌بارهٔ همهٔ پرسنل فهرست (که در ردیف‌ها نیامده‌اند)
    function addAllEmployees() {
        var used = usedBy(null);
        var ids = Object.keys(EMP).sort(function (a, b) {
            return String(EMP[a].name).localeCompare(String(EMP[b].name), 'fa');
        });
        var added = 0;
        ids.forEach(function (id) {
            if (used[id]) return;
            var tr = addRow(false);
            if (!tr) return;
            var sel = tr.querySelector('[data-emp]');
            if (!sel) return;
            sel.value = id;
            fillRow(tr);
            added++;
        });
        // اگر همه از قبل انتخاب شده بودند، یک ردیف خالی بگذار
        if (added === 0) { var t = addRow(true); if (t) { var s2 = t.querySelector('[data-emp]'); if (s2) s2.focus(); } }
        // ردیف اول اگر خالی مانده باشد حذف شود
        var rows = body.querySelectorAll('tr[data-row="emp"]');
        rows.forEach(function (tr) {
            var sel = tr.querySelector('[data-emp]');
            if (sel && !sel.value && rows.length > 1) tr.remove();
        });
        recalc();
        return added;
    }
    document.querySelectorAll('.js-add-all-emp').forEach(function (b) {
        b.addEventListener('click', function () {
            var n = addAllEmployees();
            var toast = (window.FintoApp && window.FintoApp.toast) || window.printToast;
            if (toast) toast(n > 0 ? (n.toLocaleString('fa-IR') + ' پرسنل به ردیف‌ها اضافه شد.') : 'همهٔ پرسنل از قبل در فهرست هستند.', n > 0 ? 'success' : 'warn');
        });
    });
    // «مشابه ماه قبل»: پرکردن ردیف‌ها از سند حقوق قبلی
    var CLONE = <?= json_encode($cloneLines, JSON_UNESCAPED_UNICODE) ?>;
    if (CLONE && CLONE.length) {
        body.innerHTML = '';
        CLONE.forEach(function (line) {
            var tr = addRow(false);
            var sel = tr.querySelector('[data-emp]');
            if (!sel) return;
            sel.value = String(line.emp);
            var r = rowInputs(tr);
            r.days.value = fa(line.days || 30);
            r.base.value = fa(line.base || 0);
            r.ded.value = fa(line.ded || 0);
            if (r.adv) r.adv.value = fa(line.adv || 0);
            if (r.loan) r.loan.value = fa(line.loan || 0);
            r.comps.forEach(function (i) {
                var cid = i.getAttribute('data-comp');
                var v = line.comps && line.comps[cid] ? line.comps[cid] : 0;
                i.value = fa(v);
            });
            var hint = tr.querySelector('.emp-hint');
            var d = EMP[sel.value];
            if (hint && d) hint.textContent = (d.code ? d.code + ' · ' : '') + 'کپی از سند قبلی';
            recalc();
        });
    }
    if (!body.querySelectorAll('tr[data-row="emp"]').length) addRow(false);   // یک ردیف خالی برای شروع
    recalc();
})();
</script>
<?= view('partials/foot') ?>
