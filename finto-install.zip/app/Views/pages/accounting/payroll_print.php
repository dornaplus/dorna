<?php /** @var array $d @var array $lines @var array $tpl @var array $business */
$lines = $lines ?? []; $business = $business ?? Auth::business();
$tpl = $tpl ?? Printing::template('payroll');
?>
<?= view('partials/public_head', ['title' => $title]) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
    <?= view('partials/print_bar', ['back' => url('app/payroll-documents/'.$d['id'])]) ?>
    <div class="print-head">
        <div class="print-brand">
            <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
            <div class="biz"><?= e($business['name'] ?? '') ?></div>
            <div class="print-meta">
                <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <b><?= e($business['economic_code']) ?></b><br><?php endif; ?>
                <?= e($business['address'] ?? '') ?><?php if (!empty($business['phone'])): ?><br>تلفن: <?= e($business['phone']) ?><?php endif; ?>
            </div>
        </div>
        <div style="text-align:left">
            <div style="font-size:15px;font-weight:700;color:var(--p-800)">سند حقوق و دستمزد</div>
            <div class="print-meta">شماره: <b><?= e(fa_digits((string)$d['doc_no'])) ?></b><br>تاریخ: <b><?= e(jdate($d['doc_date'])) ?></b><br>
                دوره: <b><?= e((string)$d['period_title']) ?></b></div>
        </div>
    </div>
    <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)$d['doc_no']); ?>
    <table class="print-tbl">
        <thead><tr><th>#</th><th>کد پرسنلی</th><th>نام و نام خانوادگی</th><th>روز کارکرد</th><th>حقوق و مزایا</th><th>کسورات</th><th>خالص پرداختی</th></tr></thead>
        <tbody>
        <?php foreach ($lines as $i => $l): ?>
            <tr>
                <td><?= num($i + 1) ?></td>
                <td><?= e((string)($l['employee_code'] ?? '—')) ?></td>
                <td><?= e((string)($l['full_name'] ?? '—')) ?></td>
                <td><?= num($l['worked_days'], 0) ?></td>
                <td><?= num($l['gross_amount']) ?></td>
                <td><?= num($l['deductions_amount']) ?></td>
                <td><?= num($l['net_amount']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (!$lines): ?><tr><td colspan="7" style="text-align:center">ردیفی ثبت نشده است.</td></tr><?php endif; ?>
        </tbody>
        <tfoot>
            <tr><th colspan="4">جمع کل (<?= num((int)$d['employee_count']) ?> نفر)</th><th><?= num($d['gross_amount']) ?></th><th><?= num($d['deductions_amount']) ?></th><th><?= num($d['net_amount']) ?></th></tr>
            <?php if ((float)$d['insurance_employee'] > 0 || (float)$d['insurance_employer'] > 0 || (float)$d['tax_amount'] > 0): ?>
            <tr><th colspan="4">بیمهٔ سهم کارمند / کارفرما / مالیات</th>
                <th colspan="3"><?= num($d['insurance_employee']) ?> / <?= num($d['insurance_employer']) ?> / <?= num($d['tax_amount']) ?></th></tr>
            <?php endif; ?>
        </tfoot>
    </table>
    <?php if ($d['cash_title'] ?? ''): ?><div class="print-note">حساب پرداخت: <strong><?= e((string)$d['cash_title']) ?></strong></div><?php endif; ?>
    <?php if (!empty($tpl['amount_in_words'])): ?><div class="words">خالص پرداختی به حروف: <?= e($amountWords) ?></div><?php endif; ?>
    <?php if (!empty($tpl['show_bank_info'])) echo Printing::bankBlock(); ?>
    <?php if (!empty($tpl['show_signature'])): ?><div class="signs"><div>تهیه‌کننده</div><div>مدیر مالی</div><div>مدیرعامل</div></div><?php endif; ?>
    <div class="print-foot">
        <span><?= e(config('app')['name']) ?> — <?= e($business['name'] ?? '') ?></span>
        <span>تاریخ چاپ: <?= e(jdate(today())) ?> — ساعت <?= e(date('H:i')) ?></span>
    </div>
</div>
<?= view('partials/public_foot') ?>
