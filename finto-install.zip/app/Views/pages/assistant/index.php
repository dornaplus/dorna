<?= view('partials/head', ['title' => $title]) ?>
<?php $enabled = $enabled ?? false; $model = $model ?? ''; ?>
<div class="page-head">
  <div>
    <h2><?= icon('spark') ?> دستیار هوشمند فینتو</h2>
    <div class="muted sm">پرسش از دادهٔ کسب‌وکار با زبان طبیعی — مدل: <?= e($model) ?></div>
  </div>
  <div class="actions">
    <span class="badge <?= $enabled ? 'on' : 'off' ?>"><?= $enabled ? 'متصل به هوش مصنوعی' : 'غیرفعال' ?></span>
    <a class="btn gray sm" href="<?= url('app') ?>">داشبورد</a>
  </div>
</div>

<?php if (!$enabled): ?>
  <div class="alert warn">سرویس هوش مصنوعی تنظیم نشده است. کلید را در <code>config.php</code> بخش <code>ai.api_key</code> قرار دهید یا متغیر محیطی <code>AVALAI_API_KEY</code> را تنظیم کنید.</div>
<?php endif; ?>

<div class="grid ai-layout">
  <div class="card ai-chat">
    <div class="ai-msgs" id="aiMsgs">
      <div class="ai-msg bot">سلام 👋 من دستیار حسابداری فینتو هستم. می‌توانی دربارهٔ فروش، خرید، طلب و بدهی، موجودی انبار، چک‌ها و اسناد سؤال بپرسی.</div>
    </div>
    <form class="ai-input" id="aiForm" autocomplete="off">
      <input class="inp" id="aiQ" placeholder="مثال: فروش این ماه چقدر بوده و بهترین مشتری کیست؟">
      <button class="btn" type="submit"><?= icon('spark') ?> بپرس</button>
    </form>
    <div class="chips-row" id="aiSuggest">
      <button type="button" class="chip" data-q="فروش این ماه چقدر بوده و بهترین مشتری کیست؟">فروش این ماه</button>
      <button type="button" class="chip" data-q="طلب از مشتریان چقدر است؟ ۵ بدهکار بزرگ را نشان بده.">بدهکاران بزرگ</button>
      <button type="button" class="chip" data-q="کدام کالاها زیر نقطه سفارش هستند؟">کالاهای کم‌موجود</button>
      <button type="button" class="chip" data-q="چک‌های نزدیک سررسید تا ۳۰ روز آینده">چک‌های نزدیک سررسید</button>
      <button type="button" class="chip" data-q="فاکتورهای سررسید گذشته و مبلغ معوق آن‌ها">فاکتورهای معوق</button>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3><?= icon('spark') ?> خلاصهٔ مدیریتی</h3></div>
    <p class="help" style="margin-top:0">یک گزارش کوتاه از وضعیت مالی این ماه همراه با ۳ اقدام پیشنهادی.</p>
    <button class="btn soft" id="aiSummaryBtn" type="button" style="width:100%">ساخت خلاصهٔ مدیریتی</button>
    <div id="aiSummary" class="ai-summary-out"></div>
  </div>
</div>

<script>
(function () {
  var TOKEN = <?= json_encode(csrf_token()) ?>;
  var ASK = <?= json_encode(url('app/assistant/ask')) ?>;
  var SUM = <?= json_encode(url('app/ai/summary')) ?>;
  var msgs = document.getElementById('aiMsgs');
  var form = document.getElementById('aiForm');
  var qEl = document.getElementById('aiQ');

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  function fmt(v) { if (v === null || v === undefined || v === '') return ''; var n = Number(String(v).replace(/,/g, '')); return isNaN(n) ? esc(v) : n.toLocaleString('fa-IR'); }
  function add(html, cls) { var d = document.createElement('div'); d.className = 'ai-msg ' + (cls || 'bot'); d.innerHTML = html; msgs.appendChild(d); msgs.scrollTop = msgs.scrollHeight; return d; }

  function renderResult(j) {
    var out = '';
    if (j.answer) out += '<div class="ai-answer">' + esc(j.answer).replace(/\n/g, '<br>') + '</div>';
    if (j.rows && j.rows.length) {
      var cols = Object.keys(j.rows[0]);
      var fa = j.columns_fa || {};
      var lbl = function (c) { return fa[c] || fa[String(c).toLowerCase()] || c; };
      out += '<div class="table-wrap" style="margin-top:10px"><table class="tbl" style="min-width:0"><thead><tr>';
      cols.forEach(function (c) { out += '<th>' + esc(lbl(c)) + '</th>'; });
      out += '</tr></thead><tbody>';
      j.rows.slice(0, 30).forEach(function (r) {
        out += '<tr>';
        cols.forEach(function (c) { out += '<td class="num">' + fmt(r[c]) + '</td>'; });
        out += '</tr>';
      });
      out += '</tbody></table></div>';
      out += '<div class="help">' + j.rows.length.toLocaleString('fa-IR') + ' ردیف</div>';

      if (j.chart && j.chart.x && j.chart.y && j.rows.length <= 30) {
        var vals = j.rows.map(function (r) { return Number(String(r[j.chart.y]).replace(/,/g, '')) || 0; });
        var max = Math.max.apply(null, vals.concat([1]));
        out += '<div class="bars" style="margin-top:10px">';
        j.rows.slice(0, 12).forEach(function (r) {
          var v = Number(String(r[j.chart.y]).replace(/,/g, '')) || 0;
          var xlbl = fa[j.chart.x] || j.chart.x;
          out += '<div class="bar-row"><div class="br-top"><span>' + esc(r[j.chart.x]) + '</span><b>' + fmt(v) + '</b></div>'
               + '<div class="bar-track"><div class="bar-fill" style="width:' + Math.max(3, Math.round(v / max * 100)) + '%"></div></div></div>';
        });
        out += '</div>';
      }
    }
    add(out || '<div class="muted">نتیجه‌ای نبود.</div>', 'bot');
  }

  function ask(q) {
    if (!q.trim()) return;
    add(esc(q), 'user');
    var wait = add('<span class="spinner"></span> در حال تحلیل داده…', 'bot thinking');
    fetch(ASK, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: '_token=' + encodeURIComponent(TOKEN) + '&question=' + encodeURIComponent(q) })
      .then(function (r) { return r.json(); })
      .then(function (j) { wait.remove(); if (!j.ok) { add('<div class="alert error">' + esc(j.error || 'خطا') + (j.detail ? '<br><span class="help">' + esc(j.detail) + '</span>' : '') + '</div>', 'bot'); return; } renderResult(j); })
      .catch(function () { wait.remove(); add('<div class="alert error">ارتباط با سرور برقرار نشد.</div>', 'bot'); });
  }

  form.addEventListener('submit', function (e) { e.preventDefault(); var q = qEl.value; qEl.value = ''; ask(q); });
  document.querySelectorAll('#aiSuggest .chip').forEach(function (b) { b.addEventListener('click', function () { ask(b.getAttribute('data-q')); }); });

  var sumBtn = document.getElementById('aiSummaryBtn');
  if (sumBtn) sumBtn.addEventListener('click', function () {
    var out = document.getElementById('aiSummary');
    out.innerHTML = '<div class="muted"><span class="spinner"></span> در حال ساخت خلاصه…</div>';
    fetch(SUM, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: '_token=' + encodeURIComponent(TOKEN) })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j.ok) { out.innerHTML = '<div class="alert error">' + esc(j.error || 'خطا') + '</div>'; return; }
        var h = '<div class="badge ' + (j.health === 'good' ? 'on' : (j.health === 'bad' ? 'off' : '')) + '" style="margin-bottom:8px">' + (j.health === 'good' ? 'وضعیت خوب' : (j.health === 'bad' ? 'نیازمند توجه' : 'قابل قبول')) + '</div>';
        h += '<div style="line-height:2">' + esc(j.summary).replace(/\n/g, '<br>') + '</div>';
        if (j.actions && j.actions.length) { h += '<div class="section-title" style="margin:12px 0 6px">اقدام پیشنهادی</div><ul class="ai-actions">'; j.actions.forEach(function (a) { h += '<li>' + esc(a) + '</li>'; }); h += '</ul>'; }
        out.innerHTML = h;
      })
      .catch(function () { out.innerHTML = '<div class="alert error">ارتباط برقرار نشد.</div>'; });
  });
})();
</script>
<?= view('partials/foot') ?>
