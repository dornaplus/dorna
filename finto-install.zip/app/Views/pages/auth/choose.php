<?php
/** صفحهٔ انتخاب سامانه — دو حالت: ثبت‌نام (register) و ورود (login) */
$variant = $variant ?? 'register';
$isLogin = $variant === 'login';
$proUrl  = $isLogin ? url('login?mode=pro') : url('register?mode=pro');
?>
<?= view('partials/public_head', ['title' => $title]) ?>
<div class="choose-wrap">
  <div class="choose-head">
    <div class="logo-mark">فن</div>
    <h1><?= $isLogin ? 'ورود به سامانه' : 'به فینتو خوش آمدید' ?></h1>
    <p class="lead"><?= $isLogin
      ? 'با کدام سامانه می‌خواهید وارد شوید؟ یکی را انتخاب کنید.'
      : 'کدام سامانه مناسب کسب‌وکار شماست؟ یکی را انتخاب کنید.' ?></p>
  </div>
  <div class="choose-grid">
    <a class="choose-card pro" href="<?= $proUrl ?>">
      <span class="cc-ic"><?= icon('warehouse', 30) ?></span>
      <b>حسابداری حرفه‌ای با انبارداری</b>
      <span class="cc-sub">مناسب شرکت‌ها، بازرگانی، تولیدی و پخش</span>
      <ul class="cc-feats">
        <li>اسناد حسابداری، دفتر روزنامه و ترازنامه</li>
        <li>انبارداری، کاردکس و انبارگردانی</li>
        <li>فروش و خرید، خزانه، چک و گزارش‌های مالی</li>
      </ul>
      <span class="cc-cta"><?= $isLogin ? 'ورود به نسخهٔ حرفه‌ای' : 'شروع نسخهٔ حرفه‌ای' ?> <?= icon('back', 15) ?></span>
    </a>
    <a class="choose-card shop" href="<?= url('fida/login') ?>">
      <span class="cc-ic"><?= icon('receipt', 30) ?></span>
      <b>فاکتورزنی فروشگاه کوچک</b>
      <span class="cc-sub">مناسب پیج‌های اینستاگرام و تلگرام و سایت‌های کوچک</span>
      <ul class="cc-feats">
        <li>صدور سریع فاکتور و پیش‌فاکتور</li>
        <li>مدیریت مشتریان و اقلام</li>
        <li>گزارش فروش — سبک، ساده و سریع</li>
      </ul>
      <span class="cc-cta">ورود به اپ فاکتور (فیدا) <?= icon('back', 15) ?></span>
    </a>
  </div>
  <div class="choose-foot">
    <?php if ($isLogin): ?>
      حساب کاربری ندارید؟ <a href="<?= url('register') ?>">ثبت‌نام کنید</a>
    <?php else: ?>
      حساب کاربری دارید؟ <a href="<?= url('login?mode=pro') ?>">وارد شوید</a>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/public_foot') ?>
