<?= view('partials/public_head', ['title' => $title]) ?>
<div class="auth-wrap">
  <aside class="auth-art">
    <div class="auth-logo">
      <div class="amark">فن</div>
      <div>
        <b style="font-family:var(--font2);font-size:18px;display:block;line-height:1.4">فینتو</b>
        <span style="font-size:11.5px;color:rgba(255,255,255,.72)">حسابداری و انبارداری</span>
      </div>
    </div>
    <div>
      <h1>کسب‌وکارتان را<br>هوشمندانه مدیریت کنید</h1>
      <p class="lead">نرم‌افزار یکپارچهٔ حسابداری، فروش، انبار، خزانه‌داری و گزارش‌های مالی — سریع، امن و ساده.</p>
      <div class="auth-feats">
        <div class="auth-feat"><span class="af-ic"><?= icon('receipt') ?></span><div><b>فاکتور و فروش</b><span>صدور و پیگیری</span></div></div>
        <div class="auth-feat"><span class="af-ic"><?= icon('box') ?></span><div><b>انبار هوشمند</b><span>موجودی و کاردکس</span></div></div>
        <div class="auth-feat"><span class="af-ic"><?= icon('bank') ?></span><div><b>خزانه و بانک</b><span>دریافت و پرداخت</span></div></div>
        <div class="auth-feat"><span class="af-ic"><?= icon('chart') ?></span><div><b>گزارش‌های مالی</b><span>ترازنامه و سود و زیان</span></div></div>
      </div>
    </div>
    <div style="font-size:11.5px;color:rgba(255,255,255,.66)">نسخه <?= e(config('app')['version']) ?> — نرم‌افزار حسابداری فینتو</div>
  </aside>

  <div class="auth-panel">
    <div class="auth-card">
      <div style="text-align:center;margin-bottom:18px">
        <div style="width:56px;height:56px;border-radius:18px;background:linear-gradient(135deg,var(--p-600),var(--p-400));color:#fff;display:grid;place-items:center;font-size:22px;font-weight:700;margin:0 auto 10px">فن</div>
        <h2 style="font-family:var(--font2);margin:0 0 4px">ورود به نرم‌افزار فینتو</h2>
        <div class="a-sub">سامانه حسابداری، انبارداری و فروش</div>
      </div>
      <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
      <?php if (config('app')['demo_mode']): ?>
        <div class="alert info small">کاربران نمونه: <b>09120000001</b> تا <b>09120000004</b> — رمز: <b>demo1234</b></div>
      <?php endif; ?>
      <form method="post" action="<?= url('login') ?>">
        <?= csrf_field() ?>
        <div class="field"><label>موبایل یا ایمیل</label>
          <input class="inp" type="text" name="mobile" value="<?= e(Flash::old('mobile')) ?>" placeholder="09121234567" required autofocus></div>
        <div class="field"><label>کلمه عبور</label>
          <div class="input-wrap">
            <input class="inp" id="login-pass" type="password" name="password" placeholder="••••••••" required>
            <button type="button" class="toggle-pass" data-toggle-pass="login-pass" aria-label="نمایش رمز" title="نمایش رمز"><?= icon('eye', 18) ?></button>
          </div>
        </div>
        <button class="btn block" type="submit">ورود</button>
      </form>
      <div style="display:flex;justify-content:space-between;margin-top:16px;font-size:12.5px">
        <a href="<?= url('forgot') ?>">رمز عبورم را فراموش کرده‌ام</a>
        <a href="<?= url('register') ?>">ثبت‌نام کنید</a>
      </div>
    </div>
    <div class="small muted"><a href="<?= url('/') ?>">← بازگشت به صفحه اصلی</a></div>
  </div>
</div>
<?= view('partials/public_foot') ?>
