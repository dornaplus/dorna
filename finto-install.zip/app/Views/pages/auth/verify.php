<?= view('partials/public_head', ['title' => $title]) ?>
<div class="public">
  <div class="auth-card">
    <div class="steps">
      <div class="s on"><i>۱</i> شماره موبایل</div>
      <div class="s on"><i>۲</i> کد تایید</div>
      <div class="s"><i>۳</i> اطلاعات شخصی</div>
      <div class="s"><i>۴</i> کسب‌وکار</div>
    </div>
    <h2>کد تایید را وارد کنید</h2>
    <div class="sub">کد ۶ رقمی ارسال‌شده به شماره <b style="direction:ltr;display:inline-block"><?= e($mobile) ?></b> را وارد کنید.</div>
    <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
    <?php if (!empty($info)): ?><div class="alert info small"><?= e($info) ?></div><?php endif; ?>
    <?php $send = $_SESSION['_otp_send'] ?? null; if ($send && empty($send['ok'])): ?>
      <div class="alert warn small">پیامک کد تایید ارسال نشد<?= !empty($send['ip_restricted']) ? ' — IP این سرور در کاوه‌نگار مجاز نیست (در پنل کاوه‌نگار → تنظیمات امنیتی، IP سرور را اضافه کنید)' : '' ?><?= !empty($send['message']) ? ' — ' . e($send['message']) : '' ?>.</div>
    <?php endif; ?>
    <form method="post" action="<?= url('verify') ?>">
      <?= csrf_field() ?>
      <div class="field"><label>کد تایید</label>
        <input class="inp otp-input" type="text" name="code" inputmode="numeric" placeholder="______" maxlength="6" required autofocus></div>
      <button class="btn" style="width:100%;justify-content:center">تایید و ادامه</button>
    </form>
    <form method="post" action="<?= url('verify/resend') ?>" style="margin-top:12px;text-align:center">
      <?= csrf_field() ?>
      <button class="btn ghost sm" type="submit">ارسال مجدد کد</button>
    </form>
    <div style="text-align:center;margin-top:12px;font-size:12.5px"><a href="<?= url('register') ?>">تغییر شماره موبایل</a></div>
  </div>
</div>
<?= view('partials/public_foot') ?>
