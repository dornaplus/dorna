<?= view('partials/head', ['title' => $title]) ?>
<?php
$st = $state ?? []; $feats = Billing::FEATURES; $cur = Auth::currency();
$active = !empty($st['is_active']);
$money = fn($v) => num((float)$v);
?>
<div class="pkg-wrap">

  <!-- ═══ هیرو ═══ -->
  <section class="pkg-hero">
    <span class="pkg-pill">👑 اشتراک فینتو · پیشنهاد ویژه</span>
    <h2><?= $active ? 'اشتراک شما فعال است — خیالت راحت!' : 'همهٔ فینتو، بدون محدودیت، با یک اشتراک' ?></h2>
    <p class="lead">
      <?php if ($active): ?>
        پکیج «<?= e((string)($st['plan_title'] ?? '')) ?>» تا <b><?= e(jdate((string)$st['expires_at'])) ?></b> اعتبار دارد
        (<?= num((int)$st['days_left']) ?> روز باقی‌مانده). هر وقت خواستی می‌توانی تمدید یا پکیج بلندمدت‌تری انتخاب کنی.
      <?php else: ?>
        حسابداری، انبار، بانکداری، حقوق و دستمزد و گزارشات — همه با <b>سطر و سند نامحدود</b>.
        اگر این مدت از فینتو راضی بودی، همین حالا اشتراک رو فعال کن و کار کسب‌وکارت رو بدون وقفه ادامه بده.
      <?php endif; ?>
    </p>
    <div class="pkg-status">
      <?php if ($active): ?>
        <span class="pkg-chip ok">✅ فعال تا <?= e(jdate((string)$st['expires_at'])) ?></span>
        <span class="pkg-chip">📦 <?= e((string)($st['plan_title'] ?? '')) ?></span>
      <?php else: ?>
        <span class="pkg-chip">🔒 بدون اشتراک فعال — ثبت اطلاعات و گزارش‌ها قفل است</span>
      <?php endif; ?>
      <a class="pkg-chip" href="<?= url('app/subscription') ?>" style="text-decoration:none">🧾 سابقهٔ پرداخت‌ها</a>
    </div>
    <div class="pkg-feats">
      <?php foreach ($feats as $f): ?>
        <div class="pkg-feat">
          <i class="ic"><?= $f['icon'] ?></i>
          <span class="tx"><b><?= e($f['title']) ?></b><small><?= e($f['hint']) ?></small></span>
          <b class="tick">✔</b>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- ═══ پکیج‌ها ═══ -->
  <div class="pkg-section-title">💳 پکیج‌های اشتراک <span class="muted small">— هر سه پکیج، دسترسی کامل به همهٔ امکانات</span></div>
  <div class="pkg-grid">
    <?php foreach ($plans as $pl):
        $months = max(1, (int)($pl['duration_months'] ?? 12));
        $price = (float)$pl['price_amount'];
        $per = (int)round($price / $months);
        $best = !empty($pl['is_popular']);
        $saveLabel = $months >= 12 ? '🎁 معادل دو ماه هدیه' : ($months >= 6 ? '🎁 یک ماه صرفه‌جویی' : '🚀 شروع سبک و کم‌هزینه');
    ?>
      <article class="pkg-card<?= $best ? ' best' : '' ?>">
        <?php if ($best): ?><span class="ribbon">پیشنهاد ما</span><?php endif; ?>
        <div class="ttl"><?= e($pl['title']) ?></div>
        <div class="sub"><?= e((string)($pl['description'] ?? '')) ?></div>
        <div class="pkg-price"><span class="num"><?= $money($price) ?></span><span class="cur">تومان</span></div>
        <div class="pkg-per">معادل <b><?= num($per) ?></b> تومان در ماه</div>
        <span class="pkg-save"><?= $saveLabel ?></span>
        <ul class="pkg-list">
          <li><span class="tick">✔</span> دسترسی کامل به همهٔ بخش‌ها و گزارشات</li>
          <li><span class="tick">✔</span> سطر و سند <b>نامحدود</b> (فاکتور، انبار، حسابداری)</li>
          <li><span class="tick">✔</span> کاربر و نقش <b>نامحدود</b> با سطح دسترسی دلخواه</li>
          <li><span class="tick">✔</span> پشتیبان‌گیری امن و پشتیبانی ویژه</li>
        </ul>
        <div class="pkg-cta">
          <form method="post" action="<?= url('app/plans/' . (int)$pl['id'] . '/subscribe') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="gateway" value="internal">
            <button class="btn <?= $best ? 'btn-p' : 'btn-g' ?>" type="submit">
              <?= $active ? 'تمدید ' . e($pl['title']) : 'فعال‌سازی ' . e($pl['title']) ?>
            </button>
          </form>
          <div class="pkg-note">پرداخت آزمایشی داخلی · فعال‌سازی فوری</div>
        </div>
      </article>
    <?php endforeach; ?>
  </div>

  <!-- ═══ مزیت‌ها ═══ -->
  <div class="pkg-trust">
    <div class="t"><i>⚡</i><div><b>فعال‌سازی فوری</b><small>بعد از تأیید، همهٔ بخش‌ها بلافاصله باز می‌شوند.</small></div></div>
    <div class="t"><i>🧮</i><div><b>حسابداری اصولی</b><small>اسناد خودکار، تراز، سود و زیان و جریان نقدی.</small></div></div>
    <div class="t"><i>🔐</i><div><b>داده‌های شما، مال شما</b><small>هر کسب‌وکار کاملاً مستقل و جدا از بقیه است.</small></div></div>
    <div class="t"><i>☁️</i><div><b>پشتیبان‌گیری</b><small>فایل پشتیبان کامل + خروجی CSV همهٔ بخش‌ها.</small></div></div>
  </div>

  <!-- ═══ پرسش‌های پرتکرار ═══ -->
  <div class="pkg-faq">
    <details open><summary>وجه اشتراک بابت چیست؟</summary><p>دسترسی به همهٔ امکانات نرم‌افزار با سطر و سند نامحدود، پشتیبان‌گیری، پشتیبانی و به‌روزرسانی‌ها. هیچ هزینهٔ پنهانی وجود ندارد.</p></details>
    <details><summary>اگر اشتراکم تمام شود چه می‌شود؟</summary><p>داده‌های شما محفوظ می‌ماند اما <b>ثبت اطلاعات و مشاهدهٔ گزارش‌ها قفل</b> می‌شود؛ با فعال‌سازی اشتراک همه‌چیز بلافاصله برمی‌گردد.</p></details>
    <details><summary>می‌توانم بعداً به پکیج بلندمدت‌تر تغییر دهم؟</summary><p>بله. هنگام تمدید، از آخرین روز اعتبار فعلی محاسبه می‌شود و پکیج جدید از همان‌جا ادامه پیدا می‌کند.</p></details>
    <details><summary>کاربر و نقش‌ها محدودیتی دارند؟</summary><p>خیر؛ تعداد کاربران و نقش‌ها با سطح دسترسی دلخواه <b>نامحدود</b> است.</p></details>
  </div>

</div>
<?= view('partials/foot') ?>
