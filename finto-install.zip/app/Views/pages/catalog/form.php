<?= view('partials/head', ['title' => $title]) ?>
<?php $row = array_merge($row ?? [], $_SESSION['_old'] ?? []); ?>
<form method="post" action="<?= e($action) ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/products') ?>">فهرست کالاها</a></div>
    <?php if (!empty($autoCodeNext)): ?>
      <div class="ac-bar">
        <label class="ac-line" for="autoCode">
          <input type="checkbox" id="autoCode" name="auto_code" value="1" checked>
          <span class="ac-txt">
            <span class="ac-title">کد کالا خودکار
              <i class="ac-chip" id="autoCodeChip">پیشنهاد: <?= e(fa_digits((string)$autoCodeNext)) ?></i>
            </span>
            <small>آخرین کد کالای این کسب‌وکار + ۱ پیشنهاد می‌شود. برای ورود دستی، تیک را بردارید.</small>
          </span>
        </label>
      </div>
    <?php endif; ?>
    <?php foreach ($groups as $gtitle => $fields): ?>
      <div class="section-title"><?= e($gtitle) ?></div>
      <div class="form-grid">
        <?php foreach ($fields as $f): ?><?= Fields::render($f, $row[$f['name']] ?? null, ['row' => $row]) ?><?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="grid c2">
    <div class="card">
      <div class="card-head"><h3>مالیات پیش‌فرض فروش</h3></div>
      <div class="form-grid">
        <div class="field"><label>نوع مالیات</label>
          <select class="inp" name="tax_id"><option value="">— بدون مالیات —</option>
            <?php foreach (Database::all('SELECT id,title,rate_percent FROM taxes WHERE business_id=? AND is_active=1 ORDER BY id', [Auth::businessId()]) as $t): ?>
              <option value="<?= $t['id'] ?>" <?= (string)($selectedTax ?? '') === (string)$t['id'] ? 'selected' : '' ?>><?= e($t['title'].' ('.$t['rate_percent'].'٪)') ?></option>
            <?php endforeach; ?></select></div>
      </div>
      <div class="alert info">نرخ مالیات در فاکتور فروش به‌صورت پیش‌فرض همین مقدار خواهد بود و در هر فاکتور قابل تغییر است.</div>
    </div>
    <div class="card">
      <div class="card-head"><h3>قیمت‌های کالا</h3><span class="pill"><?= num(count($priceTypes)) ?> نوع قیمت</span></div>
      <div class="form-grid">
        <?php foreach ($priceTypes as $pt): $pv = 0; foreach ($prices as $pp) if ((int)$pp['price_type_id'] === (int)$pt['id']) $pv = $pp['price']; ?>
          <div class="field"><label><?= e($pt['title_fa']) ?><?= !empty($pt['is_default']) ? ' (پیش‌فرض)' : '' ?></label>
            <input class="inp money" type="text" name="price[<?= (int)$pt['id'] ?>]" value="<?= $pv > 0 ? e(num((float)$pv)) : '' ?>" placeholder="۰">
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>

  <?php if ($units): ?>
  <div class="card">
    <div class="card-head"><h3>واحدهای این کالا</h3></div>
    <div class="table-wrap"><table class="tbl" style="min-width:420px">
      <thead><tr><th>واحد</th><th>ضریب تبدیل</th><th>بارکد</th></tr></thead>
      <tbody><?php foreach ($units as $u): ?>
        <tr><td><?= e($u['unit_title']) ?></td><td class="num"><?= num($u['factor'], 2) ?></td><td><?= e($u['barcode'] ?? '—') ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <div class="hint">برای تعریف واحد فرعی جدید به <a href="<?= url('app/units') ?>">واحدهای شمارش</a> بروید.</div>
  </div>
  <?php endif; ?>

  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn"><?= empty($row['id']) ? 'ثبت کالا / خدمت' : 'ذخیره تغییرات' ?></button>
    <a class="btn gray" href="<?= url('app/products') ?>">انصراف</a>
  </div></div>
</form>
<script>
(function () {
    var cb = document.getElementById('autoCode');
    var input = document.querySelector('[name="code"]');
    if (!cb || !input) return;
    var next = <?= json_encode((string)($autoCodeNext ?? ''), JSON_UNESCAPED_UNICODE) ?>;
    function fa(v) { return String(v == null ? '' : v).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }); }
    function sync() {
        if (cb.checked) {
            if (!input.value || input.dataset.auto === '1') input.value = next;
            input.dataset.auto = '1';
            input.readOnly = true;
            input.classList.add('is-auto');
            var chip = document.getElementById('autoCodeChip');
            if (chip) chip.textContent = 'پیشنهاد: ' + fa(next);
        } else {
            if (input.dataset.auto === '1') input.value = '';
            input.dataset.auto = '0';
            input.readOnly = false;
            input.classList.remove('is-auto');
            input.focus();
        }
    }
    cb.addEventListener('change', sync);
    sync();
})();
</script>
<?= view('partials/foot') ?>
