<?= view('partials/head', ['title' => $title]) ?>
<?php
$hasFilter = $f['q'] !== '' || $f['ext'] !== '' || $f['size'] !== '' || $f['locked'] !== '' || $f['from'] !== '' || $f['to'] !== '' || $f['user_id'] > 0;
$qs = fn(array $over = []) => url('app/documents') . '?' . http_build_query(array_merge($f, $over));
?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('folder', 20) ?> اسناد من</h2>
    <span class="muted small">آرشیو شخصی فایل‌ها با رمزگذاری اختیاری<?= $isAdmin ? ' — نمای مدیر (همهٔ کاربران)' : '' ?></span>
  </div>
  <div class="page-head-actions">
    <button class="btn" type="button" id="docUploadToggle"><?= icon('upload', 16) ?> آپلود سند جدید</button>
  </div>
</div>

<div class="doc-stats">
  <div class="doc-stat"><span class="doc-stat-ic"><?= icon('file', 18) ?></span><div><b><?= num($stats['count']) ?></b><small>سند</small></div></div>
  <div class="doc-stat"><span class="doc-stat-ic"><?= icon('box', 18) ?></span><div><b><?= e(UserDocument::humanSize($stats['bytes'])) ?></b><small>حجم کل</small></div></div>
  <div class="doc-stat"><span class="doc-stat-ic"><?= icon('lock', 18) ?></span><div><b><?= num($stats['locked']) ?></b><small>قفل‌شده</small></div></div>
</div>

<a class="stor-mini" href="<?= url('app/storage') ?>">
  <div class="stor-mini-l"><span><?= icon('box', 15) ?> فضای ذخیره‌سازی: <?= e(StorageQuota::human($storageUsed)) ?> از <?= e(StorageQuota::human($storageQuota)) ?></span><b><?= num($storagePct, 1) ?>٪</b></div>
  <div class="stor-bar"><i style="width:<?= (float)$storagePct ?>%"></i></div>
</a>

<div class="card" id="docUpload" hidden>
  <div class="card-head"><h3>آپلود سند جدید</h3><div class="grow"></div><span class="muted small">حداکثر <?= num((int)round(UserDocument::MAX_SIZE / 1048576)) ?> مگابایت — PDF، تصویر یا هر فایل دیگر</span></div>
  <form method="post" action="<?= url('app/documents') ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div class="form-grid">
      <div class="field"><label>عنوان سند <span class="req">*</span></label><input class="inp" type="text" name="title" placeholder="مثلاً قرارداد فروش، فاکتور، اسکن مدرک…" maxlength="190" required></div>
      <div class="field"><label>فایل <span class="req">*</span></label><input class="inp" type="file" name="file" required></div>
      <div class="field w2"><label>توضیحات</label><textarea class="inp" name="description" rows="2" placeholder="توضیح کوتاه دربارهٔ این سند (اختیاری)"></textarea></div>
      <div class="field">
        <label class="doc-lock-toggle"><input type="checkbox" id="docLockChk" onchange="document.getElementById('docLockRow').hidden = !this.checked"> <span><?= icon('lock', 15) ?> قفل با رمز عبور</span></label>
      </div>
      <div class="field" id="docLockRow" hidden><label>رمز عبور</label><input class="inp" type="password" name="password" id="docPassword" placeholder="حداقل ۴ کاراکتر" minlength="4"></div>
    </div>
    <div class="form-actions"><button class="btn"><?= icon('check', 16) ?> ذخیره سند</button>
      <button class="btn gray" type="button" onclick="document.getElementById('docUpload').hidden=true">انصراف</button></div>
  </form>
</div>

<form class="doc-filters" method="get" action="<?= url('app/documents') ?>">
  <div class="doc-search"><span class="mag"><?= icon('search', 16) ?></span>
    <input class="inp" type="search" name="q" value="<?= e($f['q']) ?>" placeholder="جست‌وجو در عنوان، توضیح یا نام فایل…"></div>
  <select class="inp" name="ext">
    <option value="">همهٔ پسوندها</option>
    <?php foreach ($exts as $x): ?><option value="<?= e($x) ?>" <?= $f['ext'] === $x ? 'selected' : '' ?>><?= e(strtoupper($x)) ?></option><?php endforeach; ?>
  </select>
  <select class="inp" name="size">
    <option value="">همهٔ حجم‌ها</option>
    <option value="small" <?= $f['size'] === 'small' ? 'selected' : '' ?>>کمتر از ۱ مگابایت</option>
    <option value="medium" <?= $f['size'] === 'medium' ? 'selected' : '' ?>>۱ تا ۱۰ مگابایت</option>
    <option value="large" <?= $f['size'] === 'large' ? 'selected' : '' ?>>بیش از ۱۰ مگابایت</option>
  </select>
  <select class="inp" name="locked">
    <option value="">همه (قفل و آزاد)</option>
    <option value="yes" <?= $f['locked'] === 'yes' ? 'selected' : '' ?>>فقط قفل‌شده</option>
    <option value="no" <?= $f['locked'] === 'no' ? 'selected' : '' ?>>فقط آزاد</option>
  </select>
  <?php if ($isAdmin): ?>
  <select class="inp" name="user_id">
    <option value="">همهٔ کاربران</option>
    <?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>" <?= $f['user_id'] === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?> (<?= num((int)$u['cnt']) ?>)</option><?php endforeach; ?>
  </select>
  <?php endif; ?>
  <select class="inp" name="sort">
    <option value="created_desc" <?= $f['sort'] === 'created_desc' ? 'selected' : '' ?>>جدیدترین</option>
    <option value="created_asc" <?= $f['sort'] === 'created_asc' ? 'selected' : '' ?>>قدیمی‌ترین</option>
    <option value="title_asc" <?= $f['sort'] === 'title_asc' ? 'selected' : '' ?>>نام (الفبا)</option>
    <option value="ext_asc" <?= $f['sort'] === 'ext_asc' ? 'selected' : '' ?>>پسوند</option>
    <option value="size_desc" <?= $f['sort'] === 'size_desc' ? 'selected' : '' ?>>حجم (بزرگ‌تر)</option>
    <option value="size_asc" <?= $f['sort'] === 'size_asc' ? 'selected' : '' ?>>حجم (کوچک‌تر)</option>
  </select>
  <input class="inp" type="text" name="from" value="<?= e($f['from']) ?>" placeholder="از تاریخ" data-jalali>
  <input class="inp" type="text" name="to" value="<?= e($f['to']) ?>" placeholder="تا تاریخ" data-jalali>
  <button class="btn sm">اعمال فیلتر</button>
  <?php if ($hasFilter): ?><a class="btn gray sm" href="<?= url('app/documents') ?>">حذف فیلترها</a><?php endif; ?>
</form>

<?php if (!$rows): ?>
  <div class="doc-empty">
    <div style="font-size:34px">🗂️</div>
    <b>هنوز سندی ذخیره نکرده‌اید</b>
    <p class="muted small">روی «آپلود سند جدید» بزنید و فایل (PDF، عکس، Word، Excel، ZIP و…) را با عنوان و توضیح ذخیره کنید. می‌توانید روی آن رمز هم بگذارید.</p>
  </div>
<?php else: ?>
  <div class="doc-grid">
    <?php foreach ($rows as $d):
      [$ic, $lbl] = UserDocument::kind((string)$d['ext']);
      $locked = (int)$d['is_encrypted'] === 1;
    ?>
    <div class="doc-card">
      <div class="doc-card-top">
        <span class="doc-ic"><?= icon($ic, 22) ?></span>
        <div class="doc-t"><b title="<?= e($d['title']) ?>"><?= e($d['title']) ?></b>
          <small class="muted"><?= e(strtoupper((string)$d['ext'])) ?> · <?= e(UserDocument::humanSize($d['size_bytes'])) ?></small></div>
        <?php if ($locked): ?><span class="doc-lock" title="قفل با رمز"><?= icon('lock', 14) ?></span><?php endif; ?>
      </div>
      <?php if (trim((string)$d['description']) !== ''): ?><p class="doc-desc"><?= e(mb_strimwidth((string)$d['description'], 0, 120, '…')) ?></p><?php endif; ?>
      <div class="doc-file"><?= icon('file', 13) ?> <?= e(mb_strimwidth((string)$d['file_name'], 0, 46, '…')) ?></div>
      <div class="doc-card-foot">
        <span class="doc-meta">
          <?php if ($isAdmin): ?><?= Avatar::html((string)$d['owner_name'], (string)$d['owner_avatar'], 'pm-av', 20) ?> <b><?= e($d['owner_name']) ?></b> · <?php endif; ?>
          <?= e(jdate((string)$d['created_at'], '/')) ?>
        </span>
        <div class="doc-acts">
          <a class="btn soft sm" href="<?= url('app/documents/' . (int)$d['id'] . '/download') ?>" <?= $locked && !$isAdmin ? '' : 'download' ?>><?= $locked && !$isAdmin ? icon('key', 14) : icon('download', 14) ?> <?= $locked && !$isAdmin ? 'بازگشایی' : 'دانلود' ?></a>
          <form method="post" action="<?= url('app/documents/' . (int)$d['id'] . '/delete') ?>" onsubmit="return confirm('این سند حذف شود؟')" style="margin:0"><?= csrf_field() ?><button class="btn danger sm" type="submit"><?= icon('trash', 14) ?></button></form>
        </div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<script>
(function () {
  var t = document.getElementById('docUploadToggle'), u = document.getElementById('docUpload');
  if (t && u) t.addEventListener('click', function () { u.hidden = !u.hidden; if (!u.hidden) u.querySelector('input[name=title]').focus(); });
})();
</script>
<?= view('partials/foot') ?>
