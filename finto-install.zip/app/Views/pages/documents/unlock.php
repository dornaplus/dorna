<?= view('partials/public_head', ['title' => $title]) ?>
<div class="auth-wrap" style="min-height:100vh">
  <div class="auth-panel" style="max-width:460px;margin:0 auto">
    <div class="auth-card" style="text-align:center">
      <div style="width:60px;height:60px;border-radius:18px;background:linear-gradient(135deg,#8B5CF6,#6D28D9);color:#fff;display:grid;place-items:center;margin:0 auto 14px"><?= icon('lock', 26) ?></div>
      <h2 style="font-family:var(--font2);margin:0 0 6px">این سند قفل است</h2>
      <div class="a-sub" style="margin-bottom:16px">برای دانلود «<?= e($doc['title']) ?>» رمز را وارد کنید.</div>

      <div class="card tight" style="text-align:right;margin-bottom:16px">
        <div style="display:flex;align-items:center;gap:10px">
          <?php [$ic, $lbl] = UserDocument::kind((string)$doc['ext']); ?>
          <span style="width:40px;height:40px;border-radius:12px;background:var(--p100);color:var(--p700);display:grid;place-items:center;flex:0 0 auto"><?= icon($ic, 20) ?></span>
          <div style="min-width:0">
            <div style="font-weight:700;font-size:13.4px"><?= e($doc['file_name']) ?></div>
            <div class="muted small"><?= e(UserDocument::humanSize($doc['size_bytes'])) ?> · <?= e(strtoupper((string)$doc['ext'])) ?></div>
          </div>
        </div>
      </div>

      <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

      <form method="post" action="<?= url('app/documents/' . (int)$doc['id'] . '/download') ?>">
        <?= csrf_field() ?>
        <div class="field" style="text-align:right"><label>رمز سند</label>
          <input class="inp" type="password" name="password" placeholder="••••••••" required autofocus></div>
        <button class="btn block" type="submit"><?= icon('key', 16) ?> بازگشایی و دانلود</button>
      </form>

      <div style="margin-top:14px;font-size:12.5px"><a href="<?= url('app/documents') ?>">← بازگشت به اسناد</a></div>
    </div>
  </div>
</div>
<?= view('partials/public_foot') ?>
