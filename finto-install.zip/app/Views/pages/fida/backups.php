<?= view('partials/fida_head', ['title' => $title ?? 'پشتیبان‌گیری و بازیابی']) ?>
<?php
$st = ['success' => ['c-done', 'آماده'], 'running' => ['c-wait', 'در حال ساخت'], 'failed' => ['c-danger', 'ناموفق']];
$totalRows = array_sum($counts);
$bulk = array_filter($labels, fn($k) => ($counts[$k] ?? 0) > 0, ARRAY_FILTER_USE_KEY);
?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">پشتیبان‌گیری و بازیابی
    <a class="m" href="<?= url('fida/settings') ?>">← تنظیمات</a></h2>

  <div class="card">
    <div class="stats bk-stats">
      <div class="stat g wide"><div class="k">داده‌های پروفایل شما</div><div class="v"><?= num($totalRows) ?> <small>ردیف</small></div></div>
      <div class="stat"><div class="k">اشخاص</div><div class="v"><?= num($counts['fida_persons'] ?? 0) ?></div></div>
      <div class="stat"><div class="k">فاکتورها</div><div class="v"><?= num($counts['fida_invoices'] ?? 0) ?></div></div>
      <div class="stat"><div class="k">کالا و خدمات</div><div class="v"><?= num($counts['fida_items'] ?? 0) ?></div></div>
      <div class="stat"><div class="k">چک‌ها</div><div class="v"><?= num($counts['fida_cheques'] ?? 0) ?></div></div>
    </div>
  </div>

  <div class="bk-actions">
    <button class="qk" type="button" onclick="document.getElementById('mkBackup').submit()">
      <span class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></span>
      <span>گرفتن پشتیبان جدید</span></button>
    <button class="qk" type="button" onclick="document.getElementById('impFile').click()">
      <span class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4M8 8l4-4 4 4M4 16v3.5h16V16"/></svg></span>
      <span>بازیابی از فایل</span></button>
  </div>
  <form method="post" action="<?= url('fida/backups') ?>" id="mkBackup"><?= csrf_field() ?></form>

  <div class="card">
    <div class="card-head"><b>📚 پشتیبان‌های من</b><span class="muted small"><?= num(count($jobs)) ?> مورد</span></div>
    <?php if (!$jobs): ?>
      <div class="bk-empty">هنوز پشتیبانی نگرفته‌اید.<br>با «گرفتن پشتیبان جدید» یک نسخهٔ کامل از داده‌های خودتان بسازید.</div>
    <?php else: foreach ($jobs as $j): [$cls, $lbl] = $st[$j['status']] ?? ['c-pre', $j['status']]; ?>
      <div class="bk-card">
        <div class="bk-card-top">
          <span class="thumb">🗄️</span>
          <div class="bk-m">
            <b>پشتیبان #<?= num($j['id']) ?></b>
            <small><?= e(jdate((string)($j['created_at'] ?? today()))) ?> · <?= num((float)$j['size_mb'], 2) ?> مگابایت · <?= num($j['row_count']) ?> ردیف<?= $j['error_message'] ? '<br>' . e((string)$j['error_message']) : '' ?></small>
            <div class="bk-chips">
              <span class="chip <?= $cls ?>"><?= e($lbl) ?></span>
              <span class="chip"><?= $j['job_type'] === 'auto' ? 'خودکار' : 'دستی' ?></span>
            </div>
          </div>
        </div>
        <div class="bk-btns">
          <a class="btn btn-p" href="<?= url('fida/backups/' . (int)$j['id'] . '/download?format=json') ?>">JSON</a>
          <a class="btn btn-g" href="<?= url('fida/backups/' . (int)$j['id'] . '/download?format=csv') ?>">CSV</a>
          <form method="post" action="<?= url('fida/backups/' . (int)$j['id'] . '/delete') ?>" onsubmit="return confirm('این پشتیبان حذف شود؟')">
            <?= csrf_field() ?><button class="btn btn-danger" type="submit">حذف</button>
          </form>
        </div>
      </div>
    <?php endforeach; endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><b>📥 بازیابی از فایل</b></div>
    <form method="post" action="<?= url('fida/backups/import') ?>" enctype="multipart/form-data" class="bk-upload"
          onsubmit="return confirm('داده‌های فعلی پروفایل شما با محتوای این فایل جایگزین می‌شود. ادامه؟')">
      <?= csrf_field() ?>
      <div class="field" style="margin:0">
        <label>فایل پشتیبان (JSON یا CSV همین سامانه)</label>
        <input type="file" name="backup_file" id="impFile" accept=".json,.csv,application/json,text/csv" required>
      </div>
      <div class="bk-note-box">
        پیش از بازیابی، خودکار یک <b>پشتیبان ایمنی</b> از وضعیت فعلی گرفته می‌شود.<br>
        فایل پشتیبان هر کاربر فقط روی همان پروفایل قابل بازیابی است.
      </div>
      <div class="bk-foot">
        <button class="btn btn-p" type="submit">شروع بازیابی</button>
        <a class="btn btn-g" href="<?= url('fida/settings') ?>">انصراف</a>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-head"><b>ℹ️ چه چیزی پشتیبان می‌شود؟</b></div>
    <div class="bk-info">
      <?php foreach ($bulk as $t => $lbl): ?>
        <span class="chip"><?= e($lbl) ?>: <?= num($counts[$t]) ?></span>
      <?php endforeach; ?>
      <?php if (!$bulk): ?><span class="chip">هنوز داده‌ای ثبت نشده است</span><?php endif; ?>
    </div>
    <div class="bk-note">
      داده‌ها بیرون از پوشهٔ وب ذخیره می‌شوند و هیچ کاربری به پشتیبان کاربر دیگر دسترسی ندارد.
      فایل CSV برای مشاهده در اکسل (همهٔ بخش‌ها در یک فایل) و فایل JSON برای بازگردانی دقیق است.
    </div>
  </div>
</section>
<?= view('partials/fida_foot') ?>
