<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$months = Fida::JALALI_MONTHS; $wd = Fida::WEEKDAYS; $icons = Fida::EVENT_KINDS_ICON;
$prevM = $jm - 1; $prevY = $jy; if ($prevM < 1) { $prevM = 12; $prevY--; }
$nextM = $jm + 1; $nextY = $jy; if ($nextM > 12) { $nextM = 1; $nextY++; }
[$ty, $tm, $td] = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'));
$selJal = jdate($sel);
$selEvents = $dayEvents;
?>
<section class="panel on">
  <div class="cal-head">
    <button class="icon-btn sm" type="button" onclick="location.href='<?= url('fida/calendar?y=' . $nextY . '&m=' . $nextM) ?>'" aria-label="ماه بعد">‹</button>
    <div class="cal-title">
      <b><?= e($months[$jm - 1]) ?> <?= num($jy) ?></b>
      <small>📌 <?= num($monthCount) ?> رویداد در این ماه · امروز <?= e(jdate(today())) ?></small>
    </div>
    <button class="icon-btn sm" type="button" onclick="location.href='<?= url('fida/calendar?y=' . $prevY . '&m=' . $prevM) ?>'" aria-label="ماه قبل">›</button>
  </div>
  <div class="cal-tools">
    <button class="btn sm btn-g" type="button" onclick="location.href='<?= url('fida/calendar?y=' . $ty . '&m=' . $tm . '&d=' . $td . '/' . $tm . '/' . $td) ?>'">📅 امروز</button>
    <button class="btn sm" type="button" onclick="calNew('<?= e($selJal) ?>')">＋ رویداد جدید</button>
    <span class="muted small"><?= num(count($todayEvents)) ?> رویداد امروز</span>
  </div>

  <div class="cal-card">
    <div class="cal-week"><?php foreach ($wd as $i => $w): ?><span class="<?= $i === 6 ? 'hol' : '' ?>"><?= e($w) ?></span><?php endforeach; ?></div>
    <div class="cal-grid">
      <?php foreach ($grid as $c): $isSel = $c['date'] === $sel; ?>
        <a class="cal-day<?= $c['in_month'] ? '' : ' out' ?><?= $c['is_today'] ? ' today' : '' ?><?= $c['is_holiday'] ? ' hol' : '' ?><?= $isSel ? ' sel' : '' ?><?= !empty($c['events']) ? ' has' : '' ?>"
           href="<?= url('fida/calendar?y=' . $jy . '&m=' . $jm . '&d=' . $c['jd'] . '/' . $c['jm'] . '/' . $c['jy']) ?>">
          <span class="cd-n"><?= num($c['jd']) ?></span>
          <span class="cd-ev">
            <?php foreach (array_slice($c['events'], 0, 2) as $ev): ?>
              <i class="cd-chip<?= !empty($ev['is_done']) ? ' done' : '' ?><?= $ev['priority'] === 'high' ? ' hi' : '' ?>"><?= $icons[$ev['kind']] ?? '📌' ?><?= e(mb_substr((string)$ev['title'], 0, 9)) ?></i>
            <?php endforeach; ?>
            <?php if (count($c['events']) > 2): ?><i class="cd-more">+<?= num(count($c['events']) - 2) ?></i><?php endif; ?>
          </span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- رویدادهای روز انتخاب‌شده -->
  <div class="card cal-day-card">
    <div class="card-head" style="display:flex;align-items:center;gap:8px">
      <h3 style="margin:0;font-size:14px">🗓️ <?= e($selJal) ?><?= $sel === today() ? ' (امروز)' : '' ?></h3>
      <div class="grow"></div>
      <button class="btn sm" type="button" onclick="calNew('<?= e($selJal) ?>')">＋ افزودن</button>
    </div>
    <?php if (!$selEvents): ?>
      <div class="muted small" style="padding:6px 2px">برای این روز رویدادی ثبت نشده — با «＋ افزودن» یک یادآوری بساز.</div>
    <?php else: ?>
      <?php foreach ($selEvents as $ev): ?>
        <div class="ev-row<?= !empty($ev['is_done']) ? ' done' : '' ?>">
          <span class="ev-ic<?= $ev['priority'] === 'high' ? ' hi' : '' ?>"><?= $icons[$ev['kind']] ?? '📌' ?></span>
          <div class="ev-m">
            <b><?= e($ev['title']) ?></b>
            <small>
              <?= e(Fida::EVENT_KINDS[$ev['kind']] ?? '') ?>
              <?= !empty($ev['event_time']) ? ' · ⏰ ' . e(fa_digits(substr((string)$ev['event_time'], 0, 5))) : '' ?>
              <?= !empty($ev['notify_days']) ? ' · 🔔 ' . num((int)$ev['notify_days']) . ' روز قبل' : '' ?>
              <?= $ev['priority'] === 'high' ? ' · ⚡ مهم' : '' ?>
              <?php if (!empty($ev['note'])): ?><span class="ev-note"><?= e($ev['note']) ?></span><?php endif; ?>
            </small>
          </div>
          <form method="post" action="<?= url('fida/calendar/' . (int)$ev['id'] . '/toggle') ?>" style="display:inline"><?= csrf_field() ?>
            <input type="hidden" name="back_y" value="<?= (int)$jy ?>"><input type="hidden" name="back_m" value="<?= (int)$jm ?>">
            <input type="hidden" name="back_d" value="<?= e($selJal) ?>">
            <button class="btn sm <?= !empty($ev['is_done']) ? 'btn-g' : 'ghost' ?>" type="submit" title="انجام‌شده/نشده"><?= !empty($ev['is_done']) ? '↩︎' : '✓' ?></button></form>
          <button class="btn sm ghost" type="button" onclick='calEdit(<?= json_encode($ev, JSON_UNESCAPED_UNICODE) ?>)'>✎</button>
          <form method="post" action="<?= url('fida/calendar/' . (int)$ev['id'] . '/delete') ?>" style="display:inline" onsubmit="return confirm('این رویداد حذف شود؟')"><?= csrf_field() ?>
            <input type="hidden" name="back_y" value="<?= (int)$jy ?>"><input type="hidden" name="back_m" value="<?= (int)$jm ?>">
            <button class="btn sm ghost" type="submit" style="color:#E11D48">🗑</button></form>
        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- رویدادهای پیش‌رو -->
  <h2 class="sec" style="margin-top:14px">⏭️ رویدادهای پیش‌رو <span class="m">۶۰ روز آینده</span></h2>
  <?php if (!$upcoming): ?>
    <div class="card center muted">رویداد آینده‌ای ثبت نشده است.</div>
  <?php else: ?>
    <?php foreach ($upcoming as $ev): $d = (int)floor((strtotime((string)$ev['event_date']) - strtotime(today())) / 86400); ?>
      <a class="row ev-up<?= $ev['priority'] === 'high' ? ' hi' : '' ?><?= !empty($ev['is_done']) ? ' done' : '' ?>"
           href="<?= url('fida/calendar?y=' . (int)explode('/', (string)$ev['jalali_date'])[0] . '&m=' . (int)explode('/', (string)$ev['jalali_date'])[1] . '&d=' . $ev['jalali_date']) ?>">
        <div class="thumb t-sell"><?= $icons[$ev['kind']] ?? '📌' ?></div>
        <div class="m"><b><?= e($ev['title']) ?></b>
          <small><?= e((string)$ev['jalali_label']) ?> · <?= $d === 0 ? 'امروز' : ($d === 1 ? 'فردا' : num($d) . ' روز دیگر') ?>
            <?= !empty($ev['event_time']) ? ' · ⏰ ' . e(fa_digits(substr((string)$ev['event_time'], 0, 5))) : '' ?></small></div>
        <span class="chip <?= $d === 0 ? 'c-done' : 'c-wait' ?>"><?= e(Fida::EVENT_KINDS[$ev['kind']] ?? '') ?></span>
      </a>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<!-- برگهٔ افزودن/ویرایش رویداد -->
<div class="submodal" id="evSheet" hidden>
  <div class="sub-card" style="max-width:520px">
    <div class="sub-head" style="padding:16px 18px">
      <span class="sub-badge">تقویم من</span>
      <h3 id="evTitle">➕ رویداد جدید</h3>
      <p>برای هر روز می‌توانی یادآوری، جلسه، تماس، پرداخت و … ثبت کنی. همهٔ رویدادها شخصی و فقط برای خودت است.</p>
    </div>
    <form method="post" action="<?= url('fida/calendar') ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="id" id="evId" value="">
      <input type="hidden" name="back_y" value="<?= (int)$jy ?>"><input type="hidden" name="back_m" value="<?= (int)$jm ?>">
      <div class="sub-body" style="padding:14px 18px;display:grid;gap:10px">
        <label class="field"><span>عنوان *</span><input class="inp" name="title" id="evT" required placeholder="مثلاً: تماس با آقای رضایی"></label>
        <div class="grid-2b" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <label class="field"><span>تاریخ *</span><input class="inp jalali" name="event_date" id="evD" required placeholder="۱۴۰۵/۰۷/۰۹"></label>
          <label class="field"><span>ساعت</span><input class="inp" name="event_time" id="evTime" placeholder="۱۰:۳۰" dir="ltr"></label>
        </div>
        <div class="grid-2b" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <label class="field"><span>نوع</span><select class="inp" name="kind" id="evK">
            <?php foreach (Fida::EVENT_KINDS as $k => $v): ?><option value="<?= $k ?>"><?= $icons[$k] ?> <?= e($v) ?></option><?php endforeach; ?>
          </select></label>
          <label class="field"><span>اهمیت</span><select class="inp" name="priority" id="evP">
            <option value="normal">عادی</option><option value="high">⚡ مهم</option></select></label>
        </div>
        <label class="field"><span>یادآوری چند روز قبل هم اعلان شود؟</span>
          <select class="inp" name="notify_days" id="evN">
            <?php foreach ([0 => 'فقط همان روز', 1 => '۱ روز قبل', 2 => '۲ روز قبل', 3 => '۳ روز قبل', 7 => '۱ هفته قبل'] as $k => $v): ?>
              <option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?>
          </select></label>
        <label class="field"><span>یادداشت</span><textarea class="inp wide" name="note" id="evNote" rows="2"></textarea></label>
        <label class="checkbox" style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="is_done" id="evDone" value="1" style="width:auto"><span class="small">انجام شد</span></label>
      </div>
      <div class="sub-foot">
        <div class="row2" style="display:grid;grid-template-columns:1fr auto;gap:8px">
          <button class="btn btn-p" type="submit">💾 ذخیرهٔ رویداد</button>
          <button class="btn btn-g" type="button" onclick="document.getElementById('evSheet').hidden=true">بستن</button>
        </div>
      </div>
    </form>
  </div>
</div>
<script>
function calNew(jalaliDate) {
  document.getElementById('evTitle').textContent = '➕ رویداد جدید';
  document.getElementById('evId').value = '';
  document.getElementById('evT').value = '';
  document.getElementById('evD').value = jalaliDate || '';
  document.getElementById('evTime').value = '';
  document.getElementById('evK').value = 'reminder';
  document.getElementById('evP').value = 'normal';
  document.getElementById('evN').value = '0';
  document.getElementById('evNote').value = '';
  document.getElementById('evDone').checked = false;
  document.getElementById('evSheet').hidden = false;
}
function calEdit(e) {
  document.getElementById('evTitle').textContent = '✎ ویرایش رویداد';
  document.getElementById('evId').value = e.id;
  document.getElementById('evT').value = e.title || '';
  var d = e.event_date || '';
  document.getElementById('evD').value = e.jalali_date || d;
  document.getElementById('evTime').value = (e.event_time || '').slice(0,5);
  document.getElementById('evK').value = e.kind || 'reminder';
  document.getElementById('evP').value = e.priority || 'normal';
  document.getElementById('evN').value = String(e.notify_days || 0);
  document.getElementById('evNote').value = e.note || '';
  document.getElementById('evDone').checked = Number(e.is_done) === 1;
  document.getElementById('evSheet').hidden = false;
}
document.getElementById('evSheet').addEventListener('click', function (ev) { if (ev.target === this) this.hidden = true; });
</script>
<?= view('partials/fida_foot') ?>
