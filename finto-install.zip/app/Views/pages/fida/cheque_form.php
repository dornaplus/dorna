<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$isEdit = !empty($row['id']);
$dir = $row['direction'] ?? (($_GET['direction'] ?? '') === 'issued' ? 'issued' : 'received');
$st = [
  'in_hand'   => 'در جریان',
  'deposited' => 'سپرده‌شده',
  'cleared'   => 'وصول‌شده',
  'returned'  => 'برگشتی',
  'cancelled' => 'ابطال‌شده',
];
?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0"><?= $isEdit ? 'ویرایش چک' : 'ثبت چک' ?></h2>

  <form method="post" action="<?= url('fida/cheques') ?>" id="chqForm">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
    <?php if (!empty($preInvoice)): ?><input type="hidden" name="invoice_id" value="<?= (int)$preInvoice ?>"><?php endif; ?>
    <?php if (!empty($row['invoice_id'])): ?><input type="hidden" name="invoice_id" value="<?= (int)$row['invoice_id'] ?>"><?php endif; ?>

    <div class="chips">
      <button type="button" class="<?= $dir === 'received' ? 'on' : '' ?>" onclick="setDir('received')">چک دریافتی</button>
      <button type="button" class="<?= $dir === 'issued' ? 'on' : '' ?>" onclick="setDir('issued')">چک پرداختی</button>
    </div>
    <input type="hidden" name="direction" id="dir" value="<?= e($dir) ?>">

    <div class="sect"><h3><span class="n">۱</span> مشخصات چک</h3>
      <div class="grid2">
        <div class="field"><label>شمارهٔ چک *</label><input class="inp" name="cheque_no" value="<?= e(fa_digits((string)($row['cheque_no'] ?? ''))) ?>" required></div>
        <div class="field"><label>مبلغ (<?= Fida::unit() ?>) *</label><input class="inp money" name="amount" value="<?= e($row['amount'] ?? '0') ?>" required></div>
      </div>
      <div class="grid2">
        <div class="field"><label>بانک</label><input class="inp" name="bank_name" value="<?= e($row['bank_name'] ?? '') ?>" placeholder="ملی، صادرات، …"></div>
        <div class="field"><label>شعبه</label><input class="inp" name="branch_name" value="<?= e($row['branch_name'] ?? '') ?>"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>شماره حساب</label><input class="inp" name="account_no" dir="ltr" value="<?= e($row['account_no'] ?? '') ?>"></div>
        <div class="field"><label>شناسه صیادی</label><input class="inp" name="sayad_id" dir="ltr" value="<?= e($row['sayad_id'] ?? '') ?>"></div>
      </div>
    </div>

    <div class="sect"><h3><span class="n">۲</span> طرف حساب و تاریخ‌ها</h3>
      <div class="field"><label>طرف حساب (از لیست اشخاص)</label>
        <select class="inp" name="person_id" id="personSel">
          <option value="">— ثبت نام آزاد —</option>
          <?php foreach ($persons as $ps): ?>
            <option value="<?= (int)$ps['id'] ?>" <?= (int)($row['person_id'] ?? $prePerson ?? 0) === (int)$ps['id'] ? 'selected' : '' ?>><?= e($ps['full_name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field" id="freeNameWrap"><label>نام طرف حساب (اگر در لیست نیست)</label>
        <input class="inp" name="person_name" value="<?= e($row['person_name'] ?? '') ?>" placeholder="مثلاً: آقای رضایی"></div>
      <div class="grid2">
        <div class="field"><label>تاریخ صدور</label>
          <input class="inp jalali" name="issue_date" value="<?= e(fa_digits((string)($row['issue_jalali'] ?? jdate(today())))) ?>" placeholder="۱۴۰۵/۰۷/۰۸"></div>
        <div class="field"><label>سررسید *</label>
          <input class="inp jalali" name="due_date" value="<?= e(fa_digits($row['due_jalali'] ?? '')) ?>" placeholder="۱۴۰۵/۰۷/۱۵" required></div>
      </div>
      <div class="field"><label>وضعیت</label>
        <select class="inp" name="status">
          <?php foreach ($st as $k => $lbl): ?>
            <option value="<?= $k ?>" <?= ($row['status'] ?? 'in_hand') === $k ? 'selected' : '' ?>><?= $lbl ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label>توضیحات</label><input class="inp" name="note" value="<?= e($row['note'] ?? '') ?>"></div>
    </div>

    <div class="btns">
      <button class="btn btn-p" type="submit"><?= $isEdit ? 'ذخیرهٔ تغییرات' : 'ثبت چک' ?></button>
      <button class="btn btn-g" type="button" onclick="location.href='<?= url('fida/cheques') ?>'">انصراف</button>
    </div>
  </form>

  <?php if ($isEdit): ?>
    <div class="sect"><h3><span class="n">۳</span> تغییر سریع وضعیت</h3>
      <div class="quickstatus">
        <?php foreach ($st as $k => $lbl): if ($k === ($row['status'] ?? '')) continue; ?>
          <form method="post" action="<?= url('fida/cheques/' . (int)$row['id'] . '/status') ?>">
            <?= csrf_field() ?><input type="hidden" name="status" value="<?= $k ?>">
            <button class="btn sm <?= in_array($k, ['cleared'], true) ? 'btn-p' : 'btn-g' ?>" type="submit"><?= $lbl ?></button>
          </form>
        <?php endforeach; ?>
      </div>
      <form method="post" action="<?= url('fida/cheques/' . (int)$row['id'] . '/delete') ?>" onsubmit="return confirm('این چک حذف شود؟')" style="margin-top:12px">
        <?= csrf_field() ?>
        <button class="btn btn-danger" type="submit">حذف چک</button>
      </form>
    </div>
  <?php endif; ?>
</section>

<script>
(function () {
  var dirInput = document.getElementById('dir');
  window.setDir = function (d) {
    dirInput.value = d;
    document.querySelectorAll('.chips button').forEach(function (b) {
      b.classList.toggle('on', (d === 'received' && b.textContent.indexOf('دریافتی') !== -1)
                             || (d === 'issued' && b.textContent.indexOf('پرداختی') !== -1));
    });
    var sel = document.getElementById('personSel');
    if (sel && sel.selectedIndex === 0) return;
  };
  // اگر شخصی از لیست انتخاب شد، فیلد نام آزاد لازم نیست
  var sel = document.getElementById('personSel'), free = document.getElementById('freeNameWrap');
  function sync() { if (free) free.style.display = (sel && sel.value) ? 'none' : ''; }
  if (sel) { sel.addEventListener('change', sync); sync(); }
})();
</script>
<?= view('partials/fida_foot') ?>
