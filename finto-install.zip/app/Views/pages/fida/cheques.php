<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$st = [
  'in_hand'   => ['c-wait',   'در جریان'],
  'deposited' => ['c-credit', 'سپرده‌شده'],
  'cleared'   => ['c-done',   'وصول‌شده'],
  'returned'  => ['c-danger', 'برگشتی'],
  'cancelled' => ['c-pre',    'ابطال‌شده'],
];
$filters = [
  'all'      => 'همه',
  'received' => 'دریافتی',
  'issued'   => 'پرداختی',
  'due'      => 'نزدیک سررسید',
  'cleared'  => 'وصول‌شده',
  'returned' => 'برگشتی',
];
?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">چک‌ها <span class="m" style="color:var(--grey-50)"><?= num(count($rows)) ?> فقره</span></h2>

  <div class="card">
    <div class="stats">
      <div class="stat g"><div class="k">دریافتی در جریان</div><div class="v"><?= num($sum['recv'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat r"><div class="k">پرداختی در جریان</div><div class="v"><?= num($sum['issued'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat"><div class="k">نزدیک سررسید (۳ روز)</div><div class="v"><?= num($sum['due_count'] ?? 0) ?> <small>فقره</small></div></div>
      <div class="stat r"><div class="k">برگشتی</div><div class="v"><?= num($sum['returned'] ?? 0) ?> <small>فقره</small></div></div>
    </div>
  </div>

  <div class="quicks" style="margin:14px 0 10px">
    <div class="qk" onclick="location.href='<?= url('fida/cheques/create') ?>'">
      <div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></div>
      <span>ثبت چک دریافتی</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/cheques/create?direction=issued') ?>'">
      <div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.5" width="19" height="13" rx="2.5"/><path d="M2.5 10h19M6.5 15h4"/></svg></div>
      <span>ثبت چک پرداختی</span></div>
  </div>

  <div class="chips">
    <?php foreach ($filters as $k => $lbl): ?>
      <button class="<?= $f === $k ? 'on' : '' ?>" onclick="location.href='<?= url('fida/cheques' . ($k === 'all' ? '' : '?f=' . $k)) ?>'"><?= $lbl ?></button>
    <?php endforeach; ?>
  </div>

  <?php foreach ($rows as $r):
      $c = $st[$r['status']] ?? ['c-wait', $r['status']];
      $open = in_array($r['status'], ['in_hand', 'deposited'], true);
      $d = (int)$r['days_to_due'];
  ?>
    <div class="row <?= (int)$focus === (int)$r['id'] ? 'row-focus' : '' ?>" onclick="location.href='<?= url('fida/cheques/' . (int)$r['id'] . '/edit') ?>'">
      <div class="thumb <?= $r['direction'] === 'issued' ? 't-buy' : 't-sell' ?>"><?= $r['direction'] === 'issued' ? '📤' : '📥' ?></div>
      <div class="m">
        <b><?= e(fa_digits((string)$r['cheque_no'])) ?> · <?= e($r['party_name']) ?></b>
        <small><?= $r['bank_name'] ? e($r['bank_name']) . ' · ' : '' ?>سررسید <?= e(fa_digits($r['due_jalali'])) ?><?= $r['invoice_code'] ? ' · ' . e(fa_digits((string)$r['invoice_code'])) : '' ?></small>
        <span class="chip <?= $c[0] ?>"><?= $r['direction'] === 'issued' ? 'پرداختی' : 'دریافتی' ?> · <?= $c[1] ?></span>
        <?php if ($open && $d <= 3): ?><span class="chip <?= $d < 0 ? 'c-danger' : 'c-wait' ?>"><?= FidaNotice::label($d) ?></span><?php endif; ?>
      </div>
      <div class="amt"><?= num($r['amount']) ?><small><?= Fida::unit() ?></small></div>
    </div>
  <?php endforeach; ?>

  <?php if (!$rows): ?>
    <div class="card center muted">چکی با این فیلتر ثبت نشده است.<br>
      <a class="btn sm" style="margin-top:10px;display:inline-flex" href="<?= url('fida/cheques/create') ?>">ثبت اولین چک</a></div>
  <?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
