<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$chip = ['paid' => ['c-done', 'پرداخت‌شده'], 'credit' => ['c-credit', 'اعتباری'], 'pending' => ['c-wait', 'در انتظار تأیید'], 'converted' => ['c-pre', 'تبدیل‌شده'], 'closed' => ['c-done', 'بسته']];
$nm = Auth::user()['full_name'] ?? 'کاربر';
$thumb = ['sale' => 't-sell', 'pre_invoice' => 't-pre', 'purchase' => 't-buy'];
$ticon = ['sale' => '🧾', 'pre_invoice' => '📝', 'purchase' => '📦'];
$cs = $chequeSum ?? [];
?>
<section class="panel on">
  <div class="card">
    <div class="hello">
      <div class="av"><?= e(mb_substr($nm, 0, 1)) ?></div>
      <div><b>سلام، <?= e($nm) ?> 👋</b><small>امروز آمادهٔ فاکتور زنی سریعی</small></div>
    </div>
    <div class="stats">
      <div class="stat g"><div class="k">فروش این ماه</div><div class="v"><?= num($kpi['month']) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat"><div class="k">فاکتورها</div><div class="v"><?= num($kpi['invoices']) ?> <small>عدد</small></div></div>
      <div class="stat"><div class="k">اشخاص</div><div class="v"><?= num($kpi['persons']) ?> <small>نفر</small></div></div>
      <div class="stat r"><div class="k">مانده اعتباری</div><div class="v"><?= num($kpi['debt']) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat g"><div class="k">چک دریافتی در جریان</div><div class="v"><?= num($cs['recv'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat r"><div class="k">چک پرداختی در جریان</div><div class="v"><?= num($cs['issued'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
    </div>
  </div>

  <?php if (!empty($notices)): $n0 = $notices[0]; ?>
    <div class="card notice" data-sev="<?= e($n0['severity']) ?>" style="margin-top:14px;cursor:pointer" onclick="location.href='<?= url('fida/notifications') ?>'">
      <div class="notice-top">
        <span class="notice-ic <?= e($n0['severity']) ?>"><?= FidaNotice::icon($n0['icon'], 18) ?></span>
        <div class="notice-title">
          <b><?= e($n0['title']) ?><span class="dot"></span></b>
          <span class="notice-when">فوری · <?= e($n0['when']) ?></span>
        </div>
      </div>
      <div class="notice-desc"><?= e($n0['desc']) ?></div>
      <?php if (count($notices) > 1): ?>
        <div class="notice-desc" style="color:var(--purple);font-weight:800">
          + <?= num(count($notices) - 1) ?> اعلان دیگر — مشاهدهٔ همه
        </div>
      <?php endif; ?>
    </div>
  <?php endif; ?>

  <div class="gold" onclick="location.href='<?= url('fida/gold') ?>'">
    <div class="ic"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l2.7 5.5 6 .9-4.3 4.2 1 6-5.4-2.8L6.6 19.6l1-6L3.3 9.4l6-.9L12 3z"/></svg></div>
    <div><b>اشتراک طلایی فعال کن</b><small>سطر نامحدود، خروجی PDF و بدون لیبل</small></div>
    <div class="go">فعال‌سازی</div>
  </div>

  <div class="quicks">
    <div class="qk" onclick="location.href='<?= url('fida/invoices/create?type=sale') ?>'"><div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg></div><span>فاکتور جدید</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/cheques/create') ?>'"><div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="5.5" width="19" height="13" rx="2.5"/><path d="M2.5 10h19M6.5 15h4"/></svg></div><span>ثبت چک</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/persons/create') ?>'"><div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="3.5"/><path d="M5 20c1.2-3.4 3.8-5 7-5s5.8 1.6 7 5"/></svg></div><span>شخص جدید</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/items/create') ?>'"><div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8 12 3 3 8v8l9 5 9-5V8z"/></svg></div><span>کالای جدید</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/reports') ?>'"><div class="i"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M5 20V10M12 20V4M19 20v-7"/></svg></div><span>گزارش‌ها</span></div>
  </div>

  <!-- نصب اپ روی گوشی (PWA) — فقط وقتی اپ نصب نشده و قابل نصب باشد نمایش داده می‌شود -->
  <div class="card" data-pwa-install hidden style="display:flex;align-items:center;gap:12px;cursor:pointer" onclick="pwaInstall()">
    <div style="width:44px;height:44px;border-radius:13px;display:grid;place-items:center;font-size:21px;background:linear-gradient(150deg,var(--purple),var(--purple-deep));color:#fff;flex:0 0 auto">📲</div>
    <div style="flex:1;min-width:0">
      <b style="font-size:13.5px">فیدا را روی گوشی نصب کن</b>
      <small style="display:block;color:var(--grey-50);font-size:11.5px;margin-top:3px">آیکون روی صفحهٔ اصلی · باز شدن تمام‌صفحه و سریع‌تر</small>
    </div>
    <span class="btn btn-p sm" style="pointer-events:none">نصب</span>
  </div>


  <!-- تقویم من: رویدادهای امروز و پیش‌رو -->
  <?php
    $__uid = (int)Auth::id();
    $__todayEv = Fida::eventsOn($__uid, today());
    $__soon = Fida::upcomingEvents($__uid, 3, 30);
    $__icons = Fida::EVENT_KINDS_ICON;
  ?>
  <div class="card" style="display:grid;gap:8px">
    <div style="display:flex;align-items:center;gap:8px">
      <b style="font-size:14px">🗓️ تقویم من</b>
      <span class="muted small"><?= num(count($__todayEv)) ?> رویداد امروز</span>
      <span class="muted small" style="margin-inline-start:auto"><?= e(jdate(today())) ?></span>
    </div>
    <?php if ($__todayEv): ?>
      <?php foreach ($__todayEv as $ev): ?>
        <a class="ev-row<?= !empty($ev['is_done']) ? ' done' : '' ?>" style="text-decoration:none;color:inherit" href="<?= url('fida/calendar?d=' . $ev['jalali_date']) ?>">
          <span class="ev-ic<?= $ev['priority'] === 'high' ? ' hi' : '' ?>"><?= $__icons[$ev['kind']] ?? '📌' ?></span>
          <div class="ev-m"><b><?= e($ev['title']) ?></b>
            <small><?= e(Fida::EVENT_KINDS[$ev['kind']] ?? '') ?><?= !empty($ev['event_time']) ? ' · ⏰ ' . e(fa_digits(substr((string)$ev['event_time'], 0, 5))) : '' ?><?= !empty($ev['is_done']) ? ' · انجام‌شده' : '' ?></small></div>
        </a>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="muted small">امروز رویدادی نداری. برای هر روز می‌توانی یادآوری، جلسه یا تماس ثبت کنی.</div>
    <?php endif; ?>
    <?php if ($__soon): ?>
      <div class="small" style="color:var(--grey-50);border-top:1px dashed var(--line);padding-top:6px">پیش‌رو:</div>
      <?php foreach ($__soon as $ev): ?>
        <a class="small" style="color:inherit;text-decoration:none" href="<?= url('fida/calendar?d=' . $ev['jalali_date']) ?>">
          <?= $__icons[$ev['kind']] ?? '📌' ?> <?= e($ev['title']) ?> — <?= e((string)$ev['jalali_label']) ?>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
    <a class="btn sm btn-g" href="<?= url('fida/calendar') ?>" style="justify-self:start">📅 تقویم کامل و افزودن رویداد</a>
  </div>

  <h2 class="sec">چک‌های در جریان <span class="m" onclick="location.href='<?= url('fida/cheques') ?>'">مشاهده همه</span></h2>
  <?php if (!empty($cheques)): ?>
    <?php foreach ($cheques as $ch): $d = (int)$ch['days_to_due']; ?>
      <div class="row" onclick="location.href='<?= url('fida/cheques/' . (int)$ch['id'] . '/edit') ?>'">
        <div class="thumb <?= $ch['direction'] === 'issued' ? 't-buy' : 't-sell' ?>"><?= $ch['direction'] === 'issued' ? '📤' : '📥' ?></div>
        <div class="m"><b><?= e(fa_digits((string)$ch['cheque_no'])) ?> · <?= e($ch['party_name']) ?></b>
          <small>سررسید <?= e(fa_digits($ch['due_jalali'])) ?><?= $ch['bank_name'] ? ' · ' . e($ch['bank_name']) : '' ?></small>
          <span class="chip <?= $d < 0 ? 'c-danger' : 'c-wait' ?>"><?= FidaNotice::label($d) ?></span></div>
        <div class="amt"><?= num($ch['amount']) ?><small><?= Fida::unit() ?></small></div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="card" style="display:flex;align-items:center;justify-content:space-between;gap:10px">
      <span class="muted" style="font-size:12.5px;line-height:1.9">چک دریافتی یا پرداختی ثبت کن تا سررسیدش را یادت بیاوریم.</span>
      <a class="btn sm" style="flex:0 0 auto" href="<?= url('fida/cheques/create') ?>">ثبت چک</a>
    </div>
  <?php endif; ?>

  <h2 class="sec">آخرین فاکتورها <span class="m" onclick="location.href='<?= url('fida/invoices') ?>'">مشاهده همه</span></h2>
  <?php foreach ($recent as $r): $c = $chip[$r['status']] ?? ['c-wait', $r['status']]; ?>
    <div class="row" onclick="location.href='<?= url('fida/invoices/' . (int)$r['id']) ?>'">
      <div class="thumb <?= $thumb[$r['invoice_type']] ?? 't-sell' ?>"><?= $ticon[$r['invoice_type']] ?? '🧾' ?></div>
      <div class="m"><b><?= e(['sale'=>'فاکتور فروش','pre_invoice'=>'پیش‌فاکتور','purchase'=>'فاکتور خرید'][$r['invoice_type']] ?? 'فاکتور') ?> · <?= e($r['person_name']) ?></b>
        <small dir="ltr"><?= e(fa_digits((string)$r['invoice_code'])) ?></small><span class="chip <?= $c[0] ?>"><?= e($c[1]) ?></span></div>
      <div class="amt"><?= num($r['final_amount']) ?><small><?= Fida::unit() ?></small></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$recent): ?><div class="card center muted">هنوز فاکتوری ثبت نشده است.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
