<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">⭐ اشتراک طلایی</h2>
  <div class="card">
    <b style="font-size:15px">اشتراک طلایی فعال کن</b>
    <p style="font-size:12px;color:var(--grey-50);margin:6px 0 0">سطر نامحدود در فاکتور · خروجی PDF بدون لیبل · ذخیره محصولات و خدمات · پشتیبانی ویژه</p>
    <div class="plan-row" style="margin-top:12px">
      <?php $badges = ['best_seller' => '🏆 پرفروش‌ترین', 'recommended' => 'پیشنهادی', 'value' => 'مقرون‌به‌صرفه'];
      foreach ($plans as $i => $p): ?>
        <div class="plan <?= (int)($p['duration_months'] ?? 0) === 12 || ($p['badge'] ?? '') === 'recommended' ? 'on' : '' ?>"
             data-plan="<?= (int)$p['id'] ?>"
             onclick="document.querySelectorAll('.plan').forEach(function(x){x.classList.remove('on')});this.classList.add('on');document.getElementById('planId').value='<?= (int)$p['id'] ?>'">
          <?php if ((int)$p['old_price'] > 0 || (int)$p['discount_amount'] > 0): ?><span class="tag">تخفیف</span><?php endif; ?>
          <?php if ((int)$p['discount_amount'] > 0): ?>
            <b><?= num($p['final_price']) ?></b><small>تومان</small>
            <small style="text-decoration:line-through;opacity:.6"><?= num($p['price']) ?> تومان</small>
          <?php else: ?>
            <b><?= num($p['price']) ?></b><small>تومان</small>
            <?php if ((int)$p['old_price'] > 0): ?><small style="text-decoration:line-through;opacity:.6"><?= num($p['old_price']) ?> تومان</small><?php endif; ?>
          <?php endif; ?>
          <small><?= num($p['duration_months']) ?> ماهه<?= $p['badge'] ? ' · ' . $badges[$p['badge']] : '' ?></small>
        </div>
      <?php endforeach; ?>
    </div>
    <input type="hidden" name="plan_id" id="planId" value="<?= (int)($plans[0]['id'] ?? 0) ?>">
    <?php if (!empty($bazaar['enabled'])): ?>
      <button class="btn btn-p" id="btnBazaar" style="width:100%;margin-top:12px" type="button">
        💳 پرداخت با کافه‌بازار
      </button>
      <div class="pv-note" style="margin-top:8px">
        پرداخت داخل اپلیکیشن <b>کافه‌بازار</b> انجام می‌شود؛ پس از پرداخت، اشتراک به‌صورت خودکار فعال می‌شود.
        <?php if (!empty($bazaar['sandbox'])): ?><br><b style="color:var(--golder)">حالت آزمایشی فعال است (پرداخت واقعی انجام نمی‌شود).</b><?php endif; ?>
        <?php if (empty($bazaar['ready'])): ?><br><b style="color:#B91C1C">کلید API کافه‌بازار هنوز تنظیم نشده است.</b><?php endif; ?>
      </div>
      <div class="pv-note" style="margin-top:6px">اگر اپلیکیشن «بازار» روی گوشی‌ات نصب است، همین دکمه کافی است. در غیر این‌صورت آن را از بازار نصب کن.</div>
    <?php else: ?>
      <form method="post" action="<?= url('fida/gold/subscribe') ?>"><?= csrf_field() ?>
        <input type="hidden" name="plan_id" id="planId" value="<?= (int)($plans[0]['id'] ?? 0) ?>">
        <button class="btn btn-p" style="width:100%;margin-top:12px" type="submit">فعال‌سازی اشتراک</button>
      </form>
    <?php endif; ?>

    <!-- تأیید پرداخت بازگشتی از کافه‌بازار -->
    <form method="post" action="<?= url('fida/gold/bazaar/confirm') ?>" id="bzForm" hidden>
      <?= csrf_field() ?>
      <input type="hidden" name="purchase_token" value="">
      <input type="hidden" name="plan_id" value="">
    </form>
    <div class="card bz-wait" id="bzWait" hidden>
      <b>⏳ در حال تأیید پرداخت…</b>
      <small>لطفاً صفحه را نبند؛ در حال بررسی پرداخت با کافه‌بازار هستیم.</small>
      <div class="bz-bar"><i></i></div>
    </div>
  </div>

  <div class="invite">
    <b>🎟️ کد تخفیف داری؟</b>
    <?php if (!empty($discount)): ?>
      <p style="color:var(--golder);font-weight:700">کد «<?= e($discount['code']) ?>» اعمال شد — <?= (int)$discount['discount_mode'] === 'percent' ? num((int)$discount['discount_value']) . '٪' : num((int)$discount['discount_value']) . ' تومان' ?> تخفیف روی قیمت اشتراک محاسبه می‌شود.</p>
      <form method="post" action="<?= url('fida/discount/remove') ?>" style="margin-top:6px"><?= csrf_field() ?>
        <button class="btn sm soft" type="submit">برداشتن کد تخفیف</button></form>
    <?php else: ?>
      <p>اگر کد تخفیف داری وارد کن تا روی قیمت اشتراک اعمال شود.</p>
      <form method="post" action="<?= url('fida/discount/apply') ?>" style="display:flex;gap:8px;margin-top:8px">
        <?= csrf_field() ?>
        <input class="inp" name="discount_code" dir="ltr" placeholder="مثلاً FIDA20" style="flex:1" autocomplete="off">
        <button class="btn sm" type="submit">اعمال کد تخفیف</button>
      </form>
      <?php if (!empty($codes)): ?>
        <div class="code" style="flex-wrap:wrap;gap:6px">
          <span style="font-size:11px;color:var(--grey-50)">کدهای فعال:</span>
          <?php foreach ($codes as $c): ?>
            <b dir="ltr"><?= e($c['code']) ?></b>
            <small style="font-size:11px;color:var(--grey-50)"><?= e((int)$c['discount_mode'] === 'percent' ? num((int)$c['discount_value']) . '٪' : num((int)$c['discount_value']) . ' تومان') ?><?= $c['title'] ? ' — ' . e($c['title']) : '' ?></small>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    <?php endif; ?>
  </div>

  <h2 class="sec">اشتراک‌های اخیر</h2>
  <?php foreach ($subs as $s): ?>
    <div class="row">
      <div class="thumb <?= $s['source'] === 'invite' ? 't-pre' : 't-sell' ?>"><?= $s['source'] === 'invite' ? '🎁' : '⭐' ?></div>
      <div class="m"><b><?= $s['source'] === 'invite' ? 'اشتراک با کد دعوت' : 'خرید اشتراک' ?><?php if (!empty($s['discount_code'])): ?> <span class="chip c-done"><?= e($s['discount_code']) ?></span><?php endif; ?></b>
        <small dir="ltr"><?= e($s['activated_at']) ?> → <?= e($s['expires_at']) ?></small>
        <?php if ((int)($s['discount_amount'] ?? 0) > 0): ?><small>تخفیف <?= num((int)$s['discount_amount']) ?> — پرداختی <?= num((int)($s['paid_amount'] ?? 0)) ?> تومان</small><?php endif; ?>
        <span class="chip <?= $s['status'] === 'active' ? 'c-done' : 'c-wait' ?>"><?= $s['status'] === 'active' ? 'فعال' : 'منقضی' ?></span></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$subs): ?><div class="card center muted">اشتراکی ثبت نشده است.</div><?php endif; ?>

  <?php if (!empty($purchases)): ?>
    <h2 class="sec">پرداخت‌های درگاه کافه‌بازار</h2>
    <?php foreach ($purchases as $pu): $st = ['verified' => ['c-done', 'تأییدشده'], 'pending' => ['c-wait', 'در حال بررسی'], 'failed' => ['c-danger', 'ناموفق'], 'refunded' => ['c-danger', 'مرجوع']][$pu['status']] ?? ['c-wait', $pu['status']]; ?>
      <div class="row">
        <div class="thumb <?= $pu['status'] === 'verified' ? 't-sell' : 't-pre' ?>">💳</div>
        <div class="m">
          <b><?= e((string)$pu['sku']) ?></b>
          <small dir="ltr"><?= e((string)$pu['created_at']) ?></small>
          <small>مبلغ: <?= num((int)$pu['amount']) ?> تومان<?= (int)$pu['day_count'] > 0 ? ' · ' . num((int)$pu['day_count']) . ' روز' : '' ?></small>
        </div>
        <span class="chip <?= $st[0] ?>"><?= $st[1] ?></span>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</section>

<style>
  .bz-wait{margin-top:12px;display:grid;gap:6px;text-align:center}
  .bz-wait small{color:var(--grey-50);font-size:12px}
  .bz-bar{height:6px;border-radius:6px;background:var(--purple-soft);overflow:hidden;margin-top:4px}
  .bz-bar i{display:block;height:100%;width:35%;border-radius:6px;background:linear-gradient(90deg,var(--purple),var(--purple-deep));animation:bzMove 1.1s ease-in-out infinite}
  @keyframes bzMove{0%{transform:translateX(120%)}100%{transform:translateX(-260%)}}
  .pv-note{font-size:11.5px;color:var(--grey-50);line-height:1.9}
</style>
<script>
  window.BZ_LINKS = <?= json_encode(array_map(fn($p) => Bazaar::skuFor($p) !== '' ? Bazaar::paymentLink(Bazaar::skuFor($p), ($return_url ?? '') . '?bz=' . (int)$p['id']) : '', $plans), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  (function () {
    var btn = document.getElementById('btnBazaar');
    if (btn) {
      btn.addEventListener('click', function () {
        var pid = document.getElementById('planId').value;
        var link = window.BZ_LINKS[pid];
        if (!link) { alert('برای این پلن هنوز شناسهٔ محصول (SKU) در تنظیمات کافه‌بازار تعریف نشده است.'); return; }
        location.href = link;   // باز شدن اپلیکیشن کافه‌بازار
      });
    }
    // انتخاب پلن (نسخهٔ درگاه)
    document.querySelectorAll('.plan').forEach(function (el) {
      el.addEventListener('click', function () {
        var sel = document.getElementById('planId'); if (sel) sel.value = this.getAttribute('data-plan') || sel.value;
      });
    });
    // بازگشت از کافه‌بازار: توکن خرید در آدرس می‌آید → تأیید در سرور
    var q = new URLSearchParams(location.search);
    var tok = q.get('purchaseToken') || q.get('purchase_token');
    if (!tok) return;
    var pid = q.get('bz') || q.get('plan_id') || (document.getElementById('planId') || {}).value || '';
    var wait = document.getElementById('bzWait'); if (wait) wait.hidden = false;
    var f = document.getElementById('bzForm');
    f.querySelector('[name=purchase_token]').value = tok;
    f.querySelector('[name=plan_id]').value = pid;
    f.submit();
  })();
</script>
<?= view('partials/fida_foot') ?>
