<?= view('partials/fida_head', ['title' => $title]) ?>
<?php $typeFa = ['sale' => 'فاکتور فروش', 'pre_invoice' => 'پیش‌فاکتور', 'purchase' => 'فاکتور خرید'];
$taxDefault = (float)($settings['tax_percent'] ?? 9);
$cur = Fida::unit($settings);              // واحد پول (تومان/ریال) از تنظیمات
$dm  = Fida::discountMode($settings);      // حالت تخفیف (درصدی/مبلغی)
$on  = static fn($k) => !empty($settings[$k]);   // تنظیمات نمایش هر بخش
$showDisc = $on('show_discount'); $showShip = $on('show_ship'); $showTax = $on('show_tax');
$showAdv = $on('show_advance'); $showPrev = $on('show_previous_debt'); ?>
<section class="panel on">
  <div class="chips">
    <?php foreach ($typeFa as $k => $v): ?>
      <button class="<?= $k === $type ? 'on' : '' ?>" onclick="location.href='<?= url('fida/invoices/create?type=' . $k) ?>'"><?= $v ?></button>
    <?php endforeach; ?>
  </div>
  <form method="post" action="<?= url('fida/invoices') ?>" id="invForm">
    <?= csrf_field() ?>
    <input type="hidden" name="invoice_type" value="<?= e($type) ?>">
    <div class="card">
      <div class="grid2">
        <div class="field"><label>نوع سند</label><input class="inp" value="<?= e($typeFa[$type]) ?>" readonly></div>
        <div class="field"><label>تاریخ</label><input class="inp" value="<?= e(jdate(today())) ?>" readonly></div>
      </div>
      <div class="field"><label>نوع پرداخت</label>
        <select class="inp" name="pay_method">
          <?php foreach (['cash' => 'نقدی', 'card' => 'کارت به کارت', 'credit' => 'اعتباری', 'transfer' => 'انتقال'] as $k => $v): ?><option value="<?= $k ?>" <?= $k === 'cash' ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
        </select></div>
    </div>

    <div class="sect"><h3><span class="n">۱</span> مشخصات شخص</h3>
      <div class="field"><label>شخص (مشتری/تأمین‌کننده) *</label>
        <select class="inp" name="person_id" required><option value="">— انتخاب از لیست —</option>
          <?php foreach ($persons as $ps): ?><option value="<?= (int)$ps['id'] ?>"><?= e($ps['full_name']) ?><?= $ps['phone'] ? ' — ' . e($ps['phone']) : '' ?></option><?php endforeach; ?>
        </select></div>
      <div class="grid2">
        <?php if ($showPrev): ?><div class="field"><label>بدهی قبلی (<?= $cur ?>)</label><input class="inp money" name="previous_debt_amount" value="0"></div><?php endif; ?>
        <?php if ($showAdv): ?><div class="field"><label>بیعانه دریافتی (<?= $cur ?>)</label><input class="inp money" name="advance_amount" value="0"></div><?php endif; ?>
      </div>
      <div class="field"><label>سررسید (فقط اعتباری)</label><input class="inp jalali" name="due_date" placeholder="۱۴۰۵/۰۷/۱۵"></div>
    </div>

    <div class="sect"><h3><span class="n">۲</span> اقلام کالا / خدمت</h3>
      <div class="thead"><span></span><span>شرح</span><span>تعداد</span><span>واحد</span><span>قیمت واحد</span><span>مبلغ</span><span></span></div>
      <div id="items">
        <div class="trow">
          <span class="idx">۱</span>
          <div class="cell c-name">
            <div class="cbx2 cbx-name">
              <input type="hidden" name="item_id[]" class="it-id">
              <input class="inp it-name" placeholder="جست‌وجو یا افزودن کالا…" autocomplete="off">
              <div class="cbx2-list"></div>
            </div>
          </div>
          <div class="cell c-qty"><span class="clbl">تعداد</span><input class="inp it-qty" name="quantity[]" value="1"></div>
          <div class="cell c-unit"><span class="clbl">واحد</span>
            <div class="cbx2 cbx-unit">
              <input class="inp it-unit" name="unit[]" value="عدد" placeholder="واحد…" autocomplete="off" title="واحد شمارش — برای دیدن فهرست کلیک کنید">
              <div class="cbx2-list"></div>
            </div>
          </div>
          <div class="cell c-price"><span class="clbl">قیمت واحد</span><input class="inp it-price money" name="unit_price[]" value="0"></div>
          <div class="cell c-amt"><span class="clbl">مبلغ</span><input class="it-amt" value="0" readonly></div>
          <button type="button" class="del" data-del-row title="حذف">×</button>
        </div>
      </div>
      <button type="button" class="btn btn-g" style="margin-top:8px" id="addRow">+ افزودن ردیف</button>
      <?php if (!empty($templates)): ?>
        <div class="field" style="margin-top:10px"><label>قالب آماده</label>
          <div style="display:flex;gap:8px">
            <select class="inp" id="tplSel"><option value="">— انتخاب قالب —</option>
              <?php foreach ($templates as $t): ?><option value="<?= (int)$t['id'] ?>"><?= e($t['name']) ?> (<?= num(count($t['items'])) ?>)</option><?php endforeach; ?></select>
            <button type="button" class="btn sm" id="applyTpl">اعمال</button>
          </div>
        </div>
      <?php endif; ?>
    </div>

    <div class="sect"><h3><span class="n">۳</span> جمع، مالیات و توضیحات</h3>
      <input type="hidden" name="discount_mode" id="discMode" value="<?= $dm ?>">
      <div class="grid2">
        <?php if ($showDisc): ?>
          <div class="field"><label>تخفیف <?= $dm === 'percent' ? '(٪)' : '(' . $cur . ')' ?></label>
            <input class="inp money" name="discount_value" id="discValue" value="0"></div>
        <?php endif; ?>
        <?php if ($showShip): ?>
          <div class="field"><label>هزینه ارسال (<?= $cur ?>)</label><input class="inp money" name="ship_amount" value="0"></div>
        <?php endif; ?>
      </div>
      <?php if ($showTax): ?>
      <div class="grid2">
        <div class="field"><label>نوع مالیات</label>
          <select class="inp" name="tax_mode" id="taxMode">
            <option value="percent">درصدی (٪)</option>
            <option value="amount">مبلغی (<?= $cur ?>)</option>
          </select></div>
        <div class="field"><label>مالیات</label>
          <input class="inp" name="tax_value" id="taxValue" value="<?= (float)$taxDefault ?>" inputmode="decimal" autocomplete="off"></div>
      </div>
      <?php endif; ?>
      <div class="sums">
        <div class="tot"><span>جمع اقلام</span><b id="sumItems">0</b></div>
        <?php if ($showDisc): ?><div class="tot"><span>تخفیف</span><b id="sumDisc">0</b></div><?php endif; ?>
        <?php if ($showShip): ?><div class="tot"><span>هزینه ارسال</span><b id="sumShip">0</b></div><?php endif; ?>
        <?php if ($showTax): ?><div class="tot"><span>مالیات <small id="taxModeLbl" style="color:var(--grey-50)"></small></span><b id="sumTax">0</b></div><?php endif; ?>
        <div class="grand"><span>مبلغ قابل پرداخت</span><b id="grand">0</b></div>
      </div>
      <div class="field" style="margin-top:8px"><label>توضیحات</label><input class="inp" name="notes"></div>
    </div>

    <div class="btns">
      <button class="btn btn-p" type="submit"><?= $type === 'pre_invoice' ? 'ثبت پیش‌فاکتور' : 'ثبت فاکتور' ?></button>
      <button class="btn btn-g" type="button" onclick="location.href='<?= url('fida/invoices') ?>'">انصراف</button>
    </div>
  </form>
</section>

<div class="modal-bg" id="itemModal">
  <div class="setcard" style="max-width:400px;width:100%;margin:0">
    <h3>➕ کالا / خدمت جدید</h3>
    <div class="field"><label>عنوان *</label><input class="inp" id="ni-title"></div>
    <div class="grid2">
      <div class="field"><label>واحد</label><input class="inp" id="ni-unit" value="عدد"></div>
      <div class="field"><label>قیمت واحد (<?= $cur ?>)</label><input class="inp money" id="ni-price" value="0"></div>
    </div>
    <div class="field"><label>نوع</label><select class="inp" id="ni-kind"><option value="supply">کالا</option><option value="service">خدمت</option></select></div>
    <div class="btns">
      <button type="button" class="btn btn-p" id="ni-save">ذخیره و انتخاب</button>
      <button type="button" class="btn btn-g" id="ni-cancel">انصراف</button>
    </div>
  </div>
</div>

<?php
$itemsJson = array_map(function ($it) {
    return ['id' => (int)$it['id'], 'title' => $it['title'], 'unit' => $it['unit'], 'unit_price' => (int)$it['unit_price']];
}, $items ?: []);
?>
<script type="application/json" id="tplData"><?= json_encode($templates ?? [], JSON_UNESCAPED_UNICODE) ?></script>
<script type="application/json" id="itemsData"><?= json_encode($itemsJson, JSON_UNESCAPED_UNICODE) ?></script>
<script type="application/json" id="unitsData"><?= json_encode(array_values($units ?? ['عدد']), JSON_UNESCAPED_UNICODE) ?></script>
<script>
(function () {
  var wrap = document.getElementById('items');
  var ITEMS = JSON.parse(document.getElementById('itemsData').textContent || '[]');
  var UNITS = JSON.parse((document.getElementById('unitsData') || {}).textContent || '["عدد"]');
  var modal = document.getElementById('itemModal');
  var pendingRow = null;

  function fa2en2(s) { return String(s == null ? '' : s).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[٠-٩]/g, function (c) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(c); }); }
  function num(v) { return parseFloat(fa2en2(v).replace(/[^\d.-]/g, '')) || 0; }
  function money(v) { return Number(v).toLocaleString('fa-IR'); }
  function norm(s) { return String(s == null ? '' : s).toLowerCase().replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').trim(); }
  function fa(v) { return Number(v).toLocaleString('fa-IR'); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[c]; }); }

  function recalc() {
    var total = 0;
    wrap.querySelectorAll('.trow').forEach(function (tr, i) {
      tr.querySelector('.idx').textContent = (i + 1).toLocaleString('fa-IR');
      var q = num(tr.querySelector('.it-qty').value), p = num(tr.querySelector('.it-price').value), a = q * p;
      tr.querySelector('.it-amt').value = a.toLocaleString('fa-IR'); total += a;
    });
    // تخفیف: درصدی یا مبلغی (بر پایهٔ تنظیمات)
    var dmEl = document.getElementById('discMode'), dvEl = document.getElementById('discValue');
    var dmode = dmEl ? dmEl.value : 'amount';
    var dv = dvEl ? num(dvEl.value) : 0;
    var d = dmode === 'percent' ? Math.round(total * Math.min(100, Math.max(0, dv)) / 100) : Math.max(0, dv);
    var shipEl = document.querySelector('[name=ship_amount]');
    var s = shipEl ? num(shipEl.value) : 0;
    var base = Math.max(0, total - d + s);
    var modeEl = document.getElementById('taxMode'), valEl = document.getElementById('taxValue');
    var mode = modeEl ? modeEl.value : 'percent';
    var tv = valEl ? num(valEl.value) : 0;
    var tax = !modeEl ? 0 : (mode === 'percent' ? Math.round(base * Math.min(100, tv) / 100) : Math.round(tv));
    document.getElementById('sumItems').textContent = fa(total);
    var sd = document.getElementById('sumDisc'); if (sd) sd.textContent = fa(d) + (dmode === 'percent' ? ' (' + fa(dv) + '٪)' : '');
    var ss = document.getElementById('sumShip'); if (ss) ss.textContent = fa(s);
    var st = document.getElementById('sumTax'); if (st) st.textContent = fa(tax);
    var lbl = document.getElementById('taxModeLbl');
    if (lbl) lbl.textContent = mode === 'percent' ? '(' + fa(tv) + '٪)' : '(مبلغی)';
    document.getElementById('grand').textContent = fa(base + tax);
  }

  function setItem(tr, it) {
    tr.querySelector('.it-id').value = it.id;
    tr.querySelector('.it-name').value = it.title;
    tr.querySelector('.it-unit').value = it.unit || '—';
    tr.querySelector('.it-price').value = money(it.unit_price || 0);
    if (window.FintoApp && window.FintoApp.initMoney) window.FintoApp.initMoney(tr);
    recalc();
  }

  function closeLists() { document.querySelectorAll('.cbx2-list.on').forEach(function (b) { b.classList.remove('on'); }); }

  function renderUnits(tr, all) {
    var inp = tr.querySelector('.it-unit');
    var box = inp.closest('.cbx2').querySelector('.cbx2-list');
    var q = all ? '' : norm(inp.value);
    var list = UNITS.filter(function (u) { return !q || norm(u).indexOf(q) !== -1; }).slice(0, 40);
    var html = list.map(function (u) { return '<div class="cbx2-item" data-unit="' + esc(u) + '"><span>' + esc(u) + '</span></div>'; }).join('');
    var exact = UNITS.some(function (u) { return norm(u) === q; });
    if (q && !exact) html += '<div class="cbx2-item cbx2-add" data-addunit="1">➕ افزودن واحد «' + esc(inp.value) + '»</div>';
    if (!html) html = '<div class="cbx2-empty">واحدی پیدا نشد</div>';
    box.innerHTML = html; box.classList.add('on');
  }

  function addUnitFromRow(tr, box) {
    var inp = tr.querySelector('.it-unit');
    var t = (inp.value || '').trim();
    if (t.length < 1) { alert('نام واحد را وارد کنید.'); return; }
    var body = new URLSearchParams();
    body.append('_token', window.CSRF || '');
    body.append('title', t);
    fetch(window.APP_BASE + '/fida/units/quick', { method: 'POST', body: body, headers: { 'X-CSRF-Token': window.CSRF || '' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.ok) { alert((j && j.error) || 'خطا در ذخیرهٔ واحد.'); return; }
        if (j.units && j.units.length) UNITS = j.units;
        inp.value = j.title;
        box.classList.remove('on');
      })
      .catch(function () { alert('خطا در ارتباط با سرور.'); });
  }

  function renderList(tr, all) {
    var box = tr.querySelector('.it-name').closest('.cbx2').querySelector('.cbx2-list');
    var raw = tr.querySelector('.it-name').value;
    var q = all ? '' : norm(raw);
    var list = ITEMS.filter(function (it) { return !q || norm(it.title).indexOf(q) !== -1; }).slice(0, 60);
    var html = list.map(function (it) {
      return '<div class="cbx2-item" data-id="' + it.id + '"><span>' + esc(it.title) + '</span><small>' + money(it.unit_price) + ' · ' + esc(it.unit || '') + '</small></div>';
    }).join('');
    var exact = ITEMS.some(function (it) { return norm(it.title) === q; });
    if (q && !exact) html += '<div class="cbx2-item cbx2-add" data-add="1">➕ افزودن «' + esc(raw) + '»</div>';
    if (!html) html = '<div class="cbx2-empty">موردی پیدا نشد</div>';
    box.innerHTML = html; box.classList.add('on');
  }

  function openAdd(tr) {
    pendingRow = tr;
    document.getElementById('ni-title').value = tr.querySelector('.it-name').value;
    document.getElementById('ni-unit').value = 'عدد';
    document.getElementById('ni-price').value = '0';
    document.getElementById('ni-kind').value = 'supply';
    closeLists();
    modal.classList.add('on');
    setTimeout(function () { document.getElementById('ni-title').focus(); }, 30);
  }

  /** اتصال یک کمبوباکس (کالا یا واحد) به ورودی و فهرستش */
  function bindCbx(input, render, onPick) {
    var box = input.closest('.cbx2').querySelector('.cbx2-list');
    input.addEventListener('focus', function () { closeLists(); render(true); });
    input.addEventListener('input', function () { render(false); });
    input.addEventListener('blur', function () { setTimeout(closeLists, 160); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeLists(); return; }
      if (e.key === 'Enter') {
        e.preventDefault();
        if (!box.classList.contains('on')) render(false);
        var first = box.querySelector('.cbx2-item');
        if (first) first.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      }
    });
    box.addEventListener('mousedown', function (e) {
      var row = e.target.closest ? e.target.closest('.cbx2-item') : null;
      if (!row) return;
      e.preventDefault();
      onPick(row, box);
    });
  }

  function bind(tr) {
    tr.addEventListener('input', recalc);
    // کمبوباکس کالا/خدمت
    bindCbx(tr.querySelector('.it-name'), function (all) { renderList(tr, all); }, function (row, box) {
      if (row.getAttribute('data-add')) { openAdd(tr); return; }
      var it = ITEMS.filter(function (x) { return String(x.id) === row.getAttribute('data-id'); })[0];
      if (it) { setItem(tr, it); box.classList.remove('on'); }
    });
    // کمبوباکس واحد (پیش‌فرض: عدد — قابل تغییر و افزودن)
    bindCbx(tr.querySelector('.it-unit'), function (all) { renderUnits(tr, all); }, function (row, box) {
      if (row.getAttribute('data-addunit')) { addUnitFromRow(tr, box); return; }
      var u = row.getAttribute('data-unit');
      if (u !== null) { tr.querySelector('.it-unit').value = u; box.classList.remove('on'); }
    });
    tr.querySelector('[data-del-row]').addEventListener('click', function () {
      if (wrap.querySelectorAll('.trow').length > 1) { tr.remove(); recalc(); }
    });
  }

  wrap.querySelectorAll('.trow').forEach(bind);
  var dvi = document.getElementById('discValue'); if (dvi) dvi.addEventListener('input', recalc);
  var shi = document.querySelector('[name=ship_amount]'); if (shi) shi.addEventListener('input', recalc);
  var tm = document.getElementById('taxMode'), tvv = document.getElementById('taxValue');
  if (tm) { tm.addEventListener('change', function () { if (this.value === 'percent' && !num(tvv.value)) tvv.value = '<?= (float)$taxDefault ?>'; recalc(); }); }
  if (tvv) { tvv.addEventListener('input', recalc); }

  var tplRow = wrap.querySelector('.trow').cloneNode(true);
  document.getElementById('addRow').addEventListener('click', function () {
    var tr = tplRow.cloneNode(true);
    tr.querySelector('.it-name').value = ''; tr.querySelector('.it-id').value = '';
    tr.querySelector('.it-qty').value = '1'; tr.querySelector('.it-price').value = '0';
    tr.querySelector('.it-unit').value = 'عدد'; tr.querySelector('.it-amt').value = '0';
    wrap.appendChild(tr); bind(tr);
    if (window.FintoApp && window.FintoApp.initMoney) window.FintoApp.initMoney(tr);
    if (window.FintoApp && window.FintoApp.initDigits) window.FintoApp.initDigits(tr);
    recalc();
  });

  document.getElementById('ni-cancel').addEventListener('click', function () { modal.classList.remove('on'); });
  modal.addEventListener('click', function (e) { if (e.target === modal) modal.classList.remove('on'); });
  document.getElementById('ni-save').addEventListener('click', function () {
    var t = document.getElementById('ni-title').value.trim();
    if (t.length < 2) { alert('عنوان کالا را وارد کنید.'); return; }
    var body = new URLSearchParams();
    body.append('_token', window.CSRF || '');
    body.append('title', t);
    body.append('unit', document.getElementById('ni-unit').value);
    body.append('unit_price', document.getElementById('ni-price').value);
    body.append('kind', document.getElementById('ni-kind').value);
    fetch(window.APP_BASE + '/fida/items/quick', { method: 'POST', body: body, headers: { 'X-CSRF-Token': window.CSRF || '' } })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.ok) { alert((j && j.error) || 'خطا در ذخیره.'); return; }
        if (!ITEMS.some(function (x) { return String(x.id) === String(j.item.id); })) ITEMS.push(j.item);
        if (pendingRow) setItem(pendingRow, j.item);
        modal.classList.remove('on');
      })
      .catch(function () { alert('خطا در ارتباط با سرور.'); });
  });

  var TPL = JSON.parse(document.getElementById('tplData').textContent || '[]');
  var ap = document.getElementById('applyTpl');
  if (ap) ap.addEventListener('click', function () {
    var id = document.getElementById('tplSel').value; if (!id) return;
    var t = TPL.filter(function (x) { return String(x.id) === String(id); })[0]; if (!t) return;
    wrap.innerHTML = '';
    (t.items || []).forEach(function (it) {
      var tr = tplRow.cloneNode(true);
      tr.querySelector('.it-qty').value = it.quantity || 1;
      wrap.appendChild(tr); bind(tr);
      var nt = norm(it.item_title);
      var match = nt ? ITEMS.filter(function (x) { return norm(x.title).indexOf(nt) !== -1; })[0] : null;
      if (match) setItem(tr, match);
      tr.querySelector('.it-price').value = money(it.unit_price || 0);
      if (it.unit) tr.querySelector('.it-unit').value = it.unit;
      if (window.FintoApp && window.FintoApp.initMoney) window.FintoApp.initMoney(tr);
    });
    recalc();
  });

  recalc();
})();
</script>
<?= view('partials/fida_foot') ?>
