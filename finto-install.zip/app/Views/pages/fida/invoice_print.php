<?= view('partials/public_head', ['title' => $title]) ?>
<?php $titles = ['sale'=>'فاکتور فروش','pre_invoice'=>'پیش‌فاکتور','purchase'=>'فاکتور خرید'];
$cur = Fida::unit($s);                       // واحد پول از تنظیمات
$on  = static fn($k) => !empty($s[$k]);      // تنظیمات نمایش هر ردیف ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
  <?= view('partials/print_bar', ['back' => url('fida/invoices/'.$inv['id'])]) ?>
  <style>
  :root{
    --acc: <?= Fida::accent($s['accent_color'] ?? 'purple', 0) ?>;
    --acc-soft: <?= Fida::accent($s['accent_color'] ?? 'purple', 1) ?>;
    --acc-ink: <?= Fida::accent($s['accent_color'] ?? 'purple', 2) ?>;
    --acc-line: <?= Fida::accent($s['accent_color'] ?? 'purple', 3) ?>;
  }
  .print-head{border-bottom-color:var(--acc)}
  .print-head h1,.print-head h2,.print-head .biz{color:var(--acc-ink)}
  .inv-type{color:var(--acc)}
  table.print-tbl thead th{background:var(--acc-soft);color:var(--acc-ink);border-color:var(--acc-line)}
  table.print-tbl tbody td{border-color:var(--acc-line)}
  table.print-tbl tbody tr:nth-child(even) td{background:var(--acc-soft)}
  table.print-tbl tfoot th{background:var(--acc-soft);color:var(--acc-ink);border-color:var(--acc-line)}
  table.print-tbl tfoot tr.total th{background:var(--acc);color:#fff;border-color:var(--acc)}
  .words{background:var(--acc-soft);border-color:var(--acc-line);color:var(--acc-ink)}
  /* لوگو در سربرگ */
  .print-logo{max-height:62px;max-width:170px;object-fit:contain;display:block;margin-bottom:7px}
  /* مهر و امضا */
  .signs{align-items:flex-end}
  .signs>div{flex:1;text-align:center;border-top:0;padding-top:0}
  .signs>div>.sign-imgs{display:flex;align-items:flex-end;justify-content:center;gap:14px;
    min-height:80px;padding-bottom:6px;break-inside:avoid}
  .signs>div>.sign-imgs img{max-height:80px;max-width:150px;object-fit:contain;display:block}
  .signs>div>span{display:block;border-top:1px dashed var(--acc-line);padding-top:7px;font-size:11.5px;color:#4B5563}
  /* اطلاعات حساب بانکی */
  .bank-box{margin-top:9px;border:1px solid var(--acc-line);border-radius:10px;padding:9px 12px;background:var(--acc-soft);break-inside:avoid}
  .bank-box .bank-t{font-size:11.6px;font-weight:800;color:var(--acc-ink);margin-bottom:5px}
  .bank-box .bank-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:3px 14px;font-size:11.6px;color:#374151}
  .bank-box .bank-grid b{color:var(--acc-ink);font-weight:800;letter-spacing:.4px}
  @media print{.bank-box{background:#fff}}
  </style>
  <div class="print-head">
    <div>
      <?php $logoUrl = Fida::imageUrl($s['logo_path'] ?? null); if ($logoUrl): ?>
        <img class="print-logo" src="<?= e($logoUrl) ?>" alt="لوگو">
      <?php endif; ?>
      <?php if (!empty($s['header_title'])): ?><div class="head-title" style="font-size:13.5px;font-weight:800;color:var(--acc-ink);margin-bottom:2px"><?= e($s['header_title']) ?></div><?php endif; ?>
      <div class="biz"><?= e($s['shop_name'] ?? 'فروشگاه') ?></div>
      <div class="print-meta">
        <?php if (!empty($s['shop_address'])): ?>نشانی: <?= e($s['shop_address']) ?><br><?php endif; ?>
        <?php if (!empty($s['shop_phone'])): ?>تلفن: <b dir="ltr"><?= e($s['shop_phone']) ?></b><br><?php endif; ?>
        <?php if (!empty($s['header_description'])): ?><?= e($s['header_description']) ?><?php endif; ?>
      </div>
    </div>
    <div style="text-align:left">
      <div class="inv-type" style="font-size:16px;font-weight:800"><?= e($titles[$inv['invoice_type']] ?? 'فاکتور') ?></div>
      <div class="print-meta">شماره: <b dir="ltr"><?= e(fa_digits((string)$inv['invoice_code'])) ?></b><br>تاریخ: <b><?= e(fa_digits($inv['invoice_jalali'])) ?></b>
      <?php if (!empty($inv['due_jalali'])): ?><br>سررسید: <b><?= e(fa_digits($inv['due_jalali'])) ?></b><?php endif; ?>
      <?php if (empty($s) || !empty($s['show_types'])): ?><br>نوع پرداخت: <b><?= e(['cash'=>'نقدی','card'=>'کارت','credit'=>'اعتباری','transfer'=>'انتقال'][$inv['pay_method'] ?? ''] ?? '—') ?></b><?php endif; ?></div>
    </div>
  </div>
  <div class="print-meta" style="margin-bottom:8px">
    خریدار/طرف حساب: <b><?= e($inv['person_name']) ?></b><?php if (!empty($inv['city'])): ?> — <?= e($inv['city']) ?><?php endif; ?>
  </div>
  <table class="print-tbl">
    <thead><tr><th style="width:38px">#</th><th>کالا / خدمت</th><th>واحد</th><th>مقدار</th><th>قیمت واحد</th><th>جمع</th></tr></thead>
    <tbody>
    <?php foreach ($items as $i => $it): ?>
      <tr><td><?= num($i+1) ?></td><td><?= e($it['item_title']) ?></td><td><?= e($it['unit']) ?></td>
        <td><?= num($it['quantity'], 2) ?></td><td><?= num($it['unit_price']) ?></td><td><?= num($it['total_price']) ?></td></tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><th colspan="5">جمع اقلام</th><th><?= num($inv['total_amount']) ?></th></tr>
      <?php if ((int)$inv['discount_amount'] > 0 && ($on('show_discount') || (int)$inv['discount_amount'] > 0)): ?>
        <tr><th colspan="5">تخفیف</th><th><?= num($inv['discount_amount']) ?></th></tr>
      <?php endif; ?>
      <?php if ((int)($inv['ship_amount'] ?? 0) > 0 && ($on('show_ship') || (int)$inv['ship_amount'] > 0)): ?>
        <tr><th colspan="5">هزینه ارسال</th><th><?= num($inv['ship_amount']) ?></th></tr>
      <?php endif; ?>
      <?php if ((int)($inv['tax_amount'] ?? 0) > 0 && ($on('show_tax') || (int)$inv['tax_amount'] > 0)): ?>
        <tr><th colspan="5">مالیات<?= (float)($inv['tax_percent'] ?? 0) > 0 ? ' (' . num($inv['tax_percent'], 0) . '٪)' : '' ?></th><th><?= num($inv['tax_amount']) ?></th></tr>
      <?php endif; ?>
      <?php if ((int)($inv['previous_debt_amount'] ?? 0) > 0 && ($on('show_previous_debt') || (int)$inv['previous_debt_amount'] > 0)): ?>
        <tr><th colspan="5">بدهی قبلی</th><th><?= num($inv['previous_debt_amount']) ?></th></tr>
      <?php endif; ?>
      <tr class="total"><th colspan="5">مبلغ قابل پرداخت <small style="font-weight:600">(<?= e($cur) ?>)</small></th><th><?= num($inv['final_amount']) ?></th></tr>
      <?php if ((int)($inv['advance_amount'] ?? 0) > 0 && $on('show_advance')): ?>
        <tr><th colspan="5">بیعانه دریافتی</th><th><?= num($inv['advance_amount']) ?></th></tr>
      <?php endif; ?>
      <?php if ((int)$inv['paid_amount'] > 0): ?>
        <tr><th colspan="5">پرداخت‌شده</th><th><?= num($inv['paid_amount']) ?></th></tr>
        <tr><th colspan="5">مانده</th><th><?= num($inv['balance_amount']) ?></th></tr>
      <?php endif; ?>
    </tfoot>
  </table>
  <div class="words">مبلغ به حروف: <?= e(amount_in_words((float)$inv['final_amount'], $cur)) ?></div>
  <?php if (!empty($inv['notes'])): ?><div class="words" style="border-style:solid">توضیحات: <?= e($inv['notes']) ?></div><?php endif; ?>
  <?php $fidaBank = (!empty($s['show_bank_info']) && class_exists('Fida')) ? Fida::defaultBank() : null; ?>
  <?php if ($fidaBank): ?>
    <div class="bank-box">
      <div class="bank-t">💳 اطلاعات پرداخت — جهت واریز مبلغ فاکتور</div>
      <div class="bank-grid">
        <span>بانک: <b><?= e($fidaBank['bank_name']) ?></b></span>
        <span>صاحب حساب: <b><?= e($fidaBank['account_holder']) ?></b></span>
        <?php if (!empty($fidaBank['card_no'])): ?><span>شماره کارت: <b dir="ltr"><?= e(Fida::groupDigits($fidaBank['card_no'])) ?></b></span><?php endif; ?>
        <?php if (!empty($fidaBank['iban'])): ?><span>شبا: <b dir="ltr"><?= e($fidaBank['iban']) ?></b></span><?php endif; ?>
        <?php if (!empty($fidaBank['account_no'])): ?><span>شماره حساب: <b dir="ltr"><?= e($fidaBank['account_no']) ?></b></span><?php endif; ?>
      </div>
    </div>
  <?php endif; ?>
  <?php $stampUrl = Fida::imageUrl($s['stamp_path'] ?? null); $signUrl = Fida::imageUrl($s['signature_path'] ?? null); ?>
  <div class="signs">
    <div>
      <?php if ($stampUrl || $signUrl): ?>
        <div class="sign-imgs">
          <?php if ($stampUrl): ?><img src="<?= e($stampUrl) ?>" alt="مهر"><?php endif; ?>
          <?php if ($signUrl): ?><img src="<?= e($signUrl) ?>" alt="امضا"><?php endif; ?>
        </div>
      <?php endif; ?>
      <span>مهر و امضای فروشنده</span>
    </div>
    <div><span>امضای خریدار</span></div>
  </div>
  <div class="print-foot"><span><?= e($s['owner_name'] ?? '') ?> — <?= e($s['shop_name'] ?? '') ?></span><span>چاپ <?= e(jdate(today())) ?></span></div>
</div>
<?= view('partials/public_foot') ?>
