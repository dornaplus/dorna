<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$chip = ['paid'=>['c-done','پرداخت‌شده'],'credit'=>['c-credit','اعتباری'],'pending'=>['c-wait','در انتظار تأیید'],'converted'=>['c-pre','تبدیل‌شده'],'closed'=>['c-done','بسته']];
$c = $chip[$inv['status']] ?? ['c-wait', $inv['status']];
$typeFa = ['sale'=>'فاکتور فروش','pre_invoice'=>'پیش‌فاکتور','purchase'=>'فاکتور خرید'];
?>
<section class="panel on">
  <div class="card">
    <div class="hello">
      <div class="av"><?= e(mb_substr((string)$inv['person_name'], 0, 1)) ?></div>
      <div><b><?= e($inv['person_name']) ?></b>
        <small dir="ltr"><?= e(fa_digits((string)$inv['invoice_code'])) ?> · <?= e(fa_digits($inv['invoice_jalali'])) ?></small>
        <span class="chip <?= $c[0] ?>"><?= e($c[1]) ?></span></div>
      <div class="grow" style="flex:1"></div>
      <div class="amt"><?= num($inv['final_amount']) ?><small><?= Fida::unit() ?></small></div>
    </div>
    <div class="btns" style="margin-top:10px">
      <a class="btn btn-g sm" href="<?= url('fida/invoices') ?>">فهرست</a>
      <a class="btn sm" href="<?= url('fida/invoices/'.(int)$inv['id'].'/print') ?>" target="_blank">چاپ</a>
      <?php if ($inv['invoice_type'] === 'pre_invoice'): ?>
        <form method="post" action="<?= url('fida/invoices/'.(int)$inv['id'].'/convert') ?>" style="display:inline"><?= csrf_field() ?>
          <button class="btn btn-p sm" type="submit">تبدیل به فاکتور فروش</button></form>
      <?php endif; ?>
    </div>
  </div>

  <h2 class="sec">اقلام</h2>
  <div class="card" style="padding:.4rem .2rem">
    <div class="thead"><span></span><span>شرح</span><span>تعداد</span><span>واحد</span><span>قیمت واحد</span><span>مبلغ</span><span></span></div>
    <?php foreach ($items as $i => $it): ?>
      <div class="trow">
        <span class="idx"><?= num($i + 1) ?></span>
        <span class="it-name"><?= e($it['item_title']) ?></span>
        <span class="it-qty"><?= num($it['quantity'], 2) ?></span>
        <span class="it-unit"><?= e($it['unit']) ?></span>
        <span class="it-price"><?= num($it['unit_price']) ?></span>
        <span class="it-amt"><?= num($it['total_price']) ?></span>
        <span></span>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="sums">
    <div class="tot"><span>جمع اقلام</span><b><?= num($inv['total_amount']) ?></b></div>
    <div class="tot"><span>تخفیف</span><b><?= num($inv['discount_amount']) ?></b></div>
    <div class="tot"><span>هزینه ارسال</span><b><?= num($inv['ship_amount']) ?></b></div>
    <?php if ((int)($inv['tax_amount'] ?? 0) > 0): ?>
      <div class="tot"><span>مالیات<?= (float)($inv['tax_percent'] ?? 0) > 0 ? ' (' . num($inv['tax_percent'], 0) . '٪)' : '' ?></span><b><?= num($inv['tax_amount']) ?></b></div>
    <?php endif; ?>
    <div class="tot"><span>پرداخت‌شده</span><b><?= num($inv['paid_amount']) ?></b></div>
    <div class="grand"><span>مانده قابل پرداخت</span><b><?= num($inv['balance_amount']) ?></b></div>
  </div>

  <div class="sect"><h3><span class="n">💳</span> ثبت پرداخت</h3>
    <form method="post" action="<?= url('fida/payments') ?>" id="payForm"><?= csrf_field() ?>
      <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
      <div class="grid2">
        <div class="field"><label>مبلغ (<?= Fida::unit() ?>)</label><input class="inp money" name="amount" value="<?= num($inv['balance_amount'], 0) ?>"></div>
        <div class="field"><label>روش</label><select class="inp" name="pay_method" id="payMethod">
          <?php foreach (['cash'=>'نقد','card'=>'کارت','transfer'=>'انتقال','check'=>'چک'] as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?></select></div>
      </div>
      <div id="chequeFields" hidden>
        <div class="grid2">
          <div class="field"><label>شمارهٔ چک</label><input class="inp" name="cheque_no" placeholder="۱۲۳۴۵۶"></div>
          <div class="field"><label>بانک</label><input class="inp" name="cheque_bank" placeholder="ملی، صادرات، …"></div>
        </div>
        <div class="field"><label>سررسید چک</label><input class="inp jalali" name="cheque_due" placeholder="۱۴۰۵/۰۸/۰۱"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>تاریخ</label><input class="inp jalali" name="paid_at" value="<?= e(jdate(today())) ?>"></div>
        <div class="field"><label>یادداشت</label><input class="inp" name="note"></div>
      </div>
      <button class="btn btn-p" style="width:100%" type="submit">ثبت پرداخت</button>
    </form>
  </div>

  <?php if (!empty($cheques)): ?>
    <div class="sect"><h3><span class="n">🧾</span> چک‌های این فاکتور</h3>
      <?php foreach ($cheques as $ch): ?>
        <div class="row" onclick="location.href='<?= url('fida/cheques/' . (int)$ch['id'] . '/edit') ?>'">
          <div class="thumb <?= $ch['direction'] === 'issued' ? 't-buy' : 't-sell' ?>"><?= $ch['direction'] === 'issued' ? '📤' : '📥' ?></div>
          <div class="m"><b><?= e(fa_digits((string)$ch['cheque_no'])) ?><?= $ch['bank_name'] ? ' · ' . e($ch['bank_name']) : '' ?></b>
            <small>سررسید <?= e(fa_digits($ch['due_jalali'])) ?></small></div>
          <div class="amt"><?= num($ch['amount']) ?><small><?= Fida::unit() ?></small></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>

  <script>
  (function () {
    var sel = document.getElementById('payMethod');
    var box = document.getElementById('chequeFields');
    if (!sel || !box) return;
    function sync() { box.hidden = sel.value !== 'check'; }
    sel.addEventListener('change', sync); sync();
  })();
  </script>

  <div class="sect"><h3><span class="n">⚙</span> وضعیت</h3>
    <form method="post" action="<?= url('fida/invoices/'.(int)$inv['id'].'/status') ?>"><?= csrf_field() ?>
      <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
      <div style="display:flex;gap:8px">
        <select class="inp" name="status">
          <?php foreach (['paid'=>'پرداخت‌شده','credit'=>'اعتباری','pending'=>'در انتظار','converted'=>'تبدیل‌شده','closed'=>'بسته'] as $k=>$v): ?>
            <option value="<?= $k ?>" <?= $inv['status']===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
        </select>
        <button class="btn btn-g" type="submit">تغییر</button>
      </div>
    </form>
  </div>

  <h2 class="sec">پرداخت‌ها</h2>
  <?php foreach ($pays as $p): ?>
    <div class="row"><div class="thumb t-pre">💳</div>
      <div class="m"><b><?= e(Meta::enumLabel($p['pay_method'])) ?></b><small dir="ltr"><?= e(fa_digits($p['paid_jalali'])) ?><?= $p['note'] ? ' · ' . e($p['note']) : '' ?></small></div>
      <div class="amt"><?= num($p['amount']) ?><small><?= Fida::unit() ?></small></div></div>
  <?php endforeach; ?>
  <?php if (!$pays): ?><div class="card center muted">پرداختی ثبت نشده.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
