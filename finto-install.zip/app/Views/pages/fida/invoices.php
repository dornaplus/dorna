<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$chip = ['paid'=>['c-done','پرداخت‌شده'],'credit'=>['c-credit','اعتباری'],'pending'=>['c-wait','در انتظار تأیید'],'converted'=>['c-pre','تبدیل‌شده'],'closed'=>['c-done','بسته']];
$thumb = ['sale'=>'t-sell','pre_invoice'=>'t-pre','purchase'=>'t-buy'];
$ticon = ['sale'=>'🧾','pre_invoice'=>'📝','purchase'=>'📦'];
$typeFa = ['sale'=>'فروش','pre_invoice'=>'پیش‌فاکتور','purchase'=>'خرید'];
?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">فاکتورهای من <span class="m" style="color:var(--grey-50)"><?= num(count($rows)) ?> عدد</span></h2>
  <div class="chips">
    <button class="<?= $type === '' ? 'on' : '' ?>" onclick="location.href='<?= url('fida/invoices') ?>'">همه</button>
    <button class="<?= $type === 'sale' ? 'on' : '' ?>" onclick="location.href='<?= url('fida/invoices?type=sale') ?>'">فروش</button>
    <button class="<?= $type === 'pre_invoice' ? 'on' : '' ?>" onclick="location.href='<?= url('fida/invoices?type=pre_invoice') ?>'">پیش‌فاکتور</button>
    <button class="<?= $type === 'purchase' ? 'on' : '' ?>" onclick="location.href='<?= url('fida/invoices?type=purchase') ?>'">خرید</button>
  </div>
  <form method="get" class="card tight" style="display:flex;gap:.5rem;align-items:center;margin-bottom:10px">
    <?php if ($type !== ''): ?><input type="hidden" name="type" value="<?= e($type) ?>"><?php endif; ?>
    <input class="inp" name="q" value="<?= e($q) ?>" placeholder="کد فاکتور یا نام شخص…">
    <button class="btn sm" type="submit">جست‌وجو</button>
  </form>
  <?php foreach ($rows as $r): $c = $chip[$r['status']] ?? ['c-wait', $r['status']]; ?>
    <div class="row" onclick="location.href='<?= url('fida/invoices/'.(int)$r['id']) ?>'">
      <div class="thumb <?= $thumb[$r['invoice_type']] ?? 't-sell' ?>"><?= $ticon[$r['invoice_type']] ?? '🧾' ?></div>
      <div class="m"><b><?= e($r['person_name']) ?></b><small dir="ltr"><?= e(fa_digits((string)$r['invoice_code'])) ?> · <?= e(fa_digits($r['invoice_jalali'])) ?></small>
        <span class="chip <?= $c[0] ?>"><?= e($c[1]) ?></span></div>
      <div class="amt"><?= num($r['final_amount']) ?><small><?= Fida::unit() ?></small></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="card center muted">فاکتوری یافت نشد.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
