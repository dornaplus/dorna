<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0"><?= e($title) ?></h2>
  <form method="post" action="<?= url('fida/items') ?>"><?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
    <div class="sect"><h3><span class="n">۱</span> مشخصات کالا/خدمت</h3>
      <div class="field"><label>عنوان *</label><input class="inp" name="title" value="<?= e($row['title'] ?? '') ?>" required></div>
      <div class="grid2">
        <div class="field"><label>نوع</label><select class="inp" name="kind">
          <?php foreach (['supply'=>'کالا','service'=>'خدمت'] as $k=>$v): ?><option value="<?= $k ?>" <?= ($row['kind']??'supply')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>واحد</label><input class="inp" name="unit" value="<?= e($row['unit'] ?? 'عدد') ?>"></div>
      </div>
      <div class="field"><label>قیمت واحد (<?= Fida::unit() ?>)</label><input class="inp money" name="unit_price" value="<?= e($row['unit_price'] ?? '0') ?>"></div>
      <div class="field"><label>وضعیت</label><select class="inp" name="is_active">
        <option value="1" <?= ($row['is_active'] ?? 1) ? 'selected' : '' ?>>فعال</option><option value="0" <?= isset($row['is_active']) && !$row['is_active'] ? 'selected' : '' ?>>غیرفعال</option></select></div>
    </div>
    <div class="btns"><button class="btn btn-p" type="submit">ذخیره</button><button class="btn btn-g" type="button" onclick="location.href='<?= url('fida/items') ?>'">انصراف</button></div>
  </form>
</section>
<?= view('partials/fida_foot') ?>
