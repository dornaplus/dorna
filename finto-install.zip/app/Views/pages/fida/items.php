<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">کالاها و خدمات <span class="m" style="color:var(--grey-50)"><?= num(count($rows)) ?> مورد</span></h2>
  <div class="quicks" style="margin-bottom:10px">
    <div class="qk" onclick="location.href='<?= url('fida/items/create') ?>'"><div class="i">＋</div><span>کالا/خدمت جدید</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/invoices/create?type=sale') ?>'"><div class="i">🧾</div><span>فاکتور جدید</span></div>
  </div>
  <?php foreach ($rows as $r): ?>
    <div class="row" onclick="location.href='<?= url('fida/items/'.(int)$r['id'].'/edit') ?>'">
      <div class="thumb <?= $r['kind'] === 'service' ? 't-pre' : 't-buy' ?>"><?= $r['kind'] === 'service' ? '🛠' : '📦' ?></div>
      <div class="m"><b><?= e($r['title']) ?></b><small><?= $r['kind'] === 'service' ? 'خدمت' : 'کالا' ?> · واحد <?= e($r['unit']) ?></small></div>
      <div class="amt"><?= num($r['unit_price']) ?><small><?= Fida::unit() ?></small></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="card center muted">کالایی ثبت نشده است.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
