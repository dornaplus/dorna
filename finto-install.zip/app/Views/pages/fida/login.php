<?php
$mode = $mode ?? 'login';
$isRegister = $mode === 'register';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= $isRegister ? 'ثبت‌نام' : 'ورود' ?> | اپ فاکتورزنی فیدا</title>
<meta name="theme-color" content="#6D28D9">
<link rel="manifest" href="<?= url('manifest-fida.webmanifest') ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= asset('pwa/fida-32.png') ?>">
<link rel="icon" href="<?= asset('pwa/favicon.ico') ?>" sizes="any">
<link rel="apple-touch-icon" href="<?= asset('pwa/fida-180.png') ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="فیدا">
<link rel="stylesheet" href="<?= asset('fida-auth.css') ?>?v=1">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>

<div class="footer-glow" aria-hidden="true"></div>

<main class="page">
  <div class="brand-mark">
    <span class="owl"><img src="<?= asset('fida-owl.png') ?>" alt="فیدا"></span>
    <span>فیدا<small>اپ فاکتورزنی</small></span>
  </div>

  <div class="tabs" role="tablist">
    <button type="button" role="tab" class="<?= !$isRegister ? 'on' : '' ?>" onclick="location.href='<?= url('fida/login') ?>'">ورود</button>
    <button type="button" role="tab" class="<?= $isRegister ? 'on' : '' ?>" onclick="location.href='<?= url('fida/login?mode=register') ?>'">ثبت‌نام</button>
  </div>

  <div class="head">
    <h1><?= $isRegister ? 'حساب جدید بساز' : 'شماره موبایلت رو وارد کن' ?></h1>
    <p class="sub"><?= $isRegister ? 'نام و شماره‌ات رو بده؛ کد تایید پیامک می‌شه.' : 'کد تایید برات پیامک می‌شه.' ?></p>
  </div>

  <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

  <form class="form" method="post" action="<?= url('fida/login') ?>">
    <?= csrf_field() ?>
    <input type="hidden" name="mode" value="<?= $isRegister ? 'register' : 'login' ?>">

    <?php if ($isRegister): ?>
      <label class="name-field">
        <input type="text" name="full_name" value="<?= e($oldName ?? '') ?>" placeholder="نام و نام خانوادگی" autocomplete="name" required>
      </label>
    <?php endif; ?>

    <div class="field-shell">
      <div class="fx blur-animated" role="presentation"></div>
      <div class="fx border-animated" role="presentation"></div>
      <div class="phone-field">
        <span class="prefix"><span class="cc">+98</span></span>
        <input type="tel" name="mobile" value="<?= e($oldMobile ?? '') ?>" inputmode="numeric" maxlength="11"
               pattern="09[0-9]{9}" required
               placeholder="0912 123 4567"
               autocomplete="tel-national"
               aria-label="شماره موبایل"
               title="شماره موبایل ۱۱ رقمی با ۰۹">
      </div>
    </div>

    <button type="submit" class="btn"><?= $isRegister ? 'ثبت‌نام و دریافت کد' : 'تایید و دریافت کد' ?></button>

    <p class="legal">
      ورود فقط با <b>کد پیامکی</b> انجام می‌شود — نیازی به رمز عبور نیست.<br>
      با ادامه، <a href="#">شرایط و قوانین</a> و <a href="#">سیاست حریم خصوصی</a> را می‌پذیرم.
    </p>
  </form>

  <?php if (config('app')['demo_mode']): ?>
    <div class="demo">
      حالت نمایشی — کاربران نمونه: <code>09120000001</code> تا <code>09120000004</code>
      <?php if ($isRegister): ?><br>برای ثبت‌نام از شمارهٔ دیگری استفاده کنید.<?php endif; ?>
    </div>
  <?php endif; ?>

  <a class="back-home" href="<?= url('login?mode=pro') ?>">بازگشت به سامانه حسابداری فینتو</a>
</main>

<script>
(function () {
  function fa2en(s) {
    return String(s == null ? '' : s)
      .replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); })
      .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); });
  }
  var phone = document.querySelector('.phone-field input');
  if (phone) {
    var clean = function () {
      var v = fa2en(phone.value).replace(/\D/g, '').slice(0, 11);
      if (v !== phone.value) {
        var pos = phone.selectionStart;
        phone.value = v;
        try { phone.setSelectionRange(v.length, v.length); } catch (e) {}
      }
    };
    phone.addEventListener('input', clean);
    phone.addEventListener('keyup', clean);
    phone.addEventListener('paste', function () { setTimeout(clean, 0); });
    phone.addEventListener('blur', clean);
    clean();
  }
})();
</script>
<script>window.PWA_APP = 'fida'; window.PWA_FAB = false; window.PWA_BTN = false;</script>
<script src="<?= asset('pwa.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../../public/assets/pwa.js') ?: 1 ?>"></script>

</body>
</html>
