<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$sevLabel = ['danger' => 'فوری', 'warn' => 'نزدیک', 'info' => 'یادآوری'];
?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">اعلان‌ها
    <span class="m" style="color:var(--grey-50)"><?= $unread > 0 ? num($unread) . ' خوانده‌نشده' : 'همه خوانده‌شده' ?></span></h2>

  <?php if ($items): ?>
    <div style="display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap">
      <?php if ($unread > 0): ?>
      <form method="post" action="<?= url('fida/notifications/read-all') ?>" style="display:inline;margin:0">
        <?= csrf_field() ?>
        <button class="btn btn-g sm" type="submit">همه را خوانده‌شده کن</button>
      </form>
      <?php endif; ?>
      <form method="post" action="<?= url('fida/notifications/dismiss-all') ?>" style="display:inline;margin:0"
            onsubmit="return confirm('همهٔ اعلان‌ها برای شما حذف شوند؟ (فقط برای پروفایل شما)')">
        <?= csrf_field() ?>
        <button class="btn btn-danger sm" type="submit">حذف همه</button>
      </form>
    </div>
  <?php endif; ?>

  <?php foreach ($items as $it): ?>
    <div class="card notice <?= $it['read'] ? 'is-read' : '' ?>" data-sev="<?= e($it['severity']) ?>">
      <div class="notice-top">
        <span class="notice-ic <?= e($it['severity']) ?>"><?= FidaNotice::icon($it['icon'], 18) ?></span>
        <div class="notice-title">
          <b><?= e($it['title']) ?><?php if (!$it['read']): ?><span class="dot" title="خوانده‌نشده"></span><?php endif; ?></b>
          <span class="notice-when"><?= e($sevLabel[$it['severity']] ?? '') ?> · <?= e($it['when']) ?></span>
        </div>
      </div>

      <div class="notice-desc"><?= e($it['desc']) ?></div>

      <div class="notice-actions">
        <a class="btn sm" href="<?= e($it['url']) ?>">مشاهده</a>
        <form method="post" action="<?= url('fida/notifications/read') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="key" value="<?= e($it['key']) ?>">
          <input type="hidden" name="mode" value="<?= $it['read'] ? 'unread' : 'read' ?>">
          <button class="btn sm btn-g" type="submit"><?= $it['read'] ? 'خوانده‌نشده' : 'خواندم' ?></button>
        </form>
        <form method="post" action="<?= url('fida/notifications/dismiss') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="key" value="<?= e($it['key']) ?>">
          <button class="btn sm btn-danger" type="submit" title="حذف این اعلان">حذف</button>
        </form>
      </div>
    </div>
  <?php endforeach; ?>

  <?php if (!$items): ?>
    <div class="card center muted">
      <div style="font-size:34px;margin-bottom:8px">🔔</div>
      اعلان جدیدی نداری.<br>
      <small style="color:var(--grey-50)">چک‌ها و فاکتورهای اعتباری نزدیک سررسید، اینجا هشدار می‌گیرند.</small>
    </div>
  <?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
