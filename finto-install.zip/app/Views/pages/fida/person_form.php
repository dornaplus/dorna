<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0"><?= e($title) ?></h2>
  <form method="post" action="<?= url('fida/persons') ?>"><?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
    <div class="sect"><h3><span class="n">۱</span> مشخصات شخص</h3>
      <div class="field"><label>نام و نام خانوادگی / نام فروشگاه *</label><input class="inp" name="full_name" value="<?= e($row['full_name'] ?? '') ?>" required></div>
      <div class="grid2">
        <div class="field"><label>تلفن</label><input class="inp" name="phone" dir="ltr" value="<?= e($row['phone'] ?? '') ?>" placeholder="09121234567"></div>
        <div class="field"><label>شهر</label><input class="inp" name="city" value="<?= e($row['city'] ?? '') ?>"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>نوع</label><select class="inp" name="person_type">
          <?php foreach (['customer'=>'مشتری','supplier'=>'تأمین‌کننده','partner'=>'همکار'] as $k=>$v): ?><option value="<?= $k ?>" <?= ($row['person_type']??'customer')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>حقیقی/حقوقی</label><select class="inp" name="person_kind">
          <?php foreach (['individual'=>'حقیقی','company'=>'حقوقی'] as $k=>$v): ?><option value="<?= $k ?>" <?= ($row['person_kind']??'individual')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="field"><label>آدرس</label><input class="inp" name="address" value="<?= e($row['address'] ?? '') ?>"></div>
      <div class="grid2">
        <div class="field"><label>سمت/عنوان</label><input class="inp" name="role" value="<?= e($row['role'] ?? '') ?>"></div>
        <div class="field"><label>تاریخ عضویت</label><input class="inp jalali" name="registered_at" value="<?= e(fa_digits((string)($row['registered_jalali'] ?? jdate(today())))) ?>"></div>
      </div>
      <div class="field"><label>وضعیت</label><select class="inp" name="status">
        <?php foreach (['active'=>'فعال','inactive'=>'غیرفعال'] as $k=>$v): ?><option value="<?= $k ?>" <?= ($row['status']??'active')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="btns"><button class="btn btn-p" type="submit">ذخیره</button><button class="btn btn-g" type="button" onclick="location.href='<?= url('fida/persons') ?>'">انصراف</button></div>
  </form>
</section>
<?= view('partials/fida_foot') ?>
