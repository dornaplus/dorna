<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <div class="card">
    <div class="hello">
      <div class="av"><?= e(mb_substr((string)$person['full_name'], 0, 1)) ?></div>
      <div><b><?= e($person['full_name']) ?></b><small><?= $person['person_kind'] === 'company' ? 'حقوقی' : 'حقیقی' ?><?= $person['phone'] ? ' · ' . e($person['phone']) : '' ?><?= $person['city'] ? ' · ' . e($person['city']) : '' ?></small></div>
      <div class="grow" style="flex:1"></div>
      <button class="btn sm" type="button" onclick="location.href='<?= url('fida/persons/'.(int)$person['id'].'/edit') ?>'">ویرایش</button>
    </div>
    <div class="stats">
      <div class="stat"><div class="k">تعداد اسناد</div><div class="v"><?= num($sum['doc_count'] ?? count($inv)) ?></div></div>
      <div class="stat g"><div class="k">جمع خرید</div><div class="v"><?= num($sum['total_amount'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat r"><div class="k">مانده اعتباری</div><div class="v"><?= num($sum['credit_balance'] ?? 0) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat"><div class="k">پرداخت‌ها</div><div class="v"><?= num(count($pays)) ?> <small>فقره</small></div></div>
    </div>
  </div>
  <h2 class="sec">فاکتورها</h2>
  <?php foreach ($inv as $r): ?><div class="row" onclick="location.href='<?= url('fida/invoices/'.(int)$r['id']) ?>'">
    <div class="thumb t-sell">🧾</div><div class="m"><b dir="ltr"><?= e(fa_digits((string)$r['invoice_code'])) ?></b><small dir="ltr"><?= e(fa_digits($r['invoice_jalali'])) ?></small></div>
    <div class="amt"><?= num($r['balance_amount']) ?><small>مانده</small></div></div><?php endforeach; ?>
  <?php if (!$inv): ?><div class="card center muted">سندی ثبت نشده.</div><?php endif; ?>
  <h2 class="sec">پرداخت‌ها</h2>
  <?php foreach ($pays as $p): ?><div class="row"><div class="thumb t-pre">💳</div>
    <div class="m"><b dir="ltr"><?= e(fa_digits((string)($p['invoice_code'] ?? '—'))) ?></b><small dir="ltr"><?= e(fa_digits($p['paid_jalali'])) ?></small></div>
    <div class="amt"><?= num($p['amount']) ?><small><?= Fida::unit() ?></small></div></div><?php endforeach; ?>
  <?php if (!$pays): ?><div class="card center muted">پرداختی ثبت نشده.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
