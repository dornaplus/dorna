<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">اشخاص <span class="m" style="color:var(--grey-50)"><?= num(count($rows)) ?> نفر</span></h2>
  <div class="quicks" style="margin-bottom:10px">
    <div class="qk" onclick="location.href='<?= url('fida/persons/create') ?>'"><div class="i">＋</div><span>شخص جدید</span></div>
    <div class="qk" onclick="location.href='<?= url('fida/invoices/create?type=sale') ?>'"><div class="i">🧾</div><span>فاکتور جدید</span></div>
  </div>
  <?php foreach ($rows as $r): ?>
    <div class="row" onclick="location.href='<?= url('fida/persons/'.(int)$r['id']) ?>'">
      <div class="av"><?= e(mb_substr(trim((string)$r['full_name']) ?: 'ش', 0, 1)) ?></div>
      <div class="m"><b><?= e($r['full_name']) ?></b>
        <small><?= $r['person_kind'] === 'company' ? 'حقوقی' : 'حقیقی' ?><?= $r['city'] ? ' · ' . e($r['city']) : '' ?> · <?= num($r['doc_count']) ?> سند</small>
        <span class="chip <?= (float)$r['credit_balance'] > 0 ? 'c-credit' : 'c-done' ?>">مانده <?= num($r['credit_balance']) ?></span></div>
      <div class="amt"><?= num($r['total_amount']) ?><small><?= Fida::unit() ?></small></div>
    </div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="card center muted">شخصی ثبت نشده است.</div><?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
