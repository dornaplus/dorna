<?= view('partials/fida_head', ['title' => $title]) ?>
<?php $sumDaily = 0; foreach ($daily as $d) $sumDaily += (float)$d['realized_amount'];
      $sumItems = 0; foreach ($topItems as $t) $sumItems += (float)$t['total_amount']; ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">گزارش‌ها</h2>
  <div class="card">
    <div class="stats">
      <div class="stat g"><div class="k">فروش ۳۰ روز</div><div class="v"><?= num($sumDaily) ?> <small><?= Fida::unit() ?></small></div></div>
      <div class="stat"><div class="k">اقلام پرفروش</div><div class="v"><?= num(count($topItems)) ?> <small>قلم</small></div></div>
      <div class="stat"><div class="k">برترین مشتریان</div><div class="v"><?= num(count($topPersons)) ?> <small>نفر</small></div></div>
      <div class="stat r"><div class="k">فروش اقلام</div><div class="v"><?= num($sumItems) ?> <small><?= Fida::unit() ?></small></div></div>
    </div>
  </div>

  <h2 class="sec">فروش روزانه</h2>
  <?php foreach ($daily as $d): ?>
    <div class="row"><div class="thumb t-sell">📅</div>
      <div class="m"><b><?= e(fa_digits($d['invoice_jalali'])) ?></b><small><?= num($d['doc_count']) ?> فاکتور</small></div>
      <div class="amt"><?= num($d['realized_amount']) ?><small><?= Fida::unit() ?></small></div></div>
  <?php endforeach; ?>
  <?php if (!$daily): ?><div class="card center muted">داده‌ای نیست.</div><?php endif; ?>

  <h2 class="sec">پرفروش‌ترین کالاها</h2>
  <?php foreach ($topItems as $t): ?>
    <div class="row"><div class="thumb t-buy">📦</div>
      <div class="m"><b><?= e($t['item_title']) ?></b><small>مقدار <?= num($t['total_qty']) ?> · <?= num($t['invoice_count']) ?> فاکتور</small></div>
      <div class="amt"><?= num($t['total_amount']) ?><small><?= Fida::unit() ?></small></div></div>
  <?php endforeach; ?>

  <h2 class="sec">برترین مشتریان</h2>
  <?php foreach ($topPersons as $p): ?>
    <div class="row"><div class="av"><?= e(mb_substr((string)$p['full_name'], 0, 1)) ?></div>
      <div class="m"><b><?= e($p['full_name']) ?></b><small><?= num($p['doc_count']) ?> سند</small></div>
      <div class="amt"><?= num($p['total_amount']) ?><small><?= Fida::unit() ?></small></div></div>
  <?php endforeach; ?>

  <?php if ($pay): ?>
  <h2 class="sec">تفکیک روش پرداخت</h2>
  <?php foreach ($pay as $p): ?>
    <div class="row"><div class="thumb t-pre">💳</div>
      <div class="m"><b><?= e($p['bucket']) ?></b><small><?= num($p['doc_count']) ?> سند</small></div>
      <div class="amt"><?= num($p['percent'], 1) ?>٪<small><?= num($p['amount']) ?> <?= Fida::unit() ?></small></div></div>
  <?php endforeach; ?>
  <?php endif; ?>
</section>
<?= view('partials/fida_foot') ?>
