<?= view('partials/fida_head', ['title' => $title]) ?>
<?php
$imgUrl = static fn($k) => Fida::imageUrl($s[$k] ?? null);
$logo = $imgUrl('logo_path'); $stamp = $imgUrl('stamp_path'); $sign = $imgUrl('signature_path');
?>
<form method="post" action="<?= url('fida/settings') ?>" enctype="multipart/form-data">
<?= csrf_field() ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">تنظیمات</h2>

  <div class="setcard">
    <h3>🏪 فروشگاه من</h3>
    <div class="grid2">
      <div class="upl-box">
        <div class="upl-prev" id="prevLogo"><?php if ($logo): ?><img src="<?= e($logo) ?>" alt="لوگو"><?php else: ?><span class="upl-ph">📷</span><?php endif; ?></div>
        <div class="upl-actions">
          <label class="btn sm" style="cursor:pointer"><?= $logo ? 'تغییر لوگو' : 'انتخاب لوگو' ?>
            <input type="file" name="logo_file" accept="image/png,image/jpeg,image/webp,image/gif" hidden onchange="fidaPrev(this,'prevLogo')"></label>
          <?php if ($logo): ?><button class="btn sm btn-danger" type="submit" name="delete_logo" value="1" onclick="return confirm('لوگو حذف شود؟')">حذف</button><?php endif; ?>
        </div>
        <small class="upl-hint">JPG / PNG / WEBP — حداکثر ۳ مگابایت</small>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px">
        <div class="field" style="margin:0"><label>عنوان سربرگ</label><input class="inp" name="header_title" value="<?= e($s['header_title'] ?? '') ?>"></div>
        <div class="field" style="margin:0"><label>توضیح کوتاه / آدرس</label><input class="inp" name="header_description" value="<?= e($s['header_description'] ?? '') ?>"></div>
      </div>
    </div>
    <div class="field" style="margin-top:8px"><label>نام فروشگاه</label><input class="inp" name="shop_name" value="<?= e($s['shop_name'] ?? '') ?>"></div>
    <div class="grid2">
      <div class="field"><label>نام مدیر</label><input class="inp" name="owner_name" value="<?= e($s['owner_name'] ?? '') ?>"></div>
      <div class="field"><label>تلفن</label><input class="inp" name="shop_phone" dir="ltr" value="<?= e($s['shop_phone'] ?? '') ?>"></div>
    </div>
    <div class="field"><label>نشانی فروشگاه</label><input class="inp" name="shop_address" value="<?= e($s['shop_address'] ?? '') ?>" placeholder="مثال: تهران، خیابان …"><small class="upl-hint">در سربرگ چاپ و PDF زیر نام فروشگاه چاپ می‌شود.</small></div>
    <div class="setrow" style="margin-top:6px">
      <span>رنگ سازمانی<small>در چاپ و خروجی PDF فاکتور استفاده می‌شود</small></span>
      <span class="swatches">
        <?php $accNames = ['purple' => 'بنفش', 'blue' => 'آبی', 'green' => 'سبز', 'red' => 'قرمز'];
        foreach (Fida::ACCENTS as $k => $pal): ?>
          <button type="button" data-k="<?= $k ?>" title="<?= e($accNames[$k] ?? $k) ?>" aria-label="<?= e($accNames[$k] ?? $k) ?>"
            class="<?= ($s['accent_color'] ?? 'purple') === $k ? 'on' : '' ?>" style="background:<?= $pal[0] ?>"></button>
        <?php endforeach; ?>
      </span>
    </div>
    <input type="hidden" name="accent_color" id="accent" value="<?= e($s['accent_color'] ?? 'purple') ?>">

    <div class="print-preview" id="accPreview">
      <div class="pp-head">
        <b><?= e($s['shop_name'] ?? 'فروشگاه من') ?></b>
        <span>فاکتور فروش · INV-1405-0001</span>
      </div>
      <table class="pp-tbl">
        <thead><tr><th>#</th><th>کالا / خدمت</th><th>مقدار</th><th>جمع</th></tr></thead>
        <tbody><tr><td>۱</td><td>نمونهٔ کالا</td><td>۲</td><td>۱٬۰۰۰٬۰۰۰</td></tr></tbody>
        <tfoot><tr class="pp-total"><th colspan="3">مبلغ قابل پرداخت</th><th>۱٬۰۰۰٬۰۰۰</th></tr></tfoot>
      </table>
      <div class="pp-cap">پیش‌نمایش چاپ و PDF — با تغییر رنگ، همین‌جا به‌روز می‌شود</div>
    </div>
  </div>

  <div class="setcard">
    <h3>✍️ مهر و امضا (برای چاپ و PDF)</h3>
    <div class="grid2">
      <div class="upl-box">
        <div class="upl-prev" id="prevStamp"><?php if ($stamp): ?><img src="<?= e($stamp) ?>" alt="مهر"><?php else: ?><span class="upl-ph">🔖</span><?php endif; ?></div>
        <div class="upl-actions">
          <label class="btn sm" style="cursor:pointer"><?= $stamp ? 'تغییر مهر' : 'انتخاب تصویر مهر' ?>
            <input type="file" name="stamp_file" accept="image/png,image/jpeg,image/webp,image/gif" hidden onchange="fidaPrev(this,'prevStamp')"></label>
          <?php if ($stamp): ?><button class="btn sm btn-danger" type="submit" name="delete_stamp" value="1" onclick="return confirm('تصویر مهر حذف شود؟')">حذف</button><?php endif; ?>
        </div>
        <small class="upl-hint">زیر کادر «مهر و امضای فروشنده» چاپ می‌شود</small>
      </div>
      <div class="upl-box">
        <div class="upl-prev" id="prevSign"><?php if ($sign): ?><img src="<?= e($sign) ?>" alt="امضا"><?php else: ?><span class="upl-ph">🖋</span><?php endif; ?></div>
        <div class="upl-actions">
          <label class="btn sm" style="cursor:pointer"><?= $sign ? 'تغییر امضا' : 'انتخاب تصویر امضا' ?>
            <input type="file" name="signature_file" accept="image/png,image/jpeg,image/webp,image/gif" hidden onchange="fidaPrev(this,'prevSign')"></label>
          <?php if ($sign): ?><button class="btn sm btn-danger" type="submit" name="delete_signature" value="1" onclick="return confirm('تصویر امضا حذف شود؟')">حذف</button><?php endif; ?>
        </div>
        <small class="upl-hint">کنار مهر، در کادر فروشنده چاپ می‌شود</small>
      </div>
    </div>
    <div class="help" style="margin-top:8px">اگر تصویری بارگذاری نشود، جای مهر و امضا در چاپ و PDF <b>خالی</b> می‌ماند.</div>
  </div>

  <div class="setcard">
    <h3>🧮 نمایش فاکتور</h3>
    <?php foreach (['show_ship' => ['هزینه ارسال', 'نمایش ردیف هزینه ارسال'], 'show_discount' => ['تخفیف', 'نمایش ردیف تخفیف'], 'show_advance' => ['بیعانه', 'نمایش مبلغ بیعانه دریافتی'], 'show_previous_debt' => ['بدهی قبلی', 'نمایش بدهی قبلی شخص'], 'show_types' => ['نوع فاکتور و پرداخت', 'نمایش پیش‌فاکتور/فروش/خرید'], 'show_tax' => ['مالیات', 'نمایش ردیف مالیات در فاکتور']] as $k => $lbl): ?>
      <div class="setrow"><span><?= $lbl[0] ?><small><?= $lbl[1] ?></small></span>
        <span class="sw"><input type="checkbox" name="<?= $k ?>" value="1" <?= !empty($s[$k]) ? 'checked' : '' ?>><i></i></span></div>
    <?php endforeach; ?>
    <div class="setrow"><span>اطلاعات حساب بانکی<small>نمایش شماره کارت/شبا در چاپ و PDF فاکتور</small></span>
      <span class="sw"><input type="checkbox" name="show_bank_info" value="1" <?= !empty($s['show_bank_info']) ? 'checked' : '' ?>><i></i></span></div>
    <div class="setrow"><span>واحد پول</span>
      <select class="inp" name="currency" style="max-width:150px">
        <?php foreach (['toman' => 'تومان', 'rial' => 'ریال'] as $k => $v): ?><option value="<?= $k ?>" <?= ($s['currency'] ?? 'toman') === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
      </select></div>
    <div class="setrow"><span>درصد مالیات پیش‌فرض</span>
      <input class="inp" name="tax_percent" value="<?= (float)($s['tax_percent'] ?? 9) ?>" style="max-width:110px" inputmode="decimal"></div>
    <div class="setrow"><span>حالت تخفیف</span>
      <select class="inp" name="discount_mode" style="max-width:150px">
        <?php foreach (['percent' => 'درصدی', 'amount' => 'مبلغی'] as $k => $v): ?><option value="<?= $k ?>" <?= ($s['discount_mode'] ?? 'percent') === $k ? 'selected' : '' ?>><?= $v ?></option><?php endforeach; ?>
      </select></div>
  </div>

  <button class="btn btn-p" style="width:100%" type="submit">ذخیره تنظیمات</button>
</section>
</form>

<section class="panel on">
  <h2 class="sec">حساب‌های بانکی (برای چاپ و PDF)</h2>
  <div class="setcard">
    <h3>🏦 حساب‌های من</h3>
    <div class="help">می‌توانید چند حساب اضافه کنید؛ حسابی که «پیش‌فرض» است در چاپ و PDF فاکتور نمایش داده می‌شود.</div>

    <?php if (empty($banks)): ?>
      <div class="help" style="margin-top:10px">هنوز حسابی ثبت نشده است. از فرم زیر حساب خود را اضافه کنید (شماره کارت و شبا اختیاری‌اند).</div>
    <?php else: ?>
      <div class="bank-list">
        <?php foreach ($banks as $b): $isDef = (int)$b['id'] === $defaultBankId; ?>
          <div class="bank-item<?= $isDef ? ' on' : '' ?>">
            <div class="bi-head">
              <b><?= e($b['bank_name']) ?></b>
              <?php if ($isDef): ?><span class="badge def">پیش‌فرض ✓</span><?php endif; ?>
            </div>
            <div class="bi-rows">
              <span>صاحب حساب: <b><?= e($b['account_holder']) ?></b></span>
              <?php if (!empty($b['card_no'])): ?><span>شماره کارت: <b dir="ltr"><?= e(Fida::groupDigits($b['card_no'])) ?></b></span><?php endif; ?>
              <?php if (!empty($b['iban'])): ?><span>شبا: <b dir="ltr"><?= e((string)$b['iban']) ?></b></span><?php endif; ?>
              <?php if (!empty($b['account_no'])): ?><span>شماره حساب: <b dir="ltr"><?= e((string)$b['account_no']) ?></b></span><?php endif; ?>
            </div>
            <div class="bi-actions">
              <?php if (!$isDef): ?>
                <form method="post" action="<?= url('fida/bank-accounts/'.(int)$b['id'].'/default') ?>" style="display:inline">
                  <?= csrf_field() ?><button class="btn sm btn-p" type="submit">انتخاب به‌عنوان پیش‌فرض</button>
                </form>
              <?php else: ?>
                <span class="chip">نمایش در چاپ و PDF</span>
              <?php endif; ?>
              <form method="post" action="<?= url('fida/bank-accounts/'.(int)$b['id'].'/delete') ?>" style="display:inline"
                    onsubmit="return confirm('این حساب بانکی حذف شود؟')">
                <?= csrf_field() ?><button class="btn sm btn-danger" type="submit">حذف</button>
              </form>
            </div>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form method="post" action="<?= url('fida/bank-accounts') ?>" class="bank-add">
      <?= csrf_field() ?>
      <div class="grid2">
        <div class="field"><label>نام بانک <span class="req">*</span></label><input class="inp" name="bank_name" placeholder="مثال: بانک ملت"></div>
        <div class="field"><label>نام صاحب حساب <span class="req">*</span></label><input class="inp" name="account_holder" placeholder="مثال: علی محمدی"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>شماره کارت</label><input class="inp" name="card_no" dir="ltr" inputmode="numeric" placeholder="6037 9977 1234 5678"></div>
        <div class="field"><label>شماره شبا (بدون IR)</label><input class="inp" name="iban" dir="ltr" placeholder="IR... یا فقط رقم‌ها"></div>
      </div>
      <div class="grid2">
        <div class="field"><label>شماره حساب</label><input class="inp" name="account_no" dir="ltr" inputmode="numeric"></div>
        <div class="field"><label>ترتیب نمایش</label><input class="inp" name="sort_order" inputmode="numeric" value="0"></div>
      </div>
      <button class="btn btn-p" type="submit">➕ افزودن حساب بانکی</button>
    </form>
  </div>
</section>

<section class="panel on">
  <h2 class="sec">پشتیبان‌گیری و بازیابی</h2>
  <div class="card">
    <div class="row" onclick="location.href='<?= url('fida/backups') ?>'" style="margin-top:0">
      <div class="thumb" style="background:var(--purple-soft)">🗄️</div>
      <div class="m"><b>پشتیبان‌گیری و بازیابی داده‌ها</b>
        <small>یک نسخهٔ کامل از اشخاص، کالاها، فاکتورها، چک‌ها، قالب‌ها و تنظیمات پروفایل خودتان (JSON + CSV)</small></div>
      <span class="chip">ورود</span>
    </div>
    <div class="row" data-pwa-install hidden onclick="pwaInstall()">
      <div class="thumb" style="background:var(--purple-soft)">📲</div>
      <div class="m"><b>نصب اپ روی گوشی</b>
        <small>فیدا را مثل یک اپ واقعی روی صفحهٔ اصلی نصب کنید؛ بدون نوار مرورگر و با دسترسی یک‌لمسی</small></div>
      <span class="chip">نصب</span>
    </div>
  </div>
</section>

<script>window.FIDA_ACCENTS = <?= json_encode(Fida::ACCENTS, JSON_UNESCAPED_UNICODE) ?>;</script>
<script>
function fidaPrev(input, boxId) {
  var box = document.getElementById(boxId);
  if (!box || !input.files || !input.files[0]) return;
  var url = URL.createObjectURL(input.files[0]);
  box.innerHTML = '<img src="' + url + '" alt="">';
}
(function () {
  var A = window.FIDA_ACCENTS || {}, hidden = document.getElementById('accent'), pv = document.getElementById('accPreview');
  function apply(k) {
    var p = A[k] || A.purple; if (!p) return;
    if (hidden) hidden.value = k;
    document.querySelectorAll('.swatches button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-k') === k); });
    if (pv) {
      pv.style.setProperty('--acc', p[0]);
      pv.style.setProperty('--acc-soft', p[1]);
      pv.style.setProperty('--acc-ink', p[2]);
      pv.style.setProperty('--acc-line', p[3]);
    }
  }
  document.querySelectorAll('.swatches button').forEach(function (b) {
    b.addEventListener('click', function () { apply(b.getAttribute('data-k')); });
  });
  apply((hidden && hidden.value) || 'purple');
})();
</script>
<?= view('partials/fida_foot') ?>
