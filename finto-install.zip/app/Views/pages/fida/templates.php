<?= view('partials/fida_head', ['title' => $title]) ?>
<section class="panel on">
  <h2 class="sec" style="margin-top:0">قالب‌های فاکتور</h2>
  <?php foreach ($rows as $r): ?>
    <div class="row"><div class="thumb t-pre">📝</div>
      <div class="m"><b><?= e($r['name']) ?></b><small><?= e($r['description'] ?? '—') ?> · <?= num($r['items_count']) ?> قلم</small></div></div>
  <?php endforeach; ?>
  <?php if (!$rows): ?><div class="card center muted">قالبی ثبت نشده است.</div><?php endif; ?>

  <div class="setcard">
    <h3>➕ قالب جدید</h3>
    <form method="post" action="<?= url('fida/templates') ?>"><?= csrf_field() ?>
      <div class="grid2">
        <div class="field"><label>نام قالب *</label><input class="inp" name="name" required></div>
        <div class="field"><label>توضیح</label><input class="inp" name="description"></div>
      </div>
      <?php $it = Database::all('SELECT id,title,unit_price FROM fida_items WHERE is_active=1 ORDER BY title LIMIT 200'); ?>
      <?php for ($i = 0; $i < 3; $i++): ?>
        <div class="grid2" style="margin-top:6px">
          <select name="t_item_id[]" class="inp"><option value="">— انتخاب کالا —</option>
            <?php foreach ($it as $x): ?><option value="<?= (int)$x['id'] ?>"><?= e($x['title']) ?></option><?php endforeach; ?></select>
          <input class="inp" name="t_quantity[]" value="1" placeholder="مقدار">
        </div>
        <input type="hidden" name="t_unit_price[]" value="0">
      <?php endfor; ?>
      <button class="btn btn-p" style="width:100%;margin-top:10px" type="submit">ثبت قالب</button>
    </form>
  </div>
</section>
<?= view('partials/fida_foot') ?>
