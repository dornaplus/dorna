<?php
$digits = 6;
$masked = $mobile ? substr($mobile, 0, 4) . ' *** ' . substr($mobile, -4) : '';
$faDigits = function (string $s): string {
    return strtr($s, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']);
};
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>کد تایید | اپ فاکتورزنی فیدا</title>
<meta name="theme-color" content="#6D28D9">
<link rel="manifest" href="<?= url('manifest-fida.webmanifest') ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= asset('pwa/fida-32.png') ?>">
<link rel="icon" href="<?= asset('pwa/favicon.ico') ?>" sizes="any">
<link rel="apple-touch-icon" href="<?= asset('pwa/fida-180.png') ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="فیدا">
<link rel="stylesheet" href="<?= asset('fida-auth.css') ?>?v=1">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>

<div class="footer-glow" aria-hidden="true"></div>

<main class="page">
  <div class="brand-mark">
    <span class="owl"><img src="<?= asset('fida-owl.png') ?>" alt="فیدا"></span>
    <span>فیدا<small>اپ فاکتورزنی</small></span>
  </div>

  <div class="check" aria-hidden="true">
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8.5 8.5 0 0 1-8.5 8.5c-1.5 0-2.9-.4-4.1-1L3 21l1.6-4.7A8.5 8.5 0 1 1 21 12Z"/><path d="M8.5 11h.01"/><path d="M12 11h.01"/><path d="M15.5 11h.01"/></svg>
  </div>

  <div class="head">
    <h1>کد تایید رو وارد کن</h1>
    <p class="sub">کد <?= $faDigits((string)$digits) ?> رقمی به شماره‌ی زیر پیامک شد.</p>
    <div class="phone-display">
      <span class="num" dir="ltr"><?= e($faDigits($masked)) ?></span>
      <a href="<?= url('fida/login?mode=' . ($purpose === 'register' ? 'register' : 'login')) ?>">ویرایش شماره</a>
    </div>
  </div>

  <?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <?php if (!empty($info)): ?><div class="alert info"><?= e($info) ?></div><?php endif; ?>
  <?php if (!empty($testCode)): ?>
    <div class="testcode">
      کد تست: <b dir="ltr"><?= e($testCode) ?></b>
      <button type="button" id="fillTest" data-code="<?= e($testCode) ?>">درج خودکار</button>
    </div>
  <?php endif; ?>

  <form class="form otp-form" method="post" action="<?= url('fida/verify') ?>" id="otpForm">
    <?= csrf_field() ?>
    <div class="otp">
      <?php for ($i = 0; $i < $digits; $i++): ?>
        <input type="tel" inputmode="numeric" maxlength="1" pattern="[0-9]" required
               aria-label="رقم <?= $faDigits((string)($i + 1)) ?>" <?= $i === 0 ? 'autofocus' : '' ?>>
      <?php endfor; ?>
    </div>
    <input type="hidden" name="code" id="otpCode">
    <button type="submit" class="btn">تایید و ورود</button>
  </form>

  <div class="resend">کدی دریافت نکردی؟
    <form method="post" action="<?= url('fida/verify/resend') ?>" style="display:inline">
      <?= csrf_field() ?>
      <button type="submit" class="linklike">ارسال مجدد کد</button>
    </form>
  </div>
  <a class="back-home" href="<?= url('fida/login') ?>">بازگشت به صفحهٔ ورود</a>
</main>

<script>
(function () {
  var boxes = Array.prototype.slice.call(document.querySelectorAll('.otp input'));
  var hidden = document.getElementById('otpCode');
  var form = document.getElementById('otpForm');
  function fa2en(s) {
    return String(s == null ? '' : s)
      .replace(/[۰-۹]/g, function (c) { return String(c.charCodeAt(0) - 1776); })
      .replace(/[٠-٩]/g, function (c) { return String(c.charCodeAt(0) - 1632); });
  }
  function sync() { hidden.value = boxes.map(function (b) { return b.value || ''; }).join(''); }
  boxes.forEach(function (b, i) {
    b.addEventListener('input', function () {
      b.value = fa2en(b.value).replace(/\D/g, '').slice(0, 1);
      b.classList.toggle('filled', b.value !== '');
      if (b.value && i < boxes.length - 1) boxes[i + 1].focus();
      sync();
      if (boxes.every(function (x) { return x.value; })) form.submit();
    });
    b.addEventListener('keydown', function (e) {
      if (e.key === 'Backspace' && b.value === '' && i > 0) {
        boxes[i - 1].focus(); boxes[i - 1].value = ''; boxes[i - 1].classList.remove('filled'); sync();
      }
      if (e.key === 'ArrowLeft' && i < boxes.length - 1) { boxes[i + 1].focus(); e.preventDefault(); }
      if (e.key === 'ArrowRight' && i > 0) { boxes[i - 1].focus(); e.preventDefault(); }
    });
    b.addEventListener('paste', function (e) {
      e.preventDefault();
      var d = (e.clipboardData.getData('text').match(/\d/g) || []).slice(0, boxes.length);
      boxes.forEach(function (x) { x.value = ''; x.classList.remove('filled'); });
      d.forEach(function (x, j) { boxes[j].value = x; boxes[j].classList.add('filled'); });
      boxes[Math.min(d.length, boxes.length - 1)].focus();
      sync();
      if (d.length === boxes.length) form.submit();
    });
  });
  var fillBtn = document.getElementById('fillTest');
  if (fillBtn) fillBtn.addEventListener('click', function () {
    var d = (fillBtn.getAttribute('data-code') || '').split('');
    boxes.forEach(function (x, j) { x.value = d[j] || ''; x.classList.toggle('filled', !!x.value); });
    sync();
    form.submit();
  });
  form.addEventListener('submit', sync);
})();
</script>
<script>window.PWA_APP = 'fida'; window.PWA_FAB = false; window.PWA_BTN = false;</script>
<script src="<?= asset('pwa.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../../public/assets/pwa.js') ?: 1 ?>"></script>

</body>
</html>
