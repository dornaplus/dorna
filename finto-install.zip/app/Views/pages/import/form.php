<?= view('partials/head', ['title' => $title]) ?>
<div class="tabs" data-tabs="#imp-scope" style="margin-bottom:12px">
  <a class="on" data-tab="#tab-import">بارگذاری فایل</a>
  <a data-tab="#tab-jobs">کارهای انجام‌شده</a>
</div>
<div id="imp-scope">
  <div class="card" data-tab="#tab-import" id="tab-import">
    <div class="card-head"><h3>به‌روزرسانی اطلاعات از فایل CSV</h3>
      <div class="grow"></div>
      <a class="btn ghost sm" target="_blank" rel="noopener" href="<?= url('app/import-jobs/template?entity='.$entity) ?>">دانلود قالب CSV</a></div>
    <form method="post" action="<?= url('app/import-jobs') ?>" enctype="multipart/form-data">
      <?= csrf_field() ?>
      <div class="form-grid">
        <div class="field"><label>نوع داده</label>
          <select class="inp" name="entity_type">
            <?php foreach ($entities as $k => $d): ?>
              <option value="<?= e($k) ?>" <?= $k === $entity ? 'selected' : '' ?>><?= e($d['title']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="hint">ستون‌های مجاز: <?= e(implode(' · ', $entities[$entity]['columns'])) ?></div></div>
        <div class="field"><label>روش ثبت</label>
          <select class="inp" name="mode">
            <option value="upsert">ثبت جدید + ویرایش موجود (پیشنهادی)</option>
            <option value="insert">فقط رکوردهای جدید</option>
            <option value="update">فقط ویرایش رکوردهای موجود</option>
          </select>
          <div class="hint">تطبیق رکوردها بر اساس ستون «کد» انجام می‌شود.</div></div>
        <div class="field"><label>فایل CSV</label>
          <input class="inp" type="file" name="file" accept=".csv,text/csv" required>
          <div class="hint">کدگذاری UTF-8؛ جداکنندهٔ , یا ; پشتیبانی می‌شود.</div></div>
        <div class="field"><label>حالت</label>
          <label class="checkbox"><input type="checkbox" name="dry_run" value="1"><span class="small">فقط پیش‌بررسی (هیچ چیزی ثبت نشود)</span></label></div>
      </div>
      <div class="alert info">پیش از بارگذاری، با «دانلود قالب CSV» ستون‌های درست را بگیرید. ردیف‌های دارای خطا نادیده گرفته و در گزارش نشان داده می‌شوند.</div>
      <div class="form-actions"><button class="btn success">شروع به‌روزرسانی</button>
        <a class="btn gray" href="<?= url('app/settings/business') ?>">انصراف</a></div>
    </form>
  </div>

  <div class="card" data-tab="#tab-jobs" id="tab-jobs" style="display:none">
    <div class="card-head"><h3>کارهای به‌روزرسانی</h3><span class="pill"><?= num(count($jobs)) ?> مورد</span></div>
    <?php if (!$jobs): ?><div class="muted small">تا کنون بارگذاری‌ای انجام نشده است.</div>
    <?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:760px">
      <thead><tr><th>#</th><th>نوع داده</th><th>روش</th><th>کل ردیف</th><th>موفق</th><th>خطا</th><th>وضعیت</th><th>زمان</th><th></th></tr></thead>
      <tbody><?php foreach ($jobs as $j): ?>
        <tr><td><?= num($j['id']) ?></td>
          <td><?= e($entities[$j['entity_type']]['title'] ?? $j['entity_type']) ?></td>
          <td><?= e(['insert' => 'جدید', 'update' => 'ویرایش', 'upsert' => 'جدید+ویرایش'][$j['mode']] ?? $j['mode']) ?></td>
          <td class="num"><?= num($j['total_rows']) ?></td>
          <td class="num"><?= num($j['success_rows']) ?></td>
          <td class="num"><?= num($j['error_rows']) ?></td>
          <td><span class="pill st-<?= $j['status'] === 'done' ? 'active' : ($j['status'] === 'failed' ? 'cancelled' : 'unpaid') ?>"><?= e(Meta::enumLabel($j['status'])) ?></span></td>
          <td class="muted small"><?= e(jdate($j['created_at'])) ?> <?= e(substr((string)$j['created_at'], 11, 5)) ?></td>
          <td class="acts"><a class="btn ghost sm" href="<?= url('app/import-jobs/'.$j['id'].'/result') ?>">گزارش</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/foot') ?>
