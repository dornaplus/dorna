<?php /** @var array $rep @var array $entities */ ?>
<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head"><h3>پیش‌بررسی به‌روزرسانی (بدون ثبت)</h3>
    <span class="pill"><?= e($entities[$rep['entity']]['title'] ?? $rep['entity']) ?></span>
    <div class="grow"></div>
    <a class="btn gray sm" href="<?= url('app/import-jobs/create') ?>">بازگشت</a></div>
  <div class="grid c4">
    <div class="stat"><span>کل ردیف‌ها</span><b><?= num($rep['total']) ?></b></div>
    <div class="stat"><span>قابل ثبت</span><b style="color:#059669"><?= num($rep['ok']) ?></b></div>
    <div class="stat"><span>از آن، ویرایش</span><b><?= num($rep['updated']) ?></b></div>
    <div class="stat"><span>خطا</span><b style="color:#E11D48"><?= num($rep['failed']) ?></b></div>
  </div>
  <div class="alert info">هیچ داده‌ای در دیتابیس ثبت نشد. برای ثبت واقعی، تیک «فقط پیش‌بررسی» را بردارید و دوباره بارگذاری کنید.</div>
</div>
<?php $errs = (array)($rep['errors'] ?? []); ?>
<?php if ($errs): ?>
<div class="card">
  <div class="card-head"><h3>خطاها</h3><span class="pill"><?= num(count($errs)) ?></span></div>
  <div class="table-wrap"><table class="tbl" style="min-width:720px">
    <thead><tr><th>خط فایل</th><th>پیام خطا</th><th>محتوای ردیف</th></tr></thead>
    <tbody><?php foreach ($errs as $er): ?>
      <tr><td class="num"><?= num((int)($er['line'] ?? 0)) ?></td>
        <td><?= e((string)($er['message'] ?? '')) ?></td>
        <td class="muted small" dir="ltr"><?= e(implode(' | ', array_map(fn($x) => (string)$x, (array)($er['row'] ?? [])))) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>
<?= view('partials/foot') ?>
