<?php /** @var array $job @var array|null $report @var array $entities */ ?>
<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head"><h3>گزارش به‌روزرسانی #<?= num($job['id']) ?></h3>
    <span class="pill st-<?= $job['status'] === 'done' ? 'active' : ($job['status'] === 'failed' ? 'cancelled' : 'unpaid') ?>"><?= e(Meta::enumLabel($job['status'])) ?></span>
    <div class="grow"></div>
    <a class="btn ghost sm" href="<?= url('app/import-jobs/create') ?>">بارگذاری جدید</a>
    <a class="btn gray sm" href="<?= url('app/import-jobs/create') ?>#tab-jobs">بازگشت</a></div>
  <div class="grid c4">
    <div class="stat"><span>نوع داده</span><b><?= e($entities[$job['entity_type']]['title'] ?? $job['entity_type']) ?></b></div>
    <div class="stat"><span>کل ردیف‌ها</span><b><?= num($job['total_rows']) ?></b></div>
    <div class="stat"><span>موفق</span><b style="color:#059669"><?= num($job['success_rows']) ?></b></div>
    <div class="stat"><span>خطا</span><b style="color:#E11D48"><?= num($job['error_rows']) ?></b></div>
  </div>
  <div class="print-meta" style="margin-top:10px">
    روش: <b><?= e(['insert' => 'فقط جدید', 'update' => 'فقط ویرایش', 'upsert' => 'جدید + ویرایش'][$job['mode']] ?? $job['mode']) ?></b>
    — شروع: <b><?= e(jdate($job['started_at'] ?? $job['created_at'])) ?></b>
    — پایان: <b><?= e($job['finished_at'] ? jdate($job['finished_at']) : '—') ?></b>
    <?php if (!empty($report['file'])): ?> — فایل: <b dir="ltr"><?= e((string)$report['file']) ?></b><?php endif; ?>
  </div>
</div>

<?php $errs = (array)($report['errors'] ?? []); ?>
<div class="card">
  <div class="card-head"><h3>ردیف‌های دارای خطا</h3><span class="pill"><?= num(count($errs)) ?></span></div>
  <?php if (!$errs): ?>
    <div class="alert success">همهٔ ردیف‌ها بدون خطا پردازش شدند. ✅</div>
  <?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:720px">
      <thead><tr><th>خط فایل</th><th>پیام خطا</th><th>محتوای ردیف</th></tr></thead>
      <tbody><?php foreach ($errs as $er): ?>
        <tr><td class="num"><?= num((int)($er['line'] ?? 0)) ?></td>
          <td><?= e((string)($er['message'] ?? '')) ?></td>
          <td class="muted small" dir="ltr"><?= e(implode(' | ', array_map(fn($x) => (string)$x, (array)($er['row'] ?? [])))) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
