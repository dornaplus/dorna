<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var string $kind @var array $row @var array $lines @var array $categories @var array $accounts @var array $persons
 *  @var array $cashAccounts @var array $taxes @var array $projects @var array $costCenters @var int $defaultAccount @var string $action */
$isExp = ($kind ?? 'expense') === 'expense';
$lines = $lines ?? []; $row = $row ?? [];
$accounts = $accounts ?? []; $categories = $categories ?? []; $persons = $persons ?? [];
$cashAccounts = $cashAccounts ?? []; $taxes = $taxes ?? []; $projects = $projects ?? []; $costCenters = $costCenters ?? [];
$catField = $isExp ? 'expense_category_id' : 'income_category_id';
$old = $_SESSION['_old'] ?? [];
?>
<?php if (!empty($old)): ?><div class="alert warn sm">مقادیر وارد‌شده از آخرین تلاش شما بازیابی شده است.</div><?php endif; ?>
<form method="post" action="<?= e($action) ?>" class="stack" data-incexp="1">
<?= csrf_field() ?>
<input type="hidden" name="doc_type" value="<?= $isExp ? 'expense' : 'income' ?>">
<div class="card">
    <div class="card-head">
        <h3><?= $isExp ? 'سند هزینه' : 'سند درآمد' ?> <?= $row ? '— ویرایش '.e(fa_digits((string)$row['doc_no'])) : '' ?></h3>
        <span class="pill <?= $isExp ? 'st-unpaid' : 'st-paid' ?>"><?= $isExp ? 'هزینه' : 'درآمد' ?></span>
    </div>
    <div class="card-body">
        <div class="grid c4">
            <label class="field"><span>تاریخ سند</span>
                <input type="text" name="doc_date" class="inp jalali" dir="ltr" required
                       value="<?= e(jdate($row['doc_date'] ?? ($old['doc_date'] ?? today()))) ?>" data-date="<?= e($row['doc_date'] ?? today()) ?>">
            </label>
            <label class="field"><span>عنوان سند <button type="button" class="btn soft sm" style="margin-inline-start:6px" data-ai-compose data-type="expense_desc" data-target="#incexp-title" data-context="<?= $isExp ? 'سند هزینه' : 'سند درآمد' ?>"><?= icon('spark', 14) ?> پیشنهاد با AI</button></span><input type="text" name="title" id="incexp-title" class="inp" required
                       value="<?= e($row['title'] ?? ($old['title'] ?? '')) ?>" placeholder="<?= $isExp ? 'مثال: اجاره دفتر مرکزی' : 'مثال: فروش ضایعات' ?>"></label>
            <label class="field"><span>دسته‌بندی</span>
                <select name="category_id" class="inp select-search">
                    <option value="">— انتخاب نشده —</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" data-account="<?= (int)$c['default_account_id'] ?>"
                            <?= (string)($row[$catField] ?? ($old['category_id'] ?? '')) === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>طرف حساب</span>
                <select name="person_id" class="inp select-search">
                    <option value="">— بدون طرف حساب —</option>
                    <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '')) ?: ($p['company_name'] ?? ''); ?>
                        <option value="<?= (int)$p['id'] ?>" <?= (string)($row['person_id'] ?? ($old['person_id'] ?? '')) === (string)$p['id'] ? 'selected' : '' ?>><?= e($nm) ?> — <?= e($p['code']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>حساب <?= $isExp ? 'هزینه' : 'درآمد' ?> (پیش‌فرض)</span>
                <select name="account_id" id="incexp-account" class="inp select-search">
                    <option value="">— از دسته‌بندی/نگاشت حساب‌ها —</option>
                    <?php foreach ($accounts as $a): ?>
                        <option value="<?= (int)$a['id'] ?>" <?= (string)($row['expense_account_id'] ?? $row['revenue_account_id'] ?? ($old['account_id'] ?? '')) === (string)$a['id'] ? 'selected' : '' ?>><?= e($a['code']) ?> — <?= e($a['title']) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="button" class="btn soft sm" style="margin-top:7px" data-ai-categorize data-kind="<?= $isExp ? 'expense' : 'income' ?>" data-select="#incexp-account" data-desc="#incexp-title"><?= icon('spark') ?> پیشنهاد حساب با هوش مصنوعی</button>
                <div class="help" data-ai-out></div>
            </label>
            <label class="field"><span>نحوه تسویه</span>
                <select name="cash_account_id" class="inp select-search">
                    <option value="">نقدی نشده (بستانکار / بدهکار می‌شود)</option>
                    <?php foreach ($cashAccounts as $c): ?>
                        <option value="<?= (int)$c['id'] ?>" <?= (string)($row['cash_account_id'] ?? ($old['cash_account_id'] ?? '')) === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?>
                            (<?= e(cashAccountKind($c['account_kind'])) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>پروژه</span>
                <select name="project_id" class="inp select-search">
                    <option value="">— بدون پروژه —</option>
                    <?php foreach ($projects as $pj): ?>
                        <option value="<?= (int)$pj['id'] ?>" <?= (string)($row['project_id'] ?? ($old['project_id'] ?? '')) === (string)$pj['id'] ? 'selected' : '' ?>><?= e($pj['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label class="field"><span>مرکز هزینه</span>
                <select name="cost_center_id" class="inp select-search">
                    <option value="">— بدون مرکز هزینه —</option>
                    <?php foreach ($costCenters as $cc): ?>
                        <option value="<?= (int)$cc['id'] ?>" <?= (string)($row['cost_center_id'] ?? ($old['cost_center_id'] ?? '')) === (string)$cc['id'] ? 'selected' : '' ?>><?= e($cc['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
        </div>
        <?php if ($isExp): ?>
        <label class="field"><span>قابل بازگشت (بازپرداخت‌شدنی)</span>
            <select name="refundable" class="inp" style="max-width:220px">
                <option value="no" <?= ($row['refundable'] ?? 'no') === 'no' ? 'selected' : '' ?>>خیر</option>
                <option value="yes" <?= ($row['refundable'] ?? '') === 'yes' ? 'selected' : '' ?>>بله</option>
            </select>
        </label>
        <?php else: ?>
            <input type="hidden" name="refundable" value="no">
        <?php endif; ?>
    </div>
</div>

<div class="card">
    <div class="card-head">
        <h3>ردیف‌های سند</h3>
        <button type="button" class="btn soft sm js-add-row">افزودن ردیف</button>
    </div>
    <div class="table-wrap">
        <table class="tbl" data-rows="il">
            <thead>
                <tr>
                    <th style="width:42px">#</th>
                    <th>شرح ردیف</th>
                    <th>حساب</th>
                    <th>مرکز هزینه</th>
                    <th>مالیات</th>
                    <th>مبلغ (<?= e(currency_title()) ?>)</th>
                    <th style="width:46px"></th>
                </tr>
            </thead>
            <tbody>
            <?php $i = 0; foreach ($lines as $l): ?>
                <tr>
                    <td class="num"><?= $i + 1 ?></td>
                    <td><input type="text" name="line_title[<?= $i ?>]" class="inp" value="<?= e($l['title']) ?>"></td>
                    <td>
                        <select name="line_account_id[<?= $i ?>]" class="inp select-search">
                            <option value="">— پیش‌فرض —</option>
                            <?php foreach ($accounts as $a): ?>
                                <option value="<?= (int)$a['id'] ?>" <?= (int)$l['account_id'] === (int)$a['id'] ? 'selected' : '' ?>><?= e($a['code']) ?> — <?= e($a['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_cost_center_id[<?= $i ?>]" class="inp">
                            <option value="">—</option>
                            <?php foreach ($costCenters as $cc): ?>
                                <option value="<?= (int)$cc['id'] ?>" <?= (int)($l['cost_center_id'] ?? 0) === (int)$cc['id'] ? 'selected' : '' ?>><?= e($cc['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_tax_id[<?= $i ?>]" class="inp">
                            <option value="">بدون مالیات</option>
                            <?php foreach ($taxes as $t): ?>
                                <option value="<?= (int)$t['id'] ?>" data-rate="<?= (float)$t['rate_percent'] ?>" <?= (int)($l['tax_id'] ?? 0) === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['title']) ?> (<?= e(num($t['rate_percent'], 0)) ?>٪)</option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                    <td><input type="text" name="line_amount[<?= $i ?>]" class="inp money sum_src" value="<?= e(number_format((float)$l['amount'])) ?>"></td>
                    <td><button type="button" class="btn icon gray js-del-row" title="حذف ردیف">✕</button></td>
                </tr>
            <?php $i++; endforeach; ?>
            <?php if (!$lines): ?>
                <tr>
                    <td class="num">1</td>
                    <td><input type="text" name="line_title[0]" class="inp" placeholder="شرح ردیف"></td>
                    <td>
                        <select name="line_account_id[0]" class="inp select-search"><option value="">— پیش‌فرض —</option>
                            <?php foreach ($accounts as $a): ?><option value="<?= (int)$a['id'] ?>"><?= e($a['code']) ?> — <?= e($a['title']) ?></option><?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_cost_center_id[0]" class="inp"><option value="">—</option>
                            <?php foreach ($costCenters as $cc): ?><option value="<?= (int)$cc['id'] ?>"><?= e($cc['name']) ?></option><?php endforeach; ?>
                        </select>
                    </td>
                    <td>
                        <select name="line_tax_id[0]" class="inp"><option value="">بدون مالیات</option>
                            <?php foreach ($taxes as $t): ?><option value="<?= (int)$t['id'] ?>" data-rate="<?= (float)$t['rate_percent'] ?>"><?= e($t['title']) ?></option><?php endforeach; ?>
                        </select>
                    </td>
                    <td><input type="text" name="line_amount[0]" class="inp money sum_src" value="0"></td>
                    <td><button type="button" class="btn icon gray js-del-row" title="حذف ردیف">✕</button></td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-foot">
        <div class="total-box">
            <div><span>جمع ردیف‌ها</span><strong class="num sum_src_out"><?= money(0) ?></strong></div>
            <div><span>جمع مالیات</span><strong class="num tax_out"><?= money(0) ?></strong></div>
            <div class="grand"><span>مبلغ نهایی سند</span><strong class="num grand_out"><?= money(0) ?></strong></div>
        </div>
        <div class="actions">
            <button type="submit" class="btn"><?= $row ? 'ذخیره تغییرات' : ($isExp ? 'ثبت سند هزینه' : 'ثبت سند درآمد') ?></button>
            <a class="btn gray" href="<?= url($isExp ? 'app/expenses' : 'app/incomes') ?>">انصراف</a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-head"><h3>توضیحات و پیوست</h3></div>
    <div class="card-body">
        <div class="grid c2">
            <label class="field"><span>توضیحات</span><textarea name="description" class="inp" rows="3"><?= e($row['description'] ?? ($old['description'] ?? '')) ?></textarea></label>
            <label class="field"><span>یادداشت پیوست (شماره فاکتور/فیش)</span><input type="text" name="attach_note" class="inp" placeholder="مثال: فیش واریزی ۸۷۴۵۲"></label>
        </div>
    </div>
</div>
</form>
<script>
(function () {
    var tbl = document.querySelector('table[data-rows="il"]');
    if (!tbl) return;
    function num(v) { return parseFloat(String(v).replace(/[^\d.-]/g, '')) || 0; }
    function renumber() {
        tbl.querySelectorAll('tbody tr').forEach(function (tr, n) {
            tr.querySelector('td.num') && (tr.querySelector('td.num').textContent = n + 1);
            tr.querySelectorAll('input,select').forEach(function (el) {
                if (el.name) el.name = el.name.replace(/\[\d+]/, '[' + n + ']');
            });
        });
    }
    function recalc() {
        var sum = 0, tax = 0;
        tbl.querySelectorAll('tbody tr').forEach(function (tr) {
            var amt = num((tr.querySelector('input[name^="line_amount"]') || {}).value);
            var sel = tr.querySelector('select[name^="line_tax_id"]');
            var rate = sel && sel.selectedOptions[0] ? parseFloat(sel.selectedOptions[0].dataset.rate || 0) : 0;
            sum += amt; tax += amt * rate / 100;
        });
        document.querySelectorAll('.sum_src_out').forEach(function (el) { el.textContent = sum.toLocaleString('fa-IR'); });
        document.querySelectorAll('.tax_out').forEach(function (el) { el.textContent = tax.toLocaleString('fa-IR'); });
        document.querySelectorAll('.grand_out').forEach(function (el) { el.textContent = (sum + tax).toLocaleString('fa-IR'); });
    }
    tbl.addEventListener('input', recalc);
    tbl.addEventListener('change', recalc);
    var add = document.querySelector('.js-add-row');
    if (add) add.addEventListener('click', function () {
        var tpl = tbl.querySelector('tbody tr').cloneNode(true);
        tpl.querySelectorAll('input').forEach(function (i) { i.value = i.classList.contains('money') ? '0' : ''; });
        tpl.querySelectorAll('select').forEach(function (s) { s.value = ''; });
        tbl.querySelector('tbody').appendChild(tpl);
        renumber(); recalc();
    });
    tbl.addEventListener('click', function (ev) {
        var b = ev.target.closest('.js-del-row');
        if (!b) return;
        var rows = tbl.querySelectorAll('tbody tr');
        if (rows.length <= 1) { rows[0].querySelectorAll('input').forEach(function (i) { i.value = i.classList.contains('money') ? '0' : ''; }); }
        else b.closest('tr').remove();
        renumber(); recalc();
    });
    tbl.addEventListener('change', function (ev) {
        if (ev.target.name !== 'category_id') return;
        var opt = ev.target.selectedOptions[0];
        var acc = opt && opt.dataset.account ? opt.dataset.account : '';
        var sel = document.querySelector('select[name="account_id"]');
        if (sel && acc) sel.value = acc;
    });
    recalc();
})();
</script>
<?= view('partials/foot') ?>