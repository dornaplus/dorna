<?= view('partials/head', ['title' => $title]) ?>
<?= view('partials/ai_upload', ['kind' => 'invoice', 'label' => 'فاکتور خرید/فروش']) ?>
<form method="post" action="<?= url('app/invoices') ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="invoice_type" value="<?= e($type) ?>">
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><span class="pill">شماره بعدی: <?= e($nextNo) ?></span><div class="grow"></div>
      <a class="btn ghost sm" href="<?= url('app/invoices?type='.$type) ?>">بازگشت به فهرست</a></div>
    <div class="form-grid">
      <div class="field"><label>شخص (<?= $type === 'sale' || $type === 'sale_return' ? 'مشتری' : 'تأمین‌کننده' ?> <span class="req">*</span></label>
        <select class="inp select-search" name="person_id" data-person-select="1" data-autoload="<?= $isReturn ? '0' : '0' ?>" required>
          <option value="">— انتخاب کنید —</option>
          <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '').' '.($p['company_name'] ?? '')); ?>
            <option value="<?= $p['id'] ?>" <?= (int)($preselectedPerson ?? 0) === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['code'].' — '.$nm.($p['mobile'] ? ' - '.$p['mobile'] : '')) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">شخص جدید؟ <a href="<?= url('app/persons/create') ?>" target="_blank">تعریف شخص</a></div>
      </div>
      <div class="field"><label>تاریخ فاکتور <span class="req">*</span></label>
        <input class="inp jalali" type="text" name="invoice_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      <div class="field"><label>تاریخ سررسید</label>
        <input class="inp jalali" type="text" name="due_date" data-term-autofill="1" placeholder="۱۴۰۴/۰۲/۱۵"
               data-value="<?= e((string)($dueDateDefault ?? '')) ?>" value="<?= !empty($dueDateDefault) ? e(jdate($dueDateDefault)) : '' ?>">
        <div class="hint">با انتخاب شخص، بر اساس «شرایط پرداخت» او خودکار پر می‌شود.</div></div>
      <div class="field"><label>انبار</label>
        <select class="inp" name="warehouse_id">
          <?php foreach ($warehouses as $w): ?><option value="<?= $w['id'] ?>"><?= e($w['title']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>نوع تسویه</label>
        <select class="inp" name="settlement_type">
          <option value="credit">اعتباری (نسیه)</option>
          <option value="cash">نقدی</option>
          <option value="cheque">چکی</option>
        </select></div>
      <div class="field"><label>حساب دریافت/پرداخت (در تسویه نقدی)</label>
        <select class="inp" name="cash_account_id"><option value="">— بدون—</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['title']) ?></option><?php endforeach; ?>
        </select></div>
      <?php if ($isReturn): ?>
      <div class="field"><label>فاکتور مرجع (برگشت از)</label>
        <select class="inp select-search" name="reference_invoice_id"><option value="">— انتخاب کنید —</option>
          <?php foreach ($openInvoices as $oi): ?><option value="<?= $oi['id'] ?>"><?= e(fa_digits((string)$oi['invoice_no']).' — '.jdate($oi['invoice_date']).' — '.num($oi['total_amount'])) ?></option><?php endforeach; ?>
        </select></div>
      <?php endif; ?>
      <?php if ($type === 'sale' || $type === 'sale_return'): ?>
      <div class="field"><label>بازاریاب</label>
        <select class="inp" name="marketer_id"><option value="">— بدون بازاریاب —</option>
          <?php foreach ($marketers as $mk): ?><option value="<?= $mk['id'] ?>"><?= e(($mk['full_name'] ?: $mk['code']).' ('.$mk['commission_percent'].'٪)') ?></option><?php endforeach; ?>
        </select></div>
      <?php endif; ?>
      <div class="field"><label>پروژه</label>
        <select class="inp" name="project_id"><option value="">— بدون پروژه —</option>
          <?php foreach ($projects as $pj): ?><option value="<?= $pj['id'] ?>"><?= e($pj['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>مرکز هزینه</label>
        <select class="inp" name="cost_center_id"><option value="">— بدون مرکز هزینه —</option>
          <?php foreach ($costCenters as $cc): ?><option value="<?= $cc['id'] ?>"><?= e($cc['name']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>تخفیف کل فاکتور</label><input class="inp money" type="text" name="invoice_discount" value="0"></div>
      <div class="field field-wide"><label>توضیحات <button type="button" class="btn soft sm" style="margin-inline-start:6px" data-ai-compose data-type="invoice_desc" data-target="#inv-desc" data-from="[name=person_id]"><?= icon('spark', 14) ?> تولید با AI</button></label><textarea class="inp" id="inv-desc" name="description" rows="2"></textarea></div>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>ردیف‌های کالا و خدمات</h3><div class="grow"></div>
      <button class="btn sm" type="button" data-add-row="inv">+ افزودن ردیف</button></div>
    <div class="table-wrap">
      <table class="tbl" style="min-width:900px">
        <thead><tr><th style="width:34px">#</th><th>کالا / خدمت</th><th>واحد</th><th>مقدار</th><th>قیمت واحد</th><th>تخفیف ٪</th><th>مالیات</th><th>جمع ردیف</th><th></th></tr></thead>
        <tbody data-rows="inv"></tbody>
      </table>
    </div>
    <template id="tpl-inv">
      <td>__n__</td>
      <td>
        <select name="line_product_id[]" class="inp select-search" required>
          <option value="">— انتخاب —</option>
          <?php foreach ($products as $pr): ?>
            <option value="<?= $pr['id'] ?>" data-sale="<?= (float)$pr['sale_price'] ?>" data-buy="<?= (float)$pr['buy_price'] ?>" data-unit="<?= (int)$pr['main_unit_id'] ?>" data-stock="<?= (float)$pr['stock_qty'] ?>">
              <?= e($pr['code'].' — '.$pr['title'].' ['.num($pr['stock_qty'], 1).']') ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="hint">موجودی: <span data-stock>—</span></div>
      </td>
      <td>
        <select name="line_unit_id[]" class="inp">
          <?php foreach (Database::all('SELECT id,title FROM units WHERE business_id=? ORDER BY id', [Auth::businessId()]) as $un): ?>
            <option value="<?= $un['id'] ?>"><?= e($un['title']) ?></option>
          <?php endforeach; ?>
        </select>
      </td>
      <td><input class="inp" type="number" step="any" name="line_quantity[]" value="1" min="0.0001" required></td>
      <td><input class="inp money" type="text" name="line_unit_price[]" value="" required></td>
      <td><input class="inp" type="number" step="any" name="line_discount[]" value="0" min="0" max="100"></td>
      <td>
        <select name="line_tax_id[]" class="inp">
          <option value="" data-rate="0">بدون مالیات</option>
          <?php foreach ($taxes as $tx): ?>
            <option value="<?= $tx['id'] ?>" data-rate="<?= (float)$tx['rate_percent'] ?>" <?= (!empty($vatTaxId) && (int)$tx['id'] === (int)$vatTaxId) ? 'selected' : '' ?>><?= e($tx['title'].' ('.$tx['rate_percent'].'٪)') ?></option>
          <?php endforeach; ?>
        </select>
      </td>
      <td><span data-line-total>0</span></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>

    <div class="form-grid" style="margin-top:12px">
      <div class="field"><label>جمع کل اقلام (بدون تخفیف)</label><div class="big-num" style="font-size:16px"><span id="sum_subtotal">0</span></div></div>
      <div class="field"><label>جمع تخفیف‌ها</label><div class="big-num" style="font-size:16px"><span id="sum_discount">0</span></div></div>
      <div class="field"><label>جمع مالیات</label><div class="big-num" style="font-size:16px"><span id="sum_tax">0</span></div></div>
      <div class="field"><label>جمع مقدار</label><div class="big-num" style="font-size:16px"><span id="sum_qty">0</span></div></div>
      <div class="field"><label>مبلغ قابل پرداخت فاکتور</label><div class="big-num" style="color:var(--p-700)"><span id="sum_total">0</span> <?= e(Auth::currency()) ?></div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>هزینه‌های اضافی (حمل، بسته‌بندی…)</h3><div class="grow"></div>
      <button class="btn ghost sm" type="button" data-add-row="chg">+ افزودن هزینه</button></div>
    <div class="table-wrap"><table class="tbl" style="min-width:700px">
      <thead><tr><th>نوع</th><th>عنوان</th><th>مبلغ</th><th>مالیات</th><th></th></tr></thead>
      <tbody data-rows="chg" data-charges></tbody></table></div>
    <template id="tpl-chg">
      <td><select name="charge_type[]" class="inp">
        <option value="shipping">حمل و نقل</option><option value="packaging">بسته‌بندی</option>
        <option value="insurance">بیمه</option><option value="other">سایر</option></select></td>
      <td><input class="inp" type="text" name="charge_title[]" value="هزینه حمل"></td>
      <td><input class="inp money" type="text" name="charge_amount[]" value=""></td>
      <td><select name="charge_tax_id[]" class="inp"><option value="" data-rate="0">بدون مالیات</option>
        <?php foreach ($taxes as $tx): ?><option value="<?= $tx['id'] ?>" data-rate="<?= (float)$tx['rate_percent'] ?>" <?= (!empty($vatTaxId) && (int)$tx['id'] === (int)$vatTaxId) ? 'selected' : '' ?>><?= e($tx['title']) ?></option><?php endforeach; ?>
      </select></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>
  </div>

  <div class="card">
    <div class="form-actions" style="border:none;margin:0;padding:0">
      <button class="btn success" name="save_mode" value="post" type="submit">ذخیره و قطعی‌سازی (صدور سند)</button>
      <button class="btn ghost" name="save_mode" value="draft" type="submit">ذخیره پیش‌نویس</button>
      <a class="btn gray" href="<?= url('app/invoices?type='.$type) ?>">انصراف</a>
      <div class="spacer"></div>
      <span class="help">با قطعی‌سازی، سند حسابداری و سند انبار به‌صورت خودکار صادر می‌شود.</span>
    </div>
  </div>
</form>
<?= view('partials/foot') ?>
