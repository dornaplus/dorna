<?= view('partials/head', ['title' => $title]) ?>
<div class="card tight">
  <form method="get" class="filters">
    <input type="hidden" name="type" value="<?= e($type) ?>">
    <div class="field" style="flex:1;min-width:200px"><label>جست‌وجو</label><input class="inp" type="text" name="q" value="<?= e($q) ?>" placeholder="شماره فاکتور یا توضیح…"></div>
    <div class="field"><label>وضعیت</label>
      <select class="inp" name="status"><option value="">همه</option>
        <?php foreach (['draft','posted','cancelled','returned'] as $s): ?>
          <option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(Meta::enumLabel($s)) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="field"><label>شخص</label>
      <select class="inp" name="person_id"><option value="">همه</option>
        <?php foreach (Database::all('SELECT id,code,first_name,last_name,company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [Auth::businessId()]) as $pp): ?>
          <option value="<?= $pp['id'] ?>" <?= $personId == $pp['id'] ? 'selected' : '' ?>><?= e(trim(($pp['first_name'] ?? '').' '.($pp['last_name'] ?? '').' '.($pp['company_name'] ?? ''))) ?></option>
        <?php endforeach; ?>
      </select></div>
    <div class="field"><label>از تاریخ</label><input class="inp jalali" type="text" name="from" value="<?= e($from) ?>"></div>
    <div class="field"><label>تا تاریخ</label><input class="inp jalali" type="text" name="to" value="<?= e($to) ?>"></div>
    <div class="field"><button class="btn">اعمال</button></div>
  </form>
</div>

<div class="card">
  <div class="card-head">
    <h3><?= e($title) ?></h3><span class="pill"><?= num($totals['cnt'] ?? 0) ?> فاکتور</span>
    <div class="grow"></div>
    <a class="btn" href="<?= url('app/invoices/create?type='.$type) ?>">+ ثبت <?= e(InvoiceController::TYPE_TITLES[$type] ?? 'فاکتور') ?></a>
    <a class="btn ghost sm" href="<?= url('app/reports/invoice_list?invoice_type='.$type) ?>">گزارش</a>
  </div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'فاکتوری با این شرایط یافت نشد.', 'actionUrl' => url('app/invoices/create?type='.$type), 'actionText' => '+ ثبت فاکتور']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>تاریخ</th><th>شخص</th><th>نوع تسویه</th><th>مبلغ کل</th><th>پرداخت‌شده</th><th>مانده</th><th>سود</th><th>وضعیت</th><th>تسویه</th><th>عملیات</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): $pname = trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '').' '.($r['company_name'] ?? '')); ?>
      <tr>
        <td><a href="<?= url('app/invoices/'.$r['id']) ?>"><b><?= e(fa_digits((string)$r['invoice_no'])) ?></b></a>
          <?php if ($r['reference_invoice_id']): ?><div class="s muted">برگشت</div><?php endif; ?></td>
        <td><?= e(jdate($r['invoice_date'])) ?></td>
        <td><?= e($pname) ?><div class="muted small"><?= e($r['person_code'] ?? '') ?></div></td>
        <td><span class="pill"><?= e(Meta::enumLabel($r['settlement_type'])) ?></span></td>
        <td class="num money-v"><?= num($r['total_amount']) ?></td>
        <td class="num"><?= num($r['paid_amount']) ?></td>
        <td class="num" style="color:<?= (float)$r['remaining_amount'] > 0 ? 'var(--err)' : 'var(--ok)' ?>"><?= num($r['remaining_amount']) ?></td>
        <td class="num"><?= num($r['profit_amount']) ?></td>
        <td><span class="pill st-<?= e($r['status']) ?>"><?= e(Meta::enumLabel($r['status'])) ?></span></td>
        <td><span class="pill st-<?= e($r['settlement_status']) ?>"><?= e(Meta::enumLabel($r['settlement_status'])) ?></span></td>
        <td class="acts">
          <a class="btn ghost sm" href="<?= url('app/invoices/'.$r['id']) ?>">مشاهده</a>
          <?= print_buttons(url('app/invoices/'.$r['id'].'/print'), 'sm') ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot class="tfoot"><tr>
      <td colspan="4">جمع کل</td>
      <td class="num"><?= num($totals['total'] ?? 0) ?></td>
      <td class="num"><?= num($totals['paid'] ?? 0) ?></td>
      <td class="num"><?= num($totals['remaining'] ?? 0) ?></td>
      <td class="num"><?= num($totals['profit'] ?? 0) ?></td>
      <td colspan="3"></td>
    </tr></tfoot>
  </table></div>
  <?= view('partials/pagination', ['page' => $page, 'per' => $per, 'total' => (int)($totals['cnt'] ?? 0)]) ?>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
