<?php /** @var array $inv @var array $lines @var array $charges @var array $person @var array $tpl @var array $business */
$tpl = $tpl ?? Printing::template('invoice'); ?>
<?= view('partials/public_head', ['title' => $title]) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
  <?= view('partials/print_bar', ['back' => url('app/invoices/'.$inv['id'])]) ?>
  <div class="print-head">
    <div class="print-brand">
      <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
      <div class="biz"><?= e($business['name'] ?? '') ?></div>
      <div class="print-meta">
        <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <b><?= e($business['economic_code']) ?></b><br><?php endif; ?>
        <?php if (!empty($business['national_id'])): ?>شناسه ملی: <b><?= e($business['national_id']) ?></b><br><?php endif; ?>
        <?php if (!empty($business['address'])): ?>نشانی: <?= e($business['address']) ?><br><?php endif; ?>
        <?php if (!empty($business['phone'])): ?>تلفن: <b><?= e($business['phone']) ?></b><?php endif; ?>
      </div>
    </div>
    <div style="text-align:left">
      <div style="font-size:15px;font-weight:700;color:var(--p-800)"><?= e($typeTitle) ?></div>
      <div class="print-meta">شماره: <b><?= e(fa_digits((string)$inv['invoice_no'])) ?></b><br>تاریخ: <b><?= e(jdate($inv['invoice_date'])) ?></b><br>
        <?php if ($inv['due_date']): ?>سررسید: <b><?= e(jdate($inv['due_date'])) ?></b><?php endif; ?></div>
    </div>
  </div>
  <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)$inv['invoice_no']); ?>
  <div class="print-meta" style="margin-bottom:8px">
    خریدار/فروشنده: <b><?= e(trim(($person['first_name'] ?? '').' '.($person['last_name'] ?? '').' '.($person['company_name'] ?? ''))) ?></b>
    <?php if (!empty($person['mobile'])): ?> — همراه: <b style="direction:ltr;display:inline-block"><?= e($person['mobile']) ?></b><?php endif; ?>
    <?php if (!empty($person['national_id'])): ?> — کد ملی: <b><?= e($person['national_id']) ?></b><?php endif; ?><br>
    <?php if (!empty($person['address'])): ?>نشانی: <?= e($person['address']) ?><?php endif; ?>
  </div>
  <table class="print-tbl">
    <thead><tr><th>#</th><th>کالا / خدمت</th><th>واحد</th><th>مقدار</th><th>قیمت واحد</th><th>تخفیف</th><th>مالیات</th><th>جمع</th></tr></thead>
    <tbody>
    <?php foreach ($lines as $l): ?>
      <tr>
        <td><?= num($l['row_no']) ?></td>
        <td><?= e(($l['code'] ?? '').' — '.($l['product_title'] ?? '')) ?></td>
        <td><?= e($l['unit_title'] ?? '—') ?></td>
        <td><?= num($l['quantity'], 2) ?></td>
        <td><?= num($l['unit_price']) ?></td>
        <td><?= num($l['discount_amount']) ?></td>
        <td><?= num($l['tax_amount']) ?></td>
        <td><?= num($l['line_total']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><th colspan="7">جمع اقلام</th><th><?= num($inv['subtotal']) ?></th></tr>
      <tr><th colspan="7">تخفیف</th><th><?= num((float)$inv['line_discount'] + (float)$inv['invoice_discount']) ?></th></tr>
      <tr><th colspan="7">مالیات بر ارزش افزوده</th><th><?= num($inv['tax_amount']) ?></th></tr>
      <?php if ((float)$inv['charges_amount'] > 0): ?><tr><th colspan="7">هزینه‌های اضافی</th><th><?= num($inv['charges_amount']) ?></th></tr><?php endif; ?>
      <tr><th colspan="7">مبلغ قابل پرداخت</th><th><?= num($inv['total_amount']) ?></th></tr>
    </tfoot>
  </table>
  <?php if (!empty($tpl['amount_in_words'])): ?><div class="words">مبلغ به حروف: <?= e($amountWords) ?></div><?php endif; ?>
  <?php if ($inv['description']): ?><div class="small muted" style="margin-top:8px">توضیحات: <?= e($inv['description']) ?></div><?php endif; ?>
  <?php if (!empty($tpl['show_bank_info'])) echo Printing::bankBlock(); ?>
  <?php if (!empty($tpl['show_signature'])): ?>
  <div class="signs">
    <?php if (!empty($business['name'])): ?><span>مهر و امضای فروشنده</span><?php endif; ?>
    <span>امضای خریدار</span>
  </div>
  <?php endif; ?>
</div>
<?= view('partials/public_foot') ?>
