<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head">
    <h3><?= e($typeTitle) ?> <?= e(fa_digits((string)$inv['invoice_no'])) ?></h3>
    <span class="pill st-<?= e($inv['status']) ?>"><?= e(Meta::enumLabel($inv['status'])) ?></span>
    <span class="pill st-<?= e($inv['settlement_status']) ?>"><?= e(Meta::enumLabel($inv['settlement_status'])) ?></span>
    <div class="grow"></div>
    <?php if ($inv['status'] === 'draft'): ?>
      <form method="post" action="<?= url('app/invoices/'.$inv['id'].'/post') ?>" style="display:inline"><?= csrf_field() ?>
        <button class="btn success">قطعی‌سازی و صدور سند</button></form>
      <form method="post" data-confirm="این پیش‌فاکتور/فاکتور لغو شود؟" action="<?= url('app/invoices/'.$inv['id'].'/cancel') ?>" style="display:inline"><?= csrf_field() ?>
        <button class="btn danger">لغو</button></form>
    <?php endif; ?>
    <?php if ($inv['settlement_status'] !== 'paid' && $inv['status'] === 'posted'): ?>
      <a class="btn ghost" href="<?= url('app/receipts/create?person_id='.$inv['person_id']) ?>">ثبت دریافت</a>
    <?php endif; ?>
    <?= print_buttons(url('app/invoices/'.$inv['id'].'/print')) ?>
  </div>

  <div class="grid c4">
    <div><div class="muted small">شخص</div><div><b><?= e(trim(($inv['first_name'] ?? '').' '.($inv['last_name'] ?? '').' '.($inv['company_name'] ?? ''))) ?></b></div><div class="muted small"><?= e($inv['person_code'] ?? '') ?></div></div>
    <div><div class="muted small">تاریخ فاکتور</div><div><b><?= e(jdate($inv['invoice_date'])) ?></b></div><div class="muted small">سررسید: <?= e(jdate($inv['due_date'])) ?></div></div>
    <div><div class="muted small">نوع تسویه</div><div><b><?= e(Meta::enumLabel($inv['settlement_type'])) ?></b></div><div class="muted small">انبار: <?= e(Database::val('SELECT title FROM warehouses WHERE id=?', [$inv['warehouse_id']], '—')) ?></div></div>
    <div><div class="muted small">سند حسابداری / سند انبار</div>
      <div><?= $je ? '<a href="'.url('app/journal/'.$je['id']).'">سند '.e(fa_digits((string)$je['entry_no'])).'</a>' : '<span class="muted">—</span>' ?></div>
      <div><?= $invDoc ? '<a href="'.url('app/inventory-documents/'.$invDoc['id']).'">'.e(fa_digits((string)$invDoc['doc_no'])).'</a>' : '<span class="muted">—</span>' ?></div></div>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>اقلام فاکتور</h3></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>#</th><th>کالا/خدمت</th><th>مقدار</th><th>واحد</th><th>قیمت واحد</th><th>تخفیف</th><th>مالیات</th><th>جمع ردیف</th><th>بهای تمام‌شده</th></tr></thead>
    <tbody>
    <?php foreach ($lines as $l): ?>
      <tr>
        <td><?= num($l['row_no']) ?></td>
        <td><?= e(($l['code'] ?? '').' — '.($l['product_title'] ?? '')) ?></td>
        <td class="num"><?= num($l['quantity'], 2) ?></td>
        <td><?= e($l['unit_title'] ?? '—') ?></td>
        <td class="num"><?= num($l['unit_price']) ?></td>
        <td class="num"><?= num($l['discount_amount']) ?></td>
        <td class="num"><?= num($l['tax_amount']) ?> <span class="muted small"><?= e($l['tax_title'] ?? '') ?></span></td>
        <td class="num money-v"><?= num($l['line_total']) ?></td>
        <td class="num muted"><?= num($l['unit_cost']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="grid c4" style="margin-top:12px">
    <div><div class="muted small">جمع اقلام</div><b><?= num($inv['subtotal']) ?></b></div>
    <div><div class="muted small">تخفیف (ردیف + کل)</div><b><?= num((float)$inv['line_discount'] + (float)$inv['invoice_discount']) ?></b></div>
    <div><div class="muted small">مالیات و هزینه‌ها</div><b><?= num((float)$inv['tax_amount'] + (float)$inv['charges_amount']) ?></b></div>
    <div><div class="muted small">مبلغ کل قابل پرداخت</div><b class="big-num" style="font-size:18px"><?= num($inv['total_amount']) ?></b></div>
  </div>
  <?php if ($charges): ?>
    <div class="section-title">هزینه‌های اضافی</div>
    <div class="table-wrap"><table class="tbl" style="min-width:520px">
      <thead><tr><th>نوع</th><th>عنوان</th><th>مبلغ</th><th>مالیات</th></tr></thead>
      <tbody><?php foreach ($charges as $c): ?>
        <tr><td><?= e(Meta::enumLabel($c['charge_type'])) ?></td><td><?= e($c['title']) ?></td><td class="num"><?= num($c['amount']) ?></td><td class="num"><?= num($c['tax_amount']) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
  <?php endif; ?>
</div>

<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>تسویه‌ها</h3><span class="pill">پرداخت‌شده: <?= num($inv['paid_amount']) ?></span>
      <span class="pill">مانده: <?= num($inv['remaining_amount']) ?></span></div>
    <?php if (!$settlements): ?><div class="muted small">تسویه‌ای ثبت نشده است.</div><?php endif; ?>
    <div class="table-wrap"><table class="tbl" style="min-width:460px">
      <?php if ($settlements): ?>
      <thead><tr><th>تاریخ</th><th>منبع</th><th>سند</th><th>مبلغ</th><th>توضیح</th></tr></thead>
      <tbody><?php foreach ($settlements as $s): ?>
        <tr><td><?= e(jdate($s['settled_at'])) ?></td>
          <td><span class="pill"><?= e(Meta::enumLabel($s['settle_source'])) ?></span></td>
          <td><?= e(fa_digits((string)($s['receipt_no'] ?? $s['payment_no'] ?? $s['cheque_no'] ?? '—'))) ?></td>
          <td class="num"><?= num($s['amount']) ?></td><td class="muted small"><?= e($s['note'] ?? '') ?></td></tr>
      <?php endforeach; ?></tbody>
      <?php endif; ?>
    </table></div>
    <?php if ($je): ?>
      <div class="section-title">سند حسابداری</div>
      <div class="table-wrap"><table class="tbl" style="min-width:560px">
        <thead><tr><th>حساب</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th></tr></thead>
        <tbody>
        <?php foreach (Database::all('SELECT l.*, a.code, a.title FROM journal_entry_lines l JOIN chart_of_accounts a ON a.id=l.account_id WHERE l.journal_entry_id=? ORDER BY l.row_no', [$je['id']]) as $jl): ?>
          <tr><td><?= e($jl['code'].' — '.$jl['title']) ?></td><td class="muted small"><?= e($jl['description'] ?? '') ?></td>
            <td class="num"><?= (float)$jl['debit_amount'] ? num($jl['debit_amount']) : '—' ?></td>
            <td class="num"><?= (float)$jl['credit_amount'] ? num($jl['credit_amount']) : '—' ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>گردش وضعیت</h3></div>
    <div class="table-wrap"><table class="tbl" style="min-width:420px">
      <thead><tr><th>از</th><th>به</th><th>کاربر</th><th>تاریخ</th><th>دلیل</th></tr></thead>
      <tbody><?php foreach ($history as $h): ?>
        <tr><td><?= e($h['from_status'] ? Meta::enumLabel($h['from_status']) : '—') ?></td>
          <td><span class="pill st-<?= e($h['to_status']) ?>"><?= e(Meta::enumLabel($h['to_status'])) ?></span></td>
          <td><?= e($h['full_name'] ?? '—') ?></td><td><?= e(jdate($h['changed_at'], '/', true)) ?></td><td class="muted small"><?= e($h['reason'] ?? '') ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <div class="help" style="margin-top:10px">سود فاکتور: <b><?= num($inv['profit_amount']) ?></b> — بهای تمام‌شده: <b><?= num($inv['cost_amount']) ?></b></div>
    <?php if ($inv['description']): ?><div class="section-title">توضیحات</div><div class="small"><?= e($inv['description']) ?></div><?php endif; ?>
  </div>
</div>

<?php if (!empty($receipts)): ?>
<div class="card">
  <div class="card-head"><h3><?= icon('wallet', 16) ?> رسیدهای پرداخت مشتری (پورتال)</h3><span class="pill"><?= num(count($receipts)) ?></span></div>
  <div class="table-wrap"><table class="tbl" style="min-width:640px">
    <thead><tr><th>فایل</th><th>توضیح</th><th>تاریخ ارسال</th><th>وضعیت</th><th>بررسی‌کننده</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($receipts as $r): ?>
      <tr>
        <td><a href="<?= url('app/invoices/' . (int)$inv['id'] . '/receipt/' . (int)$r['id'] . '/download') ?>" target="_blank" rel="noopener"><?= icon('file', 14) ?> <?= e($r['file_name']) ?></a>
          <div class="muted small"><?= num((int)round((int)$r['size_bytes'] / 1024)) ?> کیلوبایت</div></td>
        <td class="muted small"><?= e($r['note'] ?? '—') ?></td>
        <td><?= e(jdate($r['created_at'], '/', true)) ?></td>
        <td><span class="pill st-<?= e($r['status']) ?>"><?= e(['pending' => 'در انتظار تأیید', 'verified' => 'تأیید شد', 'rejected' => 'رد شد'][$r['status']] ?? $r['status']) ?></span></td>
        <td class="muted small"><?= e($r['reviewer_name'] ?? '—') ?></td>
        <td>
          <?php if ($r['status'] === 'pending' && (Auth::can('invoices.approve') || Auth::can('invoices.edit'))): ?>
            <div class="btn-row" style="justify-content:flex-end">
              <form method="post" action="<?= url('app/invoices/' . (int)$inv['id'] . '/receipt/' . (int)$r['id'] . '/review') ?>" style="margin:0"><?= csrf_field() ?><input type="hidden" name="status" value="verified"><button class="btn success sm">تأیید</button></form>
              <form method="post" action="<?= url('app/invoices/' . (int)$inv['id'] . '/receipt/' . (int)$r['id'] . '/review') ?>" style="margin:0"><?= csrf_field() ?><input type="hidden" name="status" value="rejected"><button class="btn danger sm">رد</button></form>
            </div>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?php endif; ?>
<?= view('partials/foot') ?>
