<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $threads @var array|null $thread @var array $messages @var array $attachments @var array $colleagues @var array $searchResults */
$me = (int)Auth::id();
$activeId = (int)($thread['id'] ?? 0);
$otherName = ''; $otherAvatar = '';
foreach ($threads as $t) if ((int)$t['id'] === $activeId) { $otherName = (string)$t['other_name']; $otherAvatar = (string)($t['other_avatar'] ?? ''); }
if ($activeId && $otherName === '') $otherName = (string)Database::val('SELECT full_name FROM users WHERE id=?', [Messages::otherId($thread)], '');
$threadTotal = array_sum(array_map(fn($t) => (int)$t['unread'], $threads));
?>
<div class="pm-wrap<?= $activeId ? ' has-thread' : '' ?>">
  <aside class="pm-side">
    <div class="pm-side-head">
      <form method="get" action="<?= url('app/messages') ?>" class="pm-search">
        <input class="inp" type="search" name="q" value="<?= e($q) ?>" placeholder="جست‌وجوی پیام یا همکار…">
      </form>
      <div class="pm-side-actions">
        <div class="pm-unread-total"><?= num($unread) ?> پیام نخوانده</div>
        <button class="btn soft sm" type="button" id="pmGroupBtn">+ گروه جدید</button>
      </div>
    </div>
    <?php if ($q !== '' && $searchResults): ?>
      <div class="pm-search-res">
        <div class="pm-section">نتایج جست‌وجو (<?= num(count($searchResults)) ?>)</div>
        <?php foreach (array_slice($searchResults, 0, 12) as $r): ?>
          <a class="pm-item" href="<?= url('app/messages?t=' . (int)$r['thread_id']) ?>">
            <?= Avatar::html((string)($r['sender_name'] ?? ''), (string)($r['sender_avatar'] ?? ''), 'pm-av') ?>
            <span class="pm-item-b"><b><?= e((string)($r['sender_name'] ?? '—')) ?></b><small><?= e(mb_substr((string)($r['body'] ?? ''), 0, 60)) ?></small></span>
            <span class="pm-item-t"><?= e(jdate((string)$r['created_at'], '/')) ?></span>
          </a>
        <?php endforeach; ?>
        <div class="pm-section">گفت‌وگوها</div>
      </div>
    <?php endif; ?>
    <div class="pm-list">
      <?php foreach ($threads as $t): ?>
        <a class="pm-item <?= (int)$t['id'] === $activeId ? 'on' : '' ?>" href="<?= url('app/messages?t=' . (int)$t['id']) ?>">
          <?php if ((string)($t['kind'] ?? 'direct') === 'group'): ?><span class="pm-av grp">👥</span><?php else: ?><?= Avatar::html((string)($t['other_name'] ?? ''), (string)($t['other_avatar'] ?? ''), 'pm-av') ?><?php endif; ?>
          <span class="pm-item-b">
            <b><?= e((string)($t['other_name'] ?? '—')) ?><?php if ((string)($t['kind'] ?? 'direct') === 'group'): ?> <i class="pm-mcount"><?= num((int)($t['member_count'] ?? 0)) ?> عضو</i><?php endif; ?></b>
            <small>
              <?php if ((int)$t['last_sender'] === $me): ?><span class="pm-you">شما:</span> <?php endif; ?>
              <?= e(mb_substr((string)($t['last_body'] ?? ''), 0, 42)) ?: ((int)$t['last_has_file'] === 1 ? '📎 فایل' : '—') ?>
            </small>
          </span>
          <?php if ((int)$t['unread'] > 0): ?><span class="pm-badge"><?= num((int)$t['unread']) ?></span><?php endif; ?>
          <span class="pm-item-t"><?= e(Messages::ago((string)($t['last_at'] ?? $t['created_at']))) ?></span>
        </a>
      <?php endforeach; ?>
      <?php if (!$threads): ?><div class="pm-empty">هنوز گفت‌وگویی ندارید. از فهرست همکاران یک نفر را انتخاب کنید.</div><?php endif; ?>
    </div>
  </aside>

  <section class="pm-main">
    <?php if (!$thread): ?>
      <div class="pm-start">
        <h3><?= icon('mail', 18) ?> یک گفت‌وگو را شروع کنید</h3>
        <p class="muted sm">می‌توانید همراه پیام، فایل (تصویر، PDF، Word، Excel، ZIP) هم بفرستید. فایل‌ها روی سرور ذخیره می‌شوند و فقط دو طرف گفت‌وگو به آن‌ها دسترسی دارند.</p>
        <div class="pm-cols">
          <?php foreach ($colleagues as $c): ?>
            <a class="pm-col" href="<?= url('app/messages?u=' . (int)$c['id']) ?>">
              <?= Avatar::html((string)$c['full_name'], (string)($c['avatar_path'] ?? ''), 'pm-av') ?>
              <span class="pm-col-b"><b><?= e($c['full_name']) ?></b><small><?= e((string)($c['mobile'] ?? '')) ?></small></span>
              <span class="pm-col-go">شروع گفت‌وگو</span>
            </a>
          <?php endforeach; ?>
          <?php if (!$colleagues): ?><div class="pm-empty">همکار دیگری در این کسب‌وکار ثبت نشده است.</div><?php endif; ?>
        </div>
      </div>
    <?php else: ?>
      <?php $isGroup = (string)($thread['kind'] ?? 'direct') === 'group'; ?>
      <div class="pm-main-head">
        <a class="pm-back" href="<?= url('app/messages') ?>" title="بازگشت">→</a>
        <?php if ($isGroup): ?><span class="pm-av grp">👥</span><?php else: ?><?= Avatar::html($otherName, $otherAvatar, 'pm-av') ?><?php endif; ?>
        <div class="pm-main-h">
          <b><?= e($isGroup ? (string)($thread['title'] ?? 'گروه') : $otherName) ?></b>
          <small>
            <?php if ($isGroup): ?>
              <?= num(count($members)) ?> عضو: <?= e(implode('، ', array_map(fn($m) => (string)($m['full_name'] ?? '—'), $members))) ?>
            <?php else: ?>
              <?= num(count($messages)) ?> پیام · <?= e(jdate((string)$thread['created_at'], '/')) ?> به بعد
            <?php endif; ?>
          </small>
        </div>
      </div>
      <div class="pm-msgs" id="pmMsgs" data-thread="<?= $activeId ?>">
        <?= view('partials/pm_messages', ['rows' => $messages, 'att' => $attachments, 'openEvents' => $openEvents]) ?>
        <?php if (!$messages): ?><div class="pm-empty">گفت‌وگو خالی است؛ اولین پیام را بفرستید.</div><?php endif; ?>
      </div>
      <form class="pm-composer" id="pmForm" method="post" action="<?= url('app/messages/send') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <input type="hidden" name="thread_id" value="<?= $activeId ?>">
        <input type="file" name="files[]" id="pmFiles" multiple hidden
               accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.rar">
        <button class="pm-attach" type="button" id="pmAttachBtn" title="پیوست فایل"><?= icon('upload', 18) ?></button>
        <textarea class="inp" name="body" id="pmBody" rows="1" placeholder="پیام خود را بنویسید… (Enter برای ارسال)"></textarea>
        <button class="btn" type="submit"><?= icon('check', 16) ?> ارسال</button>
        <div class="pm-files-preview" id="pmFilesPreview" hidden></div>
      </form>
    <?php endif; ?>
  </section>
</div>

<div class="pm-modal-bg" id="pmGroupModal" hidden>
  <form class="pm-modal" method="post" action="<?= url('app/messages/group') ?>">
    <?= csrf_field() ?>
    <div class="pm-modal-head"><b>ساخت گروه جدید</b><div class="grow"></div>
      <button class="pm-x" type="button" data-pm-group-close>×</button></div>
    <div class="pm-modal-body">
      <label class="field"><span>نام گروه</span>
        <input class="inp" name="title" placeholder="مثلاً گروه انبار و فروش" maxlength="150" required></label>
      <div class="pm-section">اعضای گروه</div>
      <div class="pm-members">
        <?php foreach ($colleagues as $c): ?>
          <label class="pm-member"><input type="checkbox" name="members[]" value="<?= (int)$c['id'] ?>">
            <?= Avatar::html((string)$c['full_name'], (string)($c['avatar_path'] ?? ''), 'pm-av sm') ?>
            <span><?= e($c['full_name']) ?></span></label>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="pm-modal-foot">
      <button class="btn">ساخت گروه</button>
      <button class="btn gray" type="button" data-pm-group-close>انصراف</button>
    </div>
  </form>
</div>

<script>
(function () {
    var BASE = window.APP_BASE || '';
    var gBtn = document.getElementById('pmGroupBtn'), gModal = document.getElementById('pmGroupModal');
    if (gBtn && gModal) {
        gBtn.addEventListener('click', function () { gModal.hidden = false; });
        gModal.querySelectorAll('[data-pm-group-close]').forEach(function (b) { b.addEventListener('click', function () { gModal.hidden = true; }); });
        gModal.addEventListener('click', function (e) { if (e.target === gModal) gModal.hidden = true; });
    }
    var form = document.getElementById('pmForm');
    if (form) {
        var body = document.getElementById('pmBody');
        var files = document.getElementById('pmFiles');
        var prev = document.getElementById('pmFilesPreview');
        var msgs = document.getElementById('pmMsgs');
        var attachBtn = document.getElementById('pmAttachBtn');
        if (attachBtn) attachBtn.addEventListener('click', function () { files.click(); });
        if (files) files.addEventListener('change', function () {
            if (!prev) return;
            if (!files.files.length) { prev.hidden = true; prev.innerHTML = ''; return; }
            prev.hidden = false;
            prev.innerHTML = Array.prototype.map.call(files.files, function (f) {
                return '<span class="pm-chip">📎 ' + f.name + ' (' + Math.round(f.size / 1024) + 'KB)</span>';
            }).join('');
        });
        if (body) {
            var grow = function () { body.style.height = 'auto'; body.style.height = Math.min(140, body.scrollHeight) + 'px'; };
            body.addEventListener('input', grow);
            body.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.submit(); }
            });
            grow();
        }
        var lastId = function () {
            var rows = msgs.querySelectorAll('.pm-row');
            return rows.length ? parseInt(rows[rows.length - 1].getAttribute('data-id'), 10) : 0;
        };
        var scrollDown = function () { msgs.scrollTop = msgs.scrollHeight; };
        scrollDown();
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var fd = new FormData(form);
            fd.append('ajax', '1');
            fd.append('after', lastId());
            fetch(BASE + '/app/messages/send', { method: 'POST', body: fd, credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (j) {
                    if (!j || !j.ok) { alert((j && j.error) || 'ارسال ناموفق بود'); return; }
                    var empty = msgs.querySelector('.pm-empty'); if (empty) empty.remove();
                    if (j.html) msgs.insertAdjacentHTML('beforeend', j.html);
                    body.value = ''; if (files) files.value = '';
                    if (prev) { prev.hidden = true; prev.innerHTML = ''; }
                    body.style.height = 'auto';
                    scrollDown();
                })
                .catch(function () { alert('ارتباط برقرار نشد.'); });
        });
        // دریافت پیام‌های تازه
        setInterval(function () {
            fetch(BASE + '/app/messages/poll?t=' + msgs.getAttribute('data-thread') + '&after=' + lastId(), { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
                .then(function (r) { return r.json(); })
                .then(function (j) {
                    if (!j || !j.ok || !j.html) return;
                    var empty = msgs.querySelector('.pm-empty'); if (empty) empty.remove();
                    msgs.insertAdjacentHTML('beforeend', j.html);
                    scrollDown();
                }).catch(function () {});
        }, 15000);
    }
})();
</script>
<?= view('partials/foot') ?>
