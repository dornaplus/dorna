<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<form method="post" action="<?= url('app/payroll/advances') ?>">
  <?= csrf_field() ?>
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">مبلغ از حساب انتخاب‌شده پرداخت و به‌صورت قسط از سندهای حقوق کسر می‌شود.</div></div>
    <div style="display:flex;gap:8px"><a class="btn ghost" href="<?= url('app/payroll/advances') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ثبت مساعده و صدور سند</button></div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>اطلاعات مساعده</h3></div>
    <div class="card-body">
      <div class="grid-2b">
        <div class="field"><label>پرسنل *</label>
          <select class="inp" name="employee_id" id="advEmp" required><option value="">— انتخاب —</option>
            <?php foreach ($employees as $e): $o = $outstanding[(int)$e['id']] ?? ['advance'=>0,'loan'=>0]; ?>
              <option value="<?= (int)$e['id'] ?>" data-adv="<?= (float)$o['advance'] ?>" data-loan="<?= (float)$o['loan'] ?>"><?= e($e['code'] . ' — ' . $e['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="help" id="advOut"></div></div>
        <div class="field"><label>تاریخ *</label><input class="inp jalali" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>مبلغ مساعده (<?= e($cur) ?>) *</label><input class="inp money" name="amount" id="advAmount" value="0" required></div>
        <div class="field"><label>تعداد قسط *</label><input class="inp" name="installments" id="advInst" value="1" inputmode="numeric" required>
          <div class="help" id="advPer"></div></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>حساب پرداخت *</label>
          <select class="inp" name="cash_account_id" required><option value="">— انتخاب —</option>
            <?php foreach ($cashAccounts as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['title'] . ' (' . num($c['current_balance']) . ')') ?></option><?php endforeach; ?>
          </select></div>
        <div class="field"><label>کارگاه (اختیاری)</label><select class="inp" name="workshop_id"><option value="">— —</option>
          <?php foreach ($workshops as $w): ?><option value="<?= (int)$w['id'] ?>"><?= e($w['code'] . ' — ' . $w['title']) ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="field"><label>توضیح درخواست</label><input class="inp" name="request_note" placeholder="مثال: مساعدهٔ ضروری"></div>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-p" type="submit">ثبت</button>
    <a class="btn ghost" href="<?= url('app/payroll/advances') ?>">انصراف</a></div>
</form>
<script>
(function () {
  function num(v) { return Number(String(v == null ? '' : v).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[^\d.-]/g, '')) || 0; }
  var emp = document.getElementById('advEmp'), amt = document.getElementById('advAmount'), inst = document.getElementById('advInst');
  var out = document.getElementById('advOut'), per = document.getElementById('advPer');
  function upd() {
    var o = emp.options[emp.selectedIndex]; var a = o ? num(o.getAttribute('data-adv')) : 0;
    out.textContent = a > 0 ? 'مساعدهٔ باز فعلی این پرسنل: ' + a.toLocaleString('fa-IR') : '';
    var n = Math.max(1, num(inst.value));
    per.textContent = 'هر قسط: ' + Math.round(num(amt.value) / n).toLocaleString('fa-IR');
  }
  [emp, amt, inst].forEach(function (el) { if (el) { el.addEventListener('input', upd); el.addEventListener('change', upd); } });
  upd();
})();
</script>
<?= view('partials/foot') ?>
