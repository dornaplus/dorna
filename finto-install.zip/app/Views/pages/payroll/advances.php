<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">مساعده‌ها</h1>
    <div class="muted small">پرداخت علی‌الحساب حقوق که به‌صورت قسط از سند حقوق کسر می‌شود.</div></div>
  <?php if (Auth::can('payroll.create')): ?><a class="btn btn-p" href="<?= url('app/payroll/advances/create') ?>">+ ثبت مساعده</a><?php endif; ?>
</div>
<form method="get" class="filters" style="margin-top:12px">
  <div class="field" style="flex:1;min-width:170px"><label>جست‌وجو</label><input class="inp" name="q" value="<?= e($f['q']) ?>"></div>
  <div class="field"><label>پرسنل</label><select class="inp" name="employee_id"><option value="">همه</option>
    <?php foreach ($employees as $e): ?><option value="<?= (int)$e['id'] ?>" <?= (int)$f['employee_id'] === (int)$e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>وضعیت</label><select class="inp" name="status"><option value="">همه</option>
    <?php foreach (Payroll::ADVANCE_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>
<div class="card">
  <div class="card-head"><h3>فهرست مساعده‌ها</h3><div class="grow"></div>
    <span class="pill">جمع: <?= num($sum['amount']) ?></span>
    <span class="pill">کسرشده: <?= num($sum['settled']) ?></span>
    <span class="pill">مانده: <?= num($sum['remaining']) ?></span></div>
  <?php if (!$rows): ?><?= view('partials/empty', ['message' => 'مساعده‌ای ثبت نشده است.']) ?><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>تاریخ</th><th>پرسنل</th><th>مبلغ</th><th>اقساط</th><th>قسط</th><th>کسرشده</th><th>مانده</th><th>حساب</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $a): ?>
      <tr><td><b><?= e(fa_digits((string)$a['doc_no'])) ?></b></td><td><span class="muted small"><?= e(jdate($a['doc_date'])) ?></span></td>
        <td><?= e($a['full_name']) ?><div class="muted small"><?= e($a['employee_code']) ?><?= $a['workshop_title'] ? ' · ' . e($a['workshop_title']) : '' ?></div></td>
        <td><b><?= num($a['amount']) ?></b></td>
        <td><?= num((int)$a['installments']) ?></td><td><?= num($a['installment_amount']) ?></td>
        <td><?= num($a['settled_amount']) ?></td>
        <td><?= num($a['remaining']) ?> <span class="muted small">(<?= num((int)$a['remaining_installments']) ?> قسط)</span></td>
        <td><span class="muted small"><?= e($a['cash_title'] ?? '—') ?></span></td>
        <td><span class="pill" style="<?= $a['status'] === 'open' ? 'background:#FDF0DC;color:#B45309' : ($a['status'] === 'settled' ? 'background:#E7F7EF;color:#047857' : '') ?>"><?= e(Payroll::ADVANCE_STATUS[$a['status']] ?? $a['status']) ?></span></td>
        <td><?php if (Auth::can('payroll.edit') && $a['status'] === 'open'): ?>
          <form method="post" action="<?= url('app/payroll/advances/' . (int)$a['id'] . '/cancel') ?>" style="display:inline"
                onsubmit="return confirm('این مساعده لغو شود و سند آن برگشت خورد؟')"><?= csrf_field() ?>
            <button class="btn sm ghost" style="color:#E11D48" type="submit">لغو</button></form>
        <?php endif; ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
