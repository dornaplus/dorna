<?= view('partials/head', ['title' => $title]) ?>
<?php
$cur = Auth::currency(); $row = $row ?? [];
$val = fn(string $k, $d = '') => old($k, $row[$k] ?? $d);
$money = fn(string $k) => num((float)old($k, $row[$k] ?? 0));
$jd = fn(string $k) => !empty(old($k, $row[$k] ?? '')) ? jdate((string)old($k, $row[$k] ?? '')) : '';
$empData = [];
foreach ($employees as $e) {
    $s = Database::one('SELECT * FROM employee_salary_settings WHERE employee_id=?', [(int)$e['id']]) ?: [];
    $empData[(int)$e['id']] = ['job' => (string)($e['job_title'] ?? ''), 'ws' => (int)($e['workshop_id'] ?? 0),
        'base' => (float)($s['base_salary'] ?? 0), 'housing' => (float)($s['housing_allowance'] ?? 0),
        'food' => (float)($s['food_allowance'] ?? 0), 'child' => (float)($s['child_allowance'] ?? 0),
        'other' => (float)($s['other_allowances'] ?? 0), 'ie' => (float)($s['insurance_rate_employee'] ?? 7),
        'ir' => (float)($s['insurance_rate_employer'] ?? 23)];
}
?>
<form method="post" action="<?= url(!empty($row['id']) ? 'app/payroll/contracts/' . (int)$row['id'] . '/edit' : 'app/payroll/contracts') ?>">
  <?= csrf_field() ?>
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">قرارداد مبنای «تنظیمات حقوق» پرسنل است؛ با تأیید گزینهٔ پایین، عوامل آن روی پروندهٔ حقوق اعمال می‌شود.</div></div>
    <div style="display:flex;gap:8px">
      <a class="btn ghost" href="<?= url('app/payroll/contracts') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ذخیرهٔ قرارداد</button></div>
  </div>

  <div class="grid-2b" style="margin-top:14px;align-items:start">
    <div class="card">
      <div class="card-head"><h3>طرفین و مشخصات قرارداد</h3></div>
      <div class="card-body">
        <div class="grid-2b">
          <div class="field"><label>شماره قرارداد</label><input class="inp" name="contract_no" value="<?= e($val('contract_no', $nextNo)) ?>" dir="ltr"></div>
          <div class="field"><label>تاریخ امضا</label><input class="inp jalali" name="signed_date" value="<?= e($jd('signed_date')) ?>" data-value="<?= e((string)old('signed_date', $row['signed_date'] ?? '')) ?>"></div>
        </div>
        <div class="field"><label>پرسنل *</label>
          <select class="inp select-search" name="employee_id" id="ctEmp" required>
            <option value="">— انتخاب پرسنل —</option>
            <?php foreach ($employees as $e): ?>
              <option value="<?= (int)$e['id'] ?>" <?= (string)old('employee_id', $row['employee_id'] ?? '') === (string)$e['id'] ? 'selected' : '' ?>>
                <?= e($e['code'] . ' — ' . $e['full_name'] . ($e['job_title'] ? ' (' . $e['job_title'] . ')' : '')) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="help" id="ctHint">با انتخاب پرسنل، عوامل حقوق فعلی او در فرم بارگذاری می‌شود.</div></div>
        <div class="grid-2b">
          <div class="field"><label>عنوان قرارداد</label><input class="inp" name="title" value="<?= e($val('title')) ?>" placeholder="مثال: قرارداد کار مدت معین یک‌ساله"></div>
          <div class="field"><label>عنوان شغل در قرارداد</label><input class="inp" name="job_title" id="ctJob" value="<?= e($val('job_title')) ?>"></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>نوع قرارداد *</label><select class="inp" name="contract_type" id="ctType">
            <?php foreach (Payroll::CONTRACT_TYPES as $k => $v): ?><option value="<?= $k ?>" <?= (string)old('contract_type', $row['contract_type'] ?? 'fixed_term') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
          </select></div>
          <div class="field"><label>وضعیت</label><select class="inp" name="status">
            <?php foreach (Payroll::CONTRACT_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= (string)old('status', $row['status'] ?? 'draft') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
          </select></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>شروع قرارداد *</label><input class="inp jalali" name="start_date" required value="<?= e($jd('start_date') ?: jdate(today())) ?>" data-value="<?= e((string)old('start_date', $row['start_date'] ?? today())) ?>"></div>
          <div class="field"><label>پایان قرارداد</label><input class="inp jalali" name="end_date" value="<?= e($jd('end_date')) ?>" data-value="<?= e((string)old('end_date', $row['end_date'] ?? '')) ?>">
            <div class="help">برای قرارداد رسمی/کارمزدی اختیاری است؛ برای مدت معین الزامی.</div></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>کارگاه / محل خدمت</label><select class="inp select-search" name="workshop_id" id="ctWs"><option value="">— بدون کارگاه —</option>
            <?php foreach ($workshops as $w): ?><option value="<?= (int)$w['id'] ?>" <?= (string)old('workshop_id', $row['workshop_id'] ?? '') === (string)$w['id'] ? 'selected' : '' ?>><?= e($w['code'] . ' — ' . $w['title']) ?></option><?php endforeach; ?>
          </select></div>
          <div class="field"><label>مدت آزمایشی (ماه)</label><input class="inp" name="trial_months" value="<?= e($val('trial_months', '0')) ?>" inputmode="numeric"></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>ساعت کاری ماهانه</label><input class="inp" name="work_hours_monthly" value="<?= e($val('work_hours_monthly', '176')) ?>" inputmode="decimal"></div>
          <div class="field"><label>روز کاری ماهانه</label><input class="inp" name="work_days_monthly" value="<?= e($val('work_days_monthly', '26')) ?>" inputmode="decimal"></div>
        </div>
        <div class="field"><label>مرخصی استحقاقی سالانه (روز)</label><input class="inp" name="paid_leave_days" value="<?= e($val('paid_leave_days', '26')) ?>" inputmode="numeric"></div>
        <div class="field"><label>متن قرارداد (قالب چاپ)</label>
          <select class="inp" name="template_id">
            <option value="">— متن پیش‌فرض —</option>
            <?php foreach (($templates ?? []) as $t): ?>
              <option value="<?= (int)$t['id'] ?>" <?= (string)old('template_id', $row['template_id'] ?? ($t['is_default'] ?? 0 ? $t['id'] : '')) === (string)$t['id'] ? 'selected' : '' ?>><?= e($t['title']) ?><?= !empty($t['is_default']) ? ' (پیش‌فرض)' : '' ?></option>
            <?php endforeach; ?>
          </select>
          <div class="help">متن‌های قرارداد در <a href="<?= url('app/settings/hr?tab=templates') ?>" target="_blank" rel="noopener">تنظیمات حقوق ← متن قرارداد</a> قابل ویرایش‌اند.</div></div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h3>عوامل حقوق قرارداد</h3><div class="grow"></div><span class="pill">واحد: <?= e($cur) ?></span></div>
      <div class="card-body">
        <div class="field"><label>حقوق پایهٔ ماهانه *</label><input class="inp money" name="base_salary" id="ctBase" value="<?= e($money('base_salary')) ?>" required></div>
        <div class="grid-2b">
          <div class="field"><label>حق مسکن</label><input class="inp money" name="housing_allowance" id="ctHousing" value="<?= e($money('housing_allowance')) ?>"></div>
          <div class="field"><label>حق بن (خواربار)</label><input class="inp money" name="food_allowance" id="ctFood" value="<?= e($money('food_allowance')) ?>"></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>حق اولاد</label><input class="inp money" name="child_allowance" id="ctChild" value="<?= e($money('child_allowance')) ?>"></div>
          <div class="field"><label>سایر مزایا</label><input class="inp money" name="other_allowances" id="ctOther" value="<?= e($money('other_allowances')) ?>"></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>بیمهٔ سهم کارمند (٪)</label><input class="inp" name="insurance_rate_employee" id="ctIE" value="<?= e(num((float)old('insurance_rate_employee', $row['insurance_rate_employee'] ?? 7), 2)) ?>"></div>
          <div class="field"><label>بیمهٔ سهم کارفرما (٪)</label><input class="inp" name="insurance_rate_employer" id="ctIR" value="<?= e(num((float)old('insurance_rate_employer', $row['insurance_rate_employer'] ?? 23), 2)) ?>"></div>
        </div>
        <div class="field" style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;padding:10px">
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" name="apply_to_salary" value="1" style="width:auto"
                   <?= (int)old('apply_to_salary', $row['apply_to_salary'] ?? 1) ? 'checked' : '' ?>>
            <span>عوامل این قرارداد در «تنظیمات حقوق» پرسنل اعمال شود</span></label>
          <div class="help">با فعال‌بودن، حقوق پایه، مزایا و نرخ‌های بیمهٔ پروندهٔ پرسنل با این قرارداد به‌روزرسانی می‌شود.</div>
        </div>
        <div class="field"><label>شرایط و ضوابط</label><textarea class="inp wide" name="terms" rows="4"><?= e((string)old('terms', $row['terms'] ?? '')) ?></textarea></div>
        <div class="field"><label>یادداشت</label><input class="inp" name="note" value="<?= e($val('note')) ?>"></div>
      </div>
    </div>
  </div>

  <div style="display:flex;gap:8px;margin-top:12px">
    <button class="btn btn-p" type="submit">ذخیرهٔ قرارداد</button>
    <a class="btn ghost" href="<?= url('app/payroll/contracts') ?>">انصراف</a>
  </div>
</form>
<script>
(function () {
  function num(v) { return Number(String(v == null ? '' : v).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[^\d.-]/g, '')) || 0; }
  function fa(n) { return String(Math.round(n)).replace(/\d/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[d]; }).replace(/\B(?=(\d{3})+(?!\d))/g, '٬'); }
  var EMP = <?= json_encode($empData, JSON_UNESCAPED_UNICODE) ?>;
  var emp = document.getElementById('ctEmp'), hint = document.getElementById('ctHint');
  if (emp) emp.addEventListener('change', function () {
    var d = EMP[emp.value]; if (!d) { if (hint) hint.textContent = ''; return; }
    var g = document.getElementById('ctJob'); if (g && !g.value) g.value = d.job;
    var w = document.getElementById('ctWs'); if (w && !w.value && d.ws) w.value = String(d.ws);
    var set = function (id, v) { var el = document.getElementById(id); if (el) el.value = fa(v); };
    set('ctBase', d.base); set('ctHousing', d.housing); set('ctFood', d.food); set('ctChild', d.child); set('ctOther', d.other);
    set('ctIE', d.ie); set('ctIR', d.ir);
    if (hint) hint.textContent = 'عوامل فعلی پروندهٔ حقوق بارگذاری شد — قابل ویرایش است.';
  });
})();
</script>
<?= view('partials/foot') ?>
