<?php
/** نمایش و چاپ متن قرارداد (رندرشده از قالب تنظیمات حقوق) */
$rendered = $rendered ?? ['body' => '', 'template' => null];
$tplTitle = (string)($rendered['template']['title'] ?? 'متن پیش‌فرض');
?>
<?php if (!empty($print)): ?>
<!doctype html><html dir="rtl" lang="fa"><head><meta charset="utf-8"><title><?= e($title) ?></title>
<link rel="stylesheet" href="<?= asset('theme.css') ?>">
<style>body{background:#fff;padding:22px;font-family:var(--font2)}.sheet{max-width:900px;margin:0 auto}
.doc{white-space:pre-wrap;line-height:2.05;font-size:14px;text-align:justify}.hdr{display:flex;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:6px;margin-bottom:14px}</style>
</head><body>
<div class="sheet">
  <div class="hdr"><div><b><?= e($biz['name'] ?? '') ?></b><?php if (!empty($biz['address'])): ?><div class="muted small"><?= e($biz['address']) ?></div><?php endif; ?></div>
    <div class="muted small">قرارداد کار شماره <?= e(fa_digits((string)$c['contract_no'])) ?> — <?= e(jdate($c['start_date'])) ?></div></div>
  <div class="doc"><?= e((string)$rendered['body']) ?></div>
  <?php if (!empty($c['terms'])): ?>
    <div style="margin-top:18px;border-top:1px dashed #999;padding-top:10px">
      <b>شرایط و ضوابط توافقی:</b>
      <div class="doc" style="margin-top:6px"><?= e((string)$c['terms']) ?></div>
    </div>
  <?php endif; ?>
</div>
<script>window.print && window.print();</script></body></html>
<?php else: ?>
<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">قرارداد کار <?= e(fa_digits((string)$c['contract_no'])) ?></h1>
    <div class="muted small"><?= e($c['full_name']) ?> · <?= e(Payroll::CONTRACT_TYPES[$c['contract_type']] ?? '') ?>
      · <span class="pill"><?= e(Payroll::CONTRACT_STATUS[$c['status']] ?? '') ?></span>
      · قالب: <b><?= e($tplTitle) ?></b></div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="btn ghost" href="<?= url('app/payroll/contracts') ?>">بازگشت</a>
    <?php if (Auth::can('payroll.create')): ?><a class="btn" href="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/edit') ?>">ویرایش</a><?php endif; ?>
    <a class="btn" target="_blank" rel="noopener" href="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/print') ?>">چاپ</a>
    <?php if (Auth::can('payroll.edit')): ?>
      <form method="post" action="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/apply') ?>" style="display:inline"><?= csrf_field() ?>
        <button class="btn btn-p" type="submit">اعمال در تنظیمات حقوق</button></form>
    <?php endif; ?>
    <a class="btn ghost" href="<?= url('app/settings/hr?tab=templates') ?>">ویرایش متن قرارداد</a>
  </div>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3><?= e($biz['name'] ?? 'کارفرما') ?></h3><div class="grow"></div>
    <span class="pill">شماره <?= e(fa_digits((string)$c['contract_no'])) ?></span>
    <span class="pill"><?= e(jdate($c['start_date'])) ?><?= !empty($c['end_date']) ? ' تا ' . e(jdate($c['end_date'])) : '' ?></span></div>
  <div class="card-body" style="white-space:pre-wrap;line-height:2.05;text-align:justify"><?= e((string)$rendered['body']) ?></div>
  <?php if (!empty($c['terms'])): ?>
    <div class="card-body" style="border-top:1px dashed #cbd5e1">
      <div class="section-title">شرایط و ضوابط توافقی این قرارداد</div>
      <div style="white-space:pre-wrap;line-height:2"><?= e((string)$c['terms']) ?></div>
    </div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
<?php endif; ?>
