<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">قراردادهای کار</h1>
    <div class="muted small">قرارداد پرسنل، عوامل حقوق و مدت اعتبار — مبنای سند حقوق و تنظیمات حقوق هر پرسنل.</div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="btn ghost" href="<?= url('app/settings/hr') ?>">تنظیمات حقوق</a>
    <?php if (Auth::can('payroll.create')): ?><a class="btn btn-p" href="<?= url('app/payroll/contracts/create') ?>">+ ثبت قرارداد جدید</a><?php endif; ?>
  </div>
</div>

<div class="kpis" style="margin-top:14px">
  <div class="kpi card"><div class="dot">◈</div><div class="t">کل قراردادها</div><div class="v"><?= num($stats['total']) ?></div><div class="u">ثبت‌شده</div></div>
  <div class="kpi card green"><div class="dot">✓</div><div class="t">قرارداد جاری</div><div class="v"><?= num($stats['active']) ?></div><div class="u">در اعتبار</div></div>
  <div class="kpi card gold"><div class="dot">◷</div><div class="t">نزدیک به پایان</div><div class="v"><?= num(count($expiring)) ?></div><div class="u">تا ۶۰ روز آینده</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">پایان‌یافته / فسخ</div><div class="v"><?= num($stats['expired'] + $stats['terminated']) ?></div><div class="u"><?= num($stats['draft']) ?> پیش‌نویس</div></div>
</div>

<?php if ($expiring): ?>
<div class="card" style="margin-top:14px;border-color:#FCD34D">
  <div class="card-head"><h3>⚠️ قراردادهای نزدیک به پایان</h3><div class="grow"></div><span class="pill">تا ۶۰ روز</span></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>پرسنل</th><th>شماره</th><th>پایان</th><th>روز باقی‌مانده</th><th></th></tr></thead>
    <tbody><?php foreach ($expiring as $e): ?>
      <tr><td><?= e($e['full_name']) ?></td><td><?= e(fa_digits((string)$e['contract_no'])) ?></td>
        <td><?= e(jdate($e['end_date'])) ?></td><td><b><?= num((int)$e['days_to_end']) ?></b> روز</td>
        <td><a class="btn sm ghost" href="<?= url('app/payroll/contracts/' . (int)$e['id']) ?>">مشاهده</a></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<form method="get" class="filters" style="margin-top:14px">
  <div class="field" style="flex:1;min-width:170px"><label>جست‌وجو</label><input class="inp" name="q" value="<?= e($f['q']) ?>" placeholder="شماره قرارداد یا نام پرسنل"></div>
  <div class="field"><label>پرسنل</label><select class="inp select-search" name="employee_id"><option value="">همه</option>
    <?php foreach ($employees as $e): ?><option value="<?= (int)$e['id'] ?>" <?= (int)$f['employee_id'] === (int)$e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>نوع قرارداد</label><select class="inp" name="contract_type"><option value="">همه</option>
    <?php foreach (Payroll::CONTRACT_TYPES as $k => $v): ?><option value="<?= $k ?>" <?= $f['contract_type'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>وضعیت</label><select class="inp" name="status"><option value="">همه</option>
    <?php foreach (Payroll::CONTRACT_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="card">
  <div class="card-head"><h3>فهرست قراردادها</h3><div class="grow"></div><span class="pill"><?= num(count($rows)) ?> قرارداد</span></div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'قراردادی ثبت نشده است.', 'actionUrl' => Auth::can('payroll.create') ? url('app/payroll/contracts/create') : '', 'actionText' => '+ ثبت قرارداد جدید']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>پرسنل</th><th>نوع</th><th>عنوان شغل</th><th>کارگاه</th><th>شروع</th><th>پایان</th><th>حقوق پایه</th><th>جمع مزایا</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $c): $st = (string)$c['status']; ?>
      <tr>
        <td><b><?= e(fa_digits((string)$c['contract_no'])) ?></b>
          <?php if (!empty($c['apply_to_salary'])): ?><div class="muted small">اعمال‌شده در حقوق</div><?php endif; ?></td>
        <td><a href="<?= url('app/employees/' . (int)$c['employee_id']) ?>"><?= e($c['full_name']) ?></a>
          <div class="muted small"><?= e($c['employee_code']) ?></div></td>
        <td><span class="pill"><?= e(Payroll::CONTRACT_TYPES[$c['contract_type']] ?? $c['contract_type']) ?></span></td>
        <td><span class="muted small"><?= e($c['job_title'] ?: '—') ?></span></td>
        <td><span class="muted small"><?= e($c['workshop_title'] ?? '—') ?></span></td>
        <td><span class="muted small"><?= e(jdate($c['start_date'])) ?></span></td>
        <td><span class="muted small"><?= e(!empty($c['end_date']) ? jdate($c['end_date']) : '—') ?></span>
          <?php if (!empty($c['end_date']) && (int)$c['days_to_end'] >= 0 && (int)$c['days_to_end'] <= 60): ?>
            <div class="muted small" style="color:#B45309"><?= num((int)$c['days_to_end']) ?> روز مانده</div><?php endif; ?></td>
        <td><b><?= num($c['base_salary']) ?></b></td>
        <td><?= num((float)$c['total_salary'] - (float)$c['base_salary']) ?></td>
        <td><span class="pill" style="<?= $st === 'active' ? 'background:#E7F7EF;color:#047857' : ($st === 'draft' ? 'background:#FDF0DC;color:#B45309' : '') ?>"><?= e(Payroll::CONTRACT_STATUS[$st] ?? $st) ?></span></td>
        <td style="white-space:nowrap">
          <a class="btn sm ghost" href="<?= url('app/payroll/contracts/' . (int)$c['id']) ?>">مشاهده</a>
          <?php if (Auth::can('payroll.create')): ?><a class="btn sm" href="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/edit') ?>">ویرایش</a><?php endif; ?>
          <?php if (Auth::can('payroll.edit')): ?>
            <form method="post" action="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/apply') ?>" style="display:inline"><?= csrf_field() ?>
              <button class="btn sm ghost" type="submit" title="اعمال عوامل قرارداد در تنظیمات حقوق پرسنل">اعمال در حقوق</button></form>
            <form method="post" action="<?= url('app/payroll/contracts/' . (int)$c['id'] . '/delete') ?>" style="display:inline"
                  onsubmit="return confirm('قرارداد <?= e($c['contract_no']) ?> حذف شود؟')"><?= csrf_field() ?>
              <button class="btn sm ghost" style="color:#E11D48" type="submit">حذف</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
