<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $m @var array $row @var array $salary @var array $cols */
$cur = Auth::currency();
$field = function (string $name, array $o = []) use ($row, $cols) {
    if (!isset($cols[$name])) return;
    $spec = Fields::spec('employees', $name, $cols[$name]);
    $val = old($name, $row[$name] ?? null);
    if (!empty($o['readonly'])) { echo '<div class="field" data-name="' . e($name) . '"><label>' . e($spec['label']) . '</label><input class="inp" value="' . e((string)$val) . '" readonly dir="ltr"></div>'; return; }
    echo Fields::render($spec, $val);
};
$money = function (string $name, string $label, $val, string $extra = '') use ($cur) {
    echo '<div class="field" data-name="' . e($name) . '"><label>' . e($label) . ($extra === 'req' ? ' <span class="req">*</span>' : '') . '</label>'
        . '<input class="inp money" name="' . e($name) . '" value="' . e(num((float)($val ?? 0), 0)) . '"><div class="help"></div></div>';
};
?>
<form method="post" action="<?= url($row ? 'app/employees/' . (int)$row['id'] : 'app/employees') ?>">
  <?= csrf_field() ?>
  <div class="page-head">
    <div>
      <h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">پروندهٔ کامل پرسنلی: هویتی، تماس، شغلی، بیمه، بانکی و مزایا — همه در یک صفحه.</div>
    </div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <a class="btn ghost" href="<?= url('app/employees') ?>">بازگشت به فهرست</a>
      <button class="btn btn-p" type="submit">ذخیرهٔ پرونده</button>
    </div>
  </div>

  <div class="grid-2b" style="margin-top:14px;align-items:start">
    <!-- ═══ هویتی ═══ -->
    <div class="card">
      <div class="card-head"><h3>اطلاعات هویتی</h3><div class="grow"></div><span class="pill">شناسنامه و مشخصات</span></div>
      <div class="card-body">
        <div class="grid-2b">
          <div class="field"><label>کد پرسنلی</label>
            <input class="inp" name="code" value="<?= e(old('code', $row['code'] ?? $nextCode)) ?>" dir="ltr"></div>
          <div class="field"><label>وضعیت پرونده</label>
            <select class="inp" name="status">
              <?php foreach (['active' => 'فعال', 'suspended' => 'معلق', 'terminated' => 'پایان همکاری', 'retired' => 'بازنشسته', 'inactive' => 'غیرفعال'] as $k => $v): ?>
                <option value="<?= $k ?>" <?= (string)old('status', $row['status'] ?? 'active') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
              <?php endforeach; ?>
            </select></div>
        </div>
        <div class="field"><label>نام و نام خانوادگی <span class="req">*</span></label>
          <input class="inp" name="full_name" value="<?= e(old('full_name', $row['full_name'] ?? '')) ?>" required></div>
        <div class="grid-2b">
          <?php $field('father_name'); $field('national_id'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('id_card_no'); $field('id_card_issue_place'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('birth_date'); $field('birth_place'); ?>
        </div>
        <div class="grid c3">
          <?php $field('gender'); $field('marital_status'); $field('children_count'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('military_status'); $field('education_level'); ?>
        </div>
        <div class="field"><label>رشتهٔ تحصیلی</label>
          <input class="inp" name="field_of_study" value="<?= e(old('field_of_study', $row['field_of_study'] ?? '')) ?>"></div>
      </div>
    </div>

    <!-- ═══ تماس ═══ -->
    <div class="card">
      <div class="card-head"><h3>تماس و نشانی</h3><div class="grow"></div><span class="pill">راه‌های ارتباطی</span></div>
      <div class="card-body">
        <div class="grid-2b">
          <?php $field('mobile'); $field('phone'); ?>
        </div>
        <?php $field('email'); ?>
        <div class="field"><label>نشانی</label><input class="inp" name="address" value="<?= e(old('address', $row['address'] ?? '')) ?>"></div>
        <div class="grid c3">
          <?php $field('province_id'); $field('city_id'); $field('postal_code'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('emergency_name'); $field('emergency_phone'); ?>
        </div>
      </div>
    </div>
  </div>

  <div class="grid-2b" style="margin-top:14px;align-items:start">
    <!-- ═══ شغلی ═══ -->
    <div class="card">
      <div class="card-head"><h3>اطلاعات شغلی</h3><div class="grow"></div><span class="pill">سمت، کارگاه و قرارداد</span></div>
      <div class="card-body">
        <div class="grid-2b">
          <?php $field('job_title'); $field('department'); ?>
        </div>
        <div class="grid-2b">
          <div class="field"><label>کارگاه محل خدمت</label>
            <select class="inp select-search" name="workshop_id" id="empWorkshop">
              <option value="">— بدون کارگاه —</option>
              <?php foreach ($workshops as $w): ?>
                <option value="<?= (int)$w['id'] ?>" <?= (string)old('workshop_id', $row['workshop_id'] ?? '') === (string)$w['id'] ? 'selected' : '' ?>>
                  <?= e($w['code'] . ' — ' . $w['title']) ?></option>
              <?php endforeach; ?>
            </select>
            <div class="help">با انتخاب کارگاه، پرسنل به‌طور خودکار به اعضای آن کارگاه هم افزوده می‌شود.</div>
          </div>
          <div class="field"><label>سمت در کارگاه</label>
            <input class="inp" name="workshop_role" value="<?= e((string)old('workshop_role', '')) ?>" placeholder="مثال: سرکارگر">
            <div class="help">برای گزارش‌های کارگاه و سند حقوق استفاده می‌شود.</div></div>
        </div>
        <div class="grid-2b">
          <?php $field('manager_employee_id'); $field('shift_title'); ?>
        </div>
        <div class="grid c3">
          <?php $field('employment_type'); $field('hire_date'); $field('contract_end_date'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('termination_date'); ?>
          <div class="field"><label>شخص متناظر در «اشخاص»</label>
            <select class="inp select-search" name="person_id">
              <option value="">— بدون اتصال —</option>
              <?php $curPerson = (int)old('person_id', $row['person_id'] ?? 0); ?>
              <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? '') . ' ' . ($p['company_name'] ?? '')); ?>
                <option value="<?= (int)$p['id'] ?>"
                  <?= $curPerson === (int)$p['id'] ? 'selected' : '' ?>
                  <?= (!empty($p['has_file']) && $curPerson !== (int)$p['id']) ? 'disabled' : '' ?>>
                  <?= e(trim(($p['code'] ?? '') . ' — ' . $nm) . ($p['mobile'] ? ' · ' . $p['mobile'] : '') . (!empty($p['has_file']) && $curPerson !== (int)$p['id'] ? ' (دارای پرونده)' : '')) ?>
                </option>
              <?php endforeach; ?>
            </select>
            <div class="help">فقط اشخاص <b>حقیقی</b> بدون پروندهٔ پرسنلی قابل انتخاب‌اند؛ مشخصات پایه از همین شخص خوانده می‌شود.</div>
          </div>
        </div>
        <label class="switch-row" style="display:flex;align-items:center;gap:8px;margin-top:6px">
          <input type="checkbox" name="is_active" value="1" <?= (int)old('is_active', $row['is_active'] ?? 1) ? 'checked' : '' ?>
                 style="width:auto"><span>پروندهٔ فعال است (در سند حقوق و فهرست‌ها نمایش داده شود)</span>
        </label>
      </div>
    </div>

    <!-- ═══ بیمه و بانک ═══ -->
    <div class="card">
      <div class="card-head"><h3>بیمه، مالیات و بانک</h3><div class="grow"></div><span class="pill">اطلاعات پرداخت</span></div>
      <div class="card-body">
        <div class="grid-2b">
          <?php $field('insurance_no'); $field('insurance_start_date'); ?>
        </div>
        <div class="field"><label>شماره پروندهٔ مالیاتی</label>
          <input class="inp" name="tax_file_no" value="<?= e(old('tax_file_no', $row['tax_file_no'] ?? '')) ?>" dir="ltr"></div>
        <div class="grid-2b">
          <?php $field('bank_name'); $field('account_no'); ?>
        </div>
        <div class="grid-2b">
          <?php $field('iban'); $field('card_no'); ?>
        </div>
        <div class="field"><label>ملاحظات</label>
          <input class="inp" name="note" value="<?= e(old('note', $row['note'] ?? '')) ?>"></div>
      </div>
    </div>
  </div>

  <!-- ═══ حقوق و مزایا ═══ -->
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>حقوق و مزایا</h3><div class="grow"></div>
      <span class="pill">مبنای محاسبهٔ سند حقوق</span>
      <span class="pill">واحد: <?= e($cur) ?></span></div>
    <div class="card-body">
      <div class="grid c3">
        <?php $money('base_salary', 'حقوق پایهٔ ماهانه', old('base_salary', $salary['base_salary'] ?? 0), 'req'); ?>
        <?php $money('housing_allowance', 'حق مسکن', old('housing_allowance', $salary['housing_allowance'] ?? 0)); ?>
        <?php $money('food_allowance', 'حق بن (خواربار)', old('food_allowance', $salary['food_allowance'] ?? 0)); ?>
      </div>
      <div class="grid c3">
        <?php $money('child_allowance', 'حق اولاد', old('child_allowance', $salary['child_allowance'] ?? 0)); ?>
        <?php $money('other_allowances', 'سایر مزایا', old('other_allowances', $salary['other_allowances'] ?? 0)); ?>
        <?php $money('tax_exemption_amount', 'مبلغ معافیت مالیاتی', old('tax_exemption_amount', $salary['tax_exemption_amount'] ?? 0)); ?>
      </div>
      <div class="grid c4">
        <div class="field"><label>نرخ بیمهٔ کارمند (٪)</label>
          <input class="inp" name="insurance_rate_employee" inputmode="decimal"
                 value="<?= e(num((float)old('insurance_rate_employee', $salary['insurance_rate_employee'] ?? 7), 2)) ?>"></div>
        <div class="field"><label>نرخ بیمهٔ کارفرما (٪)</label>
          <input class="inp" name="insurance_rate_employer" inputmode="decimal"
                 value="<?= e(num((float)old('insurance_rate_employer', $salary['insurance_rate_employer'] ?? 23), 2)) ?>"></div>
        <div class="field"><label>حساب پرداخت حقوق</label>
          <select class="inp" name="cash_account_id"><option value="">— —</option>
            <?php foreach ($cashAccounts as $c): ?>
              <option value="<?= (int)$c['id'] ?>" <?= (string)old('cash_account_id', $salary['cash_account_id'] ?? '') === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="field"><label>روش پرداخت</label>
          <select class="inp" name="payment_method_id"><option value="">— —</option>
            <?php foreach ($paymentMethods as $pm): ?>
              <option value="<?= (int)$pm['id'] ?>" <?= (string)old('payment_method_id', $salary['payment_method_id'] ?? '') === (string)$pm['id'] ? 'selected' : '' ?>><?= e($pm['title']) ?></option>
            <?php endforeach; ?>
          </select></div>
      </div>
      <div class="field" style="max-width:260px"><label>اعتبار تنظیمات حقوق از تاریخ</label>
        <input class="inp jalali" name="salary_effective_from"
               value="<?= e(!empty($salary['effective_from']) ? jdate($salary['effective_from']) : jdate(today())) ?>"
               data-value="<?= e($salary['effective_from'] ?? today()) ?>"></div>
    </div>
  </div>

  <div style="display:flex;gap:8px;margin-top:12px">
    <button class="btn btn-p" type="submit">ذخیرهٔ پرونده</button>
    <a class="btn ghost" href="<?= url('app/employees') ?>">انصراف</a>
  </div>
</form>
<?= view('partials/foot') ?>
