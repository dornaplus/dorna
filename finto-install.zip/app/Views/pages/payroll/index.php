<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">حقوق و دستمزد</h1>
    <div class="muted small">کارگاه‌ها، سندهای حقوق، مساعده و وام کارکنان</div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="btn ghost" href="<?= url('app/payroll/workshops') ?>"><?= icon('box') ?> کارگاه‌ها</a>
    <a class="btn ghost" href="<?= url('app/payroll/contracts') ?>">قراردادها<?= !empty($contractStats['total']) ? ' (' . num($contractStats['active']) . ')' : '' ?></a>
    <?php if (Auth::can('payroll.create')): ?>
      <a class="btn" href="<?= url('app/payroll/advances/create') ?>">مساعده</a>
      <a class="btn" href="<?= url('app/payroll/loans/create') ?>">وام</a>
      <a class="btn btn-p" href="<?= url('app/payroll-documents/create') ?>"><?= icon('coins') ?> ثبت سند حقوق</a>
    <?php endif; ?>
  </div>
</div>

<form method="get" class="filters" style="margin-top:12px">
  <div class="field"><label>از تاریخ</label><input class="inp jalali" name="from" value="<?= e($from) ?>"></div>
  <div class="field"><label>تا تاریخ</label><input class="inp jalali" name="to" value="<?= e($to) ?>"></div>
  <div class="field"><label>کارگاه</label><select class="inp" name="workshop_id"><option value="">همه</option>
    <?php foreach ($workshops as $w): ?><option value="<?= (int)$w['id'] ?>" <?= $workshopId == $w['id'] ? 'selected' : '' ?>><?= e($w['code'] . ' — ' . $w['title']) ?></option><?php endforeach; ?>
  </select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="kpis" style="margin-top:14px">
  <div class="kpi card"><div class="dot">◈</div><div class="t">جمع حقوق ناخالص</div><div class="v"><?= num($stats['gross']) ?></div><div class="u"><?= num($stats['docs']) ?> سند · <?= num($stats['employees']) ?> پرسنل</div></div>
  <div class="kpi card green"><div class="dot">↑</div><div class="t">خالص پرداختی</div><div class="v"><?= num($stats['net']) ?></div><div class="u">پس از کسورات</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">بیمه + مالیات</div><div class="v"><?= num($stats['insurance_employee'] + $stats['tax']) ?></div><div class="u">سهم کارمند</div></div>
  <div class="kpi card gold"><div class="dot">◷</div><div class="t">مساعده و وام باز</div><div class="v"><?= num($stats['advance_open_amount'] + $stats['loan_open_amount']) ?></div><div class="u"><?= num($stats['advance_open_count'] + $stats['loan_open_count']) ?> پرونده</div></div>
</div>

<div class="grid c3" style="margin-top:14px">
  <div class="card" style="grid-column:span 2">
    <div class="card-head"><h3>هزینهٔ حقوق به تفکیک کارگاه</h3><div class="grow"></div>
      <span class="pill"><?= num($stats['workshops']) ?> کارگاه فعال</span></div>
    <?php if (!$byWorkshop): ?><div class="card-body muted small">در این بازه سند حقوقی ثبت نشده است.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>کارگاه</th><th>سندها</th><th>ردیف پرسنل</th><th>ناخالص</th><th>خالص</th><th></th></tr></thead>
      <tbody><?php foreach ($byWorkshop as $r): ?>
        <tr><td><?= e($r['title']) ?></td><td><?= num((int)$r['docs']) ?></td><td><?= num((int)$r['emp_lines']) ?></td>
          <td><b><?= num($r['gross']) ?></b></td><td><?= num($r['net']) ?></td>
          <td><a class="btn sm ghost" href="<?= url('app/payroll/report?from=' . urlencode($from) . '&to=' . urlencode($to)) ?>">گزارش</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>مساعده‌های باز</h3><div class="grow"></div><a class="btn sm ghost" href="<?= url('app/payroll/advances?status=open') ?>">همه</a></div>
    <?php if (!$advances): ?><div class="card-body muted small">مساعدهٔ بازی نیست.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>پرسنل</th><th>مانده</th><th>اقساط</th></tr></thead>
      <tbody><?php foreach ($advances as $a): ?>
        <tr><td><?= e($a['full_name']) ?><div class="muted small"><?= e($a['doc_no']) ?></div></td>
          <td><b><?= num($a['remaining']) ?></b></td><td><?= num((int)$a['remaining_installments']) ?> قسط</td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>

<?php if (!empty($expiringContracts)): ?>
<div class="card" style="margin-top:14px;border-color:#FCD34D">
  <div class="card-head"><h3>⚠️ قراردادهای نزدیک به پایان</h3><div class="grow"></div>
    <span class="pill"><?= num(count($expiringContracts)) ?> مورد تا ۶۰ روز</span>
    <a class="btn sm ghost" href="<?= url('app/payroll/contracts') ?>">فهرست قراردادها</a></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>پرسنل</th><th>شماره قرارداد</th><th>پایان</th><th>روز مانده</th><th></th></tr></thead>
    <tbody><?php foreach ($expiringContracts as $ct): ?>
      <tr><td><?= e($ct['full_name']) ?></td><td><?= e(fa_digits((string)$ct['contract_no'])) ?></td>
        <td><?= e(jdate($ct['end_date'])) ?></td><td><b><?= num((int)$ct['days_to_end']) ?></b></td>
        <td><a class="btn sm ghost" href="<?= url('app/payroll/contracts/' . (int)$ct['id']) ?>">مشاهده</a></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<div class="grid-2b" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>وام‌های در جریان</h3><div class="grow"></div><a class="btn sm ghost" href="<?= url('app/payroll/loans') ?>">همه</a></div>
    <?php if (!$loans): ?><div class="card-body muted small">وام در جریانی نیست.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>پرسنل</th><th>شماره</th><th>مانده</th><th>اقساط باقی</th></tr></thead>
      <tbody><?php foreach ($loans as $l): ?>
        <tr><td><?= e($l['full_name']) ?></td><td><span class="muted small" dir="ltr"><?= e(fa_digits((string)$l['loan_no'])) ?></span></td>
          <td><b><?= num($l['remaining']) ?></b></td><td><?= num((int)$l['remaining_installments']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>آخرین اسناد حقوق</h3><div class="grow"></div><a class="btn sm ghost" href="<?= url('app/payroll-documents') ?>">همهٔ اسناد</a></div>
    <?php if (!$docs): ?><div class="card-body muted small">سندی در این بازه نیست.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>شماره</th><th>دوره</th><th>کارگاه</th><th>خالص</th><th>وضعیت</th></tr></thead>
      <tbody><?php foreach ($docs as $d): ?>
        <tr><td><a href="<?= url('app/payroll-documents/' . (int)$d['id']) ?>"><b><?= e(fa_digits((string)$d['doc_no'])) ?></b></a></td>
          <td><?= e((string)$d['period_title']) ?></td><td><span class="muted small"><?= e($d['workshop_title'] ?? '—') ?></span></td>
          <td><?= num($d['net_amount']) ?></td><td><?= e(Meta::enumLabel((string)$d['status'])) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/foot') ?>
