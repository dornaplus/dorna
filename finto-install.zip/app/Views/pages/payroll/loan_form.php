<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<form method="post" action="<?= url('app/payroll/loans') ?>">
  <?= csrf_field() ?>
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">مبلغ وام پرداخت می‌شود و اقساط آن به‌صورت خودکار از سندهای حقوق کسر می‌گردد.</div></div>
    <div style="display:flex;gap:8px"><a class="btn ghost" href="<?= url('app/payroll/loans') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ثبت وام و صدور سند</button></div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>اطلاعات وام</h3></div>
    <div class="card-body">
      <div class="grid-2b">
        <div class="field"><label>پرسنل *</label>
          <select class="inp" name="employee_id" id="lnEmp" required><option value="">— انتخاب —</option>
            <?php foreach ($employees as $e): $o = $outstanding[(int)$e['id']] ?? ['advance'=>0,'loan'=>0]; ?>
              <option value="<?= (int)$e['id'] ?>" data-adv="<?= (float)$o['advance'] ?>" data-loan="<?= (float)$o['loan'] ?>"><?= e($e['code'] . ' — ' . $e['full_name']) ?></option>
            <?php endforeach; ?>
          </select>
          <div class="help" id="lnOut"></div></div>
        <div class="field"><label>تاریخ وام *</label><input class="inp jalali" name="loan_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>مبلغ وام (<?= e($cur) ?>) *</label><input class="inp money" name="amount" id="lnAmount" value="0" required></div>
        <div class="field"><label>تعداد قسط *</label><input class="inp" name="installments" id="lnInst" value="1" inputmode="numeric" required>
          <div class="help" id="lnPer"></div></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>حساب پرداخت *</label><select class="inp" name="cash_account_id" required><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['title'] . ' (' . num($c['current_balance']) . ')') ?></option><?php endforeach; ?></select></div>
        <div class="field"><label>ضامن (اختیاری)</label><select class="inp" name="guarantor_person_id"><option value="">— —</option>
          <?php foreach ($persons as $pp): ?><option value="<?= (int)$pp['id'] ?>"><?= e(trim($pp['code'] . ' ' . ($pp['first_name'] ?? '') . ' ' . ($pp['last_name'] ?? '') . ' ' . ($pp['company_name'] ?? ''))) ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="field"><label>علت وام</label><input class="inp" name="purpose" placeholder="مثال: کمک‌هزینهٔ درمان"></div>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-p" type="submit">ثبت</button>
    <a class="btn ghost" href="<?= url('app/payroll/loans') ?>">انصراف</a></div>
</form>
<script>
(function () {
  function num(v) { return Number(String(v == null ? '' : v).replace(/[۰-۹]/g, function (c) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(c); }).replace(/[^\d.-]/g, '')) || 0; }
  var emp = document.getElementById('lnEmp'), amt = document.getElementById('lnAmount'), inst = document.getElementById('lnInst');
  var out = document.getElementById('lnOut'), per = document.getElementById('lnPer');
  function upd() {
    var o = emp.options[emp.selectedIndex]; var l = o ? num(o.getAttribute('data-loan')) : 0;
    out.textContent = l > 0 ? 'ماندهٔ وام فعلی این پرسنل: ' + l.toLocaleString('fa-IR') : '';
    var n = Math.max(1, num(inst.value));
    per.textContent = 'هر قسط: ' + Math.round(num(amt.value) / n).toLocaleString('fa-IR');
  }
  [emp, amt, inst].forEach(function (el) { if (el) { el.addEventListener('input', upd); el.addEventListener('change', upd); } });
  upd();
})();
</script>
<?= view('partials/foot') ?>
