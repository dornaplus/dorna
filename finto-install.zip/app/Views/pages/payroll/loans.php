<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">وام‌ها</h1>
    <div class="muted small">وام کارکنان با اقساط؛ هر قسط از سند حقوق کسر می‌شود.</div></div>
  <?php if (Auth::can('payroll.create')): ?><a class="btn btn-p" href="<?= url('app/payroll/loans/create') ?>">+ ثبت وام</a><?php endif; ?>
</div>
<form method="get" class="filters" style="margin-top:12px">
  <div class="field" style="flex:1;min-width:170px"><label>جست‌وجو</label><input class="inp" name="q" value="<?= e($f['q']) ?>"></div>
  <div class="field"><label>پرسنل</label><select class="inp" name="employee_id"><option value="">همه</option>
    <?php foreach ($employees as $e): ?><option value="<?= (int)$e['id'] ?>" <?= (int)$f['employee_id'] === (int)$e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>وضعیت</label><select class="inp" name="status"><option value="">همه</option>
    <?php foreach (Payroll::LOAN_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>
<div class="card">
  <div class="card-head"><h3>فهرست وام‌ها</h3><div class="grow"></div>
    <span class="pill">جمع: <?= num($sum['amount']) ?></span>
    <span class="pill">کسرشده: <?= num($sum['paid']) ?></span>
    <span class="pill">مانده: <?= num($sum['remaining']) ?></span></div>
  <?php if (!$rows): ?><?= view('partials/empty', ['message' => 'وامی ثبت نشده است.']) ?><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>تاریخ</th><th>پرسنل</th><th>مبلغ</th><th>اقساط</th><th>قسط</th><th>کسرشده</th><th>مانده</th><th>ضامن</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $l): ?>
      <tr><td><b dir="ltr"><?= e(fa_digits((string)$l['loan_no'])) ?></b></td><td><span class="muted small"><?= e(jdate($l['loan_date'])) ?></span></td>
        <td><?= e($l['full_name']) ?><div class="muted small"><?= e($l['employee_code']) ?></div></td>
        <td><b><?= num($l['amount']) ?></b></td><td><?= num((int)$l['installments']) ?></td><td><?= num($l['installment_amount']) ?></td>
        <td><?= num($l['paid_amount']) ?></td>
        <td><?= num($l['remaining']) ?> <span class="muted small">(<?= num((int)$l['remaining_installments']) ?> قسط)</span></td>
        <td><span class="muted small"><?= e($l['guarantor_name'] ?: '—') ?></span></td>
        <td><span class="pill" style="<?= $l['status'] === 'active' ? 'background:#E0F2FE;color:#0369A1' : ($l['status'] === 'settled' ? 'background:#E7F7EF;color:#047857' : '') ?>"><?= e(Payroll::LOAN_STATUS[$l['status']] ?? $l['status']) ?></span></td>
        <td><?php if (Auth::can('payroll.edit') && $l['status'] === 'active'): ?>
          <form method="post" action="<?= url('app/payroll/loans/' . (int)$l['id'] . '/cancel') ?>" style="display:inline"
                onsubmit="return confirm('این وام لغو شود و سند آن برگشت خورد؟')"><?= csrf_field() ?>
            <button class="btn sm ghost" style="color:#E11D48" type="submit">لغو</button></form>
        <?php endif; ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
