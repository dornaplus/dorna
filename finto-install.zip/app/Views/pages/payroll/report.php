<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">گزارش جامع حقوق</h1>
    <div class="muted small">از <?= e(jdate($gregFrom)) ?> تا <?= e(jdate($gregTo)) ?> · <?= num(count($rows)) ?> ردیف</div></div>
  <div style="display:flex;gap:8px">
    <a class="btn ghost" href="<?= url('app/payroll/report?' . http_build_query(array_filter(['from' => $_GET['from'] ?? null, 'to' => $_GET['to'] ?? null, 'workshop_id' => $workshopId ?: null, 'employee_id' => $employeeId ?: null, 'export' => 'csv']))) ?>">خروجی CSV</a>
    <a class="btn ghost" href="javascript:window.print()">چاپ</a>
  </div>
</div>

<form method="get" class="filters" style="margin-top:12px">
  <div class="field"><label>از تاریخ</label><input class="inp jalali" name="from" value="<?= e($from) ?>"></div>
  <div class="field"><label>تا تاریخ</label><input class="inp jalali" name="to" value="<?= e($to) ?>"></div>
  <div class="field"><label>کارگاه</label><select class="inp" name="workshop_id"><option value="">همه</option>
    <?php foreach ($workshops as $w): ?><option value="<?= (int)$w['id'] ?>" <?= $workshopId == $w['id'] ? 'selected' : '' ?>><?= e($w['code'] . ' — ' . $w['title']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>پرسنل</label><select class="inp" name="employee_id"><option value="">همه</option>
    <?php foreach ($employees as $e): ?><option value="<?= (int)$e['id'] ?>" <?= $employeeId == $e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="kpis" style="margin-top:14px">
  <div class="kpi card"><div class="dot">◈</div><div class="t">حقوق ناخالص</div><div class="v"><?= num($tot['gross']) ?></div><div class="u"><?= num(count($rows)) ?> ردیف حقوق</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">کسورات</div><div class="v"><?= num($tot['ded']) ?></div><div class="u">بیمه، مالیات و سایر</div></div>
  <div class="kpi card gold"><div class="dot">◷</div><div class="t">مساعده + قسط وام</div><div class="v"><?= num($tot['adv'] + $tot['loan']) ?></div><div class="u">مساعده <?= num($tot['adv']) ?> · وام <?= num($tot['loan']) ?></div></div>
  <div class="kpi card green"><div class="dot">↑</div><div class="t">خالص پرداختی</div><div class="v"><?= num($tot['net']) ?></div><div class="u">جمع ستون خالص</div></div>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>ریز حقوق پرسنل</h3><div class="grow"></div>
    <span class="pill">بیمهٔ سهم کارمند: <?= num($stats['insurance_employee']) ?></span>
    <span class="pill">بیمهٔ سهم کارفرما: <?= num($stats['insurance_employer']) ?></span>
    <span class="pill">مالیات: <?= num($stats['tax']) ?></span></div>
  <?php if (!$rows): ?><?= view('partials/empty', ['message' => 'در این بازه سند حقوقی ثبت نشده است.']) ?><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>تاریخ</th><th>سند</th><th>دوره</th><th>کارگاه</th><th>پرسنل</th><th>سمت</th><th>روز</th><th>ناخالص</th><th>کسورات</th><th>مساعده</th><th>قسط وام</th><th>خالص</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?>
      <tr><td><span class="muted small"><?= e(jdate($r['doc_date'])) ?></span></td>
        <td><a href="<?= url('app/payroll-documents/' . (int)Database::val('SELECT id FROM payroll_documents WHERE doc_no=? AND business_id=?', [$r['doc_no'], Auth::businessId()], 0)) ?>"><?= e(fa_digits((string)$r['doc_no'])) ?></a></td>
        <td><?= e((string)$r['period_title']) ?></td>
        <td><span class="muted small"><?= e($r['workshop_title'] ?? '—') ?></span></td>
        <td><?= e($r['full_name']) ?></td><td><span class="muted small"><?= e($r['job_title'] ?: '—') ?></span></td>
        <td><?= num((float)$r['worked_days'], 1) ?></td>
        <td><?= num($r['gross_amount']) ?></td>
        <td><?= num($r['deductions_amount']) ?></td>
        <td><?= (float)$r['advance_amount'] > 0 ? num($r['advance_amount']) : '—' ?></td>
        <td><?= (float)$r['loan_amount'] > 0 ? num($r['loan_amount']) : '—' ?></td>
        <td><b><?= num($r['net_amount']) ?></b></td></tr>
    <?php endforeach; ?></tbody>
    <tfoot><tr><th colspan="7">جمع کل</th><th><?= num($tot['gross']) ?></th><th><?= num($tot['ded']) ?></th>
      <th><?= num($tot['adv']) ?></th><th><?= num($tot['loan']) ?></th><th><?= num($tot['net']) ?></th></tr></tfoot>
  </table></div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>خلاصه به تفکیک کارگاه</h3></div>
  <?php if (!$byWorkshop): ?><div class="card-body muted small">داده‌ای نیست.</div><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>کارگاه</th><th>تعداد سند</th><th>ردیف پرسنل</th><th>ناخالص</th><th>خالص</th></tr></thead>
    <tbody><?php foreach ($byWorkshop as $b): ?>
      <tr><td><?= e($b['title']) ?></td><td><?= num((int)$b['docs']) ?></td><td><?= num((int)$b['emp_lines']) ?></td>
        <td><?= num($b['gross']) ?></td><td><b><?= num($b['net']) ?></b></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
