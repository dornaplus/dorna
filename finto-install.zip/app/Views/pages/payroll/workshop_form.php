<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= url('app/payroll/workshops') ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">کارگاه مبنای تخصیص دستمزد و گزارش‌گیری است.</div></div>
    <div style="display:flex;gap:8px"><a class="btn ghost" href="<?= url('app/payroll/workshops') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ذخیره</button></div>
  </div>
  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>مشخصات کارگاه</h3></div>
    <div class="card-body">
      <div class="grid-2b">
        <div class="field"><label>کد کارگاه</label><input class="inp" name="code" value="<?= e($row['code'] ?? $nextCode) ?>" dir="ltr" <?= !empty($row) ? 'readonly' : '' ?>></div>
        <div class="field"><label>نام کارگاه *</label><input class="inp" name="title" value="<?= e($row['title'] ?? '') ?>" placeholder="مثال: کارگاه ساختمانی شمال" required></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>نوع کارگاه</label><select class="inp" name="workshop_type">
          <?php foreach (Payroll::WORKSHOP_TYPES as $k => $v): ?><option value="<?= $k ?>" <?= ($row['workshop_type'] ?? 'project') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
        </select></div>
        <div class="field"><label>وضعیت</label><select class="inp" name="status">
          <?php foreach (Payroll::WORKSHOP_STATUS as $k => $v): ?><option value="<?= $k ?>" <?= ($row['status'] ?? 'active') === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?>
        </select></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>مسئول کارگاه (کاربر)</label><select class="inp" name="manager_user_id"><option value="">— —</option>
          <?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>" <?= (int)($row['manager_user_id'] ?? 0) === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option><?php endforeach; ?>
        </select></div>
        <div class="field"><label>مسئول کارگاه (شخص)</label><select class="inp" name="manager_person_id"><option value="">— —</option>
          <?php foreach ($persons as $pp): ?><option value="<?= (int)$pp['id'] ?>" <?= (int)($row['manager_person_id'] ?? 0) === (int)$pp['id'] ? 'selected' : '' ?>><?= e(trim($pp['code'] . ' ' . ($pp['first_name'] ?? '') . ' ' . ($pp['last_name'] ?? '') . ' ' . ($pp['company_name'] ?? ''))) ?></option><?php endforeach; ?>
        </select></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>شروع</label><input class="inp jalali" name="start_date" data-value="<?= e($row['start_date'] ?? '') ?>" value="<?= e(!empty($row['start_date']) ? jdate($row['start_date']) : '') ?>"></div>
        <div class="field"><label>پایان</label><input class="inp jalali" name="end_date" data-value="<?= e($row['end_date'] ?? '') ?>" value="<?= e(!empty($row['end_date']) ? jdate($row['end_date']) : '') ?>"></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>مرکز هزینه</label><select class="inp" name="cost_center_id"><option value="">— —</option>
          <?php foreach ($costCenters as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)($row['cost_center_id'] ?? 0) === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['name']) ?></option><?php endforeach; ?>
        </select></div>
        <div class="field"><label>بودجهٔ دستمزد (<?= e(Auth::currency()) ?>)</label><input class="inp money" name="budget_amount" value="<?= num((float)($row['budget_amount'] ?? 0), 0) ?>"></div>
      </div>
      <div class="field"><label>نشانی</label><input class="inp" name="address" value="<?= e($row['address'] ?? '') ?>"></div>
      <div class="field"><label>یادداشت</label><input class="inp" name="note" value="<?= e($row['note'] ?? '') ?>"></div>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px"><button class="btn btn-p" type="submit">ذخیره</button>
    <a class="btn ghost" href="<?= url('app/payroll/workshops') ?>">انصراف</a></div>
</form>
<?= view('partials/foot') ?>
