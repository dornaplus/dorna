<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">کارگاه <?= e($w['title']) ?></h1>
    <div class="muted small">کد <?= e($w['code']) ?> · <?= e(Payroll::WORKSHOP_TYPES[$w['workshop_type']] ?? '') ?>
      · <span class="pill"><?= e(Payroll::WORKSHOP_STATUS[$w['status']] ?? '') ?></span></div></div>
  <div style="display:flex;gap:8px">
    <a class="btn ghost" href="<?= url('app/payroll/workshops') ?>">بازگشت</a>
    <?php if (Auth::can('payroll.edit')): ?><a class="btn" href="<?= url('app/payroll/workshops/' . (int)$w['id'] . '/edit') ?>">ویرایش</a><?php endif; ?>
    <?php if (Auth::can('payroll.create')): ?><a class="btn btn-p" href="<?= url('app/payroll-documents/create?workshop_id=' . (int)$w['id']) ?>">ثبت سند حقوق این کارگاه</a><?php endif; ?>
  </div>
</div>

<div class="grid-2b" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>اطلاعات کارگاه</h3></div>
    <div class="card-body"><table class="tbl" style="background:transparent">
      <tr><th style="width:150px">مسئول (کاربر)</th><td><?= e($w['manager_user_name'] ?: '—') ?></td></tr>
      <tr><th>مسئول (شخص)</th><td><?= e(trim((string)$w['manager_person_name']) ?: '—') ?></td></tr>
      <tr><th>مرکز هزینه</th><td><?= e($w['cost_center_name'] ?? '—') ?></td></tr>
      <tr><th>بودجهٔ دستمزد</th><td><?= (float)$w['budget_amount'] > 0 ? num($w['budget_amount']) . ' ' . e($cur) : '—' ?></td></tr>
      <tr><th>بازه</th><td><?= e(!empty($w['start_date']) ? jdate($w['start_date']) : '—') ?> تا <?= e(!empty($w['end_date']) ? jdate($w['end_date']) : '—') ?></td></tr>
      <tr><th>نشانی</th><td><?= e($w['address'] ?: '—') ?></td></tr>
      <?php if (!empty($w['note'])): ?><tr><th>یادداشت</th><td><?= e($w['note']) ?></td></tr><?php endif; ?>
    </table></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>افزودن پرسنل به کارگاه</h3></div>
    <?php if (!Auth::can('payroll.edit')): ?>
      <div class="card-body muted small">برای افزودن پرسنل، مجوز ویرایش حقوق لازم است.</div>
    <?php else: ?>
    <form method="post" action="<?= url('app/payroll/workshops/' . (int)$w['id'] . '/employee') ?>" class="card-body">
      <?= csrf_field() ?>
      <div class="field"><label>پرسنل *</label><select class="inp" name="employee_id" required><option value="">— انتخاب —</option>
        <?php foreach ($employees as $e): ?><option value="<?= (int)$e['id'] ?>"><?= e($e['code'] . ' — ' . $e['full_name'] . ($e['job_title'] ? ' (' . $e['job_title'] . ')' : '')) ?></option><?php endforeach; ?>
      </select></div>
      <div class="grid-2b">
        <div class="field"><label>سمت در کارگاه</label><input class="inp" name="role_title" placeholder="مثال: سرکارگر"></div>
        <div class="field"><label>دستمزد روزانه (<?= e($cur) ?>)</label><input class="inp money" name="daily_wage" value="0"></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>از تاریخ</label><input class="inp jalali" name="from_date"></div>
        <div class="field"><label>تا تاریخ</label><input class="inp jalali" name="to_date"></div>
      </div>
      <button class="btn btn-p" type="submit">افزودن به کارگاه</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>پرسنل کارگاه</h3><div class="grow"></div><span class="pill"><?= num(count($w['employees'])) ?> نفر</span></div>
  <?php if (!$w['employees']): ?><div class="card-body muted small">هنوز پرسنلی به این کارگاه اضافه نشده است.</div><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>کد</th><th>نام</th><th>سمت</th><th>دپارتمان</th><th>سمت در کارگاه</th><th>دستمزد روزانه</th><th>بازه</th><th></th></tr></thead>
    <tbody><?php foreach ($w['employees'] as $e): ?>
      <tr><td><?= e($e['employee_code']) ?></td><td><?= e($e['full_name']) ?></td>
        <td><span class="muted small"><?= e($e['job_title'] ?: '—') ?></span></td>
        <td><span class="muted small"><?= e($e['department'] ?: '—') ?></span></td>
        <td><?= e($e['role_title'] ?: '—') ?></td>
        <td><?= (float)$e['daily_wage'] > 0 ? num($e['daily_wage']) : '—' ?></td>
        <td><span class="muted small"><?= e(!empty($e['from_date']) ? jdate($e['from_date']) : '—') ?> تا <?= e(!empty($e['to_date']) ? jdate($e['to_date']) : '—') ?></span></td>
        <td><?php if (Auth::can('payroll.edit')): ?>
          <form method="post" action="<?= url('app/payroll/workshop-member/' . (int)$e['id'] . '/delete') ?>" style="display:inline"
                onsubmit="return confirm('این پرسنل از کارگاه حذف شود؟')"><?= csrf_field() ?>
            <input type="hidden" name="workshop_id" value="<?= (int)$w['id'] ?>">
            <button class="btn sm ghost" style="color:#E11D48" type="submit">حذف</button></form>
        <?php endif; ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>سندهای حقوق این کارگاه</h3><div class="grow"></div><span class="pill"><?= num(count($docs)) ?> سند</span></div>
  <?php if (!$docs): ?><div class="card-body muted small">سندی برای این کارگاه ثبت نشده است.</div><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>دوره</th><th>تاریخ</th><th>پرسنل</th><th>ناخالص</th><th>خالص</th><th>وضعیت</th></tr></thead>
    <tbody><?php foreach ($docs as $d): ?>
      <tr><td><a href="<?= url('app/payroll-documents/' . (int)$d['id']) ?>"><?= e(fa_digits((string)$d['doc_no'])) ?></a></td>
        <td><?= e((string)$d['period_title']) ?></td><td><?= e(jdate($d['doc_date'])) ?></td>
        <td><?= num((int)$d['employee_count']) ?></td><td><?= num($d['gross_amount']) ?></td><td><b><?= num($d['net_amount']) ?></b></td>
        <td><?= e(Meta::enumLabel((string)$d['status'])) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
