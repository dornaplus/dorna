<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">کارگاه‌ها</h1>
    <div class="muted small">محل‌ها/پروژه‌هایی که پرسنل در آن‌ها کار می‌کنند و حقوق به آن‌ها تخصیص می‌یابد.</div></div>
  <?php if (Auth::can('payroll.edit')): ?><a class="btn btn-p" href="<?= url('app/payroll/workshops/create') ?>">+ تعریف کارگاه</a><?php endif; ?>
</div>
<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>فهرست کارگاه‌ها</h3><div class="grow"></div><span class="pill"><?= num(count($rows)) ?> کارگاه</span></div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'کارگاهی ثبت نشده است.', 'actionUrl' => Auth::can('payroll.edit') ? url('app/payroll/workshops/create') : '', 'actionText' => '+ تعریف کارگاه']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>کد</th><th>نام کارگاه</th><th>نوع</th><th>مسئول</th><th>مرکز هزینه</th><th>پرسنل</th><th>هزینهٔ حقوق</th><th>بودجه</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $w): ?>
      <tr>
        <td><b><?= e($w['code']) ?></b></td>
        <td><a href="<?= url('app/payroll/workshops/' . (int)$w['id']) ?>"><?= e($w['title']) ?></a>
          <?php if (!empty($w['address'])): ?><div class="muted small"><?= e($w['address']) ?></div><?php endif; ?></td>
        <td><?= e(Payroll::WORKSHOP_TYPES[$w['workshop_type']] ?? $w['workshop_type']) ?></td>
        <td><?= e($w['manager_user_name'] ?: (trim((string)$w['manager_person_name']) ?: '—')) ?></td>
        <td><span class="muted small"><?= e($w['cost_center_name'] ?? '—') ?></span></td>
        <td><?= num((int)$w['employees_count']) ?> نفر</td>
        <td><b><?= num($w['paid_total']) ?></b></td>
        <td><span class="muted small"><?= (float)$w['budget_amount'] > 0 ? num($w['budget_amount']) : '—' ?></span></td>
        <td><?php $st = (string)$w['status']; ?>
          <span class="pill" style="<?= $st === 'active' ? 'background:#E7F7EF;color:#047857' : '' ?>"><?= e(Payroll::WORKSHOP_STATUS[$st] ?? $st) ?></span></td>
        <td style="white-space:nowrap">
          <a class="btn sm ghost" href="<?= url('app/payroll/workshops/' . (int)$w['id']) ?>">پرسنل</a>
          <?php if (Auth::can('payroll.edit')): ?>
            <a class="btn sm" href="<?= url('app/payroll/workshops/' . (int)$w['id'] . '/edit') ?>">ویرایش</a>
            <form method="post" action="<?= url('app/payroll/workshops/' . (int)$w['id'] . '/delete') ?>" style="display:inline"
                  onsubmit="return confirm('کارگاه «<?= e($w['title']) ?>» حذف شود؟')"><?= csrf_field() ?>
              <button class="btn sm ghost" style="color:#E11D48" type="submit">حذف</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
