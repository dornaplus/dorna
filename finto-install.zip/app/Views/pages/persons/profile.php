<?= view('partials/head', ['title' => $title]) ?>
<?php
$pid = (int)$person['id'];
$kind = $person['person_kind'] ?? 'haqiqi';
$credit = (float)($fin['credit_limit_amount'] ?? 0);
$debtor = $balance > 0;   // بدهکار (طلب ما از او)
?>
<div class="pp-head card">
  <div class="pp-ident">
    <div class="pp-avatar"><?= e(mb_substr(trim($pname) ?: 'ش', 0, 1)) ?></div>
    <div class="pp-name">
      <div class="pp-name-row">
        <h2><?= e($pname) ?></h2>
        <?php foreach ($types as $t): ?><span class="pill st-active"><?= e($t['title_fa']) ?></span><?php endforeach; ?>
        <span class="muted small"><?= e($person['code']) ?> · <?= e(Meta::enumLabel($kind)) ?></span>
      </div>
      <div class="pp-contacts">
        <?php if (!empty($person['mobile'])): ?><span><?= icon('phone', 14) ?> <?= e($person['mobile']) ?></span><?php endif; ?>
        <?php if (!empty($person['phone'])): ?><span><?= icon('phone', 14) ?> <?= e($person['phone']) ?></span><?php endif; ?>
        <?php if (!empty($person['email'])): ?><span><?= icon('mail', 14) ?> <?= e($person['email']) ?></span><?php endif; ?>
        <?php if (!empty($person['marketer_id'])): ?><span class="muted">بازاریاب: <?= e((string)Database::val('SELECT full_name FROM marketers WHERE id=?', [$person['marketer_id']], '—')) ?></span><?php endif; ?>
      </div>
    </div>
  </div>
  <div class="pp-actions">
    <?php if (Auth::can('persons.edit')): ?><a class="btn soft" href="<?= url('app/persons/' . $pid . '/edit') ?>"><?= icon('edit', 15) ?> ویرایش</a><?php endif; ?>
    <?php if (Auth::can('invoices.create')): ?><a class="btn" href="<?= url('app/invoices/create?type=sale&person_id=' . $pid) ?>"><?= icon('plus', 15) ?> فاکتور فروش</a><?php endif; ?>
  </div>
</div>

<div class="pp-kpis">
  <div class="kpi <?= $debtor ? 'red' : 'green' ?>"><div class="dot"><?= icon('wallet', 20) ?></div>
    <div class="t">مانده حساب</div><div class="v"><?= num($balance) ?></div>
    <div class="u"><?= $debtor ? 'بدهکار به ما' : ($balance < 0 ? 'بستانکار' : 'تسویه') ?></div></div>
  <div class="kpi"><div class="dot"><?= icon('receipt', 20) ?></div>
    <div class="t">مجموع فروش</div><div class="v"><?= num($invStats['sales_total']) ?></div>
    <div class="u"><?= num($invStats['cnt']) ?> فاکتور</div></div>
  <div class="kpi"><div class="dot"><?= icon('coins', 20) ?></div>
    <div class="t">ماندهٔ فاکتورها</div><div class="v"><?= num($invStats['remaining']) ?></div>
    <div class="u">پرداخت‌نشده</div></div>
  <div class="kpi <?= $credit > 0 && $balance > $credit ? 'red' : '' ?>"><div class="dot"><?= icon('shield', 20) ?></div>
    <div class="t">سقف اعتبار</div><div class="v"><?= num($credit) ?></div>
    <div class="u"><?= !empty($fin['payment_term_id']) ? e((string)Database::val('SELECT title FROM payment_terms WHERE id=?', [$fin['payment_term_id']], '—')) : '—' ?></div></div>
</div>

<div class="pp-grid">
  <div class="pp-main">
    <div class="card">
      <div class="card-head"><h3><?= icon('spark', 16) ?> فعالیت‌ها و تایم‌لاین تعامل</h3><div class="grow"></div><span class="pill"><?= num(count($activities)) ?></span></div>

      <form method="post" action="<?= url('app/persons/' . $pid . '/activity') ?>" class="pp-act-form">
        <?= csrf_field() ?>
        <div class="pp-act-row">
          <select class="inp" name="activity_type" id="ppActType">
            <?php foreach ($actTypes as $k => $v): ?><option value="<?= e($k) ?>"><?= e($v[0]) ?></option><?php endforeach; ?>
          </select>
          <input class="inp" type="text" name="subject" placeholder="عنوان (مثلاً تماس دربارهٔ سفارش…)" maxlength="190">
          <input class="inp jalali" type="text" name="happened_at" value="<?= e(jdate(today())) ?>" title="تاریخ رخداد" data-value="<?= e(today()) ?>">
        </div>
        <div class="pp-act-row" id="ppDueRow" hidden>
          <span class="pp-due-lbl"><?= icon('clock', 14) ?> زمان پیگیری بعدی:</span>
          <input class="inp jalali" type="text" name="due_at" placeholder="مثلاً ۱۴۰۴/۰۷/۲۰" data-value="">
        </div>
        <textarea class="inp" name="body" rows="2" placeholder="شرح گفتگو، نتیجهٔ تماس یا یادداشت… (اختیاری)"></textarea>
        <div class="pp-act-foot"><button class="btn sm"><?= icon('check', 14) ?> ثبت فعالیت</button></div>
      </form>

      <div class="pp-timeline">
        <?php foreach ($activities as $a): $ty = (string)$a['activity_type']; ?>
          <div class="pp-tl">
            <span class="pp-tl-ic t-<?= e($ty) ?>"><?= icon(PersonActivity::iconName($ty), 16) ?></span>
            <div class="pp-tl-b">
              <div class="pp-tl-top">
                <b><?= e($a['subject']) ?></b>
                <span class="pill"><?= e(PersonActivity::label($ty)) ?></span>
                <?php if ($ty === 'followup'): ?>
                  <span class="pill <?= (int)$a['is_done'] ? 'st-done' : 'st-open' ?>"><?= (int)$a['is_done'] ? 'انجام‌شده' : 'در انتظار' ?></span>
                  <?php if (!empty($a['due_at'])): ?><span class="muted small"><?= icon('clock', 13) ?> <?= e(jdate($a['due_at'])) ?></span><?php endif; ?>
                <?php endif; ?>
                <div class="grow"></div>
                <span class="muted small"><?= e((string)($a['user_name'] ?? '—')) ?> · <?= e(jdate($a['happened_at'], '/', true)) ?></span>
              </div>
              <?php if (trim((string)$a['body']) !== ''): ?><p class="pp-tl-body"><?= nl2br(e($a['body'])) ?></p><?php endif; ?>
              <div class="pp-tl-acts">
                <?php if ($ty === 'followup'): ?>
                  <form method="post" action="<?= url('app/persons/' . $pid . '/activity/' . (int)$a['id'] . '/done') ?>" style="margin:0"><?= csrf_field() ?>
                    <button class="btn <?= (int)$a['is_done'] ? 'gray' : 'soft' ?> sm" type="submit"><?= icon('check', 13) ?> <?= (int)$a['is_done'] ? 'بازگردانی' : 'انجام شد' ?></button></form>
                <?php endif; ?>
                <form method="post" action="<?= url('app/persons/' . $pid . '/activity/' . (int)$a['id'] . '/delete') ?>" onsubmit="return confirm('این فعالیت حذف شود؟')" style="margin:0"><?= csrf_field() ?><button class="btn danger sm" type="submit"><?= icon('trash', 13) ?></button></form>
              </div>
            </div>
          </div>
        <?php endforeach; ?>
        <?php if (!$activities): ?><div class="pp-empty">هنوز فعالیتی ثبت نشده. اولین تماس، یادداشت یا پیگیری را ثبت کنید.</div><?php endif; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h3><?= icon('receipt', 16) ?> فاکتورهای اخیر</h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/invoices?person_id=' . $pid) ?>">همهٔ فاکتورها</a></div>
      <?php if (!$invoices): ?><div class="pp-empty">فاکتوری ثبت نشده است.</div><?php else: ?>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>شماره</th><th>تاریخ</th><th>نوع</th><th>مبلغ</th><th>پرداخت‌شده</th><th>مانده</th><th>وضعیت</th></tr></thead>
        <tbody><?php foreach ($invoices as $inv): ?>
          <tr><td><a href="<?= url('app/invoices/' . (int)$inv['id']) ?>"><b><?= e($inv['invoice_no']) ?></b></a></td>
            <td><?= e(jdate($inv['invoice_date'])) ?></td>
            <td><span class="muted small"><?= e(Meta::enumLabel($inv['invoice_type'])) ?></span></td>
            <td><?= num($inv['total_amount']) ?></td>
            <td><?= num($inv['paid_amount']) ?></td>
            <td><b class="<?= (float)$inv['remaining_amount'] > 0 ? 'danger' : 'ok' ?>"><?= num($inv['remaining_amount']) ?></b></td>
            <td><span class="pill st-<?= e($inv['settlement_status']) ?>"><?= e(Meta::enumLabel($inv['settlement_status'])) ?></span></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h3><?= icon('lifebuoy', 16) ?> تیکت‌های پشتیبانی</h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/tickets/create?person_id=' . $pid) ?>">تیکت جدید</a></div>
      <?php if (!$tickets): ?><div class="pp-empty">تیکتی برای این شخص ثبت نشده است.</div><?php else: ?>
      <div class="pp-tickets"><?php foreach ($tickets as $tk): ?>
        <a class="pp-ticket" href="<?= url('app/tickets/' . (int)$tk['id']) ?>">
          <span class="pill st-<?= e($tk['status']) ?>"><?= e(Meta::enumLabel($tk['status'])) ?></span>
          <b><?= e($tk['ticket_no']) ?> — <?= e($tk['subject']) ?></b>
          <span class="muted small"><?= e(Meta::enumLabel($tk['priority'])) ?> · <?= e(jdate($tk['created_at'], '/')) ?></span>
        </a>
      <?php endforeach; ?></div>
      <?php endif; ?>
    </div>
  </div>

  <div class="pp-side">
    <div class="card">
      <div class="card-head"><h3><?= icon('clock', 16) ?> پیگیری‌های باز</h3><div class="grow"></div><span class="pill <?= $followups ? 'st-open' : '' ?>"><?= num(count($followups)) ?></span></div>
      <?php if (!$followups): ?><div class="pp-empty">پیگیری بازی وجود ندارد.</div><?php else: ?>
      <div class="pp-followups"><?php foreach ($followups as $fu): ?>
        <div class="pp-fu">
          <div class="pp-fu-b"><b><?= e($fu['subject']) ?></b>
            <span class="muted small"><?= !empty($fu['due_at']) ? icon('clock', 12) . ' ' . e(jdate($fu['due_at'])) : '' ?><?= trim((string)$fu['body']) !== '' ? ' · ' . e(mb_strimwidth((string)$fu['body'], 0, 60, '…')) : '' ?></span></div>
          <form method="post" action="<?= url('app/persons/' . $pid . '/activity/' . (int)$fu['id'] . '/done') ?>" style="margin:0"><?= csrf_field() ?><button class="btn soft sm" type="submit"><?= icon('check', 13) ?> انجام شد</button></form>
        </div>
      <?php endforeach; ?></div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h3><?= icon('folder', 16) ?> اسناد و پیوست‌ها</h3><div class="grow"></div><span class="pill"><?= num(count($docs)) ?></span></div>
      <form method="post" action="<?= url('app/persons/' . $pid . '/docs') ?>" enctype="multipart/form-data" class="pp-doc-up">
        <?= csrf_field() ?><input type="file" name="file" required><button class="btn sm" type="submit"><?= icon('upload', 14) ?> پیوست</button>
      </form>
      <?php if (!$docs): ?><div class="pp-empty">سندی پیوست نشده است.</div><?php else: ?>
      <div class="pp-docs"><?php foreach ($docs as $doc): $durl = $doc['entity_type'] === 'person' ? url('app/persons/' . $pid . '/docs/' . (int)$doc['id'] . '/download') : url('app/invoices'); ?>
        <div class="pp-doc">
          <span class="pp-doc-ic"><?= icon('file', 16) ?></span>
          <div class="pp-doc-b"><b><?= e($doc['file_name']) ?></b><span class="muted small"><?= e((string)($doc['uploader_name'] ?? '—')) ?> · <?= num((int)round((int)$doc['size_bytes'] / 1024)) ?> کیلوبایت</span></div>
          <div class="pp-doc-acts">
            <?php if ($doc['entity_type'] === 'person'): ?>
              <a class="btn soft sm" href="<?= e($durl) ?>" target="_blank" rel="noopener"><?= icon('download', 13) ?></a>
              <form method="post" action="<?= url('app/persons/' . $pid . '/docs/' . (int)$doc['id'] . '/delete') ?>" onsubmit="return confirm('حذف شود؟')" style="margin:0"><?= csrf_field() ?><button class="btn danger sm"><?= icon('trash', 13) ?></button></form>
            <?php endif; ?>
          </div>
        </div>
      <?php endforeach; ?></div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-head"><h3><?= icon('bank', 16) ?> اطلاعات مالی و اعتباری</h3></div>
      <div class="pp-fin">
        <div><span>سقف اعتبار</span><b><?= num($credit) ?></b></div>
        <div><span>تخفیف پیش‌فرض</span><b><?= num((float)($fin['default_discount_percent'] ?? 0)) ?>٪</b></div>
        <div><span>شرط پرداخت</span><b><?= !empty($fin['payment_term_id']) ? e((string)Database::val('SELECT title FROM payment_terms WHERE id=?', [$fin['payment_term_id']], '—')) : '—' ?></b></div>
        <div><span>پیامک تشکر</span><b><?= !empty($fin['sms_thanks_enabled']) ? 'فعال' : 'غیرفعال' ?></b></div>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  var type = document.getElementById('ppActType'), due = document.getElementById('ppDueRow');
  if (type && due) {
    var sync = function () { due.hidden = type.value !== 'followup'; };
    type.addEventListener('change', sync); sync();
  }
})();
</script>
<?= view('partials/foot') ?>
