<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); $qs = function (array $extra = []) use ($f) { $q = array_filter([
    'fund_id' => $f['fund_id'] ?: null, 'type' => $f['type'] ?: null, 'status' => $f['status'] ?: null,
    'category_id' => $f['category_id'] ?: null, 'q' => $f['q'] ?: null,
    'from' => $_GET['from'] ?? null, 'to' => $_GET['to'] ?? null,
] + $extra, fn($v) => $v !== null && $v !== ''); return $q ? '?' . http_build_query($q) : ''; }; ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">اسناد تنخواه</h1>
    <div class="muted small"><?= num($total) ?> سند</div></div>
  <?php if (Auth::can('petty_cash.create')): ?>
    <div style="display:flex;gap:8px"><a class="btn" href="<?= url('app/petty-cash/create?type=charge') ?>">شارژ</a>
      <a class="btn btn-p" href="<?= url('app/petty-cash/create?type=expense') ?>">+ ثبت هزینه</a></div>
  <?php endif; ?>
</div>

<form method="get" class="filters" style="margin-top:12px">
  <div class="field" style="flex:1;min-width:180px"><label>جست‌وجو</label><input class="inp" name="q" value="<?= e($f['q']) ?>"></div>
  <div class="field"><label>تنخواه</label><select class="inp" name="fund_id"><option value="">همه</option>
    <?php foreach ($funds as $x): ?><option value="<?= (int)$x['id'] ?>" <?= (int)$f['fund_id'] === (int)$x['id'] ? 'selected' : '' ?>><?= e($x['code'] . ' — ' . $x['title']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>نوع</label><select class="inp" name="type"><option value="">همه</option>
    <?php foreach (PettyCash::TYPES as $k => $v): ?><option value="<?= $k ?>" <?= $f['type'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>وضعیت</label><select class="inp" name="status"><option value="">همه</option>
    <?php foreach (PettyCash::STATUSES as $k => $v): ?><option value="<?= $k ?>" <?= $f['status'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>مرکز هزینه</label><select class="inp" name="category_id"><option value="">همه</option>
    <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>" <?= (int)$f['category_id'] === (int)$c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>از تاریخ</label><input class="inp jalali" name="from" value="<?= e($_GET['from'] ?? '') ?>"></div>
  <div class="field"><label>تا تاریخ</label><input class="inp jalali" name="to" value="<?= e($_GET['to'] ?? '') ?>"></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="card">
  <div class="card-head"><h3>فهرست اسناد</h3><div class="grow"></div><span class="pill">صفحهٔ <?= num($page) ?></span></div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'سندی با این فیلترها یافت نشد.']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>تاریخ</th><th>نوع</th><th>تنخواه</th><th>بابت</th><th>مرکز هزینه</th><th>مبلغ</th><th>پیوست</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($rows as $e): ?>
      <tr>
        <td><a href="<?= url('app/petty-cash/' . (int)$e['id']) ?>"><b><?= e(fa_digits((string)$e['doc_no'])) ?></b></a></td>
        <td><span class="muted small"><?= e(jdate($e['doc_date'])) ?></span></td>
        <td><?= e(PettyCash::typeTitle((string)$e['entry_type'])) ?></td>
        <td><span class="muted small"><?= e($e['fund_code']) ?></span></td>
        <td><?= e($e['title']) ?><?php if (!empty($e['reference_no'])): ?><div class="muted small">فاکتور: <?= e(fa_digits((string)$e['reference_no'])) ?></div><?php endif; ?></td>
        <td><span class="muted small"><?= e($e['category_title'] ?? '—') ?></span></td>
        <td><b><?= num($e['amount']) ?></b></td>
        <td><?= (int)$e['attach_count'] > 0 ? '📎 ' . num((int)$e['attach_count']) : '—' ?></td>
        <td><span class="pill st-<?= e(PettyCash::STATUS_CLASS[$e['status']] ?? '') ?>"><?= e(PettyCash::statusTitle((string)$e['status'])) ?></span></td>
        <td><a class="btn sm ghost" href="<?= url('app/petty-cash/' . (int)$e['id']) ?>">مشاهده</a></td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php $pages = (int)ceil($total / $per); if ($pages > 1): ?>
    <div class="card-body" style="display:flex;gap:6px;flex-wrap:wrap">
      <?php for ($i = 1; $i <= min($pages, 20); $i++): ?>
        <a class="pill <?= $i === $page ? 'on' : '' ?>" href="<?= url('app/petty-cash/entries' . $qs(['page' => $i])) ?>"><?= num($i) ?></a>
      <?php endfor; ?>
    </div>
  <?php endif; ?>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
