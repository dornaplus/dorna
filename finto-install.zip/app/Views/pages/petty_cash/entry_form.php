<?= view('partials/head', ['title' => $title]) ?>
<?php
$cur = Auth::currency();
$isCharge = $type === 'charge';
$isSettle = $type === 'settle';
$isExpense = $type === 'expense';
$isRefund = $type === 'refund';
$needsCash = $isCharge || $isSettle;
$needsExpense = $isExpense || $isRefund;
?>
<form method="post" action="<?= url('app/petty-cash') ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <input type="hidden" name="entry_type" value="<?= e($type) ?>">
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">شمارهٔ بعدی: <b><?= e(fa_digits((string)$nextNo)) ?></b></div></div>
    <div style="display:flex;gap:8px"><a class="btn ghost" href="<?= url('app/petty-cash') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ثبت سند</button></div>
  </div>

  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>اطلاعات سند</h3>
      <div class="grow"></div>
      <span class="pill"><?= e(PettyCash::typeTitle($type)) ?></span></div>
    <div class="card-body">
      <?php if ($isCharge): ?><div class="help" style="margin-bottom:10px">وجه از حساب نقد/بانک برداشت و به تنخواه‌دار تخصیص داده می‌شود.</div><?php endif; ?>
      <?php if ($isSettle): ?><div class="help" style="margin-bottom:10px">ماندهٔ تنخواه به حساب نقد/بانک برگشت داده می‌شود.</div><?php endif; ?>
      <?php if ($isExpense): ?><div class="help" style="margin-bottom:10px">هزینه از تنخواه‌دار پرداخت شده و به حساب هزینه/مرکز هزینه ثبت می‌شود.</div><?php endif; ?>
      <?php if ($isRefund): ?><div class="help" style="margin-bottom:10px">وجهی به تنخواه برگشت داده می‌شود (کسر از هزینه).</div><?php endif; ?>

      <div class="grid-2b">
        <div class="field"><label>تنخواه *</label>
          <select class="inp" name="fund_id" required>
            <option value="">— انتخاب تنخواه —</option>
            <?php foreach ($funds as $f): ?>
              <option value="<?= (int)$f['id'] ?>" <?= (int)$fundId === (int)$f['id'] ? 'selected' : '' ?>>
                <?= e($f['code'] . ' — ' . $f['title'] . ' (مانده ' . num($f['balance']) . ')') ?></option>
            <?php endforeach; ?>
          </select>
          <?php if (!$funds): ?><div class="help" style="color:#E11D48">تنخواهی برای شما تعریف نشده است؛ ابتدا تنخواه بسازید.</div><?php endif; ?>
        </div>
        <div class="field"><label>تاریخ سند *</label><input class="inp jalali" type="text" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      </div>

      <div class="grid-2b">
        <div class="field"><label><?= $needsCash ? 'عنوان' : 'نام محصول / خدمت' ?> *</label>
          <input class="inp" name="title" placeholder="<?= $needsCash ? 'مثال: شارژ تنخواه انبار' : 'مثال: خرید نوشت‌افزار' ?>" required></div>
        <div class="field"><label>مبلغ (<?= e($cur) ?>) *</label><input class="inp money" type="text" name="amount" value="0" required></div>
      </div>

      <?php if ($needsCash): ?>
        <div class="grid-2b">
          <div class="field"><label><?= $isCharge ? 'از حساب (مبدأ) *' : 'به حساب (مقصد) *' ?></label>
            <select class="inp" name="cash_account_id" required><option value="">— انتخاب —</option>
              <?php foreach ($cashAccounts as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['title'] . ' (' . num($c['current_balance']) . ')') ?></option><?php endforeach; ?>
            </select></div>
          <div class="field"><label>شمارهٔ پیگیری/رسید</label><input class="inp" name="reference_no"></div>
        </div>
      <?php endif; ?>

      <?php if ($needsExpense): ?>
        <div class="grid-2b">
          <div class="field"><label>مرکز هزینه (دسته)</label>
            <select class="inp" name="category_id" id="pcCat"><option value="">— بدون مرکز هزینه —</option>
              <?php foreach ($categories as $c): ?><option value="<?= (int)$c['id'] ?>" data-acc="<?= (int)($c['default_account_id'] ?? 0) ?>"><?= e($c['title']) ?></option><?php endforeach; ?>
            </select></div>
          <div class="field"><label>حساب هزینه</label>
            <select class="inp" name="expense_account_id">
              <option value="">— پیش‌فرض مرکز هزینه —</option>
              <?php foreach ($accounts as $a): ?>
                <?php if ((int)$a['id'] === (int)$defaultExpense): ?>
                  <option value="<?= (int)$a['id'] ?>" selected><?= e($a['code'] . ' — ' . $a['title'] . ' (پیش‌فرض)') ?></option>
                <?php else: ?>
                  <option value="<?= (int)$a['id'] ?>"><?= e($a['code'] . ' — ' . $a['title']) ?></option>
                <?php endif; ?>
              <?php endforeach; ?>
            </select></div>
        </div>
        <div class="grid-2b">
          <div class="field"><label>طرف حساب (اختیاری)</label>
            <select class="inp" name="person_id"><option value="">— —</option>
              <?php foreach ($persons as $pp): ?><option value="<?= (int)$pp['id'] ?>"><?= e(trim($pp['code'] . ' ' . ($pp['first_name'] ?? '') . ' ' . ($pp['last_name'] ?? '') . ' ' . ($pp['company_name'] ?? ''))) ?></option><?php endforeach; ?>
            </select></div>
          <div class="field"><label>مرکز هزینه (تحلیل)</label>
            <select class="inp" name="cost_center_id"><option value="">— —</option>
              <?php foreach ($costCenters as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['name']) ?></option><?php endforeach; ?>
            </select></div>
        </div>
        <div class="field"><label>شمارهٔ فاکتور / رسید</label><input class="inp" name="reference_no"></div>
      <?php endif; ?>

      <div class="field"><label>توضیحات</label><input class="inp" name="description"></div>
      <div class="field"><label>پیوست (تصویر فاکتور/رسید — تا ۵ فایل، ۸ مگابایت)</label>
        <input class="inp" type="file" name="files[]" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt"></div>

      <?php if ($canApprove): ?>
        <div class="field" style="margin-top:6px">
          <label style="display:flex;align-items:center;gap:8px;font-weight:500">
            <input type="checkbox" name="auto_approve" value="1" checked> تأیید فوری و صدور سند حسابداری (شما مجوز تأیید دارید)
          </label>
        </div>
      <?php else: ?>
        <div class="help" style="margin-top:6px">سند شما پس از ثبت، برای تأیید مدیر ارسال می‌شود.</div>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px">
    <button class="btn btn-p" type="submit">ثبت سند</button>
    <a class="btn ghost" href="<?= url('app/petty-cash') ?>">انصراف</a>
  </div>
</form>
<script>
(function () {
  var cat = document.getElementById('pcCat');
  if (!cat) return;
  var acc = document.querySelector('[name=expense_account_id]');
  if (!acc) return;
  cat.addEventListener('change', function () {
    var a = cat.options[cat.selectedIndex] && cat.options[cat.selectedIndex].getAttribute('data-acc');
    if (a && a !== '0') acc.value = a;
  });
})();
</script>
<?= view('partials/foot') ?>
