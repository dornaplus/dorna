<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); $st = PettyCash::STATUS_CLASS[$e['status']] ?? ''; ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">سند تنخواه <span dir="ltr"><?= e(fa_digits((string)$e['doc_no'])) ?></span></h1>
    <div class="muted small"><?= e(PettyCash::typeTitle((string)$e['entry_type'])) ?> · <?= e(jdate($e['doc_date'])) ?>
      · <span class="pill st-<?= e($st) ?>"><?= e(PettyCash::statusTitle((string)$e['status'])) ?></span></div></div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="btn ghost" href="<?= url('app/petty-cash/entries') ?>">بازگشت</a>
    <?php if ($e['status'] === 'approved' && Auth::can('petty_cash.print')): ?>
      <a class="btn" href="<?= url('app/petty-cash/' . (int)$e['id'] . '/print') ?>" target="_blank"><?= icon('print') ?> چاپ</a>
    <?php endif; ?>
    <?php if ($e['status'] === 'pending' && Auth::can('petty_cash.approve')): ?>
      <form method="post" action="<?= url('app/petty-cash/' . (int)$e['id'] . '/approve') ?>" style="display:inline"><?= csrf_field() ?>
        <button class="btn btn-p" type="submit">تأیید و صدور سند</button></form>
      <form method="post" action="<?= url('app/petty-cash/' . (int)$e['id'] . '/reject') ?>" style="display:inline"><?= csrf_field() ?>
        <input type="hidden" name="reason" value="">
        <button class="btn ghost" style="color:#E11D48" type="submit" onclick="this.form.reason.value = prompt('دلیل رد سند؟') || 'رد شد';">رد سند</button></form>
    <?php endif; ?>
    <?php if (Auth::can('petty_cash.edit')): ?>
      <form method="post" action="<?= url('app/petty-cash/' . (int)$e['id'] . '/delete') ?>" style="display:inline"
            onsubmit="return confirm('این سند حذف شود؟ (سند حسابداری آن برگشت می‌خورد)')"><?= csrf_field() ?>
        <button class="btn ghost" style="color:#E11D48" type="submit">حذف</button></form>
    <?php endif; ?>
  </div>
</div>

<?php if ($e['status'] === 'rejected' && !empty($e['reject_reason'])): ?>
  <div class="alert error" style="margin-top:12px">دلیل رد سند: <b><?= e($e['reject_reason']) ?></b></div>
<?php endif; ?>

<div class="grid-2b" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>مشخصات سند</h3>
      <div class="grow"></div><span class="pill">مبلغ: <?= num($e['amount']) ?> <?= e($cur) ?></span></div>
    <div class="card-body">
      <table class="tbl" style="background:transparent">
        <tr><th style="width:170px">تنخواه</th><td><?= e($e['fund_code'] . ' — ' . $e['fund_title']) ?></td></tr>
        <tr><th>حساب کل تنخواه</th><td><?= e($e['gl_code'] . ' — ' . $e['gl_title']) ?></td></tr>
        <tr><th><?= $e['entry_type'] === 'charge' || $e['entry_type'] === 'settle' ? 'عنوان' : 'بابت' ?></th><td><?= e($e['title']) ?></td></tr>
        <tr><th>مبلغ</th><td><b><?= num($e['amount']) ?></b> <?= e($cur) ?></td></tr>
        <?php if (!empty($e['category_title'])): ?><tr><th>مرکز هزینه</th><td><?= e($e['category_title']) ?></td></tr><?php endif; ?>
        <?php if (!empty($e['cost_center_name'])): ?><tr><th>مرکز هزینه (تحلیل)</th><td><?= e($e['cost_center_name']) ?></td></tr><?php endif; ?>
        <?php if (!empty($e['expense_account_title'])): ?><tr><th>حساب هزینه</th><td><?= e($e['expense_account_code'] . ' — ' . $e['expense_account_title']) ?></td></tr><?php endif; ?>
        <?php if (!empty($e['cash_title'])): ?><tr><th>حساب نقد/بانک</th><td><?= e($e['cash_title']) ?></td></tr><?php endif; ?>
        <?php if (!empty($e['reference_no'])): ?><tr><th>شماره فاکتور/رسید</th><td dir="ltr"><?= e(fa_digits((string)$e['reference_no'])) ?></td></tr><?php endif; ?>
        <?php if (!empty($e['person_name']) || !empty($e['first_name'])): ?>
          <tr><th>طرف حساب</th><td><?= e(trim(($e['first_name'] ?? '') . ' ' . ($e['last_name'] ?? '') . ' ' . ($e['company_name'] ?? ''))) ?></td></tr>
        <?php endif; ?>
        <?php if (!empty($e['description'])): ?><tr><th>توضیحات</th><td><?= e($e['description']) ?></td></tr><?php endif; ?>
        <tr><th>ثبت‌کننده</th><td><?= e($e['creator_name'] ?? '—') ?></td></tr>
      </table>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>سند حسابداری</h3>
      <div class="grow"></div>
      <?php if ($je): ?><span class="pill" dir="ltr">#<?= e(fa_digits((string)$je['entry_no'])) ?></span><?php endif; ?></div>
    <?php if (!$je): ?>
      <div class="card-body muted small">هنوز سند حسابداری صادر نشده است<?= $e['status'] === 'pending' ? ' (در انتظار تأیید).' : '.' ?></div>
    <?php else: ?>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>حساب</th><th>شرح</th><th>بدهکار</th><th>بستانکار</th></tr></thead>
        <tbody><?php foreach ($jeLines as $l): ?>
          <tr><td><?= e($l['account_code'] . ' — ' . $l['account_title']) ?></td><td><span class="muted small"><?= e($l['description'] ?? '') ?></span></td>
            <td><?= (float)$l['debit_amount'] > 0 ? num($l['debit_amount']) : '—' ?></td>
            <td><?= (float)$l['credit_amount'] > 0 ? num($l['credit_amount']) : '—' ?></td></tr>
        <?php endforeach; ?></tbody>
        <tfoot><tr><th colspan="2">جمع</th><th><?= num($je['total_debit']) ?></th><th><?= num($je['total_credit']) ?></th></tr></tfoot>
      </table></div>
      <div class="card-body"><div class="muted small">وضعیت سند: <?= e(Meta::enumLabel((string)$je['status'])) ?> · تاریخ: <?= e(jdate($je['entry_date'])) ?></div></div>
    <?php endif; ?>
  </div>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>پیوست‌ها (تصویر فاکتور/رسید)</h3><div class="grow"></div>
    <span class="pill"><?= num(count($e['attachments'] ?? [])) ?> فایل</span></div>
  <?php if (empty($e['attachments'])): ?>
    <div class="card-body muted small">پیوستی برای این سند ثبت نشده است.</div>
  <?php else: ?>
    <div class="card-body" style="display:flex;gap:12px;flex-wrap:wrap">
      <?php foreach ($e['attachments'] as $a): $isImg = str_starts_with((string)$a['mime_type'], 'image/'); ?>
        <div style="border:1px solid var(--line);border-radius:14px;padding:8px;width:180px;text-align:center">
          <?php if ($isImg): ?>
            <a href="<?= url('app/petty-cash/attach/' . (int)$a['id']) ?>" target="_blank">
              <img src="<?= url('app/petty-cash/attach/' . (int)$a['id']) ?>" alt="" style="max-width:100%;max-height:120px;border-radius:10px"></a>
          <?php else: ?>
            <div style="font-size:34px">📄</div>
          <?php endif; ?>
          <div class="small" style="margin-top:6px;word-break:break-all"><?= e($a['file_name']) ?></div>
          <div class="muted small"><?= num(round((int)$a['size_bytes'] / 1024, 0)) ?> کیلوبایت</div>
          <a class="btn sm ghost" style="margin-top:6px" href="<?= url('app/petty-cash/attach/' . (int)$a['id'] . '?dl=1') ?>">دانلود</a>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
