<?= view('partials/head', ['title' => $title]) ?>
<form method="post" action="<?= url('app/petty-cash/funds') ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="id" value="<?= (int)($row['id'] ?? 0) ?>">
  <div class="page-head">
    <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
      <div class="muted small">حساب کل تنخواه بهتر است یک حساب فرعی زیر «تنخواه گردان» باشد.</div></div>
    <div style="display:flex;gap:8px"><a class="btn ghost" href="<?= url('app/petty-cash/funds') ?>">بازگشت</a>
      <button class="btn btn-p" type="submit">ذخیره</button></div>
  </div>

  <div class="card" style="margin-top:14px">
    <div class="card-head"><h3>مشخصات تنخواه</h3></div>
    <div class="card-body">
      <div class="grid-2b">
        <div class="field"><label>کد تنخواه</label><input class="inp" name="code" value="<?= e($row['code'] ?? $nextCode) ?>" dir="ltr" <?= !empty($row) ? 'readonly' : '' ?>></div>
        <div class="field"><label>عنوان تنخواه *</label><input class="inp" name="title" value="<?= e($row['title'] ?? '') ?>" placeholder="مثال: تنخواه انبار مرکزی" required></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>حساب کل تنخواه *</label>
          <select class="inp" name="gl_account_id" required>
            <option value="">— انتخاب حساب —</option>
            <?php foreach ($accounts as $a): ?>
              <option value="<?= (int)$a['id'] ?>" <?= (int)($row['gl_account_id'] ?? $defaultGl) === (int)$a['id'] ? 'selected' : '' ?>>
                <?= e($a['code'] . ' — ' . $a['title']) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="field"><label>تنخواه‌دار (کاربر سیستم)</label>
          <select class="inp" name="keeper_user_id"><option value="">— بدون تنخواه‌دار —</option>
            <?php foreach ($users as $u): ?><option value="<?= (int)$u['id'] ?>" <?= (int)($row['keeper_user_id'] ?? 0) === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>شخص مرتبط (اختیاری)</label>
          <select class="inp" name="person_id"><option value="">— —</option>
            <?php foreach ($persons as $pp): ?>
              <option value="<?= (int)$pp['id'] ?>" <?= (int)($row['person_id'] ?? 0) === (int)$pp['id'] ? 'selected' : '' ?>><?= e(trim($pp['code'] . ' ' . ($pp['first_name'] ?? '') . ' ' . ($pp['last_name'] ?? '') . ' ' . ($pp['company_name'] ?? ''))) ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="field"><label>وضعیت</label>
          <select class="inp" name="status">
            <?php foreach (['active' => 'فعال', 'suspended' => 'غیرفعال (ثبت سند متوقف)', 'closed' => 'بسته'] as $k => $v): ?>
              <option value="<?= $k ?>" <?= ($row['status'] ?? 'active') === $k ? 'selected' : '' ?>><?= e($v) ?></option>
            <?php endforeach; ?>
          </select></div>
      </div>
      <div class="grid-2b">
        <div class="field"><label>سقف تنخواه (<?= e(Auth::currency()) ?>)</label><input class="inp money" name="ceiling_amount" value="<?= num((float)($row['ceiling_amount'] ?? 0), 0) ?>"></div>
        <div class="field"><label>هشدار وقتی مانده کمتر از (<?= e(Auth::currency()) ?>)</label><input class="inp money" name="low_balance_amount" value="<?= num((float)($row['low_balance_amount'] ?? 0), 0) ?>"></div>
      </div>
      <div class="field"><label>یادداشت</label><input class="inp" name="note" value="<?= e($row['note'] ?? '') ?>"></div>
      <?php if (!empty($row)): ?>
        <div class="help">ماندهٔ فعلی: <b><?= num($row['balance'] ?? 0) ?></b> <?= e(Auth::currency()) ?> — این مانده از روی اسناد تأییدشده محاسبه می‌شود.</div>
      <?php endif; ?>
    </div>
  </div>
  <div style="display:flex;gap:8px;margin-top:12px">
    <button class="btn btn-p" type="submit">ذخیره</button>
    <a class="btn ghost" href="<?= url('app/petty-cash/funds') ?>">انصراف</a>
  </div>
</form>
<?= view('partials/foot') ?>
