<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)"><?= e($title) ?></h1>
    <div class="muted small">هر تنخواه یک صندوق پیش‌پرداخت با حساب کل اختصاصی و سقف مشخص است.</div></div>
  <?php if (!empty($canManage)): ?><a class="btn btn-p" href="<?= url('app/petty-cash/funds/create') ?>">+ تعریف تنخواه</a><?php endif; ?>
</div>

<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>فهرست تنخواه‌ها</h3><div class="grow"></div><span class="pill"><?= num(count($rows)) ?> تنخواه</span></div>
  <?php if (!$rows): ?>
    <?= view('partials/empty', ['message' => 'تنخواهی ثبت نشده است.', 'actionUrl' => !empty($canManage) ? url('app/petty-cash/funds/create') : '', 'actionText' => '+ تعریف تنخواه']) ?>
  <?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>کد</th><th>عنوان</th><th>تنخواه‌دار</th><th>شخص</th><th>حساب کل</th><th>مانده</th><th>سقف</th><th>هشدار</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $f): ?>
      <tr>
        <td><b><?= e($f['code']) ?></b></td>
        <td><?= e($f['title']) ?><?php if (!empty($f['note'])): ?><div class="muted small"><?= e($f['note']) ?></div><?php endif; ?></td>
        <td><?= e($f['keeper_name'] ?: '—') ?><?php if (!empty($f['keeper_mobile'])): ?><div class="muted small" dir="ltr"><?= e($f['keeper_mobile']) ?></div><?php endif; ?></td>
        <td><?= e(trim((string)$f['person_name']) ?: '—') ?></td>
        <td><span class="muted small"><?= e($f['gl_code'] . ' — ' . $f['gl_title']) ?></span></td>
        <td><b><?= num($f['balance']) ?></b> <span class="muted small"><?= e($cur) ?></span></td>
        <td><span class="muted small"><?= (float)$f['ceiling_amount'] > 0 ? num($f['ceiling_amount']) : '—' ?></span></td>
        <td><?= (float)$f['low_balance_amount'] > 0 ? '<span class="muted small">' . num($f['low_balance_amount']) . '</span>' : '—' ?></td>
        <td>
          <?php if ((string)$f['status'] === 'active'): ?><span class="pill" style="background:#E7F7EF;color:#047857">فعال</span>
          <?php else: ?><span class="pill"><?= e(['suspended' => 'غیرفعال', 'closed' => 'بسته'][$f['status']] ?? $f['status']) ?></span><?php endif; ?>
        </td>
        <td style="white-space:nowrap">
          <a class="btn sm ghost" href="<?= url('app/petty-cash/entries?fund_id=' . (int)$f['id']) ?>">اسناد</a>
          <a class="btn sm ghost" href="<?= url('app/petty-cash/reports?fund_id=' . (int)$f['id']) ?>">کارت تنخواه</a>
          <?php if (!empty($canManage)): ?>
            <a class="btn sm" href="<?= url('app/petty-cash/funds/' . (int)$f['id'] . '/edit') ?>">ویرایش</a>
            <form method="post" action="<?= url('app/petty-cash/funds/' . (int)$f['id'] . '/delete') ?>" style="display:inline"
                  onsubmit="return confirm('تنخواه «<?= e($f['title']) ?>» حذف شود؟')">
              <?= csrf_field() ?><button class="btn sm ghost" style="color:#E11D48" type="submit">حذف</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
