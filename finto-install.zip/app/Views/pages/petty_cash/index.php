<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div>
    <h1 style="margin:0;font-family:var(--font2)">تنخواه گردان</h1>
    <div class="muted small">مدیریت صندوق‌های پیش‌پرداخت، هزینه‌ها و گردش تأیید</div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <?php if (Auth::can('petty_cash.create')): ?>
      <a class="btn" href="<?= url('app/petty-cash/create?type=charge') ?>"><?= icon('wallet') ?> شارژ تنخواه</a>
      <a class="btn btn-p" href="<?= url('app/petty-cash/create?type=expense') ?>"><?= icon('coins') ?> ثبت هزینه</a>
    <?php endif; ?>
    <?php if (Auth::can('petty_cash.edit')): ?><a class="btn ghost" href="<?= url('app/petty-cash/funds/create') ?>">+ تنخواه جدید</a><?php endif; ?>
  </div>
</div>

<form method="get" class="filters" style="margin-top:12px">
  <div class="field"><label>از تاریخ</label><input class="inp jalali" type="text" name="from" value="<?= e($from) ?>"></div>
  <div class="field"><label>تا تاریخ</label><input class="inp jalali" type="text" name="to" value="<?= e($to) ?>"></div>
  <div class="field"><label>تنخواه</label>
    <select class="inp" name="fund_id"><option value="">همهٔ تنخواه‌ها</option>
      <?php foreach ($funds as $f): ?><option value="<?= (int)$f['id'] ?>" <?= $fundId == $f['id'] ? 'selected' : '' ?>><?= e($f['code'] . ' — ' . $f['title']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="kpis" style="margin-top:14px">
  <div class="kpi card"><div class="dot">◈</div><div class="t">ماندهٔ کل تنخواه‌ها</div><div class="v"><?= num($stats['funds_balance']) ?></div><div class="u"><?= num($stats['funds_count']) ?> تنخواه فعال</div></div>
  <div class="kpi card green"><div class="dot">↑</div><div class="t">شارژ در بازه</div><div class="v"><?= num($stats['charge']) ?></div><div class="u">واریز به تنخواه‌داران</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">هزینه در بازه</div><div class="v"><?= num($stats['expense']) ?></div><div class="u">خروجی از تنخواه</div></div>
  <div class="kpi card gold"><div class="dot">◷</div><div class="t">در انتظار تأیید</div><div class="v"><?= num($stats['pending']) ?></div><div class="u"><?= num($stats['pending_amount']) ?> <?= e($cur) ?></div></div>
</div>

<div class="grid c3" style="margin-top:14px">
  <div class="card" style="grid-column:span 2">
    <div class="card-head"><h3>تنخواه‌ها و ماندهٔ هر تنخواه‌دار</h3><div class="grow"></div>
      <span class="pill">جمع: <?= num($stats['funds_balance']) ?> <?= e($cur) ?></span></div>
    <?php if (!$funds): ?>
      <?= view('partials/empty', ['message' => 'هنوز تنخواهی تعریف نشده است.', 'actionUrl' => Auth::can('petty_cash.edit') ? url('app/petty-cash/funds/create') : '', 'actionText' => '+ تعریف تنخواه']) ?>
    <?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>کد</th><th>تنخواه</th><th>تنخواه‌دار</th><th>حساب کل</th><th>مانده</th><th>سقف</th><th>وضعیت</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($funds as $f): ?>
        <tr>
          <td><b><?= e($f['code']) ?></b></td>
          <td><a href="<?= url('app/petty-cash/entries?fund_id=' . (int)$f['id']) ?>"><?= e($f['title']) ?></a></td>
          <td><?= e($f['keeper_name'] ?: ($f['person_name'] ?: '—')) ?></td>
          <td><span class="muted small"><?= e($f['gl_code'] . ' — ' . $f['gl_title']) ?></span></td>
          <td><b><?= num($f['balance']) ?></b></td>
          <td><span class="muted small"><?= (float)$f['ceiling_amount'] > 0 ? num($f['ceiling_amount']) : '—' ?></span></td>
          <td>
            <?php if (!empty($f['low'])): ?><span class="pill st-bad" style="background:#FFE9EC;color:#E11D48">موجودی کم</span>
            <?php elseif ($f['status'] === 'active'): ?><span class="pill" style="background:#E7F7EF;color:#047857">فعال</span>
            <?php else: ?><span class="pill"><?= e(['suspended' => 'غیرفعال', 'closed' => 'بسته'][$f['status']] ?? $f['status']) ?></span><?php endif; ?>
          </td>
          <td style="white-space:nowrap">
            <a class="btn sm ghost" href="<?= url('app/petty-cash/reports?fund_id=' . (int)$f['id']) ?>">کارت</a>
            <?php if (Auth::can('petty_cash.create')): ?><a class="btn sm" href="<?= url('app/petty-cash/create?type=expense&fund_id=' . (int)$f['id']) ?>">هزینه</a><?php endif; ?>
            <?php if (Auth::can('petty_cash.edit')): ?><a class="btn sm ghost" href="<?= url('app/petty-cash/funds/' . (int)$f['id'] . '/edit') ?>">ویرایش</a><?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>هزینه به تفکیک مرکز هزینه</h3></div>
    <div class="card-body">
      <?php if (!$byCategory): ?><div class="muted small">داده‌ای در این بازه نیست.</div><?php else:
        $max = max(array_map(fn($r) => (float)$r['total'], $byCategory)) ?: 1; ?>
        <?php foreach ($byCategory as $r): ?>
          <div style="margin-bottom:10px">
            <div style="display:flex;justify-content:space-between;font-size:12.6px"><span><?= e($r['title']) ?></span><b><?= num($r['total']) ?></b></div>
            <div style="height:8px;background:var(--p100);border-radius:99px;overflow:hidden;margin-top:4px">
              <div style="height:100%;width:<?= max(3, (int)round(100 * (float)$r['total'] / $max)) ?>%;background:linear-gradient(90deg,#8B5CF6,#6D28D9)"></div>
            </div>
          </div>
        <?php endforeach; ?>
      <?php endif; ?>
    </div>
  </div>
</div>

<div class="grid-2b" style="margin-top:14px">
  <div class="card">
    <div class="card-head"><h3>در انتظار تأیید</h3><div class="grow"></div>
      <a class="btn sm ghost" href="<?= url('app/petty-cash/entries?status=pending') ?>">همه</a></div>
    <?php if (!$pending): ?><div class="card-body muted small">درخواست تأییدنشده‌ای نیست ✅</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>شماره</th><th>تنخواه</th><th>بابت</th><th>مبلغ</th><th></th></tr></thead>
      <tbody><?php foreach ($pending as $e): ?>
        <tr><td><a href="<?= url('app/petty-cash/' . (int)$e['id']) ?>"><?= e(fa_digits((string)$e['doc_no'])) ?></a></td>
          <td><span class="muted small"><?= e($e['fund_code']) ?></span></td>
          <td><?= e($e['title']) ?></td><td><b><?= num($e['amount']) ?></b></td>
          <td><a class="btn sm" href="<?= url('app/petty-cash/' . (int)$e['id']) ?>">بررسی</a></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>آخرین اسناد</h3><div class="grow"></div>
      <a class="btn sm ghost" href="<?= url('app/petty-cash/entries') ?>">همهٔ اسناد</a></div>
    <?php if (!$recent): ?><div class="card-body muted small">سندی در این بازه ثبت نشده است.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>تاریخ</th><th>نوع</th><th>بابت</th><th>مبلغ</th><th>وضعیت</th></tr></thead>
      <tbody><?php foreach ($recent as $e): ?>
        <tr><td><span class="muted small"><?= e(jdate($e['doc_date'])) ?></span></td>
          <td><?= e(PettyCash::typeTitle((string)$e['entry_type'])) ?></td>
          <td><a href="<?= url('app/petty-cash/' . (int)$e['id']) ?>"><?= e($e['title']) ?></a></td>
          <td><?= num($e['amount']) ?></td>
          <td><span class="pill st-<?= e(PettyCash::STATUS_CLASS[$e['status']] ?? '') ?>"><?= e(PettyCash::statusTitle((string)$e['status'])) ?></span></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/foot') ?>
