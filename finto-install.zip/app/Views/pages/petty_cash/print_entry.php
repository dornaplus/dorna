<?= view('partials/public_head', ['title' => $title]) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
  <?= view('partials/print_bar', ['back' => url('app/petty-cash/' . (int)$e['id'])]) ?>
  <div class="print-head">
    <div class="print-brand">
      <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
      <div class="biz"><?= e($business['name'] ?? '') ?></div>
      <div class="print-meta">
        <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <b><?= e($business['economic_code']) ?></b><br><?php endif; ?>
        <?= e($business['address'] ?? '') ?><?php if (!empty($business['phone'])): ?><br>تلفن: <?= e($business['phone']) ?><?php endif; ?>
      </div>
    </div>
    <div style="text-align:left">
      <div style="font-size:15px;font-weight:700;color:var(--p-800)">سند <?= e(PettyCash::typeTitle((string)$e['entry_type'])) ?></div>
      <div class="print-meta">شماره: <b><?= e(fa_digits((string)$e['doc_no'])) ?></b><br>تاریخ: <b><?= e(jdate($e['doc_date'])) ?></b></div>
    </div>
  </div>
  <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)$e['doc_no']); ?>
  <table class="print-tbl">
    <tbody>
      <tr><th style="width:170px">تنخواه</th><td><?= e($e['fund_code'] . ' — ' . $e['fund_title']) ?></td></tr>
      <tr><th>حساب کل تنخواه</th><td><?= e($e['gl_code'] . ' — ' . $e['gl_title']) ?></td></tr>
      <tr><th><?= in_array((string)$e['entry_type'], ['charge','settle'], true) ? 'عنوان' : 'بابت' ?></th><td><?= e($e['title']) ?></td></tr>
      <tr><th>مبلغ</th><td><b><?= num($e['amount']) ?> <?= e(Auth::currency()) ?></b></td></tr>
      <?php if (!empty($e['category_title'])): ?><tr><th>مرکز هزینه</th><td><?= e($e['category_title']) ?></td></tr><?php endif; ?>
      <?php if (!empty($e['reference_no'])): ?><tr><th>شماره فاکتور/رسید</th><td><?= e(fa_digits((string)$e['reference_no'])) ?></td></tr><?php endif; ?>
      <?php if (!empty($e['description'])): ?><tr><th>توضیحات</th><td><?= e($e['description']) ?></td></tr><?php endif; ?>
    </tbody>
  </table>
  <div class="words">مبلغ به حروف: <?= e($amountWords) ?></div>
  <?php if (!empty($tpl['show_signature'])): ?>
  <div class="signs"><div><span>تنخواه‌دار</span></div><div><span>تأییدکننده</span></div><div><span>مدیر مالی</span></div></div>
  <?php endif; ?>
  <div class="print-foot"><span><?= e($business['name'] ?? '') ?></span><span>چاپ <?= e(jdate(today())) ?></span></div>
</div>
<?= view('partials/public_foot') ?>
