<?= view('partials/head', ['title' => $title]) ?>
<?php $cur = Auth::currency(); ?>
<div class="page-head">
  <div><h1 style="margin:0;font-family:var(--font2)">گزارشات تنخواه</h1>
    <div class="muted small">از <?= e(jdate($gregFrom)) ?> تا <?= e(jdate($gregTo)) ?><?= $fund ? ' — تنخواه: ' . e($fund['title']) : '' ?></div></div>
  <div style="display:flex;gap:8px">
    <a class="btn ghost" href="<?= url('app/petty-cash/reports?' . http_build_query(array_filter(['fund_id' => $fundId ?: null, 'from' => $_GET['from'] ?? null, 'to' => $_GET['to'] ?? null, 'export' => 'csv']))) ?>">خروجی CSV</a>
    <a class="btn ghost" href="<?= url('app/petty-cash/reports?' . http_build_query(array_filter(['fund_id' => $fundId ?: null, 'from' => $_GET['from'] ?? null, 'to' => $_GET['to'] ?? null])) ) ?>" target="_blank" onclick="window.print();return false;">چاپ</a>
  </div>
</div>

<form method="get" class="filters" style="margin-top:12px">
  <div class="field"><label>تنخواه</label><select class="inp" name="fund_id"><option value="">همه</option>
    <?php foreach ($funds as $x): ?><option value="<?= (int)$x['id'] ?>" <?= (int)$fundId === (int)$x['id'] ? 'selected' : '' ?>><?= e($x['code'] . ' — ' . $x['title']) ?></option><?php endforeach; ?></select></div>
  <div class="field"><label>از تاریخ</label><input class="inp jalali" name="from" value="<?= e($from) ?>"></div>
  <div class="field"><label>تا تاریخ</label><input class="inp jalali" name="to" value="<?= e($to) ?>"></div>
  <div class="field"><button class="btn">اعمال</button></div>
</form>

<div class="kpis" style="margin-top:14px">
  <div class="kpi card"><div class="dot">↑</div><div class="t">جمع شارژ</div><div class="v"><?= num($stats['charge']) ?></div><div class="u">تخصیص به تنخواه‌دار</div></div>
  <div class="kpi card red"><div class="dot">↓</div><div class="t">جمع هزینه</div><div class="v"><?= num($stats['expense']) ?></div><div class="u">خروج از تنخواه</div></div>
  <div class="kpi card green"><div class="dot">↺</div><div class="t">برگشت + تسویه</div><div class="v"><?= num($stats['refund'] + $stats['settle']) ?></div><div class="u">برگشت به حساب‌ها</div></div>
  <div class="kpi card gold"><div class="dot">◈</div><div class="t">ماندهٔ دوره</div><div class="v"><?= num($stats['balance']) ?></div><div class="u">شارژ + برگشت − هزینه − تسویه</div></div>
</div>

<div class="grid c3" style="margin-top:14px">
  <div class="card"><div class="card-head"><h3>هزینه به تفکیک مرکز هزینه</h3></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>مرکز هزینه</th><th>تعداد</th><th>مبلغ</th><th>سهم</th></tr></thead>
      <tbody>
      <?php $sumCat = array_sum(array_map(fn($r) => (float)$r['total'], $byCategory)) ?: 1; ?>
      <?php foreach ($byCategory as $r): ?>
        <tr><td><?= e($r['title']) ?></td><td><?= num((int)$r['cnt']) ?></td><td><b><?= num($r['total']) ?></b></td>
          <td><?= num(round(100 * (float)$r['total'] / $sumCat, 1)) ?>٪</td></tr>
      <?php endforeach; ?>
      <?php if (!$byCategory): ?><tr><td colspan="4" class="muted small">داده‌ای نیست.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card"><div class="card-head"><h3>وضعیت اسناد دوره</h3></div>
    <div class="card-body">
      <div class="tot" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line)"><span>تأییدشده</span><b><?= num($stats['approved_count']) ?> سند</b></div>
      <div class="tot" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line)"><span>در انتظار تأیید</span><b><?= num($stats['pending']) ?> سند — <?= num($stats['pending_amount']) ?></b></div>
      <div class="tot" style="display:flex;justify-content:space-between;padding:8px 0"><span>ردشده</span><b><?= num($stats['rejected']) ?> سند — <?= num($stats['rejected_amount']) ?></b></div>
      <div class="help" style="margin-top:10px">جمع ماندهٔ تنخواه‌های شما: <b><?= num($stats['funds_balance']) ?></b> <?= e($cur) ?></div>
    </div>
  </div>
  <div class="card"><div class="card-head"><h3>ماندهٔ تنخواه‌ها</h3></div>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>تنخواه</th><th>تنخواه‌دار</th><th>مانده</th></tr></thead>
      <tbody><?php foreach ($funds as $x): ?>
        <tr><td><a href="<?= url('app/petty-cash/reports?fund_id=' . (int)$x['id']) ?>"><?= e($x['code']) ?></a></td>
          <td><span class="muted small"><?= e($x['keeper_name'] ?: '—') ?></span></td>
          <td><b<?= !empty($x['low']) ? ' style="color:#E11D48"' : '' ?>><?= num($x['balance']) ?></b></td></tr>
      <?php endforeach; ?>
      <?php if (!$funds): ?><tr><td colspan="3" class="muted small">تنخواهی نیست.</td></tr><?php endif; ?>
      </tbody>
    </table></div>
  </div>
</div>

<?php if ($fund): ?>
<div class="card" style="margin-top:14px">
  <div class="card-head"><h3>کارت تنخواه <?= e($fund['code'] . ' — ' . $fund['title']) ?></h3><div class="grow"></div>
    <span class="pill">ماندهٔ ابتدای دوره: <?= num($ledgerOpening) ?></span></div>
  <?php if (!$ledgerRows): ?><div class="card-body muted small">گردشی در این بازه نیست.</div><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>تاریخ</th><th>شماره</th><th>نوع</th><th>بابت</th><th>بدهکار (شارژ/برگشت)</th><th>بستانکار (هزینه/تسویه)</th><th>مانده</th></tr></thead>
    <tbody><?php foreach ($ledgerRows as $r): $isIn = in_array((string)$r['entry_type'], ['charge','refund'], true); ?>
      <tr><td><span class="muted small"><?= e(jdate($r['doc_date'])) ?></span></td>
        <td><a href="<?= url('app/petty-cash/' . (int)$r['id']) ?>" dir="ltr"><?= e(fa_digits((string)$r['doc_no'])) ?></a></td>
        <td><?= e(PettyCash::typeTitle((string)$r['entry_type'])) ?></td>
        <td><?= e($r['title']) ?></td>
        <td><?= $isIn ? num($r['amount']) : '—' ?></td>
        <td><?= !$isIn ? num($r['amount']) : '—' ?></td>
        <td><b><?= num($r['running']) ?></b></td></tr>
    <?php endforeach; ?></tbody>
    <tfoot><tr><th colspan="6">ماندهٔ پایان دوره</th><th><?= num($fund['balance']) ?></th></tr></tfoot>
  </table></div>
  <?php endif; ?>
</div>
<?php endif; ?>
<?= view('partials/foot') ?>
