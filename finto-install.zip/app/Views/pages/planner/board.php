<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $cols @var array $projects @var array $users @var array $types @var array $summary @var array $filters */
$base = url('app/planner/board');
$qs = function (array $over = []) use ($base, $filters) {
    $p = array_filter(array_merge($filters, $over), fn($v) => $v !== 0 && $v !== '' && $v !== null);
    return $base . ($p ? '?' . http_build_query($p) : '');
};
$colMeta = [
    'open' => ['باز', 'pl-open'], 'in_progress' => ['در جریان', 'pl-doing'],
    'done' => ['انجام‌شده', 'pl-done'], 'failed' => ['انجام‌نشده', 'pl-failed'],
];
?>
<div class="pl-head">
  <h2 class="page-title"><?= icon('list', 20) ?> برد مدیریت پروژه</h2>
  <div class="pl-head-actions">
    <a class="btn soft sm" href="<?= url('app/planner') ?>"><?= icon('calendar', 15) ?> تقویم</a>
    <a class="btn sm" href="<?= url('app/planner?new=' . today()) ?>"><?= icon('plus', 15) ?> وظیفهٔ جدید</a>
  </div>
</div>

<div class="pl-projects">
  <?php
    // فقط پروژه‌هایی که وظیفه دارند (برد تمیز بماند)
    $withTasks = array_values(array_filter($summary, fn($p) => (int)$p['tasks'] > 0));
    if (!$withTasks) $withTasks = array_slice(array_values(array_filter($summary, fn($p) => $p['status'] === 'open')), 0, 4);
    $any = false; foreach ($withTasks as $pr): $any = true; ?>
    <a class="pl-proj" href="<?= e($qs(['project_id' => (int)$pr['id']])) ?>">
      <div class="pl-proj-top"><b><?= e($pr['name']) ?></b><span class="pl-tag"><?= e((string)($pr['code'] ?? '')) ?></span></div>
      <div class="pl-proj-bar"><i style="width:<?= (int)$pr['progress'] ?>%"></i></div>
      <div class="pl-proj-meta">
        <span><?= num($pr['progress']) ?>٪ پیشرفت</span>
        <span><?= num((int)$pr['done']) ?>/<?= num((int)$pr['tasks']) ?> انجام‌شده</span>
        <?php if ((int)$pr['doing'] > 0): ?><span class="ok"><?= num((int)$pr['doing']) ?> در جریان</span><?php endif; ?>
        <?php if ((int)$pr['overdue'] > 0): ?><span class="bad"><?= num((int)$pr['overdue']) ?> معوق</span><?php endif; ?>
      </div>
    </a>
  <?php endforeach; ?>
  <?php if (!$any): ?><div class="pl-empty">پروژه‌ای با وظیفه ثبت نشده است. از «محل / مرجع» یا فیلد پروژه در فرم رویداد، وظیفه را به یک پروژه بچسبانید.</div><?php endif; ?>
</div>

<form class="pl-bar" method="get" action="<?= e($base) ?>">
  <div class="pl-mnav"><b>وظایف و پروژه‌ها</b></div>
  <div class="pl-filter">
    <select class="inp" name="project_id" onchange="this.form.submit()">
      <option value="">همهٔ پروژه‌ها</option>
      <?php foreach ($projects as $pr): ?>
        <option value="<?= (int)$pr['id'] ?>" <?= (int)$filters['project_id'] === (int)$pr['id'] ? 'selected' : '' ?>><?= e($pr['name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="inp" name="assignee" onchange="this.form.submit()">
      <option value="">همهٔ مسئولان</option>
      <?php foreach ($users as $u): ?>
        <option value="<?= (int)$u['id'] ?>" <?= (int)$filters['assignee'] === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="inp" name="priority" onchange="this.form.submit()">
      <option value="">همهٔ اولویت‌ها</option>
      <?php foreach (Planner::PRIORITIES as $k => $lbl): ?>
        <option value="<?= e($k) ?>" <?= (string)$filters['priority'] === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <input class="inp" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="جست‌وجو…">
    <button class="btn sm">اعمال</button>
    <?php if (array_filter($filters)): ?><a class="btn gray sm" href="<?= e($base) ?>">حذف فیلترها</a><?php endif; ?>
  </div>
</form>

<div class="pl-board-wrap">
  <div class="pl-board">
    <?php foreach ($cols as $st => $list): [$lbl, $cls] = $colMeta[$st]; ?>
      <div class="pl-col <?= e($cls) ?>">
        <div class="pl-col-head"><b><?= e($lbl) ?></b><span class="pl-tag"><?= num(count($list)) ?></span></div>
        <div class="pl-col-body">
          <?php foreach ($list as $e): [$hex, $soft] = Planner::colorHex((string)($e['type_color'] ?? 'purple'));
            $due = (string)($e['end_date'] ?: $e['start_date']);
            $d = (int)round((strtotime($due) - strtotime(today())) / 86400);
            $late = $d < 0 && in_array($st, ['open', 'in_progress'], true); ?>
            <div class="pl-kcard" style="--c:<?= e($hex) ?>;--cs:<?= e($soft) ?>">
              <div class="pl-kcard-top">
                <span class="pl-card-ic"><?= icon((string)($e['type_icon'] ?: 'check'), 15) ?></span>
                <a class="pl-kcard-t" href="<?= url('app/planner?open=' . (int)$e['id']) ?>"><?= e($e['title']) ?></a>
              </div>
              <div class="pl-kcard-meta">
                <?php if (!empty($e['project_name'])): ?><span class="pl-tag"><?= e($e['project_name']) ?></span><?php endif; ?>
                <span class="pl-tag p-<?= e($e['priority']) ?>"><?= e(Planner::PRIORITIES[$e['priority']] ?? '') ?></span>
                <span class="pl-tag <?= $late ? 'st-failed' : '' ?>"><?= e(jdate($due)) ?><?= $st === 'done' || $st === 'failed' ? '' : ($d < 0 ? ' · ' . num(abs($d)) . ' روز گذشته' : ($d === 0 ? ' · امروز' : ' · ' . num($d) . ' روز')) ?></span>
              </div>
              <div class="pl-kcard-foot">
                <span class="pl-who"><?= Avatar::html((string)($e['assignee_name'] ?? ''), (string)($e['assignee_avatar'] ?? ''), 'pm-av', 20) ?> <?= e((string)($e['assignee_name'] ?? 'بدون مسئول')) ?></span>
                <div class="grow"></div>
                <?php if ($st !== 'in_progress' && $st !== 'done'): ?>
                  <form method="post" action="<?= url('app/planner/' . (int)$e['id'] . '/status') ?>" class="pl-mini-form">
                    <?= csrf_field() ?><input type="hidden" name="status" value="in_progress"><input type="hidden" name="back" value="board"><button class="btn soft sm" title="شروع">▶</button>
                  </form>
                <?php endif; ?>
                <?php if ($st !== 'done'): ?>
                  <form method="post" action="<?= url('app/planner/' . (int)$e['id'] . '/status') ?>" class="pl-mini-form">
                    <?= csrf_field() ?><input type="hidden" name="status" value="done"><input type="hidden" name="back" value="board"><button class="btn sm" title="انجام شد">✓</button>
                  </form>
                <?php endif; ?>
                <?php if ($st !== 'failed'): ?>
                  <form method="post" action="<?= url('app/planner/' . (int)$e['id'] . '/status') ?>" class="pl-mini-form pl-fail">
                    <?= csrf_field() ?><input type="hidden" name="status" value="failed"><input type="hidden" name="back" value="board">
                    <input type="text" name="note" placeholder="دلیل…" required>
                    <button class="btn danger sm" title="انجام نشد">✗</button>
                  </form>
                <?php endif; ?>
              </div>
            </div>
          <?php endforeach; ?>
          <?php if (!$list): ?><div class="pl-empty sm">موردی نیست</div><?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?= view('partials/foot') ?>
