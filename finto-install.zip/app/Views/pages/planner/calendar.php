<?= view('partials/head', ['title' => $title]) ?>
<?php
/** @var array $cells @var array $byDay @var array $events @var array $types @var array $users @var array $settings @var array $stats @var array $filters */
$maxV = (int)$settings['max_visible'];
$workDays = (array)$settings['work_days'];
$todayIso = today();
$base = url('app/planner');
$q = function (array $over = []) use ($base, $view, $jy, $jm, $filters) {
    $p = array_merge(['view' => $view, 'y' => $jy, 'm' => $jm], $over);
    if (!empty($filters['assignee'])) $p['assignee'] = $filters['assignee'];
    if (!empty($filters['type_id'])) $p['type_id'] = $filters['type_id'];
    if (!empty($filters['priority'])) $p['priority'] = $filters['priority'];
    if (!empty($filters['q'])) $p['q'] = $filters['q'];
    foreach ((array)$filters['status'] as $s) $p['status'][] = $s;
    return $base . '?' . http_build_query($p);
};
$prevM = $jm === 1 ? [12, $jy - 1] : [$jm - 1, $jy];
$nextM = $jm === 12 ? [1, $jy + 1] : [$jm + 1, $jy];
?>
<div class="pl-head">
  <h2 class="page-title"><?= icon('calendar', 20) ?> برنامه‌ریز و تقویم</h2>
  <div class="pl-head-actions">
    <?php [$cy, $cm] = current_jalali_ym(); ?><a class="btn soft sm" href="<?= e($q(['view' => 'month', 'y' => $cy, 'm' => $cm, 'day' => null, 'open' => null])) ?>">امروز</a>
    <a class="btn sm" href="<?= e($q(['new' => $todayIso, 'open' => null, 'day' => null])) ?>"><?= icon('plus', 15) ?> رویداد جدید</a>
  </div>
</div>

<?php if ($aiEnabled): ?>
<div class="pl-ai">
  <div class="pl-ai-head">
    <b><?= icon('spark', 17) ?> دستیار هوشمند برنامه‌ریزی</b>
    <span class="muted sm">تحلیل وظایف و ساخت سریع رویداد با AvalAI</span>
    <div class="grow"></div>
    <button class="btn soft sm" type="button" data-ai-plan>تحلیل وضعیت و اولویت‌ها</button>
  </div>
  <div class="pl-ai-row">
    <input class="inp" id="plAiText" placeholder="مثلاً: فردا ساعت ۱۰ جلسه با تأمین‌کننده دربارهٔ قیمت مفتول — اولویت زیاد">
    <button class="btn sm" type="button" data-ai-parse>ساخت رویداد از این متن</button>
  </div>
  <div class="pl-ai-out" id="plAiOut" hidden></div>
</div>
<?php endif; ?>

<div class="pl-stats">
  <div class="pl-st"><span>کل رویدادها</span><b><?= num($stats['total']) ?></b></div>
  <div class="pl-st"><span>باز</span><b><?= num($stats['open']) ?></b></div>
  <div class="pl-st"><span>در جریان</span><b><?= num($stats['in_progress']) ?></b></div>
  <div class="pl-st g"><span>انجام‌شده</span><b><?= num($stats['done']) ?></b></div>
  <div class="pl-st r"><span>انجام‌نشده</span><b><?= num($stats['failed']) ?></b></div>
  <div class="pl-st y"><span>امروز</span><b><?= num($stats['today']) ?></b></div>
  <div class="pl-st r"><span>معوق</span><b><?= num($stats['overdue']) ?></b></div>
</div>

<div class="pl-bar">
  <?php if ($view === 'month'): ?>
    <div class="pl-mnav">
      <a class="pl-arrow" href="<?= e($q(['y' => $prevM[1], 'm' => $prevM[0], 'day' => null])) ?>" title="ماه قبل">›</a>
      <b><?= e(Planner::jalaliMonthName($jm) . ' ' . fa_digits((string)$jy)) ?></b>
      <a class="pl-arrow" href="<?= e($q(['y' => $nextM[1], 'm' => $nextM[0], 'day' => null])) ?>" title="ماه بعد">‹</a>
    </div>
  <?php else: ?>
    <div class="pl-mnav"><b>فهرست رویدادها — <?= e(jdate($from)) ?> تا <?= e(jdate($to)) ?></b></div>
  <?php endif; ?>
  <div class="pl-views">
    <a class="pl-v <?= $view === 'month' ? 'on' : '' ?>" href="<?= e($q(['view' => 'month'])) ?>">تقویم ماه</a>
    <a class="pl-v <?= $view === 'agenda' ? 'on' : '' ?>" href="<?= e($q(['view' => 'agenda'])) ?>">فهرست</a>
  </div>
  <form class="pl-filter" method="get" action="<?= e($base) ?>">
    <input type="hidden" name="view" value="<?= e($view) ?>">
    <input type="hidden" name="y" value="<?= (int)$jy ?>"><input type="hidden" name="m" value="<?= (int)$jm ?>">
    <select class="inp" name="assignee" onchange="this.form.submit()">
      <option value="">همهٔ مسئولان</option>
      <?php foreach ($users as $u): ?>
        <option value="<?= (int)$u['id'] ?>" <?= (int)$filters['assignee'] === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="inp" name="type_id" onchange="this.form.submit()">
      <option value="">همهٔ انواع</option>
      <?php foreach ($types as $t): ?>
        <option value="<?= (int)$t['id'] ?>" <?= (int)$filters['type_id'] === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['title']) ?></option>
      <?php endforeach; ?>
    </select>
    <select class="inp" name="priority" onchange="this.form.submit()">
      <option value="">همهٔ اولویت‌ها</option>
      <?php foreach (Planner::PRIORITIES as $k => $lbl): ?>
        <option value="<?= e($k) ?>" <?= (string)$filters['priority'] === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
      <?php endforeach; ?>
    </select>
    <input class="inp" type="search" name="q" value="<?= e($filters['q']) ?>" placeholder="جست‌وجو…">
    <button class="btn sm">فیلتر</button>
    <?php if (array_filter([$filters['assignee'], $filters['type_id'], $filters['priority'], $filters['q']]) || $filters['status']): ?>
      <a class="btn gray sm" href="<?= e($q(['assignee' => 0, 'type_id' => 0, 'priority' => '', 'q' => '', 'status' => []])) ?>">حذف فیلترها</a>
    <?php endif; ?>
  </form>
</div>

<?php if ($view === 'month'): ?>
<div class="pl-cal-wrap">
  <div class="pl-cal">
    <div class="pl-dow">
      <?php foreach (Planner::WEEKDAYS as $i => $d): ?><span class="<?= in_array($i, $workDays, true) ? '' : 'off' ?>"><?= e($d) ?></span><?php endforeach; ?>
    </div>
    <div class="pl-grid">
      <?php foreach ($cells as $c): if ($c === null): ?>
        <div class="pl-cell empty"></div>
      <?php else:
        $evs = $byDay[$c['iso']] ?? [];
        $isToday = $c['iso'] === $todayIso;
        $isWork = in_array($c['wd'], $workDays, true);
        $isFriday = $c['wd'] === 6;
      ?>
        <div class="pl-cell<?= $isToday ? ' today' : '' ?><?= $isWork ? '' : ' off' ?><?= $isFriday ? ' fri' : '' ?>">
          <a class="pl-day" href="<?= e($q(['day' => $c['iso'], 'open' => null])) ?>" title="نمایش رویدادهای این روز">
            <span class="pl-j"><?= num($c['j']) ?></span>
            <span class="pl-g"><?= num((int)date('j', strtotime($c['iso']))) ?></span>
          </a>
          <div class="pl-evs">
            <?php foreach (array_slice($evs, 0, $maxV) as $ev):
              [$hex, $soft] = Planner::colorHex((string)($ev['type_color'] ?? 'purple')); ?>
              <a class="pl-chip s-<?= e($ev['status']) ?>" style="--c:<?= e($hex) ?>;--cs:<?= e($soft) ?>"
                 href="<?= e($q(['open' => (int)$ev['id'], 'day' => null])) ?>" title="<?= e($ev['title']) ?> — <?= e(Planner::STATUSES[$ev['status']] ?? '') ?>">
                <?php if (!$ev['all_day'] && !empty($ev['start_time'])): ?><i><?= e(substr((string)$ev['start_time'], 0, 5)) ?></i><?php endif; ?>
                <span><?= e($ev['title']) ?></span>
              </a>
            <?php endforeach; ?>
            <?php if (count($evs) > $maxV): ?>
              <a class="pl-more" href="<?= e($q(['day' => $c['iso'], 'open' => null])) ?>">+<?= num(count($evs) - $maxV) ?> مورد دیگر</a>
            <?php endif; ?>
          </div>
        </div>
      <?php endif; endforeach; ?>
    </div>
  </div>
</div>
<?php else: ?>
<div class="pl-agenda">
  <?php $has = false; foreach ($byDay as $iso => $evs): if (!$evs) continue; $has = true; ?>
    <div class="pl-ag-day">
      <div class="pl-ag-date"><?= e(Planner::WEEKDAYS[((int)date('w', strtotime($iso)) + 1) % 7]) ?> <?= e(jdate($iso)) ?>
        <a class="pl-add" href="<?= e($q(['new' => $iso, 'day' => null, 'open' => null])) ?>">+ افزودن</a></div>
      <?php foreach ($evs as $ev): [$hex, $soft] = Planner::colorHex((string)($ev['type_color'] ?? 'purple')); ?>
        <a class="pl-ag-row s-<?= e($ev['status']) ?>" style="--c:<?= e($hex) ?>;--cs:<?= e($soft) ?>"
           href="<?= e($q(['open' => (int)$ev['id'], 'day' => null])) ?>">
          <span class="pl-ag-ic"><?= icon((string)($ev['type_icon'] ?: 'check'), 16) ?></span>
          <span class="pl-ag-t"><b><?= e($ev['title']) ?></b>
            <small><?= e($ev['type_title'] ?? '') ?><?= !empty($ev['assignee_name']) ? ' · مسئول: ' . e($ev['assignee_name']) : '' ?><?= !empty($ev['location']) ? ' · ' . e($ev['location']) : '' ?></small></span>
          <span class="pl-tag p-<?= e($ev['priority']) ?>"><?= e(Planner::PRIORITIES[$ev['priority']] ?? '') ?></span>
          <span class="pl-tag st-<?= e($ev['status']) ?>"><?= e(Planner::STATUSES[$ev['status']] ?? '') ?></span>
          <span class="pl-ag-d"><?= e(jdate((string)($ev['end_date'] ?: $ev['start_date']))) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>
  <?php if (!$has): ?><div class="pl-empty">در این بازه رویدادی ثبت نشده است.</div><?php endif; ?>
</div>
<?php endif; ?>

<?php if (!empty($dayIso)): ?>
<div class="pl-drawer-bg" data-pl-close></div>
<aside class="pl-drawer">
  <div class="pl-drawer-head">
    <b><?= e(jdate($dayIso)) ?></b>
    <span class="muted sm"><?= e(Planner::WEEKDAYS[((int)date('w', strtotime($dayIso)) + 1) % 7]) ?> · <?= num(count($dayEvents)) ?> رویداد</span>
    <div class="grow"></div>
    <a class="btn sm" href="<?= e($q(['new' => $dayIso, 'day' => null])) ?>">+ رویداد</a>
    <a class="pl-x" href="<?= e($q(['day' => null])) ?>" data-pl-close>×</a>
  </div>
  <div class="pl-drawer-body">
    <?php if (!$dayEvents): ?><div class="pl-empty">این روز رویدادی ندارد.</div><?php endif; ?>
    <?php foreach ($dayEvents as $ev): [$hex, $soft] = Planner::colorHex((string)($ev['type_color'] ?? 'purple')); ?>
      <a class="pl-card s-<?= e($ev['status']) ?>" style="--c:<?= e($hex) ?>;--cs:<?= e($soft) ?>"
         href="<?= e($q(['open' => (int)$ev['id'], 'day' => $dayIso])) ?>">
        <span class="pl-card-ic"><?= icon((string)($ev['type_icon'] ?: 'check'), 16) ?></span>
        <span class="pl-card-b"><b><?= e($ev['title']) ?></b>
          <small><?= e($ev['type_title'] ?? '') ?><?= !empty($ev['start_time']) && !$ev['all_day'] ? ' · ' . e(substr((string)$ev['start_time'], 0, 5)) : '' ?><?= !empty($ev['assignee_name']) ? ' · ' . e($ev['assignee_name']) : '' ?></small></span>
        <span class="pl-tag st-<?= e($ev['status']) ?>"><?= e(Planner::STATUSES[$ev['status']] ?? '') ?></span>
      </a>
    <?php endforeach; ?>
  </div>
</aside>
<?php endif; ?>

<?php $modalEvent = $openEvent; $isNew = (!$modalEvent && !empty($newDate)); ?>
<?php if ($modalEvent || $isNew):
  $ed = $modalEvent ?: ['title' => '', 'description' => '', 'location' => '', 'type_id' => 0, 'all_day' => 1,
      'start_date' => $newDate, 'end_date' => null, 'start_time' => '', 'end_time' => '', 'priority' => 'normal',
      'assignee_user_id' => 0, 'repeat_rule' => 'none', 'remind_days' => (int)$settings['reminder_days'],
      'status' => 'open', 'progress' => 0, 'completion_note' => ''];
  $edId = (int)($modalEvent['id'] ?? 0);
?>
<div class="pl-modal-bg" data-pl-close></div>
<div class="pl-modal">
  <div class="pl-modal-head">
    <b><?= $edId ? 'رویداد #' . num($edId) : 'رویداد جدید' ?></b>
    <?php if ($edId): ?><span class="pl-tag st-<?= e($ed['status']) ?>"><?= e(Planner::STATUSES[$ed['status']] ?? '') ?></span><?php endif; ?>
    <div class="grow"></div>
    <a class="pl-x" href="<?= e($q(['open' => null, 'new' => null])) ?>" data-pl-close>×</a>
  </div>
  <form class="pl-form" method="post" action="<?= e($edId ? url('app/planner/' . $edId) : url('app/planner')) ?>">
    <?= csrf_field() ?>
    <div class="pl-form-grid">
      <label class="field w2"><span>عنوان رویداد *</span><input class="inp" name="title" value="<?= e($ed['title'] ?? '') ?>" required maxlength="190"></label>
      <label class="field"><span>نوع</span>
        <select class="inp" name="type_id">
          <option value="">— بدون نوع —</option>
          <?php foreach ($types as $t): ?>
            <option value="<?= (int)$t['id'] ?>" <?= (int)($ed['type_id'] ?? 0) === (int)$t['id'] ? 'selected' : '' ?>><?= e($t['title']) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>پروژه</span>
        <select class="inp" name="project_id">
          <option value="">— بدون پروژه —</option>
          <?php foreach (($projects ?? []) as $pr): ?>
            <option value="<?= (int)$pr['id'] ?>" <?= (int)($ed['project_id'] ?? 0) === (int)$pr['id'] ? 'selected' : '' ?>><?= e($pr['name']) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>مسئول انجام</span>
        <select class="inp" name="assignee_user_id">
          <option value="">— خودم / بدون مسئول —</option>
          <?php foreach ($users as $u): ?>
            <option value="<?= (int)$u['id'] ?>" <?= (int)($ed['assignee_user_id'] ?? 0) === (int)$u['id'] ? 'selected' : '' ?>><?= e($u['full_name']) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>از تاریخ *</span>
        <input class="inp jalali" name="start_date" value="<?= e(jdate((string)($ed['start_date'] ?? today()))) ?>" data-value="<?= e((string)($ed['start_date'] ?? today())) ?>" required></label>
      <label class="field"><span>تا تاریخ (اختیاری)</span>
        <input class="inp jalali" name="end_date" value="<?= !empty($ed['end_date']) ? e(jdate((string)$ed['end_date'])) : '' ?>" data-value="<?= e((string)($ed['end_date'] ?? '')) ?>"></label>
      <label class="field"><span>اولویت</span>
        <select class="inp" name="priority">
          <?php foreach (Planner::PRIORITIES as $k => $lbl): ?>
            <option value="<?= e($k) ?>" <?= (string)($ed['priority'] ?? 'normal') === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>تکرار</span>
        <select class="inp" name="repeat_rule">
          <?php foreach (Planner::REPEATS as $k => $lbl): ?>
            <option value="<?= e($k) ?>" <?= (string)($ed['repeat_rule'] ?? 'none') === $k ? 'selected' : '' ?>><?= e($lbl) ?></option>
          <?php endforeach; ?>
        </select></label>
      <label class="field"><span>یادآوری (روز قبل)</span>
        <input class="inp" name="remind_days" value="<?= e(fa_digits((string)($ed['remind_days'] ?? 1))) ?>" inputmode="numeric"></label>
      <label class="field w2"><span>محل / مرجع</span><input class="inp" name="location" value="<?= e($ed['location'] ?? '') ?>" maxlength="190" placeholder="مثلاً انبار مرکزی، شعبهٔ ۲ …"></label>
      <div class="field w2">
        <label class="pl-check"><input type="checkbox" name="all_day" value="1" <?= !empty($ed['all_day']) ? 'checked' : '' ?> onchange="this.closest('.pl-form').querySelectorAll('.pl-time').forEach(function(e){e.hidden=this.checked},this)"> <span>تمام‌روز (بدون ساعت)</span></label>
      </div>
      <label class="field pl-time" <?= !empty($ed['all_day']) ? 'hidden' : '' ?>><span>ساعت شروع</span><input class="inp" type="time" name="start_time" value="<?= e(substr((string)($ed['start_time'] ?? ''), 0, 5)) ?>"></label>
      <label class="field pl-time" <?= !empty($ed['all_day']) ? 'hidden' : '' ?>><span>ساعت پایان</span><input class="inp" type="time" name="end_time" value="<?= e(substr((string)($ed['end_time'] ?? ''), 0, 5)) ?>"></label>
      <label class="field w3"><span>توضیحات</span><textarea class="inp" name="description" rows="3"><?= e($ed['description'] ?? '') ?></textarea></label>
    </div>
    <div class="form-actions">
      <button class="btn"><?= $edId ? 'ذخیره تغییرات' : 'ثبت رویداد' ?></button>
      <a class="btn gray" href="<?= e($q(['open' => null, 'new' => null])) ?>">انصراف</a>
      <?php if ($edId && ($modalEvent['can_edit'] ?? false)): ?>
        <div class="spacer"></div>
        <button class="btn danger" type="submit" form="pl-del" onclick="return confirm('این رویداد حذف شود؟')">حذف رویداد</button>
      <?php endif; ?>
    </div>
  </form>
  <?php if ($edId && ($modalEvent['can_edit'] ?? false)): ?>
    <form id="pl-del" method="post" action="<?= url('app/planner/' . $edId . '/delete') ?>"><?= csrf_field() ?></form>
  <?php endif; ?>

  <?php if ($edId && ($modalEvent['can_status'] ?? false)): ?>
    <div class="pl-sec">
      <h4>وضعیت انجام</h4>
      <div class="pl-status-row">
        <?php foreach (['in_progress' => 'شروع شد', 'done' => 'انجام شد', 'failed' => 'انجام نشد', 'cancelled' => 'لغو'] as $sk => $slbl): ?>
          <form method="post" action="<?= url('app/planner/' . $edId . '/status') ?>" class="pl-status-form">
            <?= csrf_field() ?>
            <input type="hidden" name="status" value="<?= e($sk) ?>">
            <?php if ($sk === 'failed'): ?>
              <input class="inp" name="note" placeholder="دلیل انجام‌نشدن (الزامی)" required>
            <?php endif; ?>
            <button class="btn <?= $sk === 'done' ? '' : ($sk === 'failed' ? 'danger' : 'soft') ?> sm"><?= e($slbl) ?></button>
          </form>
        <?php endforeach; ?>
      </div>
      <?php if (!empty($modalEvent['completion_note'])): ?>
        <div class="pl-note">توضیح ثبت‌شده: <?= e($modalEvent['completion_note']) ?></div>
      <?php endif; ?>
    </div>

    <div class="pl-sec">
      <h4>فایل‌ها و مدارک</h4>
      <div class="pl-files">
        <?php foreach (($attachments ?? []) as $a): [$fic, $flbl] = Planner::fileKind((string)$a['file_name']); ?>
          <div class="pl-file">
            <span class="pl-file-ic"><?= icon($fic, 16) ?></span>
            <span class="pl-file-b"><b><?= e($a['file_name']) ?></b>
              <small><?= e($flbl) ?> · <?= num((int)round(((int)$a['size_bytes']) / 1024)) ?> کیلوبایت · <?= e((string)($a['user_name'] ?? '—')) ?> · <?= e(jdate((string)$a['created_at'], '/', true)) ?><?= !empty($a['note']) ? ' · ' . e($a['note']) : '' ?></small></span>
            <a class="btn soft sm" href="<?= url('app/planner/attach/' . (int)$a['id']) ?>" target="_blank" rel="noopener">مشاهده</a>
            <?php if ((int)$a['user_id'] === (int)Auth::id() || Auth::isAdmin()): ?>
              <form method="post" action="<?= url('app/planner/attach/' . (int)$a['id'] . '/delete') ?>" onsubmit="return confirm('این فایل حذف شود؟')" style="margin:0">
                <?= csrf_field() ?><input type="hidden" name="event_id" value="<?= (int)$edId ?>"><button class="btn danger sm">حذف</button>
              </form>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
        <?php if (empty($attachments)): ?><div class="pl-empty">هنوز فایلی ارسال نشده است.</div><?php endif; ?>
      </div>
      <?php if ($modalEvent['can_status'] ?? false): ?>
        <form class="pl-upload" method="post" action="<?= url('app/planner/' . $edId . '/attach') ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <input type="file" name="file" accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.zip,.rar" required>
          <input class="inp" name="note" placeholder="توضیح کوتاه (اختیاری)" maxlength="255">
          <button class="btn sm">ارسال فایل برای مدیر</button>
        </form>
        <div class="pl-hint">تصویر، PDF، Word، Excel، CSV، TXT یا ZIP — حداکثر ۸ مگابایت. فایل فقط برای افراد مرتبط با همین رویداد قابل مشاهده است.</div>
      <?php endif; ?>
    </div>

    <div class="pl-sec">
      <h4>گفت‌وگو</h4>
      <div class="pl-comments">
        <?php foreach ($openComments as $c): ?>
          <div class="pl-cm">
            <?= Avatar::html((string)($c['user_name'] ?? ''), (string)($c['user_avatar'] ?? ''), 'pm-av', 28) ?>
            <div class="pl-cm-b"><b><?= e($c['user_name'] ?? '—') ?></b><span class="muted sm"><?= e(jdate((string)$c['created_at'], '/', true)) ?></span><p><?= e($c['body']) ?></p></div>
          </div>
        <?php endforeach; ?>
        <?php if (!$openComments): ?><div class="pl-empty">پیامی ثبت نشده است.</div><?php endif; ?>
      </div>
      <form method="post" action="<?= url('app/planner/' . $edId . '/comment') ?>" class="pl-cm-form">
        <?= csrf_field() ?>
        <input class="inp" name="body" placeholder="پیام، توضیح یا گزارش پیشرفت…" maxlength="600">
        <button class="btn sm">ارسال</button>
      </form>
    </div>
  <?php endif; ?>

  <?php if ($edId): ?>
    <div class="pl-meta">
      <span class="pl-meta-who"><?= Avatar::html((string)($modalEvent['assignee_name'] ?? ''), (string)($modalEvent['assignee_avatar'] ?? ''), 'pm-av', 22) ?> مسئول: <b><?= e($modalEvent['assignee_name'] ?? '—') ?></b></span>
      <span class="pl-meta-who"><?= Avatar::html((string)($modalEvent['creator_name'] ?? ''), (string)($modalEvent['creator_avatar'] ?? ''), 'pm-av', 22) ?> سازنده: <b><?= e($modalEvent['creator_name'] ?? '—') ?></b></span>
      <span>بازه: <b><?= e(jdate((string)$modalEvent['start_date'])) ?><?= !empty($modalEvent['end_date']) ? ' تا ' . e(jdate((string)$modalEvent['end_date'])) : '' ?></b></span>
      <span>پیشرفت: <b><?= num((int)$modalEvent['progress']) ?>٪</b></span>
    </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<script>
(function () {
    var BASE = window.APP_BASE || '';
    function post(url, data) {
        var b = new URLSearchParams(data || {}); b.append('_token', window.CSRF || '');
        return fetch(BASE + url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' },
            body: b.toString(), credentials: 'same-origin' }).then(function (r) { return r.json(); });
    }
    function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }
    var out = document.getElementById('plAiOut');
    document.querySelectorAll('[data-ai-plan]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            if (!out) return;
            out.hidden = false; out.innerHTML = '<div class="pl-ai-load">⏳ در حال تحلیل با هوش مصنوعی…</div>';
            post('/app/planner/ai/plan', {}).then(function (j) {
                if (!j || !j.ok) { out.innerHTML = '<div class="pl-ai-err">' + esc((j && j.error) || 'خطا') + '</div>'; return; }
                out.innerHTML = '<div class="pl-ai-txt">' + esc(j.text).replace(/\n/g, '<br>') + '</div>';
            }).catch(function () { out.innerHTML = '<div class="pl-ai-err">ارتباط برقرار نشد.</div>'; });
        });
    });
    document.querySelectorAll('[data-ai-parse]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var t = document.getElementById('plAiText');
            if (!t || t.value.trim().length < 4) { if (t) t.focus(); return; }
            btn.disabled = true; btn.textContent = '…';
            post('/app/planner/ai/parse', { text: t.value }).then(function (j) {
                btn.disabled = false; btn.textContent = 'ساخت رویداد از این متن';
                if (!j || !j.ok) { if (out) { out.hidden = false; out.innerHTML = '<div class="pl-ai-err">' + esc((j && j.error) || 'خطا') + '</div>'; } return; }
                try { sessionStorage.setItem('pl_ai_event', JSON.stringify(j.event)); } catch (e) {}
                location.href = BASE + '/app/planner?new=' + (j.event.start_iso || '');
            }).catch(function () { btn.disabled = false; btn.textContent = 'ساخت رویداد از این متن'; });
        });
    });
    // پرکردن فرم از نتیجهٔ هوش مصنوعی
    try {
        var pend = sessionStorage.getItem('pl_ai_event');
        if (pend) {
            sessionStorage.removeItem('pl_ai_event');
            var ev = JSON.parse(pend), f = document.querySelector('.pl-form');
            if (f) {
                var set = function (n, v) { var e = f.querySelector('[name="' + n + '"]'); if (e && v != null && v !== '') e.value = v; };
                set('title', ev.title); set('priority', ev.priority); set('location', ev.location);
                set('description', ev.description); set('remind_days', ev.remind_days);
                if (ev.type_id) set('type_id', ev.type_id);
                if (ev.assignee_id) set('assignee_user_id', ev.assignee_id);
                if (ev.start_iso) { var sd = f.querySelector('[name="start_date"]'); if (sd) { sd.setAttribute('data-value', ev.start_iso); sd.value = ev.start_jalali; } }
                if (ev.end_iso) { var ed2 = f.querySelector('[name="end_date"]'); if (ed2) { ed2.setAttribute('data-value', ev.end_iso); ed2.value = ev.end_jalali; } }
            }
        }
    } catch (e) { }

    document.querySelectorAll('[data-pl-close]').forEach(function (el) {
        el.addEventListener('click', function () { location.href = '<?= e($q(['open' => null, 'new' => null, 'day' => null])) ?>'; });
    });
    var box = document.querySelector('input[name="all_day"]');
    if (box) {
        var sync = function () { document.querySelectorAll('.pl-time').forEach(function (f) { f.hidden = box.checked; }); };
        box.addEventListener('change', sync); sync();
    }
})();
</script>
<?= view('partials/foot') ?>
