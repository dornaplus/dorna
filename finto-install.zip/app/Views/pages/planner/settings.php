<?= view('partials/head', ['title' => $title]) ?>
<?php /** @var array $types @var array $settings @var array $colors @var array $weekdays @var array $users */ ?>
<div class="pl-head">
  <h2 class="page-title"><?= icon('cog', 20) ?> تنظیمات برنامه‌ریز</h2>
  <div class="pl-head-actions">
    <a class="btn soft sm" href="<?= url('app/planner') ?>"><?= icon('calendar', 15) ?> تقویم</a>
  </div>
</div>

<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>پارامترهای برنامه‌ریز</h3></div>
    <form method="post" action="<?= url('app/planner/settings') ?>" class="card-body">
      <?= csrf_field() ?>
      <div class="form-grid">
        <label class="field"><span>یادآوری پیش‌فرض (روز قبل)</span>
          <input class="inp" name="reminder_days" value="<?= e(fa_digits((string)$settings['reminder_days'])) ?>" inputmode="numeric"></label>
        <label class="field"><span>نمای پیش‌فرض</span>
          <select class="inp" name="default_view">
            <option value="month" <?= $settings['default_view'] === 'month' ? 'selected' : '' ?>>تقویم ماه</option>
            <option value="agenda" <?= $settings['default_view'] === 'agenda' ? 'selected' : '' ?>>فهرست</option>
          </select></label>
        <label class="field"><span>تعداد رویداد نمایشی در هر روز</span>
          <input class="inp" name="max_visible" value="<?= e(fa_digits((string)$settings['max_visible'])) ?>" inputmode="numeric"></label>
        <div class="field w2"><span>روزهای کاری (روزهای غیرکاری کم‌رنگ نمایش داده می‌شوند)</span>
          <div class="pl-days">
            <?php foreach ($weekdays as $i => $d): ?>
              <label class="pl-day-chip"><input type="checkbox" name="work_days[]" value="<?= $i ?>" <?= in_array($i, (array)$settings['work_days'], true) ? 'checked' : '' ?>> <span><?= e($d) ?></span></label>
            <?php endforeach; ?>
          </div>
        </div>
        <label class="field pl-check-field"><input type="checkbox" name="allow_user_create" value="1" <?= !empty($settings['allow_user_create']) ? 'checked' : '' ?>> <span>کاربران عادی هم بتوانند رویداد شخصی ثبت کنند</span></label>
        <label class="field pl-check-field"><input type="checkbox" name="notify_manager" value="1" <?= !empty($settings['notify_manager']) ? 'checked' : '' ?>> <span>اعلان انجام/انجام‌نشدن به سازندهٔ رویداد ارسال شود</span></label>
      </div>
      <div class="form-actions"><button class="btn">ذخیرهٔ تنظیمات</button>
        <a class="btn gray" href="<?= url('app/planner') ?>">بازگشت</a></div>
    </form>
  </div>

  <div class="card">
    <div class="card-head"><h3>انواع رویداد</h3><span class="pill"><?= num(count($types)) ?></span></div>
    <div class="card-body">
      <form method="post" action="<?= url('app/planner/types') ?>" class="pl-type-form">
        <?= csrf_field() ?>
        <input class="inp" name="title" placeholder="عنوان نوع (مثلاً بازدید انبار)" required maxlength="80">
        <select class="inp" name="color">
          <?php foreach ($colors as $k => $c): ?><option value="<?= e($k) ?>" <?= $k === 'purple' ? 'selected' : '' ?>><?= e(Planner::colorLabel($k)) ?></option><?php endforeach; ?>
        </select>
        <select class="inp" name="icon">
          <?php foreach (['check', 'users', 'bell', 'truck', 'eye', 'shield', 'star', 'clock', 'tag', 'money', 'file', 'info'] as $ic): ?>
            <option value="<?= e($ic) ?>"><?= e(Planner::iconLabel($ic)) ?></option>
          <?php endforeach; ?>
        </select>
        <input class="inp" name="sort_order" placeholder="ترتیب" value="0" inputmode="numeric" style="max-width:90px">
        <button class="btn sm">افزودن</button>
      </form>

      <div class="pl-types">
        <?php foreach ($types as $t): [$hex, $soft] = Planner::colorHex((string)$t['color']); ?>
          <form class="pl-type-row" method="post" action="<?= url('app/planner/types') ?>" style="--c:<?= e($hex) ?>;--cs:<?= e($soft) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int)$t['id'] ?>">
            <span class="pl-type-dot"></span>
            <input class="inp" name="title" value="<?= e($t['title']) ?>" maxlength="80">
            <select class="inp" name="color">
              <?php foreach ($colors as $k => $c): ?><option value="<?= e($k) ?>" <?= (string)$t['color'] === $k ? 'selected' : '' ?>><?= e(Planner::colorLabel($k)) ?></option><?php endforeach; ?>
            </select>
            <select class="inp" name="icon">
              <?php foreach (['check', 'users', 'bell', 'truck', 'eye', 'shield', 'star', 'clock', 'tag', 'money', 'file', 'info'] as $ic): ?>
                <option value="<?= e($ic) ?>" <?= (string)$t['icon'] === $ic ? 'selected' : '' ?>><?= e(Planner::iconLabel($ic)) ?></option>
              <?php endforeach; ?>
            </select>
            <input class="inp" name="sort_order" value="<?= e(fa_digits((string)$t['sort_order'])) ?>" inputmode="numeric" style="max-width:80px">
            <label class="pl-mini-check"><input type="checkbox" name="is_active" value="1" <?= !empty($t['is_active']) ? 'checked' : '' ?>> <span>فعال</span></label>
            <button class="btn sm soft">ذخیره</button>
          </form>
          <form method="post" action="<?= url('app/planner/types/' . (int)$t['id'] . '/delete') ?>" class="pl-type-del" onsubmit="return confirm('این نوع حذف/غیرفعال شود؟')">
            <?= csrf_field() ?><button class="btn danger sm">حذف</button>
          </form>
        <?php endforeach; ?>
        <?php if (!$types): ?><div class="pl-empty">هنوز نوعی تعریف نشده است.</div><?php endif; ?>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>راهنمای کار با برنامه‌ریز</h3></div>
  <div class="card-body pl-help">
    <ul>
      <li><b>تخصیص وظیفه:</b> مدیر می‌تواند رویدادی برای یک کاربر (مثلاً انباردار) ثبت کند و بازهٔ «از تاریخ … تا تاریخ …» بدهد.</li>
      <li><b>ایزوله‌بودن:</b> هر کاربر فقط رویدادهایی را می‌بیند که مسئول آن است یا خودش ساخته؛ مدیر کسب‌وکار همه را می‌بیند.</li>
      <li><b>اعلان:</b> با رسیدن بازهٔ رویداد، به مسئول و سازنده اعلان داده می‌شود (و در زنگ اعلان‌ها دیده می‌شود).</li>
      <li><b>گزارش انجام:</b> مسئول می‌تواند «انجام شد» یا «انجام نشد + دلیل» ثبت کند و در گفت‌وگوی همان رویداد پیام بگذارد.</li>
    </ul>
  </div>
</div>
<?= view('partials/foot') ?>
