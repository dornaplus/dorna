<?= view('partials/public_head', ['title' => $title]) ?>
<?php
$pname = trim((string)($person['first_name'] ?? '') . ' ' . (string)($person['last_name'] ?? ''));
if ($pname === '') $pname = (string)($person['company_name'] ?? 'مشتری');
?>
<div class="portal-wrap">
  <header class="portal-head">
    <div class="portal-brand"><b>فینتو</b><span>پورتال مشتری</span></div>
    <div class="portal-user">
      <span class="portal-av"><?= e(mb_substr($pname, 0, 1)) ?></span>
      <div><b><?= e($pname) ?></b><small class="muted"><?= e($person['code']) ?></small></div>
    </div>
    <a class="btn ghost sm" href="<?= url('portal/logout') ?>"><?= icon('logout', 15) ?> خروج</a>
  </header>

  <div class="portal-body">
    <div class="portal-summary">
      <div class="ps"><span>کل خرید</span><b><?= num($summary['total']) ?></b></div>
      <div class="ps"><span>پرداخت‌شده</span><b class="ok"><?= num($summary['paid']) ?></b></div>
      <div class="ps"><span>ماندهٔ بدهی</span><b class="danger"><?= num($summary['remaining']) ?></b></div>
      <div class="ps"><span>تعداد فاکتور</span><b><?= num($summary['cnt']) ?></b></div>
    </div>

    <?php if ($accounts): ?>
    <div class="card" style="margin-bottom:14px">
      <div class="card-head"><h3><?= icon('bank', 16) ?> روش‌های پرداخت</h3></div>
      <div class="portal-accounts">
        <?php foreach ($accounts as $a): ?>
          <div class="portal-acc">
            <div class="portal-acc-bank"><?= e($a['bank_name']) ?></div>
            <div class="portal-acc-row"><span>صاحب حساب</span><b><?= e($a['account_holder']) ?></b></div>
            <?php if (!empty($a['card_no'])): ?><div class="portal-acc-row"><span>شماره کارت</span><b dir="ltr"><?= e($a['card_no']) ?></b></div><?php endif; ?>
            <?php if (!empty($a['iban'])): ?><div class="portal-acc-row"><span>شبا</span><b dir="ltr"><?= e($a['iban']) ?></b></div><?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-head"><h3><?= icon('receipt', 16) ?> فاکتورهای من</h3><div class="grow"></div>
        <a class="btn ghost sm" href="<?= url('portal/statement') ?>" target="_blank"><?= icon('print', 15) ?> صورت‌حساب</a></div>

      <?php if (!$invoices): ?>
        <div class="pp-empty">فاکتوری ثبت نشده است.</div>
      <?php else: ?>
      <div class="table-wrap"><table class="tbl">
        <thead><tr><th>شماره</th><th>تاریخ</th><th>سررسید</th><th>مبلغ</th><th>پرداخت‌شده</th><th>مانده</th><th>وضعیت</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($invoices as $inv): $rem = (float)$inv['remaining_amount']; ?>
          <tr>
            <td><b><?= e(fa_digits((string)$inv['invoice_no'])) ?></b></td>
            <td><?= e(jdate($inv['invoice_date'])) ?></td>
            <td><?= !empty($inv['due_date']) ? e(jdate($inv['due_date'])) : '—' ?></td>
            <td><?= num($inv['total_amount']) ?></td>
            <td><?= num($inv['paid_amount']) ?></td>
            <td><b class="<?= $rem > 0 ? 'danger' : 'ok' ?>"><?= num($rem) ?></b></td>
            <td><span class="pill st-<?= e($inv['settlement_status']) ?>"><?= e(Meta::enumLabel($inv['settlement_status'])) ?></span></td>
            <td>
              <?php if ($rem > 0): ?>
                <button class="btn soft sm" type="button" data-pr-open="pr<?= (int)$inv['id'] ?>"><?= icon('upload', 14) ?> آپلود رسید</button>
              <?php else: ?><span class="muted small">تسویه شده</span><?php endif; ?>
            </td>
          </tr>
          <?php if ($rem > 0): ?>
          <tr class="pr-row" id="pr<?= (int)$inv['id'] ?>" hidden>
            <td colspan="8">
              <form method="post" action="<?= url('portal/upload-receipt') ?>" enctype="multipart/form-data" class="pr-form">
                <?= csrf_field() ?>
                <input type="hidden" name="invoice_id" value="<?= (int)$inv['id'] ?>">
                <div class="pr-fields">
                  <input class="inp" type="file" name="file" accept=".jpg,.jpeg,.png,.pdf" required>
                  <input class="inp" type="text" name="note" placeholder="توضیح (اختیاری — مثلاً نام واریزکننده)" maxlength="500">
                  <button class="btn sm" type="submit"><?= icon('check', 14) ?> ارسال رسید</button>
                </div>
                <div class="hint">تصویر یا PDF رسید پرداخت را آپلود کنید؛ پس از بررسی کارشناسان، فاکتور تسویه می‌شود.</div>
              </form>
            </td>
          </tr>
          <?php endif; ?>
        <?php endforeach; ?>
        </tbody>
      </table></div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
(function () {
  document.querySelectorAll('[data-pr-open]').forEach(function (b) {
    b.addEventListener('click', function () {
      var row = document.getElementById(b.getAttribute('data-pr-open'));
      if (row) row.hidden = !row.hidden;
    });
  });
})();
</script>
<?= view('partials/public_foot') ?>
