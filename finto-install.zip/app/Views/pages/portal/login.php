<?= view('partials/public_head', ['title' => $title]) ?>
<div class="auth-wrap" style="min-height:100vh">
  <div class="auth-panel" style="max-width:460px;margin:0 auto">
    <div class="auth-card" style="text-align:center">
      <div style="width:56px;height:56px;border-radius:18px;background:linear-gradient(135deg,#8B5CF6,#6D28D9);color:#fff;display:grid;place-items:center;margin:0 auto 12px;font-size:22px;font-weight:700">فن</div>
      <h2 style="font-family:var(--font2);margin:0 0 4px">پورتال مشتری</h2>
      <div class="a-sub">مشاهدهٔ فاکتورها، صورت‌حساب و ثبت رسید پرداخت</div>
      <?php if (!empty($error)): ?><div class="alert error" style="margin-top:14px"><?= e($error) ?></div><?php endif; ?>
      <form method="post" action="<?= url('portal') ?>" style="margin-top:18px">
        <?= csrf_field() ?>
        <div class="field" style="text-align:right"><label>شماره موبایل</label>
          <input class="inp" type="text" name="mobile" value="<?= e($mobile) ?>" placeholder="09121234567" dir="ltr" required autofocus></div>
        <button class="btn block" type="submit"><?= icon('shield', 16) ?> دریافت کد تایید</button>
      </form>
      <div class="small muted" style="margin-top:14px">با شمارهٔ ثبت‌شده در سیستم وارد شوید؛ کد تایید پیامک می‌شود.</div>
    </div>
    <div class="small muted"><a href="<?= url('/') ?>">← بازگشت به صفحه اصلی</a></div>
  </div>
</div>
<?= view('partials/public_foot') ?>
