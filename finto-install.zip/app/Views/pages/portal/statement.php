<?= view('partials/public_head', ['title' => $title]) ?>
<?php
$pname = trim((string)($person['first_name'] ?? '') . ' ' . (string)($person['last_name'] ?? ''));
if ($pname === '') $pname = (string)($person['company_name'] ?? 'مشتری');
$bizName = (string)($business['name'] ?? '');
?>
<div class="portal-wrap">
  <div class="print-page statement">
    <div class="stmt-head">
      <div>
        <h2><?= e($bizName) ?></h2>
        <div class="muted small">صورت‌حساب مشتری</div>
      </div>
      <div class="stmt-meta">
        <div>مشتری: <b><?= e($pname) ?></b></div>
        <div>کد: <?= e($person['code']) ?></div>
        <div>تاریخ: <?= e(jdate(today())) ?></div>
      </div>
    </div>

    <div class="stmt-summary">
      <span>کل خرید: <b><?= num($summary['total']) ?></b></span>
      <span>پرداخت‌شده: <b><?= num($summary['paid']) ?></b></span>
      <span>مانده: <b><?= num($summary['remaining']) ?></b></span>
    </div>

    <table class="tbl">
      <thead><tr><th>شماره</th><th>تاریخ</th><th>سررسید</th><th>مبلغ</th><th>پرداخت‌شده</th><th>مانده</th><th>وضعیت</th></tr></thead>
      <tbody>
      <?php foreach ($invoices as $inv): ?>
        <tr><td><?= e(fa_digits((string)$inv['invoice_no'])) ?></td>
          <td><?= e(jdate($inv['invoice_date'])) ?></td>
          <td><?= !empty($inv['due_date']) ? e(jdate($inv['due_date'])) : '—' ?></td>
          <td><?= num($inv['total_amount']) ?></td>
          <td><?= num($inv['paid_amount']) ?></td>
          <td><?= num($inv['remaining_amount']) ?></td>
          <td><?= e(Meta::enumLabel($inv['settlement_status'])) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>

    <div class="stmt-foot muted small">این صورت‌حساب به‌صورت خودکار از سامانهٔ فینتو تولید شده است.</div>
  </div>
  <div class="no-print" style="text-align:center;margin-top:16px">
    <button class="btn" type="button" onclick="window.print()"><?= icon('print', 15) ?> چاپ</button>
    <a class="btn gray" href="<?= url('portal/dashboard') ?>">بازگشت</a>
  </div>
</div>
<?= view('partials/public_foot') ?>
