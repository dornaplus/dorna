<?= view('partials/public_head', ['title' => $title]) ?>
<div class="auth-wrap" style="min-height:100vh">
  <div class="auth-panel" style="max-width:440px;margin:0 auto">
    <div class="auth-card" style="text-align:center">
      <div style="width:56px;height:56px;border-radius:18px;background:linear-gradient(135deg,#8B5CF6,#6D28D9);color:#fff;display:grid;place-items:center;margin:0 auto 12px"><?= icon('shield', 26) ?></div>
      <h2 style="font-family:var(--font2);margin:0 0 4px">کد تایید</h2>
      <div class="a-sub">کد پیامک‌شده به <b dir="ltr"><?= e($mobile) ?></b> را وارد کنید.</div>
      <?php if (!empty($error)): ?><div class="alert error" style="margin-top:14px"><?= e($error) ?></div><?php endif; ?>
      <?php if (!empty($info)): ?><div class="alert info" style="margin-top:14px"><?= e($info) ?></div><?php endif; ?>
      <form method="post" action="<?= url('portal/verify') ?>" style="margin-top:18px">
        <?= csrf_field() ?>
        <div class="field" style="text-align:right"><label>کد ۶ رقمی</label>
          <input class="inp" type="text" name="code" inputmode="numeric" maxlength="6" placeholder="••••••" dir="ltr" style="text-align:center;letter-spacing:6px;font-size:20px" required autofocus></div>
        <button class="btn block" type="submit"><?= icon('check', 16) ?> ورود</button>
      </form>
      <div class="small muted" style="margin-top:14px"><a href="<?= url('portal') ?>">شماره را اشتباه وارد کردم</a></div>
    </div>
  </div>
</div>
<?= view('partials/public_foot') ?>
