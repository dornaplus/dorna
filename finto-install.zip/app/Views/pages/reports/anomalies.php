<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('shield', 20) ?> ناهنجاری‌های اسناد</h2>
    <span class="muted small">اسناد غیرعادی: مبالغ بسیار بزرگ (بیش از <?= num($a['threshold']) ?> تومان)، تکرار مشکوک و فروش به مشتریان بدحساب.</span>
  </div>
  <div class="page-head-actions">
    <a class="btn gray" href="<?= url('app/reports') ?>">مرکز گزارش‌ها</a>
  </div>
</div>

<div class="grid c3">
  <div class="kpi card red"><div class="dot"><?= icon('shield', 20) ?></div><div class="t">مبالغ بزرگ</div><div class="v"><?= num(count($a['big_invoices'])) ?></div><div class="u">فاکتور</div></div>
  <div class="kpi card gold"><div class="dot"><?= icon('refresh', 20) ?></div><div class="t">تکرار مشکوک</div><div class="v"><?= num(count($a['repetition'])) ?></div><div class="u">الگو</div></div>
  <div class="kpi card"><div class="dot"><?= icon('users', 20) ?></div><div class="t">مشتریان بدحساب</div><div class="v"><?= num(count($a['bad_debt'])) ?></div><div class="u">مشتری</div></div>
</div>

<?php if (!count($a['big_invoices']) && !count($a['repetition']) && !count($a['bad_debt'])): ?>
<div class="pp-empty">ناهنجاری‌ای یافت نشد. 👌</div>
<?php else: ?>

<?php if ($a['big_invoices']): ?>
<div class="card">
  <div class="card-head"><h3><?= icon('shield', 16) ?> مبالغ بسیار بزرگ (آستانه <?= num($a['threshold']) ?> تومان)</h3></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>فاکتور</th><th>مشتری</th><th>تاریخ</th><th>مبلغ</th></tr></thead>
    <tbody><?php foreach ($a['big_invoices'] as $r): ?>
      <tr><td><a href="<?= url('app/invoices/' . (int)$r['id']) ?>"><b><?= e($r['invoice_no']) ?></b></a></td>
        <td><?= e($r['who']) ?></td><td><?= e(jdate($r['invoice_date'])) ?></td>
        <td class="num" style="color:var(--danger)"><?= num($r['total_amount']) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<?php if ($a['repetition']): ?>
<div class="card">
  <div class="card-head"><h3><?= icon('refresh', 16) ?> تکرار مشکوک (چند فاکتور با مبلغ یکسان)</h3></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>مشتری</th><th>مبلغ تکراری</th><th>تعداد</th><th>فاکتورها</th></tr></thead>
    <tbody><?php foreach ($a['repetition'] as $r): ?>
      <tr><td><?= e($r['who']) ?></td>
        <td class="num"><?= num($r['total_amount']) ?></td>
        <td><span class="pill st-partial"><?= num((int)$r['cnt']) ?> بار</span></td>
        <td class="muted small"><?= e($r['first_no']) ?> تا <?= e($r['last_no']) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<?php if ($a['bad_debt']): ?>
<div class="card">
  <div class="card-head"><h3><?= icon('users', 16) ?> فروش به مشتریان بدحساب</h3></div>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>مشتری</th><th>کد</th><th>ماندهٔ معوق</th><th>مجموع فروش</th></tr></thead>
    <tbody><?php foreach ($a['bad_debt'] as $r): ?>
      <tr><td><a href="<?= url('app/persons/' . (int)$r['person_id']) ?>"><?= e($r['who']) ?></a></td>
        <td><?= e($r['code']) ?></td>
        <td class="num" style="color:var(--danger)"><?= num($r['overdue_amount']) ?></td>
        <td class="num"><?= num($r['recent_sales']) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<?php endif; ?>
<?= view('partials/foot') ?>
