<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('spark', 20) ?> گزارش مدیریتی هوشمند</h2>
    <span class="muted small">هر ماه، هوش مصنوعی یک گزارش دو صفحه‌ای از سود/زیان، نقدینگی، مشتریان، هشدارها و ۳ اقدام پیشنهادی می‌سازد.</span>
  </div>
  <div class="page-head-actions">
    <form method="post" action="<?= url('app/management-reports/generate') ?>" style="margin:0"><?= csrf_field() ?>
      <button class="btn" type="submit" <?= $hasCurrent ? 'disabled title="گزارش این ماه ساخته شده است"' : '' ?>><?= icon('spark', 15) ?> ساخت گزارش این ماه</button>
    </form>
  </div>
</div>

<?php if (!$hasCurrent): ?>
<div class="alert info">گزارش مدیریتی ماه «<?= e($currentPeriod) ?>» هنوز ساخته نشده است. روی «ساخت گزارش این ماه» بزنید تا هوش مصنوعی آن را تولید کند.</div>
<?php endif; ?>

<?php if (!$reports): ?>
<div class="pp-empty">هنوز گزارشی ساخته نشده است.</div>
<?php else: ?>
<div class="mr-list">
  <?php foreach ($reports as $r): ?>
    <a class="mr-item" href="<?= url('app/management-reports/' . (int)$r['id']) ?>">
      <span class="mr-item-ic"><?= icon('spark', 20) ?></span>
      <div class="mr-item-b"><b><?= e($r['title']) ?></b>
        <small class="muted">دورهٔ <?= e($r['period']) ?> · تولید: <?= e(jdate($r['created_at'], '/', true)) ?></small></div>
      <span class="mr-item-go">مشاهده →</span>
    </a>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?= view('partials/foot') ?>
