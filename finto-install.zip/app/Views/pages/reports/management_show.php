<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('spark', 20) ?> <?= e($r['title']) ?></h2>
    <span class="muted small">دورهٔ <?= e($r['period']) ?> · <?= e(jdate($r['created_at'], '/', true)) ?></span>
  </div>
  <div class="page-head-actions">
    <a class="btn gray" href="<?= url('app/management-reports') ?>"><?= icon('back', 15) ?> همهٔ گزارش‌ها</a>
    <button class="btn soft" type="button" onclick="window.print()"><?= icon('print', 15) ?> چاپ</button>
  </div>
</div>

<div class="card mr-doc">
  <?= $r['content'] ?>
</div>
<?= view('partials/foot') ?>
