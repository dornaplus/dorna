<?php
/** @var array $rep @var array $cols @var array $rows @var array $totals @var array $filters @var array $business @var array $tpl @var array $filterLabels */
$rep = $rep ?? []; $cols = $cols ?? []; $rows = $rows ?? []; $totals = $totals ?? []; $business = $business ?? [];
$filterLabels = $filterLabels ?? []; $filters = $filters ?? [];
$tpl = $tpl ?? Printing::template('statement');
$grandTotal = 0.0;
foreach ((array)$totals as $v) { if (is_numeric($v)) $grandTotal += (float)$v; }
?>
<?= view('partials/public_head', ['title' => $title ?? 'چاپ گزارش']) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
    <?= view('partials/print_bar', ['back' => url('app/reports/'.($rep['key'] ?? ''))]) ?>
    <?php if (!empty($runError)): ?><div class="alert error"><?= e($runError) ?></div><?php endif; ?>
    <div class="print-head">
        <div class="print-brand">
            <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
            <h1><?= e($business['name'] ?? '') ?></h1>
            <div class="muted sm">
                <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <?= e($business['economic_code']) ?> — <?php endif; ?>
                <?= e($business['address'] ?? '') ?></div>
        </div>
        <div class="end">
            <h2><?= e($rep['title'] ?? 'گزارش') ?></h2>
            <div>تاریخ گزارش: <strong><?= e(jdate(today())) ?></strong></div>
            <?php if ($filters): ?>
                <div class="muted sm">
                    <?php $bits = []; foreach ($filters as $k => $v) { $bits[] = ($filterLabels[$k] ?? $k).': '.e($v); } echo implode(' — ', $bits); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)($rep['key'] ?? 'report')); ?>
    <table class="tbl print-tbl">
        <thead>
        <tr>
            <th style="width:40px">#</th>
            <?php foreach ($cols as $c): ?><th><?= e(Schema::label($rep['view'], $c)) ?></th><?php endforeach; ?>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $i => $r): ?>
            <tr>
                <td class="num"><?= $i + 1 ?></td>
                <?php foreach ($cols as $c): $m = Schema::column($rep['view'], $c) ?? ['type' => 'varchar', 'name' => $c]; ?>
                    <td class="<?= in_array($m['type'], ['decimal','double','float','int','bigint','smallint','tinyint'], true) ? 'num' : '' ?>"><?= report_cell($m, $r[$c] ?? null) ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <?php if ($totals): ?>
        <tfoot>
            <tr><th class="end">جمع کل</th><?php foreach ($cols as $c): ?><th class="num"><?= isset($totals[$c]) ? money($totals[$c]) : '' ?></th><?php endforeach; ?></tr>
        </tfoot>
        <?php endif; ?>
    </table>
    <?php if (!empty($tpl['amount_in_words']) && $grandTotal > 0): ?>
        <div class="words">جمع کل به حروف: <?= e(amount_in_words($grandTotal, currency_title())) ?></div>
    <?php endif; ?>
    <?php if (!empty($tpl['show_bank_info'])) echo Printing::bankBlock(); ?>
    <?php if (!empty($tpl['show_signature'])): ?><div class="signs"><div>تهیه‌کننده</div><div>مدیر مالی</div><div>مدیرعامل</div></div><?php endif; ?>
    <div class="print-foot">
        <span><?= e(config('app')['name']) ?> — <?= e($business['name'] ?? '') ?></span>
        <span><?= num(count($rows), 0) ?> ردیف — چاپ <?= e(jdate(today())) ?> <?= e(date('H:i')) ?></span>
    </div>
</div>
<?= view('partials/public_foot') ?>
