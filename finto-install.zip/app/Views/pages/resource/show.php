<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head">
    <h3><?= e($m['title']) ?> — <?= e($m['singular']) ?> #<?= num($row[Schema::pk($m['table'])[0]]) ?></h3>
    <div class="grow"></div>
    <?php if ($m['key'] === 'payroll-documents' && Auth::can('payroll.view')): ?>
      <a class="btn soft" target="_blank" rel="noopener" href="<?= url('app/payroll-documents/'.$row[Schema::pk($m['table'])[0]].'/print') ?>">چاپ سند</a>
    <?php endif; ?>
    <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
      <a class="btn" href="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/edit') ?>">ویرایش</a>
    <?php endif; ?>
    <a class="btn ghost" href="<?= url('app/'.$m['key']) ?>">بازگشت به فهرست</a>
  </div>
  <div class="form-grid">
    <?php foreach (Schema::columns($m['table']) as $c => $meta): if (in_array($c, Fields::SYSTEM_COLS, true) && !in_array($c, ['journal_entry_id','inventory_doc_id'], true)) continue; ?>
      <div class="field"><label><?= e(Schema::label($m['table'], $c)) ?></label>
        <div><?= Fields::display($m['table'], $c, $row[$c] ?? null, $row) ?></div></div>
    <?php endforeach; ?>
  </div>
</div>

<?= view('partials/ai_insight', ['scope' => 'record', 'module' => $m['key'], 'id' => (string)$row[Schema::pk($m['table'])[0]], 'title' => ($m['singular'] ?: $m['title']) . ' #' . $row[Schema::pk($m['table'])[0]]]) ?>

<?php
// ── قراردادهای کار پرسنل (رابط با تنظیمات حقوق و دستمزد) ──
if ($m['key'] === 'employees' && Auth::can('payroll.view')):
    $eid = (int)$row['id']; $ebiz = (int)Auth::businessId();
    $contracts = Database::all("SELECT * FROM employee_contracts WHERE business_id=? AND employee_id=? AND is_active=1
                                 ORDER BY start_date DESC, id DESC LIMIT 20", [$ebiz, $eid]);
    $activeCt = null; foreach ($contracts as $ct) if ($ct['status'] === 'active') { $activeCt = $ct; break; }
    if ($contracts):
?>
<div class="card">
  <div class="card-head"><h3>قراردادهای کار</h3><div class="grow"></div>
    <span class="pill"><?= num(count($contracts)) ?> قرارداد</span>
    <?php if (Auth::can('payroll.create')): ?>
      <a class="btn sm" href="<?= url('app/payroll/contracts/create?employee_id=' . $eid) ?>">+ ثبت قرارداد جدید</a>
    <?php endif; ?>
    <a class="btn sm ghost" href="<?= url('app/payroll/contracts?employee_id=' . $eid) ?>">فهرست قراردادهای او</a>
  </div>
  <div class="table-wrap"><table class="tbl" style="min-width:600px">
    <thead><tr><th>شماره</th><th>نوع</th><th>شروع</th><th>پایان</th><th>حقوق پایه</th><th>جمع مزایا</th><th>وضعیت</th><th></th></tr></thead>
    <tbody><?php foreach ($contracts as $ct): ?>
      <tr><td><b><?= e(fa_digits((string)$ct['contract_no'])) ?></b></td>
        <td><span class="muted small"><?= e(Payroll::CONTRACT_TYPES[$ct['contract_type']] ?? '') ?></span></td>
        <td><span class="muted small"><?= e(jdate($ct['start_date'])) ?></span></td>
        <td><span class="muted small"><?= e(!empty($ct['end_date']) ? jdate($ct['end_date']) : '—') ?></span></td>
        <td><?= num($ct['base_salary']) ?></td>
        <td><?= num((float)$ct['housing_allowance'] + (float)$ct['food_allowance'] + (float)$ct['child_allowance'] + (float)$ct['other_allowances']) ?></td>
        <td><span class="pill" style="<?= $ct['status'] === 'active' ? 'background:#E7F7EF;color:#047857' : '' ?>"><?= e(Payroll::CONTRACT_STATUS[$ct['status']] ?? $ct['status']) ?></span></td>
        <td><a class="btn sm ghost" href="<?= url('app/payroll/contracts/' . (int)$ct['id']) ?>">مشاهده</a></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; endif; ?>

<?php
// ── ارتباط «اشخاص» با «حقوق و دستمزد»: پروندهٔ پرسنلی و وام‌های ضمانت‌شده ──
if ($m['key'] === 'persons' && Auth::can('payroll.view')):
    $pid = (int)$row['id']; $pbiz = (int)Auth::businessId();
    $empFile = Database::one('SELECT e.*, ws.title AS workshop_title FROM employees e
                                 LEFT JOIN payroll_workshops ws ON ws.id=e.workshop_id
                                WHERE e.business_id=? AND e.person_id=? AND e.deleted_at IS NULL LIMIT 1', [$pbiz, $pid]);
    $guaranteed = Database::all('SELECT l.*, e.full_name, (l.amount - l.paid_amount) AS remaining
                                   FROM employee_loans l JOIN employees e ON e.id=l.employee_id
                                  WHERE l.business_id=? AND l.guarantor_person_id=? AND l.status="active"
                                  ORDER BY l.id DESC LIMIT 20', [$pbiz, $pid]);
    $sal = []; $open = ['advance' => 0, 'loan' => 0]; $ded = [];
    if ($empFile) {
        $ded = Database::one('SELECT IFNULL(SUM(gross_amount),0) gross, IFNULL(SUM(net_amount),0) net, COUNT(*) docs
                                FROM payroll_documents WHERE business_id=? AND deleted_at IS NULL AND status IN ("posted","paid")', [$pbiz]) ?: [];
        $sal = Database::one('SELECT base_salary FROM employee_salary_settings WHERE employee_id=?', [(int)$empFile['id']]) ?: [];
        $open = Payroll::outstanding((int)$empFile['id']);
    }
    if ($empFile || $guaranteed):
?>
<div class="card">
  <div class="card-head"><h3>ارتباط با حقوق و دستمزد</h3><div class="grow"></div>
    <?php if ($empFile): ?><span class="pill">دارای پروندهٔ پرسنلی</span><?php endif; ?>
    <?php if ($guaranteed): ?><span class="pill">ضامن <?= num(count($guaranteed)) ?> وام</span><?php endif; ?>
  </div>
  <?php if ($empFile): ?>
    <div class="table-wrap"><table class="tbl" style="min-width:520px"><tbody>
      <tr><th style="width:190px">پروندهٔ پرسنلی</th>
        <td><b><?= e($empFile['full_name']) ?></b> <span class="muted small">(<?= e($empFile['code']) ?>)</span>
          · <?= e($empFile['job_title'] ?: '—') ?>
          <?php if (!empty($empFile['workshop_title'])): ?> · کارگاه: <?= e($empFile['workshop_title']) ?><?php endif; ?>
          · <span class="pill"><?= e(Meta::enumLabel((string)$empFile['status'])) ?></span></td></tr>
      <tr><th>حقوق پایه</th><td><?= num((float)($sal['base_salary'] ?? 0)) ?> <?= e(Auth::currency()) ?></td></tr>
      <tr><th>ماندهٔ مساعده</th><td><?= num($open['advance'] ?? 0) ?> <?= e(Auth::currency()) ?></td></tr>
      <tr><th>ماندهٔ وام</th><td><?= num($open['loan'] ?? 0) ?> <?= e(Auth::currency()) ?></td></tr>
      <tr><th>جمع اسناد حقوق (کسب‌وکار)</th><td><?= num($ded['gross'] ?? 0) ?> ناخالص · <?= num($ded['net'] ?? 0) ?> خالص · <?= num($ded['docs'] ?? 0) ?> سند</td></tr>
    </tbody></table></div>
    <div class="form-actions">
      <a class="btn sm" href="<?= url('app/employees/' . (int)$empFile['id']) ?>">مشاهدهٔ پرونده</a>
      <a class="btn sm ghost" href="<?= url('app/employees/' . (int)$empFile['id'] . '/edit') ?>">ویرایش پرونده</a>
      <a class="btn sm ghost" href="<?= url('app/payroll/advances?employee_id=' . (int)$empFile['id']) ?>">مساعده‌های او</a>
      <a class="btn sm ghost" href="<?= url('app/payroll/loans?employee_id=' . (int)$empFile['id']) ?>">وام‌های او</a>
      <a class="btn sm ghost" href="<?= url('app/payroll/report?employee_id=' . (int)$empFile['id']) ?>">گزارش حقوق او</a>
    </div>
  <?php endif; ?>
  <?php if ($guaranteed): ?>
    <div class="table-wrap" style="margin-top:8px"><table class="tbl" style="min-width:520px">
      <thead><tr><th>وام</th><th>پرسنل</th><th>مبلغ وام</th><th>مانده</th><th>وضعیت</th></tr></thead>
      <tbody><?php foreach ($guaranteed as $g): ?>
        <tr><td><?= e(fa_digits((string)$g['loan_no'])) ?></td><td><?= e($g['full_name']) ?></td>
          <td><?= num($g['amount']) ?></td><td><?= num($g['remaining']) ?></td>
          <td><?= e(Payroll::LOAN_STATUS[$g['status']] ?? $g['status']) ?></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <div class="form-actions"><a class="btn sm ghost" href="<?= url('app/payroll/loans') ?>">فهرست وام‌ها</a></div>
  <?php endif; ?>
</div>
<?php endif; endif; ?>


<?php foreach ($children as $ch): $def = $ch['def']; ?>
<div class="card">
  <div class="card-head"><h3><?= e($def['title']) ?></h3><span class="pill"><?= num(count($ch['rows'])) ?> ردیف</span><div class="grow"></div>
    <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
      <button class="btn sm" data-modal="modal-child-<?= e($def['table']) ?>" type="button">+ افزودن</button>
    <?php endif; ?>
  </div>
  <?php if (!$ch['rows']): ?>
    <div class="muted small">ردیفی ثبت نشده است.</div>
  <?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:520px">
      <thead><tr><?php foreach ($def['list'] as $c): ?><th><?= e(Schema::label($def['table'], $c)) ?></th><?php endforeach; ?>
        <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?><th>عملیات</th><?php endif; ?></tr></thead>
      <tbody>
      <?php foreach ($ch['rows'] as $cr): ?>
        <tr>
          <?php foreach ($def['list'] as $c): ?><td><?= Fields::display($def['table'], $c, $cr[$c] ?? null, $cr) ?></td><?php endforeach; ?>
          <?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
            <td class="acts">
              <form method="post" data-confirm="این ردیف حذف شود؟" action="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/child/'.$def['table'].'/'.$cr[Schema::pk($def['table'])[0]].'/delete') ?>" style="display:inline">
                <?= csrf_field() ?><button class="btn danger sm">حذف</button>
              </form>
            </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</div>
<?php if (!$m['readonly'] && Auth::can(($m['perm'] ?: 'x').'.edit')): ?>
<div class="modal-backdrop" id="modal-child-<?= e($def['table']) ?>">
  <div class="modal">
    <h3>افزودن به <?= e($def['title']) ?></h3>
    <form method="post" action="<?= url('app/'.$m['key'].'/'.$row[Schema::pk($m['table'])[0]].'/child/'.$def['table']) ?>">
      <?= csrf_field() ?>
      <?php
        $childGroups = Fields::groups($def['table'], ['hide' => array_merge([$def['fk'], 'id', 'business_id', 'created_at', 'created_by', 'updated_at', 'updated_by', 'deleted_at', 'row_version'])]);
        $requiredFields = []; $optionalFields = [];
        foreach ($childGroups as $fields) foreach ($fields as $f) { if ($f['required']) $requiredFields[] = $f; else $optionalFields[] = $f; }
      ?>
      <div class="grid c2" style="gap:0 12px">
        <?php foreach ($requiredFields as $f): ?><?= Fields::render($f, null, []) ?><?php endforeach; ?>
      </div>
      <?php if ($optionalFields): ?>
      <details style="margin:10px 0">
        <summary class="muted small" style="cursor:pointer">سایر فیلدها</summary>
        <div class="grid c2" style="gap:0 12px">
          <?php foreach ($optionalFields as $f): ?><?= Fields::render($f, null, []) ?><?php endforeach; ?>
        </div>
      </details>
      <?php endif; ?>
      <div class="form-actions"><button class="btn" type="submit">افزودن</button><button class="btn gray" data-close type="button">بستن</button></div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php endforeach; ?>
<?= view('partials/foot') ?>
