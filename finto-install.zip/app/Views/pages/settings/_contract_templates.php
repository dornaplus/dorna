<?php
/** ادیتور متن قراردادها (تب «متن قرارداد» در تنظیمات حقوق) */
$templates = $templates ?? [];
$editing = $editing ?? null;
$tokenList = Payroll::CONTRACT_TOKENS;
$cur = Auth::currency();
$preview = $preview ?? null;
?>
<div class="card-head"><h3>متن قرارداد کار</h3><div class="grow"></div>
  <span class="pill"><?= num(count($templates)) ?> قالب</span>
</div>
<div class="card-body">
  <div class="help" style="margin-bottom:8px">
    متن قرارداد را با جانگهدارها بنویسید؛ هنگام چاپ قرارداد هر پرسنل، این جانگهدارها با اطلاعات واقعی او پر می‌شوند.
    می‌توانید <b>چند متن</b> بسازید و یکی را <b>پیش‌فرض</b> کنید.
  </div>

  <div class="row" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">
    <?php foreach ($templates as $t): ?>
      <a class="btn sm <?= (int)($editing['id'] ?? 0) === (int)$t['id'] ? '' : 'ghost' ?>"
         href="<?= url('app/settings/hr?tab=contracts&template=' . (int)$t['id']) ?>">
        <?= e($t['title']) ?><?= !empty($t['is_default']) ? ' ★' : '' ?></a>
    <?php endforeach; ?>
    <a class="btn sm ghost" href="<?= url('app/settings/hr?tab=contracts&template=new') ?>">+ متن جدید</a>
  </div>

  <input type="hidden" name="tpl_action" id="tplAction" value="">
  <input type="hidden" name="tpl_id" value="<?= (int)($editing['id'] ?? 0) ?>">

  <div class="grid-2b" style="align-items:start">
    <div>
      <div class="grid-2b">
        <div class="field"><label>عنوان قالب</label>
          <input class="inp" name="tpl_title" value="<?= e((string)($editing['title'] ?? 'قرارداد کار')) ?>" placeholder="مثال: قرارداد مدت معین یک‌ساله"></div>
        <div class="field"><label>یادداشت</label>
          <input class="inp" name="tpl_note" value="<?= e((string)($editing['note'] ?? '')) ?>"></div>
      </div>

      <div class="field">
        <label>متن قرارداد</label>
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin:4px 0">
          <button class="btn sm ghost" type="button" onclick="tplInsert('\n')">خط جدید</button>
          <button class="btn sm ghost" type="button" onclick="tplInsert('امضای کارفرما / نمایندهٔ قانونی: .....................')">امضای کارفرما</button>
          <button class="btn sm ghost" type="button" onclick="tplInsert('امضای کارگر: .....................')">امضای کارگر</button>
          <button class="btn sm ghost" type="button" onclick="tplInsert('$[today]$')">تاریخ امروز</button>
        </div>
        <textarea class="inp wide" name="tpl_body" id="tplBody" rows="20" style="font-family:var(--font2);line-height:1.9"
                  dir="rtl"><?= e((string)($editing['body'] ?? Payroll::DEFAULT_CONTRACT_BODY)) ?></textarea>
        <div class="help"><span id="tplCount">0</span> کاراکتر — برای پیش‌نمایش، یک پرسنل را انتخاب کنید.</div>
      </div>

      <div class="section-title">جانگهدارها (برای درج، روی هر دکمه بزنید)</div>
      <div style="display:flex;gap:6px;flex-wrap:wrap;max-height:190px;overflow:auto">
        <?php foreach ($tokenList as $tk => $label): ?>
          <button class="btn sm ghost" type="button" title="<?= e($label) ?>" onclick="tplInsert('$[<?= e($tk) ?>]$')">$[<?= e($tk) ?>]$</button>
        <?php endforeach; ?>
      </div>

      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
        <button class="btn btn-p" type="submit" onclick="document.getElementById('tplAction').value='save'">ذخیرهٔ متن</button>
        <button class="btn" type="submit" onclick="document.getElementById('tplAction').value='new'">ذخیره به‌عنوان متن جدید</button>
        <button class="btn ghost" type="submit" onclick="document.getElementById('tplAction').value='default'">تعیین به‌عنوان پیش‌فرض</button>
        <button class="btn ghost" type="submit" style="color:#E11D48"
                onclick="return confirm('این متن حذف شود؟') && (document.getElementById('tplAction').value='delete')">حذف متن</button>
      </div>
    </div>

    <div>
      <div class="section-title">پیش‌نمایش با اطلاعات پرسنل</div>
      <form method="get" action="<?= url('app/settings/hr') ?>" class="filters" style="border:none;padding:0">
        <input type="hidden" name="tab" value="contracts">
        <input type="hidden" name="template" value="<?= (int)($editing['id'] ?? 0) ?>">
        <div class="field" style="min-width:220px"><label>پرسنل</label>
          <select class="inp select-search" name="preview_employee" onchange="this.form.submit()">
            <option value="">— انتخاب پرسنل —</option>
            <?php foreach (($employees ?? []) as $e): ?>
              <option value="<?= (int)$e['id'] ?>" <?= (int)($previewEmp ?? 0) === (int)$e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option>
            <?php endforeach; ?>
          </select></div>
      </form>
      <div class="card" style="background:#F8FAFC;margin-top:8px;max-height:640px;overflow:auto">
        <div class="card-body" style="white-space:pre-wrap;line-height:2;font-size:13px" id="tplPreviewBox"><?= e((string)($preview['body'] ?? 'برای پیش‌نمایش، پرسنل را انتخاب کنید.')) ?></div>
      </div>
      <?php if (!empty($preview['template'])): ?>
        <div class="help">پیش‌نمایش با قالب «<?= e((string)$preview['template']['title']) ?>» و اطلاعات واقعی پرسنل تولید شده است.</div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
function tplInsert(text) {
  var ta = document.getElementById('tplBody'); if (!ta) return;
  var s = ta.selectionStart || 0, e = ta.selectionEnd || 0;
  ta.value = ta.value.slice(0, s) + text + ta.value.slice(e);
  ta.focus(); ta.selectionStart = ta.selectionEnd = s + text.length;
  tplCount();
}
function tplCount() { var ta = document.getElementById('tplBody'), c = document.getElementById('tplCount'); if (ta && c) c.textContent = ta.value.length; }
document.addEventListener('DOMContentLoaded', function () { tplCount(); var ta = document.getElementById('tplBody'); if (ta) ta.addEventListener('input', tplCount); });
</script>
