<?= view('partials/head', ['title' => $title]) ?>
<?php $cfg = $cfg ?? []; $connected = $connected ?? false; ?>
<div class="page-head">
  <div>
    <h2><?= icon('spark') ?> تنظیمات هوش مصنوعی</h2>
    <div class="muted sm">اتصال به سرویس هوش مصنوعی برای دستیار، پیشنهاد حساب و خلاصهٔ مدیریتی.</div>
  </div>
  <div class="actions">
    <span class="badge <?= $connected ? 'on' : 'off' ?>"><?= $connected ? 'متصل' : 'غیرفعال' ?></span>
    <a class="btn ghost sm" href="<?= url('app/assistant') ?>"><?= icon('spark') ?> دستیار</a>
  </div>
</div>

<?php if (!empty($error)): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

<form method="post" action="<?= url('app/settings/ai') ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3>اتصال سرویس</h3><div class="grow"></div>
      <span class="muted sm">سازگار با OpenAI · پیش‌فرض: AvalAI</span></div>

    <div class="fs">
      <div class="fs-title"><span class="ttl-ic"><?= icon('spark', 15) ?></span> وضعیت و مدل</div>
      <div class="grid c2">
        <label class="field"><span>فعال بودن دستیار هوشمند</span>
          <div class="switch-row" style="display:flex;align-items:center;gap:10px">
            <label class="switch"><input type="checkbox" name="enabled" value="1" <?= !empty($cfg['enabled']) ? 'checked' : '' ?>><span></span></label>
            <span class="muted sm">در صورت خاموش بودن، دکمه‌های هوش مصنوعی نمایش داده نمی‌شوند.</span>
          </div>
        </label>
        <label class="field"><span>حالت تفکری مدل (کندتر، دقیق‌تر)</span>
          <div class="switch-row" style="display:flex;align-items:center;gap:10px">
            <label class="switch"><input type="checkbox" name="thinking" value="1" <?= !empty($cfg['thinking']) ? 'checked' : '' ?>><span></span></label>
            <span class="muted sm">برای سرعت و هزینهٔ کمتر توصیه می‌شود خاموش بماند.</span>
          </div>
        </label>
      </div>
      <div class="grid c2">
        <label class="field"><span>مدل</span>
          <input class="inp" type="text" name="model" dir="ltr" value="<?= e($cfg['model'] ?? 'deepseek-v4.1-flash') ?>" placeholder="deepseek-v4.1-flash">
          <div class="hint">مثال: <code dir="ltr">deepseek-v4.1-flash</code></div>
        </label>
        <label class="field"><span>آدرس پایه (Base URL)</span>
          <input class="inp" type="text" name="base_url" dir="ltr" value="<?= e($cfg['base_url'] ?? 'https://api.avalai.ir/v1') ?>">
          <div class="hint">هر سرویس سازگار با OpenAI پذیرفته می‌شود.</div>
        </label>
      </div>
    </div>

    <div class="fs">
      <div class="fs-title"><span class="ttl-ic"><?= icon('shield', 15) ?></span> کلید دسترسی</div>
      <label class="field"><span>API Key</span>
        <div class="input-wrap">
          <input class="inp" type="password" name="api_key" dir="ltr" id="aiKey" placeholder="<?= $maskedKey !== '' ? e($maskedKey) : 'کلید API را وارد کنید…' ?>" autocomplete="off">
          <button type="button" class="toggle-pass" data-toggle-pass="aiKey" aria-label="نمایش کلید"><?= icon('eye', 18) ?></button>
        </div>
        <div class="hint">برای تغییر کلید، مقدار جدید را وارد کنید؛ در غیر این صورت کلید فعلی حفظ می‌شود.</div>
      </label>
    </div>

    <div class="form-actions">
      <button class="btn success" type="submit"><?= icon('check') ?> ذخیره تنظیمات هوش مصنوعی</button>
    </div>
  </div>
</form>

<div class="card" style="margin-top:12px">
  <div class="card-head"><h3>راهنما</h3></div>
  <ul class="help" style="line-height:2">
    <li>کلید و مدل برای همان کسب‌وکار ذخیره می‌شود؛ اگر خالی بماند، مقدار پیش‌فرض فایل <code>config.php</code> استفاده می‌شود.</li>
    <li>برای امنیت بیشتر می‌توانید کلید را در متغیر محیطی <code>AVALAI_API_KEY</code> یا <code>config.local.php</code> نگه دارید.</li>
    <li>تمام درخواست‌ها فقط-خواندنی و محدود به دادهٔ همین کسب‌وکار هستند.</li>
  </ul>
</div>
<?= view('partials/foot') ?>
