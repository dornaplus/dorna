<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head">
    <h3><?= icon('database') ?> پشتیبان‌گیری از داده‌های «<?= e(Auth::business()['name'] ?? '') ?>»</h3>
    <div class="grow"></div>
    <form method="post" action="<?= url('app/backups') ?>" style="display:inline">
      <?= csrf_field() ?>
      <button class="btn" type="submit" <?= Auth::can('backup.create') ? '' : 'disabled' ?>><?= icon('download', 16) ?> گرفتن پشتیبان جدید</button>
    </form>
  </div>
  <div class="help">
    با هر بار زدن دکمه، همهٔ داده‌های این کسب‌وکار (اشخاص، کالا، فاکتورها، اسناد، خزانه، انبار، تنظیمات و …) پشتیبان گرفته می‌شود و روی سرور ذخیره می‌گردد.
    دو فایل ساخته می‌شود: <b>JSON</b> (برای بازگردانی) و <b>CSV</b> (همهٔ بخش‌ها در یک فایل، برای اکسل).
    <br><b>پشتیبان هر کسب‌وکار کاملاً مستقل است</b> و هیچ‌گاه در داده‌های کسب‌وکارهای دیگر دیده یا بازگردانی نمی‌شود.
  </div>
</div>

<?php if (!empty($result)): ?>
  <div class="card" style="margin-top:12px">
    <div class="card-head"><h3>نتیجهٔ آخرین بازگردانی</h3></div>
    <div class="help"><?= e($result) ?></div>
  </div>
<?php endif; ?>

<div class="card" style="margin-top:12px">
  <div class="card-head"><h3><?= icon('upload') ?> بازگردانی از فایل پشتیبان</h3></div>
  <form method="post" action="<?= url('app/backups/import') ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
      <input type="file" name="backup_file" accept=".json,.csv,application/json,text/csv" required
             style="flex:1 1 260px;min-width:220px;padding:8px;border:1px solid var(--line);border-radius:12px;background:#fff">
      <button class="btn" type="submit" <?= Auth::can('backup.create') ? '' : 'disabled' ?>
              onclick="return confirm('بازگردانی، داده‌های فعلی این کسب‌وکار را با فایل پشتیبان جایگزین می‌کند. ادامه می‌دهید؟')">
        <?= icon('upload', 16) ?> بازگردانی کن
      </button>
    </div>
    <div class="help" style="margin-top:8px">
      فایل <b>JSON</b> یا <b>CSV</b> که از همین سامانه گرفته‌اید قابل بازگردانی است.
      پیش از بازگردانی، یک <b>پشتیبان ایمنی</b> از وضعیت فعلی خودکار گرفته می‌شود.
      فقط داده‌های همین کسب‌وکار جایگزین می‌شود و سایر کسب‌وکارها دست‌نخورده می‌مانند.
    </div>
  </form>
</div>

<div class="card" style="margin-top:12px">
  <div class="card-head"><h3>پشتیبان‌های ذخیره‌شده</h3><div class="grow"></div>
    <span class="pill"><?= num(count($jobs)) ?> فایل</span></div>
  <div class="table-wrap">
    <table class="tbl" style="min-width:760px">
      <thead><tr><th>#</th><th>تاریخ</th><th>نوع</th><th>حجم</th><th>ردیف</th><th>وضعیت</th><th>دانلود</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($jobs as $j): ?>
        <tr>
          <td class="num" dir="ltr"><?= num((int)$j['id']) ?></td>
          <td><?= e(jdate($j['created_at'], '/', true)) ?></td>
          <td><span class="pill"><?= $j['job_type'] === 'manual' ? 'دستی' : 'خودکار' ?></span></td>
          <td class="num"><?= num((float)($j['size_mb'] ?? 0), 2) ?> MB</td>
          <td class="num"><?= num((int)($j['row_count'] ?? 0)) ?></td>
          <td>
            <?php $st = ['success' => ['active', 'موفق'], 'failed' => ['cancelled', 'ناموفق'], 'running' => ['pending', 'در حال اجرا']][$j['status']] ?? ['pending', $j['status']]; ?>
            <span class="pill st-<?= $st[0] ?>"><?= e($st[1]) ?></span>
          </td>
          <td>
            <?php if ($j['status'] === 'success' && !empty($j['file_name'])): ?>
              <a class="btn ghost sm" target="_blank" rel="noopener" title="فایل پشتیبان برای بازگردانی"
                 href="<?= url('app/backups/' . (int)$j['id'] . '/download?format=json') ?>"><?= icon('download', 14) ?> پشتیبان (JSON)</a>
              <a class="btn ghost sm" target="_blank" rel="noopener" title="خروجی CSV همهٔ بخش‌ها"
                 href="<?= url('app/backups/' . (int)$j['id'] . '/download?format=csv') ?>"><?= icon('table', 14) ?> CSV</a>
            <?php else: ?><span class="muted small">—</span><?php endif; ?>
          </td>
          <td>
            <form method="post" action="<?= url('app/backups/' . (int)$j['id'] . '/delete') ?>" style="display:inline"
                  onsubmit="return confirm('این پشتیبان حذف شود؟')">
              <?= csrf_field() ?>
              <button class="btn ghost sm" type="submit">حذف</button>
            </form>
          </td>
        </tr>
        <?php if (!empty($j['error_message'])): ?>
          <tr><td colspan="8" class="muted small"><?= e($j['error_message']) ?></td></tr>
        <?php endif; ?>
      <?php endforeach; ?>
      <?php if (!$jobs): ?><tr><td colspan="8" class="muted small">هنوز پشتیبانی گرفته نشده است.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= view('partials/foot') ?>
