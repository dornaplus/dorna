<?= view('partials/head', ['title' => $title]) ?>
<?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post" action="<?= url('app/settings/business') ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <?php $logoImg = $logoImg ?? ''; ?>
  <div class="card">
    <div class="card-head"><h3>اطلاعات کسب‌وکار</h3>
      <span class="pill"><?= e($biz['name'] ?? '') ?></span>
      <span class="pill st-<?= e($biz['status'] ?? 'faal') ?>"><?= e(Meta::enumLabel($biz['status'] ?? '')) ?></span>
      <div class="grow"></div><a class="btn ghost sm" href="<?= url('app') ?>">داشبورد</a></div>
    <?php foreach ($groups as $gtitle => $fields): ?>
      <div class="section-title"><?= e($gtitle) ?></div>
      <div class="form-grid">
        <?php foreach ($fields as $f): ?><?= Fields::render($f, $biz[$f['name']] ?? null, ['row' => $biz]) ?><?php endforeach; ?>
      </div>
    <?php endforeach; ?>
  </div>
  <div class="card">
    <div class="card-head"><h3>لوگوی کسب‌وکار (سربرگ چاپ)</h3>
      <div class="grow"></div>
      <span class="pill <?= $logoImg ? 'st-active' : '' ?>"><?= $logoImg ? 'تنظیم شده' : 'تنظیم نشده' ?></span></div>
    <div style="display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap">
      <div style="min-width:190px;min-height:96px;border:1px dashed var(--line);border-radius:12px;display:flex;align-items:center;justify-content:center;padding:10px;background:#fff">
        <?= $logoImg ?: '<span class="muted sm">تصویری بارگذاری نشده است</span>' ?>
      </div>
      <div style="flex:1;min-width:240px">
        <label class="field"><span>انتخاب تصویر (JPG / PNG / WEBP — حداکثر ۳ مگابایت)</span>
          <input type="file" name="logo" accept="image/png,image/jpeg,image/webp,image/gif"></label>
        <p class="muted sm" style="margin:6px 0">اندازهٔ پیشنهادی ۴۰۰×۱۲۰ پیکسل با پس‌زمینهٔ شفاف. این تصویر در سربرگ همهٔ چاپ‌ها نمایش داده می‌شود؛ به شرطی که «نمایش لوگو» در قالب چاپ فعال باشد.</p>
        <?php if ($logoImg): ?><label class="checkbox"><input type="checkbox" name="remove_logo" value="1"><span class="small">حذف لوگوی فعلی</span></label><?php endif; ?>
      </div>
    </div>
  </div>
  <div class="grid c3">
    <div class="card"><div class="card-head"><h3>واحد پول پایه</h3></div>
      <div class="table-wrap"><table class="tbl" style="min-width:260px">
        <thead><tr><th>واحد پول</th><th>نماد</th><th>پایه</th></tr></thead>
        <tbody><?php foreach ($currencies as $c): ?>
          <tr><td><?= e($c['title']) ?></td><td><?= e($c['symbol']) ?></td><td><?= !empty($c['is_base']) ? '<span class="pill st-active">پایه</span>' : '—' ?></td></tr>
        <?php endforeach; ?></tbody></table></div></div>
    <div class="card"><div class="card-head"><h3>استان‌ها</h3></div>
      <div class="checkgrid"><?php foreach ($provinces as $pr): ?><span class="badge off"><?= e($pr['title']) ?></span><?php endforeach; ?></div></div>
    <div class="card"><div class="card-head"><h3>شهرها</h3></div>
      <div class="checkgrid"><?php foreach ($cities as $ct): ?><span class="badge off"><?= e($ct['title']) ?></span><?php endforeach; ?></div></div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره اطلاعات کسب‌وکار</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a>
    <div class="spacer"></div>
    <a class="btn ghost" href="<?= url('app/subscription') ?>">اشتراک من</a>
    <a class="btn ghost" href="<?= url('app/settings/hr') ?>">تنظیمات حقوق و دستمزد</a>
  </div></div>
</form>
<?= view('partials/foot') ?>
