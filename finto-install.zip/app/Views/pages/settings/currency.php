<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('bank', 20) ?> نرخ ارز</h2>
    <span class="muted small">نرخ لحظه‌ای خرید و فروش ارزهای خارجی — برای تسعیر اسناد و فاکتورها استفاده می‌شود.</span>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>به‌روزرسانی نرخ‌ها</h3><span class="muted small">تاریخ: <?= e(jdate($today)) ?></span></div>
  <form method="post" action="<?= url('app/settings/currency') ?>">
    <?= csrf_field() ?>
    <div class="table-wrap"><table class="tbl">
      <thead><tr><th>ارز</th><th>کد</th><th>نرخ خرید (تومان)</th><th>نرخ فروش (تومان)</th><th>آخرین نرخ</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $row): $c = $row['currency']; $r = $row['rate']; ?>
        <tr>
          <td><b><?= e($c['title']) ?></b> <span class="muted small"><?= e($c['symbol'] ?? '') ?></span></td>
          <td class="muted small" dir="ltr"><?= e($c['code']) ?></td>
          <td><input type="hidden" name="currency_id[]" value="<?= (int)$c['id'] ?>">
            <input class="inp money" type="text" name="buy_rate[]" value="<?= $r ? num($r['buy_rate'], 0) : '' ?>" placeholder="—"></td>
          <td><input class="inp money" type="text" name="sell_rate[]" value="<?= $r ? num($r['sell_rate'], 0) : '' ?>" placeholder="—"></td>
          <td class="muted small"><?= $r ? num($r['avg_rate'], 0) . ' (' . e(jdate($r['rate_date'])) . ')' : '—' ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <div class="form-actions"><button class="btn"><?= icon('check', 15) ?> ثبت نرخ‌ها</button></div>
  </form>
</div>
<?= view('partials/foot') ?>
