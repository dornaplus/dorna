<?= view('partials/head', ['title' => $title]) ?>
<div class="tabs" data-tabs="#hr-scope" style="margin-bottom:12px">
  <a class="on" data-tab="#tab-hr">تنظیمات حقوق و دستمزد</a>
  <a data-tab="#tab-comp">اجزای حقوق</a>
  <a data-tab="#tab-extras">مرخصی و دستگاه‌ها</a>
  <a data-tab="#tab-contracts">قراردادها و عیدی</a>
  <a data-tab="#tab-templates">متن قرارداد</a>
</div>
<form method="post" action="<?= url('app/settings/hr') ?>">
  <?= csrf_field() ?>
  <div id="hr-scope">
    <div class="card" data-tab="#tab-hr" id="tab-hr">
      <div class="card-head"><h3>پارامترهای حقوق و دستمزد</h3>
        <div class="grow"></div><a class="btn ghost sm" href="<?= url('app/payroll-documents/create') ?>">ثبت سند حقوق</a></div>
      <?= view('pages/settings/_settings_form', ['groups' => $groups]) ?>
    </div>

    <div class="card" data-tab="#tab-comp" id="tab-comp" hidden>
      <div class="card-head"><h3>اجزای حقوق</h3><span class="pill"><?= num(count($components)) ?></span></div>
      <div class="table-wrap"><table class="tbl" style="min-width:760px">
        <thead><tr><th>عنوان</th><th>نوع</th><th>روش محاسبه</th><th>درصد</th><th>مبلغ پیش‌فرض</th><th>حساب</th></tr></thead>
        <tbody><?php foreach ($components as $c): ?>
          <tr>
            <td><?= e($c['title']) ?></td>
            <td><span class="pill"><?= e(Meta::enumLabel($c['component_kind'])) ?></span></td>
            <td><?= e(Meta::enumLabel($c['calc_type'])) ?></td>
            <td><input class="inp" type="number" step="any" name="component[<?= (int)$c['id'] ?>][rate_percent]" value="<?= e($c['rate_percent']) ?>"></td>
            <td><input class="inp money" type="text" name="component[<?= (int)$c['id'] ?>][default_amount]" value="<?= e(num((float)$c['default_amount'])) ?>"></td>
            <td class="muted small"><?= e($c['account_title'] ?? '—') ?></td>
          </tr>
        <?php endforeach; ?></tbody></table></div>
      <div class="section-title">افزودن جزء جدید</div>
      <div class="form-grid">
        <div class="field"><label>عنوان</label><input class="inp" type="text" name="new_component_title"></div>
        <div class="field"><label>نوع</label><select class="inp" name="new_component_kind">
          <option value="earning">مزایا</option><option value="deduction">کسورات</option><option value="employer">سهم کارفرما</option></select></div>
        <div class="field"><label>روش محاسبه</label><select class="inp" name="new_component_calc">
          <option value="fixed">مبلغ ثابت</option><option value="percent_of_base">درصد از حقوق پایه</option><option value="percent_of_gross">درصد از جمع حقوق</option></select></div>
        <div class="field"><label>درصد</label><input class="inp" type="number" step="any" name="new_component_rate" value="0"></div>
        <div class="field"><label>مبلغ پیش‌فرض</label><input class="inp money" type="text" name="new_component_amount" value="0"></div>
        <div class="field"><label>حساب</label><select class="inp select-search" name="new_component_account"><option value="">— انتخاب —</option>
          <?php foreach ($accounts as $a): ?><option value="<?= $a['id'] ?>"><?= e($a['code'].' — '.$a['title']) ?></option><?php endforeach; ?></select></div>
      </div>
    </div>

    <div class="card" data-tab="#tab-extras" id="tab-extras" hidden>
      <div class="grid c3">
        <div>
          <div class="section-title">انواع مرخصی</div>
          <div class="table-wrap"><table class="tbl" style="min-width:240px"><thead><tr><th>عنوان</th><th>استحقاقی</th><th>سقف روز</th></tr></thead>
            <tbody><?php foreach ($leaveTypes as $l): ?><tr><td><?= e($l['title']) ?></td><td><?= !empty($l['is_paid']) ? 'بله' : 'خیر' ?></td><td class="num"><?= num($l['annual_quota_days']) ?></td></tr><?php endforeach; ?>
            <?php if (!$leaveTypes): ?><tr><td colspan="3" class="muted small">موردی ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
          <div class="form-actions" style="border:none;padding:0"><a class="btn ghost sm" href="<?= url('app/leave-types/create') ?>">+ نوع مرخصی</a></div>
        </div>
        <div>
          <div class="section-title">دستگاه‌های حضور و غیاب</div>
          <div class="table-wrap"><table class="tbl" style="min-width:280px"><thead><tr><th>عنوان</th><th>نوع</th><th>آدرس</th><th>آخرین همگام‌سازی</th></tr></thead>
            <tbody><?php foreach ($devices as $d): ?><tr><td><?= e($d['title']) ?></td><td><?= e(Meta::enumLabel($d['device_type'])) ?></td><td dir="ltr" class="muted small"><?= e($d['ip_address'] ?? '—') ?></td>
              <td class="muted small"><?= e($d['last_sync_at'] ? jdate($d['last_sync_at'], '/', true) : '—') ?></td></tr><?php endforeach; ?>
            <?php if (!$devices): ?><tr><td colspan="4" class="muted small">دستگاهی ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
          <div class="form-actions" style="border:none;padding:0"><a class="btn ghost sm" href="<?= url('app/attendance-devices/create') ?>">+ دستگاه جدید</a></div>
        </div>
        <div>
          <div class="section-title">راهنما</div>
          <div class="help">
            اجزای حقوق در سند حقوق و دستمزد استفاده می‌شوند؛ سهم کارفرما به هزینه اضافه و کسورات از خالص کسر می‌شود.
           نرخ بیمه و مالیات را می‌توانید در تب اول تغییر دهید.
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="card" data-tab="#tab-templates" id="tab-templates" hidden>
    <?= view('pages/settings/_contract_templates', ['templates' => $templates ?? [], 'editing' => $editing ?? null,
        'preview' => $preview ?? null, 'previewEmp' => $previewEmp ?? 0, 'employees' => $employees ?? []]) ?>
  </div>

  <div class="card" data-tab="#tab-contracts" id="tab-contracts" hidden>
    <div class="card-head"><h3>قراردادهای کار</h3><div class="grow"></div>
      <span class="pill"><?= num((int)($contracts['total'] ?? 0)) ?> قرارداد</span>
      <a class="btn sm ghost" href="<?= url('app/payroll/contracts') ?>">فهرست قراردادها</a>
      <?php if (Auth::can('payroll.create')): ?><a class="btn sm" href="<?= url('app/payroll/contracts/create') ?>">+ ثبت قرارداد جدید</a><?php endif; ?>
    </div>
    <div class="row" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:8px">
      <span class="pill">جاری: <?= num((int)($contracts['active'] ?? 0)) ?></span>
      <span class="pill">پیش‌نویس: <?= num((int)($contracts['draft'] ?? 0)) ?></span>
      <span class="pill">پایان‌یافته: <?= num((int)($contracts['expired'] ?? 0)) ?></span>
      <span class="pill">فسخ: <?= num((int)($contracts['terminated'] ?? 0)) ?></span>
    </div>
    <?php if (!empty($expiring)): ?>
      <div class="alert" style="background:#FFFBEB;border-color:#FDE68A;color:#92400E">⚠️ <?= num(count($expiring)) ?> قرارداد تا ۶۰ روز آینده به پایان می‌رسد.</div>
    <?php endif; ?>
    <div class="table-wrap"><table class="tbl" style="min-width:620px">
      <thead><tr><th>شماره</th><th>پرسنل</th><th>نوع</th><th>شروع</th><th>پایان</th><th>حقوق پایه</th><th>وضعیت</th><th></th></tr></thead>
      <tbody><?php foreach (($recentContracts ?? []) as $c): ?>
        <tr><td><?= e(fa_digits((string)$c['contract_no'])) ?></td><td><?= e($c['full_name']) ?></td>
          <td><span class="muted small"><?= e(Payroll::CONTRACT_TYPES[$c['contract_type']] ?? '') ?></span></td>
          <td><span class="muted small"><?= e(jdate($c['start_date'])) ?></span></td>
          <td><span class="muted small"><?= e(!empty($c['end_date']) ? jdate($c['end_date']) : '—') ?></span></td>
          <td><?= num($c['base_salary']) ?></td>
          <td><span class="pill"><?= e(Payroll::CONTRACT_STATUS[$c['status']] ?? $c['status']) ?></span></td>
          <td><a class="btn sm ghost" href="<?= url('app/payroll/contracts/' . (int)$c['id']) ?>">مشاهده</a></td></tr>
      <?php endforeach; ?>
      <?php if (empty($recentContracts)): ?><tr><td colspan="8" class="muted small">قراردادی ثبت نشده است.</td></tr><?php endif; ?>
      </tbody></table></div>

    <div class="section-title" style="margin-top:14px">محاسبهٔ عیدی و حق سنوات</div>
    <form method="get" action="<?= url('app/settings/hr') ?>" class="filters" style="border:none;padding:0">
      <div class="field" style="min-width:240px"><label>پرسنل</label>
        <select class="inp select-search" name="calc_employee" onchange="this.form.submit()">
          <option value="">— انتخاب پرسنل —</option>
          <?php foreach (($employees ?? []) as $e): ?>
            <option value="<?= (int)$e['id'] ?>" <?= (int)($calcEmp ?? 0) === (int)$e['id'] ? 'selected' : '' ?>><?= e($e['full_name']) ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><button class="btn">محاسبه</button></div>
    </form>
    <?php if (!empty($calc)): ?>
      <div class="kpis" style="margin-top:10px">
        <div class="kpi card"><div class="dot">◈</div><div class="t">مبنای ماهانه</div><div class="v"><?= num($calc['monthly']) ?></div><div class="u"><?= $calc['eidi_base'] === 'gross' ? 'حقوق و مزایا' : 'حقوق پایه' ?></div></div>
        <div class="kpi card gold"><div class="dot">★</div><div class="t">عیدی (<?= num($calc['months'], 1) ?> ماه)</div><div class="v"><?= num($calc['eidi']) ?></div>
          <div class="u"><?= $calc['eidi_cap'] > 0 ? 'سقف ' . num($calc['eidi_cap']) : 'بدون سقف' ?></div></div>
        <div class="kpi card green"><div class="dot">↑</div><div class="t">حق سنوات</div><div class="v"><?= num($calc['sanavat']) ?></div><div class="u"><?= num($calc['years'], 2) ?> سال سابقه</div></div>
      </div>
      <div class="help" style="margin-top:6px">محاسبه بر اساس پارامترهای «عیدی و حق سنوات» در همین صفحه؛ با تغییر آن‌ها نتیجه به‌روز می‌شود.</div>
    <?php endif; ?>
  </div>

  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره تنظیمات حقوق</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
