<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('bank', 20) ?> درگاه و پرداخت</h2>
    <span class="muted small">حساب‌های دریافت وجه که در «پورتال مشتری» نمایش داده می‌شوند (شبا، کارت، بانک و صاحب حساب).</span>
  </div>
  <div class="page-head-actions">
    <a class="btn ghost" href="<?= e($portalUrl) ?>" target="_blank"><?= icon('eye', 15) ?> مشاهدهٔ پورتال</a>
  </div>
</div>

<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>افزودن حساب دریافت</h3></div>
    <form method="post" action="<?= url('app/settings/payment/store') ?>">
      <?= csrf_field() ?>
      <div class="form-grid">
        <div class="field"><label>نام بانک <span class="req">*</span></label><input class="inp" type="text" name="bank_name" placeholder="مثلاً بانک ملت" required></div>
        <div class="field"><label>نام صاحب حساب <span class="req">*</span></label><input class="inp" type="text" name="account_holder" placeholder="نام شخص/شرکت" required></div>
        <div class="field"><label>شماره کارت</label><input class="inp" type="text" name="card_no" dir="ltr" placeholder="1234-5678-9012-3456"></div>
        <div class="field"><label>شبا</label><input class="inp" type="text" name="iban" dir="ltr" placeholder="IR..."></div>
        <div class="field"><label>ترتیب</label><input class="inp" type="number" name="sort_order" value="0"></div>
        <div class="field"><label>فعال</label><label class="switch"><input type="checkbox" name="is_active" value="1" checked><span></span></label></div>
      </div>
      <div class="form-actions"><button class="btn"><?= icon('plus', 15) ?> افزودن حساب</button></div>
    </form>
  </div>

  <div class="card">
    <div class="card-head"><h3>حساب‌های فعلی</h3><span class="pill"><?= num(count($accounts)) ?></span></div>
    <?php if (!$accounts): ?><div class="pp-empty">حسابی تعریف نشده است.</div><?php else: ?>
    <div class="portal-accounts">
      <?php foreach ($accounts as $a): ?>
        <div class="pay-row">
          <div class="pay-row-b">
            <div class="portal-acc-bank"><?= e($a['bank_name']) ?> — <?= e($a['account_holder']) ?></div>
            <div class="muted small" dir="ltr" style="text-align:right">
              <?php if (!empty($a['card_no'])): ?><?= e('کارت ' . $a['card_no']) ?><?php endif; ?>
              <?php if (!empty($a['iban'])): ?><?= !empty($a['card_no']) ? ' · ' : '' ?><?= e($a['iban']) ?><?php endif; ?>
            </div>
          </div>
          <span class="pill <?= $a['is_active'] ? 'st-active' : 'st-draft' ?>"><?= $a['is_active'] ? 'فعال' : 'غیرفعال' ?></span>
          <form method="post" action="<?= url('app/settings/payment/' . (int)$a['id'] . '/delete') ?>" onsubmit="return confirm('حذف شود؟')" style="margin:0"><?= csrf_field() ?><button class="btn danger sm"><?= icon('trash', 14) ?></button></form>
        </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <div class="help" style="margin-top:12px">این حساب‌ها در پورتال مشتری به‌عنوان «روش‌های پرداخت» نمایش داده می‌شوند و مشتری پس از واریز، رسید پرداخت را آپلود می‌کند.</div>
  </div>
</div>
<?= view('partials/foot') ?>
