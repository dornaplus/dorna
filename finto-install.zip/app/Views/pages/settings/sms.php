<?= view('partials/head', ['title' => $title]) ?>
<?php
$smsCfg = Sms::config();
$keySet = $smsCfg['api_key'] !== '';
$ip = Sms::outboundIp();
?>
<div class="card">
  <div class="card-head"><h3><?= icon('phone') ?> اتصال سامانه پیامک (کاوه‌نگار)</h3><div class="grow"></div>
    <button type="button" class="btn soft sm" id="smsTestBtn">آزمون اتصال</button></div>

  <div class="grid c3" style="margin:4px 0 10px">
    <div class="kpi card"><div class="dot">⚙</div><div class="t">درایور فعال</div>
      <div class="v" style="font-size:16px" dir="ltr"><?= e($smsCfg['driver']) ?></div>
      <div class="u">kavenegar = ارسال واقعی · log = فقط ثبت</div></div>
    <div class="kpi card <?= $keySet ? 'green' : 'gold' ?>"><div class="dot">🔑</div><div class="t">کلید API</div>
      <div class="v" style="font-size:16px"><?= $keySet ? 'تنظیم شده ✅' : 'تنظیم نشده ✗' ?></div>
      <div class="u" dir="ltr"><?= $keySet ? e(substr($smsCfg['api_key'], 0, 6) . '…' . substr($smsCfg['api_key'], -4)) : '—' ?></div></div>
    <div class="kpi card"><div class="dot">🌐</div><div class="t">IP عمومی این سرور</div>
      <div class="v" style="font-size:16px" dir="ltr"><?= $ip !== '' ? e($ip) : 'نامشخص' ?></div>
      <div class="u">این IP باید در پنل کاوه‌نگار مجاز باشد</div></div>
  </div>

  <div class="help">الگوی کد تایید (Lookup): <b dir="ltr"><?= e($smsCfg['otp_template']) ?></b>
    — خط ارسال: <b dir="ltr"><?= $smsCfg['sender'] !== '' ? e($smsCfg['sender']) : '(پیش‌فرض حساب)' ?></b></div>
  <div id="smsTestOut" class="help" style="margin-top:8px"></div>

  <div class="field" style="margin-top:12px">
    <label>ارسال پیامک آزمایشی به شمارهٔ</label>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <input class="inp" id="smsTestMobile" placeholder="09121234567" dir="ltr" style="max-width:190px" inputmode="numeric">
      <button type="button" class="btn sm" id="smsSendBtn">ارسال آزمایشی</button>
    </div>
  </div>
  <div id="smsSendOut" class="help" style="margin-top:6px"></div>
</div>
<script>
(function () {
  var out = document.getElementById('smsTestOut');
  var sOut = document.getElementById('smsSendOut');
  var ip = <?= json_encode($ip) ?>;

  function showIpHint(j) {
    if (j.ip_restricted && ip) {
      return ' <b>(این IP باید در پنل کاوه‌نگار → تنظیمات → محدودیت IP اضافه شود: <span dir="ltr">' + ip + '</span>)</b>';
    }
    return '';
  }
  document.getElementById('smsTestBtn').addEventListener('click', function () {
    out.textContent = 'در حال آزمون اتصال…';
    fetch(<?= json_encode(url('app/settings/sms/test')) ?>, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: '_token=' + encodeURIComponent(window.CSRF || '') })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.ok) { out.innerHTML = '<span style="color:#0E9F6E;font-weight:700">اتصال موفق است ✅</span> — درایور: <b dir="ltr">' + (j.driver || '') + '</b> — الگو: <b dir="ltr">' + (j.template || '') + '</b>'; return; }
        out.innerHTML = '<span style="color:#E11D48;font-weight:700">اتصال ناموفق</span> — کد ' + (j.status || '') + ' — ' + (j.message || j.error || '') + showIpHint(j);
      })
      .catch(function () { out.textContent = 'ارتباط برقرار نشد.'; });
  });

  var btn = document.getElementById('smsSendBtn');
  if (btn) btn.addEventListener('click', function () {
    var m = (document.getElementById('smsTestMobile').value || '').trim();
    if (!m) { sOut.textContent = 'شماره را وارد کنید.'; return; }
    sOut.textContent = 'در حال ارسال…';
    fetch(<?= json_encode(url('app/settings/sms/send-test')) ?>, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: '_token=' + encodeURIComponent(window.CSRF || '') + '&mobile=' + encodeURIComponent(m) })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (j.ok) {
          var id = (j.entry && (j.entry.messageid || j.entry[0] && j.entry[0].messageid)) || '';
          sOut.innerHTML = '<span style="color:#0E9F6E;font-weight:700">پیامک ارسال شد ✅</span>' + (id ? ' — شناسه: <b dir="ltr">' + id + '</b>' : '');
          return;
        }
        sOut.innerHTML = '<span style="color:#E11D48;font-weight:700">ارسال ناموفق</span> — کد ' + (j.status || '') + ' — ' + (j.message || j.error || '') + showIpHint(j);
      })
      .catch(function () { sOut.textContent = 'ارتباط برقرار نشد.'; });
  });
})();
</script>
<div class="grid c3">
  <div class="kpi card"><div class="dot">✉</div><div class="t">اعتبار پیامک</div><div class="v"><?= num($balance) ?></div><div class="u">پیامک قابل ارسال</div></div>
  <div class="kpi card green"><div class="dot">▤</div><div class="t">قالب‌های پیامک</div><div class="v"><?= num(count($templates)) ?></div><div class="u">قالب فعال</div></div>
  <div class="kpi card gold"><div class="dot">◔</div><div class="t">ارسال‌های اخیر</div><div class="v"><?= num(count($recent)) ?></div><div class="u">۲۰ پیام آخر</div></div>
</div>
<form method="post" action="<?= url('app/settings/sms') ?>">
  <?= csrf_field() ?>
  <div class="card" style="margin-top:12px">
    <div class="card-head"><h3>تنظیمات سامانه پیامک</h3><div class="grow"></div>
      
      </div>
    <?= view('pages/settings/_settings_form', ['groups' => $groups]) ?>
  </div>
  <div class="grid c2">
    <div class="card">
      <div class="card-head"><h3>قالب‌های پیامک</h3></div>
      <div class="table-wrap"><table class="tbl" style="min-width:520px">
        <thead><tr><th>عنوان</th><th>رخداد</th><th>متن</th><th>وضعیت</th></tr></thead>
        <tbody><?php foreach ($templates as $t): ?>
          <tr><td><?= e($t['title_fa']) ?></td><td class="muted small" dir="ltr"><?= e($t['event_key']) ?></td>
            <td class="muted small"><?= e(mb_substr((string)$t['body_template'], 0, 40)) ?>…</td>
            <td><span class="pill st-<?= !empty($t['is_active']) ? 'active' : 'cancelled' ?>"><?= !empty($t['is_active']) ? 'فعال' : 'غیرفعال' ?></span></td></tr>
        <?php endforeach; ?>
        <?php if (!$templates): ?><tr><td colspan="4" class="muted small">قالبی ثبت نشده است.</td></tr><?php endif; ?></tbody></table></div>
    </div>
    <div class="card">
      <div class="card-head"><h3>قواعد اطلاع‌رسانی</h3></div>
      <div class="table-wrap"><table class="tbl" style="min-width:460px">
        <thead><tr><th>رخداد</th><th>وضعیت</th><th>روز قبل</th><th>مبلغ آستانه</th></tr></thead>
        <tbody><?php foreach ($rules as $r): ?>
          <tr><td class="muted small" dir="ltr"><?= e($r['rule_key']) ?></td>
            <td><span class="pill st-<?= !empty($r['is_enabled']) ? 'active' : 'cancelled' ?>"><?= !empty($r['is_enabled']) ? 'فعال' : 'خاموش' ?></span></td>
            <td class="muted small"><?= e(str_replace(['[', ']', '"'], '', (string)$r['days_before_json'])) ?></td>
            <td class="num"><?= num($r['threshold_amount']) ?></td></tr>
        <?php endforeach; ?>
        <?php if (!$rules): ?><tr><td colspan="4" class="muted small">قاعده‌ای ثبت نشده.</td></tr><?php endif; ?></tbody></table></div>
    </div>
  </div>
  <div class="card">
    <div class="card-head"><h3>آخرین پیامک‌ها</h3></div>
    <div class="table-wrap"><table class="tbl" style="min-width:700px">
      <thead><tr><th>گیرنده</th><th>متن</th><th>کانال</th><th>وضعیت</th><th>هزینه</th><th>تاریخ</th></tr></thead>
      <tbody><?php foreach ($recent as $msg): ?>
        <tr><td dir="ltr"><?= e($msg['recipient'] ?? '—') ?></td><td class="muted small"><?= e(mb_substr((string)$msg['body'], 0, 50)) ?></td>
          <td><span class="pill"><?= e(Meta::enumLabel($msg['channel'])) ?></span></td>
          <td><span class="pill st-<?= $msg['status'] === 'sent' || $msg['status'] === 'delivered' ? 'paid' : ($msg['status'] === 'failed' ? 'cancelled' : 'unpaid') ?>"><?= e(Meta::enumLabel($msg['status'])) ?></span></td>
          <td class="num"><?= num($msg['cost_amount']) ?></td><td><?= e(jdate($msg['sent_at'] ?? $msg['created_at'], '/', true)) ?></td></tr>
      <?php endforeach; ?>
      <?php if (!$recent): ?><tr><td colspan="6" class="muted small">پیامکی ارسال نشده است.</td></tr><?php endif; ?></tbody></table></div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ذخیره تنظیمات پیامک</button>
    <a class="btn gray" href="<?= url('app') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
