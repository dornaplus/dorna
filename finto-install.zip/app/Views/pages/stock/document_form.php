<?= view('partials/head', ['title' => $title]) ?>
<?= view('partials/ai_upload', ['kind' => 'stock_doc', 'label' => 'سند انبار / ضایعات']) ?>
<form method="post" action="<?= url('app/inventory-documents') ?>">
  <?= csrf_field() ?>
  <input type="hidden" name="doc_type" value="<?= e($type) ?>">
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><span class="pill">شماره بعدی: <?= e($nextNo) ?></span><div class="grow"></div>
      <div class="tabs" data-tabs="#doc-type-scope">
        <?php foreach ($docTypes as $dt): ?>
          <a class="<?= $dt === $type ? 'on' : '' ?>" href="<?= url('app/inventory-documents/create?type='.$dt) ?>"><?= e(StockController::DOC_TITLES[$dt] ?? $dt) ?></a>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="form-grid">
      <div class="field"><label>انبار <span class="req">*</span></label>
        <select class="inp" name="warehouse_id" required>
          <?php foreach ($warehouses as $w): ?>
            <option value="<?= $w['id'] ?>" <?= ($doc['warehouse_id'] ?? '') == $w['id'] ? 'selected' : '' ?>><?= e($w['title']) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>تاریخ سند <span class="req">*</span></label>
        <input class="inp jalali" type="text" name="doc_date" data-value="<?= e($doc['doc_date'] ?? today()) ?>" value="<?= e(jdate($doc['doc_date'] ?? today())) ?>" required></div>
      <div class="field"><label><?= $type === 'buy_return' ? 'تأمین‌کننده' : 'شخص مرتبط' ?></label>
        <select class="inp select-search" name="person_id"><option value="">— انتخاب —</option>
          <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '').' '.($p['company_name'] ?? '')); ?>
            <option value="<?= $p['id'] ?>"><?= e($p['code'].' — '.$nm) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field field-wide"><label>شرح سند</label><textarea class="inp" name="description" rows="2"></textarea></div>
    </div>
    <div class="alert info">
      <?php if ($type === 'receive'): ?>ورود کالا به انبار (خرید بدون فاکتور، برگشت از فروش، امانی…) — بهای واحد را وارد کنید تا کاردکس و بهای تمام‌شده اصلاح شود.
      <?php elseif ($type === 'issue'): ?>خروج کالا از انبار؛ بهای تمام‌شده به‌صورت خودکار از لایه‌های FIFO محاسبه می‌شود.
      <?php elseif ($type === 'waste'): ?>ثبت ضایعات با انتخاب دلیل ضایعات.
      <?php elseif ($type === 'opening'): ?>ثبت موجودی اول دوره با بهای تمام‌شده مشخص.
      <?php elseif ($type === 'buy_return'): ?>برگشت به تأمین‌کننده (خروج کالا).
      <?php else: ?>برگشت از فروش (ورود کالا به انبار).<?php endif; ?>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>اقلام سند</h3><div class="grow"></div><button class="btn sm" type="button" data-add-row="stock">+ افزودن ردیف</button></div>
    <div class="table-wrap"><table class="tbl" style="min-width:780px">
      <thead><tr><th style="width:34px">#</th><th>کالا</th><th>واحد</th><th>مقدار</th><th>بهای واحد</th><th>دلیل ضایعات</th><th>توضیح</th><th></th></tr></thead>
      <tbody data-rows="stock"></tbody>
    </table></div>
    <template id="tpl-stock">
      <td>__n__</td>
      <td>
        <select name="line_product_id[]" class="inp select-search" required>
          <option value="">— انتخاب کالا —</option>
          <?php foreach ($products as $pr): ?>
            <option value="<?= $pr['id'] ?>" data-unit="<?= (int)$pr['main_unit_id'] ?>" data-stock="<?= (float)$pr['stock_qty'] ?>"><?= e($pr['code'].' — '.$pr['title'].' ['.num($pr['stock_qty'], 1).']') ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint">موجودی: <span data-stock>—</span></div>
      </td>
      <td>
        <select name="line_unit_id[]" class="inp">
          <?php foreach (Database::all('SELECT id,title FROM units WHERE business_id=? ORDER BY id', [Auth::businessId()]) as $un): ?>
            <option value="<?= $un['id'] ?>"><?= e($un['title']) ?></option>
          <?php endforeach; ?>
        </select>
      </td>
      <td><input class="inp" type="number" step="any" min="0.0001" name="line_quantity[]" value="1" required></td>
      <td><input class="inp money" type="text" name="line_unit_cost[]" value="" placeholder="<?= $type === 'issue' || $type === 'waste' ? 'خودکار (FIFO)' : '۰' ?>"></td>
      <td><select name="line_waste_reason[]" class="inp"><option value="">—</option>
        <?php foreach ($wasteReasons as $wr): ?><option value="<?= $wr['id'] ?>"><?= e($wr['title']) ?></option><?php endforeach; ?>
      </select></td>
      <td><input class="inp" type="text" name="line_desc[]"></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>
    <div class="grid c3" style="margin-top:10px">
      <div><div class="muted small">جمع مقدار</div><b><span id="sum_qty">0</span></b></div>
      <div><div class="muted small">جمع بهای تمام‌شده</div><b><span id="sum_cost">0</span></b></div>
      <div class="help">پس از ثبت، سند انبار به‌همراه کاردکس و سند حسابداری (در صورت وجود قاعده) صادر می‌شود.</div>
    </div>
    <div class="form-actions">
      <button class="btn success">ثبت و قطعی‌سازی سند</button>
      <a class="btn gray" href="<?= url('app/inventory-documents') ?>">انصراف</a>
    </div>
  </div>
</form>
<?= view('partials/foot') ?>
