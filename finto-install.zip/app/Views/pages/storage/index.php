<?= view('partials/head', ['title' => $title]) ?>
<div class="page-head">
  <div class="page-head-l">
    <h2><?= icon('box', 20) ?> فضای ذخیره‌سازی اسناد</h2>
    <span class="muted small">سهمیهٔ هر کاربر <?= num(StorageQuota::BASE_GB) ?> گیگابایت است؛ برای بیشتر، فضای اضافه بخرید.</span>
  </div>
  <div class="page-head-actions">
    <a class="btn ghost" href="<?= url('app/documents') ?>"><?= icon('folder', 15) ?> مدیریت اسناد</a>
  </div>
</div>

<div class="stor-grid">
  <div class="card">
    <div class="card-head"><h3>وضعیت فضای شما</h3></div>
    <div class="stor-numbers">
      <div class="stor-num"><b><?= e(StorageQuota::human($used)) ?></b><span>مصرف‌شده</span></div>
      <div class="stor-num"><b><?= e(StorageQuota::human($remaining)) ?></b><span>باقی‌مانده</span></div>
      <div class="stor-num"><b><?= e(StorageQuota::human($quota)) ?></b><span>کل فضا</span></div>
      <div class="stor-num"><b><?= num($docCount) ?></b><span>سند</span></div>
    </div>
    <div class="stor-bar"><i style="width:<?= (float)$pct ?>%"></i></div>
    <div class="stor-bar-labels">
      <span><?= num($pct, 1) ?>٪ پر شده</span>
      <span class="muted"><?= num(StorageQuota::BASE_GB) ?> گیگ پایه<?= $purchasedGb > 0 ? ' + ' . num($purchasedGb) . ' گیگ خریداری‌شده' : '' ?></span>
    </div>
  </div>

  <div class="card">
    <div class="card-head"><h3>خرید فضای اضافه</h3></div>
    <div class="help" style="margin-bottom:14px">هر گیگابایت اضافه <b><?= num($pricePerGb) ?> تومان</b> است — جدا از پکیج اشتراک. بین ۱ تا <?= num($maxGb) ?> گیگ انتخاب کنید.</div>
    <form method="post" action="<?= url('app/storage/purchase') ?>">
      <?= csrf_field() ?>
      <div class="stor-buy">
        <?php for ($g = 1; $g <= $maxGb; $g++): ?>
          <label class="stor-opt">
            <input type="radio" name="gigabytes" value="<?= $g ?>" <?= $g === 1 ? 'checked' : '' ?>>
            <span><b><?= num($g) ?> گیگ</b><small><?= num($g * $pricePerGb) ?> تومان</small></span>
          </label>
        <?php endfor; ?>
      </div>
      <div class="stor-total" id="storTotal">مبلغ قابل پرداخت: <b><?= num($pricePerGb) ?> تومان</b></div>
      <div class="form-actions"><button class="btn"><?= icon('wallet', 16) ?> پرداخت و فعال‌سازی</button></div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-head"><h3>تاریخچهٔ خریدها</h3></div>
  <?php if (!$history): ?><div class="pp-empty">خریدی ثبت نشده است.</div><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>تاریخ</th><th>حجم</th><th>مبلغ</th><th>وضعیت</th><th>شناسه</th></tr></thead>
    <tbody><?php foreach ($history as $h): ?>
      <tr><td><?= e(jdate($h['created_at'], '/', true)) ?></td>
        <td><b><?= num((int)$h['gigabytes']) ?> گیگ</b></td>
        <td><?= num($h['amount']) ?> تومان</td>
        <td><span class="pill <?= $h['status'] === 'paid' ? 'st-paid' : 'st-pending' ?>"><?= e(Meta::enumLabel($h['status'])) ?></span></td>
        <td><span class="muted small"><?= e($h['gateway_ref']) ?></span></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
  <?php endif; ?>
</div>

<script>
(function () {
  var radios = document.querySelectorAll('input[name=gigabytes]'), total = document.getElementById('storTotal');
  var price = <?= (int)$pricePerGb ?>;
  function paint() { var v = 1; radios.forEach(function (r) { if (r.checked) v = parseInt(r.value, 10); });
    total.innerHTML = 'مبلغ قابل پرداخت: <b>' + (v * price).toLocaleString('fa-IR') + ' تومان</b>'; }
  radios.forEach(function (r) { r.addEventListener('change', paint); });
})();
</script>
<?= view('partials/foot') ?>
