<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head"><h3>چک <?= e(fa_digits((string)$ch['cheque_no'])) ?></h3>
    <span class="pill st-<?= e($ch['status']) ?>"><?= e(Trade::chequeStatusTitle($ch['status'])) ?></span>
    <span class="pill"><?= $ch['direction'] === 'received' ? 'دریافتی' : 'پرداختی' ?></span><div class="grow"></div>
    <a class="btn ghost" href="<?= url('app/cheques?direction='.$ch['direction']) ?>">فهرست</a></div>
  <div class="grid c4">
    <div><div class="muted small">مبلغ</div><b class="big-num" style="font-size:18px"><?= num($ch['amount']) ?></b></div>
    <div><div class="muted small">شخص</div><b><?= e(trim(($ch['first_name'] ?? '').' '.($ch['last_name'] ?? '').' '.($ch['company_name'] ?? ''))) ?></b></div>
    <div><div class="muted small">بانک / شعبه</div><b><?= e(($ch['bank_name'] ?? '—').' / '.($ch['branch_name'] ?? '—')) ?></b></div>
    <div><div class="muted small">سررسید</div><b><?= e(jdate($ch['due_date'])) ?></b></div>
  </div>
</div>
<div class="grid c2">
  <div class="card">
    <div class="card-head"><h3>عملیات چرخه چک</h3></div>
    <div class="btn-row">
      <?php
      $events = $ch['direction'] === 'received'
        ? [['deposited','واگذاری به بانک'], ['cleared','وصول شد'], ['bounced','برگشت خورد'], ['endorsed','واگذاری به شخص'], ['cancelled','ابطال']]
        : [['paid','پرداخت شد'], ['bounced','برگشت خورد'], ['cancelled','ابطال']];
      foreach ($events as [$ev, $lbl]): ?>
        <form method="post" action="<?= url('app/cheques/'.$ch['id'].'/event') ?>" style="display:inline">
          <?= csrf_field() ?>
          <input type="hidden" name="event" value="<?= $ev ?>">
          <input type="hidden" name="event_date" value="<?= e(jdate(today())) ?>">
          <input type="hidden" name="note" value="<?= e($lbl) ?>">
          <button class="btn <?= $ev === 'bounced' || $ev === 'cancelled' ? 'danger' : ($ev === 'cleared' || $ev === 'paid' ? 'success' : 'ghost') ?> sm"><?= e($lbl) ?></button>
        </form>
      <?php endforeach; ?>
    </div>
    <div class="help" style="margin-top:12px">
      هر رویداد در جدول <b>cheque_histories</b> ثبت و در صورت نیاز سند حسابداری متناظر صادر می‌شود
      (وصول: بدهکار بانک/بستانکار چک‌های دریافتنی — برگشت: برگشت به حساب شخص).
    </div>
    <form method="post" action="<?= url('app/cheques/'.$ch['id'].'/event') ?>" style="margin-top:12px">
      <?= csrf_field() ?>
      <div class="form-grid">
        <div class="field"><label>رویداد دیگر</label>
          <select class="inp" name="event">
            <option value="deposited">واگذاری به بانک</option><option value="cleared">وصول</option><option value="bounced">برگشتی</option>
            <option value="spent">خرج به شخص</option><option value="endorsed">واگذاری (ظهرنویسی)</option><option value="paid">پرداخت چک صادره</option><option value="cancelled">ابطال</option>
          </select></div>
        <div class="field"><label>تاریخ رویداد</label><input class="inp jalali" type="text" name="event_date" data-value="<?= e(today()) ?>"></div>
        <div class="field field-wide"><label>توضیح</label><input class="inp" type="text" name="note"></div>
      </div>
      <button class="btn">ثبت رویداد</button>
    </form>
  </div>
  <div class="card">
    <div class="card-head"><h3>تاریخچه رویدادها</h3></div>
    <?php if (!$histories): ?><div class="muted small">رویدادی ثبت نشده است.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:520px">
      <thead><tr><th>رویداد</th><th>از</th><th>به</th><th>تاریخ</th><th>کاربر</th><th>سند</th><th>توضیح</th></tr></thead>
      <tbody><?php foreach ($histories as $h): ?>
        <tr><td><?= e(Trade::chequeEventTitle($h['event'])) ?></td>
          <td><?= e($h['from_status'] ? Trade::chequeStatusTitle($h['from_status']) : '—') ?></td>
          <td><?= e(Trade::chequeStatusTitle($h['to_status'])) ?></td>
          <td><?= e(jdate($h['event_date'])) ?></td><td><?= e($h['full_name'] ?? '—') ?></td>
          <td><?= $h['journal_entry_id'] ? '<a href="'.url('app/journal/'.$h['journal_entry_id']).'">#'.num($h['journal_entry_id']).'</a>' : '—' ?></td>
          <td class="muted small"><?= e($h['note'] ?? '') ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/foot') ?>
