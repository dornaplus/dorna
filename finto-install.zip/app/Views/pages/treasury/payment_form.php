<?= view('partials/head', ['title' => $title]) ?>
<?= view('partials/ai_upload', ['kind' => 'payment', 'label' => 'سند پرداخت']) ?>
<form method="post" action="<?= url('app/payments') ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3>ثبت پرداخت</h3><span class="pill">شماره بعدی: <?= e($nextNo) ?></span></div>
    <div class="form-grid">
      <div class="field"><label>پرداخت به (شخص) <span class="req">*</span></label>
        <select class="inp select-search" name="person_id" data-person-select required>
          <option value="">— انتخاب کنید —</option>
          <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '').' '.($p['company_name'] ?? '')); ?>
            <option value="<?= $p['id'] ?>" <?= $personId == $p['id'] ? 'selected' : '' ?>><?= e($p['code'].' — '.$nm) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint"><a href="<?= url('app/payments/create') ?>">بارگذاری فاکتورهای باز شخص</a></div></div>
      <div class="field"><label>تاریخ پرداخت <span class="req">*</span></label>
        <input class="inp jalali" type="text" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      <div class="field"><label>مبلغ پرداخت <span class="req">*</span></label><input class="inp money" type="text" name="amount" required></div>
      <div class="field"><label>روش پرداخت</label>
        <select class="inp" name="payment_kind"><option value="cash">نقد / کارت / حواله</option><option value="cheque">چک</option></select></div>
      <div class="field"><label>حساب نقد/بانک</label>
        <select class="inp" name="cash_account_id" required><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?><option value="<?= $c['id'] ?>"><?= e($c['title'].' ('.num($c['current_balance']).')') ?></option><?php endforeach; ?>
        </select></div>
      <div class="field"><label>روش پرداخت (نوع)</label>
        <select class="inp" name="payment_method_id"><option value="">— انتخاب —</option>
          <?php foreach ($methods as $m): ?><option value="<?= $m['id'] ?>"><?= e($m['title_fa']) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>مرکز هزینه</label>
        <select class="inp" name="cost_center_id"><option value="">— انتخاب —</option>
          <?php foreach ($costCenters as $cc): ?><option value="<?= $cc['id'] ?>"><?= e($cc['name']) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>شماره پیگیری</label><input class="inp" type="text" name="bank_reference"></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"></textarea></div>
    </div>
    <details style="margin-top:6px">
      <summary class="section-title" style="cursor:pointer">اطلاعات چک صادره</summary>
      <div class="form-grid">
        <div class="field"><label>شماره چک</label><input class="inp" type="text" name="cheque_no"></div>
        <div class="field"><label>بانک</label><input class="inp" type="text" name="bank_name"></div>
        <div class="field"><label>شعبه</label><input class="inp" type="text" name="branch_name"></div>
        <div class="field"><label>شماره حساب</label><input class="inp" type="text" name="account_no"></div>
        <div class="field"><label>شناسه صیادی</label><input class="inp" type="text" name="sayad_id"></div>
        <div class="field"><label>تاریخ صدور</label><input class="inp jalali" type="text" name="issue_date" data-value="<?= e(today()) ?>"></div>
        <div class="field"><label>تاریخ سررسید</label><input class="inp jalali" type="text" name="due_date"></div>
      </div>
    </details>
  </div>
  <div class="card">
    <div class="card-head"><h3>تخصیص به فاکتورهای خرید و اسناد هزینه</h3><div class="grow"></div>
      <button class="btn ghost sm" type="button" data-add-row="alloc">+ افزودن ردیف</button></div>
    <div class="table-wrap"><table class="tbl" style="min-width:760px">
      <thead><tr><th>فاکتور خرید / سند هزینه</th><th>مانده</th><th>مبلغ تخصیص</th><th>مانده بعد</th><th></th></tr></thead>
      <tbody data-rows="alloc"></tbody></table></div>
    <template id="tpl-alloc">
      <td><select name="alloc_invoice_id[]" class="inp select-search">
        <option value="">— بدون تخصیص —</option>
        <?php foreach ($openInvoices as $oi): ?><option value="<?= $oi['id'] ?>" data-remain="<?= (float)$oi['remaining_amount'] ?>"><?= e('فاکتور '.fa_digits((string)$oi['invoice_no']).' — مانده '.num($oi['remaining_amount'])) ?></option><?php endforeach; ?>
      </select></td>
      <td><span class="badge off" data-remain="0">—</span></td>
      <td><input class="inp money" type="text" name="alloc_amount[]" value=""></td>
      <td><span data-after>—</span></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>
    <div class="section-title">پرداخت اسناد هزینه باز</div>
    <div class="table-wrap"><table class="tbl" style="min-width:700px">
      <thead><tr><th>سند هزینه</th><th>عنوان</th><th>مبلغ</th><th>پرداخت</th></tr></thead>
      <tbody>
      <?php foreach ($unpaidExpenses as $ex): ?>
        <tr>
          <td><?= e(fa_digits((string)$ex['doc_no'])) ?><input type="hidden" name="alloc_expense_id[]" value="<?= $ex['id'] ?>"></td>
          <td><?= e($ex['title']) ?> <span class="muted small"><?= e(jdate($ex['doc_date'])) ?></span></td>
          <td class="num"><?= num($ex['amount']) ?></td>
          <td><input class="inp money" type="text" name="alloc_expense_amount[]" value="" placeholder="0"></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$unpaidExpenses): ?><tr><td colspan="4" class="muted small">سند هزینه پرداخت‌نشده‌ای وجود ندارد.</td></tr><?php endif; ?>
      </tbody></table></div>
    <div class="grid c2" style="margin-top:10px">
      <div><div class="muted small">جمع تخصیص‌ها</div><b><span id="sum_alloc">0</span></b></div>
      <div id="alloc_hint" class="alert info" style="margin:0">مبلغ پرداخت را وارد کنید.</div>
    </div>
  </div>
  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ثبت پرداخت و صدور سند</button>
    <a class="btn gray" href="<?= url('app/payments') ?>">انصراف</a></div></div>
</form>
<?= view('partials/foot') ?>
