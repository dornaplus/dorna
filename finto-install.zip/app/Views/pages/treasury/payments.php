<?= view('partials/head', ['title' => $title]) ?>
<div class="card tight">
  <form method="get" class="filters">
    <div class="field" style="flex:1;min-width:200px"><label>جست‌وجو</label><input class="inp" type="text" name="q" value="<?= e($q) ?>"></div>
    <div class="field"><label>وضعیت</label><select class="inp" name="status"><option value="">همه</option>
      <?php foreach (['draft','posted','cancelled'] as $s): ?><option value="<?= $s ?>" <?= $status === $s ? 'selected' : '' ?>><?= e(Meta::enumLabel($s)) ?></option><?php endforeach; ?>
    </select></div>
    <div class="field"><label>شخص</label>
      <select class="inp" name="person_id"><option value="">همه</option>
        <?php foreach (Database::all('SELECT id,code,first_name,last_name,company_name FROM persons WHERE business_id=? AND deleted_at IS NULL ORDER BY id DESC LIMIT 300', [Auth::businessId()]) as $pp): ?>
          <option value="<?= $pp['id'] ?>" <?= $personId == $pp['id'] ? 'selected' : '' ?>><?= e(trim($pp['code'].' '.($pp['first_name'] ?? '').' '.($pp['last_name'] ?? '').' '.($pp['company_name'] ?? ''))) ?></option>
        <?php endforeach; ?></select></div>
    <div class="field"><label>از تاریخ</label><input class="inp jalali" type="text" name="from" value="<?= e($from) ?>"></div>
    <div class="field"><label>تا تاریخ</label><input class="inp jalali" type="text" name="to" value="<?= e($to) ?>"></div>
    <div class="field"><button class="btn">اعمال</button></div>
  </form>
</div>
<div class="card">
  <div class="card-head"><h3>پرداخت‌ها</h3><span class="pill"><?= num($totals['cnt'] ?? 0) ?> سند</span>
    <span class="pill">جمع: <?= num($totals['total'] ?? 0) ?></span><div class="grow"></div>
    <a class="btn" href="<?= url('app/payments/create') ?>">+ ثبت پرداخت</a></div>
  <?php if (!$rows): ?><?= view('partials/empty', ['message' => 'سند پرداختی ثبت نشده است.', 'actionUrl' => url('app/payments/create'), 'actionText' => '+ ثبت پرداخت']) ?><?php else: ?>
  <div class="table-wrap"><table class="tbl">
    <thead><tr><th>شماره</th><th>تاریخ</th><th>شخص</th><th>حساب</th><th>چک</th><th>مبلغ</th><th>وضعیت</th><th>عملیات</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?>
      <tr>
        <td><a href="<?= url('app/payments/'.$r['id']) ?>"><b><?= e(fa_digits((string)$r['doc_no'])) ?></b></a></td>
        <td><?= e(jdate($r['doc_date'])) ?></td>
        <td><?= e(trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '').' '.($r['company_name'] ?? ''))) ?></td>
        <td><?= e($r['cash_title'] ?? '—') ?></td>
        <td><?= e(fa_digits((string)($r['cheque_no'] ?? '—'))) ?></td>
        <td class="num money-v"><?= num($r['amount']) ?></td>
        <td><span class="pill st-<?= e($r['status']) ?>"><?= e(Meta::enumLabel($r['status'])) ?></span></td>
        <td class="acts"><a class="btn ghost sm" href="<?= url('app/payments/'.$r['id']) ?>">مشاهده</a>
          <?= print_buttons(url('app/payments/'.$r['id'].'/print'), 'sm') ?></td>
      </tr>
    <?php endforeach; ?></tbody></table></div>
  <?= view('partials/pagination', ['page' => $page, 'per' => $per, 'total' => (int)($totals['cnt'] ?? 0)]) ?>
  <?php endif; ?>
</div>
<?= view('partials/foot') ?>
