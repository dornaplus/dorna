<?php /** @var array $r @var array $lines @var array $tpl @var array $business */
$tpl = $tpl ?? Printing::template('receipt'); ?>
<?= view('partials/public_head', ['title' => $title]) ?>
<?= Printing::style($tpl) ?>
<div class="print-page" data-autoprint data-pdf="<?= !empty($_GET['pdf']) ? '1' : '0' ?>">
  <?= view('partials/print_bar', ['back' => url('app/receipts/'.$r['id'])]) ?>
  <div class="print-head">
    <div class="print-brand">
      <?php if (!empty($tpl['show_logo'])) echo Printing::logo($business); ?>
      <div class="biz"><?= e($business['name'] ?? '') ?></div>
      <div class="print-meta">
        <?php if (!empty($tpl['show_economic_code']) && !empty($business['economic_code'])): ?>کد اقتصادی: <b><?= e($business['economic_code']) ?></b><br><?php endif; ?>
        <?= e($business['address'] ?? '') ?><?php if (!empty($business['phone'])): ?><br>تلفن: <?= e($business['phone']) ?><?php endif; ?></div>
    </div>
    <div style="text-align:left"><div style="font-size:15px;font-weight:700;color:var(--p-800)">رسید دریافت وجه</div>
      <div class="print-meta">شماره: <b><?= e(fa_digits((string)$r['doc_no'])) ?></b><br>تاریخ: <b><?= e(jdate($r['doc_date'])) ?></b></div></div>
  </div>
  <?php if (!empty($tpl['show_barcode'])) echo Printing::barcode((string)$r['doc_no']); ?>
  <div class="print-meta" style="margin:10px 0">
    دریافت شد از آقای/خانم/شرکت: <b><?= e(trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '').' '.($r['company_name'] ?? ''))) ?></b><br>
    مبلغ: <b><?= num($r['amount']) ?> <?= e(Auth::currency()) ?></b>
  </div>
  <?php if (!empty($tpl['amount_in_words'])): ?><div class="words">مبلغ به حروف: <?= e($amountWords) ?></div><?php endif; ?>
  <table class="print-tbl">
    <thead><tr><th>ردیف</th><th>بابت</th><th>شماره فاکتور</th><th>مبلغ</th></tr></thead>
    <tbody>
    <?php $i = 1; foreach ($lines as $l): ?>
      <tr><td><?= num($i++) ?></td><td><?= e($l['description'] ?? 'تسویه فاکتور') ?></td><td><?= e(fa_digits((string)($l['invoice_no'] ?? '—'))) ?></td><td><?= num($l['amount']) ?></td></tr>
    <?php endforeach; ?>
    <?php if (!$lines): ?><tr><td>۱</td><td>علی‌الحساب</td><td>—</td><td><?= num($r['amount']) ?></td></tr><?php endif; ?>
    </tbody>
  </table>
  <?php if (!empty($tpl['show_bank_info'])) echo Printing::bankBlock(); ?>
  <?php if (!empty($tpl['show_signature'])): ?><div class="signs"><span>امضای دریافت‌کننده</span><span>مهر و امضای شرکت</span></div><?php endif; ?>
</div>
<?= view('partials/public_foot') ?>
