<?= view('partials/head', ['title' => $title]) ?>
<?= view('partials/ai_upload', ['kind' => 'receipt', 'label' => 'رسید دریافت']) ?>
<form method="post" action="<?= url('app/receipts') ?>">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3>ثبت دریافت</h3><span class="pill">شماره بعدی: <?= e($nextNo) ?></span></div>
    <div class="form-grid">
      <div class="field"><label>دریافت از (شخص) <span class="req">*</span></label>
        <select class="inp select-search" name="person_id" data-person-select data-url-base="<?= url('app/receipts/create') ?>" required>
          <option value="">— انتخاب کنید —</option>
          <?php foreach ($persons as $p): $nm = trim(($p['first_name'] ?? '').' '.($p['last_name'] ?? '').' '.($p['company_name'] ?? '')); ?>
            <option value="<?= $p['id'] ?>" <?= $personId == $p['id'] ? 'selected' : '' ?>><?= e($p['code'].' — '.$nm) ?></option>
          <?php endforeach; ?>
        </select>
        <div class="hint"><a href="<?= url('app/receipts/create') ?>">بارگذاری فاکتورهای باز شخص</a></div></div>
      <div class="field"><label>تاریخ دریافت <span class="req">*</span></label>
        <input class="inp jalali" type="text" name="doc_date" data-value="<?= e(today()) ?>" value="<?= e(jdate(today())) ?>" required></div>
      <div class="field"><label>مبلغ دریافت <span class="req">*</span></label>
        <input class="inp money" type="text" name="amount" required placeholder="0"></div>
      <div class="field"><label>روش دریافت</label>
        <select class="inp" name="payment_kind" id="pay_kind">
          <option value="cash">نقد / کارت / حواله</option>
          <option value="cheque">چک</option>
        </select></div>
      <div class="field"><label>حساب نقد/بانک</label>
        <select class="inp" name="cash_account_id" required><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?>
            <option value="<?= $c['id'] ?>" <?= $c['id'] == $cashAccountId ? 'selected' : '' ?>><?= e($c['title'].' ('.num($c['current_balance']).')') ?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label>روش پرداخت</label>
        <select class="inp" name="payment_method_id"><option value="">— انتخاب —</option>
          <?php foreach ($methods as $m): ?><option value="<?= $m['id'] ?>"><?= e($m['title_fa']) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>شماره پیگیری بانکی</label><input class="inp" type="text" name="bank_reference"></div>
      <div class="field field-wide"><label>توضیحات</label><textarea class="inp" name="description" rows="2"></textarea></div>
    </div>
    <details id="cheque_box" style="margin-top:6px">
      <summary class="section-title" style="cursor:pointer">اطلاعات چک (در صورت دریافت چکی)</summary>
      <div class="form-grid">
        <div class="field"><label>شماره چک</label><input class="inp" type="text" name="cheque_no"></div>
        <div class="field"><label>بانک</label><input class="inp" type="text" name="bank_name"></div>
        <div class="field"><label>شعبه</label><input class="inp" type="text" name="branch_name"></div>
        <div class="field"><label>شماره حساب</label><input class="inp" type="text" name="account_no"></div>
        <div class="field"><label>شناسه صیادی</label><input class="inp" type="text" name="sayad_id"></div>
        <div class="field"><label>تاریخ صدور</label><input class="inp jalali" type="text" name="issue_date" data-value="<?= e(today()) ?>"></div>
        <div class="field"><label>تاریخ سررسید</label><input class="inp jalali" type="text" name="due_date"></div>
      </div>
    </details>
  </div>

  <div class="card">
    <div class="card-head"><h3>تخصیص به فاکتورهای باز</h3><div class="grow"></div>
      <button class="btn ghost sm" type="button" data-add-row="alloc">+ افزودن ردیف</button></div>
    <?php if ($personId && !$openInvoices): ?><div class="alert info">فاکتور تسویه‌نشده‌ای برای این شخص وجود ندارد؛ مبلغ به‌صورت علی‌الحساب ثبت می‌شود.</div><?php endif; ?>
    <div class="table-wrap"><table class="tbl" style="min-width:760px">
      <thead><tr><th>فاکتور</th><th>تاریخ</th><th>مانده فاکتور</th><th>مبلغ تخصیص</th><th>مانده بعد از تخصیص</th><th></th></tr></thead>
      <tbody data-rows="alloc"></tbody>
    </table></div>
    <template id="tpl-alloc">
      <td>
        <select name="alloc_invoice_id[]" class="inp select-search">
          <option value="">— انتخاب فاکتور —</option>
          <?php foreach ($openInvoices as $oi): ?>
            <option value="<?= $oi['id'] ?>" data-remain="<?= (float)$oi['remaining_amount'] ?>"><?= e(fa_digits((string)$oi['invoice_no']).' — '.jdate($oi['invoice_date'])) ?></option>
          <?php endforeach; ?>
        </select>
      </td>
      <td class="muted small"><?= e(jdate(today())) ?></td>
      <td><span class="badge off" data-remain="<?= $openInvoices ? (float)$openInvoices[0]['remaining_amount'] : 0 ?>"><?= num($openInvoices ? $openInvoices[0]['remaining_amount'] : 0) ?></span></td>
      <td><input class="inp money" type="text" name="alloc_amount[]" value=""></td>
      <td><span data-after>—</span></td>
      <td><button class="btn danger sm" type="button" data-del-row>×</button></td>
    </template>
    <div class="grid c2" style="margin-top:10px">
      <div><div class="muted small">جمع تخصیص‌ها</div><b><span id="sum_alloc">0</span></b></div>
      <div id="alloc_hint" class="alert info" style="margin:0">مبلغ دریافت را وارد کنید تا وضعیت تخصیص نمایش داده شود.</div>
    </div>
  </div>

  <div class="card"><div class="form-actions" style="border:none;padding:0;margin:0">
    <button class="btn success">ثبت دریافت و صدور سند</button>
    <a class="btn gray" href="<?= url('app/receipts') ?>">انصراف</a>
  </div></div>
</form>
<?= view('partials/foot') ?>
