<?= view('partials/head', ['title' => $title]) ?>
<div class="card">
  <div class="card-head"><h3>سند دریافت <?= e(fa_digits((string)$r['doc_no'])) ?></h3>
    <span class="pill st-<?= e($r['status']) ?>"><?= e(Meta::enumLabel($r['status'])) ?></span><div class="grow"></div>
    <?= print_buttons(url('app/receipts/'.$r['id'].'/print')) ?>
    <a class="btn ghost" href="<?= url('app/receipts') ?>">فهرست</a></div>
  <div class="grid c4">
    <div><div class="muted small">از شخص</div><b><?= e(trim(($r['first_name'] ?? '').' '.($r['last_name'] ?? '').' '.($r['company_name'] ?? ''))) ?></b></div>
    <div><div class="muted small">تاریخ</div><b><?= e(jdate($r['doc_date'])) ?></b></div>
    <div><div class="muted small">حساب</div><b><?= e($r['cash_title'] ?? '—') ?></b></div>
    <div><div class="muted small">مبلغ</div><b class="big-num" style="font-size:18px"><?= num($r['amount']) ?></b></div>
  </div>
  <?php if ($r['cheque_no']): ?><div class="alert info" style="margin-top:12px">این دریافت با چک شماره <b><?= e(fa_digits((string)$r['cheque_no'])) ?></b> انجام شده است.</div><?php endif; ?>
</div>
<div class="grid c2">
  <div class="card"><div class="card-head"><h3>تخصیص به فاکتورها</h3></div>
    <?php if (!$lines): ?><div class="muted small">تخصیصی ثبت نشده (علی‌الحساب).</div><?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:420px">
      <thead><tr><th>فاکتور</th><th>مبلغ فاکتور</th><th>تخصیص</th></tr></thead>
      <tbody><?php foreach ($lines as $l): ?>
        <tr><td><a href="<?= url('app/invoices/'.$l['invoice_id']) ?>"><?= e(fa_digits((string)($l['invoice_no'] ?? '#'.$l['invoice_id']))) ?></a></td>
          <td class="num"><?= num($l['total_amount']) ?></td><td class="num"><?= num($l['amount']) ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div>
  <div class="card"><div class="card-head"><h3>سند حسابداری</h3>
    <?php if ($je): ?><a class="btn ghost sm" href="<?= url('app/journal/'.$je['id']) ?>"><?= e(fa_digits((string)$je['entry_no'])) ?></a><?php endif; ?></div>
    <?php if (!$jeLines): ?><div class="muted small">سند حسابداری صادر نشده است.</div><?php else: ?>
    <div class="table-wrap"><table class="tbl" style="min-width:420px">
      <thead><tr><th>حساب</th><th>بدهکار</th><th>بستانکار</th></tr></thead>
      <tbody><?php foreach ($jeLines as $jl): ?>
        <tr><td><?= e($jl['account_code'].' — '.$jl['account_title']) ?></td>
          <td class="num"><?= (float)$jl['debit_amount'] ? num($jl['debit_amount']) : '—' ?></td>
          <td class="num"><?= (float)$jl['credit_amount'] ? num($jl['credit_amount']) : '—' ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <?php endif; ?>
  </div>
</div>
<?= view('partials/foot') ?>
