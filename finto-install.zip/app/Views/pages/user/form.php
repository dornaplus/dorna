<?= view('partials/head', ['title' => $title]) ?>
<?php $row = array_merge($row ?? [], $_SESSION['_old'] ?? []); $ubr = $ubr ?? []; ?>
<form method="post" action="<?= e($action) ?>" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="card">
    <div class="card-head"><h3><?= e($title) ?></h3><div class="grow"></div><a class="btn ghost sm" href="<?= url('app/users') ?>">فهرست کاربران</a></div>
    <?php if (!$isNew): ?>
      <div class="av-manage">
        <div class="av-preview"><?= Avatar::html($row['full_name'] ?? '', $row['avatar_path'] ?? '', 'avatar', 72) ?></div>
        <div class="av-manage-b">
          <div class="av-upload">
            <input type="file" name="avatar" accept=".jpg,.jpeg,.png,.webp,.gif">
            <button class="btn sm" type="submit">بارگذاری تصویر</button>
          </div>
          <?php if (!empty($row['avatar_path'])): ?>
            <button class="btn gray sm" type="submit" name="remove_avatar" value="1" onclick="return confirm('تصویر پروفایل این کاربر حذف شود؟')">حذف تصویر</button>
          <?php endif; ?>
          <div class="hint">تصویر پروفایل این کاربر — JPG، PNG، WEBP یا GIF (حداکثر ۳ مگابایت).</div>
        </div>
      </div>
    <?php endif; ?>
    <?php foreach ($groups as $gtitle => $fields): ?>
      <div class="section-title"><?= e($gtitle) ?></div>
      <div class="form-grid">
        <?php foreach ($fields as $f): ?><?= Fields::render($f, $row[$f['name']] ?? null, ['row' => $row]) ?><?php endforeach; ?>
        <?php if ($f === end($fields) && in_array('mobile', array_map(fn($x) => $x['name'], $fields), true)): ?>
          <div class="field"><label><?= $isNew ? 'رمز عبور اولیه' : 'رمز عبور جدید (اختیاری)' ?> <?= $isNew ? '<span class="req">*</span>' : '' ?></label>
            <input class="inp" type="password" name="password_hash" autocomplete="new-password" <?= $isNew ? 'required minlength="8"' : '' ?>></div>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
  </div>

  <div class="card">
    <div class="card-head"><h3>نقش و دسترسی در این کسب‌وکار</h3></div>
    <div class="form-grid">
      <div class="field"><label>نقش کاربر <span class="req">*</span></label>
        <select class="inp" name="role_id" required><option value="">— انتخاب نقش —</option>
          <?php foreach ($roles as $r): ?>
            <option value="<?= $r['id'] ?>" <?= (string)($roleId ?? '') === (string)$r['id'] ? 'selected' : '' ?>><?= e($r['name']) ?></option>
          <?php endforeach; ?></select>
        <div class="hint">نقش‌های دلخواه را در <a href="<?= url('app/roles') ?>">سطح دسترسی</a> بسازید.</div></div>
      <div class="field"><label>حداکثر تخفیف مجاز (٪)</label><input class="inp" type="number" step="any" name="max_discount_percent" value="<?= e($ubr['max_discount_percent'] ?? 0) ?>"></div>
      <div class="field"><label>مشاهده بهای تمام‌شده</label>
        <label class="switch"><input type="checkbox" name="can_see_cost" value="1" <?= !empty($ubr['can_see_cost']) ? 'checked' : '' ?>><span></span></label></div>
      <div class="field"><label>انبار پیش‌فرض</label>
        <select class="inp" name="default_warehouse_id"><option value="">— انتخاب —</option>
          <?php foreach ($warehouses as $w): ?>
            <option value="<?= $w['id'] ?>" <?= (string)($ubr['default_warehouse_id'] ?? '') === (string)$w['id'] ? 'selected' : '' ?>><?= e($w['title']) ?></option>
          <?php endforeach; ?></select></div>
      <div class="field"><label>صندوق/بانک پیش‌فرض</label>
        <select class="inp" name="default_cash_account_id"><option value="">— انتخاب —</option>
          <?php foreach ($cashAccounts as $c): ?>
            <option value="<?= $c['id'] ?>" <?= (string)($ubr['default_cash_account_id'] ?? '') === (string)$c['id'] ? 'selected' : '' ?>><?= e($c['title']) ?></option>
          <?php endforeach; ?></select></div>
    </div>
    <div class="form-actions"><button class="btn"><?= $isNew ? 'ثبت کاربر' : 'ذخیره تغییرات' ?></button>
      <a class="btn gray" href="<?= url('app/users') ?>">انصراف</a>
      <?php if (!$isNew && Auth::can('users.edit')): ?>
        <div class="spacer"></div>
        <button class="btn ghost" formaction="<?= url('app/users/'.$row['id'].'/password') ?>" formmethod="post" name="new_password" value="1">بازنشانی رمز</button>
      <?php endif; ?>
    </div>
  </div>
</form>
<?= view('partials/foot') ?>
