<?php
/** کارت «تحلیل هوشمند» — قابل استفاده در هر بخش.
 *  @var string $scope  dashboard|resource|record|report|audit
 *  @var string|null $module @var string|null $id @var string|null $title
 *  @var array|null $sample @var int|null $count
 */
$scope = $scope ?? 'dashboard';
?>
<?php if (Ai::enabled()): ?>
<div class="card ai-insight" data-ai-insight
     data-scope="<?= e($scope) ?>"
     data-module="<?= e($module ?? '') ?>"
     data-id="<?= e($id ?? '') ?>"
     data-title="<?= e($title ?? '') ?>"
     <?php if (!empty($sample)): ?>data-sample="<?= e(json_encode($sample, JSON_UNESCAPED_UNICODE)) ?>" data-count="<?= (int)($count ?? 0) ?>"<?php endif; ?>>
  <div class="card-head">
    <h3><?= icon('spark') ?> تحلیل هوشمند<?= !empty($title) ? ' — ' . e($title) : '' ?></h3>
    <div class="grow"></div>
    <button class="btn soft sm" type="button" data-ai-run><?= icon('spark', 15) ?> تحلیل کن</button>
  </div>
  <div class="ai-insight-out"><div class="muted sm">برای دریافت تحلیل هوش مصنوعی از این بخش، روی «تحلیل کن» بزنید.</div></div>
</div>
<?php endif; ?>
