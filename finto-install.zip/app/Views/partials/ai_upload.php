<?php
/** جعبهٔ «بارگذاری سند و استخراج خودکار» برای فرم‌های ثبت.
 *  @var string $kind  invoice|receipt|payment|cheque|stock_doc|stock_transfer
 *  @var string|null $label
 */
$kind = $kind ?? 'invoice';
?>
<?php if (Ai::enabled()): ?>
<div class="card tight ai-upload" data-ai-upload data-kind="<?= e($kind) ?>">
  <div class="card-head">
    <h3><?= icon('spark') ?> بارگذاری سند و استخراج خودکار<?= !empty($label) ? ' — ' . e($label) : '' ?></h3>
    <div class="grow"></div>
    <span class="badge off">نیازمند تأیید شما</span>
  </div>
  <div class="ai-up-row">
    <input type="file" class="inp" accept=".pdf,.png,.jpg,.jpeg,.webp" data-ai-file>
    <button type="button" class="btn soft sm" data-ai-extract><?= icon('spark', 15) ?> استخراج اطلاعات</button>
  </div>
  <div class="help" style="margin-top:6px">سند را به‌صورت PDF یا تصویر انتخاب کنید؛ هوش مصنوعی اطلاعات را می‌خواند و فرم را <b>پیش‌پر</b> می‌کند. <b>هیچ‌چیز خودکار ثبت نمی‌شود</b>؛ پس از بازبینی، خودتان دکمهٔ ثبت را بزنید.</div>
  <div class="ai-up-out" data-ai-out></div>
</div>
<?php endif; ?>
