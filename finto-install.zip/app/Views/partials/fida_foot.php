  </main>
</div>
<button class="fab" type="button" onclick="location.href='<?= url('fida/invoices/create?type=sale') ?>'" aria-label="فاکتور جدید">
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14M5 12h14"/></svg>
</button>
<nav class="bnav"><div class="in">
  <?php $bn = [
    ['fida', 'داشبورد', 'M3.5 10.5 12 3.5l8.5 7V20a1 1 0 0 1-1 1H15v-6h-6v6H4.5a1 1 0 0 1-1-1v-9.5z'],
    ['fida/invoices', 'فاکتورها', 'M6 2.5h9l4 4V21a.5.5 0 0 1-.5.5h-12A.5.5 0 0 1 6 21V2.5z'],
    ['fida/items', 'کالا', 'M21 8 12 3 3 8v8l9 5 9-5V8z'],
    ['fida/persons', 'اشخاص', 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm-7 8c1-3.2 4-4.8 7-4.8s6 1.6 7 4.8'],
    ['fida/reports', 'گزارش‌ها', 'M5 20V10M12 20V4M19 20v-7'],
  ]; foreach ($bn as $b): $base = url($b[0]); $bp = rtrim(url_path($b[0]), '/'); $cp = rtrim(current_path(), '/'); $on = ($cp === $bp) || ($b[0] !== 'fida' && str_starts_with($cp, $bp . '/')); ?>
    <button class="navb <?= $on ? 'on' : '' ?>" type="button" onclick="location.href='<?= $base ?>'">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="<?= $b[2] ?>"/></svg><span><?= e($b[1]) ?></span></button>
  <?php endforeach; ?>
</div></nav>
<div class="toast-wrap"><?php foreach (Flash::all() as $f): ?><div class="toast <?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?></div>
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>; window.CSRF = <?= json_encode(csrf_token()) ?>;</script>
<script>
/* ── زنگ اعلان‌ها ── */
(function () {
  var btn = document.getElementById('bellBtn'), pop = document.getElementById('notifPop');
  var list = document.getElementById('notifList'), badge = document.getElementById('bellBadge');
  if (!btn || !pop || !list) return;
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]; }); }
  function render(d) {
    if (badge) {
      var n = d.unread || 0;
      badge.textContent = Number(n).toLocaleString('fa-IR');
      badge.classList.toggle('hide', n === 0);
    }
    var items = d.items || [];
    if (!items.length) { list.innerHTML = '<div class="notif-empty">🔔 اعلان جدیدی نداری</div>'; return; }
    list.innerHTML = items.slice(0, 6).map(function (it) {
      return '<div class="notif-item' + (it.read ? ' is-read' : '') + '" data-key="' + esc(it.key) + '">'
        + '<a class="ni-body" href="' + it.url + '">'
        +   '<span class="notif-ic ' + it.severity + '">' + it.icon + '</span>'
        +   '<span class="notif-main">'
        +     '<span class="notif-top"><b>' + esc(it.title) + '</b><i class="notif-when">' + esc(it.when) + '</i></span>'
        +     '<small>' + esc(it.desc) + '</small>'
        +   '</span>'
        + '</a>'
        + '<button class="notif-del" type="button" title="حذف این اعلان" aria-label="حذف این اعلان" data-del="' + esc(it.key) + '">×</button>'
        + '</div>';
    }).join('')
    + '<div class="notif-foot">'
    +   '<button class="notif-all" type="button" data-readall="1">خوانده‌شدن همه</button>'
    +   '<button class="notif-all danger" type="button" data-dismissall="1">حذف همه</button>'
    + '</div>'
    + '<a class="notif-all" href="' + window.APP_BASE + '/fida/notifications">مشاهدهٔ همهٔ اعلان‌ها</a>';
  }
  function load() {
    fetch(window.APP_BASE + '/fida/notifications/feed', { credentials: 'same-origin' })
      .then(function (r) { return r.json(); }).then(render).catch(function () {});
  }
  // حذف یک اعلان / خوانده‌شدن / حذف همه — فقط برای همین کاربر
  function post(path, data) {
    var body = new URLSearchParams(data || {});
    body.append('_token', window.CSRF || '');
    return fetch(window.APP_BASE + path, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: body.toString(), credentials: 'same-origin' });
  }
  list.addEventListener('click', function (e) {
    var del = e.target.closest('[data-del]');
    if (del) {
      e.preventDefault(); e.stopPropagation();
      var key = del.getAttribute('data-del');
      post('/fida/notifications/dismiss', { key: key, ajax: '1' }).then(function () {
        var row = del.closest('.notif-item'); if (row) row.remove();
        load();
      }).catch(function () {});
      return;
    }
    var ra = e.target.closest('[data-readall]');
    if (ra) { e.preventDefault(); e.stopPropagation(); post('/fida/notifications/read-all', { ajax: '1' }).then(load).catch(function () {}); return; }
    var da = e.target.closest('[data-dismissall]');
    if (da) {
      e.preventDefault(); e.stopPropagation();
      if (!window.confirm('همهٔ اعلان‌ها برای شما حذف شوند؟ (فقط برای پروفایل شما)')) return;
      post('/fida/notifications/dismiss-all', { ajax: '1' }).then(function () { list.innerHTML = '<div class="notif-empty">🔔 اعلان جدیدی نداری</div>'; load(); }).catch(function () {});
      return;
    }
    var body = e.target.closest('.ni-body');
    if (body) {
      var row2 = body.closest('.notif-item');
      if (row2) post('/fida/notifications/read', { key: row2.getAttribute('data-key'), ajax: '1' }).catch(function () {});
    }
  });

  btn.addEventListener('click', function (e) {
    e.stopPropagation();
    pop.hidden = !pop.hidden;
    if (!pop.hidden) load();
  });
  document.addEventListener('click', function () { pop.hidden = true; });
  pop.addEventListener('click', function (e) { e.stopPropagation(); });
  load();
})();
</script>
<script src="<?= asset('app.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/app.js') ?: 9 ?>"></script>
<script>window.PWA_APP = 'fida';</script>
<script src="<?= asset('pwa.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/pwa.js') ?: 1 ?>"></script>
</body></html>
