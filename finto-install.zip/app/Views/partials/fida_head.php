<?php
$u = Auth::user(); $name = $u['full_name'] ?? 'کاربر'; $initials = mb_substr(trim((string)$name) ?: 'ف', 0, 2);
$fset = class_exists('Fida') ? Fida::settings() : [];
$nbadge = class_exists('FidaNotice') ? FidaNotice::badge((int)Auth::id()) : ['unread' => 0, 'urgent' => 0];
?>
<!DOCTYPE html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= e($title ?? 'فیدا') ?> | اپ فاکتور زنی</title>
<?php /* ── PWA: نصب روی گوشی (اندروید/کروم و iPhone/iPad) ── */ ?>
<meta name="theme-color" content="#6D28D9">
<meta name="color-scheme" content="light">
<meta name="description" content="فیدا — صدور فاکتور و پیش‌فاکتور، کالا و مشتری، چک، تقویم کاری و گزارش‌ها؛ سریع و ساده روی گوشی.">
<link rel="manifest" href="<?= url('manifest-fida.webmanifest') ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= asset('pwa/fida-32.png') ?>">
<link rel="icon" href="<?= asset('pwa/favicon.ico') ?>" sizes="any">
<link rel="apple-touch-icon" href="<?= asset('pwa/fida-180.png') ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="فیدا">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="stylesheet" href="<?= asset('fida.css') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/fida.css') ?: 6 ?>">
</head><body>
<div class="app">
  <header class="topbar">
    <img src="<?= asset('fida-owl.png') ?>" alt="فیدا">
    <div class="t">اپ فاکتور زنی<small><?= e($fset['shop_name'] ?? 'فروشگاه من') ?> · <?= e(jdate(today())) ?></small></div>
    <div class="grow"></div>

    <button class="icon-btn" type="button" onclick="location.href='<?= url('fida/calendar') ?>'" aria-label="تقویم من" title="تقویم من">
      <svg viewBox="0 0 24 24" width="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3.5" y="5" width="17" height="16" rx="3"/><path d="M8 3v4M16 3v4M3.5 10h17"/><path d="M8 14h3M8 17.5h7"/>
      </svg>
    </button>

    <button class="icon-btn bell" type="button" id="bellBtn" aria-label="اعلان‌ها">
      <svg viewBox="0 0 24 24" width="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
        <path d="M18 8.5a6 6 0 1 0-12 0c0 5-2 6.5-2 6.5h16s-2-1.5-2-6.5z"/><path d="M10.3 19a2 2 0 0 0 3.4 0"/>
      </svg>
      <span class="badge<?= ((int)($nbadge['unread'] ?? 0)) === 0 ? ' hide' : '' ?>" id="bellBadge"><?= num($nbadge['unread'] ?? 0) ?></span>
    </button>

    <span class="gold-chip" onclick="location.href='<?= url('fida/gold') ?>'">⭐ <span class="gc-t">اشتراک طلایی</span></span>
    <button class="icon-btn" type="button" onclick="location.href='<?= url('fida/settings') ?>'" aria-label="تنظیمات">
      <svg viewBox="0 0 24 24" width="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M4.6 4.6l2.1 2.1M17.3 17.3l2.1 2.1M2.5 12h3M18.5 12h3M4.6 19.4l2.1-2.1M17.3 6.7l2.1-2.1"/></svg>
    </button>
    <button class="icon-btn" type="button" onclick="location.href='<?= url('fida/logout') ?>'" aria-label="خروج" title="<?= e($name) ?> — خروج">
      <svg viewBox="0 0 24 24" width="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M15 12H4M8 8l-4 4 4 4M14 4h5v16h-5"/></svg>
    </button>
  </header>

<?php
  // ── سهم رایگان (۵ فاکتور) و پیشنهاد اشتراک — فقط در فیدا ──
  $__uri = (string)($_SERVER['REQUEST_URI'] ?? '');
  $__skip = str_contains($__uri, '/fida/gold') || str_contains($__uri, '/fida/login') || str_contains($__uri, '/fida/verify');
  $__st = class_exists('Fida') ? Fida::accessState((int)Auth::id()) : null;
  $__msg = ($__st && !$__st['is_gold']) ? Fida::upgradeMessages($__st) : null;
  $__cheap = class_exists('Fida') ? (int)Database::val('SELECT MIN(price) FROM fida_gold_plans WHERE is_active=1', [], 0) : 0;
?>
<?php if ($__st && !$__st['is_gold'] && !$__skip): ?>
  <div class="free-bar<?= $__st['remaining'] <= 0 ? ' warn' : '' ?>" id="freeBar">
    <?php if ($__st['remaining'] > 0): ?>
      <span>🎁 <b>نسخهٔ رایگان</b> — <?= num((int)$__st['remaining']) ?> فاکتور رایگان باقی مانده (از <?= num((int)$__st['limit']) ?>)</span>
      <button class="fb-cta" type="button" onclick="location.href='<?= url('fida/gold') ?>'">⭐ ارتقا به طلایی</button>
    <?php else: ?>
      <span>⭐ <b>اشتراک لازم است</b> — برای ثبت فاکتور و پیش‌فاکتور جدید، اشتراکت رو فعال کن</span>
      <button class="fb-cta" type="button" onclick="location.href='<?= url('fida/gold') ?>'">خرید اشتراک</button>
    <?php endif; ?>
  </div>
<?php endif; ?>

<?php if ($__st && !empty($__st['show_popup']) && !$__skip && $__msg): ?>
  <div class="submodal" id="subModal" hidden>
    <div class="sub-card" role="dialog" aria-modal="true" aria-label="پیشنهاد اشتراک طلایی">
      <div class="sub-head">
        <span class="sub-badge">پیشنهاد ویژه</span>
        <div class="crown">⭐</div>
        <h3><?= e($__msg['title']) ?></h3>
        <p><?= e($__msg['sub']) ?></p>
      </div>
      <div class="sub-body">
        <div class="sub-offer">
          <b>🎁 با اشتراک طلایی این‌ها را داری:</b>
          <div class="sub-opts">
            <div class="sub-opt"><i>♾️</i><span>سطر نامحدود در فاکتور — دیگر نگران تعداد ردیف نباش</span></div>
            <div class="sub-opt"><i>📄</i><span>چاپ و خروجی PDF بدون لیبل فیدا (آمادهٔ تحویل به مشتری)</span></div>
            <div class="sub-opt"><i>🧾</i><span>ذخیرهٔ محصولات و خدمات با قیمت، برای فاکتورزنی سریع</span></div>
            <div class="sub-opt"><i>🧍</i><span>مدیریت مشتریان و بدهکاران با پیگیری مانده</span></div>
            <div class="sub-opt"><i>☁️</i><span>پشتیبان‌گیری امن از همهٔ فاکتورها و بازیابی هر زمان</span></div>
            <div class="sub-opt"><i>🎧</i><span>پشتیبانی ویژهٔ کاربران طلایی</span></div>
          </div>
        </div>
        <div class="sub-note">
          <span>💡</span>
          <span>اگر در این مدت راضی بودی، همین حالا اشتراک رو فعال کن تا کارت بدون وقفه جلو بره و نیازهای کسب‌وکارت رو راحت و بی‌دغدغه رفع کنی.</span>
        </div>
      </div>
      <div class="sub-foot">
        <div class="row2">
          <button class="btn btn-p" type="button" onclick="location.href='<?= url('fida/gold') ?>'">⭐ فعال‌سازی اشتراک<?= $__cheap ? ' از ' . num($__cheap) . ' تومان' : '' ?></button>
          <button class="btn btn-g" type="button" onclick="fidaSubLater()">بعداً</button>
        </div>
        <div class="sub-code">🎟️ با کد تخفیف <b dir="ltr">FIDA20</b> ارزان‌تر بخر — کد را در صفحهٔ اشتراک وارد کن.</div>
      </div>
    </div>
  </div>
  <script>
  function fidaSubLater(){ try{ sessionStorage.setItem('fidaSubDismissed','1'); }catch(e){} var m=document.getElementById('subModal'); if(m) m.hidden=true; }
  (function(){ try{ if(sessionStorage.getItem('fidaSubDismissed')==='1') return; }catch(e){}
    var m=document.getElementById('subModal'); if(m) setTimeout(function(){ m.hidden=false; }, 600); })();
  document.addEventListener('keydown', function(e){ if(e.key==='Escape') fidaSubLater(); });
  </script>
<?php endif; ?>

  <div class="notif-pop" id="notifPop" hidden>
    <div class="notif-pop-head">
      <b>اعلان‌ها</b>
      <a href="<?= url('fida/notifications') ?>">مشاهدهٔ همه</a>
    </div>
    <div class="notif-pop-list" id="notifList">
      <div class="notif-empty">در حال بارگذاری…</div>
    </div>
  </div>

  <main>
