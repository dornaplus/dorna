    </div>
  </div>
</div>
<nav class="bottom-nav">
  <?php foreach ([
    ['app', 'داشبورد', 'gauge', 'dashboard.view', ''],
    ['app/invoices', 'فاکتور', 'receipt', 'invoices.view', 'invoice'],
    ['app/persons', 'اشخاص', 'users', 'persons.view', 'person'],
    ['app/products', 'کالا', 'box', 'products.view', 'product'],
  ] as [$bnUrl, $bnLabel, $bnIcon, $bnPerm, $bnMatch]):
    if ($bnUrl === 'app' && !Auth::isAdmin()) continue;   // داشبورد فقط برای مدیر سیستم
    if ($bnPerm && !Auth::can($bnPerm)) continue;
    $bnOn = $bnMatch === '' ? (current_path() === url_path($bnUrl)) : str_contains(current_path(), $bnMatch); ?>
    <a href="<?= url($bnUrl) ?>" class="<?= $bnOn ? 'on' : '' ?>"><span class="bn-ic"><?= icon($bnIcon, 22) ?></span><span><?= $bnLabel ?></span></a>
  <?php endforeach; ?>
  <button type="button" data-burger class="bn-menu"><span class="bn-ic"><?= icon('list', 22) ?></span><span>منو</span></button>
</nav>
<div class="modal-backdrop" id="modal-biz">
  <div class="modal">
    <h3>تغییر کسب‌وکار</h3>
    <div class="small muted" style="margin-bottom:10px">کسب‌وکارهای در دسترس شما:</div>
    <?php foreach (Auth::businesses() as $b): ?>
      <form method="post" action="<?= url('app/switch-business/'.$b['id']) ?>" style="margin-bottom:6px">
        <?= csrf_field() ?>
        <button class="btn <?= Auth::businessId() == $b['id'] ? 'soft' : 'gray' ?>" style="width:100%;justify-content:space-between">
          <span><?= e($b['name']) ?></span><span class="small muted"><?= e($b['role_name'] ?? '') ?></span>
        </button>
      </form>
    <?php endforeach; ?>
    <div class="btn-row" style="margin-top:12px">
      <a class="btn ghost sm" href="<?= url('onboarding/business') ?>">+ کسب‌وکار جدید</a>
      <div class="spacer"></div>
      <button class="btn gray sm" data-close type="button">بستن</button>
    </div>
  </div>
</div>
<script src="<?= asset('app.js') ?>?v=<?= time() ?>"></script>
<script>window.PWA_APP = 'finto';</script>
<script src="<?= asset('pwa.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/pwa.js') ?: 1 ?>"></script>
</body>
</html>
