<?php
$u = Auth::user(); $biz = Auth::business(); $flash = Flash::all();
$fullName = $u['full_name'] ?? 'کاربر';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#7C3AED">
<meta name="color-scheme" content="light">
<meta name="description" content="<?= e(config('app')['name']) ?>">
<title><?= e($title ?? 'فینتو') ?> | <?= e(config('app')['short_name']) ?></title>
<?php /* ── PWA: نصب روی گوشی ── */ ?>
<link rel="manifest" href="<?= url('manifest-finto.webmanifest') ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= asset('pwa/finto-32.png') ?>">
<link rel="icon" href="<?= asset('pwa/favicon.ico') ?>" sizes="any">
<link rel="apple-touch-icon" href="<?= asset('pwa/finto-180.png') ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="فینتو">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="preload" as="font" type="font/woff2" href="<?= asset('fonts/Vazirmatn-Regular.woff2') ?>" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="<?= asset('fonts/Vazirmatn-SemiBold.woff2') ?>" crossorigin>
<link rel="stylesheet" href="<?= asset('theme.css') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/theme.css') ?: '1' ?>">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>; window.CSRF = <?= json_encode(csrf_token()) ?>;</script>
</head>
<body>
<?php
// ── قفل اشتراک: نوار هشدار + پاپ‌آپ پیشنهاد (فقط وقتی اشتراک فعال نیست) ──
$__billing = class_exists('Billing') ? Billing::state() : null;
$__lockUri = (string)($_SERVER['REQUEST_URI'] ?? '');
$__lockSkip = str_contains($__lockUri, '/app/plans') || str_contains($__lockUri, '/app/subscription') || str_contains($__lockUri, '/login');
if ($__billing && empty($__billing['is_active']) && !$__lockSkip):
?>
  <div class="sub-lock-bar">
    <span>🔒 <b>اشتراک شما به پایان رسیده است</b> — ثبت اطلاعات و مشاهدهٔ گزارش‌ها قفل شده است.</span>
    <a class="sb-cta" href="<?= url('app/plans') ?>">⭐ فعال‌سازی اشتراک</a>
  </div>
  <div class="sub-lock" id="subLock" hidden>
    <div class="sub-lock-card" role="dialog" aria-modal="true" aria-label="پیشنهاد اشتراک">
      <div class="sub-lock-head">
        <div style="font-size:26px">👑</div>
        <h3><?= $__billing['expired'] ? 'اشتراک شما به پایان رسید' : 'برای استفاده از فینتو، اشتراک فعال کن' ?></h3>
        <p>با تمدید اشتراک، همهٔ بخش‌ها و گزارش‌های نرم‌افزار بدون محدودیت باز می‌شوند و ثبت اطلاعات ادامه پیدا می‌کند.</p>
      </div>
      <div class="sub-lock-body">
        <div class="sub-opts">
          <?php foreach (array_slice(Billing::FEATURES, 0, 6) as $f): ?>
            <div class="sub-opt"><i><?= $f['icon'] ?></i><span><?= e($f['title']) ?> — <b><?= e($f['hint']) ?></b></span></div>
          <?php endforeach; ?>
          <div class="sub-opt"><i>🔒</i><span>با اشتراک منقضی، هیچ سندی ثبت نمی‌شود و گزارش‌ها بسته است</span></div>
        </div>
        <div class="sub-opts" style="margin-top:10px">
          <div class="sub-note" style="display:flex;gap:8px;font-size:12.5px;line-height:2;background:var(--p50);border:1px solid var(--line);border-radius:14px;padding:11px 12px;color:var(--p900);font-weight:600">
            <span>💡</span><span>اگر این مدت از فینتو راضی بودی، همین حالا اشتراک رو فعال کن و کار حسابداری کسب‌وکارت رو بدون وقفه و بی‌دغدغه ادامه بده.</span>
          </div>
        </div>
      </div>
      <div class="sub-lock-foot">
        <div class="row2">
          <a class="btn btn-p" href="<?= url('app/plans') ?>">⭐ مشاهدهٔ پکیج‌ها و فعال‌سازی</a>
          <button class="btn ghost" type="button" onclick="document.getElementById('subLock').hidden=true">بعداً</button>
        </div>
      </div>
    </div>
  </div>
  <script>
  (function(){ try{ if(sessionStorage.getItem('fintoSubLater')==='1') return; }catch(e){}
    var m=document.getElementById('subLock'); if(m) setTimeout(function(){ m.hidden=false; }, 500); })();
  </script>
<?php endif; ?>
<div class="sidebar-backdrop"></div>
<div class="toast-wrap">
  <?php foreach ($flash as $f): ?><div class="toast <?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>
</div>
<div class="app">
  <aside class="sidebar"><?= view('partials/sidebar') ?></aside>
  <div class="main">
    <header class="topbar">
      <button class="icon-btn burger" data-burger type="button" aria-label="باز و بسته کردن منو"><?= icon('list', 20) ?></button>
      <div class="page-title"><?= e($title ?? '') ?></div>
      <div class="grow"></div>

      <div class="searchbox">
        <span class="mag"><?= icon('search', 16) ?></span>
        <input type="text" placeholder="جست‌وجوی سریع…" data-quick-search>
        <kbd class="sb-kbd">Alt + K</kbd>
        <div class="search-results"></div>
      </div>

      <?php if ($biz): ?>
      <button class="chip chip-biz" type="button" data-modal="modal-biz" title="تغییر کسب‌وکار">
        <?= icon('bank', 15) ?>
        <span class="chip-biz-name"><?= e(mb_strimwidth($biz['name'], 0, 24, '…')) ?></span>
        <?= icon('down', 12) ?>
      </button>
      <?php endif; ?>

      <div class="chip tb-date" title="<?= e(weekday_fa()) ?>"><?= icon('calendar', 15) ?><span class="tb-date-d"><?= e(jdate(today())) ?></span><span class="tb-date-w"><?= e(weekday_fa()) ?></span></div>

      <?php if (Auth::isAdmin()): ?><a class="icon-btn" href="<?= url('app/tickets/create') ?>" title="پشتیبانی" aria-label="پشتیبانی"><?= icon('lifebuoy', 18) ?></a><?php endif; ?>

      <div class="tb-sep"></div>

      <div class="tb-host">
        <button class="icon-btn msg-btn" id="msgBtn" type="button" aria-label="پیام‌ها" aria-expanded="false">
          <?= icon('mail') ?><span class="badge msg-badge hide" id="msgBadge">۰</span>
        </button>
        <div class="drop" id="dropMsg">
          <div class="drop-head"><b>پیام‌ها</b><span class="badge purple" id="msgCount">—</span></div>
          <div class="drop-body" id="msgList"><div class="drop-empty">در حال بارگذاری…</div></div>
          <a class="drop-link" href="<?= url('app/messages') ?>">مشاهدهٔ همهٔ پیام‌ها</a>
        </div>
      </div>
      <div class="tb-host">
        <button class="icon-btn" id="notifBtn" type="button" aria-label="اعلان‌ها" aria-expanded="false">
          <?= icon('bell') ?><span class="dot" id="notifDot" hidden></span>
        </button>
        <div class="drop" id="dropNotif">
          <div class="drop-head"><b>اعلان‌ها</b><span class="badge purple" id="notifCount">—</span></div>
          <div class="drop-body" id="notifList"><div class="drop-empty">در حال بارگذاری…</div></div>
          <div class="drop-foot" data-notif-foot hidden>
            <div class="drop-link" data-notif-readall style="cursor:pointer">خوانده‌شدن همه</div>
            <div class="drop-link danger" data-notif-dismissall style="cursor:pointer">حذف همه</div>
          </div>
          <?php $canInv = route_allowed('app/invoices'); $canChq = route_allowed('app/cheques'); ?>
          <?php if ($canInv || $canChq): ?>
          <div class="drop-actions" data-can-invoice="<?= $canInv ? '1' : '0' ?>" data-can-cheque="<?= $canChq ? '1' : '0' ?>">
            <?php if ($canInv): ?><a class="drop-link" href="<?= url('app/invoices') ?>">اعلان‌های فاکتورها</a><?php endif; ?>
            <?php if ($canChq): ?><a class="drop-link" href="<?= url('app/cheques') ?>">اعلان‌های چک‌ها</a><?php endif; ?>
          </div>
          <?php endif; ?>
        </div>
      </div>

      <div class="tb-sep"></div>

      <a href="<?= url('app/my-account') ?>" class="av-link" title="حساب کاربری"><?= Avatar::chip($u) ?></a>
      <a class="icon-btn logout-btn" href="<?= url('logout') ?>" title="خروج از حساب" aria-label="خروج"><?= icon('logout', 18) ?></a>
    </header>
    <div class="content">
      <?php if (!empty($_SESSION['_errors'])): ?>
        <div class="alert error"><b>خطاها:</b><div><?= implode('<br>', array_map('e', $_SESSION['_errors'])) ?></div></div>
        <?php unset($_SESSION['_errors']); ?>
      <?php endif; ?>
