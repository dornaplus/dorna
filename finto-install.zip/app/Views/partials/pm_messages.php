<?php /** @var array $rows پیام‌ها @var array $att پیوست‌ها به تفکیک پیام */ ?>
<?php foreach (($rows ?? []) as $m): $mine = (int)$m['sender_id'] === (int)Auth::id(); ?>
  <div class="pm-row <?= $mine ? 'me' : 'them' ?>" data-id="<?= (int)$m['id'] ?>">
    <?php if (!$mine): ?>
      <?= Avatar::html((string)($m['sender_name'] ?? ''), (string)($m['sender_avatar'] ?? ''), 'pm-av pm-msg-av', 30) ?>
    <?php endif; ?>
    <div class="pm-bubble">
      <?php if (!$mine): ?><span class="pm-who"><?= e((string)($m['sender_name'] ?? '—')) ?></span><?php endif; ?>
      <?php if (trim((string)($m['body'] ?? '')) !== ''): ?><div class="pm-text"><?= nl2br(e((string)$m['body'])) ?></div><?php endif; ?>
      <?php foreach ((array)($att[(int)$m['id']] ?? []) as $a): [$ic, $lbl] = Messages::fileKind((string)$a['file_name']); ?>
        <span class="pm-file-wrap">
          <a class="pm-file" href="<?= url('app/messages/file/' . (int)$a['id']) ?>" target="_blank" rel="noopener">
            <span class="pm-file-ic"><?= icon($ic, 15) ?></span>
            <span class="pm-file-b"><b><?= e($a['file_name']) ?></b><small><?= e($lbl) ?> · <?= num((int)round(((int)$a['size_bytes']) / 1024)) ?> کیلوبایت</small></span>
            <span class="pm-file-dl"><?= icon('download', 14) ?></span>
          </a>
          <?php if ((int)$a['user_id'] === (int)Auth::id() || Auth::isAdmin()): ?>
            <form method="post" action="<?= url('app/messages/file/' . (int)$a['id'] . '/delete') ?>" onsubmit="return confirm('این فایل حذف شود؟')" class="pm-file-del">
              <?= csrf_field() ?><input type="hidden" name="thread_id" value="<?= (int)$m['thread_id'] ?>"><button title="حذف فایل">×</button>
            </form>
          <?php endif; ?>
        </span>
      <?php endforeach; ?>
      <?php if ((int)$m['has_file'] === 1 && !empty($openEvents)): ?>
        <form class="pm-toev" method="post" action="<?= url('app/messages/to-event') ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="message_id" value="<?= (int)$m['id'] ?>">
          <input type="hidden" name="thread_id" value="<?= (int)$m['thread_id'] ?>">
          <select name="event_id" required title="افزودن این فایل‌ها به پروندهٔ یک رویداد برنامه‌ریز">
            <option value="">افزودن به رویداد…</option>
            <?php foreach ($openEvents as $ev): ?>
              <option value="<?= (int)$ev['id'] ?>"><?= e(mb_substr((string)$ev['title'], 0, 40)) ?> — <?= e(jdate((string)($ev['end_date'] ?: $ev['start_date']))) ?></option>
            <?php endforeach; ?>
          </select>
          <button class="pm-toev-btn" type="submit" title="افزودن به پروندهٔ رویداد"><?= icon('plus', 13) ?></button>
        </form>
      <?php endif; ?>
      <span class="pm-time"><?= e(jdate((string)$m['created_at'], '/', true)) ?></span>
    </div>
  </div>
<?php endforeach; ?>
