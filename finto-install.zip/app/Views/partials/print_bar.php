<?php /** نوار ابزار صفحه‌های چاپ — چاپ، ذخیره PDF و بازگشت. @var string|null $back */ ?>
<div class="print-bar no-print" role="toolbar" aria-label="ابزار چاپ">
  <button type="button" class="btn" data-print><?= icon('print') ?> چاپ</button>
  <button type="button" class="btn soft" data-print-pdf title="در پنجرهٔ چاپ، مقصد را «Save as PDF» انتخاب کنید"><?= icon('file') ?> ذخیره PDF</button>
  <span class="pb-spacer"></span>
  <?php if (!empty($back)): ?><a class="btn gray" href="<?= e($back) ?>"><?= icon('back') ?> بازگشت</a><?php endif; ?>
</div>
