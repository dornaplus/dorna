<script src="<?= asset('app.js') ?>?v=<?= time() ?>"></script>
<?php /* ثبت سرویس‌ورکر در صفحه‌های عمومی (ورود/ثبت‌نام) تا نصب اپ ممکن شود — بدون دکمهٔ شناور */ ?>
<script>window.PWA_APP = 'finto'; window.PWA_FAB = false; window.PWA_BTN = false;</script>
<script src="<?= asset('pwa.js') ?>?v=<?= @filemtime(__DIR__ . '/../../../public/assets/pwa.js') ?: 1 ?>"></script>
</body></html>
