<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#7C3AED">
<meta name="color-scheme" content="light">
<title><?= e($title ?? 'فینتو') ?></title>
<?php /* ── PWA: نصب روی گوشی ── */ ?>
<link rel="manifest" href="<?= url('manifest-finto.webmanifest') ?>">
<link rel="icon" type="image/png" sizes="32x32" href="<?= asset('pwa/finto-32.png') ?>">
<link rel="icon" href="<?= asset('pwa/favicon.ico') ?>" sizes="any">
<link rel="apple-touch-icon" href="<?= asset('pwa/finto-180.png') ?>">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="فینتو">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<link rel="preload" as="font" type="font/woff2" href="<?= asset('fonts/Vazirmatn-Regular.woff2') ?>" crossorigin>
<link rel="preload" as="font" type="font/woff2" href="<?= asset('fonts/Vazirmatn-SemiBold.woff2') ?>" crossorigin>
<link rel="stylesheet" href="<?= asset('theme.css') ?>?v=20261005a">
<script>window.APP_BASE = <?= json_encode(base_path(), JSON_UNESCAPED_UNICODE) ?>;</script>
</head>
<body>
<div class="toast-wrap">
  <?php foreach (Flash::all() as $f): ?><div class="toast <?= e($f['type']) ?>"><?= e($f['msg']) ?></div><?php endforeach; ?>
</div>
