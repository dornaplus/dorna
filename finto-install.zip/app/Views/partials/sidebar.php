<?php
$groups = Meta::NAV; $cur = current_path();
$biz = Auth::business();
$initials = '';
if ($biz && !empty($biz['name'])) $initials = mb_substr($biz['name'], 0, 2);
?>
<div class="brand">
  <div class="logo">فن</div>
  <div>
    <b>فینتو</b>
    <span>حسابداری و انبارداری</span>
  </div>
</div>
<?php foreach ($groups as $g):
  // بخش‌های ویژهٔ مدیر سیستم (داشبورد، تنظیمات، پشتیبانی، خرید پکیج) برای دیگر کاربران پنهان است
  if (!empty($g['admin_only']) && !Auth::isAdmin()) continue;
  // فقط گروه‌هایی که کاربر مجوز دیدنشان را دارد
  if (!empty($g['perm']) && !Auth::can((string)$g['perm'])) continue;
  if (!empty($g['route']) && !route_allowed((string)$g['route'])) continue;
  $items = array_values(array_filter($g['items'] ?? [], function ($it) {
      if (!empty($it['admin_only']) && !Auth::isAdmin()) return false;   // آیتم ویژهٔ مدیر
      if (!route_allowed($it['route'] ?? '')) return false;
      if (!empty($it['perm']) && !Auth::can((string)$it['perm'])) return false;   // مجوز اختصاصی همان آیتم
      return true;
  }));
  if (empty($items) && empty($g['route'])) continue;   // گروه بی‌مورد پنهان شود
  $g['items'] = $items;
  $active = false; $routes = array_column($g['items'], 'route');
  foreach ($routes as $r) { if (str_starts_with($cur, url_path(explode('?', $r)[0])) && explode('?', $r)[0] !== 'app' ) { $active = true; } }
  if (($g['key'] ?? '') === 'dashboard' && $cur === url_path('app')) $active = true;
  if (($g['key'] ?? '') === 'reports' && str_contains($cur, '/app/reports')) $active = true;
?>
  <div class="nav-group<?= $active ? ' active' : '' ?>">
    <?php if (empty($g['items']) && !empty($g['route'])): ?>
      <a class="nav-head nav-link" href="<?= url($g['route']) ?>">
        <span class="ico"><?= icons($g['icon'] ?? 'dot') ?></span>
        <span><?= e($g['title']) ?></span>
      </a>
    <?php else: ?>
    <div class="nav-head">
      <span class="ico"><?= icons($g['icon'] ?? 'dot') ?></span>
      <span><?= e($g['title']) ?></span>
      <?php if (!empty($g['items'])): ?><span class="caret">◀</span><?php endif; ?>
    </div>
    <?php if (!empty($g['items'])): ?>
      <div class="nav-sub">
        <?php if (!empty($g['route'])): ?><a class="<?= $cur === url($g['route']) ? 'on' : '' ?>" href="<?= url($g['route']) ?>"><?= e($g['title']) ?></a><?php endif; ?>
        <?php foreach ($g['items'] as $it): $link = explode('?', $it['route'])[0]; ?>
          <a class="<?= ($cur === url($it['route']) || ($cur.'?'.http_build_query($_GET) === url($it['route']) && str_contains($it['route'],'?'))) ? 'on' : '' ?>" href="<?= url($it['route']) ?>"><?= e($it['title']) ?></a>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>
<?php endforeach; ?>
<div class="card tight small muted" style="margin-top:14px">
  <div>نسخه <?= e(config('app')['version']) ?></div>
  <div>دیتابیس: <?= e(config('db')['name']) ?></div>
  <div><?= e(Auth::roleSlug() ? 'نقش: '.Auth::roleSlug() : '') ?></div>
</div>
<button class="btn soft sm" data-pwa-install hidden type="button" onclick="pwaInstall()" style="width:100%;margin-top:10px">📲 نصب فینتو روی گوشی</button>
