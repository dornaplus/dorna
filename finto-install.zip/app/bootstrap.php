<?php
/** راه‌اندازی نرم‌افزار: بارگذاری کلاس‌ها، نشست، منطقه زمانی و مدیریت خطا */
declare(strict_types=1);

foreach (['Helpers', 'Database', 'Schema', 'Auth', 'Ai', 'Services', 'Meta', 'Fields', 'Avatar', 'UserDocument', 'PersonActivity', 'StorageQuota', 'Portal', 'ManagementReport', 'Anomaly', 'Posting', 'Inventory', 'Trade', 'Provisioner', 'Router', 'Flash', 'Fida', 'FidaNotice', 'Bazaar', 'Backup', 'FidaBackup', 'Planner', 'Messages', 'Printing', 'PettyCash', 'Payroll', 'Migrator'] as $f) {
    require_once __DIR__.'/'.$f.'.php';
}
foreach (glob(__DIR__.'/Controllers/*.php') as $f) require_once $f;

// اطمینان از وجود پوشه‌های قابل‌نوشتن (مثلاً پس از آپلود روی هاست اشتراکی)
foreach ([__DIR__.'/../storage', __DIR__.'/../uploads'] as $dir) { if (!is_dir($dir)) @mkdir($dir, 0775, true); }

$app = config('app');
date_default_timezone_set($app['timezone']);
mb_internal_encoding('UTF-8');
setlocale(LC_ALL, $app['locale'].'.UTF-8', $app['locale'], 'fa_IR', 'C');
ini_set('display_errors', $app['debug'] ? '1' : '0');
error_reporting($app['debug'] ? E_ALL : E_ALL & ~E_DEPRECATED & ~E_NOTICE);

set_error_handler(function ($no, $str, $file, $line) {
    if (!(error_reporting() & $no)) return false;
    throw new ErrorException($str, 0, $no, $file, $line);
});
set_exception_handler(function (Throwable $e) {
    $msg = $e->getMessage();
    if (config('app')['debug']) $msg .= "\n\n".$e->getFile().':'.$e->getLine()."\n".$e->getTraceAsString();
    @file_put_contents(storage_path('error.log'), date('c').' | '.$e->getMessage().' | '.$e->getFile().':'.$e->getLine()."\n", FILE_APPEND);
    if (!headers_sent()) http_response_code(500);
    if (!headers_sent() && str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) { header('Content-Type: application/json'); echo json_encode(['ok' => false, 'error' => $e->getMessage()], JSON_UNESCAPED_UNICODE); return; }
    if (headers_sent()) { echo '<pre style="direction:rtl">'.htmlspecialchars($msg).'</pre>'; return; }
    render('errors/page', ['code' => 500, 'title' => 'خطا در پردازش درخواست', 'message' => $msg]);
});

// انتقال خودکار به HTTPS در صورت فعال بودن تنظیم (فقط درخواست‌های GET؛ تا ارسال فرم‌ها آسیب نبیند)
if (!empty($app['force_https']) && PHP_SAPI !== 'cli' && !headers_sent()
    && empty($_SERVER['HTTPS']) && (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') !== 'https')
    && strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $host = preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? ''));
    if ($host !== '') { header('Location: https://'.$host.($_SERVER['REQUEST_URI'] ?? '/'), true, 301); exit; }
}

// ورودی‌های عددی فارسی → لاتین (ذخیره در دیتابیس به‌صورت انگلیسی)
$_POST = normalize_request_digits($_POST);
$_GET  = normalize_request_digits($_GET);

Auth::start();
Migrator::run();   // مهاجرت‌های سبک و یک‌بارهٔ پایگاه‌داده (idempotent)
// پاک‌سازی پیام‌های یک‌بارمصرف در پایان درخواست (پس از نمایش در همین درخواست)
register_shutdown_function(static function (): void { Flash::age(); });
