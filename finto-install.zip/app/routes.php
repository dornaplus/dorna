<?php
/** جدول مسیرها — ترتیب مهم است: مسیرهای اختصاصی پیش از مسیرهای عمومی ماژول ثبت می‌شوند */
return function (Router $r): void {
    /* ── عمومی ── */
    $r->get('/', 'PageController@landing');
    // پورتال مشتری
    $r->any('/portal', 'PortalController@login');
    $r->any('/portal/verify', 'PortalController@verify');
    $r->get('/portal/logout', 'PortalController@logout');
    $r->get('/portal/dashboard', 'PortalController@dashboard');
    $r->post('/portal/upload-receipt', 'PortalController@uploadReceipt');
    $r->get('/portal/statement', 'PortalController@statement');
    $r->any('/login', 'AuthController@login');
    $r->any('/register', 'AuthController@register');
    $r->any('/verify', 'AuthController@verify');
    $r->post('/verify/resend', 'AuthController@resend');
    $r->any('/forgot', 'AuthController@forgot');
    $r->any('/reset', 'AuthController@reset');
    $r->get('/logout', 'AuthController@logout');
    $r->get('/terms', 'PageController@terms');

    /* ── راه‌اندازی اولیه ── */
    $r->any('/onboarding/profile', 'OnboardingController@profile');
    $r->any('/onboarding/business', 'OnboardingController@business');
    $r->get('/onboarding/done', 'OnboardingController@done');

    /* ── داخل نرم‌افزار ── */
    $r->get('/app', 'DashboardController@index');
    $r->get('/app/search', 'LookupController@quickSearch');
    $r->get('/app/lookup/{table}', 'LookupController@options');
    $r->any('/app/my-account', 'UserController@account');
    $r->post('/app/my-account/avatar', 'UserController@avatar');
    $r->post('/app/switch-business/{id}', 'UserController@switchBusiness');

    /* دستیار هوشمند (AI) */
    $r->get('/app/assistant', 'AiController@assistant');
    $r->post('/app/assistant/ask', 'AiController@ask');
    $r->post('/app/ai/categorize', 'AiController@categorize');
    $r->post('/app/ai/summary', 'AiController@summary');
    // پیام‌رسان داخلی کاربران
    $r->get('/app/messages', 'MessageController@index');
    $r->get('/app/messages/feed', 'MessageController@feed');
    $r->get('/app/messages/poll', 'MessageController@poll');
    $r->get('/app/messages/file/{id}', 'MessageController@file');
    $r->post('/app/messages/file/{id}/delete', 'MessageController@deleteFile');
    $r->post('/app/messages/send', 'MessageController@send');
    $r->post('/app/messages/group', 'MessageController@groupCreate');
    $r->post('/app/messages/to-event', 'MessageController@toEvent');
    $r->post('/app/messages/read', 'MessageController@read');
    // اسناد شخصی کاربران (مدیریت اسناد)
    $r->get('/app/documents', 'UserDocumentController@index');
    $r->post('/app/documents', 'UserDocumentController@store');
    $r->any('/app/documents/{id}/download', 'UserDocumentController@download');
    $r->post('/app/documents/{id}/delete', 'UserDocumentController@delete');
    // فضای ذخیره‌سازی
    $r->get('/app/storage', 'StorageController@index');
    $r->post('/app/storage/purchase', 'StorageController@purchase');
    // برنامه‌ریز (پلنر)
    $r->get('/app/planner', 'PlannerController@index');
    $r->get('/app/planner/settings', 'PlannerController@settings');
    $r->post('/app/planner/settings', 'PlannerController@settingsSave');
    $r->post('/app/planner/types', 'PlannerController@typeStore');
    $r->post('/app/planner/types/{id}/delete', 'PlannerController@typeDelete');
    $r->get('/app/planner/day', 'PlannerController@day');
    $r->post('/app/planner', 'PlannerController@store');
    $r->get('/app/planner/board', 'PlannerController@board');
    $r->post('/app/planner/ai/plan', 'PlannerController@aiPlan');
    $r->post('/app/planner/ai/parse', 'PlannerController@aiParse');
    $r->get('/app/planner/attach/{id}', 'PlannerController@attachment');
    $r->post('/app/planner/attach/{id}/delete', 'PlannerController@attachDelete');
    $r->get('/app/planner/{id}', 'PlannerController@show');
    $r->post('/app/planner/{id}', 'PlannerController@update');
    $r->post('/app/planner/{id}/status', 'PlannerController@status');
    $r->post('/app/planner/{id}/comment', 'PlannerController@comment');
    $r->post('/app/planner/{id}/attach', 'PlannerController@attach');
    $r->post('/app/planner/{id}/delete', 'PlannerController@delete');
    $r->get('/app/notifications', 'NotificationController@feed');
    $r->get('/app/notifications/status', 'NotificationController@status');
    $r->post('/app/notifications/state', 'NotificationController@state');
    $r->post('/app/notifications/all', 'NotificationController@all');

    /* اپ فاکتورزنی فیدا */
    /* ── اپ فاکتورزنی فیدا (بخش مستقل با لاگین اختصاصی) ── */
    $r->any('/fida/login', 'FidaController@login');
    $r->any('/fida/verify', 'FidaController@verify');
    $r->post('/fida/verify/resend', 'FidaController@authResend');
    $r->get('/fida/logout', 'FidaController@logout');
    $r->get('/fida', 'FidaController@dashboard');
    $r->get('/fida/invoices', 'FidaController@invoices');
    $r->get('/fida/invoices/create', 'FidaController@invoiceCreate');
    $r->post('/fida/invoices', 'FidaController@invoiceStore');
    $r->get('/fida/invoices/{id}', 'FidaController@invoiceShow');
    $r->post('/fida/payments', 'FidaController@paymentStore');
    $r->post('/fida/invoices/{id}/status', 'FidaController@invoiceStatus');
    $r->get('/fida/invoices/{id}/print', 'FidaController@invoicePrint');
    $r->post('/fida/invoices/{id}/convert', 'FidaController@invoiceConvert');
    $r->post('/fida/payments', 'FidaController@paymentStore');
    $r->get('/fida/cheques', 'FidaController@cheques');
    $r->get('/fida/cheques/create', 'FidaController@chequeForm');
    $r->get('/fida/cheques/{id}/edit', 'FidaController@chequeForm');
    $r->post('/fida/cheques', 'FidaController@chequeStore');
    $r->post('/fida/cheques/{id}/status', 'FidaController@chequeStatus');
    $r->post('/fida/cheques/{id}/delete', 'FidaController@chequeDelete');
    $r->get('/fida/notifications', 'FidaController@notifications');
    $r->get('/fida/notifications/feed', 'FidaController@notificationsFeed');
    $r->post('/fida/notifications/read', 'FidaController@notificationRead');
    $r->post('/fida/notifications/read-all', 'FidaController@notificationsReadAll');
    $r->post('/fida/notifications/dismiss', 'FidaController@notificationDismiss');
    $r->post('/fida/notifications/dismiss-all', 'FidaController@notificationsDismissAll');
    $r->get('/fida/persons', 'FidaController@persons');
    $r->get('/fida/persons/create', 'FidaController@personForm');
    $r->get('/fida/persons/{id}/edit', 'FidaController@personForm');
    $r->post('/fida/persons', 'FidaController@personStore');
    $r->get('/fida/persons/{id}', 'FidaController@personShow');
    $r->get('/fida/items', 'FidaController@items');
    $r->post('/fida/items/quick', 'FidaController@itemQuick');
    $r->post('/fida/units/quick', 'FidaController@unitQuick');
    $r->get('/fida/items/create', 'FidaController@itemForm');
    $r->get('/fida/items/{id}/edit', 'FidaController@itemForm');
    $r->post('/fida/items', 'FidaController@itemStore');
    $r->get('/fida/reports', 'FidaController@reports');
    $r->any('/fida/settings', 'FidaController@settings');
    // حساب‌های بانکی پروفایل (چند حساب، یکی پیش‌فرض، برای چاپ و PDF)
    $r->post('/fida/bank-accounts', 'FidaController@bankAccountStore');
    $r->post('/fida/bank-accounts/{id}/default', 'FidaController@bankAccountDefault');
    $r->post('/fida/bank-accounts/{id}/delete', 'FidaController@bankAccountDelete');
    // پشتیبان‌گیری و بازیابی فیدا (هر کاربر مستقل)
    $r->get('/fida/backups', 'FidaBackupController@index');
    $r->post('/fida/backups', 'FidaBackupController@create');
    $r->post('/fida/backups/import', 'FidaBackupController@import');
    $r->get('/fida/backups/{id}/download', 'FidaBackupController@download');
    $r->post('/fida/backups/{id}/delete', 'FidaBackupController@delete');
    $r->get('/fida/templates', 'FidaController@templates');
    $r->post('/fida/templates', 'FidaController@templateStore');
    /* تقویم شخصی */
    $r->get('/fida/calendar', 'FidaController@calendar');
    $r->post('/fida/calendar', 'FidaController@eventStore');
    $r->post('/fida/calendar/{id}/delete', 'FidaController@eventDelete');
    $r->post('/fida/calendar/{id}/toggle', 'FidaController@eventToggle');
    $r->get('/fida/gold', 'FidaController@gold');
    $r->post('/fida/gold/subscribe', 'FidaController@goldSubscribe');
    $r->post('/fida/gold/bazaar/confirm', 'FidaController@bazaarConfirm');
    $r->post('/fida/discount/apply', 'FidaController@discountApply');
    $r->post('/fida/discount/remove', 'FidaController@discountRemove');
    $r->post('/fida/invite', 'FidaController@inviteStore');
    $r->post('/fida/invite/redeem', 'FidaController@inviteRedeem');
    $r->post('/app/ai/insight', 'AiInsightController@insight');
    $r->post('/app/ai/compose', 'AiInsightController@compose');
    $r->post('/app/ai/extract', 'AiExtractController@extract');

    /* فاکتورها */
    $r->get('/app/invoices/create', 'InvoiceController@create');
    $r->post('/app/invoices', 'InvoiceController@store');
    $r->get('/app/invoices/{id}/print', 'InvoiceController@printView');
    $r->post('/app/invoices/{id}/post', 'InvoiceController@post');
    $r->post('/app/invoices/{id}/cancel', 'InvoiceController@cancel');
    $r->get('/app/invoices/{id}/receipt/{rid}/download', 'InvoiceController@receiptDownload');
    $r->post('/app/invoices/{id}/receipt/{rid}/review', 'InvoiceController@receiptReview');
    $r->get('/app/invoices', 'InvoiceController@index');
    $r->get('/app/invoices/{id}', 'InvoiceController@show');

    /* دریافت / پرداخت / انتقال */
    $r->any('/app/receipts/create', 'TreasuryController@createReceipt');
    $r->post('/app/receipts', 'TreasuryController@storeReceipt');
    $r->get('/app/receipts/{id}/print', 'TreasuryController@printReceipt');
    $r->get('/app/receipts', 'TreasuryController@receipts');
    $r->get('/app/receipts/{id}', 'TreasuryController@showReceipt');
    $r->any('/app/payments/create', 'TreasuryController@createPayment');
    $r->post('/app/payments', 'TreasuryController@storePayment');
    $r->get('/app/payments/{id}/print', 'TreasuryController@printPayment');
    $r->get('/app/payments', 'TreasuryController@payments');
    $r->get('/app/payments/{id}', 'TreasuryController@showPayment');
    $r->any('/app/transfers/create', 'TreasuryController@createTransfer');
    $r->post('/app/transfers', 'TreasuryController@storeTransfer');

    /* چک‌ها */
    /* چک‌ها: فرم و ذخیره اختصاصی از طریق کنترلر عمومی CRUD (ماژول cheques) */
    $r->get('/app/cheques/create', function (array $p) { return (new ResourceController())->create(['module' => 'cheques'] + $p); });
    $r->post('/app/cheques', function (array $p) { return (new ResourceController())->store(['module' => 'cheques'] + $p); });
    $r->post('/app/cheques/{id}/event', 'TreasuryController@chequeEvent');
    $r->get('/app/cheques/{id}', 'TreasuryController@showCheque');

    /* انبار */
    $r->any('/app/inventory-documents/create', 'StockController@createDocument');
    $r->post('/app/inventory-documents', 'StockController@storeDocument');
    $r->post('/app/inventory-documents/{id}/post', 'StockController@postDocument');
    $r->any('/app/stock-transfers/create', 'StockController@createTransfer');
    $r->post('/app/stock-transfers', 'StockController@storeTransfer');
    $r->any('/app/stock-counts/create', 'StockController@createCount');
    $r->post('/app/stock-counts', 'StockController@storeCount');

    /* حقوق و دستمزد (کارگاه، مساعده، وام، گزارش جامع) */
    $r->get('/app/payroll', 'PayrollController@index');
    $r->get('/app/payroll/workshops', 'PayrollController@workshops');
    $r->get('/app/payroll/workshops/create', 'PayrollController@workshopForm');
    $r->post('/app/payroll/workshops', 'PayrollController@workshopStore');
    $r->post('/app/payroll/workshops/{id}/delete', 'PayrollController@workshopDelete');
    $r->post('/app/payroll/workshops/{id}/employee', 'PayrollController@workshopAddEmployee');
    $r->post('/app/payroll/workshops/{id}/edit', 'PayrollController@workshopStore');
    $r->get('/app/payroll/workshops/{id}/edit', 'PayrollController@workshopForm');
    $r->post('/app/payroll/workshop-member/{id}/delete', 'PayrollController@workshopRemoveEmployee');
    $r->get('/app/payroll/advances', 'PayrollController@advances');
    $r->get('/app/payroll/advances/create', 'PayrollController@advanceForm');
    $r->post('/app/payroll/advances', 'PayrollController@advanceStore');
    $r->post('/app/payroll/advances/{id}/cancel', 'PayrollController@advanceCancel');
    $r->get('/app/payroll/loans', 'PayrollController@loans');
    $r->get('/app/payroll/loans/create', 'PayrollController@loanForm');
    $r->post('/app/payroll/loans', 'PayrollController@loanStore');
    $r->post('/app/payroll/loans/{id}/cancel', 'PayrollController@loanCancel');
    $r->get('/app/payroll/report', 'PayrollController@report');
    /* قراردادهای کار */
    $r->get('/app/payroll/contracts', 'PayrollController@contracts');
    $r->get('/app/payroll/contracts/create', 'PayrollController@contractForm');
    $r->post('/app/payroll/contracts', 'PayrollController@contractStore');
    $r->post('/app/payroll/contracts/{id}/edit', 'PayrollController@contractStore');
    $r->get('/app/payroll/contracts/{id}/edit', 'PayrollController@contractForm');
    $r->post('/app/payroll/contracts/{id}/apply', 'PayrollController@contractApply');
    $r->post('/app/payroll/contracts/{id}/delete', 'PayrollController@contractDelete');
    $r->get('/app/payroll/contracts/{id}/print', 'PayrollController@contractPrint');
    $r->get('/app/payroll/contracts/{id}', 'PayrollController@contractShow');
    $r->get('/app/payroll/workshops/{id}', 'PayrollController@workshopShow');

    /* تنخواه گردان */
    $r->get('/app/petty-cash', 'PettyCashController@index');
    $r->get('/app/petty-cash/funds', 'PettyCashController@funds');
    $r->get('/app/petty-cash/funds/create', 'PettyCashController@fundForm');
    $r->get('/app/petty-cash/funds/{id}/edit', 'PettyCashController@fundForm');
    $r->post('/app/petty-cash/funds', 'PettyCashController@fundStore');
    $r->post('/app/petty-cash/funds/{id}/delete', 'PettyCashController@fundDelete');
    $r->get('/app/petty-cash/entries', 'PettyCashController@entries');
    $r->get('/app/petty-cash/reports', 'PettyCashController@reports');
    $r->get('/app/petty-cash/create', 'PettyCashController@create');
    $r->get('/app/petty-cash/attach/{id}', 'PettyCashController@attachment');
    $r->post('/app/petty-cash/{id}/approve', 'PettyCashController@approve');
    $r->post('/app/petty-cash/{id}/reject', 'PettyCashController@reject');
    $r->post('/app/petty-cash/{id}/delete', 'PettyCashController@deleteEntry');
    $r->get('/app/petty-cash/{id}/print', 'PettyCashController@printEntry');
    $r->post('/app/petty-cash', 'PettyCashController@store');
    $r->get('/app/petty-cash/{id}', 'PettyCashController@show');

    /* حسابداری */
    $r->any('/app/journal/create', 'AccountingController@createEntry');
    $r->post('/app/journal', 'AccountingController@storeEntry');
    $r->post('/app/journal/{id}/reverse', 'AccountingController@reverseEntry');
    $r->get('/app/journal/{id}/print', 'AccountingController@printEntry');
    $r->get('/app/payroll-documents/{id}/print', 'AccountingController@printPayroll');
    $r->get('/app/persons/{id}/payment-term', 'PeopleController@paymentTerm');

    /* ── CRM: پروندهٔ ۳۶۰ مشتری + فعالیت‌ها و اسناد ── */
    $r->get('/app/persons/create', function (array $p) { return (new ResourceController())->create(['module' => 'persons'] + $p); });
    $r->get('/app/persons/{id}/edit', function (array $p) { return (new ResourceController())->edit(['module' => 'persons'] + $p); });
    $r->get('/app/persons/{id}', 'PersonProfileController@show');
    $r->post('/app/persons/{id}/activity', 'PersonProfileController@activityStore');
    $r->post('/app/persons/{id}/activity/{aid}/done', 'PersonProfileController@activityDone');
    $r->post('/app/persons/{id}/activity/{aid}/delete', 'PersonProfileController@activityDelete');
    $r->post('/app/persons/{id}/docs', 'PersonProfileController@docStore');
    $r->get('/app/persons/{id}/docs/{aid}/download', 'PersonProfileController@docDownload');
    $r->post('/app/persons/{id}/docs/{aid}/delete', 'PersonProfileController@docDelete');
    $r->get('/app/journal', 'AccountingController@journal');
    $r->get('/app/journal/{id}', 'AccountingController@showEntry');
    $r->any('/app/opening-balances/setup', 'AccountingController@openingSetup');
    $r->post('/app/fiscal-years/{id}/close', 'AccountingController@closeYear');
    $r->post('/app/fiscal-years/{id}/activate', 'AccountingController@activateYear');
    $r->any('/app/payroll-documents/create', 'AccountingController@createPayroll');
    $r->post('/app/payroll-documents', 'AccountingController@storePayroll');
    $r->post('/app/payroll-documents/{id}/pay', 'AccountingController@payPayroll');

    /* درآمد و هزینه */
    $r->any('/app/expenses/create', 'IncexpController@createExpense');
    $r->post('/app/expenses', 'IncexpController@storeExpense');
    $r->any('/app/incomes/create', 'IncexpController@createIncome');
    $r->post('/app/incomes', 'IncexpController@storeIncome');

    /* گزارش‌ها */
    $r->get('/app/reports', 'ReportController@index');
    $r->get('/app/reports/{key}/export', 'ReportController@export');
    $r->get('/app/reports/{key}/print', 'ReportController@printView');
    $r->get('/app/reports/{key}', 'ReportController@show');
    // گزارش مدیریتی خودکار ماهانه
    $r->get('/app/management-reports', 'ManagementReportController@index');
    $r->post('/app/management-reports/generate', 'ManagementReportController@generate');
    $r->get('/app/management-reports/{id}', 'ManagementReportController@show');
    // تشخیص ناهنجاری
    $r->get('/app/anomalies', 'AnomalyController@index');
    // نرخ ارز
    $r->get('/app/settings/currency', 'CurrencyController@index');
    $r->post('/app/settings/currency', 'CurrencyController@store');

    /* تنظیمات اختصاصی */
    $r->any('/app/settings/business', 'SettingsController@business');
    $r->any('/app/settings/financial', 'SettingsController@financial');
    $r->any('/app/settings/hr', 'SettingsController@hr');
    /* پشتیبان‌گیری و بازگردانی (کسب‌وکارمحور) */
    $r->get('/app/backups', 'BackupController@index');
    $r->post('/app/backups', 'BackupController@create');
    $r->post('/app/backups/import', 'BackupController@import');
    $r->get('/app/backups/{id}/download', 'BackupController@download');
    $r->post('/app/backups/{id}/delete', 'BackupController@delete');

    $r->any('/app/settings/sms', 'SettingsController@sms');
    $r->post('/app/settings/sms/test', 'SettingsController@smsTest');
    $r->post('/app/settings/sms/send-test', 'SettingsController@smsSendTest');
    // درگاه و پرداخت (حساب‌های دریافت وجه برای پورتال مشتری)
    $r->any('/app/settings/payment', 'SettingsController@payment');
    $r->post('/app/settings/payment/store', 'SettingsController@paymentStore');
    $r->post('/app/settings/payment/{id}/delete', 'SettingsController@paymentDelete');
    $r->any('/app/settings/ai', 'SettingsController@ai');
    // به‌روزرسانی اطلاعات (واردسازی واقعی CSV)
    $r->get('/app/import-jobs/create', 'ImportController@createForm');
    $r->get('/app/import-jobs/template', 'ImportController@template');
    $r->get('/app/import-jobs/preview', 'ImportController@preview');
    $r->get('/app/import-jobs/{id}/result', 'ImportController@result');
    $r->post('/app/import-jobs', 'ImportController@store');
    $r->post('/app/roles/{id}/permissions', 'SettingsController@savePermissions');
    $r->post('/app/users/{id}/password', 'SettingsController@resetPassword');
    $r->post('/app/users/{id}/business-role', 'SettingsController@saveUserRole');

    /* پشتیبانی */
    $r->any('/app/tickets/create', 'SupportController@create');
    $r->post('/app/tickets/{id}/reply', 'SupportController@reply');
    $r->post('/app/tickets/{id}/status', 'SupportController@status');
    $r->get('/app/tickets/{id}', 'SupportController@show');

    /* خرید پکیج */
    $r->get('/app/plans', 'BillingController@plans');
    $r->post('/app/plans/{id}/subscribe', 'BillingController@subscribe');
    $r->get('/app/subscription', 'BillingController@subscription');
    $r->post('/app/subscription/pay', 'BillingController@pay');

    /* ── مسیرهای عمومی ماژول‌ها (متادیتا-محور) ── */
    $r->get('/app/{module}/create', 'ResourceController@create');
    $r->post('/app/{module}', 'ResourceController@store');
    $r->post('/app/{module}/{id}/delete', 'ResourceController@destroy');
    $r->post('/app/{module}/{id}', 'ResourceController@update');
    $r->post('/app/{module}/{id}/child/{child}', 'ResourceController@childStore');
    $r->post('/app/{module}/{id}/child/{child}/{cid}/delete', 'ResourceController@childDestroy');
    $r->get('/app/{module}/{id}/edit', 'ResourceController@edit');
    $r->get('/app/{module}/{id}', 'ResourceController@show');
    $r->get('/app/{module}', 'ResourceController@index');
};
