<?php
/**
 * تنظیمات نرم‌افزار حسابداری فینتو (نسخه PHP)
 * مقادیر را مطابق سرور خود تغییر دهید.
 */
return [
    'app' => [
        'name'        => 'فینتو | نرم‌افزار حسابداری و انبارداری',
        'short_name'  => 'فینتو',
        'version'     => '1.1.0',
        'url'         => '',            // مثال: https://accounting.example.com  (خالی = تشخیص خودکار)
        'timezone'    => 'Asia/Tehran',
        'locale'      => 'fa_IR',
        'debug'       => false,         // در حال توسعه true کنید (در سرور واقعی false بماند)
        'demo_mode'   => true,          // اگر true، کد تایید پیامک‌شده در صفحه نمایش داده می‌شود
        'sms_driver'  => 'kavenegar',   // log | kavenegar  (kavenegar: ارسال واقعی با وب‌سرویس کاوه‌نگار)
        'kavenegar'   => [
            'api_key'      => '39396B65697855656D4E354B3752666F463070615668677A4A633253445934515843753547502B724D646F3D',
            'sender'       => '',       // شمارهٔ خط ارسال (اختیاری؛ خالی = خط پیش‌فرض حساب)
            'otp_template' => 'sendmelodi', // نام الگوی اعتبارسنجی برای کد تایید (Lookup)
        ],
        'session_name'=> 'FINTOSESS',
        'upload_dir'  => '/uploads',
    ],
    'db' => [
        'host'     => '127.0.0.1',
        'port'     => 3306,
        'name'     => 'finto_accounting',
        'user'     => 'finto',
        'pass'     => 'finto123',
        'charset'  => 'utf8mb4',
        'socket'   => '',               // مثال: /var/run/mysqld/mysqld.sock
    ],
    'security' => [
        'otp_ttl_seconds'   => 300,     // اعتبار کد تایید (پنج دقیقه)
        'otp_max_attempts'  => 5,
        'otp_resend_seconds'=> 120,
        'session_ttl_days'  => 30,
        'password_min'      => 8,
        'hash_secret'       => 'change-me-finto-app-secret-2026', // برای هش کد تایید
    ],
    // ── درگاه پرداخت کافه‌بازار (پرداخت درون‌برنامه‌ای فیدا) ──
    // برای فعال‌سازی: پکیج‌نیم و کلید API «پیشخان بازار» را از پنل توسعه‌دهندگان بازار بگیرید
    //   پنل بازار → اپ‌ها → [اپ شما] → «API پیشخان بازار» → دریافت توکن جدید
    'bazaar' => [
        'enabled'    => false,              // پس از تکمیل مقادیر زیر true کنید
        'sandbox'    => false,              // فقط برای آزمون محلی (بدون تماس واقعی با بازار)
        'package'    => 'ir.fida.app',      // پکیج‌نیم ثبت‌شدهٔ اپ در کافه‌بازار
        'dealer'     => 'ir.fida.app',      // پکیج‌نیم فروشنده (معمولاً همان پکیج)
        'api_secret' => '',                 // کلید API پیشخان بازار (محرمانه — فقط در همین فایل/فایل محلی)
        'skus'       => [                   // نگاشت «مدت پلن (ماه)» → شناسهٔ محصول در پنل بازار
            3  => 'fida_gold_3m',
            6  => 'fida_gold_6m',
            12 => 'fida_gold_12m',
        ],
    ],

    // ── دستیار هوشمند (سازگار با OpenAI) — پیش‌فرض: AvalAI / DeepSeek V4.1 Flash ──
    'ai' => [
        'enabled'     => true,
        'base_url'    => 'https://api.avalai.ir/v1',            // در صورت نیاز قابل تغییر (هر سرویس سازگار با OpenAI)
        'api_key'     => 'aa-fLsSSoXP7UGk1m9gQaFv12IGfeqbElNS6GwXal4cF66nh3cZ', // با متغیر محیطی AVALAI_API_KEY یا config.local.php قابل بازنویسی است
        'model'       => 'deepseek-v4.1-flash',
        'timeout'     => 70,      // ثانیه
        'max_tokens'  => 2000,
        'temperature' => 0.2,
        'thinking'    => false,   // حالت تفکری مدل (برای سرعت/هزینه خاموش است)
    ],
];
