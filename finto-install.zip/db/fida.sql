-- ══════════════════════════════════════════════════════════════════
--  اپ فاکتورزنی فیدا (Fida) — جدول‌های اختصاصی
--  این ماژول کاملاً خودکفاست و فقط از احراز هویت/کاربران فینتو استفاده می‌کند.
--  هیچ جدولی با جدول‌های فینتو تداخل ندارد (همه با پیشوند fida_ / v_fida_).
--  هر کاربر پروفایل و دادهٔ اختصاصی خودش را دارد (ستون user_id).
--  اجرا: پس از نصب فینتو، این فایل را روی همان دیتابیس ایمپورت کنید.
-- ══════════════════════════════════════════════════════════════════
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `fida_persons` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک (پروفایل اختصاصی)',
  full_name VARCHAR(120) NOT NULL COMMENT 'نام کامل',
  phone VARCHAR(20) NOT NULL COMMENT 'شماره تماس',
  person_type ENUM('customer','supplier','partner') NOT NULL COMMENT 'نوع شخص: مشتری/تأمین‌کننده/همکار',
  person_kind ENUM('individual','company') NOT NULL COMMENT 'حقیقی/حقوقی',
  city VARCHAR(80) NULL COMMENT 'شهر',
  role VARCHAR(60) NULL COMMENT 'حوزه فعالیت',
  address VARCHAR(255) NULL COMMENT 'آدرس',
  note VARCHAR(255) NULL COMMENT 'یادداشت داخلی',
  status ENUM('active','inactive') NOT NULL DEFAULT 'active' COMMENT 'وضعیت',
  registered_at DATE NOT NULL COMMENT 'تاریخ ثبت در برنامه (میلادی)',
  registered_jalali VARCHAR(20) NOT NULL COMMENT 'تاریخ ثبت (شمسی)',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_persons_phone (user_id, phone),
  INDEX idx_persons_user (user_id),
  INDEX idx_persons_type (person_type),
  INDEX idx_persons_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اشخاص اپ فاکتور زنی';
CREATE TABLE IF NOT EXISTS `fida_items` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک (پروفایل اختصاصی)',
  kind ENUM('service','supply') NOT NULL COMMENT 'خدمت فروش/ملزومه خرید',
  title VARCHAR(160) NOT NULL COMMENT 'عنوان قلم',
  unit VARCHAR(30) NOT NULL COMMENT 'واحد شمارش',
  unit_price BIGINT NOT NULL COMMENT 'قیمت واحد (تومان)',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_items_user (user_id),
  INDEX idx_items_kind (kind)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اقلام ذخیره‌شده (ذخیره‌سازی هوشمند: مشتری/آیتم/قیمت)';
CREATE TABLE IF NOT EXISTS `fida_invoices` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک (پروفایل اختصاصی)',
  invoice_type ENUM('sale','pre_invoice','purchase') NOT NULL COMMENT 'نوع فاکتور',
  invoice_code VARCHAR(20) NOT NULL COMMENT 'کد نمایشی (INV-/PRE-/BUY-)',
  seq SMALLINT UNSIGNED NOT NULL COMMENT 'شماره سریال در سال شمسی (بر اساس نوع)',
  invoice_year SMALLINT UNSIGNED NOT NULL COMMENT 'سال شمسی',
  invoice_month TINYINT UNSIGNED NOT NULL COMMENT 'ماه شمسی (۱..۱۲)',
  invoice_date DATE NOT NULL COMMENT 'تاریخ صدور (میلادی)',
  invoice_jalali VARCHAR(20) NOT NULL COMMENT 'تاریخ صدور (شمسی)',
  person_id INT UNSIGNED NOT NULL COMMENT 'شخص',
  status ENUM('paid','credit','pending','converted','closed') NOT NULL COMMENT 'وضعیت',
  pay_method ENUM('cash','card','credit','transfer') NULL COMMENT 'نوع پرداخت لحظه صدور',
  due_date DATE NULL COMMENT 'سررسید (اعتباری)',
  due_jalali VARCHAR(20) NULL COMMENT 'سررسید (شمسی)',
  previous_debt_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'بدهی قبلی شخص',
  advance_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'بیعانه دریافتی',
  total_amount BIGINT NOT NULL COMMENT 'جمع اقلام',
  discount_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'تخفیف',
  ship_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'هزینه ارسال',
  tax_mode ENUM('percent','amount') NULL COMMENT 'نوع مالیات: درصدی/مبلغی',
  tax_percent DECIMAL(5,2) NOT NULL DEFAULT 0 COMMENT 'درصد مالیات (در حالت درصدی)',
  tax_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ مالیات',
  final_amount BIGINT NOT NULL COMMENT 'مبلغ قابل پرداخت',
  paid_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ پرداخت‌شده تاکنون',
  notes VARCHAR(255) NULL COMMENT 'توضیحات',
  converted_to_id INT UNSIGNED NULL COMMENT 'پیش‌فاکتور: فاکتور مقصد تبدیل',
  created_at DATETIME NOT NULL COMMENT 'لحظه صدور',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invoices_code (user_id, invoice_type, invoice_year, seq),
  INDEX idx_invoices_user (user_id),
  INDEX idx_invoices_code (invoice_code),
  INDEX idx_invoices_person (person_id),
  INDEX idx_invoices_date (invoice_date),
  INDEX idx_invoices_status (status),
  CONSTRAINT fk_invoices_person FOREIGN KEY (person_id) REFERENCES fida_persons (id) ON DELETE RESTRICT,
  CONSTRAINT fk_invoices_conv FOREIGN KEY (converted_to_id) REFERENCES fida_invoices (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='فاکتورهای اپ (فروش/پیش‌فاکتور/خرید)';
CREATE TABLE IF NOT EXISTS `fida_invoice_items` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  invoice_id INT UNSIGNED NOT NULL COMMENT 'فاکتور',
  item_id INT UNSIGNED NULL COMMENT 'قلم ذخیره‌شده (NULL = سطر آزاد)',
  item_title VARCHAR(160) NOT NULL COMMENT 'عنوان سطر (لحظه ثبت)',
  unit VARCHAR(30) NOT NULL COMMENT 'واحد',
  quantity DECIMAL(10,2) NOT NULL DEFAULT 1 COMMENT 'تعداد',
  unit_price BIGINT NOT NULL COMMENT 'قیمت واحد (تومان)',
  total_price BIGINT NOT NULL COMMENT 'جمع سطر (تومان)',
  position SMALLINT UNSIGNED NOT NULL COMMENT 'ترتیب سطر',
  PRIMARY KEY (id),
  INDEX idx_initems_user (user_id),
  INDEX idx_initems_invoice (invoice_id),
  INDEX idx_initems_item (item_id),
  CONSTRAINT fk_initems_invoice FOREIGN KEY (invoice_id) REFERENCES fida_invoices (id) ON DELETE CASCADE,
  CONSTRAINT fk_initems_item FOREIGN KEY (item_id) REFERENCES fida_items (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سطرهای فاکتور';
CREATE TABLE IF NOT EXISTS `fida_payments` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  invoice_id INT UNSIGNED NOT NULL COMMENT 'فاکتور',
  person_id INT UNSIGNED NOT NULL COMMENT 'شخص',
  amount BIGINT NOT NULL COMMENT 'مبلغ (تومان)',
  pay_method ENUM('cash','card','transfer','check') NOT NULL COMMENT 'روش پرداخت',
  reference_code VARCHAR(30) NOT NULL COMMENT 'شناسه تراکنش',
  paid_at DATE NOT NULL COMMENT 'تاریخ پرداخت (میلادی)',
  paid_jalali VARCHAR(20) NOT NULL COMMENT 'تاریخ پرداخت (شمسی)',
  note VARCHAR(255) NULL COMMENT 'یادداشت',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_payments_ref (user_id, reference_code),
  INDEX idx_payments_user (user_id),
  INDEX idx_payments_invoice (invoice_id),
  INDEX idx_payments_person (person_id),
  INDEX idx_payments_date (paid_at),
  CONSTRAINT fk_payments_invoice FOREIGN KEY (invoice_id) REFERENCES fida_invoices (id) ON DELETE CASCADE,
  CONSTRAINT fk_payments_person FOREIGN KEY (person_id) REFERENCES fida_persons (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پرداخت‌های فاکتورها';
CREATE TABLE IF NOT EXISTS `fida_invoice_status_history` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  invoice_id INT UNSIGNED NOT NULL COMMENT 'فاکتور',
  old_status VARCHAR(20) NULL COMMENT 'وضعیت قبل',
  new_status VARCHAR(20) NOT NULL COMMENT 'وضعیت بعد',
  changed_at DATETIME NOT NULL COMMENT 'لحظه تغییر',
  note VARCHAR(255) NULL COMMENT 'یادداشت',
  PRIMARY KEY (id),
  INDEX idx_hist_user (user_id),
  INDEX idx_hist_invoice (invoice_id),
  CONSTRAINT fk_hist_invoice FOREIGN KEY (invoice_id) REFERENCES fida_invoices (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تاریخچه وضعیت فاکتورها';
CREATE TABLE IF NOT EXISTS `fida_invoice_templates` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  name VARCHAR(120) NOT NULL COMMENT 'نام نمونه',
  description VARCHAR(255) NULL COMMENT 'توضیح',
  icon VARCHAR(8) NULL COMMENT 'آیکون',
  usage_count INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد استفاده',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_tpl_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='نمونه فاکتورهای ذخیره‌شده';
CREATE TABLE IF NOT EXISTS `fida_template_items` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  template_id INT UNSIGNED NOT NULL COMMENT 'نمونه',
  item_title VARCHAR(160) NOT NULL COMMENT 'عنوان سطر',
  unit VARCHAR(30) NOT NULL COMMENT 'واحد',
  quantity DECIMAL(10,2) NOT NULL DEFAULT 1 COMMENT 'تعداد',
  unit_price BIGINT NOT NULL COMMENT 'قیمت واحد (تومان)',
  total_price BIGINT NOT NULL COMMENT 'جمع سطر (تومان)',
  position SMALLINT UNSIGNED NOT NULL COMMENT 'ترتیب سطر',
  PRIMARY KEY (id),
  INDEX idx_tplitems_user (user_id),
  INDEX idx_tplitems_tpl (template_id),
  CONSTRAINT fk_tplitems_tpl FOREIGN KEY (template_id) REFERENCES fida_invoice_templates (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='سطرهای نمونه فاکتورها';
CREATE TABLE IF NOT EXISTS `fida_settings` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک (پروفایل اختصاصی)',
  owner_name VARCHAR(80) NOT NULL COMMENT 'نام مالک',
  shop_name VARCHAR(120) NOT NULL COMMENT 'نام کسب‌وکار',
  shop_address VARCHAR(255) NULL COMMENT 'آدرس کسب‌وکار',
  shop_phone VARCHAR(20) NULL COMMENT 'تلفن کسب‌وکار',
  header_title VARCHAR(160) NULL COMMENT 'عنوان سربرگ',
  header_description VARCHAR(255) NULL COMMENT 'توضیح سربرگ',
  accent_color ENUM('purple','blue','green','red') NOT NULL DEFAULT 'purple' COMMENT 'رنگ سازمانی',
  logo_path VARCHAR(255) NULL COMMENT 'لوگو',
  signature_path VARCHAR(255) NULL COMMENT 'امضا',
  stamp_path VARCHAR(255) NULL COMMENT 'مهر',
  show_ship TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش ارسال',
  show_tax TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش ردیف مالیات',
  tax_percent DECIMAL(5,2) NOT NULL DEFAULT 9 COMMENT 'درصد مالیات پیش‌فرض',
  show_discount TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش تخفیف',
  show_advance TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش بیعانه',
  show_previous_debt TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'نمایش بدهی قبلی',
  show_types TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش نوع فاکتور و پرداخت',
  show_bank_info TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'نمایش اطلاعات حساب بانکی در چاپ و PDF',
  currency ENUM('toman','rial') NOT NULL DEFAULT 'toman' COMMENT 'واحد پول',
  discount_mode ENUM('percent','amount') NOT NULL DEFAULT 'percent' COMMENT 'حالت تخفیف',
  printer_model VARCHAR(80) NULL COMMENT 'پرینتر',
  printer_status ENUM('connected','disconnected','none') NOT NULL DEFAULT 'none' COMMENT 'وضعیت پرینتر',
  app_version VARCHAR(20) NULL COMMENT 'نسخه اپ',
  app_channel VARCHAR(20) NULL COMMENT 'کانال نصب',
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_settings_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تنظیمات اپ فاکتور زنی (برای هر کاربر یک ردیف)';
CREATE TABLE IF NOT EXISTS `fida_bank_accounts` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  bank_name VARCHAR(80) NOT NULL COMMENT 'نام بانک',
  account_holder VARCHAR(120) NOT NULL COMMENT 'نام صاحب حساب',
  card_no VARCHAR(32) NULL COMMENT 'شماره کارت',
  iban VARCHAR(40) NULL COMMENT 'شماره شبا',
  account_no VARCHAR(40) NULL COMMENT 'شماره حساب',
  is_default TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'حساب پیش‌فرض برای چاپ و PDF',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  sort_order SMALLINT NOT NULL DEFAULT 0 COMMENT 'ترتیب نمایش',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_fida_bank_user (user_id),
  KEY ix_fida_bank_default (user_id, is_default)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='حساب‌های بانکی پروفایل (برای چاپ فاکتور و PDF)';

CREATE TABLE IF NOT EXISTS `fida_gold_plans` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  plan_code VARCHAR(20) NOT NULL COMMENT 'کد پلن',
  title VARCHAR(80) NOT NULL COMMENT 'عنوان',
  duration_months SMALLINT UNSIGNED NOT NULL COMMENT 'مدت (ماه)',
  price BIGINT NOT NULL COMMENT 'قیمت (تومان)',
  old_price BIGINT NULL COMMENT 'قیمت قبل (تومان)',
  badge ENUM('best_seller','recommended','value') NULL COMMENT 'نشان',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  PRIMARY KEY (id),
  UNIQUE KEY uq_plans_code (plan_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='بسته‌های اشتراک طلایی (فهرست مشترک همه کاربران)';
CREATE TABLE IF NOT EXISTS `fida_subscriptions` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  plan_id INT UNSIGNED NOT NULL COMMENT 'پلن',
  activated_at DATE NOT NULL COMMENT 'تاریخ شروع',
  expires_at DATE NOT NULL COMMENT 'تاریخ پایان',
  status ENUM('active','expired') NOT NULL COMMENT 'وضعیت',
  source ENUM('purchase','invite','gift') NOT NULL DEFAULT 'purchase' COMMENT 'منبع',
  discount_code VARCHAR(40) NULL COMMENT 'کد تخفیف استفاده‌شده',
  discount_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ تخفیف (تومان)',
  paid_amount BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ پرداختی پس از تخفیف (تومان)',
  PRIMARY KEY (id),
  INDEX idx_subs_user (user_id),
  INDEX idx_subs_status (status),
  CONSTRAINT fk_subs_plan FOREIGN KEY (plan_id) REFERENCES fida_gold_plans (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='اشتراک‌های طلایی (بدون رکورد = نسخه رایگان)';
CREATE TABLE IF NOT EXISTS `fida_discount_codes` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(40) NOT NULL COMMENT 'کد تخفیف',
  title VARCHAR(120) NULL COMMENT 'عنوان/توضیح',
  discount_mode ENUM('percent','amount') NOT NULL DEFAULT 'percent' COMMENT 'نوع تخفیف',
  discount_value BIGINT NOT NULL DEFAULT 0 COMMENT 'مقدار تخفیف (درصد یا تومان)',
  max_uses SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'حداکثر استفاده (۰ = نامحدود)',
  used_count SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد استفاده',
  expires_at DATE NULL COMMENT 'تاریخ انقضا',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_discount_code (code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کدهای تخفیف اشتراک طلایی فیدا';

CREATE TABLE IF NOT EXISTS `fida_invite_codes` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک کد',
  code VARCHAR(20) NOT NULL COMMENT 'کد دعوت',
  owner_label VARCHAR(80) NOT NULL COMMENT 'مالک کد',
  friend_discount_percent SMALLINT UNSIGNED NOT NULL COMMENT 'تخفیف دوست (٪)',
  reward VARCHAR(80) NOT NULL COMMENT 'پاداش دعوت‌کننده',
  used_count INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد استفاده',
  is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'فعال',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_invite_code (code),
  INDEX idx_invite_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='کدهای دعوت (دوست ۱۵٪ + اشتراک رایگان برای تو)';
CREATE TABLE IF NOT EXISTS `fida_monthly_metrics` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  year SMALLINT UNSIGNED NOT NULL COMMENT 'سال شمسی',
  month TINYINT UNSIGNED NOT NULL COMMENT 'ماه شمسی',
  month_label VARCHAR(20) NOT NULL COMMENT 'برچسب ماه',
  doc_count SMALLINT UNSIGNED NOT NULL COMMENT 'تعداد اسناد (فروش + پیش‌فاکتور)',
  realized_amount BIGINT NOT NULL COMMENT 'مجموع تحقق‌یافته (تومان)',
  avg_amount BIGINT NOT NULL COMMENT 'میانگین هر سند (تومان)',
  computed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_metrics_ym (user_id, year, month)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خلاصه فروش ماهانه (معادل v_fida_sales_monthly)';

-- ───────────── پشتیبان‌گیری فیدا (هر کاربر، مستقل) ─────────────
CREATE TABLE IF NOT EXISTS `fida_backups` (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL COMMENT 'کاربر مالک پشتیبان',
  job_type ENUM('manual','auto') NOT NULL DEFAULT 'manual' COMMENT 'دستی/خودکار',
  scope VARCHAR(20) NOT NULL DEFAULT 'full' COMMENT 'دامنهٔ پشتیبان',
  file_name VARCHAR(190) NULL COMMENT 'نام فایل JSON',
  size_mb DECIMAL(10,2) NOT NULL DEFAULT 0 COMMENT 'حجم (مگابایت)',
  row_count INT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'تعداد ردیف‌ها',
  status ENUM('running','success','failed') NOT NULL DEFAULT 'running' COMMENT 'وضعیت',
  error_message VARCHAR(255) NULL COMMENT 'پیام خطا',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by BIGINT UNSIGNED NULL,
  PRIMARY KEY (id),
  INDEX idx_fida_backups_user (user_id, id),
  CONSTRAINT fk_fida_backups_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='پشتیبان‌های فیدا (هر کاربر مستقل)';

CREATE OR REPLACE VIEW v_fida_invoices_full AS
SELECT i.id, i.user_id, i.invoice_code, i.invoice_type, i.status, i.pay_method,
       i.invoice_date, i.invoice_jalali, i.person_id, p.full_name AS person_name, p.city,
       i.total_amount, i.discount_amount, i.ship_amount, i.tax_amount, i.tax_percent, i.tax_mode,
       i.previous_debt_amount, i.advance_amount,
       i.final_amount, i.paid_amount,
       (i.final_amount - i.paid_amount) AS balance_amount,
       i.due_date, i.due_jalali, i.notes, i.converted_to_id, i.created_at
FROM fida_invoices i
JOIN fida_persons p ON p.id = i.person_id;
CREATE OR REPLACE VIEW v_fida_person_summary AS
SELECT p.id, p.user_id, p.full_name, p.person_type, p.person_kind, p.city, p.registered_at, p.registered_jalali,
       COALESCE(s.doc_count,0) AS doc_count,
       COALESCE(s.total_amount,0) AS total_amount,
       COALESCE(s.credit_balance,0) AS credit_balance,
       s.last_doc_date,
       (p.registered_at >= (SELECT MAX(invoice_date) FROM fida_invoices WHERE user_id = p.user_id) - INTERVAL 30 DAY) AS is_new
FROM fida_persons p
LEFT JOIN (
  SELECT i.user_id, i.person_id,
         COUNT(*) AS doc_count,
         SUM(i.final_amount) AS total_amount,
         SUM(CASE WHEN i.status='credit' THEN i.final_amount - i.paid_amount ELSE 0 END) AS credit_balance,
         MAX(i.invoice_date) AS last_doc_date
  FROM fida_invoices i
  WHERE i.invoice_type='sale' OR (i.invoice_type='pre_invoice' AND i.status='pending')
  GROUP BY i.user_id, i.person_id
) s ON s.person_id = p.id AND s.user_id = p.user_id;
CREATE OR REPLACE VIEW v_fida_sales_daily AS
SELECT i.user_id, i.invoice_date, i.invoice_jalali,
       COUNT(*) AS doc_count,
       SUM(i.final_amount) AS realized_amount
FROM fida_invoices i
WHERE i.invoice_type='sale' OR (i.invoice_type='pre_invoice' AND i.status IN ('pending','converted'))
GROUP BY i.user_id, i.invoice_date, i.invoice_jalali
ORDER BY i.invoice_date;
CREATE OR REPLACE VIEW v_fida_sales_monthly AS
SELECT i.user_id, i.invoice_year AS year, i.invoice_month AS month,
       COUNT(*) AS doc_count,
       SUM(i.final_amount) AS realized_amount,
       ROUND(AVG(i.final_amount)) AS avg_amount
FROM fida_invoices i
WHERE i.invoice_type='sale' OR (i.invoice_type='pre_invoice' AND i.status IN ('pending','converted'))
GROUP BY i.user_id, i.invoice_year, i.invoice_month
ORDER BY i.invoice_year, i.invoice_month;
CREATE OR REPLACE VIEW v_fida_payment_breakdown AS
-- «این ماه» = ماه شمسیِ آخرین سند همان کاربر
SELECT i.user_id, i.status AS bucket,
       COUNT(*) AS doc_count,
       SUM(i.final_amount) AS amount,
       ROUND(100 * SUM(i.final_amount) /
         (SELECT SUM(x.final_amount) FROM fida_invoices x
          WHERE x.user_id = i.user_id
            AND (x.invoice_type='sale' OR (x.invoice_type='pre_invoice' AND x.status='pending'))
            AND x.invoice_year  = (SELECT y.invoice_year  FROM fida_invoices y WHERE y.user_id = i.user_id ORDER BY y.invoice_date DESC LIMIT 1)
            AND x.invoice_month = (SELECT z.invoice_month FROM fida_invoices z WHERE z.user_id = i.user_id ORDER BY z.invoice_date DESC LIMIT 1)
         )) AS percent
FROM fida_invoices i
WHERE (i.invoice_type='sale' OR (i.invoice_type='pre_invoice' AND i.status='pending'))
  AND i.invoice_year  = (SELECT y.invoice_year  FROM fida_invoices y WHERE y.user_id = i.user_id ORDER BY y.invoice_date DESC LIMIT 1)
  AND i.invoice_month = (SELECT z.invoice_month FROM fida_invoices z WHERE z.user_id = i.user_id ORDER BY z.invoice_date DESC LIMIT 1)
GROUP BY i.user_id, i.status;
CREATE OR REPLACE VIEW v_fida_top_items AS
SELECT i.user_id, it.item_title, it.unit,
       SUM(it.quantity) AS total_qty,
       SUM(it.total_price) AS total_amount,
       COUNT(DISTINCT it.invoice_id) AS invoice_count
FROM fida_invoice_items it
JOIN fida_invoices i ON i.id = it.invoice_id
WHERE i.invoice_type='sale' AND it.item_id IS NOT NULL
GROUP BY i.user_id, it.item_title, it.unit
ORDER BY total_amount DESC;
CREATE OR REPLACE VIEW v_fida_top_persons AS
SELECT p.id, p.user_id, p.full_name, p.person_type, p.city,
       COUNT(*) AS doc_count,
       SUM(i.final_amount) AS total_amount
FROM fida_invoices i
JOIN fida_persons p ON p.id = i.person_id
WHERE i.invoice_type='sale' OR (i.invoice_type='pre_invoice' AND i.status='pending')
GROUP BY p.id, p.user_id, p.full_name, p.person_type, p.city
ORDER BY total_amount DESC;
CREATE OR REPLACE VIEW v_fida_invoice_timeline AS
SELECT h.id, i.user_id, i.invoice_code, i.invoice_date, h.old_status, h.new_status, h.changed_at, h.note
FROM fida_invoice_status_history h
JOIN fida_invoices i ON i.id = h.invoice_id
ORDER BY h.changed_at, h.id;

-- پلن‌های اشتراک طلایی: ۳ ماهه ۲۹۰٬۰۰۰ · ۶ ماهه ۴۹۰٬۰۰۰ · یک‌ساله ۶۹۰٬۰۰۰ تومان (پلن یک‌ماهه حذف شد)
INSERT INTO `fida_gold_plans` (`plan_code`,`title`,`duration_months`,`price`,`old_price`,`badge`,`is_active`)
SELECT * FROM (SELECT 'silver' AS a,'نقره‌ای (یک‌ماهه)' AS b,1 AS c,190000 AS d,0 AS e,NULL AS f,0 AS g) t
WHERE NOT EXISTS (SELECT 1 FROM `fida_gold_plans`);
UPDATE `fida_gold_plans` SET `is_active`=0 WHERE `plan_code`='silver' OR `duration_months`=1;
INSERT INTO `fida_gold_plans` (`plan_code`,`title`,`duration_months`,`price`,`old_price`,`badge`,`is_active`)
SELECT * FROM (SELECT 'annual' AS a,'یک‌ساله' AS b,12 AS c,690000 AS d,1200000 AS e,'value' AS f,1 AS g) t
WHERE NOT EXISTS (SELECT 1 FROM `fida_gold_plans` WHERE `plan_code`='annual');
UPDATE `fida_gold_plans` SET `title`='۳ ماهه',`duration_months`=3,`price`=290000,`old_price`=490000,`badge`='best_seller',`is_active`=1 WHERE `plan_code`='gold';
UPDATE `fida_gold_plans` SET `title`='۶ ماهه',`duration_months`=6,`price`=490000,`old_price`=690000,`badge`='recommended',`is_active`=1 WHERE `plan_code`='diamond';
UPDATE `fida_gold_plans` SET `title`='یک‌ساله',`duration_months`=12,`price`=690000,`old_price`=1200000,`badge`='value',`is_active`=1 WHERE `plan_code`='annual' OR `duration_months`=12;

-- کدهای تخفیف اشتراک (کد آزمایشی: FIDA20 = ۲۰٪ تخفیف)
INSERT INTO `fida_discount_codes` (`code`,`title`,`discount_mode`,`discount_value`,`max_uses`,`is_active`)
SELECT * FROM (SELECT 'FIDA20' AS a,'کد تخفیف آزمایشی ۲۰٪' AS b,'percent' AS c,20 AS d,0 AS e,1 AS f) t
WHERE NOT EXISTS (SELECT 1 FROM `fida_discount_codes`);
INSERT INTO `fida_discount_codes` (`code`,`title`,`discount_mode`,`discount_value`,`max_uses`,`is_active`)
SELECT * FROM (SELECT 'FIDA100' AS a,'۱۰۰٬۰۰۰ تومان تخفیف نقدی' AS b,'amount' AS c,100000 AS d,100 AS e,1 AS f) t
WHERE NOT EXISTS (SELECT 1 FROM `fida_discount_codes` WHERE `code`='FIDA100');
INSERT INTO `fida_gold_plans` (`plan_code`,`title`,`duration_months`,`price`,`old_price`,`badge`,`is_active`)
SELECT 'gold','طلایی',3,490000,690000,'best_seller',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `fida_gold_plans` WHERE plan_code='gold');
INSERT INTO `fida_gold_plans` (`plan_code`,`title`,`duration_months`,`price`,`old_price`,`badge`,`is_active`)
SELECT 'diamond','الماس',6,890000,1200000,'recommended',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `fida_gold_plans` WHERE plan_code='diamond');

-- ─────────────────────────────────────────────────────────────
--  چک‌های دریافتی/پرداختی
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `fida_cheques` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک (پروفایل اختصاصی)',
  direction ENUM('received','issued') NOT NULL COMMENT 'دریافتی / پرداختی',
  cheque_no VARCHAR(30) NOT NULL COMMENT 'شماره چک',
  bank_name VARCHAR(80) NULL COMMENT 'بانک',
  branch_name VARCHAR(80) NULL COMMENT 'شعبه',
  account_no VARCHAR(40) NULL COMMENT 'شماره حساب',
  sayad_id VARCHAR(30) NULL COMMENT 'شناسه صیادی',
  amount BIGINT NOT NULL COMMENT 'مبلغ (تومان)',
  person_id INT UNSIGNED NULL COMMENT 'طرف حساب (از اشخاص)',
  person_name VARCHAR(120) NULL COMMENT 'نام آزاد طرف حساب',
  issue_date DATE NULL COMMENT 'تاریخ صدور (میلادی)',
  issue_jalali VARCHAR(20) NULL COMMENT 'تاریخ صدور (شمسی)',
  due_date DATE NOT NULL COMMENT 'سررسید (میلادی)',
  due_jalali VARCHAR(20) NOT NULL COMMENT 'سررسید (شمسی)',
  status ENUM('in_hand','deposited','cleared','returned','cancelled') NOT NULL DEFAULT 'in_hand' COMMENT 'وضعیت چرخهٔ چک',
  invoice_id INT UNSIGNED NULL COMMENT 'فاکتور مرتبط',
  note VARCHAR(255) NULL COMMENT 'توضیحات',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_cheques_user (user_id),
  INDEX idx_cheques_due (due_date),
  INDEX idx_cheques_status (status),
  INDEX idx_cheques_person (person_id),
  CONSTRAINT fk_cheques_person FOREIGN KEY (person_id) REFERENCES fida_persons (id) ON DELETE SET NULL,
  CONSTRAINT fk_cheques_invoice FOREIGN KEY (invoice_id) REFERENCES fida_invoices (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='چک‌های دریافتی و پرداختی اپ فاکتور زنی';

-- ─────────────────────────────────────────────────────────────
--  اعلان‌های خوانده‌شده (برای سیستم اعلان داخلی)
-- ─────────────────────────────────────────────────────────────
-- ════════════════════════════════════════════════════════════════════
--  تقویم شخصی فیدا: رویدادهای هر کاربر (کاملاً شخصی و مستقل)
-- ════════════════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS `fida_events` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک رویداد',
  title VARCHAR(150) NOT NULL COMMENT 'عنوان رویداد',
  event_date DATE NOT NULL COMMENT 'تاریخ رویداد (میلادی)',
  event_time TIME NULL COMMENT 'ساعت (اختیاری)',
  kind ENUM('reminder','meeting','call','payment','delivery','task','other') NOT NULL DEFAULT 'reminder' COMMENT 'نوع رویداد',
  priority ENUM('normal','high') NOT NULL DEFAULT 'normal' COMMENT 'اهمیت',
  note VARCHAR(500) NULL COMMENT 'یادداشت',
  notify_days SMALLINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'چند روز قبل هم در اعلان‌ها بیاید',
  is_done TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'انجام‌شده',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_fida_events_user (user_id, event_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='تقویم و رویدادهای شخصی کاربران فیدا';

CREATE TABLE IF NOT EXISTS `fida_notice_reads` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر',
  notice_key VARCHAR(80) NOT NULL COMMENT 'کلید یکتای اعلان',
  read_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  dismissed_at DATETIME NULL COMMENT 'زمان حذف/بستن اعلان توسط همین کاربر',
  PRIMARY KEY (id),
  UNIQUE KEY uq_notice_user (user_id, notice_key),
  KEY idx_notice_dismissed (user_id, notice_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='وضعیت اعلان‌های هر کاربر (خوانده‌شده/حذف‌شده)';

CREATE OR REPLACE VIEW v_fida_cheques_full AS
SELECT c.*, p.full_name AS person_full_name, p.phone AS person_phone,
       COALESCE(NULLIF(p.full_name,''), c.person_name, '---') AS party_name,
       DATEDIFF(c.due_date, CURDATE()) AS days_to_due,
       i.invoice_code
FROM fida_cheques c
LEFT JOIN fida_persons p ON p.id = c.person_id
LEFT JOIN fida_invoices i ON i.id = c.invoice_id;

-- ─────────────────────────────────────────────────────────────
--  واحدهای شمارش (اختصاصی هر کاربر)
-- ─────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `fida_units` (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL COMMENT 'کاربر مالک',
  title VARCHAR(30) NOT NULL COMMENT 'عنوان واحد (عدد، بسته، کیلوگرم …)',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_units_user_title (user_id, title),
  INDEX idx_units_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='واحدهای شمارش اقلام';


-- ── خریدهای اشتراک فیدا از درگاه کافه‌بازار (پیشخان) ──
CREATE TABLE IF NOT EXISTS `fida_gold_purchases` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL COMMENT 'کاربر خریدار',
  `plan_id` INT UNSIGNED NOT NULL COMMENT 'پلن اشتراک',
  `gateway` VARCHAR(20) NOT NULL DEFAULT 'bazaar' COMMENT 'درگاه پرداخت',
  `sku` VARCHAR(80) NOT NULL COMMENT 'شناسهٔ محصول در بازار',
  `purchase_token` VARCHAR(190) NOT NULL COMMENT 'توکن خرید بازار',
  `amount` BIGINT NOT NULL DEFAULT 0 COMMENT 'مبلغ پرداختی (تومان)',
  `day_count` SMALLINT UNSIGNED NOT NULL DEFAULT 90 COMMENT 'طول اشتراک (روز)',
  `status` ENUM('pending','verified','failed','refunded') NOT NULL DEFAULT 'pending',
  `subscription_id` BIGINT UNSIGNED NULL COMMENT 'اشتراک فعال‌شده',
  `response_json` TEXT NULL COMMENT 'پاسخ خام بازار',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `verified_at` DATETIME NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_gold_token` (`purchase_token`),
  KEY `idx_gold_user` (`user_id`),
  KEY `idx_gold_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='خریدهای اشتراک فیدا از کافه‌بازار';
