<?php
/**
 * ═══════════════════════════════════════════════════════════════════════════
 *  نصب‌کننده وبی نرم‌افزار حسابداری و انبارداری فینتو
 *  مناسب میزبانی اشتراکی (cPanel / DirectAdmin) و سرور اختصاصی
 *  ---------------------------------------------------------------------------
 *  روش استفاده:  فایل‌های پروژه را آپلود کنید و آدرس زیر را در مرورگر باز کنید:
 *      https://your-domain.com/install.php        (پروژه در public_html)
 *      https://your-domain.com/finto/install.php  (پروژه در زیرپوشه)
 *  پس از پایان نصب، این فایل را حذف کنید.
 * ═══════════════════════════════════════════════════════════════════════════
 */
declare(strict_types=1);

@ini_set('display_errors', '1');
error_reporting(E_ALL);
@set_time_limit(300);
@ini_set('memory_limit', '256M');

const APP_ROOT   = __DIR__;
const CONFIG_FILE= __DIR__.'/config.local.php';
const LOCK_FILE  = __DIR__.'/storage/installed.lock';
const SQL_FULL   = __DIR__.'/db/finto.sql';
const SQL_EMPTY  = __DIR__.'/db/finto-empty.sql';
const MIN_PHP    = '8.0.0';

if (session_status() === PHP_SESSION_NONE) {
    session_name('FINTOINSTALL');
    @session_start();
}

/* ─────────────────────────── ابزارها ─────────────────────────── */
function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function fa(string $n): string { return strtr($n, ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹']); }
function jout(array $d, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}
function ensure_dir(string $dir): bool { return is_dir($dir) || @mkdir($dir, 0775, true) || is_dir($dir); }
function writable(string $path): bool
{
    if (is_dir($path)) return is_writable($path);
    if (is_file($path)) return is_writable($path);
    $dir = dirname($path);
    return is_dir($dir) && is_writable($dir);
}
function req(): array { return $_SESSION['_db'] ?? []; }
function err(string $m): void { jout(['ok' => false, 'error' => $m], 200); }

/** جداکردن دستورهای SQL با در نظر گرفتن رشته‌ها، نقل‌قول‌های معکوس و توضیحات */
function sql_statements(string $sql): array
{
    $out = []; $stmt = ''; $len = strlen($sql); $i = 0;
    while ($i < $len) {
        $ch = $sql[$i];
        if (($ch === '-' && substr($sql, $i, 2) === '--') || $ch === '#') {
            $e = strpos($sql, "\n", $i); $e = $e === false ? $len : $e; $i = $e + 1; continue;
        }
        if ($ch === '/' && substr($sql, $i, 2) === '/*') {
            $e = strpos($sql, '*/', $i + 2); $e = $e === false ? $len : $e + 2; $i = $e; continue;
        }
        if ($ch === "'" || $ch === '"' || $ch === '`') {
            $q = $ch; $j = $i + 1;
            while ($j < $len) {
                if ($sql[$j] === '\\' && $q !== '`') { $j += 2; continue; }
                if ($sql[$j] === $q) { if ($q !== '`' && $j + 1 < $len && $sql[$j + 1] === $q) { $j += 2; continue; } $j++; break; }
                $j++;
            }
            $stmt .= substr($sql, $i, $j - $i); $i = $j; continue;
        }
        if ($ch === ';') {
            $t = trim($stmt);
            if ($t !== '' && !preg_match('/^CREATE\s+DATABASE\b/i', $t) && !preg_match('/^USE\s+`?[\w$]+`?$/i', $t)) $out[] = $t;
            $stmt = ''; $i++; continue;
        }
        $stmt .= $ch; $i++;
    }
    $t = trim($stmt);
    if ($t !== '' && !preg_match('/^CREATE\s+DATABASE\b/i', $t) && !preg_match('/^USE\s+`?[\w$]+`?$/i', $t)) $out[] = $t;
    return $out;
}
function sql_of(bool $demo): string
{
    $f = $demo ? SQL_FULL : SQL_EMPTY;
    if (!is_file($f)) err('فایل نصب دیتابیس پیدا نشد: '.basename($f).' — پوشه db/ را از بسته استخراج کنید.');
    return file_get_contents($f);
}
/** کلید اتصال سازگار با PHP 8.4/8.5 (MYSQL_ATTR_INIT_COMMAND منسوخ شده است) */
function init_cmd(): int
{
    return defined('Pdo\\Mysql::ATTR_INIT_COMMAND') ? \Pdo\Mysql::ATTR_INIT_COMMAND : PDO::MYSQL_ATTR_INIT_COMMAND;
}
function connect(array $d): PDO
{
    $dsn = !empty($d['socket'])
        ? "mysql:unix_socket={$d['socket']};dbname={$d['name']};charset=utf8mb4"
        : "mysql:host={$d['host']};port={$d['port']};dbname={$d['name']};charset=utf8mb4";
    return new PDO($dsn, (string)$d['user'], (string)$d['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        init_cmd() => "SET NAMES utf8mb4, time_zone='+03:30'",
    ]);
}
function server_tables(PDO $pdo, ?string $onlyTable = null): array
{
    $db = $pdo->query('SELECT DATABASE()')->fetchColumn();
    $sql = 'SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=?';
    $p = [$db];
    if ($onlyTable) { $sql .= ' AND TABLE_NAME=?'; $p[] = $onlyTable; }
    $rows = $pdo->prepare($sql); $rows->execute($p);
    return array_column($rows->fetchAll(), 'TABLE_NAME');
}
function stat_of(PDO $pdo): array
{
    $db = $pdo->query('SELECT DATABASE()')->fetchColumn();
    $tables = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=".$pdo->quote((string)$db)." AND TABLE_TYPE='BASE TABLE'")->fetchColumn();
    $views  = (int)$pdo->query("SELECT COUNT(*) FROM information_schema.VIEWS WHERE TABLE_SCHEMA=".$pdo->quote((string)$db))->fetchColumn();
    $biz = 0;
    try { $biz = (int)$pdo->query('SELECT COUNT(*) FROM businesses')->fetchColumn(); } catch (Throwable $e) { }
    return ['tables' => $tables, 'views' => $views, 'businesses' => $biz];
}

/* ═══════════════════════════ درخواست‌های AJAX ═══════════════════════════ */
$action = (string)($_GET['action'] ?? '');
if ($action !== '') {
    try {
        /* پیش‌نیازها */
        if ($action === 'requirements') {
            $rows = [
                ['نسخه PHP (نیازمند '.MIN_PHP.'+)', PHP_VERSION, version_compare(PHP_VERSION, MIN_PHP, '>='), PHP_VERSION],
                ['افزونه pdo_mysql', extension_loaded('pdo_mysql') ? 'فعال' : 'غیرفعال', extension_loaded('pdo_mysql')],
                ['افزونه mbstring', extension_loaded('mbstring') ? 'فعال' : 'غیرفعال', extension_loaded('mbstring')],
                ['افزونه json', extension_loaded('json') ? 'فعال' : 'غیرفعال', extension_loaded('json')],
                ['قابل‌نوشتن: storage/', writable(APP_ROOT.'/storage') ? 'بله' : 'خیر', writable(APP_ROOT.'/storage')],
                ['قابل‌نوشتن: uploads/', writable(APP_ROOT.'/uploads') ? 'بله' : 'خیر', writable(APP_ROOT.'/uploads')],
                ['قابل‌نوشتن: config.local.php', writable(CONFIG_FILE) ? 'بله' : 'خیر', writable(CONFIG_FILE)],
                ['فایل db/finto.sql', is_file(SQL_FULL) ? 'موجود' : 'پیدا نشد', is_file(SQL_FULL)],
                ['فایل db/finto-empty.sql', is_file(SQL_EMPTY) ? 'موجود' : 'پیدا نشد', is_file(SQL_EMPTY)],
            ];
            jout(['ok' => true, 'rows' => array_map(fn($r) => ['label' => $r[0], 'value' => $r[1], 'ok' => (bool)$r[2]], $rows),
                  'okAll' => !in_array(false, array_column($rows, 2), true)]);
        }

        /* آزمون اتصال دیتابیس */
        if ($action === 'testdb') {
            $d = [
                'host' => trim((string)($_POST['host'] ?? 'localhost')), 'port' => (int)($_POST['port'] ?? 3306),
                'name' => trim((string)($_POST['name'] ?? '')), 'user' => trim((string)($_POST['user'] ?? '')),
                'pass' => (string)($_POST['pass'] ?? ''), 'socket' => trim((string)($_POST['socket'] ?? '')),
            ];
            if ($d['name'] === '' || $d['user'] === '') err('نام دیتابیس و نام کاربری الزامی است.');
            $_SESSION['_db'] = $d;
            try {
                $pdo = connect($d);
            } catch (Throwable $e) {
                err('اتصال برقرار نشد: '.$e->getMessage().' — نام دیتابیس، کاربر و رمز را بررسی کنید. (در cPanel معمولاً نام دیتابیس و کاربر با پیشوند حساب، مانند cpuser_finto، ساخته می‌شوند.)');
            }
            $ver = (string)$pdo->query('SELECT VERSION()')->fetchColumn();
            $isMaria = stripos($ver, 'mariadb') !== false;
            $okVersion = $isMaria ? version_compare(preg_replace('/[^0-9.].*$/', '', $ver), '10.5', '>=') : version_compare($ver, '8.0.16', '>=');
            /* بررسی دسترسی information_schema — در برخی هاست‌های اشتراکی محدود است */
            $infoSchemaOk = true;
            try { $pdo->query('SELECT TABLE_NAME FROM information_schema.TABLES LIMIT 1')->fetchColumn(); }
            catch (Throwable $e) { $infoSchemaOk = false; }
            /* وصله پیش از درون‌ریزی: گستره enum های کلیدی (برای دیتابیس‌های با نصب قبلی) */
            try {
                $tbl = $pdo->query("SHOW TABLES LIKE 'auto_entry_rule_lines'")->fetchColumn();
                if ($tbl) {
                    $r = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='auto_entry_rule_lines' AND COLUMN_NAME='account_source'")->fetchColumn();
                    if ($r && stripos((string)$r, 'cash_account') === false) {
                        $pdo->exec("ALTER TABLE `auto_entry_rule_lines` MODIFY COLUMN `account_source` ENUM('fixed','mapping','person','cash_account','dynamic_tax','bank_statement') NOT NULL");
                    }
                    $r = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='auto_entry_rule_lines' AND COLUMN_NAME='amount_source'")->fetchColumn();
                    if ($r && stripos((string)$r, 'expense_total') === false) {
                        $pdo->exec("ALTER TABLE `auto_entry_rule_lines` MODIFY COLUMN `amount_source` ENUM('invoice_total','invoice_net','tax','charges','cogs','amount','paid','remaining','net','insurance_payable','payroll_tax','expense_total') NULL");
                    }
                }
            } catch (Throwable $e) { /* دیتابیس خالی — دامپ جدید خودش enum درست دارد */ }
            $st = stat_of($pdo);
            jout(['ok' => true, 'version' => $ver, 'isMaria' => $isMaria, 'okVersion' => $okVersion,
                  'info_schema_ok' => $infoSchemaOk,
                  'existing' => $st,
                  'pretty' => fa(number_format($st['tables'])) . ' جدول و ' . fa(number_format($st['views'])) . ' نما در این دیتابیس موجود است.']);
        }

        /* شروع/ادامه درون‌ریزی */
        if ($action === 'import') {
            $d = req();
            if (!$d) err('ابتدا اتصال دیتابیس را تأیید کنید (مرحله ۲).');
            $demo = ($_POST['demo'] ?? '1') === '1';
            $wipe = ($_POST['wipe'] ?? '0') === '1';
            $part = max(0, (int)($_POST['part'] ?? 0));
            $per  = 120;                       // دستور در هر بخش
            $pdo  = connect($d);
            // اگر ساختار دیتابیس از قبل موجود است (مثلاً با ایمپورت دستی فایل db/finto.sql) و
            // کاربر پاک‌سازی را نخواسته، درون‌ریزی انجام نمی‌شود و فقط تنظیمات نوشته می‌شود.
            if ($part === 0 && !$wipe) {
                $exist = stat_of($pdo);
                if ($exist['tables'] >= 100) {
                    jout(['ok' => true, 'done' => true, 'total' => 1, 'sent' => 1, 'existing' => true,
                          'note' => 'ساختار دیتابیس از قبل موجود است ('.$exist['tables'].' جدول)؛ درون‌ریزی انجام نشد.']);
                }
            }
            if ($part === 0) {
                if ($wipe) {
                    $pdo->exec('SET FOREIGN_KEY_CHECKS=0');
                    foreach (server_tables($pdo) as $t) $pdo->exec('DROP TABLE IF EXISTS `'.$t.'`');
                    $pdo->exec('SET FOREIGN_KEY_CHECKS=1');
                }
                $_SESSION['_import_total'] = count(sql_statements(sql_of($demo)));
            }
            $stmts = sql_statements(sql_of($demo));
            $total = max(1, (int)($_SESSION['_import_total'] ?? count($stmts)));
            $chunk = array_slice($stmts, $part * $per, $per);
            if (!$chunk) jout(['ok' => true, 'done' => true, 'total' => $total, 'sent' => count($stmts)]);
            $pdo->exec("SET SESSION sql_mode='STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION'");
            $pdo->exec("SET SESSION time_zone='+03:30'");
            foreach ($chunk as $s) {
                try { $pdo->exec($s); }
                catch (Throwable $e) {
                    err('خطا در دستور شماره '.fa((string)($part * $per + 1)).': '.$e->getMessage()."\n— دستور: ".mb_substr(preg_replace('/\s+/', ' ', $s), 0, 220));
                }
            }
            jout(['ok' => true, 'done' => false, 'part' => $part, 'total' => $total,
                  'doneCount' => min(count($stmts), ($part + 1) * $per), 'sent' => count($stmts)]);
        }

        /* پایان نصب: نوشتن تنظیمات، ساخت پوشه‌ها، سال مالی و قفل نصب */
        if ($action === 'finalize') {
            $d = req();
            if (!$d) err('ابتدا اتصال دیتابیس را تأیید کنید.');
            $demo = ($_POST['demo'] ?? '1') === '1';
            $demomode = ($_POST['demomode'] ?? '1') === '1';
            $pdo = connect($d);
            $st = stat_of($pdo);
            if ($st['tables'] < 100) err('درون‌ریزی کامل نشده است ('.$st['tables'].' جدول). مرحله نصب را دوباره اجرا کنید.');

            ensure_dir(APP_ROOT.'/storage'); ensure_dir(APP_ROOT.'/uploads');

            /* ماژول «اپ فاکتورزنی فیدا» — جدول‌های اختصاصی (بدون تداخل با فینتو) */
            if (is_file(__DIR__.'/db/fida.sql')) {
                foreach (sql_statements((string)file_get_contents(__DIR__.'/db/fida.sql')) as $s) {
                    try { $pdo->exec($s); } catch (Throwable $e) { /* اگر از قبل موجود بود، رد شود */ }
                }
            }
            /* ارتقای ساختار فیدا به چندکاربره (ستون user_id) — برای نصب‌های قدیمی هم امن است */
            if (is_file(__DIR__.'/app/Fida.php')) {
                require_once __DIR__.'/app/Fida.php';
                try { Fida::migrate($pdo); } catch (Throwable $e) { /* رد شود */ }
            }

            /* تنظیمات اتصال سامانهٔ پیامک (کاوه‌نگار) — برای همهٔ کسب‌وکارها */
            try {
                $smsKeys = [
                    ['sms.kavenegar_driver',   '"kavenegar"', 'string', 'درایور ارسال پیامک (kavenegar = ارسال واقعی · log = فقط ثبت)'],
                    ['sms.kavenegar_api_key',  '"39396B65697855656D4E354B3752666F463070615668677A4A633253445934515843753547502B724D646F3D"', 'string', 'کلید API کاوه‌نگار'],
                    ['sms.kavenegar_template', '"sendmelodi"', 'string', 'نام الگوی کد تایید (Lookup)'],
                    ['sms.kavenegar_sender',   '""', 'string', 'شمارهٔ خط ارسال (خالی = خط پیش‌فرض حساب)'],
                ];
                $smsGroup = 'اتصال سامانهٔ پیامک (کاوه‌نگار)';
                foreach ($smsKeys as $sk) {
                    $st = $pdo->prepare("INSERT INTO settings (business_id, category, setting_key, value_json, value_type, title_fa, group_fa, created_at)
                                         SELECT b.id, 'sms', ?, ?, ?, ?, ?, NOW() FROM businesses b
                                         WHERE NOT EXISTS (SELECT 1 FROM settings s WHERE s.business_id = b.id AND s.setting_key = ?)");
                    $st->execute([$sk[0], $sk[1], $sk[2], $sk[3], $smsGroup, $sk[0]]);
                }
                $patchNotes[] = 'تنظیمات اتصال کاوه‌نگار';
            } catch (Throwable $e) { /* رد شود */ }

            /* اعمال وصله‌های ساختار (برای دیتابیس‌های قدیمی هم امن است) */
            $patchNotes = [];
            $colExists = function(PDO $pdo, string $t, string $c): bool {
                $r = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=".$pdo->quote($t)." AND COLUMN_NAME=".$pdo->quote($c))->fetchColumn();
                return (int)$r > 0;
            };
            if ($colExists($pdo, 'persons', 'national_legal_id') && !$colExists($pdo, 'persons', 'mobile')) {
                $pdo->exec("ALTER TABLE `persons` ADD COLUMN `mobile` VARCHAR(20) NULL COMMENT 'موبایل' AFTER `father_name`, ADD COLUMN `phone` VARCHAR(20) NULL COMMENT 'تلفن' AFTER `mobile`, ADD COLUMN `email` VARCHAR(120) NULL COMMENT 'ایمیل' AFTER `phone`, ADD COLUMN `website` VARCHAR(150) NULL COMMENT 'وبسایت' AFTER `email`");
                $patchNotes[] = 'ستون‌های تماس persons';
            }
            $r = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='auto_entry_rule_lines' AND COLUMN_NAME='amount_source'")->fetchColumn();
            if ($r && stripos((string)$r, 'expense_total') === false) {
                $pdo->exec("ALTER TABLE `auto_entry_rule_lines` MODIFY COLUMN `amount_source` ENUM('invoice_total','invoice_net','tax','charges','cogs','amount','paid','remaining','net','insurance_payable','payroll_tax','expense_total') NULL");
                $patchNotes[] = 'گستره amount_source';
            }
            $r = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='year_closing_logs' AND COLUMN_NAME='status'")->fetchColumn();
            if ($r && stripos((string)$r, 'success') === false) {
                $pdo->exec("ALTER TABLE `year_closing_logs` MODIFY COLUMN `status` ENUM('success','failed','warning','done') NOT NULL");
                $patchNotes[] = 'وضعیت لاگ بستن سال';
            }
            /* حساب نقد/بانک: انتخاب واقعی کاربر (cash_account) به‌جای نگاشت ثابت cash */
            $r = $pdo->query("SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='auto_entry_rule_lines' AND COLUMN_NAME='account_source'")->fetchColumn();
            if ($r && stripos((string)$r, 'cash_account') === false) {
                $pdo->exec("ALTER TABLE `auto_entry_rule_lines` MODIFY COLUMN `account_source` ENUM('fixed','mapping','person','cash_account','dynamic_tax','bank_statement') NOT NULL");
                $patchNotes[] = 'گستره account_source';
            }
            try {
                $n = $pdo->exec("UPDATE auto_entry_rule_lines l JOIN auto_entry_rules r ON r.id=l.rule_id SET l.account_source='cash_account' WHERE l.account_source='mapping' AND l.mapping_key='cash'");
                if ($n > 0) $patchNotes[] = 'اتصال حساب نقد/بانک به حساب انتخابی ('.fa((string)$n).' خط)';
            } catch (Throwable $e) { /* قاعده هنوز نساخته نشده */ }
            // اصلاح قواعد سند خودکار حقوق در نصب‌های قبلی
            try {
                $n = $pdo->exec("UPDATE auto_entry_rule_lines l JOIN auto_entry_rules r ON r.id=l.rule_id SET l.amount_source='expense_total' WHERE r.event_key='payroll' AND l.side='debit' AND l.amount_source='amount' AND l.mapping_key='payroll_expense'");
                $n += $pdo->exec("UPDATE auto_entry_rule_lines l JOIN auto_entry_rules r ON r.id=l.rule_id SET l.amount_source='insurance_payable' WHERE r.event_key='payroll' AND l.side='credit' AND l.mapping_key='insurance_payable' AND l.amount_source='amount'");
                $n += $pdo->exec("UPDATE auto_entry_rule_lines l JOIN auto_entry_rules r ON r.id=l.rule_id SET l.amount_source='tax' WHERE r.event_key='payroll' AND l.side='credit' AND l.mapping_key='payroll_tax' AND l.amount_source='amount'");
                $n += $pdo->exec("UPDATE auto_entry_rule_lines l JOIN auto_entry_rules r ON r.id=l.rule_id SET l.amount_source='net' WHERE r.event_key='payroll' AND l.side='credit' AND l.mapping_key='payroll_payable' AND l.amount_source='amount'");
                if ($n > 0) $patchNotes[] = 'اصلاح '.fa((string)$n).' خط قواعد حقوق';
            } catch (Throwable $e) { /* قاعده هنوز نساخته نشده */ }

            /* درایور پیامک پیش‌فرض: اگر کلید کاوه‌نگار در بسته باشد، ارسال واقعی */
            $smsDriverDefault = 'log';
            try {
                $appCfg = require __DIR__.'/config.php';
                if (!empty($appCfg['app']['kavenegar']['api_key']) && empty($_POST['sms_log'])) $smsDriverDefault = 'kavenegar';
            } catch (Throwable $e) { /* پیش‌فرض log */ }

            $conf = "<?php\n"
                . "/** تنظیمات این سرور — این فایل توسط نصب‌کننده ساخته شده است (مقدارها را می‌توانید دستی هم تغییر دهید) */\n"
                . "return [\n"
                . "    'app' => [\n"
                . "        'url'       => '',            // اگر برنامه در زیرپوشه نصب شده و به‌درستی تشخیص داده نمی‌شود، مثال: 'https://example.com/finto'\n"
                . "        'debug'     => false,         // در حال توسعه true کنید تا جزئیات خطاها نمایش داده شود\n"
                . "        'demo_mode' => " . ($demomode ? 'true' : 'false') . ",         // نمایش کد تأیید روی صفحه (برای آزمون بدون پیامک)\n"
                . "        'sms_driver'=> " . var_export($smsDriverDefault, true) . ",   // log = فقط ثبت · kavenegar = ارسال واقعی پیامک\n"
                . "        'force_https'=> false,      // اگر SSL فعال است، true کنید تا همه درخواست‌ها به https منتقل شوند\n"
                . "    ],\n"
                . "    'db' => [\n"
                . "        'host'   => " . var_export($d['host'], true) . ",\n"
                . "        'port'   => " . (int)$d['port'] . ",\n"
                . "        'name'   => " . var_export($d['name'], true) . ",\n"
                . "        'user'   => " . var_export($d['user'], true) . ",\n"
                . "        'pass'   => " . var_export($d['pass'], true) . ",\n"
                . "        'socket' => " . var_export($d['socket'], true) . ",\n"
                . "    ],\n"
                . "];\n";
            if (@file_put_contents(CONFIG_FILE, $conf) === false) err('نوشتن فایل config.local.php ممکن نشد. دسترسی پوشه را بررسی کنید.');
            @chmod(CONFIG_FILE, 0644);
            ensure_dir(APP_ROOT.'/storage');

            /* ساخت سال مالی جاری با استفاده از موتور خود برنامه */
            $fy = '';
            try {
                require_once APP_ROOT.'/app/bootstrap.php';
                $jy = gregorian_to_jalali((int)date('Y'), (int)date('n'), (int)date('j'))[0];
                $made = 0;
                foreach (Database::all('SELECT id, name FROM businesses WHERE deleted_at IS NULL ORDER BY id') as $b) {
                    $has = Database::val('SELECT COUNT(*) FROM fiscal_years WHERE business_id=? AND ? BETWEEN start_date AND end_date', [$b['id'], today()]);
                    if ($has) continue;
                    [$s, $e] = jalali_year_range((int)$jy);
                    Provisioner::createFiscalYear((int)$b['id'], 'سال مالی '.(int)$jy, $s, $e, Auth::id());
                    $made++;
                }
                $bizCount = (int)Database::val('SELECT COUNT(*) FROM businesses WHERE deleted_at IS NULL', [], 0);
                $fy = $made ? 'سال مالی '.fa((string)$jy).' برای '.fa((string)$made).' کسب‌وکار ساخته شد.'
                    : ($bizCount ? 'سال مالی جاری از قبل موجود است.' : 'کسب‌وکاری ثبت نشده است؛ پس از ثبت‌نام، سال مالی و کدینگ حساب‌ها خودکار ساخته می‌شود.');
            } catch (Throwable $e) {
                $fy = 'هشدار در ساخت سال مالی: '.$e->getMessage().' (می‌توانید دستی اجرا کنید: php tools/roll_fiscal_year.php)';
            }
            /* اشتراک نمایشی: پس از «نصب با داده» همهٔ بخش‌ها و گزارش‌ها باز باشند */
            $subNote = '';
            try {
                if ($demo) {
                    $planId = (int)Database::val("SELECT id FROM plans WHERE is_active=1 ORDER BY duration_months, id LIMIT 1", [], 0);
                    if ($planId) {
                        $made = 0;
                        foreach (Database::all('SELECT id FROM businesses WHERE deleted_at IS NULL') as $b) {
                            $has = Database::val("SELECT COUNT(*) FROM subscriptions WHERE business_id=? AND is_active=1 AND status IN ('active','trial') AND expires_at >= CURDATE()", [$b['id']]);
                            if ($has) continue;
                            $starts = today();
                            $expires = date('Y-m-d', strtotime('+90 days'));
                            $row = Database::one('SELECT id FROM subscriptions WHERE business_id=? ORDER BY id DESC LIMIT 1', [$b['id']]);
                            if ($row) {
                                Database::run('UPDATE subscriptions SET plan_id=?, starts_at=?, expires_at=?, status="active", is_active=1, auto_renew=0 WHERE id=?',
                                    [$planId, $starts, $expires, (int)$row['id']]);
                            } else {
                                Database::insert('subscriptions', ['business_id' => $b['id'], 'plan_id' => $planId, 'starts_at' => $starts,
                                    'expires_at' => $expires, 'status' => 'active', 'documents_used' => 0,
                                    'documents_limit' => 0, 'auto_renew' => 0, 'is_active' => 1, 'created_at' => now(), 'created_by' => 1]);
                            }
                            $made++;
                        }
                        if ($made) $subNote = 'اشتراک نمایشی ۹۰ روزه برای '.fa((string)$made).' کسب‌وکار فعال شد.';
                    }
                }
            } catch (Throwable $e) { $subNote = ''; }

            @file_put_contents(LOCK_FILE, "installed at ".date('c')."\ndb: ".$d['name']."\n");
            $st = stat_of($pdo);
            $base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
            $warn = $demomode ? '' : 'توجه: حالت نمایش کد تأیید خاموش است؛ برای ثبت‌نام باید سامانه پیامک را در تنظیمات وصل کنید، یا در config.local.php مقدار demo_mode را true کنید.';
            if ($patchNotes) $warn = ($warn ? $warn.' | ' : '').'وصله‌های اعمال‌شده: '.implode('، ', $patchNotes);
    jout(['ok' => true, 'tables' => $st['tables'], 'views' => $st['views'], 'businesses' => $st['businesses'],
                  'fiscal' => $fy, 'subscription' => $subNote, 'appUrl' => ($base ?: '') . '/app', 'demo' => $demo, 'warning' => $warn]);
        }

        /* بررسی سلامت نصب */
        if ($action === 'health') {
            $d = req();
            if (!$d) err('ابتدا اتصال دیتابیس را تأیید کنید.');
            $pdo = connect($d);
            $st = stat_of($pdo);
            $checks = [
                ['جدول‌های نرم‌افزار ساخته شده‌اند (۱۳۹ جدول فینتو + جدول‌های فیدا)', $st['tables'] >= 129, fa(number_format($st['tables'])) . ' جدول'],
                ['نماهای گزارش‌گیری ساخته شده‌اند', $st['views'] >= 25, fa(number_format($st['views'])) . ' نما'],
                ['سال مالی جاری برای کسب‌وکارها', (function () use ($pdo): array {
                    $st = $pdo->prepare('SELECT COUNT(*) FROM fiscal_years WHERE ? BETWEEN start_date AND end_date');
                    $st->execute([date('Y-m-d')]);
                    $n = (int)$st->fetchColumn();
                    return [$n > 0, fa(number_format($n)) . ' سال مالی', $n > 0 ? '' : 'پس از ثبت‌نام، سال مالی خودکار ساخته می‌شود.'];
                })()],
                ['کاربران ثبت‌شده', (function () use ($pdo): array {
                    $n = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
                    return [$n > 0, fa(number_format($n)) . ' کاربر', $n > 0 ? '' : 'هنوز کاربری ثبت نشده است؛ از صفحه ثبت‌نام شروع کنید.'];
                })()],
                ['فایل config.local.php', is_file(CONFIG_FILE), is_file(CONFIG_FILE) ? 'ساخته شد' : 'موجود نیست'],
                ['پوشه storage قابل نوشتن', writable(APP_ROOT.'/storage'), ''],
            ];
            jout(['ok' => true, 'rows' => array_map(function ($r) {
                $ok = is_array($r[1]) ? (bool)$r[1][0] : (bool)$r[1];
                $val = is_array($r[1]) ? (string)$r[1][1] : (string)$r[2];
                $note = is_array($r[1]) ? (string)($r[1][2] ?? '') : '';
                return ['label' => $r[0], 'ok' => $ok, 'value' => $val, 'note' => $note, 'soft' => is_array($r[1])];
            }, $checks)]);
        }

        err('درخواست ناشناخته.');
    } catch (Throwable $e) {
        err($e->getMessage());
    }
}

$installed = is_file(LOCK_FILE);
$sec = req();
$host = $sec['host'] ?? 'localhost';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>نصب نرم‌افزار حسابداری فینتو</title>
<style>
 :root{--p:#6d28d9;--p2:#8b5cf6;--bg:#f6f4fb;--ink:#241b3a;--mut:#6b6480;--line:#e6e1f2;--ok:#16a34a;--bad:#dc2626;--warn:#d97706}
 *{box-sizing:border-box}
 body{margin:0;background:linear-gradient(160deg,#f7f5fc,#efeaf9 60%,#f7f5fc);color:var(--ink);
      font-family:Vazirmatn,Tahoma,"Segoe UI",system-ui,sans-serif;font-size:15px;line-height:1.9}
 .wrap{max-width:820px;margin:0 auto;padding:26px 16px 60px}
 .hero{text-align:center;margin:10px 0 22px}
 .logo{width:64px;height:64px;border-radius:20px;margin:0 auto 10px;background:linear-gradient(135deg,var(--p),var(--p2));
       display:grid;place-items:center;color:#fff;font-size:28px;font-weight:800;box-shadow:0 10px 24px rgba(109,40,217,.28)}
 h1{font-size:24px;margin:6px 0 4px}
 .sub{color:var(--mut);font-size:14px}
 .steps{display:flex;gap:8px;justify-content:center;margin:18px 0 20px;flex-wrap:wrap}
 .step{display:flex;align-items:center;gap:6px;background:#fff;border:1px solid var(--line);border-radius:999px;padding:5px 13px;font-size:13px;color:var(--mut)}
 .step.on{background:linear-gradient(135deg,var(--p),var(--p2));color:#fff;border-color:transparent;box-shadow:0 6px 16px rgba(109,40,217,.25)}
 .card{background:#fff;border:1px solid var(--line);border-radius:18px;padding:22px;box-shadow:0 12px 34px rgba(36,27,58,.07);margin-bottom:16px}
 .card h2{font-size:17px;margin:0 0 14px;display:flex;align-items:center;gap:8px}
 .grid2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
 @media(max-width:640px){.grid2{grid-template-columns:1fr}}
 label{display:block;font-size:13px;margin-bottom:5px;color:var(--mut)}
 input[type=text],input[type=password],input[type=number]{width:100%;padding:10px 12px;border:1px solid var(--line);border-radius:12px;
      font-family:inherit;font-size:14px;background:#fbfaff;direction:ltr;text-align:left}
 input:focus{outline:2px solid rgba(139,92,246,.35);border-color:var(--p2)}
 .hint{font-size:12px;color:var(--mut);margin-top:4px}
 .btn{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,var(--p),var(--p2));color:#fff;border:0;border-radius:12px;
      padding:11px 22px;font-family:inherit;font-size:15px;font-weight:600;cursor:pointer;box-shadow:0 8px 20px rgba(109,40,217,.25)}
 .btn[disabled]{opacity:.55;cursor:not-allowed;box-shadow:none}
 .btn.ghost{background:#fff;color:var(--p);border:1px solid var(--line);box-shadow:none}
 .row{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-top:14px}
 table.chk{width:100%;border-collapse:collapse;font-size:14px}
 table.chk td{padding:9px 6px;border-bottom:1px dashed var(--line)}
 table.chk tr:last-child td{border-bottom:0}
 .pill{font-size:12px;border-radius:999px;padding:2px 10px;background:#eef2ff;color:#4338ca}
 .ok{color:var(--ok);font-weight:700}.bad{color:var(--bad);font-weight:700}.warn{color:var(--warn);font-weight:700}
 .alert{border-radius:14px;padding:12px 14px;font-size:14px;margin:12px 0}
 .alert.err{background:#fef2f2;border:1px solid #fecaca;color:#991b1b}
 .alert.ok{background:#f0fdf4;border:1px solid #bbf7d0;color:#166534}
 .alert.warn{background:#fffbeb;border:1px solid #fde68a;color:#92400e}
 .alert.info{background:#f5f3ff;border:1px solid #ddd6fe;color:#5b21b6}
 pre{background:#1e1b2e;color:#e9e4ff;border-radius:12px;padding:12px;font-size:12.5px;direction:ltr;text-align:left;overflow:auto;max-height:260px}
 .bar{height:12px;background:#efeaf9;border-radius:999px;overflow:hidden;margin:12px 0 6px}
 .bar>i{display:block;height:100%;width:0;background:linear-gradient(90deg,var(--p),var(--p2));transition:width .25s}
 .kv{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;font-size:14px;margin-top:8px}
 .kv b{color:var(--mut);font-weight:500}
 code{background:#f4f1fb;border-radius:8px;padding:2px 7px;direction:ltr;display:inline-block}
 .foot{text-align:center;color:var(--mut);font-size:12.5px;margin-top:22px}
 .hidden{display:none}
 .sw{display:flex;align-items:center;gap:10px;background:#fbfaff;border:1px solid var(--line);border-radius:14px;padding:12px 14px;margin:8px 0}
 .sw input{width:18px;height:18px;accent-color:var(--p)}
</style>
</head>
<body>
<div class="wrap">
  <div class="hero">
    <div class="logo">ف</div>
    <h1>نصب نرم‌افزار حسابداری و انبارداری فینتو</h1>
    <div class="sub">نصب‌کننده وبی — مناسب cPanel و میزبانی اشتراکی</div>
  </div>

  <div class="steps">
    <div class="step on" data-s="1">۱. بررسی پیش‌نیازها</div>
    <div class="step" data-s="2">۲. اتصال دیتابیس</div>
    <div class="step" data-s="3">۳. نصب دیتابیس</div>
    <div class="step" data-s="4">۴. پایان</div>
  </div>

<?php if ($installed): ?>
  <div class="card">
    <h2>✅ نرم‌افزار قبلاً نصب شده است</h2>
    <div class="alert info">
      فایل قفل نصب (<code>storage/installed.lock</code>) وجود دارد. برای امنیت، فایل <code>install.php</code> را از سرور حذف کنید.<br>
      برای اجرای نصب مجدد، ابتدا فایل <code>storage/installed.lock</code> را حذف کنید.
    </div>
    <div class="row">
      <a class="btn" href="./app">ورود به نرم‌افزار</a>
      <a class="btn ghost" href="./health.php">بررسی سلامت نصب</a>
    </div>
  </div>
<?php else: ?>

  <!-- مرحله ۱ -->
  <div class="card" id="c1">
    <h2>۱) بررسی پیش‌نیازهای سرور</h2>
    <table class="chk" id="reqTable"><tr><td>در حال بررسی…</td></tr></table>
    <div id="reqMsg"></div>
    <div class="row">
      <button class="btn" id="toStep2" disabled>ادامه ← مرحله ۲</button>
      <button class="btn ghost" id="recheck">بررسی مجدد</button>
    </div>
  </div>

  <!-- مرحله ۲ -->
  <div class="card hidden" id="c2">
    <h2>۲) اطلاعات دیتابیس</h2>
    <div class="alert info">
      در cPanel ابتدا از بخش <b>MySQL® Databases</b> یک دیتابیس و یک کاربر بسازید و کاربر را به دیتابیس اضافه کنید (All Privileges).
      نام دیتابیس و کاربر در cPanel معمولاً با پیشوند حساب هاستینگ ساخته می‌شوند؛ مثلاً <code>cpuser_finto</code>.
    </div>
    <div class="grid2">
      <div><label>میزبان (Host)</label><input type="text" id="db_host" value="<?= h($host) ?>" placeholder="localhost">
        <div class="hint">در cPanel معمولاً <code>localhost</code> یا <code>127.0.0.1</code></div></div>
      <div><label>پورت</label><input type="number" id="db_port" value="<?= (int)($sec['port'] ?? 3306) ?>"></div>
      <div><label>نام دیتابیس</label><input type="text" id="db_name" value="<?= h($sec['name'] ?? '') ?>" placeholder="cpuser_finto"></div>
      <div><label>کاربر دیتابیس</label><input type="text" id="db_user" value="<?= h($sec['user'] ?? '') ?>" placeholder="cpuser_finto"></div>
      <div><label>رمز عبور</label><input type="password" id="db_pass" value="<?= h($sec['pass'] ?? '') ?>"></div>
      <div><label>سوکت (اختیاری)</label><input type="text" id="db_socket" placeholder="خالی بگذارید"></div>
    </div>
    <div id="dbMsg"></div>
    <div class="row">
      <button class="btn" id="testDb">آزمون اتصال و ادامه ←</button>
      <button class="btn ghost" id="back1">بازگشت</button>
    </div>
  </div>

  <!-- مرحله ۳ -->
  <div class="card hidden" id="c3">
    <h2>۳) نصب جدول‌ها و داده‌ها</h2>
    <div class="sw"><input type="checkbox" id="optDemo" checked><label for="optDemo" style="margin:0">
      نصب همراه با <b>داده نمایشی</b> (کاربران و اسناد نمونه برای آزمون سریع)</label></div>
    <div class="sw"><input type="checkbox" id="optDemoMode" checked><label for="optDemoMode" style="margin:0">
      نمایش <b>کد تأیید</b> روی صفحه به‌جای پیامک (حالت آزمایشی) — تا زمانی که سامانه پیامک را وصل نکرده‌اید این گزینه را روشن بگذارید</label></div>
    <div class="sw"><input type="checkbox" id="optWipe"><label for="optWipe" style="margin:0">
      پاک‌سازی جدول‌های موجود در این دیتابیس و نصب از نو <span class="pill">فقط اگر قبلاً نصب کرده‌اید</span></label></div>
    <div class="alert warn">اگر این دیتابیس داده دارد، گزینه پاک‌سازی را فعال نکنید.</div>
    <div class="row">
      <button class="btn" id="startInstall">شروع نصب</button>
      <button class="btn ghost" id="back2">بازگشت</button>
    </div>
    <div class="bar hidden" id="bar"><i></i></div>
    <div id="instMsg"></div>
    <pre class="hidden" id="instLog"></pre>
  </div>

  <!-- مرحله ۴ -->
  <div class="card hidden" id="c4">
    <h2>۴) نصب کامل شد 🎉</h2>
    <div id="doneMsg"></div>
    <div class="kv" id="doneKv"></div>
    <div class="card" style="box-shadow:none;background:#fbfaff;margin:14px 0 0">
      <h2 style="font-size:15px">ورود به نرم‌افزار</h2>
      <div id="loginBox">
        <div class="kv">
          <b>آدرس نرم‌افزار</b><span id="appUrl"></span>
          <b>ورود نمایشی</b><span><code>09120000001</code> / <code>demo1234</code></span>
          <b>ثبت‌نام کاربر جدید</b><span id="regUrl"></span>
        </div>
      </div>
    </div>
    <h2 style="font-size:15px;margin-top:18px">بررسی سلامت نصب</h2>
    <table class="chk" id="healthTable"><tr><td>…</td></tr></table>
    <div class="alert err" style="margin-top:16px"><b>مهم:</b> همین حالا فایل <code>install.php</code> را از هاست خود حذف کنید (File Manager → Delete).</div>
    <div class="row">
      <a class="btn" href="./app">ورود به نرم‌افزار</a>
      <a class="btn ghost" href="./register">صفحه ثبت‌نام</a>
    </div>
  </div>

<?php endif; ?>

  <div class="foot">فینتو — نرم‌افزار حسابداری و انبارداری | نصب‌کننده نسخه ۱٫۰</div>
</div>

<script>
const $ = (s) => document.querySelector(s);
const step = (n) => {
  ['c1','c2','c3','c4'].forEach((id,i) => $('#'+id).classList.toggle('hidden', i !== n-1));
  document.querySelectorAll('.step').forEach(el => el.classList.toggle('on', +el.dataset.s <= n));
  window.scrollTo({top:0, behavior:'smooth'});
};
const post = async (action, data) => {
  const body = new URLSearchParams(data || {});
  const r = await fetch('?action=' + action, {method:'POST', body, headers:{'Content-Type':'application/x-www-form-urlencoded'}});
  return await r.json();
};
function showAlert(el, type, html) { el.innerHTML = '<div class="alert ' + type + '">' + html + '</div>'; }

/* مرحله ۱ */
async function checkReq() {
  $('#reqTable').innerHTML = '<tr><td>در حال بررسی…</td></tr>';
  const d = await post('requirements');
  $('#reqTable').innerHTML = d.rows.map(r =>
    `<tr><td>${r.label}</td><td style="width:120px;text-align:left"><span class="${r.ok?'ok':'bad'}">${r.ok?'✔ ':'✘ '}${r.value}</span></td></tr>`).join('');
  $('#toStep2').disabled = !d.okAll;
  showAlert($('#reqMsg'), d.okAll ? 'ok' : 'err', d.okAll
    ? 'همه پیش‌نیازها فراهم است. می‌توانید نصب را ادامه دهید.'
    : 'برخی پیش‌نیازها فراهم نیست. در cPanel از بخش <b>Select PHP Version</b> نسخه PHP را ۸٫۰ یا بالاتر و افزونه‌های <code>pdo_mysql</code> و <code>mbstring</code> را فعال کنید. برای دسترسی نوشتن، سطح دسترسی پوشه‌ها را <code>755</code> و فایل‌ها را <code>644</code> بگذارید (یا موقتاً <code>777</code> برای پوشه <code>storage</code>).');
}
$('#recheck').onclick = checkReq;
$('#toStep2').onclick = () => step(2);
$('#back1').onclick = () => step(1);

/* مرحله ۲ */
$('#testDb').onclick = async () => {
  const data = {host:$('#db_host').value, port:$('#db_port').value, name:$('#db_name').value, user:$('#db_user').value, pass:$('#db_pass').value, socket:$('#db_socket').value};
  $('#testDb').disabled = true;
  showAlert($('#dbMsg'), 'info', 'در حال اتصال…');
  const d = await post('testdb', data);
  $('#testDb').disabled = false;
  if (!d.ok) { showAlert($('#dbMsg'), 'err', d.error); return; }
  let html = '<div class="alert ok">اتصال برقرار شد. سرور دیتابیس: <code>' + d.version + '</code><br>' + d.pretty + '</div>';
  if (!d.okVersion) html += '<div class="alert warn">نسخه دیتابیس شما کمتر از نیاز این نرم‌افزار است (نیازمند MySQL 8.0.16+ یا MariaDB 10.5+). نصب ممکن است با خطا مواجه شود؛ در صورت امکان از cPanel نسخه دیتابیس را ارتقا دهید.</div>';
  showAlert($('#dbMsg'), 'info', html);
  setTimeout(() => step(3), 600);
};
$('#back2').onclick = () => step(2);

/* مرحله ۳ */
$('#startInstall').onclick = async () => {
  const demo = $('#optDemo').checked ? '1' : '0';
  const demomode = $('#optDemoMode').checked ? '1' : '0';
  const wipe = $('#optWipe').checked ? '1' : '0';
  $('#startInstall').disabled = true;
  $('#bar').classList.remove('hidden');
  const log = $('#instLog'); log.classList.remove('hidden'); log.textContent = '';
  let part = 0, total = 1;
  while (true) {
    const d = await post('import', {part, demo, wipe});
    if (!d.ok) { showAlert($('#instMsg'), 'err', d.error); $('#startInstall').disabled = false; return; }
    total = d.total || total;
    const pct = Math.min(100, Math.round(100 * (d.done ? d.sent : d.doneCount) / Math.max(1, total)));
    document.querySelector('#bar > i').style.width = pct + '%';
    log.textContent = 'دستور ' + (d.done ? d.sent : d.doneCount) + ' از ' + total + '  (' + pct + '٪)';
    if (d.note) { log.textContent = d.note; }
    if (d.done) break;
    part++;
  }
  document.querySelector('#bar > i').style.width = '100%';
  showAlert($('#instMsg'), 'info', 'ساختار دیتابیس آماده شد. در حال نوشتن تنظیمات و ساخت سال مالی…');
  const f = await post('finalize', {demo, demomode});
  if (!f.ok) { showAlert($('#instMsg'), 'err', f.error); $('#startInstall').disabled = false; return; }
  $('#doneMsg').innerHTML = '<div class="alert ok">دیتابیس با <b>' + f.tables + '</b> جدول و <b>' + f.views + '</b> نما نصب شد. ' + f.fiscal + (f.subscription ? ' ' + f.subscription : '') + '</div>'
    + (f.warning ? '<div class="alert warn">' + f.warning + '</div>' : '');
  $('#appUrl').innerHTML = '<a href="' + f.appUrl + '"><code>' + location.origin + f.appUrl + '</code></a>';
  $('#regUrl').innerHTML = '<a href="./register"><code>' + location.origin + '<?= rtrim(str_replace("\\\\","/",dirname($_SERVER["SCRIPT_NAME"] ?? "/")),"/") ?>/register</code></a>';
  if (f.demo) $('#loginBox').classList.remove('hidden');
  else $('#loginBox').innerHTML = '<div class="alert info">داده نمایشی نصب نشده است؛ برای ساخت کسب‌وکار خودتان از صفحه <a href="./register">ثبت‌نام</a> استفاده کنید.</div>';
  const h = await post('health', {});
  $('#healthTable').innerHTML = (h.rows || []).map(r =>
    `<tr><td>${r.label} ${r.value?'<span class="pill">'+r.value+'</span>':''}${(r.note&&!r.ok)?'<div class="hint">'+r.note+'</div>':''}</td>` +
    `<td style="width:90px;text-align:left"><span class="${r.ok?'ok':(r.soft?'warn':'bad')}">${r.ok?'✔':(r.soft?'!':'✘')}</span></td></tr>`).join('');
  step(4);
};

/* شروع */
<?php if (!$installed): ?>
checkReq();
<?php endif; ?>
</script>
</body>
</html>
