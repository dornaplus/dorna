/* ═══ فینتو — اسکریپت رابط کاربری: تقویم شمسی، ردیف‌های پویا، جست‌وجو، مودال، اعداد ═══ */
(function () {
  'use strict';
  /* ── تبدیل تاریخ میلادی ↔ شمسی ── */
  function g2j(gy, gm, gd) {
    const gdm = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    const gy2 = gm > 2 ? gy + 1 : gy;
    let days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + gdm[gm - 1];
    let jy = -1595 + 33 * Math.floor(days / 12053); days %= 12053;
    jy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    let jm, jd;
    if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
    else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
    return [jy, jm, jd];
  }
  function j2g(jy, jm, jd) {
    jy += 1595;
    let days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
    let gy = 400 * Math.floor(days / 146097); days %= 146097;
    if (days > 36524) { days--; gy += 100 * Math.floor(days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    let gd = days + 1;
    const leap = (gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0;
    const m = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0; while (gm < 12 && gd > m[gm]) { gd -= m[gm]; gm++; }
    return [gy, gm + 1, gd];
  }
  const pad = (n) => String(n).padStart(2, '0');

  /* ── فیلدهای تاریخ شمسی: مقدار میلادی در فیلد مخفی، نمایش شمسی در فیلد قابل‌ویرایش ── */
  function initJalali(root) {
    (root || document).querySelectorAll('input').forEach(function (el) {
      if (!isDateField(el)) return;
      if (el.dataset.jready) return;
      el.dataset.jready = '1';
      const hidden = document.createElement('input');
      hidden.type = 'hidden'; hidden.name = el.name + '_iso';
      el.parentNode.insertBefore(hidden, el.nextSibling);
      // مقدار اولیه: اگر data-value دارد از آن، وگرنه از خود مقدار نمایشی
      let val = el.getAttribute('data-value') || '';
      if (val && /^\d{4}-\d{2}-\d{2}/.test(val)) {
        const d = new Date(val.replace(' ', 'T'));
        const [jy, jm, jd] = g2j(d.getFullYear(), d.getMonth() + 1, d.getDate());
        el.value = en2fa(jy + '/' + pad(jm) + '/' + pad(jd) + (val.length > 10 ? ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) : ''));
      }
      if (el.value) el.value = en2fa(fa2en(el.value));   // نمایش شمسی با ارقام فارسی
      const sync = function () {
        const m = fa2en(el.value.trim());
        const mm = m.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?$/);
        if (mm) {
          const [gy, gm, gd] = j2g(+mm[1], +mm[2], +mm[3]);
          hidden.value = gy + '-' + pad(gm) + '-' + pad(gd) + (mm[4] !== undefined ? ' ' + pad(+mm[4]) + ':' + pad(+mm[5]) + ':00' : '');
        } else hidden.value = '';
      };
      el.addEventListener('change', sync); el.addEventListener('input', sync);
      el.form && el.form.addEventListener('submit', sync, { once: false });
      sync();
    });
  }

  /* ── جداساز هزارگان فارسی برای فیلدهای مبلغ ── */
  function money(str) {
    let v = fa2en(String(str)).replace(/[^\d.\-]/g, '');
    if (v === '' || v === '-' || v === '.') return v;
    const neg = v.startsWith('-'); v = v.replace('-', '');
    const [i, d] = v.split('.');
    let out = i.replace(/\B(?=(\d{3})+(?!\d))/g, '٬');
    if (d !== undefined) out += '٫' + d.slice(0, 2);
    return en2fa((neg ? '-' : '') + out);
  }
  /** مقدار عددی از هر ورودی (فارسی/عربی، با جداکنندهٔ هزار و اعشار) */
  function numVal(s) {
    return parseFloat(fa2en(String(s)).replace(/[٬،,\s]/g, '').replace(/[٫]/g, '.').replace(/[−–—]/g, '-')) || 0;
  }

  /* ── تبدیل ارقام فارسی/عربی به انگلیسی ── */
  function fa2en(str) {
    return String(str)
      .replace(/[۰-۹]/g, function (ch) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch); })
      .replace(/[٠-٩]/g, function (ch) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(ch); });
  }
  /* ── تبدیل ارقام لاتین به فارسی ── */
  function en2fa(str) {
    return String(str).replace(/[0-9]/g, function (ch) { return '۰۱۲۳۴۵۶۷۸۹'.charAt(+ch); });
  }

  /* آیا فیلد «عددی» است؟ (برای جداکننده هزارگان و چیدمان ltr) */
  function isNumericField(el) {
    if (!el || el.tagName !== 'INPUT') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (['hidden', 'password', 'file', 'checkbox', 'radio', 'email', 'range', 'color', 'date', 'datetime-local'].indexOf(t) > -1) return false;
    if (el.hasAttribute('data-num')) return true;
    if (t === 'number') return true;
    const cls = ' ' + (el.className || '') + ' ';
    if (/\b(money|num|qty|quantity|percent|price|amount|rate|discount|fee|total|balance)\b/.test(cls)) return true;
    const im = (el.getAttribute('inputmode') || '').toLowerCase();
    if (im === 'numeric' || im === 'decimal') return true;
    const n = (el.getAttribute('name') || '').toLowerCase();
    if (/(^|[_\[])(amount|price|qty|quantity|count|counted|rate|percent|discount|fee|tax|salary|total|balance|capacity|limit|score|weight|volume|width|height|length|days?|year|month|number|num|max|min|credit|debit|opening|stock|paid|remaining|subtotal|charge|commission|capital|employee_count)([_\]]|$)/.test(n)) return true;
    return false;
  }

  /* آیا ارقام این فیلد باید خودکار انگلیسی شوند؟ (هر فیلد متنی/عددی، جز رمز/ایمیل/تاریخ) */
  function shouldNormalizeDigits(el) {
    if (!el || el.tagName !== 'INPUT') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (['password', 'file', 'checkbox', 'radio', 'hidden', 'email', 'url', 'color', 'range', 'date', 'datetime-local', 'time', 'month', 'week'].indexOf(t) > -1) return false;
    return true;
  }

  /* تبدیل خودکار ارقام فارسی/عربی به انگلیسی در فیلدهای ورودی */
  function initDigits(root) {
    (root || document).querySelectorAll('input, textarea').forEach(function (el) {
      if (!shouldNormalizeDigits(el)) return;
      if (el.dataset.dready) return;
      el.dataset.dready = '1';
      if (isNumericField(el)) {
        if ((el.getAttribute('type') || '').toLowerCase() === 'number') { el.setAttribute('type', 'text'); el.setAttribute('inputmode', 'decimal'); }
        el.setAttribute('dir', 'ltr');
        el.style.textAlign = 'left';
      }
      // فیلدهایی که باید فارسی نمایش داده شوند: عددی و تاریخ
      const nameAttr = (el.getAttribute('name') || '');
      const persian = isNumericField(el) || el.classList.contains('jalali') || el.hasAttribute('data-jalali')
                      || /(^|[_-])(date|dated)|(_at$)|(jalali)/i.test(nameAttr);
      const conv = function () {
        // عددی/تاریخ: نمایش فارسی (حتی اگر لاتین تایپ شود) — ذخیره در سرور به لاتین تبدیل می‌شود
        const v = persian ? en2fa(fa2en(el.value)) : fa2en(el.value);
        if (v !== el.value) {
          const pos = el.selectionStart, len = el.value.length;
          el.value = v;
          try { const p = pos == null ? v.length : Math.max(0, pos - (len - v.length)); el.setSelectionRange(p, p); } catch (e) { }
        }
      };
      el.addEventListener('input', conv);
      el.addEventListener('change', conv);
      el.addEventListener('blur', conv);
      if (persian) conv();   // مقادیر اولیهٔ سرور هم فارسی نمایش داده شوند
    });
  }

  /* آیا فیلد «تاریخ» است؟ (برای فعال‌سازی تقویم شمسی) */
  function isDateField(el) {
    if (!el || el.tagName !== 'INPUT') return false;
    const t = (el.getAttribute('type') || 'text').toLowerCase();
    if (['hidden', 'password', 'file', 'checkbox', 'radio', 'email', 'number'].indexOf(t) > -1) return false;
    const name = (el.getAttribute('name') || '').toLowerCase();
    if (/_iso$/.test(name)) return false;
    if (el.classList.contains('jalali') || el.hasAttribute('data-jalali')) return true;
    if (t === 'date' || t === 'datetime-local') return true;
    if (/(^|[_\[])(date|tarikh|birth|expiry|due)([_\]]|$)/.test(name)) return true;
    if (/(_date|_at)$/.test(name)) return true;
    const ph = el.getAttribute('placeholder') || '';
    if (/تاریخ/.test(ph)) return true;
    return false;
  }

  /* این توابع در DOMContentLoaded مقداردهی می‌شوند (برای استفاده در ردیف‌های پویا) */
  var initCombo, initDatePicker;
  function initMoney(root) {
    (root || document).querySelectorAll('input.money').forEach(function (el) {
      if (el.dataset.mready) return; el.dataset.mready = '1';
      el.addEventListener('input', function () { el.value = money(fa2en(el.value)); });
      el.addEventListener('blur', function () { const v = numVal(el.value); el.value = v ? money(v.toFixed(0)) : ''; });
    });
  }

  /* ── منو ── */
  function initNav() {
    document.querySelectorAll('.nav-group>.nav-head').forEach(function (h) {
      h.addEventListener('click', function () { h.parentNode.classList.toggle('open'); });
    });
    document.querySelectorAll('.nav-group.active').forEach(function (g) { g.classList.add('open'); });
    const sb = document.querySelector('.sidebar'), bd = document.querySelector('.sidebar-backdrop');
    document.querySelectorAll('[data-burger]').forEach(function (burger) {
      burger.addEventListener('click', function () { sb.classList.toggle('open'); bd.classList.toggle('on'); });
    });
    if (bd) bd.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
    document.querySelectorAll('.sidebar a').forEach(function (a) {
      a.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
    });
    if (bd) bd.addEventListener('click', function () { sb.classList.remove('open'); bd.classList.remove('on'); });
  }

  /* ── جست‌وجوی سریع ── */
  function initSearch() {
    const input = document.querySelector('[data-quick-search]');
    if (!input) return;
    const box = document.querySelector('.search-results');
    let timer = null;
    input.addEventListener('input', function () {
      clearTimeout(timer);
      const q = input.value.trim();
      if (q.length < 2) { box.classList.remove('on'); box.innerHTML = ''; return; }
      timer = setTimeout(function () {
        const esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
        fetch((window.APP_BASE || '') + '/app/search?q=' + encodeURIComponent(q), { headers: { 'Accept': 'application/json' } })
          .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
          .then(function (j) {
            const items = (j && j.items) ? j.items : [];
            if (!items.length) { box.innerHTML = '<div class="empty small">نتیجه‌ای یافت نشد</div>'; box.classList.add('on'); return; }
            box.innerHTML = items.map(function (it) { return '<a href="' + esc(it.url) + '"><span class="g">' + esc(it.group) + '</span><span>' + esc(it.text) + '</span></a>'; }).join('');
            box.classList.add('on');
          })
          .catch(function () { box.innerHTML = '<div class="empty small">جست‌وجو موقتاً در دسترس نیست</div>'; box.classList.add('on'); });
      }, 250);
    });
    document.addEventListener('click', function (e) { if (!e.target.closest('.searchbox')) box.classList.remove('on'); });
    document.addEventListener('keydown', function (e) { if (e.altKey && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); input.focus(); input.select(); } });
  }

  /* ── مودال ── */
  function initModals() {
    document.querySelectorAll('[data-modal]').forEach(function (btn) {
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const m = document.getElementById(btn.getAttribute('data-modal'));
        if (!m) return;
        m.classList.add('on');
        const f = m.querySelector('form');
        if (f) { f.action = btn.getAttribute('data-action') || f.action; }
        const t = m.querySelector('[data-modal-target]');
        if (t && btn.getAttribute('data-target-name')) t.textContent = btn.getAttribute('data-target-name');
      });
    });
    document.querySelectorAll('.modal-backdrop').forEach(function (b) {
      b.addEventListener('click', function (e) { if (e.target === b || e.target.closest('[data-close]')) b.classList.remove('on'); });
    });
  }

  /* ── ردیف‌های پویا (فاکتور، حواله، سند) ── */
  const TPL = {};
  function tpl(id) {
    if (!(id in TPL)) { const el = document.getElementById(id); TPL[id] = el ? el.innerHTML : null; }
    return TPL[id];
  }
  function initRows() {
    document.querySelectorAll('[data-rows]').forEach(function (wrap) {
      const key = wrap.getAttribute('data-rows');
      const addBtn = document.querySelector('[data-add-row="' + key + '"]');
      const body = wrap.querySelector('tbody') || wrap;
      let idx = body.querySelectorAll('tr[data-row], .rowline').length;
      function addRow() {
        const t = tpl('tpl-' + key);
        if (t == null) return; // تمپلیت این جدول وجود ندارد (ردیف‌ها سرورساید مدیریت می‌شوند)
        const html = t.replace(/__i__/g, idx).replace(/__n__/g, idx + 1);
        const tr = document.createElement('tr');
        tr.setAttribute('data-row', ''); tr.innerHTML = html;
        body.appendChild(tr);
        initMoney(tr); initDigits(tr); initJalali(tr); initDatePicker(tr); initSelects(tr); initCombo(tr); idx++;
        recalc(key);
      }
      if (addBtn) addBtn.addEventListener('click', function (e) { e.preventDefault(); addRow(); });
      body.addEventListener('click', function (e) {
        const del = e.target.closest('[data-del-row]');
        if (del) { e.preventDefault(); const tr = del.closest('tr[data-row]') || del.closest('.rowline'); tr.remove(); recalc(key); }
      });
      body.addEventListener('input', function () { recalc(key); });
      body.addEventListener('change', function () { recalc(key); });
      if (!body.querySelectorAll('tr[data-row]').length && body.querySelectorAll('.rowline').length === 0) addRow();
      recalc(key);
      window['recalc_' + key] = () => recalc(key);
    });
  }

  function recalc(key) {
    const wrap = document.querySelector('[data-rows="' + key + '"]');
    if (!wrap) return;
    if (key === 'inv') {
      let sub = 0, disc = 0, tax = 0, qty = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const q = numVal(tr.querySelector('[name^="line_quantity"]')?.value);
        const p = numVal(tr.querySelector('[name^="line_unit_price"]')?.value);
        const d = numVal(tr.querySelector('[name^="line_discount"]')?.value);
        const t = tr.querySelector('[name^="line_tax_id"]');
        let rate = 0;
        if (t && t.value) rate = numVal(t.options[t.selectedIndex].getAttribute('data-rate'));
        const lt = Math.max(0, q * p - q * p * d / 100);
        const tt = lt * rate / 100;
        const cell = tr.querySelector('[data-line-total]');
        if (cell) cell.textContent = (lt + tt).toLocaleString('fa-IR');
        sub += q * p; disc += q * p * d / 100; tax += tt; qty += q;
      });
      let chg = 0, chgTax = 0;
      document.querySelectorAll('[data-charges] tr[data-row]').forEach(function (tr) {
        const a = numVal(tr.querySelector('[name^="charge_amount"]')?.value);
        const t = tr.querySelector('[name^="charge_tax_id"]');
        let rate = 0; if (t && t.value) rate = numVal(t.options[t.selectedIndex].getAttribute('data-rate'));
        chg += a; chgTax += a * rate / 100;
      });
      const invDisc = numVal(document.querySelector('[name="invoice_discount"]')?.value);
      const net = Math.max(0, sub - disc - invDisc);
      const total = net + tax + chg + chgTax;
      setText('sum_subtotal', sub); setText('sum_discount', disc + invDisc); setText('sum_tax', tax + chgTax);
      setText('sum_total', total); setText('sum_qty', qty);
      const pay = document.querySelector('[name="pay_amount"]');
      if (pay) { pay.value = money(total.toFixed(0)); }
    }
    if (key === 'jv') {
      let dr = 0, cr = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        dr += numVal(tr.querySelector('[name^="line_debit"]')?.value);
        cr += numVal(tr.querySelector('[name^="line_credit"]')?.value);
      });
      setText('sum_debit', dr); setText('sum_credit', cr);
      const diff = document.getElementById('jv_diff');
      if (diff) {
        diff.textContent = (dr - cr).toLocaleString('fa-IR');
        diff.className = Math.abs(dr - cr) < 0.01 ? 'badge on' : 'badge off';
      }
    }
    if (key === 'alloc') {
      let sum = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const a = numVal(tr.querySelector('[name^="alloc_amount"]')?.value); sum += a;
        const rem = numVal(tr.querySelector('[data-remain]')?.getAttribute('data-remain'));
        const cell = tr.querySelector('[data-after]');
        if (cell) cell.textContent = Math.max(0, rem - a).toLocaleString('fa-IR');
      });
      setText('sum_alloc', sum);
      const amt = numVal(document.querySelector('[name="amount"]')?.value);
      const hint = document.getElementById('alloc_hint');
      if (hint) {
        const rest = amt - sum;
        hint.className = 'alert ' + (rest < -0.01 ? 'error' : (Math.abs(rest) < 0.01 ? 'success' : 'info'));
        hint.textContent = rest < -0.01 ? 'جمع تخصیص از مبلغ سند بیشتر است!' : (Math.abs(rest) < 0.01 ? 'مبلغ سند کاملاً تخصیص داده شد.' : 'مانده تخصیص‌نشده: ' + rest.toLocaleString('fa-IR') + ' (علی‌الحساب)');
      }
    }
    if (key === 'stock') {
      let qty = 0, cost = 0;
      wrap.querySelectorAll('tr[data-row]').forEach(function (tr) {
        const q = numVal(tr.querySelector('[name^="line_quantity"]')?.value);
        const c = numVal(tr.querySelector('[name^="line_unit_cost"]')?.value);
        qty += q; cost += q * c;
      });
      setText('sum_qty', qty); setText('sum_cost', cost);
    }
  }
  function setText(id, v) { const el = document.getElementById(id); if (el) el.textContent = (Math.round(v * 100) / 100).toLocaleString('fa-IR'); }

  /* ── انتخاب کالا: پرکردن قیمت و واحد ── */
  function initSelects(root) {
    (root || document).querySelectorAll('select.select-search').forEach(function (el) {
      if (el.dataset.sready) return; el.dataset.sready = '1';
      el.addEventListener('change', function () {
        const opt = el.options[el.selectedIndex];
        if (!opt) return;
        const tr = el.closest('tr[data-row]');
        if (tr) {
          const priceField = tr.querySelector('[name^="line_unit_price"]');
          const type = document.querySelector('[name="invoice_type"]')?.value || 'sale';
          if (priceField && !numVal(priceField.value)) {
            const p = type === 'buy' || type === 'buy_return' ? opt.getAttribute('data-buy') : opt.getAttribute('data-sale');
            if (p) priceField.value = money(Number(p).toFixed(0));
          }
          const stockHint = tr.querySelector('[data-stock]');
          if (stockHint && opt.getAttribute('data-stock') !== null) stockHint.textContent = Number(opt.getAttribute('data-stock')).toLocaleString('fa-IR');
          const unitSel = tr.querySelector('[name^="line_unit_id"]');
          if (unitSel && !unitSel.value && opt.getAttribute('data-unit')) unitSel.value = opt.getAttribute('data-unit');
        }
        if (window['recalc_' + (tr ? (tr.closest('[data-rows]')?.getAttribute('data-rows')) : '')]) window['recalc_' + tr.closest('[data-rows]').getAttribute('data-rows')]();
      });
    });
    (root || document).querySelectorAll('[data-person-select]').forEach(function (el) {
      el.addEventListener('change', function () {
        el.closest('form').querySelectorAll('[data-person-reload]').forEach(function (l) {
          const base = l.getAttribute('data-href') || l.href.split('?')[0];
          l.href = base + '?person_id=' + el.value;
        });
        const hidden = document.querySelector('[name="person_name"]');
        if (hidden) hidden.value = el.options[el.selectedIndex]?.text || '';
        if (el.dataset.autoload === '1') window.location = el.dataset.base + '?person_id=' + el.value;
        // سررسید فاکتور بر اساس «شرایط پرداخت» شخص انتخاب‌شده (تنظیمات → شرایط پرداخت)
        const form = el.closest('form');
        const due = form ? form.querySelector('[name="due_date"][data-term-autofill]') : null;
        if (due && el.value) {
          const base = (window.APP_BASE || '');
          fetch(base + '/app/persons/' + el.value + '/payment-term', { headers: { 'Accept': 'application/json' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
              if (!d || !d.ok || !d.days) return;
              const inv = form.querySelector('[name="invoice_date"]');
              const iso = (inv && inv.getAttribute('data-value')) || due.getAttribute('data-base') || '';
              if (!iso) return;
              const dt = new Date(iso + 'T00:00:00');
              if (isNaN(dt.getTime())) return;
              dt.setDate(dt.getDate() + Number(d.days));
              const out = dt.toISOString().slice(0, 10);
              due.setAttribute('data-value', out);
              due.value = (window.FintoApp && window.FintoApp.g2j) ? window.FintoApp.g2j(out) : out;
            }).catch(function () {});
        }
      });
    });
  }

  /* ── تب‌ها ── */
  function initTabs() {
    document.querySelectorAll('[data-tabs]').forEach(function (group) {
      const links = group.querySelectorAll('a,button');
      links.forEach(function (l, i) {
        l.addEventListener('click', function (e) {
          const h = l.getAttribute('href');
          if (l.tagName === 'A' && h && !h.startsWith('#')) return; // لینک واقعی، نه تب
          e.preventDefault();
          links.forEach((x) => x.classList.remove('on')); l.classList.add('on');
          const scope = document.querySelector(group.getAttribute('data-tabs'));
          if (scope) scope.querySelectorAll('[data-tab]').forEach(function (p) {
            p.style.display = p.getAttribute('data-tab') === l.getAttribute('data-tab') ? '' : 'none';
          });
        });
      });
      const active = group.querySelector('.on') || links[0];
      if (active && group.getAttribute('data-tabs')) active.click();
    });
  }

  /* ── تأیید حذف ── */
  function initConfirm() {
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
      f.addEventListener('submit', function (e) { if (!window.confirm(f.getAttribute('data-confirm'))) e.preventDefault(); });
    });
  }
  function initToasts() {
    document.querySelectorAll('.toast').forEach(function (t) {
      setTimeout(function () { t.style.transition = 'opacity .4s'; t.style.opacity = '0'; setTimeout(() => t.remove(), 450); }, 5200);
    });
  }
  function initOtp() {
    const el = document.querySelector('.otp-input');
    if (!el) return;
    el.addEventListener('input', function () { el.value = el.value.replace(/\D/g, '').slice(0, 6); });
  }
  /* ── نمایش/پنهان کردن رمز عبور ── */
  function initPasswordToggles() {
    document.querySelectorAll('[data-toggle-pass]').forEach(function (btn) {
      if (btn.dataset.pready) return; btn.dataset.pready = '1';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        const inp = document.getElementById(btn.getAttribute('data-toggle-pass'));
        if (!inp) return;
        const show = inp.type === 'password';
        inp.type = show ? 'text' : 'password';
        btn.classList.toggle('on', show);
        btn.setAttribute('aria-label', show ? 'پنهان کردن رمز' : 'نمایش رمز');
      });
    });
  }

  /* ── چاپ و ذخیره PDF ── */
  function printToast(msg, type) {
    let w = document.querySelector('.toast-wrap');
    if (!w) { w = document.createElement('div'); w.className = 'toast-wrap'; document.body.appendChild(w); }
    const t = document.createElement('div'); t.className = 'toast ' + (type || 'info'); t.textContent = msg; w.appendChild(t);
    setTimeout(function () { t.style.transition = 'opacity .4s'; t.style.opacity = '0'; setTimeout(function () { t.remove(); }, 450); }, 4000);
  }
  function initPrintButtons() {
    document.querySelectorAll('[data-print]').forEach(function (b) {
      if (b.dataset.prready) return; b.dataset.prready = '1';
      b.addEventListener('click', function (e) { e.preventDefault(); window.print(); });
    });
    document.querySelectorAll('[data-print-pdf]').forEach(function (b) {
      if (b.dataset.prready) return; b.dataset.prready = '1';
      b.addEventListener('click', function (e) {
        e.preventDefault();
        printToast('در پنجرهٔ چاپ، مقصد را «Save as PDF» انتخاب کنید.', 'info');
        setTimeout(function () { window.print(); }, 400);
      });
    });
  }
  /* صفحه‌های چاپ: پس از آماده‌شدن فونت‌ها، پنجرهٔ چاپ باز می‌شود */
  function initPrintPages() {
    const page = document.querySelector('[data-autoprint]');
    if (!page) return;
    const pdf = page.getAttribute('data-pdf') === '1';
    const go = function () {
      if (pdf) printToast('در پنجرهٔ چاپ، مقصد را «Save as PDF» انتخاب کنید.', 'info');
      setTimeout(function () { try { window.print(); } catch (e) { } }, pdf ? 450 : 200);
    };
    if (document.fonts && document.fonts.ready && document.fonts.ready.then) document.fonts.ready.then(function () { setTimeout(go, 250); });
    else setTimeout(go, 650);
  }

  /* ── دستیار هوش مصنوعی: پیشنهاد حساب و خلاصهٔ مدیریتی ── */
  function aiEsc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); }
  function aiPost(url, data) {
    var body = new URLSearchParams(data || {});
    body.append('_token', window.CSRF || '');
    return fetch((window.APP_BASE || '') + url, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: body.toString() }).then(function (r) { return r.json(); });
  }
  function initAi() {
    document.querySelectorAll('[data-ai-categorize]').forEach(function (btn) {
      if (btn.dataset.aiready) return; btn.dataset.aiready = '1';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var sel = document.querySelector(btn.getAttribute('data-select'));
        var descEl = document.querySelector(btn.getAttribute('data-desc'));
        var kind = btn.getAttribute('data-kind') || 'expense';
        var out = btn.parentNode.querySelector('[data-ai-out]');
        var desc = descEl ? descEl.value.trim() : '';
        if (desc.length < 2) { if (out) out.innerHTML = '<span class="ai-bad">ابتدا «عنوان سند» را بنویسید.</span>'; return; }
        var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = 'در حال پیشنهاد…';
        aiPost('/app/ai/categorize', { description: desc, kind: kind }).then(function (j) {
          btn.disabled = false; btn.innerHTML = old;
          if (!j.ok) { if (out) out.innerHTML = '<span class="ai-bad">' + aiEsc(j.error || 'خطا') + '</span>'; return; }
          if (sel) {
            sel.value = j.account_id; sel.dispatchEvent(new Event('change', { bubbles: true }));
            var cbx = sel.closest('.cbx');
            if (cbx) { var inp = cbx.querySelector('.cbx-input'); var opt = sel.options[sel.selectedIndex]; if (inp && opt) inp.value = opt.text; }
          }
          var pct = Math.round((j.confidence || 0) * 100);
          if (out) out.innerHTML = '<span class="ai-ok">' + aiEsc(j.code + ' — ' + j.title) + '</span>' + (j.reason ? ' — ' + aiEsc(j.reason) : '') + (pct ? ' (' + pct + '٪)' : '');
        }).catch(function () { btn.disabled = false; btn.innerHTML = old; if (out) out.innerHTML = '<span class="ai-bad">ارتباط برقرار نشد.</span>'; });
      });
    });
    document.querySelectorAll('[data-ai-summary]').forEach(function (btn) {
      if (btn.dataset.aiready) return; btn.dataset.aiready = '1';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var out = document.getElementById(btn.getAttribute('data-out'));
        var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = 'در حال ساخت…';
        if (out) out.innerHTML = '<div class="muted">در حال تحلیل داده‌های کسب‌وکار…</div>';
        aiPost('/app/ai/summary', {}).then(function (j) {
          btn.disabled = false; btn.innerHTML = old;
          if (!out) return;
          if (!j.ok) { out.innerHTML = '<div class="alert error">' + aiEsc(j.error || 'خطا') + '</div>'; return; }
          var h = '<div class="ai-sum-body">' + aiEsc(j.summary).replace(/\n/g, '<br>') + '</div>';
          if (j.actions && j.actions.length) { h += '<div class="section-title" style="margin:12px 0 6px">اقدام پیشنهادی</div><ul class="ai-actions">'; j.actions.forEach(function (a) { h += '<li>' + aiEsc(a) + '</li>'; }); h += '</ul>'; }
          out.innerHTML = h;
        }).catch(function () { btn.disabled = false; btn.innerHTML = old; if (out) out.innerHTML = '<div class="alert error">ارتباط برقرار نشد.</div>'; });
      });
    });
  }

  /* ── اعلان‌های سررسید (۳/۲/۱ روز قبل و معوق) + حذف/خواندن برای هر کاربر ── */
  function initNotifications() {
    var btn = document.getElementById('notifBtn');
    var drop = document.getElementById('dropNotif');
    if (!btn || !drop) return;
    var dot = document.getElementById('notifDot');
    var cnt = document.getElementById('notifCount');
    var list = document.getElementById('notifList');
    var foot = document.querySelector('[data-notif-foot]');
    var CACHE = [];
    function close() { drop.classList.remove('on'); btn.setAttribute('aria-expanded', 'false'); }
    function unreadCount() { return CACHE.filter(function (i) { return !i.read; }).length; }
    function itemHtml(it) {
      var sev = it.severity === 'danger' ? 'danger' : (it.severity === 'warn' ? 'warn' : '');
      var when = it.when ? '<span class="when-chip ' + sev + '">' + aiEsc(it.when) + '</span>' : '';
      return '<a class="drop-item sev-' + aiEsc(it.severity || 'info') + (it.read ? '' : ' unread') + '" href="' + aiEsc(it.url) + '" data-nid="' + aiEsc(it.id) + '">'
           + '<span class="di-ic">' + (it.icon || '') + '</span>'
           + '<span class="di-b"><b>' + aiEsc(it.title) + when + '</b><p>' + aiEsc(it.desc) + '</p></span>'
           + '<button class="drop-del" type="button" data-del="' + aiEsc(it.id) + '" title="حذف این اعلان" aria-label="حذف این اعلان">×</button>'
           + '</a>';
    }
    /* سرتیتر هر بخش + دکمهٔ رفتن به فهرست مربوط (فاکتورها / چک‌ها جدا هستند) */
    function can(kind) {
      var box = drop.querySelector('.drop-actions');
      if (!box) return false;
      return box.getAttribute(kind === 'invoice' ? 'data-can-invoice' : 'data-can-cheque') === '1';
    }
    function secHead(title, href, n, kind) {
      var base = window.APP_BASE || '';
      var allowed = !kind || can(kind);
      return '<div class="drop-sec"><span>' + aiEsc(title) + '<span class="cnt">' + n.toLocaleString('fa-IR') + '</span></span>'
           + (href && allowed ? '<a href="' + base + href + '">مشاهدهٔ ' + aiEsc(title) + '</a>' : '') + '</div>';
    }
    function paint() {
      var un = unreadCount();
      cnt.textContent = CACHE.length.toLocaleString('fa-IR') + ' مورد' + (un ? ' · ' + un.toLocaleString('fa-IR') + ' جدید' : '');
      if (dot) dot.hidden = un === 0;
      if (foot) foot.hidden = CACHE.length === 0;
      if (!CACHE.length) { list.innerHTML = '<div class="drop-empty">اعلان جدیدی ندارید ✅</div>'; return; }
      var inv = CACHE.filter(function (i) { return i.kind === 'invoice'; });
      var chq = CACHE.filter(function (i) { return i.kind === 'cheque'; });
      var oth = CACHE.filter(function (i) { return i.kind !== 'invoice' && i.kind !== 'cheque'; });
      var html = '';
      if (inv.length) html += secHead('فاکتورها', '/app/invoices', inv.length, 'invoice') + inv.map(itemHtml).join('');
      if (chq.length) html += secHead('چک‌ها', '/app/cheques', chq.length, 'cheque') + chq.map(itemHtml).join('');
      if (oth.length) html += secHead('سایر اعلان‌ها', '', oth.length, '') + oth.map(itemHtml).join('');
      list.innerHTML = html;
    }
    function load() {
      return fetch((window.APP_BASE || '') + '/app/notifications', { headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.ok ? r.json() : Promise.reject(new Error('http')); })
        .then(function (j) { CACHE = (j && j.items) || []; paint(); return j; });
    }
    btn.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      var on = drop.classList.toggle('on');
      btn.setAttribute('aria-expanded', on ? 'true' : 'false');
    });
    document.addEventListener('click', function (e) { if (!drop.contains(e.target) && !btn.contains(e.target)) close(); });
    list.addEventListener('click', function (e) {
      // حذف یک اعلان (فقط برای همین کاربر)
      var del = e.target.closest('[data-del]');
      if (del) {
        e.preventDefault(); e.stopPropagation();
        var id = del.getAttribute('data-del');
        aiPost('/app/notifications/state', { key: id, mode: 'dismiss', ajax: '1' }).then(function () {
          CACHE = CACHE.filter(function (i) { return i.id !== id; }); paint();
        }).catch(function () {});
        return;
      }
      var a = e.target.closest('.drop-item'); if (!a) return;
      var nid = a.getAttribute('data-nid');
      var it2 = CACHE.filter(function (i) { return i.id === nid; })[0];
      if (it2 && !it2.read) {
        it2.read = true; paint();
        aiPost('/app/notifications/state', { key: nid, mode: 'read', ajax: '1' }).catch(function () {});
      }
    });
    var ra = document.querySelector('[data-notif-readall]');
    if (ra) ra.addEventListener('click', function (e) {
      e.preventDefault();
      aiPost('/app/notifications/all', { mode: 'read', ajax: '1' }).then(function () {
        CACHE.forEach(function (i) { i.read = true; }); paint();
      }).catch(function () {});
    });
    var da = document.querySelector('[data-notif-dismissall]');
    if (da) da.addEventListener('click', function (e) {
      e.preventDefault();
      if (!window.confirm('همهٔ اعلان‌ها برای شما حذف شوند؟ (فقط برای حساب کاربری شما)')) return;
      aiPost('/app/notifications/all', { mode: 'dismiss', ajax: '1' }).then(function () {
        CACHE = []; paint();
      }).catch(function () {});
    });
    load().then(function (j) {
      if (!j || !j.ok) { list.innerHTML = '<div class="drop-empty">اعلانی موجود نیست.</div>'; return; }
      try {
        if (j.urgent > 0 && sessionStorage.getItem('finto_notif_seen') !== '1') {
          sessionStorage.setItem('finto_notif_seen', '1');
          var first = CACHE.filter(function (i) { return !i.read && i.days !== null && i.days <= 1; })[0];
          if (first) printToast(first.title + ' — ' + first.desc, 'warn');
        }
      } catch (e) { }
    }).catch(function () { list.innerHTML = '<div class="drop-empty">دریافت اعلان‌ها ناموفق بود.</div>'; });
  }

  /* ── پیام‌های داخلی: نشانک و کشوی هدر ── */
  function initMessages() {
    var btn = document.getElementById('msgBtn');
    var drop = document.getElementById('dropMsg');
    if (!btn || !drop) return;
    var list = document.getElementById('msgList');
    var badge = document.getElementById('msgBadge');
    var cnt = document.getElementById('msgCount');
    function close() { drop.classList.remove('on'); btn.setAttribute('aria-expanded', 'false'); }
    function paint(d) {
      if (badge) { badge.textContent = Number(d.unread || 0).toLocaleString('fa-IR'); badge.classList.toggle('hide', !d.unread); }
      if (cnt) cnt.textContent = (d.threads || 0).toLocaleString('fa-IR') + ' گفت‌وگو';
      var items = d.items || [];
      if (!items.length) { list.innerHTML = '<div class="drop-empty">پیام جدیدی ندارید</div>'; return; }
      list.innerHTML = items.slice(0, 6).map(function (it) {
        var ic = it.avatar
          ? '<span class="di-ic di-av"><img src="' + aiEsc(it.avatar) + '" alt=""></span>'
          : '<span class="di-ic">' + (it.has_file ? '📎' : '✉️') + '</span>';
        return '<a class="drop-item msg-item' + (it.unread ? ' unread' : '') + '" href="' + aiEsc(it.url) + '">'
          + ic
          + '<span class="di-b"><b>' + aiEsc(it.from) + '<span class="when-chip">' + aiEsc(it.when) + '</span></b>'
          + '<p>' + (it.body ? aiEsc(it.body) : (it.has_file ? 'فایل ارسال شد' : '')) + '</p></span></a>';
      }).join('');
    }
    btn.addEventListener('click', function (e) {
      e.preventDefault(); e.stopPropagation();
      var on = drop.classList.toggle('on');
      btn.setAttribute('aria-expanded', on ? 'true' : 'false');
      if (on) fetch((window.APP_BASE || '') + '/app/messages/feed', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.json(); }).then(paint).catch(function () {});
    });
    document.addEventListener('click', function (e) { if (!drop.contains(e.target) && !btn.contains(e.target)) close(); });
    fetch((window.APP_BASE || '') + '/app/messages/feed', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
      .then(function (r) { return r.json(); }).then(paint).catch(function () {});
    setInterval(function () {
      fetch((window.APP_BASE || '') + '/app/messages/feed', { credentials: 'same-origin', headers: { 'Accept': 'application/json' } })
        .then(function (r) { return r.json(); }).then(paint).catch(function () {});
    }, 30000);
  }

  /* ── آیکون کوچک کنار عنوان هر بخش ── */
  function initSectionIcons() {
    var svg = '<svg class="sec-ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3l1.7 4.8L18.5 9.5l-4.8 1.7L12 16l-1.7-4.8L5.5 9.5l4.8-1.7L12 3Z"/></svg>';
    document.querySelectorAll('.section-title, .fs-title, .page-head h2, .card-head h3').forEach(function (el) {
      if (el.querySelector('svg')) return;
      el.insertAdjacentHTML('afterbegin', svg);
    });
  }

  /* ── کارت «تحلیل هوشمند» در هر بخش ── */
  function initAiInsights() {
    document.querySelectorAll('[data-ai-insight]').forEach(function (card) {
      if (card.dataset.airun) return; card.dataset.airun = '1';
      var btn = card.querySelector('[data-ai-run]');
      var out = card.querySelector('.ai-insight-out');
      if (!btn || !out) return;
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = '…';
        var body = new URLSearchParams();
        body.append('_token', window.CSRF || '');
        body.append('scope', card.getAttribute('data-scope') || 'dashboard');
        body.append('module', card.getAttribute('data-module') || '');
        body.append('id', card.getAttribute('data-id') || '');
        body.append('title', card.getAttribute('data-title') || '');
        if (card.hasAttribute('data-sample')) { body.append('sample', card.getAttribute('data-sample')); body.append('count', card.getAttribute('data-count') || '0'); }
        out.innerHTML = '<div class="muted"><span class="spinner"></span> در حال تحلیل…</div>';
        fetch((window.APP_BASE || '') + '/app/ai/insight', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'Accept': 'application/json' }, body: body.toString() })
          .then(function (r) { return r.json(); })
          .then(function (j) {
            btn.disabled = false; btn.innerHTML = old;
            if (!j.ok) { out.innerHTML = '<div class="alert error">' + aiEsc(j.error || 'خطا') + '</div>'; return; }
            var h = '<div class="ai-head"><span class="ai-score band-' + aiEsc(j.band) + '">' + j.score + '</span><b>' + aiEsc(j.headline) + '</b></div>';
            if (j.bullets && j.bullets.length) { h += '<ul class="ai-actions">'; j.bullets.forEach(function (x) { h += '<li>' + aiEsc(x) + '</li>'; }); h += '</ul>'; }
            if (j.actions && j.actions.length) { h += '<div class="section-title" style="margin:10px 0 6px">اقدام پیشنهادی</div><ul class="ai-actions">'; j.actions.forEach(function (x) { h += '<li>' + aiEsc(x) + '</li>'; }); h += '</ul>'; }
            out.innerHTML = h;
          })
          .catch(function () { btn.disabled = false; btn.innerHTML = old; out.innerHTML = '<div class="alert error">ارتباط برقرار نشد.</div>'; });
      });
    });
  }
  /* ── تولید متن با AI برای فیلدها (شرح/عنوان/پیامک/پاسخ) ── */
  function initAiCompose() {
    document.querySelectorAll('[data-ai-compose]').forEach(function (btn) {
      if (btn.dataset.aiready) return; btn.dataset.aiready = '1';
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        var target = document.querySelector(btn.getAttribute('data-target'));
        var type = btn.getAttribute('data-type') || 'invoice_desc';
        var ctx = btn.getAttribute('data-context') || '';
        var from = btn.getAttribute('data-from');
        if (from) { var el = document.querySelector(from); if (el && el.value) ctx += ' | ' + el.value; }
        if (btn.hasAttribute('data-include-target') && target && target.value) ctx += ' | ' + target.value;
        var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = '…';
        aiPost('/app/ai/compose', { type: type, context: ctx }).then(function (j) {
          btn.disabled = false; btn.innerHTML = old;
          if (!j.ok) { printToast(j.error || 'خطا', 'error'); return; }
          if (target) { target.value = j.text || target.value; target.dispatchEvent(new Event('input', { bubbles: true })); }
          printToast('متن با هوش مصنوعی تولید شد.', 'info');
        }).catch(function () { btn.disabled = false; btn.innerHTML = old; printToast('ارتباط برقرار نشد.', 'error'); });
      });
    });
  }

  /* ── بارگذاری سند و استخراج خودکار (فقط پیش‌پرکردن، بدون ثبت خودکار) ── */
  function aiNorm(s) { return String(s == null ? '' : s).toLowerCase().replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[\u200c\s]+/g, ' ').replace(/[()\-–—،,.:;]/g, ' ').replace(/\s+/g, ' ').trim(); }
  function aiSetField(sel, val) {
    if (!sel || val === null || val === undefined || val === '') return false;
    var el = document.querySelector(sel);
    if (!el) return false;
    if (el.tagName === 'SELECT') {
      var opts = Array.prototype.slice.call(el.options);
      var opt = opts.filter(function (o) { return o.value === String(val); })[0];
      if (!opt) { var t = String(val).toLowerCase(); opt = opts.filter(function (o) { return o.value && o.text.toLowerCase().indexOf(t) !== -1; })[0]; }
      if (!opt) return false;
      el.value = opt.value; el.dispatchEvent(new Event('change', { bubbles: true }));
      var cbx = el.closest('.cbx'); if (cbx) { var i = cbx.querySelector('.cbx-input'); if (i) i.value = opt.text; }
      return true;
    }
    el.value = val;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }
  function aiAddItems(items) {
    var wrap = document.querySelector('[data-rows]');
    if (!wrap) return 0;
    var key = wrap.getAttribute('data-rows');
    var addBtn = document.querySelector('[data-add-row="' + key + '"]');
    var used = 0;
    function emptyRow() {
      var rows = wrap.querySelectorAll('tr[data-row]');
      for (var i = 0; i < rows.length; i++) { var p = rows[i].querySelector('[name^="line_product_id"]'); if (p && !p.value) return rows[i]; }
      return null;
    }
    items.forEach(function (it) {
      var tr = emptyRow();
      if (!tr && addBtn) { addBtn.click(); var rows = wrap.querySelectorAll('tr[data-row]'); tr = rows[rows.length - 1]; }
      if (!tr) return;
      var psel = tr.querySelector('[name^="line_product_id"]');
      if (psel) {
        var opts = Array.prototype.slice.call(psel.options), opt = null;
        if (it.product_id) opt = opts.filter(function (o) { return o.value === String(it.product_id); })[0] || null;
        if (!opt) { var t = aiNorm(it.name); if (t) opt = opts.filter(function (o) { return o.value && aiNorm(o.text).indexOf(t) !== -1; })[0] || null; }
        if (!opt) { var toks = aiNorm(it.name).split(' ').filter(function (w) { return w.length > 2; }); if (toks.length) opt = opts.filter(function (o) { var ot = aiNorm(o.text); return o.value && toks.filter(function (w) { return ot.indexOf(w) !== -1; }).length >= Math.max(1, Math.ceil(toks.length / 2)); })[0] || null; }
        if (opt) { psel.value = opt.value; psel.dispatchEvent(new Event('change', { bubbles: true })); var cbx = psel.closest('.cbx'); if (cbx) { var ci = cbx.querySelector('.cbx-input'); if (ci) ci.value = opt.text; } }
      }
      var q = tr.querySelector('[name^="line_quantity"]'); if (q && it.quantity) { q.value = it.quantity; q.dispatchEvent(new Event('input', { bubbles: true })); }
      var pr = tr.querySelector('[name^="line_unit_price"]'); if (pr && it.unit_price) { pr.value = it.unit_price; pr.dispatchEvent(new Event('input', { bubbles: true })); }
      var c = tr.querySelector('[name^="line_unit_cost"]'); if (c && it.unit_cost) { c.value = it.unit_cost; c.dispatchEvent(new Event('input', { bubbles: true })); }
      used++;
    });
    return used;
  }
  function initAiUpload() {
    document.querySelectorAll('[data-ai-upload]').forEach(function (box) {
      if (box.dataset.auready) return; box.dataset.auready = '1';
      var file = box.querySelector('[data-ai-file]');
      var btn = box.querySelector('[data-ai-extract]');
      var out = box.querySelector('[data-ai-out]');
      if (!file || !btn || !out) return;
      btn.addEventListener('click', function (e) {
        e.preventDefault();
        if (!file.files || !file.files[0]) { out.innerHTML = '<div class="alert warn sm">ابتدا یک فایل PDF یا تصویر انتخاب کنید.</div>'; return; }
        var f = file.files[0];
        var old = btn.innerHTML; btn.disabled = true; btn.innerHTML = '…';
        out.innerHTML = '<div class="muted"><span class="spinner"></span> در حال خواندن سند و استخراج اطلاعات…</div>';
        var rd = new FileReader();
        rd.onload = function () {
          var b64 = String(rd.result).split(',')[1] || '';
          aiPost('/app/ai/extract', { kind: box.getAttribute('data-kind'), filename: f.name, file_data: b64 }).then(function (j) {
            btn.disabled = false; btn.innerHTML = old;
            if (!j.ok) { out.innerHTML = '<div class="alert error">' + aiEsc(j.error || 'خطا') + '</div>'; return; }
            var filled = 0, lines = [], assign = j.assign || {};
            Object.keys(assign).forEach(function (sel) { if (aiSetField(sel, assign[sel])) { filled++; lines.push(aiEsc(sel) + ': ' + aiEsc(assign[sel])); } });
            var psel2 = document.querySelector('[name="person_id"]');
            if (psel2) {
              var popts = Array.prototype.slice.call(psel2.options), popt = null;
              if (j.person_id) popt = popts.filter(function (o) { return o.value === String(j.person_id); })[0] || null;
              if (!popt && j.person_name) { var pt = aiNorm(j.person_name); popt = popts.filter(function (o) { return o.value && aiNorm(o.text).indexOf(pt) !== -1; })[0] || null; }
              if (!popt && j.person_name) { var ptk = aiNorm(j.person_name).split(' ').filter(function (w) { return w.length > 2; }); if (ptk.length) popt = popts.filter(function (o) { var ot = aiNorm(o.text); return o.value && ptk.some(function (w) { return ot.indexOf(w) !== -1; }); })[0] || null; }
              if (popt) { psel2.value = popt.value; psel2.dispatchEvent(new Event('change', { bubbles: true })); var pcb = psel2.closest('.cbx'); if (pcb) { var pci = pcb.querySelector('.cbx-input'); if (pci) pci.value = popt.text; } filled++; lines.push('طرف حساب: ' + aiEsc(popt.text)); }
              else if (j.person_name) { lines.push('طرف حساب در سند: ' + aiEsc(j.person_name) + ' (در فهرست یافت نشد — دستی انتخاب کنید)'); }
            }
            var html = '<div class="alert success sm">' + filled + ' مورد پیش‌پر شد. لطفاً بازبینی کنید و سپس دکمهٔ «ثبت» را بزنید — هیچ‌چیز خودکار ثبت نشد.</div>';
            var meta = [];
            if (j.doc && (j.doc.number || j.doc.date)) meta.push('سند: ' + aiEsc([j.doc.number, j.doc.date].filter(Boolean).join(' — ')));
            if (j.totals && (j.totals.grand_total || j.totals.subtotal)) meta.push('جمع: ' + aiEsc(String(j.totals.grand_total || j.totals.subtotal)));
            if (typeof j.confidence === 'number' && j.confidence > 0) meta.push('اطمینان: ' + Math.round(j.confidence * 100) + '٪');
            if (meta.length) html += '<div class="help">' + meta.join(' · ') + '</div>';
            if (lines.length) html += '<ul class="ai-actions">' + lines.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ul>';
            if (j.notes) html += '<div class="help">یادداشت AI: ' + aiEsc(j.notes) + '</div>';
            if (j.items && j.items.length) {
              html += '<div class="section-title" style="margin:10px 0 6px">اقلام استخراج‌شده (' + j.items.length + ')</div>';
              html += '<div class="table-wrap"><table class="tbl" style="min-width:0"><thead><tr><th>شرح</th><th class="num">مقدار</th><th class="num">قیمت واحد</th><th class="num">بهای واحد</th></tr></thead><tbody>';
              j.items.forEach(function (it) { html += '<tr><td>' + aiEsc(it.name) + '</td><td class="num">' + (it.quantity || '') + '</td><td class="num">' + (it.unit_price || '') + '</td><td class="num">' + (it.unit_cost || '') + '</td></tr>'; });
              html += '</tbody></table></div><button type="button" class="btn soft sm" data-ai-additems style="margin-top:8px">افزودن این اقلام به فرم</button>';
            }
            out.innerHTML = html;
            var ab = out.querySelector('[data-ai-additems]');
            if (ab) ab.addEventListener('click', function (ev) { ev.preventDefault(); var n = aiAddItems(j.items || []); printToast(n + ' قلم به فرم افزوده شد؛ بازبینی کنید.', 'info'); });
          }).catch(function () { btn.disabled = false; btn.innerHTML = old; out.innerHTML = '<div class="alert error">ارتباط برقرار نشد.</div>'; });
        };
        rd.onerror = function () { btn.disabled = false; btn.innerHTML = old; out.innerHTML = '<div class="alert error">خواندن فایل ناموفق بود.</div>'; };
        rd.readAsDataURL(f);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
  
  /* تبدیل خودکار ارقام فارسی/عربی به انگلیسی در فیلدها — تابع fa2en/initDigits در بالای همین فایل (دامنهٔ سراسری) تعریف شده تا در ردیف‌های پویا هم کار کند */


  /* ═══ دراپ‌داون جستجو‌دار (combobox) برای select.select-search ═══ */
  initCombo = function (root) {
    (root || document).querySelectorAll('select.select-search').forEach(function (sel) {
      if (sel.dataset.cbready) return;
      sel.dataset.cbready = '1';
      sel.style.display = 'none';
      const wrap = document.createElement('div');
      wrap.className = 'cbx';
      const box = document.createElement('input');
      box.type = 'text'; box.className = 'inp cbx-input'; box.autocomplete = 'off';
      box.placeholder = 'جست‌وجو و انتخاب…';
      const list = document.createElement('div');
      list.className = 'cbx-list';
      wrap.appendChild(box); wrap.appendChild(list);
      sel.parentNode.insertBefore(wrap, sel);
      wrap.appendChild(sel);

      function syncBox() {
        const opt = sel.options[sel.selectedIndex];
        box.value = opt && opt.value ? opt.text : '';
      }
      syncBox();

      function renderList(filter) {
        const f = (filter || '').trim().toLowerCase();
        let html = '', count = 0;
        for (const o of sel.options) {
          if (!o.value || o.hidden) continue;
          if (f && o.text.toLowerCase().indexOf(f) === -1 && o.value.toLowerCase().indexOf(f) === -1) continue;
          html += '<div class="cbx-item' + (o.selected ? ' on' : '') + '" data-v="' + o.value + '">' + o.text + '</div>';
          if (++count >= 300) break;
        }
        list.innerHTML = html || '<div class="cbx-empty">موردی یافت نشد</div>';
        list.scrollTop = 0;
      }
      function openList() {
        document.querySelectorAll('.cbx-list.on').forEach(function (l) { if (l !== list) l.classList.remove('on'); });
        renderList('');
        list.classList.add('on');
        box.focus();
      }
      function closeList() { list.classList.remove('on'); }
      box.addEventListener('mousedown', function (e) { if (!list.classList.contains('on')) { openList(); e.preventDefault(); } });
      box.addEventListener('focus', function () { if (!list.classList.contains('on')) openList(); });
      box.addEventListener('input', function () { renderList(box.value); });
      box.addEventListener('blur', function () { setTimeout(closeList, 160); });
      list.addEventListener('mousedown', function (e) {
        const it = e.target.closest('.cbx-item');
        if (!it) return;
        e.preventDefault();
        sel.value = it.getAttribute('data-v');
        sel.dispatchEvent(new Event('change'));
        syncBox();
        closeList();
        box.blur();
      });
      box.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
          e.preventDefault();
          const items = list.querySelectorAll('.cbx-item');
          if (!items.length) return;
          let idx = Array.from(items).findIndex(function (i) { return i.classList.contains('hl'); });
          const next = e.key === 'ArrowDown' ? Math.min(idx + 1, items.length - 1) : Math.max(idx - 1, 0);
          items.forEach(function (i) { i.classList.remove('hl'); });
          items[next].classList.add('hl');
          items[next].scrollIntoView({ block: 'nearest' });
        } else if (e.key === 'Enter') {
          e.preventDefault();
          const hl = list.querySelector('.cbx-item.hl') || list.querySelector('.cbx-item.on');
          if (hl) { sel.value = hl.getAttribute('data-v'); sel.dispatchEvent(new Event('change')); syncBox(); closeList(); }
        } else if (e.key === 'Escape') { closeList(); box.blur(); }
      });
      // آبشاری: استان → شهر
      if (sel.dataset.provinceSource || sel.getAttribute('data-province-source')) {
        const srcId = sel.getAttribute('data-province-source');
        const src = srcId && document.getElementById(srcId);
        if (src) {
          src.addEventListener('change', function () {
            const prov = src.value;
            for (const o of sel.options) {
              if (!o.value) { o.hidden = false; continue; }
              o.hidden = !!prov && o.getAttribute('data-prov') !== prov;
            }
            const cur = sel.options[sel.selectedIndex];
            if (prov && cur && cur.value && cur.getAttribute('data-prov') !== prov) { sel.value = ''; syncBox(); }
          });
        }
      }
    });
  };

    /* تمام initializeها در پایان همین اسکوپ و پس از تعریف همهٔ توابع اجرا می‌شوند */
  /* ═══ تقویم شمسی بازشو (datepicker) برای input.jalali ═══ */
  const JMONTHS = ['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
  const JWDAYS = ['ش','ی','د','س','چ','پ','ج'];
  function jIsLeap(jy) { const r = jy % 33; return [1,5,9,13,17,22,26,30].indexOf(r) > -1; }
  function jMonthLen(jy, jm) { return jm <= 6 ? 31 : (jm <= 11 ? 30 : (jIsLeap(jy) ? 30 : 29)); }
  function jalaliToDate(jy, jm, jd) {
    const [gy, gm, gd] = j2g(jy, jm, jd);
    return new Date(gy, gm - 1, gd);
  }
  function dateToJalali(d) { return g2j(d.getFullYear(), d.getMonth() + 1, d.getDate()); }
  function jToday() { return dateToJalali(new Date()); }

  let dpEl = null, dpTarget = null, dpState = null;

  function dpBuild(jy, jm) {
    dpState = { jy: jy, jm: jm };
    const first = jalaliToDate(jy, jm, 1);
    let startWd = (first.getDay() + 1) % 7; // شنبه = ۰
    const len = jMonthLen(jy, jm);
    const [ty, tm, td] = jToday();
    const cur = dpTarget && fa2en(dpTarget.value).match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})/);
    const sel = cur ? [+cur[1], +cur[2], +cur[3]] : null;
    let html = '<div class="dp-head"><button type="button" class="dp-nav" data-dp="prev">‹</button>' +
      '<select class="dp-month">' + JMONTHS.map(function (m, i) { return '<option value="' + (i + 1) + '"' + ((i + 1) === jm ? ' selected' : '') + '>' + m + '</option>'; }).join('') + '</select>' +
      '<select class="dp-year">' + (function () { let s = ''; for (let y = ty - 40; y <= ty + 6; y++) s += '<option value="' + y + '"' + (y === jy ? ' selected' : '') + '>' + en2fa(String(y)) + '</option>'; return s; })() + '</select>' +
      '<button type="button" class="dp-nav" data-dp="next">›</button></div>';
    html += '<div class="dp-grid">' + JWDAYS.map(function (w) { return '<span class="dp-wd">' + w + '</span>'; }).join('');
    for (let i = 0; i < startWd; i++) html += '<span></span>';
    for (let d = 1; d <= len; d++) {
      const isToday = (ty === jy && tm === jm && td === d);
      const isSel = sel && sel[0] === jy && sel[1] === jm && sel[2] === d;
      html += '<button type="button" class="dp-day' + (isToday ? ' today' : '') + (isSel ? ' sel' : '') + '" data-dp-day="' + d + '">' + en2fa(String(d)) + '</button>';
    }
    html += '</div><div class="dp-foot"><button type="button" class="dp-btn" data-dp="today">امروز</button>' +
      '<button type="button" class="dp-btn" data-dp="clear">پاک کردن</button></div>';
    return html;
  }

  function dpOpen(input) {
    dpClose();
    dpTarget = input;
    const m = fa2en(input.value).match(/^(\d{4})\/(\d{1,2})/);
    let jy, jm;
    if (m) { jy = +m[1]; jm = +m[2]; }
    else { const t = jToday(); jy = t[0]; jm = t[1]; }
    dpEl = document.createElement('div');
    dpEl.className = 'jdp';
    dpEl.setAttribute('role', 'dialog');
    dpEl.innerHTML = dpBuild(jy, jm);
    document.body.appendChild(dpEl);
    const r = input.getBoundingClientRect();
    // اندازهٔ واقعی تقویم (به‌جای اعداد ثابت) تا موقعیت‌یابی در همهٔ پوسته‌ها درست باشد
    const W = dpEl.offsetWidth || 272, H = dpEl.offsetHeight || 344;
    let x = r.right - W, y = r.bottom + 8;
    if (window.innerWidth <= 560) { x = Math.max(8, (window.innerWidth - W) / 2); }
    else if (x < 8) x = 8;
    if (y + H > window.innerHeight) y = Math.max(8, Math.min(r.top - H - 8, window.innerHeight - H - 8));
    dpEl.style.left = x + 'px'; dpEl.style.top = y + 'px';

    // واگذاری رخداد (event delegation): ناوبری و انتخاب روز همیشه کار می‌کند
    dpEl.addEventListener('click', function (e) {
      const nav = e.target.closest('[data-dp]');
      if (nav) {
        e.preventDefault();
        const a = nav.getAttribute('data-dp');
        if (a === 'prev') { let yy = dpState.jy, mm = dpState.jm - 1; if (mm < 1) { mm = 12; yy--; } dpRender(yy, mm); }
        else if (a === 'next') { let yy = dpState.jy, mm = dpState.jm + 1; if (mm > 12) { mm = 1; yy++; } dpRender(yy, mm); }
        else if (a === 'today') { const t = jToday(); dpPick(t[0], t[1], t[2]); }
        else if (a === 'clear') { dpTarget.value = ''; dpTarget.dispatchEvent(new Event('change')); dpClose(); }
        return;
      }
      const day = e.target.closest('[data-dp-day]');
      if (day) { dpPick(dpState.jy, dpState.jm, +day.getAttribute('data-dp-day')); }
    });
    dpEl.addEventListener('change', function (e) {
      if (e.target.matches('.dp-month,.dp-year')) {
        dpRender(+dpEl.querySelector('.dp-year').value, +dpEl.querySelector('.dp-month').value);
      }
    });
    document.addEventListener('keydown', dpKeydown);
    setTimeout(function () { document.addEventListener('mousedown', dpOutside); }, 0);
  }
  function dpRender(jy, jm) { dpEl.innerHTML = dpBuild(jy, jm); }
  function dpKeydown(e) { if (e.key === 'Escape') dpClose(); }
  function dpOutside(e) { if (dpEl && !dpEl.contains(e.target) && e.target !== dpTarget && !dpTarget.contains(e.target)) dpClose(); }
  function dpClose() { if (dpEl) { dpEl.remove(); dpEl = null; } document.removeEventListener('mousedown', dpOutside); document.removeEventListener('keydown', dpKeydown); }
  function dpPick(jy, jm, jd) {
    dpTarget.value = en2fa(jy + '/' + pad(jm) + '/' + pad(jd));
    dpTarget.dispatchEvent(new Event('change'));
    dpClose();
  }

  initDatePicker = function (root) {
    (root || document).querySelectorAll('input').forEach(function (el) {
      if (!isDateField(el)) return;
      if (el.dataset.dpready) return;
      el.dataset.dpready = '1';
      const t = (el.getAttribute('type') || '').toLowerCase();
      if (t === 'date' || t === 'datetime-local') el.setAttribute('type', 'text');
      if (!el.hasAttribute('data-typing')) el.setAttribute('readonly', 'readonly'); // انتخاب از تقویم شمسی
      el.classList.add('jalali');
      el.style.cursor = 'pointer';
      el.setAttribute('autocomplete', 'off');
      el.addEventListener('click', function () { dpOpen(el); });
      el.addEventListener('focus', function () { if (window.matchMedia && window.matchMedia('(pointer:coarse)').matches) dpOpen(el); });
      el.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown') { e.preventDefault(); dpOpen(el); }
        else if (e.key === 'Escape') dpClose();
      });
    });
  };

  [initNav, initSearch, initModals, initRows, initMoney, initDigits, initCombo, initJalali, initDatePicker,
   initSelects, initTabs, initConfirm, initToasts, initOtp, initPasswordToggles, initPrintButtons, initPrintPages, initAi, initNotifications, initMessages, initSectionIcons, initAiInsights, initAiCompose, initAiUpload]
    .forEach(function (fn) { try { fn(); } catch (e) { if (window.console && console.error) console.error('Finto init:', e); } });
  window.FintoApp = { g2j, j2g, initJalali, initMoney, initDigits, initCombo, initDatePicker, initPrintPages, money, numVal, fa2en, en2fa, toast: printToast };
  });
})();
