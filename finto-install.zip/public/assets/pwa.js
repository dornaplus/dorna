/* ══════════════════════════════════════════════════════════════════════
   فینتو / فیدا — راه‌اندازی PWA
   • ثبت سرویس‌ورکر (کش دارایی‌ها + صفحهٔ آفلاین)
   • دکمهٔ «نصب اپ» برای اندروید/کروم (beforeinstallprompt)
   • راهنمای نصب برای iPhone/iPad و مرورگرهای دیگر
   در هر صفحه‌ای که این فایل لود شود کار می‌کند:
     window.PWA_APP   = 'fida' | 'finto'   (پیش‌فرض fida)
     window.PWA_FAB   = false              (دکمهٔ شناور را نشان نده)
     window.PWA_BTN   = false              (دکمه‌های [data-pwa-install] را دست نزن)
   ══════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  var base = String(window.APP_BASE || '').replace(/\/+$/, '');
  var app  = window.PWA_APP || 'fida';
  var LSK  = 'pwa.dismissed.' + app;
  var deferred = null;

  /* ── ۱) سرویس‌ورکر ── */
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register(base + '/sw.js', { scope: base + '/' }).catch(function () { /* در حالت‌های خاص بی‌صدا رد می‌شویم */ });
    });
  }

  /* ── ۲) وضعیت نصب ── */
  function standalone() {
    try {
      return (window.matchMedia && (window.matchMedia('(display-mode: standalone)').matches || window.matchMedia('(display-mode: fullscreen)').matches || window.matchMedia('(display-mode: minimal-ui)').matches)) || window.navigator.standalone === true;
    } catch (e) { return false; }
  }
  var ua = navigator.userAgent || '';
  var isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var isSafari = /Safari/.test(ua) && !/Chrome|CriOS|FxiOS|EdgiOS|OPiOS|Android|SamsungBrowser/.test(ua);
  var canInstall = !standalone();      // در حالت نصب‌شده هیچ دکمه‌ای نشان نمی‌دهیم

  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  var dismissed = ls(LSK) === '1';

  /* ── ۳) استایل‌ها ── */
  var fabBottom = app === 'fida' ? 'calc(148px + env(safe-area-inset-bottom))' : 'calc(84px + env(safe-area-inset-bottom))';
  var css = ''
  + '.pwa-fab{position:fixed;inset-inline-start:14px;bottom:' + fabBottom + ';z-index:1200;'
  + 'display:flex;align-items:center;gap:2px;background:#fff;border:1px solid #EDE9FE;border-radius:16px;'
  + 'box-shadow:0 12px 30px rgba(76,29,149,.22);padding:6px;animation:pwaIn .35s ease-out}'
  + '@keyframes pwaIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}'
  + '.pwa-fab-btn{display:flex;align-items:center;gap:9px;border:0;background:linear-gradient(150deg,#7C3AED,#5B21B6);'
  + 'color:#fff;font-family:inherit;font-weight:800;font-size:13px;border-radius:12px;padding:10px 13px;cursor:pointer}'
  + '.pwa-fab-btn .ic{font-size:17px;line-height:1}'
  + '.pwa-fab-btn small{display:block;font-weight:600;font-size:10.5px;opacity:.85;margin-top:1px}'
  + '.pwa-fab-x{border:0;background:transparent;color:#8B85A0;font-size:19px;line-height:1;width:26px;height:26px;cursor:pointer;border-radius:8px}'
  + '.pwa-ios{position:fixed;inset:0;z-index:1300;background:rgba(30,20,60,.55);backdrop-filter:blur(3px);display:flex;align-items:flex-end;justify-content:center;padding:0}'
  + '.pwa-ios-card{background:#fff;width:100%;max-width:520px;border-radius:22px 22px 0 0;padding:20px 18px calc(20px + env(safe-area-inset-bottom));animation:pwaUp .3s ease-out}'
  + '@keyframes pwaUp{from{transform:translateY(30px)}to{transform:none}}'
  + '.pwa-ios-card h3{margin:0 0 12px;font-size:16px;color:#2E1065}'
  + '.pwa-ios-card ol{margin:0;padding-inline-start:20px;color:#5B5470;font-size:13.5px;line-height:2.2}'
  + '.pwa-ios-card b{color:#4C1D95}'
  + '.pwa-ios-go{width:100%;margin-top:16px;border:0;border-radius:14px;padding:13px;font-family:inherit;font-weight:800;font-size:14.5px;'
  + 'color:#fff;background:linear-gradient(150deg,#7C3AED,#5B21B6);cursor:pointer}'
  + '.pwa-ios-tip{margin-top:10px;font-size:11.5px;color:#8B85A0;text-align:center;line-height:1.9}'
  + '[data-pwa-install][hidden]{display:none !important}';

  function injectCss() {
    if (document.getElementById('pwaCss')) return;
    var s = document.createElement('style');
    s.id = 'pwaCss'; s.textContent = css;
    document.head.appendChild(s);
  }

  /* ── ۴) مودال راهنما (iOS و سایر مرورگرها) ── */
  function modal(title, steps, tip) {
    injectCss();
    var old = document.getElementById('pwaIos'); if (old) old.parentNode.removeChild(old);
    var wrap = document.createElement('div');
    wrap.className = 'pwa-ios'; wrap.id = 'pwaIos';
    wrap.innerHTML = '<div class="pwa-ios-card" role="dialog" aria-modal="true">'
      + '<h3>' + title + '</h3><ol>' + steps.map(function (s) { return '<li>' + s + '</li>'; }).join('') + '</ol>'
      + '<button class="pwa-ios-go" type="button">متوجه شدم ✓</button>'
      + (tip ? '<div class="pwa-ios-tip">' + tip + '</div>' : '')
      + '</div>';
    wrap.addEventListener('click', function (e) { if (e.target === wrap || e.target.classList.contains('pwa-ios-go')) document.body.removeChild(wrap); });
    document.body.appendChild(wrap);
  }

  /* ── ۵) نصب ── */
  function revealBtns() {
    if (!canInstall) return;
    var els = document.querySelectorAll('[data-pwa-install]');
    for (var i = 0; i < els.length; i++) els[i].hidden = false;
  }
  function revealFab() {
    if (!canInstall) return;
    if (window.PWA_FAB === false || dismissed) return;
    if (!document.body) return;
    if (document.getElementById('pwaFab')) return;
    injectCss();
    var f = document.createElement('div');
    f.className = 'pwa-fab'; f.id = 'pwaFab';
    f.innerHTML = '<button class="pwa-fab-btn" type="button"><span class="ic">📲</span>'
      + '<span>نصب اپ روی گوشی<small>یک‌بار نصب، همیشه در دسترس</small></span></button>'
      + '<button class="pwa-fab-x" type="button" aria-label="بستن">×</button>';
    f.querySelector('.pwa-fab-btn').addEventListener('click', function () { window.pwaInstall(); });
    f.querySelector('.pwa-fab-x').addEventListener('click', function () { window.pwaDismissFab(); });
    document.body.appendChild(f);
  }
  function hideAll() {
    var f = document.getElementById('pwaFab'); if (f && f.parentNode) f.parentNode.removeChild(f);
    var els = document.querySelectorAll('[data-pwa-install]');
    for (var i = 0; i < els.length; i++) els[i].hidden = true;
  }

  window.pwaInstall = function () {
    if (deferred && deferred.prompt) {
      var d = deferred; deferred = null;
      d.prompt();
      var done = function () { hideAll(); };
      if (d.userChoice && d.userChoice.then) d.userChoice.then(done, done); else done();
      return;
    }
    if (isIOS) {
      modal('📲 نصب روی iPhone / iPad', [
        'در <b>سافاری</b> پایین صفحه، دکمهٔ <b>اشتراک‌گذاری</b> (مربع با فلش رو به بالا) را بزنید.',
        'گزینهٔ <b>«افزودن به صفحهٔ خانه»</b> — Add to Home Screen — را انتخاب کنید.',
        'در پنجرهٔ باز‌شده <b>«افزودن»</b> را بزنید. تمام! آیکون فیدا روی صفحهٔ اصلی می‌آید.'
      ], 'پس از نصب، اپ تمام‌صفحه و بدون نوار مرورگر باز می‌شود.');
      return;
    }
    modal('📲 نصب اپ روی گوشی', [
      'در مرورگر، منوی <b>⋮</b> (سه‌نقطه، بالا یا پایین) را باز کنید.',
      'گزینهٔ <b>«نصب برنامه»</b> یا <b>«افزودن به صفحهٔ اصلی»</b> را انتخاب کنید.',
      'تأیید کنید تا آیکون اپ روی صفحهٔ اصلی یا کشوی برنامه‌ها ساخته شود.'
    ], 'اگر گزینهٔ نصب را نمی‌بینید، از منوی مرورگر صفحه را رفرش کنید.');
  };
  window.pwaDismissFab = function () {
    ls(LSK, '1');
    var f = document.getElementById('pwaFab'); if (f && f.parentNode) f.parentNode.removeChild(f);
  };

  /* ── ۶) رویدادهای نصب ── */
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferred = e;
    revealBtns();
    revealFab();
  });
  window.addEventListener('appinstalled', function () {
    ls(LSK, '1');
    hideAll();
    try { console.log('[PWA] app installed'); } catch (e) {}
  });

  /* ── ۷) راه‌اندازی ── */
  function boot() {
    if (!canInstall) { hideAll(); return; }
    revealBtns();                                  // دکمه‌های «نصب اپ» همان لحظه فعال شوند
    if (isIOS || deferred) revealFab();            // iOS یا وجود پیشنهاد نصب یک‌کلیکی
    // اگر مرورگر دیرتر پیشنهاد نصب را آماده کرد
    setTimeout(function () { if (canInstall && deferred) { revealBtns(); revealFab(); } }, 3000);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
  window.pwaReveal = function () { revealBtns(); revealFab(); };   // برای آزمون/استفادهٔ داخلی

  /* ── ۸) نشانه‌گذاری حالت نصب‌شده برای CSS ── */
  try {
    if (standalone()) document.documentElement.classList.add('is-standalone');
    if (window.matchMedia) window.matchMedia('(display-mode: standalone)').addEventListener('change', function (ev) {
      document.documentElement.classList.toggle('is-standalone', ev.matches);
      if (ev.matches) hideAll();
    });
  } catch (e) {}
})();

/* ── موبایل: دکمهٔ نصب جمع‌وجورتر ── */
(function () {
  var s = document.createElement('style');
  s.textContent = '@media (max-width:430px){.pwa-fab-btn small{display:none}.pwa-fab-btn{padding:10px 12px;font-size:12.5px}.pwa-fab-x{width:24px;height:24px}}';
  document.head.appendChild(s);
})();
