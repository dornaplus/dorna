/* ══════════════════════════════════════════════════════════════════════
   فینتو / فیدا — سرویس‌ورکر PWA
   • دارایی‌های ظاهری (CSS/JS/فونت/آیکون) با راهبرد «شبکه اول، کش پشتیبان»
     ذخیره می‌شوند تا هم به‌روزرسانی فوری باشد و هم آفلاین کار کند.
   • صفحه‌های HTML و پاسخ‌های POST هرگز کش نمی‌شوند (امنیت دادهٔ کاربران).
   • وقتی اینترنت قطع است، صفحهٔ offline.html نمایش داده می‌شود.
   اجرا از ریشهٔ دامنه یا زیرپوشه پشتیبانی می‌شود (BASE از scope محاسبه می‌شود).
   ══════════════════════════════════════════════════════════════════════ */
const VERSION = 'finto-pwa-v1.0.0';
const CACHE = VERSION;
const BASE = new URL('./', self.location).pathname.replace(/\/+$/, '');   // '' یا '/زیرپوشه'

const SHELL = [
  BASE + '/offline.html',
  BASE + '/assets/theme.css',
  BASE + '/assets/fida.css',
  BASE + '/assets/app.js',
  BASE + '/assets/pwa.js',
  BASE + '/assets/fida-owl.png',
  BASE + '/assets/pwa/fida-192.png',
  BASE + '/assets/pwa/fida-512.png',
  BASE + '/assets/pwa/finto-192.png',
  BASE + '/assets/pwa/finto-512.png',
  BASE + '/assets/fonts/vazirmatn-arabic.woff2',
  BASE + '/assets/fonts/vazirmatn-latin.woff2',
  BASE + '/assets/fonts/Vazirmatn-Regular.woff2',
  BASE + '/assets/fonts/Vazirmatn-SemiBold.woff2'
];

/* ── نصب: پیش‌کش قالب پایه ── */
self.addEventListener('install', (e) => {
  e.waitUntil((async () => {
    const c = await caches.open(CACHE);
    // هر قلم را جدا اضافه می‌کنیم تا یک خطا کل نصب را خراب نکند
    await Promise.all(SHELL.map((u) => c.add(new Request(u, { cache: 'reload' })).catch(() => {})));
    self.skipWaiting();
  })());
});

/* ── فعال‌سازی: پاک‌سازی کش‌های قدیمی ── */
self.addEventListener('activate', (e) => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (e) => {
  if (e.data === 'skipWaiting' || (e.data && e.data.type === 'skipWaiting')) self.skipWaiting();
});

const STATIC_RE = /\.(css|js|mjs|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|otf|webmanifest|json)$/i;

function isStatic(url) {
  return url.pathname.includes('/assets/') || STATIC_RE.test(url.pathname);
}

/* ── واکشی ── */
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;                       // POST/PUT/... هرگز کش نمی‌شود
  let url;
  try { url = new URL(req.url); } catch (_) { return; }
  if (url.origin !== self.location.origin) return;        // منابع بیرونی دست‌نخورده

  // ۱) دارایی ظاهری: شبکه اول، در نبود شبکه از کش
  if (isStatic(url)) {
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        if (res && res.ok && (res.type === 'basic' || res.type === 'default')) {
          const c = await caches.open(CACHE);
          c.put(req, res.clone()).catch(() => {});
        }
        return res;
      } catch (_) {
        const hit = await caches.match(req, { ignoreSearch: true });
        if (hit) return hit;
        return Response.error();
      }
    })());
    return;
  }

  // ۲) رفت‌وآمد صفحه (HTML): شبکه اول و در قطعی، صفحهٔ آفلاین
  const isNav = req.mode === 'navigate' || (req.headers.get('accept') || '').includes('text/html');
  if (isNav) {
    e.respondWith((async () => {
      try {
        return await fetch(req);
      } catch (_) {
        const off = await caches.match(BASE + '/offline.html');
        return off || new Response('آفلاین', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
      }
    })());
    return;
  }

  // ۳) بقیهٔ درخواست‌ها (API/اعلان‌ها): شبکهٔ خالی
});
